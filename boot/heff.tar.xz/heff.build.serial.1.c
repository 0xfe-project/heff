// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_clo;
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ebuild_2eserial_2eabsOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eabsOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo;
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V, V, V);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      V v_t_2410 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_247, v_a_245));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      V v_t_2410 = ({ V a_0 = v_a_247; V a_1 = v_a_245; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_a_247); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SmallU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1), v_rest_241})});
    }
    case TAG_LargeU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3), v_rest_241})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_x2_240, 0);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_243), v_rest_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4), v_t_244});
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_dflt_249 = heff_field(v_x2_240, 4);
    V v_t_2410;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_dflt_249)) {
    case TAG_Nothing: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2412 = heff_field(v_dflt_249, 0);
      V v_t_2413 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2412), v_rest_241));
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12), v_t_2413});
      break;
    }
    default: heff_nomatch(v_dflt_249);
    }
    V v_rest_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2414});
    V v_rest_2423;
    switch (heff_tag_of(v_cod_247)) {
    case TAG_MkAbs: {
      V v_x_2416 = heff_field(v_cod_247, 0);
      V v_e_2417 = heff_field(v_cod_247, 1);
      V v_t_2418 = heff_intShow(heff_strLength_lent(v_x_2416, 0));
      V v_t_2419 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13), heff_dup(v_x_2416)));
      V v_t_2420 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2417, v_rest_2415));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2420})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2421 = heff_field(v_cod_247, 0);
      V v_t_2422 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2421, v_rest_2415));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15), v_t_2422});
      break;
    }
    default: heff_nomatch(v_cod_247);
    }
    V v_t_2424 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_246, v_rest_2423));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2424})});
  }
  case TAG_SRecord: {
    V v_level_2425 = heff_field(v_x2_240, 0);
    V v_fs_2426 = heff_field(v_x2_240, 1);
    V v_ds_2427 = heff_field(v_x2_240, 2);
    V v_t_2428;
    switch (heff_tag_of(v_level_2425)) {
    case TAG_Small: {
      v_t_2428 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17);
      break;
    }
    case TAG_Large: {
      v_t_2428 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2428 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19);
      break;
    }
    default: heff_nomatch(v_level_2425);
    }
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2427, 0)));
    V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2427, 2)));
    V v_xs_2431 = (g_heff_2eutil_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_i_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2431));
    V v_t_2433 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20), v_xs_2431, v_rest_241));
    V v_rest_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2432), v_t_2433});
    V v_t_2435 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2426, 0)));
    V v_t_2436 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2426, 2)));
    V v_xs_2437 = (g_heff_2eutil_2edict_2ezipKV(v_t_2435, v_t_2436));
    V v_i_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2437));
    V v_t_2439 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21), v_xs_2437, v_rest_2434));
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), v_t_2439});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2440})});
  }
  case TAG_SSum: {
    V v_vs_2441 = heff_field(v_x2_240, 0);
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2441, 0)));
    V v_t_2443 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2441, 2)));
    V v_xs_2444 = (g_heff_2eutil_2edict_2ezipKV(v_t_2442, v_t_2443));
    V v_i_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2444));
    V v_t_2446 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2444, v_rest_241));
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2445), v_t_2446});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24), v_t_2447});
  }
  case TAG_SIsTy: {
    V v_t2_2448 = heff_field(v_x2_240, 0);
    V v_cell_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25), heff_hole()});
    V v_u_2450 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2448, v_rest_241, heff_dup(v_cell_2449)));
    heff_drop(v_u_2450);
    return v_cell_2449;
  }
  case TAG_SPrimInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26), v_rest_241});
  }
  case TAG_SPrimFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27), v_rest_241});
  }
  case TAG_SPrimString: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28), v_rest_241});
  }
  case TAG_SPrimRune: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29), v_rest_241});
  }
  case TAG_SPrimArray: {
    V v_t2_2451 = heff_field(v_x2_240, 0);
    V v_cell_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30), heff_hole()});
    V v_u_2453 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2451, v_rest_241, heff_dup(v_cell_2452)));
    heff_drop(v_u_2453);
    return v_cell_2452;
  }
  case TAG_SFixed: {
    V v_w_2454 = heff_field(v_x2_240, 0);
    V v_t_2455;
    switch (heff_tag_of(v_w_2454)) {
    case TAG_I8: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31);
      break;
    }
    case TAG_I16: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32);
      break;
    }
    case TAG_I32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33);
      break;
    }
    case TAG_I64: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34);
      break;
    }
    case TAG_U8: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35);
      break;
    }
    case TAG_U16: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36);
      break;
    }
    case TAG_U32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37);
      break;
    }
    case TAG_U64: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38);
      break;
    }
    case TAG_F32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39);
      break;
    }
    default: heff_nomatch(v_w_2454);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_rest_245;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2411 = heff_intShow(heff_strLength_lent(v_a_249, 0));
      V v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(v_lit_240, v_a_249));
      V v_t_2419;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_a_2410, 0);
        V v_a_2414 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2415 = heff_arrayToList(v_a_2413);
        V v_a_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2414, v_a_248));
        V v_a_2417 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2415));
        V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(v_lit_243, v_a_2415, v_a_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2417), v_t_2418});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2412, v_t_2419});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_242), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0), v_t_243});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_244, 0));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1), v_x_244));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_rest_241})});
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3), v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_x2_240, 0);
    V v_a_2410 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2411 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2410, v_rest_241));
    V v_t_2412 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_f_249, v_rest_2411));
    return heff_tag_at_n(v_ru_24x2_240_24SApp, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4), v_t_2412});
  }
  case TAG_SLam: {
    V v_t_2413 = heff_field(v_x2_240, 0);
    V v_b_2414 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2422;
    switch (heff_tag_of(v_b_2414)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2414, 0);
      V v_e_2416 = heff_field(v_b_2414, 1);
      heff_take_n(v_b_2414, 3ULL, 2);
      V v_t_2417 = heff_intShow(heff_strLength_lent(v_x_2415, 0));
      V v_t_2418 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5), v_x_2415));
      V v_t_2419 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2416, v_rest_241));
      v_rest_2422 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2419})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2420 = heff_field(v_b_2414, 0);
      heff_take_n(v_b_2414, 1ULL, 1);
      V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2420, v_rest_241));
      v_rest_2422 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7), v_t_2421});
      break;
    }
    default: heff_nomatch(v_b_2414);
    }
    V v_t_2423 = ({ V a_0 = v_t_2413; V a_1 = v_rest_2422; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8), v_t_2423});
  }
  case TAG_SCons: {
    V v_d_2424 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2425 = heff_arrayToList(heff_take_field(v_d_2424, 0));
    V v_t_2426 = heff_arrayToList(heff_get_n(v_d_2424, 2, 3));
    V v_xs_2427 = (g_heff_2eutil_2edict_2ezipKV(v_t_2425, v_t_2426));
    V v_i_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2427));
    V v_t_2429 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9), v_xs_2427, v_rest_241));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2428), v_t_2429});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10), v_t_2430});
  }
  case TAG_SProj: {
    V v_e2_2431 = heff_field(v_x2_240, 0);
    V v_l_2432 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2433 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11), heff_hole()});
    V v_t_2434 = heff_intShow(heff_strLength_lent(v_l_2432, 0));
    V v_t_2435 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12), v_l_2432));
    V v_u_2436 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2431, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_rest_241}), heff_dup(v_cell_2433)));
    heff_drop(v_u_2436);
    return v_cell_2433;
  }
  case TAG_STag: {
    V v_t_2437 = heff_field(v_x2_240, 0);
    V v_as_2438 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439 = heff_intShow(heff_strLength_lent(v_t_2437, 0));
    V v_t_2440 = heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13), v_t_2437));
    V v_xs_2441 = heff_arrayToList(v_as_2438);
    V v_i_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = ({ V a_0 = v_xs_2441; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2441); r_; });
    V v_t_2444 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2444})});
  }
  case TAG_SMatch: {
    V v_e2_2445 = heff_field(v_x2_240, 0);
    V v_cs_2446 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2447 = heff_arrayToList(heff_take_field(v_cs_2446, 0));
    V v_t_2448 = heff_arrayToList(heff_get_n(v_cs_2446, 2, 3));
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_i_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16), v_xs_2449, v_rest_241));
    V v_rest_2452 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    V v_t_2453 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2445, v_rest_2452));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17), v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e2_2454 = heff_field(v_x2_240, 0);
    V v_l_2455 = heff_field(v_x2_240, 1);
    V v_v_2456 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2457 = heff_intShow(heff_strLength_lent(v_l_2455, 0));
    V v_t_2458 = heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18), v_l_2455));
    V v_t_2459 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2456, v_rest_241));
    V v_rest_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2459});
    V v_t_2461 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2454, v_rest_2460));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19), v_t_2461});
  }
  case TAG_SIs: {
    V v_e2_2462 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20), heff_hole()});
    V v_u_2464 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2462, v_rest_241, heff_dup(v_cell_2463)));
    heff_drop(v_u_2464);
    return v_cell_2463;
  }
  case TAG_SOpaque: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21), v_rest_241});
  }
  case TAG_SAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22), v_rest_241});
  }
  case TAG_SRec: {
    V v_e2_2465 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23), heff_hole()});
    V v_u_2467 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2465, v_rest_241, heff_dup(v_cell_2466)));
    heff_drop(v_u_2467);
    return v_cell_2466;
  }
  case TAG_SFix: {
    V v_t_2468 = heff_field(v_x2_240, 0);
    V v_b_2469 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2477;
    switch (heff_tag_of(v_b_2469)) {
    case TAG_MkAbs: {
      V v_x_2470 = heff_field(v_b_2469, 0);
      V v_e_2471 = heff_field(v_b_2469, 1);
      heff_take_n(v_b_2469, 3ULL, 2);
      V v_t_2472 = heff_intShow(heff_strLength_lent(v_x_2470, 0));
      V v_t_2473 = heff_strAppend(v_t_2472, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24), v_x_2470));
      V v_t_2474 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2471, v_rest_241));
      v_rest_2477 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2474})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2475 = heff_field(v_b_2469, 0);
      heff_take_n(v_b_2469, 1ULL, 1);
      V v_t_2476 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2475, v_rest_241));
      v_rest_2477 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26), v_t_2476});
      break;
    }
    default: heff_nomatch(v_b_2469);
    }
    V v_t_2478 = ({ V a_0 = v_t_2468; V a_1 = v_rest_2477; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2468); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27), v_t_2478});
  }
  case TAG_SImplicit: {
    V v_x_2479 = heff_field(v_x2_240, 0);
    V v_e2_2480 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2481 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28), heff_hole()});
    V v_t_2482 = heff_intShow(heff_strLength_lent(v_x_2479, 0));
    V v_t_2483 = heff_strAppend(v_t_2482, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29), v_x_2479));
    V v_cell_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, heff_hole()});
    V v_u_2485 = heff_setField(heff_dup(v_cell_2481), MK_INT(1LL), heff_dup(v_cell_2484));
    heff_drop(v_u_2485);
    V v_u_2486 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2480, v_rest_241, v_cell_2484));
    heff_drop(v_u_2486);
    return v_cell_2481;
  }
  case TAG_SPrim: {
    V v_x_2487 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2488 = heff_intShow(heff_strLength_lent(v_x_2487, 0));
    V v_t_2489 = heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30), v_x_2487));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_rest_241})});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32), v_rest_241});
  }
  case TAG_SLitInt: {
    V v_i_2493 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2494 = heff_intShow(v_i_2493);
    V v_t_2495 = heff_intShow(heff_strLength_lent(v_s_2494, 0));
    V v_t_2496 = heff_strAppend(v_t_2495, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33), v_s_2494));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2496, v_rest_241})});
  }
  case TAG_SLitFloat: {
    V v_x_2497 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_2498 = heff_floatShow(v_x_2497);
    V v_t_2499 = heff_intShow(heff_strLength_lent(v_s_2498, 0));
    V v_t_24100 = heff_strAppend(v_t_2499, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35), v_s_2498));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, v_rest_241})});
  }
  case TAG_SLitString: {
    V v_s_24101 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24102 = heff_intShow(heff_strLength_lent(v_s_24101, 0));
    V v_t_24103 = heff_strAppend(v_t_24102, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37), v_s_24101));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, v_rest_241})});
  }
  case TAG_SLitBytes: {
    V v_s_24104 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24105 = heff_intShow(heff_strLength_lent(v_s_24104, 0));
    V v_t_24106 = heff_strAppend(v_t_24105, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39), v_s_24104));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, v_rest_241})});
  }
  case TAG_SLitRune: {
    V v_c_24107 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24108 = heff_intShow(v_c_24107);
    V v_t_24109 = heff_intShow(heff_strLength_lent(v_s_24108, 0));
    V v_t_24110 = heff_strAppend(v_t_24109, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41), v_s_24108));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_rest_241})});
  }
  case TAG_SLitFixed: {
    V v_w_24111 = heff_field(v_x2_240, 0);
    V v_n_24112 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24113;
    switch (heff_tag_of(v_w_24111)) {
    case TAG_I8: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43);
      break;
    }
    case TAG_I16: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44);
      break;
    }
    case TAG_I32: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45);
      break;
    }
    case TAG_I64: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46);
      break;
    }
    case TAG_U8: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47);
      break;
    }
    case TAG_U16: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48);
      break;
    }
    case TAG_U32: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49);
      break;
    }
    case TAG_U64: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50);
      break;
    }
    case TAG_F32: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51);
      break;
    }
    default: heff_nomatch(v_w_24111);
    }
    V v_s_24114 = heff_intShow(v_n_24112);
    V v_t_24115 = heff_intShow(heff_strLength_lent(v_s_24114, 0));
    V v_t_24116 = heff_strAppend(v_t_24115, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52), v_s_24114));
    V v_t_24117 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24113, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24116, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53), v_t_24117});
  }
  case TAG_SLitFloat32: {
    V v_x_24118 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24119 = heff_floatShow(v_x_24118);
    V v_t_24120 = heff_intShow(heff_strLength_lent(v_s_24119, 0));
    V v_t_24121 = heff_strAppend(v_t_24120, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54), v_s_24119));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24121, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_243 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_243), v_rest_241});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0), v_t_244}));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_245, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1), v_x_245));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_SCode: {
    V v_t_249 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_249); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3), v_t_2410}));
  }
  case TAG_SApp: {
    V v_f_2411 = heff_field(v_x2_240, 0);
    V v_a_2412 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_rest_2413 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2412, v_rest_241));
    V v_t_2414 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_f_2411, v_rest_2413));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4), v_t_2414}));
  }
  case TAG_SLam: {
    V v_t_2415 = heff_field(v_x2_240, 0);
    V v_b_2416 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2424;
    switch (heff_tag_of(v_b_2416)) {
    case TAG_MkAbs: {
      V v_x_2417 = heff_field(v_b_2416, 0);
      V v_e_2418 = heff_field(v_b_2416, 1);
      heff_take_n(v_b_2416, 3ULL, 2);
      V v_t_2419 = heff_intShow(heff_strLength_lent(v_x_2417, 0));
      V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5), v_x_2417));
      V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2418, v_rest_241));
      v_rest_2424 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2421})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2422 = heff_field(v_b_2416, 0);
      heff_take_n(v_b_2416, 1ULL, 1);
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2422, v_rest_241));
      v_rest_2424 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7), v_t_2423});
      break;
    }
    default: heff_nomatch(v_b_2416);
    }
    V v_t_2425 = ({ V a_0 = v_t_2415; V a_1 = v_rest_2424; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8), v_t_2425}));
  }
  case TAG_SCons: {
    V v_d_2426 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2427 = heff_arrayToList(heff_take_field(v_d_2426, 0));
    V v_t_2428 = heff_arrayToList(heff_get_n(v_d_2426, 2, 3));
    V v_xs_2429 = (g_heff_2eutil_2edict_2ezipKV(v_t_2427, v_t_2428));
    V v_i_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2429));
    V v_t_2431 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9), v_xs_2429, v_rest_241));
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2430), v_t_2431});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10), v_t_2432}));
  }
  case TAG_SProj: {
    V v_e2_2433 = heff_field(v_x2_240, 0);
    V v_l_2434 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2435 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11), heff_hole()});
    V v_u_2436 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2435));
    heff_drop(v_u_2436);
    V v_t_2437 = heff_intShow(heff_strLength_lent(v_l_2434, 0));
    V v_t_2438 = heff_strAppend(v_t_2437, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12), v_l_2434));
    V t_0 = v_e2_2433;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_rest_241});
    V t_2 = v_cell_2435;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_STag: {
    V v_t_2439 = heff_field(v_x2_240, 0);
    V v_as_2440 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2441 = heff_intShow(heff_strLength_lent(v_t_2439, 0));
    V v_t_2442 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13), v_t_2439));
    V v_xs_2443 = heff_arrayToList(v_as_2440);
    V v_i_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2443));
    V v_t_2445 = ({ V a_0 = v_xs_2443; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2443); r_; });
    V v_t_2446 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2444), v_t_2445});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2446})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2447);
  }
  case TAG_SMatch: {
    V v_e2_2448 = heff_field(v_x2_240, 0);
    V v_cs_2449 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2450 = heff_arrayToList(heff_take_field(v_cs_2449, 0));
    V v_t_2451 = heff_arrayToList(heff_get_n(v_cs_2449, 2, 3));
    V v_xs_2452 = (g_heff_2eutil_2edict_2ezipKV(v_t_2450, v_t_2451));
    V v_i_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2452));
    V v_t_2454 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16), v_xs_2452, v_rest_241));
    V v_rest_2455 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2453), v_t_2454});
    V v_t_2456 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2448, v_rest_2455));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17), v_t_2456}));
  }
  case TAG_SSpecialize: {
    V v_e2_2457 = heff_field(v_x2_240, 0);
    V v_l_2458 = heff_field(v_x2_240, 1);
    V v_v_2459 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2460 = heff_intShow(heff_strLength_lent(v_l_2458, 0));
    V v_t_2461 = heff_strAppend(v_t_2460, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18), v_l_2458));
    V v_t_2462 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2459, v_rest_241));
    V v_rest_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, v_t_2462});
    V v_t_2464 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2457, v_rest_2463));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19), v_t_2464}));
  }
  case TAG_SIs: {
    V v_e2_2465 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20), heff_hole()});
    V v_u_2467 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2466));
    heff_drop(v_u_2467);
    V t_0 = v_e2_2465;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2466;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21), v_rest_241}));
  }
  case TAG_SAbandon: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22), v_rest_241}));
  }
  case TAG_SRec: {
    V v_e2_2468 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2469 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23), heff_hole()});
    V v_u_2470 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2469));
    heff_drop(v_u_2470);
    V t_0 = v_e2_2468;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2469;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_t_2471 = heff_field(v_x2_240, 0);
    V v_b_2472 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2480;
    switch (heff_tag_of(v_b_2472)) {
    case TAG_MkAbs: {
      V v_x_2473 = heff_field(v_b_2472, 0);
      V v_e_2474 = heff_field(v_b_2472, 1);
      heff_take_n(v_b_2472, 3ULL, 2);
      V v_t_2475 = heff_intShow(heff_strLength_lent(v_x_2473, 0));
      V v_t_2476 = heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24), v_x_2473));
      V v_t_2477 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2474, v_rest_241));
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_t_2477})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2478 = heff_field(v_b_2472, 0);
      heff_take_n(v_b_2472, 1ULL, 1);
      V v_t_2479 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2478, v_rest_241));
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26), v_t_2479});
      break;
    }
    default: heff_nomatch(v_b_2472);
    }
    V v_t_2481 = ({ V a_0 = v_t_2471; V a_1 = v_rest_2480; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2471); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27), v_t_2481}));
  }
  case TAG_SImplicit: {
    V v_x_2482 = heff_field(v_x2_240, 0);
    V v_e2_2483 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2484 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28), heff_hole()});
    V v_u_2485 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2484));
    heff_drop(v_u_2485);
    V v_t_2486 = heff_intShow(heff_strLength_lent(v_x_2482, 0));
    V v_t_2487 = heff_strAppend(v_t_2486, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29), v_x_2482));
    V v_cell_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, heff_hole()});
    V v_u_2489 = heff_setField(v_cell_2484, MK_INT(1LL), heff_dup(v_cell_2488));
    heff_drop(v_u_2489);
    V t_0 = v_e2_2483;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2488;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2490 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2491 = heff_intShow(heff_strLength_lent(v_x_2490, 0));
    V v_t_2492 = heff_strAppend(v_t_2491, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30), v_x_2490));
    V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2492, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2493);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32), v_rest_241}));
  }
  case TAG_SLitInt: {
    V v_i_2497 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2498 = heff_intShow(v_i_2497);
    V v_t_2499 = heff_intShow(heff_strLength_lent(v_s_2498, 0));
    V v_t_24100 = heff_strAppend(v_t_2499, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33), v_s_2498));
    V v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24101);
  }
  case TAG_SLitFloat: {
    V v_x_24102 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24103 = heff_floatShow(v_x_24102);
    V v_t_24104 = heff_intShow(heff_strLength_lent(v_s_24103, 0));
    V v_t_24105 = heff_strAppend(v_t_24104, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35), v_s_24103));
    V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24105, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24106);
  }
  case TAG_SLitString: {
    V v_s_24107 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24108 = heff_intShow(heff_strLength_lent(v_s_24107, 0));
    V v_t_24109 = heff_strAppend(v_t_24108, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37), v_s_24107));
    V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24110);
  }
  case TAG_SLitBytes: {
    V v_s_24111 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24112 = heff_intShow(heff_strLength_lent(v_s_24111, 0));
    V v_t_24113 = heff_strAppend(v_t_24112, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39), v_s_24111));
    V v_t_24114 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24114);
  }
  case TAG_SLitRune: {
    V v_c_24115 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24116 = heff_intShow(v_c_24115);
    V v_t_24117 = heff_intShow(heff_strLength_lent(v_s_24116, 0));
    V v_t_24118 = heff_strAppend(v_t_24117, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41), v_s_24116));
    V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24119);
  }
  case TAG_SLitFixed: {
    V v_w_24120 = heff_field(v_x2_240, 0);
    V v_n_24121 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24122;
    switch (heff_tag_of(v_w_24120)) {
    case TAG_I8: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43);
      break;
    }
    case TAG_I16: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44);
      break;
    }
    case TAG_I32: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45);
      break;
    }
    case TAG_I64: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46);
      break;
    }
    case TAG_U8: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47);
      break;
    }
    case TAG_U16: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48);
      break;
    }
    case TAG_U32: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49);
      break;
    }
    case TAG_U64: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50);
      break;
    }
    case TAG_F32: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51);
      break;
    }
    default: heff_nomatch(v_w_24120);
    }
    V v_s_24123 = heff_intShow(v_n_24121);
    V v_t_24124 = heff_intShow(heff_strLength_lent(v_s_24123, 0));
    V v_t_24125 = heff_strAppend(v_t_24124, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52), v_s_24123));
    V v_t_24126 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24122, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24125, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53), v_t_24126}));
  }
  case TAG_SLitFloat32: {
    V v_x_24127 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24128 = heff_floatShow(v_x_24127);
    V v_t_24129 = heff_intShow(heff_strLength_lent(v_s_24128, 0));
    V v_t_24130 = heff_strAppend(v_t_24129, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54), v_s_24128));
    V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24131);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_24cpr_str1, 1, "_");

HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V v_d_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_24cpr_str0), 2)) {
    heff_drop(v_x2_241);
    HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x31_249 = v_field_247;
        switch (heff_tag_of(v_x31_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x31_249, 0);
          V v_j_2411 = heff_field(v_x31_249, 1);
          V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
          V v_x3_2412 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_j_2411}));
          switch (heff_tag_of(v_x3_2412)) {
          case TAG_Nothing: {
            heff_drop(v_x_2410);
            heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2413 = heff_field(v_x3_2412, 0);
            heff_take_n(v_x3_2412, 1ULL, 1);
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              V v_t_2416 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2410, v_x_2414}), v_j_2415});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2412)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
        }
      } else {
        heff_drop(v_d_240);
        heff_drop(v_z_242);
        heff_drop(v_field_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_24cpr_str1))) {
      V v_x3_2418 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_2418)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_2419 = heff_field(v_x3_2418, 0);
        V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
        switch (heff_tag_of(v_x31_2419)) {
        case TAG_MkPair: {
          V v_x_2420 = heff_field(v_x31_2419, 0);
          V v_j_2421 = heff_field(v_x31_2419, 1);
          V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
          V v_t_2422 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_AbsConst, 1, (V[]){v_x_2420}), v_j_2421});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2422}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_2418)}});
      }
    } else {
      heff_drop(v_d_240);
      return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
    }
  }
}
Clo g_heff_2ebuild_2eserial_2eabsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eabsOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2eabsOf(V v_d_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(v_d_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2eabsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eabsOf(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2eserial_2etermOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etermOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eserial_2etermOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etermOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str1, 1, "n");
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_lam1, 2, 0};
Clo g_heff_2ebuild_2eserial_2edefaultOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2edefaultOf(V v_k_240, V v_x2_241) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str0), 2)) {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ebuild_2eserial_2edefaultOf_lam0, 2, 1, (V[]){v_k_240});
  } else {
    heff_drop_rec(v_k_240, 2);
    if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str1))) {
      return ((V)&g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo);
    } else {
      return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2edefaultOf(a[0], a[1]);
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_245 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_243, v_i_244}));
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_x_247}), v_j_248});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_i_2412 = args[1];
  heff_drop(v_s_2411);
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_i_2412});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
}
Clo g_heff_2ebuild_2eserial_2etakeFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeFields_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeFields(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_s_241), v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    V v_x3_2410;
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        heff_take_n(v_x31_247, 3ULL, 2);
        v_x3_2410 = (g_heff_2ebuild_2edecoder_2etimes(heff_get_n(v_k_240, 1, 2), v_x_248, v_s_241, v_j_249));
        break;
      }
      default: heff_nomatch(v_x31_247);
      }
    } else {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      v_x3_2410 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_2411 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      switch (heff_tag_of(v_x31_2411)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_field(v_x31_2411, 0);
        V v_j_2413 = heff_field(v_x31_2411, 1);
        V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
        V v_t_2414 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2412), v_j_2413});
        return heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_Just, 1, (V[]){v_t_2414});
      }
      default: return heff_nomatch(v_x31_2411);
      }
    }
    default: return heff_nomatch(v_x3_2410);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeFields(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etypeOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eserial_2etypeOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etypeOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str24, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str25, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str26, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str27, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str28, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str29, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str31, 0, "");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_z_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_248 = v_field_246;
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          V v_ru_24x31_248_24MkPair = heff_take_reuse_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_249}), v_j_2410});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_248)}});
        }
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_2413 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_x31_2417 = v_field_2415;
          switch (heff_tag_of(v_x31_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x31_2417, 0);
            V v_j_2419 = heff_field(v_x31_2417, 1);
            V v_ru_24x31_2417_24MkPair = heff_take_reuse_n(v_x31_2417, 3ULL, 2);
            V v_t_2420 = heff_tag_at_n(v_ru_24x31_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2418}), v_j_2419});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
          }
        } else {
          heff_drop(v_field_2415);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2422 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          V v_x3_2429;
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_x31_2426 = v_field_2424;
            switch (heff_tag_of(v_x31_2426)) {
            case TAG_MkPair: {
              V v_x_2427 = heff_field(v_x31_2426, 0);
              V v_j_2428 = heff_field(v_x31_2426, 1);
              heff_take_n(v_x31_2426, 3ULL, 2);
              v_x3_2429 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2427, v_z_241, v_j_2428));
              break;
            }
            default: heff_nomatch(v_x31_2426);
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2424);
            v_x3_2429 = NTAG(TAG_Nothing);
          }
          switch (heff_tag_of(v_x3_2429)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2430 = heff_field(v_x3_2429, 0);
            V v_ru_24x3_2429_24Just = heff_take_reuse_n(v_x3_2429, 1ULL, 1);
            switch (heff_tag_of(v_x31_2430)) {
            case TAG_MkPair: {
              V v_x_2431 = heff_field(v_x31_2430, 0);
              V v_j_2432 = heff_field(v_x31_2430, 1);
              V v_ru_24x31_2430_24MkPair = heff_take_reuse_n(v_x31_2430, 3ULL, 2);
              V v_t_2433 = heff_tag_at_n(v_ru_24x31_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2429_24Just, TAG_SCode, 1, (V[]){v_x_2431}), v_j_2432});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2433}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2430)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2429)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2435 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
          {
            V v_field_2437 = v_t_2435.f[1];
            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
            V v_x3_2442;
            if ((v_tag_2436 == ((int64_t)0ULL))) {
              V v_x31_2439 = v_field_2437;
              switch (heff_tag_of(v_x31_2439)) {
              case TAG_MkPair: {
                V v_x_2440 = heff_field(v_x31_2439, 0);
                V v_j_2441 = heff_field(v_x31_2439, 1);
                heff_take_n(v_x31_2439, 3ULL, 2);
                v_x3_2442 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2440, heff_dup(v_z_241), v_j_2441));
                break;
              }
              default: heff_nomatch(v_x31_2439);
              }
            } else {
              heff_drop(v_field_2437);
              v_x3_2442 = NTAG(TAG_Nothing);
            }
            switch (heff_tag_of(v_x3_2442)) {
            case TAG_Nothing: {
              heff_drop(v_z_241);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_2443 = heff_field(v_x3_2442, 0);
              heff_take_n(v_x3_2442, 1ULL, 1);
              switch (heff_tag_of(v_x31_2443)) {
              case TAG_MkPair: {
                V v_x_2444 = heff_field(v_x31_2443, 0);
                V v_j_2445 = heff_field(v_x31_2443, 1);
                V v_ru_24x31_2443_24MkPair = heff_take_reuse_n(v_x31_2443, 3ULL, 2);
                HeffT2 v_t_2446 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_j_2445));
                {
                  V v_field_2448 = v_t_2446.f[1];
                  int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
                  V v_x3_2453;
                  if ((v_tag_2447 == ((int64_t)0ULL))) {
                    V v_x31_2450 = v_field_2448;
                    switch (heff_tag_of(v_x31_2450)) {
                    case TAG_MkPair: {
                      V v_x_2451 = heff_field(v_x31_2450, 0);
                      V v_j_2452 = heff_field(v_x31_2450, 1);
                      heff_take_n(v_x31_2450, 3ULL, 2);
                      v_x3_2453 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2451, v_z_241, v_j_2452));
                      break;
                    }
                    default: heff_nomatch(v_x31_2450);
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_field_2448);
                    v_x3_2453 = NTAG(TAG_Nothing);
                  }
                  switch (heff_tag_of(v_x3_2453)) {
                  case TAG_Nothing: {
                    heff_drop(v_x_2444);
                    heff_drop_cell(v_ru_24x31_2443_24MkPair, 2);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_2454 = heff_field(v_x3_2453, 0);
                    heff_take_n(v_x3_2453, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2454)) {
                    case TAG_MkPair: {
                      V v_x_2455 = heff_field(v_x31_2454, 0);
                      V v_j_2456 = heff_field(v_x31_2454, 1);
                      heff_take_n(v_x31_2454, 3ULL, 2);
                      V v_t_2457 = heff_tag_at_n(v_ru_24x31_2443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2444, v_x_2455}), v_j_2456});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2457}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2454)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2453)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2443)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x3_2442)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT2 v_t_2459 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
            {
              V v_field_2461 = v_t_2459.f[1];
              int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
              V v_x3_2466;
              if ((v_tag_2460 == ((int64_t)0ULL))) {
                V v_x31_2463 = v_field_2461;
                switch (heff_tag_of(v_x31_2463)) {
                case TAG_MkPair: {
                  V v_x_2464 = heff_field(v_x31_2463, 0);
                  V v_j_2465 = heff_field(v_x31_2463, 1);
                  heff_take_n(v_x31_2463, 3ULL, 2);
                  v_x3_2466 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2464, heff_dup(v_z_241), v_j_2465));
                  break;
                }
                default: heff_nomatch(v_x31_2463);
                }
              } else {
                heff_drop(v_field_2461);
                v_x3_2466 = NTAG(TAG_Nothing);
              }
              switch (heff_tag_of(v_x3_2466)) {
              case TAG_Nothing: {
                heff_drop(v_z_241);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_x31_2467 = heff_field(v_x3_2466, 0);
                heff_take_n(v_x3_2466, 1ULL, 1);
                switch (heff_tag_of(v_x31_2467)) {
                case TAG_MkPair: {
                  V v_x_2468 = heff_field(v_x31_2467, 0);
                  V v_j_2469 = heff_field(v_x31_2467, 1);
                  V v_ru_24x31_2467_24MkPair = heff_take_reuse_n(v_x31_2467, 3ULL, 2);
                  HeffT2 v_t_2470 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_j_2469));
                  {
                    V v_field_2472 = v_t_2470.f[1];
                    int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
                    V v_x3_2477;
                    if ((v_tag_2471 == ((int64_t)0ULL))) {
                      V v_x31_2474 = v_field_2472;
                      switch (heff_tag_of(v_x31_2474)) {
                      case TAG_MkPair: {
                        V v_x_2475 = heff_field(v_x31_2474, 0);
                        V v_j_2476 = heff_field(v_x31_2474, 1);
                        heff_take_n(v_x31_2474, 3ULL, 2);
                        v_x3_2477 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_2475, v_z_241, v_j_2476));
                        break;
                      }
                      default: heff_nomatch(v_x31_2474);
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop(v_field_2472);
                      v_x3_2477 = NTAG(TAG_Nothing);
                    }
                    switch (heff_tag_of(v_x3_2477)) {
                    case TAG_Nothing: {
                      heff_drop(v_x_2468);
                      heff_drop_cell(v_ru_24x31_2467_24MkPair, 2);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Just: {
                      V v_x31_2478 = heff_field(v_x3_2477, 0);
                      heff_take_n(v_x3_2477, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2478)) {
                      case TAG_MkPair: {
                        V v_x_2479 = heff_field(v_x31_2478, 0);
                        V v_j_2480 = heff_field(v_x31_2478, 1);
                        heff_take_n(v_x31_2478, 3ULL, 2);
                        V v_t_2481 = heff_tag_at_n(v_ru_24x31_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2468, v_x_2479}), v_j_2480});
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2481}});
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2478)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x3_2477)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2467)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x3_2466)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_2483 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_z_242));
              {
                V v_field_2485 = v_t_2483.f[1];
                int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
                if ((v_tag_2484 == ((int64_t)0ULL))) {
                  V v_x31_2487 = v_field_2485;
                  switch (heff_tag_of(v_x31_2487)) {
                  case TAG_MkPair: {
                    V v_x_2488 = heff_field(v_x31_2487, 0);
                    V v_j_2489 = heff_field(v_x31_2487, 1);
                    V v_ru_24x31_2487_24MkPair = heff_take_reuse_n(v_x31_2487, 3ULL, 2);
                    V v_t_2490 = heff_tag_at_n(v_ru_24x31_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2488}), v_j_2489});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2490}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2487)}});
                  }
                } else {
                  heff_drop(v_field_2485);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                HeffT2 v_t_2492 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
                {
                  V v_field_2494 = v_t_2492.f[1];
                  int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                  V v_x3_2499;
                  if ((v_tag_2493 == ((int64_t)0ULL))) {
                    V v_x31_2496 = v_field_2494;
                    switch (heff_tag_of(v_x31_2496)) {
                    case TAG_MkPair: {
                      V v_x_2497 = heff_field(v_x31_2496, 0);
                      V v_j_2498 = heff_field(v_x31_2496, 1);
                      heff_take_n(v_x31_2496, 3ULL, 2);
                      v_x3_2499 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2497, heff_dup(v_z_241), v_j_2498));
                      break;
                    }
                    default: heff_nomatch(v_x31_2496);
                    }
                  } else {
                    heff_drop(v_field_2494);
                    v_x3_2499 = NTAG(TAG_Nothing);
                  }
                  switch (heff_tag_of(v_x3_2499)) {
                  case TAG_Nothing: {
                    heff_drop(v_z_241);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_x31_24100 = heff_field(v_x3_2499, 0);
                    heff_take_n(v_x3_2499, 1ULL, 1);
                    switch (heff_tag_of(v_x31_24100)) {
                    case TAG_MkPair: {
                      V v_x_24101 = heff_field(v_x31_24100, 0);
                      V v_j_24102 = heff_field(v_x31_24100, 1);
                      V v_ru_24x31_24100_24MkPair = heff_take_reuse_n(v_x31_24100, 3ULL, 2);
                      HeffT2 v_t_24103 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_j_24102));
                      {
                        V v_field_24105 = v_t_24103.f[1];
                        int64_t v_tag_24104 = ((int64_t)v_t_24103.f[0]);
                        if ((v_tag_24104 == ((int64_t)0ULL))) {
                          V v_x31_24107 = v_field_24105;
                          switch (heff_tag_of(v_x31_24107)) {
                          case TAG_MkPair: {
                            V v_x_24108 = heff_field(v_x31_24107, 0);
                            V v_j_24109 = heff_field(v_x31_24107, 1);
                            heff_take_n(v_x31_24107, 3ULL, 2);
                            V v_t_24110 = heff_tag_at_n(v_ru_24x31_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_24101, v_x_24108}), v_j_24109});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24110}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24107)}});
                          }
                        } else {
                          heff_drop(v_x_24101);
                          heff_drop_cell(v_ru_24x31_24100_24MkPair, 2);
                          heff_drop(v_field_24105);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_24100)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x3_2499)}});
                  }
                }
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  HeffT2 v_t_24112 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                  {
                    V v_field_24114 = v_t_24112.f[1];
                    int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
                    if ((v_tag_24113 == ((int64_t)0ULL))) {
                      V v_x31_24116 = v_field_24114;
                      switch (heff_tag_of(v_x31_24116)) {
                      case TAG_MkPair: {
                        V v_x_24117 = heff_field(v_x31_24116, 0);
                        V v_j_24118 = heff_field(v_x31_24116, 1);
                        V v_ru_24x31_24116_24MkPair = heff_take_reuse_n(v_x31_24116, 3ULL, 2);
                        HeffT2 v_t_24119 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_z_241), v_j_24118));
                        {
                          V v_field_24121 = v_t_24119.f[1];
                          int64_t v_tag_24120 = ((int64_t)v_t_24119.f[0]);
                          V v_x3_24126;
                          if ((v_tag_24120 == ((int64_t)0ULL))) {
                            V v_x31_24123 = v_field_24121;
                            switch (heff_tag_of(v_x31_24123)) {
                            case TAG_MkPair: {
                              V v_x_24124 = heff_field(v_x31_24123, 0);
                              V v_j_24125 = heff_field(v_x31_24123, 1);
                              heff_take_n(v_x31_24123, 3ULL, 2);
                              v_x3_24126 = (g_heff_2ebuild_2edecoder_2etimes(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_24124, v_z_241, v_j_24125));
                              break;
                            }
                            default: heff_nomatch(v_x31_24123);
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24121);
                            v_x3_24126 = NTAG(TAG_Nothing);
                          }
                          switch (heff_tag_of(v_x3_24126)) {
                          case TAG_Nothing: {
                            heff_drop(v_x_24117);
                            heff_drop_cell(v_ru_24x31_24116_24MkPair, 2);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_24127 = heff_field(v_x3_24126, 0);
                            heff_take_n(v_x3_24126, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24127)) {
                            case TAG_MkPair: {
                              V v_x_24128 = heff_field(v_x31_24127, 0);
                              V v_j_24129 = heff_field(v_x31_24127, 1);
                              V v_ru_24x31_24127_24MkPair = heff_take_reuse_n(v_x31_24127, 3ULL, 2);
                              V v_t_24130 = heff_tag_at_n(v_ru_24x31_24127_24MkPair, TAG_STag, 2, (V[]){v_x_24117, heff_arrayFromList(v_x_24128)});
                              V v_f_24131 = heff_tag_at_n(v_ru_24x31_24116_24MkPair, TAG_MkPair, 2, (V[]){v_t_24130, v_j_24129});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24131}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24127)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x3_24126)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24116)}});
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop(v_field_24114);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    HeffT2 v_t_24133 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
                    {
                      V v_field_24135 = v_t_24133.f[1];
                      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                      V v_x3_24140;
                      if ((v_tag_24134 == ((int64_t)0ULL))) {
                        V v_x31_24137 = v_field_24135;
                        switch (heff_tag_of(v_x31_24137)) {
                        case TAG_MkPair: {
                          V v_x_24138 = heff_field(v_x31_24137, 0);
                          V v_j_24139 = heff_field(v_x31_24137, 1);
                          heff_take_n(v_x31_24137, 3ULL, 2);
                          v_x3_24140 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24138, heff_dup(v_z_241), v_j_24139));
                          break;
                        }
                        default: heff_nomatch(v_x31_24137);
                        }
                      } else {
                        heff_drop(v_field_24135);
                        v_x3_24140 = NTAG(TAG_Nothing);
                      }
                      switch (heff_tag_of(v_x3_24140)) {
                      case TAG_Nothing: {
                        heff_drop(v_z_241);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_24141 = heff_field(v_x3_24140, 0);
                        heff_take_n(v_x3_24140, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24141)) {
                        case TAG_MkPair: {
                          V v_x_24142 = heff_field(v_x31_24141, 0);
                          V v_j_24143 = heff_field(v_x31_24141, 1);
                          V v_ru_24x31_24141_24MkPair = heff_take_reuse_n(v_x31_24141, 3ULL, 2);
                          HeffT2 v_t_24144 = (g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(v_z_241, v_j_24143));
                          {
                            V v_field_24146 = v_t_24144.f[1];
                            int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
                            if ((v_tag_24145 == ((int64_t)0ULL))) {
                              V v_x31_24148 = v_field_24146;
                              switch (heff_tag_of(v_x31_24148)) {
                              case TAG_MkPair: {
                                V v_x_24149 = heff_field(v_x31_24148, 0);
                                V v_j_24150 = heff_field(v_x31_24148, 1);
                                heff_take_n(v_x31_24148, 3ULL, 2);
                                V v_t_24151 = heff_tag_at_n(v_ru_24x31_24141_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24142, v_x_24149}), v_j_24150});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24151}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24148)}});
                              }
                            } else {
                              heff_drop(v_x_24142);
                              heff_drop_cell(v_ru_24x31_24141_24MkPair, 2);
                              heff_drop(v_field_24146);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24141)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_24140)}});
                      }
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      HeffT2 v_t_24153 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
                      {
                        V v_field_24155 = v_t_24153.f[1];
                        int64_t v_tag_24154 = ((int64_t)v_t_24153.f[0]);
                        V v_x3_24160;
                        if ((v_tag_24154 == ((int64_t)0ULL))) {
                          V v_x31_24157 = v_field_24155;
                          switch (heff_tag_of(v_x31_24157)) {
                          case TAG_MkPair: {
                            V v_x_24158 = heff_field(v_x31_24157, 0);
                            V v_j_24159 = heff_field(v_x31_24157, 1);
                            heff_take_n(v_x31_24157, 3ULL, 2);
                            v_x3_24160 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24158, heff_dup(v_z_241), v_j_24159));
                            break;
                          }
                          default: heff_nomatch(v_x31_24157);
                          }
                        } else {
                          heff_drop(v_field_24155);
                          v_x3_24160 = NTAG(TAG_Nothing);
                        }
                        switch (heff_tag_of(v_x3_24160)) {
                        case TAG_Nothing: {
                          heff_drop(v_z_241);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Just: {
                          V v_x31_24161 = heff_field(v_x3_24160, 0);
                          heff_take_n(v_x3_24160, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24161)) {
                          case TAG_MkPair: {
                            V v_x_24162 = heff_field(v_x31_24161, 0);
                            V v_j_24163 = heff_field(v_x31_24161, 1);
                            V v_ru_24x31_24161_24MkPair = heff_take_reuse_n(v_x31_24161, 3ULL, 2);
                            HeffT2 v_t_24164 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_j_24163));
                            {
                              V v_field_24166 = v_t_24164.f[1];
                              int64_t v_tag_24165 = ((int64_t)v_t_24164.f[0]);
                              if ((v_tag_24165 == ((int64_t)0ULL))) {
                                V v_x31_24168 = v_field_24166;
                                switch (heff_tag_of(v_x31_24168)) {
                                case TAG_MkPair: {
                                  V v_x_24169 = heff_field(v_x31_24168, 0);
                                  V v_j_24170 = heff_field(v_x31_24168, 1);
                                  heff_take_n(v_x31_24168, 3ULL, 2);
                                  HeffT2 v_t_24171 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_j_24170));
                                  {
                                    V v_field_24173 = v_t_24171.f[1];
                                    int64_t v_tag_24172 = ((int64_t)v_t_24171.f[0]);
                                    V v_x3_24178;
                                    if ((v_tag_24172 == ((int64_t)0ULL))) {
                                      V v_x31_24175 = v_field_24173;
                                      switch (heff_tag_of(v_x31_24175)) {
                                      case TAG_MkPair: {
                                        V v_x_24176 = heff_field(v_x31_24175, 0);
                                        V v_j_24177 = heff_field(v_x31_24175, 1);
                                        heff_take_n(v_x31_24175, 3ULL, 2);
                                        v_x3_24178 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24176, v_z_241, v_j_24177));
                                        break;
                                      }
                                      default: heff_nomatch(v_x31_24175);
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop(v_field_24173);
                                      v_x3_24178 = NTAG(TAG_Nothing);
                                    }
                                    switch (heff_tag_of(v_x3_24178)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_x_24162);
                                      heff_drop_cell(v_ru_24x31_24161_24MkPair, 2);
                                      heff_drop(v_x_24169);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                    case TAG_Just: {
                                      V v_x31_24179 = heff_field(v_x3_24178, 0);
                                      heff_take_n(v_x3_24178, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24179)) {
                                      case TAG_MkPair: {
                                        V v_x_24180 = heff_field(v_x31_24179, 0);
                                        V v_j_24181 = heff_field(v_x31_24179, 1);
                                        heff_take_n(v_x31_24179, 3ULL, 2);
                                        V v_t_24182 = heff_tag_at_n(v_ru_24x31_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24162, v_x_24169, v_x_24180}), v_j_24181});
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24182}});
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24179)}});
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x3_24178)}});
                                    }
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24168)}});
                                }
                              } else {
                                heff_drop(v_z_241);
                                heff_drop(v_x_24162);
                                heff_drop_cell(v_ru_24x31_24161_24MkPair, 2);
                                heff_drop(v_field_24166);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24161)}});
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x3_24160)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24184 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
                        {
                          V v_field_24186 = v_t_24184.f[1];
                          int64_t v_tag_24185 = ((int64_t)v_t_24184.f[0]);
                          V v_x3_24191;
                          if ((v_tag_24185 == ((int64_t)0ULL))) {
                            V v_x31_24188 = v_field_24186;
                            switch (heff_tag_of(v_x31_24188)) {
                            case TAG_MkPair: {
                              V v_x_24189 = heff_field(v_x31_24188, 0);
                              V v_j_24190 = heff_field(v_x31_24188, 1);
                              heff_take_n(v_x31_24188, 3ULL, 2);
                              v_x3_24191 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24189, v_z_241, v_j_24190));
                              break;
                            }
                            default: heff_nomatch(v_x31_24188);
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24186);
                            v_x3_24191 = NTAG(TAG_Nothing);
                          }
                          switch (heff_tag_of(v_x3_24191)) {
                          case TAG_Nothing: {
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_24192 = heff_field(v_x3_24191, 0);
                            V v_ru_24x3_24191_24Just = heff_take_reuse_n(v_x3_24191, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24192)) {
                            case TAG_MkPair: {
                              V v_x_24193 = heff_field(v_x31_24192, 0);
                              V v_j_24194 = heff_field(v_x31_24192, 1);
                              V v_ru_24x31_24192_24MkPair = heff_take_reuse_n(v_x31_24192, 3ULL, 2);
                              V v_t_24195 = heff_tag_at_n(v_ru_24x31_24192_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24191_24Just, TAG_SIs, 1, (V[]){v_x_24193}), v_j_24194});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24195}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24192)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x3_24191)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11), 2)) {
                          heff_drop(v_x2_240);
                          heff_drop(v_z_241);
                          V v_t_24197 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_242});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24197}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12), 2)) {
                            heff_drop(v_x2_240);
                            heff_drop(v_z_241);
                            V v_t_24199 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_242});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24199}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13), 2)) {
                              heff_drop(v_x2_240);
                              HeffT2 v_t_24201 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
                              {
                                V v_field_24203 = v_t_24201.f[1];
                                int64_t v_tag_24202 = ((int64_t)v_t_24201.f[0]);
                                V v_x3_24208;
                                if ((v_tag_24202 == ((int64_t)0ULL))) {
                                  V v_x31_24205 = v_field_24203;
                                  switch (heff_tag_of(v_x31_24205)) {
                                  case TAG_MkPair: {
                                    V v_x_24206 = heff_field(v_x31_24205, 0);
                                    V v_j_24207 = heff_field(v_x31_24205, 1);
                                    heff_take_n(v_x31_24205, 3ULL, 2);
                                    v_x3_24208 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24206, v_z_241, v_j_24207));
                                    break;
                                  }
                                  default: heff_nomatch(v_x31_24205);
                                  }
                                } else {
                                  heff_drop(v_z_241);
                                  heff_drop(v_field_24203);
                                  v_x3_24208 = NTAG(TAG_Nothing);
                                }
                                switch (heff_tag_of(v_x3_24208)) {
                                case TAG_Nothing: {
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24209 = heff_field(v_x3_24208, 0);
                                  V v_ru_24x3_24208_24Just = heff_take_reuse_n(v_x3_24208, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24209)) {
                                  case TAG_MkPair: {
                                    V v_x_24210 = heff_field(v_x31_24209, 0);
                                    V v_j_24211 = heff_field(v_x31_24209, 1);
                                    V v_ru_24x31_24209_24MkPair = heff_take_reuse_n(v_x31_24209, 3ULL, 2);
                                    V v_t_24212 = heff_tag_at_n(v_ru_24x31_24209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24208_24Just, TAG_SRec, 1, (V[]){v_x_24210}), v_j_24211});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24212}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24209)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24208)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14), 2)) {
                                heff_drop(v_x2_240);
                                HeffT2 v_t_24214 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
                                {
                                  V v_field_24216 = v_t_24214.f[1];
                                  int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
                                  V v_x3_24221;
                                  if ((v_tag_24215 == ((int64_t)0ULL))) {
                                    V v_x31_24218 = v_field_24216;
                                    switch (heff_tag_of(v_x31_24218)) {
                                    case TAG_MkPair: {
                                      V v_x_24219 = heff_field(v_x31_24218, 0);
                                      V v_j_24220 = heff_field(v_x31_24218, 1);
                                      heff_take_n(v_x31_24218, 3ULL, 2);
                                      v_x3_24221 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_24219, heff_dup(v_z_241), v_j_24220));
                                      break;
                                    }
                                    default: heff_nomatch(v_x31_24218);
                                    }
                                  } else {
                                    heff_drop(v_field_24216);
                                    v_x3_24221 = NTAG(TAG_Nothing);
                                  }
                                  switch (heff_tag_of(v_x3_24221)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_z_241);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                  case TAG_Just: {
                                    V v_x31_24222 = heff_field(v_x3_24221, 0);
                                    heff_take_n(v_x3_24221, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24222)) {
                                    case TAG_MkPair: {
                                      V v_x_24223 = heff_field(v_x31_24222, 0);
                                      V v_j_24224 = heff_field(v_x31_24222, 1);
                                      V v_ru_24x31_24222_24MkPair = heff_take_reuse_n(v_x31_24222, 3ULL, 2);
                                      HeffT2 v_t_24225 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_j_24224));
                                      {
                                        V v_field_24227 = v_t_24225.f[1];
                                        int64_t v_tag_24226 = ((int64_t)v_t_24225.f[0]);
                                        V v_x3_24232;
                                        if ((v_tag_24226 == ((int64_t)0ULL))) {
                                          V v_x31_24229 = v_field_24227;
                                          switch (heff_tag_of(v_x31_24229)) {
                                          case TAG_MkPair: {
                                            V v_x_24230 = heff_field(v_x31_24229, 0);
                                            V v_j_24231 = heff_field(v_x31_24229, 1);
                                            heff_take_n(v_x31_24229, 3ULL, 2);
                                            v_x3_24232 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_24230, v_z_241, v_j_24231));
                                            break;
                                          }
                                          default: heff_nomatch(v_x31_24229);
                                          }
                                        } else {
                                          heff_drop(v_z_241);
                                          heff_drop(v_field_24227);
                                          v_x3_24232 = NTAG(TAG_Nothing);
                                        }
                                        switch (heff_tag_of(v_x3_24232)) {
                                        case TAG_Nothing: {
                                          heff_drop(v_x_24223);
                                          heff_drop_cell(v_ru_24x31_24222_24MkPair, 2);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                        case TAG_Just: {
                                          V v_x31_24233 = heff_field(v_x3_24232, 0);
                                          heff_take_n(v_x3_24232, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24233)) {
                                          case TAG_MkPair: {
                                            V v_x_24234 = heff_field(v_x31_24233, 0);
                                            V v_j_24235 = heff_field(v_x31_24233, 1);
                                            heff_take_n(v_x31_24233, 3ULL, 2);
                                            V v_t_24236 = heff_tag_at_n(v_ru_24x31_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24223, v_x_24234}), v_j_24235});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24236}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24233)}});
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x3_24232)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24222)}});
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x3_24221)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15), 2)) {
                                  heff_drop(v_x2_240);
                                  HeffT2 v_t_24238 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                  {
                                    V v_field_24240 = v_t_24238.f[1];
                                    int64_t v_tag_24239 = ((int64_t)v_t_24238.f[0]);
                                    if ((v_tag_24239 == ((int64_t)0ULL))) {
                                      V v_x31_24242 = v_field_24240;
                                      switch (heff_tag_of(v_x31_24242)) {
                                      case TAG_MkPair: {
                                        V v_x_24243 = heff_field(v_x31_24242, 0);
                                        V v_j_24244 = heff_field(v_x31_24242, 1);
                                        V v_ru_24x31_24242_24MkPair = heff_take_reuse_n(v_x31_24242, 3ULL, 2);
                                        HeffT2 v_t_24245 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_j_24244));
                                        {
                                          V v_field_24247 = v_t_24245.f[1];
                                          int64_t v_tag_24246 = ((int64_t)v_t_24245.f[0]);
                                          V v_x3_24252;
                                          if ((v_tag_24246 == ((int64_t)0ULL))) {
                                            V v_x31_24249 = v_field_24247;
                                            switch (heff_tag_of(v_x31_24249)) {
                                            case TAG_MkPair: {
                                              V v_x_24250 = heff_field(v_x31_24249, 0);
                                              V v_j_24251 = heff_field(v_x31_24249, 1);
                                              heff_take_n(v_x31_24249, 3ULL, 2);
                                              v_x3_24252 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24250, v_z_241, v_j_24251));
                                              break;
                                            }
                                            default: heff_nomatch(v_x31_24249);
                                            }
                                          } else {
                                            heff_drop(v_z_241);
                                            heff_drop(v_field_24247);
                                            v_x3_24252 = NTAG(TAG_Nothing);
                                          }
                                          switch (heff_tag_of(v_x3_24252)) {
                                          case TAG_Nothing: {
                                            heff_drop(v_x_24243);
                                            heff_drop_cell(v_ru_24x31_24242_24MkPair, 2);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                          case TAG_Just: {
                                            V v_x31_24253 = heff_field(v_x3_24252, 0);
                                            heff_take_n(v_x3_24252, 1ULL, 1);
                                            switch (heff_tag_of(v_x31_24253)) {
                                            case TAG_MkPair: {
                                              V v_x_24254 = heff_field(v_x31_24253, 0);
                                              V v_j_24255 = heff_field(v_x31_24253, 1);
                                              heff_take_n(v_x31_24253, 3ULL, 2);
                                              V v_t_24256 = heff_tag_at_n(v_ru_24x31_24242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24243, v_x_24254}), v_j_24255});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24256}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24253)}});
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x3_24252)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24242)}});
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop(v_field_24240);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16), 2)) {
                                    heff_drop(v_x2_240);
                                    HeffT2 v_t_24258 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                    {
                                      V v_field_24260 = v_t_24258.f[1];
                                      int64_t v_tag_24259 = ((int64_t)v_t_24258.f[0]);
                                      if ((v_tag_24259 == ((int64_t)0ULL))) {
                                        V v_x31_24262 = v_field_24260;
                                        switch (heff_tag_of(v_x31_24262)) {
                                        case TAG_MkPair: {
                                          V v_x_24263 = heff_field(v_x31_24262, 0);
                                          V v_j_24264 = heff_field(v_x31_24262, 1);
                                          V v_ru_24x31_24262_24MkPair = heff_take_reuse_n(v_x31_24262, 3ULL, 2);
                                          V v_t_24265 = heff_tag_at_n(v_ru_24x31_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24263}), v_j_24264});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24265}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24262)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24260);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17), 2)) {
                                      heff_drop(v_x2_240);
                                      HeffT2 v_t_24267 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                      {
                                        V v_field_24269 = v_t_24267.f[1];
                                        int64_t v_tag_24268 = ((int64_t)v_t_24267.f[0]);
                                        if ((v_tag_24268 == ((int64_t)0ULL))) {
                                          V v_x31_24271 = v_field_24269;
                                          switch (heff_tag_of(v_x31_24271)) {
                                          case TAG_MkPair: {
                                            V v_x_24272 = heff_field(v_x31_24271, 0);
                                            V v_j_24273 = heff_field(v_x31_24271, 1);
                                            V v_ru_24x31_24271_24MkPair = heff_take_reuse_n(v_x31_24271, 3ULL, 2);
                                            V v_t_24274 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24272));
                                            V v_x_24275 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24274});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24271_24MkPair, TAG_MkPair, 2, (V[]){v_x_24275, v_j_24273})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24271)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24269);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18), 2)) {
                                        heff_drop(v_x2_240);
                                        HeffT2 v_t_24277 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                        {
                                          V v_field_24279 = v_t_24277.f[1];
                                          int64_t v_tag_24278 = ((int64_t)v_t_24277.f[0]);
                                          if ((v_tag_24278 == ((int64_t)0ULL))) {
                                            V v_x31_24281 = v_field_24279;
                                            switch (heff_tag_of(v_x31_24281)) {
                                            case TAG_MkPair: {
                                              V v_x_24282 = heff_field(v_x31_24281, 0);
                                              V v_j_24283 = heff_field(v_x31_24281, 1);
                                              V v_ru_24x31_24281_24MkPair = heff_take_reuse_n(v_x31_24281, 3ULL, 2);
                                              V v_x2_24284 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19), heff_dup(v_x_24282), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20), v_x_24282, MK_INT(0LL)), NTAG(TAG_Nil)));
                                              V v_t_24287;
                                              switch (heff_tag_of(v_x2_24284)) {
                                              case TAG_Nil: {
                                                v_t_24287 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21);
                                                break;
                                              }
                                              case TAG_Cons: {
                                                V v_x_24285 = heff_field(v_x2_24284, 0);
                                                V v_xs_24286 = heff_field(v_x2_24284, 1);
                                                heff_take_n(v_x2_24284, 3ULL, 2);
                                                v_t_24287 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22); V a_1 = v_x_24285; V a_2 = v_xs_24286; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24286); r_; });
                                                break;
                                              }
                                              default: heff_nomatch(v_x2_24284);
                                              }
                                              double v_t_24288 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24287));
                                              V v_x_24289 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24288)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24281_24MkPair, TAG_MkPair, 2, (V[]){v_x_24289, v_j_24283})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24281)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24279);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23), 2)) {
                                          heff_drop(v_x2_240);
                                          HeffT2 v_t_24291 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                          {
                                            V v_field_24293 = v_t_24291.f[1];
                                            int64_t v_tag_24292 = ((int64_t)v_t_24291.f[0]);
                                            if ((v_tag_24292 == ((int64_t)0ULL))) {
                                              V v_x31_24295 = v_field_24293;
                                              switch (heff_tag_of(v_x31_24295)) {
                                              case TAG_MkPair: {
                                                V v_x_24296 = heff_field(v_x31_24295, 0);
                                                V v_j_24297 = heff_field(v_x31_24295, 1);
                                                V v_ru_24x31_24295_24MkPair = heff_take_reuse_n(v_x31_24295, 3ULL, 2);
                                                V v_t_24298 = heff_tag_at_n(v_ru_24x31_24295_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24296}), v_j_24297});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24298}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24295)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24293);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str24), 2)) {
                                            heff_drop(v_x2_240);
                                            HeffT2 v_t_24300 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                            {
                                              V v_field_24302 = v_t_24300.f[1];
                                              int64_t v_tag_24301 = ((int64_t)v_t_24300.f[0]);
                                              if ((v_tag_24301 == ((int64_t)0ULL))) {
                                                V v_x31_24304 = v_field_24302;
                                                switch (heff_tag_of(v_x31_24304)) {
                                                case TAG_MkPair: {
                                                  V v_x_24305 = heff_field(v_x31_24304, 0);
                                                  V v_j_24306 = heff_field(v_x31_24304, 1);
                                                  V v_ru_24x31_24304_24MkPair = heff_take_reuse_n(v_x31_24304, 3ULL, 2);
                                                  V v_t_24307 = heff_tag_at_n(v_ru_24x31_24304_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24305}), v_j_24306});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24307}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24304)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24302);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str25), 2)) {
                                              heff_drop(v_x2_240);
                                              HeffT2 v_t_24309 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                              {
                                                V v_field_24311 = v_t_24309.f[1];
                                                int64_t v_tag_24310 = ((int64_t)v_t_24309.f[0]);
                                                if ((v_tag_24310 == ((int64_t)0ULL))) {
                                                  V v_x31_24313 = v_field_24311;
                                                  switch (heff_tag_of(v_x31_24313)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24314 = heff_field(v_x31_24313, 0);
                                                    V v_j_24315 = heff_field(v_x31_24313, 1);
                                                    V v_ru_24x31_24313_24MkPair = heff_take_reuse_n(v_x31_24313, 3ULL, 2);
                                                    V v_t_24316 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24314));
                                                    V v_x_24317 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24316});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24313_24MkPair, TAG_MkPair, 2, (V[]){v_x_24317, v_j_24315})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24313)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24311);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str26), 2)) {
                                                heff_drop(v_x2_240);
                                                HeffT2 v_t_24319 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(heff_dup(v_z_241), v_z_242));
                                                {
                                                  V v_field_24321 = v_t_24319.f[1];
                                                  int64_t v_tag_24320 = ((int64_t)v_t_24319.f[0]);
                                                  if ((v_tag_24320 == ((int64_t)0ULL))) {
                                                    V v_x31_24323 = v_field_24321;
                                                    switch (heff_tag_of(v_x31_24323)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24324 = heff_field(v_x31_24323, 0);
                                                      V v_j_24325 = heff_field(v_x31_24323, 1);
                                                      V v_ru_24x31_24323_24MkPair = heff_take_reuse_n(v_x31_24323, 3ULL, 2);
                                                      HeffT2 v_t_24326 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_j_24325));
                                                      {
                                                        V v_field_24328 = v_t_24326.f[1];
                                                        int64_t v_tag_24327 = ((int64_t)v_t_24326.f[0]);
                                                        if ((v_tag_24327 == ((int64_t)0ULL))) {
                                                          V v_x31_24330 = v_field_24328;
                                                          switch (heff_tag_of(v_x31_24330)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24331 = heff_field(v_x31_24330, 0);
                                                            V v_j_24332 = heff_field(v_x31_24330, 1);
                                                            V v_ru_24x31_24330_24MkPair = heff_take_reuse_n(v_x31_24330, 3ULL, 2);
                                                            V v_t_24333 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24331));
                                                            V v_x_24334 = heff_tag_at_n(v_ru_24x31_24330_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24324, v_t_24333});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24323_24MkPair, TAG_MkPair, 2, (V[]){v_x_24334, v_j_24332})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24330)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24324);
                                                          heff_drop_cell(v_ru_24x31_24323_24MkPair, 2);
                                                          heff_drop(v_field_24328);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24323)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_241);
                                                    heff_drop(v_field_24321);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str27))) {
                                                  HeffT2 v_t_24336 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                                  {
                                                    V v_field_24338 = v_t_24336.f[1];
                                                    int64_t v_tag_24337 = ((int64_t)v_t_24336.f[0]);
                                                    if ((v_tag_24337 == ((int64_t)0ULL))) {
                                                      V v_x31_24340 = v_field_24338;
                                                      switch (heff_tag_of(v_x31_24340)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24341 = heff_field(v_x31_24340, 0);
                                                        V v_j_24342 = heff_field(v_x31_24340, 1);
                                                        V v_ru_24x31_24340_24MkPair = heff_take_reuse_n(v_x31_24340, 3ULL, 2);
                                                        V v_x2_24343 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str28), heff_dup(v_x_24341), MK_INT(0LL), heff_strFind(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str29), v_x_24341, MK_INT(0LL)), NTAG(TAG_Nil)));
                                                        V v_t_24346;
                                                        switch (heff_tag_of(v_x2_24343)) {
                                                        case TAG_Nil: {
                                                          v_t_24346 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str30);
                                                          break;
                                                        }
                                                        case TAG_Cons: {
                                                          V v_x_24344 = heff_field(v_x2_24343, 0);
                                                          V v_xs_24345 = heff_field(v_x2_24343, 1);
                                                          heff_take_n(v_x2_24343, 3ULL, 2);
                                                          v_t_24346 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str31); V a_1 = v_x_24344; V a_2 = v_xs_24345; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24345); r_; });
                                                          break;
                                                        }
                                                        default: heff_nomatch(v_x2_24343);
                                                        }
                                                        double v_t_24347 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24346));
                                                        V v_x_24348 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24347)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24340_24MkPair, TAG_MkPair, 2, (V[]){v_x_24348, v_j_24342})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24340)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24338);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x2_240, v_z_241, v_z_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_x3_249;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        v_x3_249 = (g_heff_2ebuild_2edecoder_2etimes(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_247, v_s_240, v_j_248));
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      v_x3_249 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2410 = heff_field(v_x3_249, 0);
      heff_take_n(v_x3_249, 1ULL, 1);
      switch (heff_tag_of(v_x31_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x31_2410, 0);
        V v_j_2412 = heff_field(v_x31_2410, 1);
        V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
        V v_f_2413 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2411), v_j_2412});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_249)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_x3_249;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        v_x3_249 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004(v_x_247, v_s_240, v_j_248));
        break;
      }
      default: heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      v_x3_249 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x31_2410 = heff_field(v_x3_249, 0);
      heff_take_n(v_x3_249, 1ULL, 1);
      switch (heff_tag_of(v_x31_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x31_2410, 0);
        V v_j_2412 = heff_field(v_x31_2410, 1);
        V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
        V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2411)));
        V v_t_2414 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2411));
        V v_t_2415 = (g_list_2emap_24s1173914895x100384474(v_x_2411));
        V v_x_2416 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2413), v_t_2414, heff_arrayFromList(v_t_2415)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2416, v_j_2412})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_249)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    return (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(v_z_241, v_z_242));
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        V v_x3_2412;
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x31_249 = v_field_247;
          switch (heff_tag_of(v_x31_249)) {
          case TAG_MkPair: {
            V v_x_2410 = heff_field(v_x31_249, 0);
            V v_j_2411 = heff_field(v_x31_249, 1);
            heff_take_n(v_x31_249, 3ULL, 2);
            v_x3_2412 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2410, v_z_241, v_j_2411));
            break;
          }
          default: heff_nomatch(v_x31_249);
          }
        } else {
          heff_drop(v_z_241);
          heff_drop(v_field_247);
          v_x3_2412 = NTAG(TAG_Nothing);
        }
        switch (heff_tag_of(v_x3_2412)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_x31_2413 = heff_field(v_x3_2412, 0);
          V v_ru_24x3_2412_24Just = heff_take_reuse_n(v_x3_2412, 1ULL, 1);
          switch (heff_tag_of(v_x31_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x31_2413, 0);
            V v_j_2415 = heff_field(v_x31_2413, 1);
            V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
            V v_t_2416 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2412_24Just, TAG_SDecode, 1, (V[]){v_x_2414}), v_j_2415});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2412)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(heff_dup(v_z_241), v_z_242));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_x31_2422 = v_field_2420;
            switch (heff_tag_of(v_x31_2422)) {
            case TAG_MkPair: {
              V v_x_2423 = heff_field(v_x31_2422, 0);
              V v_j_2424 = heff_field(v_x31_2422, 1);
              V v_ru_24x31_2422_24MkPair = heff_take_reuse_n(v_x31_2422, 3ULL, 2);
              HeffT2 v_t_2425 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_j_2424));
              {
                V v_field_2427 = v_t_2425.f[1];
                int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
                V v_x3_2432;
                if ((v_tag_2426 == ((int64_t)0ULL))) {
                  V v_x31_2429 = v_field_2427;
                  switch (heff_tag_of(v_x31_2429)) {
                  case TAG_MkPair: {
                    V v_x_2430 = heff_field(v_x31_2429, 0);
                    V v_j_2431 = heff_field(v_x31_2429, 1);
                    heff_take_n(v_x31_2429, 3ULL, 2);
                    v_x3_2432 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2430, heff_dup(v_z_241), v_j_2431));
                    break;
                  }
                  default: heff_nomatch(v_x31_2429);
                  }
                } else {
                  heff_drop(v_field_2427);
                  v_x3_2432 = NTAG(TAG_Nothing);
                }
                switch (heff_tag_of(v_x3_2432)) {
                case TAG_Nothing: {
                  heff_drop(v_z_241);
                  heff_drop(v_x_2423);
                  heff_drop_cell(v_ru_24x31_2422_24MkPair, 2);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_2433 = heff_field(v_x3_2432, 0);
                  heff_take_n(v_x3_2432, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2433)) {
                  case TAG_MkPair: {
                    V v_x_2434 = heff_field(v_x31_2433, 0);
                    V v_j_2435 = heff_field(v_x31_2433, 1);
                    heff_take_n(v_x31_2433, 3ULL, 2);
                    HeffT2 v_t_2436 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_j_2435));
                    {
                      V v_field_2438 = v_t_2436.f[1];
                      int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
                      V v_x3_2443;
                      if ((v_tag_2437 == ((int64_t)0ULL))) {
                        V v_x31_2440 = v_field_2438;
                        switch (heff_tag_of(v_x31_2440)) {
                        case TAG_MkPair: {
                          V v_x_2441 = heff_field(v_x31_2440, 0);
                          V v_j_2442 = heff_field(v_x31_2440, 1);
                          heff_take_n(v_x31_2440, 3ULL, 2);
                          v_x3_2443 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_2441, heff_dup(v_z_241), v_j_2442));
                          break;
                        }
                        default: heff_nomatch(v_x31_2440);
                        }
                      } else {
                        heff_drop(v_field_2438);
                        v_x3_2443 = NTAG(TAG_Nothing);
                      }
                      switch (heff_tag_of(v_x3_2443)) {
                      case TAG_Nothing: {
                        heff_drop(v_z_241);
                        heff_drop(v_x_2423);
                        heff_drop_cell(v_ru_24x31_2422_24MkPair, 2);
                        heff_drop(v_x_2434);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Just: {
                        V v_x31_2444 = heff_field(v_x3_2443, 0);
                        heff_take_n(v_x3_2443, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2444)) {
                        case TAG_MkPair: {
                          V v_x_2445 = heff_field(v_x31_2444, 0);
                          V v_j_2446 = heff_field(v_x31_2444, 1);
                          heff_take_n(v_x31_2444, 3ULL, 2);
                          HeffT2 v_t_2447 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(heff_dup(v_z_241), v_j_2446));
                          {
                            V v_field_2449 = v_t_2447.f[1];
                            int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                            if ((v_tag_2448 == ((int64_t)0ULL))) {
                              V v_x31_2451 = v_field_2449;
                              switch (heff_tag_of(v_x31_2451)) {
                              case TAG_MkPair: {
                                V v_x_2452 = heff_field(v_x31_2451, 0);
                                V v_j_2453 = heff_field(v_x31_2451, 1);
                                heff_take_n(v_x31_2451, 3ULL, 2);
                                HeffT2 v_t_2454 = (g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(v_z_241, v_j_2453));
                                {
                                  V v_field_2456 = v_t_2454.f[1];
                                  int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                                  if ((v_tag_2455 == ((int64_t)0ULL))) {
                                    V v_x31_2458 = v_field_2456;
                                    switch (heff_tag_of(v_x31_2458)) {
                                    case TAG_MkPair: {
                                      V v_x_2459 = heff_field(v_x31_2458, 0);
                                      V v_j_2460 = heff_field(v_x31_2458, 1);
                                      heff_take_n(v_x31_2458, 3ULL, 2);
                                      V v_t_2461 = heff_tag_at_n(v_ru_24x31_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2423, v_x_2434, v_x_2445, v_x_2452, v_x_2459}), v_j_2460});
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2461}});
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_2458)}});
                                    }
                                  } else {
                                    heff_drop(v_x_2423);
                                    heff_drop_cell(v_ru_24x31_2422_24MkPair, 2);
                                    heff_drop(v_x_2434);
                                    heff_drop(v_x_2445);
                                    heff_drop(v_x_2452);
                                    heff_drop(v_field_2456);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2451)}});
                              }
                            } else {
                              heff_drop(v_z_241);
                              heff_drop(v_x_2423);
                              heff_drop_cell(v_ru_24x31_2422_24MkPair, 2);
                              heff_drop(v_x_2434);
                              heff_drop(v_x_2445);
                              heff_drop(v_field_2449);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2444)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x3_2443)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2433)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_2432)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2422)}});
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2420);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2463 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(heff_dup(v_z_241), v_z_242));
          {
            V v_field_2465 = v_t_2463.f[1];
            int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
            if ((v_tag_2464 == ((int64_t)0ULL))) {
              V v_x31_2467 = v_field_2465;
              switch (heff_tag_of(v_x31_2467)) {
              case TAG_MkPair: {
                V v_x_2468 = heff_field(v_x31_2467, 0);
                V v_j_2469 = heff_field(v_x31_2467, 1);
                V v_ru_24x31_2467_24MkPair = heff_take_reuse_n(v_x31_2467, 3ULL, 2);
                HeffT2 v_t_2470 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), heff_dup(v_z_241), v_j_2469));
                {
                  V v_field_2472 = v_t_2470.f[1];
                  int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
                  if ((v_tag_2471 == ((int64_t)0ULL))) {
                    V v_x31_2474 = v_field_2472;
                    switch (heff_tag_of(v_x31_2474)) {
                    case TAG_MkPair: {
                      V v_x_2475 = heff_field(v_x31_2474, 0);
                      V v_j_2476 = heff_field(v_x31_2474, 1);
                      heff_take_n(v_x31_2474, 3ULL, 2);
                      HeffT2 v_t_2477 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_j_2476));
                      {
                        V v_field_2479 = v_t_2477.f[1];
                        int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
                        if ((v_tag_2478 == ((int64_t)0ULL))) {
                          V v_x31_2481 = v_field_2479;
                          switch (heff_tag_of(v_x31_2481)) {
                          case TAG_MkPair: {
                            V v_x_2482 = heff_field(v_x31_2481, 0);
                            V v_j_2483 = heff_field(v_x31_2481, 1);
                            heff_take_n(v_x31_2481, 3ULL, 2);
                            V v_t_2484 = heff_tag_at_n(v_ru_24x31_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2468, v_x_2475, v_x_2482}), v_j_2483});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2484}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2481)}});
                          }
                        } else {
                          heff_drop(v_x_2468);
                          heff_drop_cell(v_ru_24x31_2467_24MkPair, 2);
                          heff_drop(v_x_2475);
                          heff_drop(v_field_2479);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2474)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_x_2468);
                    heff_drop_cell(v_ru_24x31_2467_24MkPair, 2);
                    heff_drop(v_field_2472);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2467)}});
              }
            } else {
              heff_drop(v_z_241);
              heff_drop(v_field_2465);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT2 v_t_2486 = (g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_24cpr(v_z_241, v_z_242));
            {
              V v_field_2488 = v_t_2486.f[1];
              int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
              if ((v_tag_2487 == ((int64_t)0ULL))) {
                V v_x31_2490 = v_field_2488;
                switch (heff_tag_of(v_x31_2490)) {
                case TAG_MkPair: {
                  V v_x_2491 = heff_field(v_x31_2490, 0);
                  V v_j_2492 = heff_field(v_x31_2490, 1);
                  V v_ru_24x31_2490_24MkPair = heff_take_reuse_n(v_x31_2490, 3ULL, 2);
                  V v_t_2493 = heff_tag_at_n(v_ru_24x31_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2491}), v_j_2492});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2493}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2490)}});
                }
              } else {
                heff_drop(v_field_2488);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_2495 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
              {
                V v_field_2497 = v_t_2495.f[1];
                int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
                V v_x3_24102;
                if ((v_tag_2496 == ((int64_t)0ULL))) {
                  V v_x31_2499 = v_field_2497;
                  switch (heff_tag_of(v_x31_2499)) {
                  case TAG_MkPair: {
                    V v_x_24100 = heff_field(v_x31_2499, 0);
                    V v_j_24101 = heff_field(v_x31_2499, 1);
                    heff_take_n(v_x31_2499, 3ULL, 2);
                    v_x3_24102 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_24100, v_z_241, v_j_24101));
                    break;
                  }
                  default: heff_nomatch(v_x31_2499);
                  }
                } else {
                  heff_drop(v_z_241);
                  heff_drop(v_field_2497);
                  v_x3_24102 = NTAG(TAG_Nothing);
                }
                switch (heff_tag_of(v_x3_24102)) {
                case TAG_Nothing: {
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_x31_24103 = heff_field(v_x3_24102, 0);
                  V v_ru_24x3_24102_24Just = heff_take_reuse_n(v_x3_24102, 1ULL, 1);
                  switch (heff_tag_of(v_x31_24103)) {
                  case TAG_MkPair: {
                    V v_x_24104 = heff_field(v_x31_24103, 0);
                    V v_j_24105 = heff_field(v_x31_24103, 1);
                    V v_ru_24x31_24103_24MkPair = heff_take_reuse_n(v_x31_24103, 3ULL, 2);
                    V v_t_24106 = heff_tag_at_n(v_ru_24x31_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24102_24Just, TAG_SIsTy, 1, (V[]){v_x_24104}), v_j_24105});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24106}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_24103)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x3_24102)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                heff_drop(v_z_241);
                V v_t_24108 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_242});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24108}});
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  heff_drop(v_z_241);
                  V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_242});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24110}});
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    heff_drop(v_z_241);
                    V v_t_24112 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_242});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24112}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      heff_drop(v_z_241);
                      V v_t_24114 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_242});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24114}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24116 = (g_heff_2ebuild_2edecoder_2eword_24cpr(heff_dup(v_z_241), v_z_242));
                        {
                          V v_field_24118 = v_t_24116.f[1];
                          int64_t v_tag_24117 = ((int64_t)v_t_24116.f[0]);
                          V v_x3_24123;
                          if ((v_tag_24117 == ((int64_t)0ULL))) {
                            V v_x31_24120 = v_field_24118;
                            switch (heff_tag_of(v_x31_24120)) {
                            case TAG_MkPair: {
                              V v_x_24121 = heff_field(v_x31_24120, 0);
                              V v_j_24122 = heff_field(v_x31_24120, 1);
                              heff_take_n(v_x31_24120, 3ULL, 2);
                              v_x3_24123 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_24121, v_z_241, v_j_24122));
                              break;
                            }
                            default: heff_nomatch(v_x31_24120);
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24118);
                            v_x3_24123 = NTAG(TAG_Nothing);
                          }
                          switch (heff_tag_of(v_x3_24123)) {
                          case TAG_Nothing: {
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                          case TAG_Just: {
                            V v_x31_24124 = heff_field(v_x3_24123, 0);
                            V v_ru_24x3_24123_24Just = heff_take_reuse_n(v_x3_24123, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24124)) {
                            case TAG_MkPair: {
                              V v_x_24125 = heff_field(v_x31_24124, 0);
                              V v_j_24126 = heff_field(v_x31_24124, 1);
                              V v_ru_24x31_24124_24MkPair = heff_take_reuse_n(v_x31_24124, 3ULL, 2);
                              V v_t_24127 = heff_tag_at_n(v_ru_24x31_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24123_24Just, TAG_SPrimArray, 1, (V[]){v_x_24125}), v_j_24126});
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24127}});
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24124)}});
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x3_24123)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11))) {
                          HeffT2 v_t_24129 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_241, v_z_242));
                          {
                            V v_field_24131 = v_t_24129.f[1];
                            int64_t v_tag_24130 = ((int64_t)v_t_24129.f[0]);
                            if ((v_tag_24130 == ((int64_t)0ULL))) {
                              V v_x31_24133 = v_field_24131;
                              switch (heff_tag_of(v_x31_24133)) {
                              case TAG_MkPair: {
                                V v_x_24134 = heff_field(v_x31_24133, 0);
                                V v_j_24135 = heff_field(v_x31_24133, 1);
                                V v_ru_24x31_24133_24MkPair = heff_take_reuse_n(v_x31_24133, 3ULL, 2);
                                V v_t_24136 = heff_tag_at_n(v_ru_24x31_24133_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_24134}), v_j_24135});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24136}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24133)}});
                              }
                            } else {
                              heff_drop(v_field_24131);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x2_240, v_z_241, v_z_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(a[0], a[1], a[2]);
}