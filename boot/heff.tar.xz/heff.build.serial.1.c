// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define LBL_el 9998
#define LBL_ty 10476
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V, V, V);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      V v_t_2410 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_247, v_a_245));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_rest_245;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2411 = heff_intShow(heff_strLength_lent(v_a_249, 0));
      V v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(v_lit_240, v_a_249));
      V v_t_2419;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_a_2410, 0);
        V v_a_2414 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2415 = heff_arrayToList(v_a_2413);
        V v_a_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2414, v_a_248));
        V v_a_2417 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2415));
        V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(v_lit_243, v_a_2415, v_a_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2417), v_t_2418});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2412, v_t_2419});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ebuild_2eserial_2etermOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etermOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eserial_2etermOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2etermOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str24, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str25, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str26, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str27, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str28, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str29, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str31, 0, "");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    HeffT2 v_t_244 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_248 = v_field_246;
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          V v_ru_24x31_248_24MkPair = heff_take_reuse_n(v_x31_248, 3ULL, 2);
          V v_t_2411 = heff_tag_at_n(v_ru_24x31_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_249}), v_j_2410});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2411}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_248)}});
        }
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_2413 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_x31_2417 = v_field_2415;
          switch (heff_tag_of(v_x31_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x31_2417, 0);
            V v_j_2419 = heff_field(v_x31_2417, 1);
            V v_ru_24x31_2417_24MkPair = heff_take_reuse_n(v_x31_2417, 3ULL, 2);
            V v_t_2420 = heff_tag_at_n(v_ru_24x31_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2418}), v_j_2419});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2420}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
          }
        } else {
          heff_drop(v_field_2415);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2422 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_x31_2426 = v_field_2424;
            switch (heff_tag_of(v_x31_2426)) {
            case TAG_MkPair: {
              V v_x_2427 = heff_field(v_x31_2426, 0);
              V v_j_2428 = heff_field(v_x31_2426, 1);
              V v_ru_24x31_2426_24MkPair = heff_take_reuse_n(v_x31_2426, 3ULL, 2);
              HeffT2 v_t_2429 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2427, v_z_241, v_j_2428));
              {
                V v_field_2431 = v_t_2429.f[1];
                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                if ((v_tag_2430 == ((int64_t)0ULL))) {
                  V v_x31_2433 = v_field_2431;
                  switch (heff_tag_of(v_x31_2433)) {
                  case TAG_MkPair: {
                    V v_x_2434 = heff_field(v_x31_2433, 0);
                    V v_j_2435 = heff_field(v_x31_2433, 1);
                    heff_take_n(v_x31_2433, 3ULL, 2);
                    V v_t_2436 = heff_tag_at_n(v_ru_24x31_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_x_2434}), v_j_2435});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2436}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2433)}});
                  }
                } else {
                  heff_drop_cell(v_ru_24x31_2426_24MkPair, 2);
                  heff_drop(v_field_2431);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2426)}});
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2424);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2438 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
          {
            V v_field_2440 = v_t_2438.f[1];
            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
            if ((v_tag_2439 == ((int64_t)0ULL))) {
              V v_x31_2442 = v_field_2440;
              switch (heff_tag_of(v_x31_2442)) {
              case TAG_MkPair: {
                V v_x_2443 = heff_field(v_x31_2442, 0);
                V v_j_2444 = heff_field(v_x31_2442, 1);
                V v_ru_24x31_2442_24MkPair = heff_take_reuse_n(v_x31_2442, 3ULL, 2);
                HeffT2 v_t_2445 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2443, heff_dup(v_z_241), v_j_2444));
                {
                  V v_field_2447 = v_t_2445.f[1];
                  int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
                  if ((v_tag_2446 == ((int64_t)0ULL))) {
                    V v_x31_2449 = v_field_2447;
                    switch (heff_tag_of(v_x31_2449)) {
                    case TAG_MkPair: {
                      V v_x_2450 = heff_field(v_x31_2449, 0);
                      V v_j_2451 = heff_field(v_x31_2449, 1);
                      heff_take_n(v_x31_2449, 3ULL, 2);
                      HeffT2 v_t_2452 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2451));
                      {
                        V v_field_2454 = v_t_2452.f[1];
                        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
                        if ((v_tag_2453 == ((int64_t)0ULL))) {
                          V v_x31_2456 = v_field_2454;
                          switch (heff_tag_of(v_x31_2456)) {
                          case TAG_MkPair: {
                            V v_x_2457 = heff_field(v_x31_2456, 0);
                            V v_j_2458 = heff_field(v_x31_2456, 1);
                            heff_take_n(v_x31_2456, 3ULL, 2);
                            HeffT2 v_t_2459 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2457, v_z_241, v_j_2458));
                            {
                              V v_field_2461 = v_t_2459.f[1];
                              int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                              if ((v_tag_2460 == ((int64_t)0ULL))) {
                                V v_x31_2463 = v_field_2461;
                                switch (heff_tag_of(v_x31_2463)) {
                                case TAG_MkPair: {
                                  V v_x_2464 = heff_field(v_x31_2463, 0);
                                  V v_j_2465 = heff_field(v_x31_2463, 1);
                                  heff_take_n(v_x31_2463, 3ULL, 2);
                                  V v_t_2466 = heff_tag_at_n(v_ru_24x31_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2450, v_x_2464}), v_j_2465});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2466}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_2463)}});
                                }
                              } else {
                                heff_drop_cell(v_ru_24x31_2442_24MkPair, 2);
                                heff_drop(v_x_2450);
                                heff_drop(v_field_2461);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2456)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop_cell(v_ru_24x31_2442_24MkPair, 2);
                          heff_drop(v_x_2450);
                          heff_drop(v_field_2454);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2449)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop_cell(v_ru_24x31_2442_24MkPair, 2);
                    heff_drop(v_field_2447);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2442)}});
              }
            } else {
              heff_drop(v_z_241);
              heff_drop(v_field_2440);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT2 v_t_2468 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
            {
              V v_field_2470 = v_t_2468.f[1];
              int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
              if ((v_tag_2469 == ((int64_t)0ULL))) {
                V v_x31_2472 = v_field_2470;
                switch (heff_tag_of(v_x31_2472)) {
                case TAG_MkPair: {
                  V v_x_2473 = heff_field(v_x31_2472, 0);
                  V v_j_2474 = heff_field(v_x31_2472, 1);
                  V v_ru_24x31_2472_24MkPair = heff_take_reuse_n(v_x31_2472, 3ULL, 2);
                  HeffT2 v_t_2475 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2473, heff_dup(v_z_241), v_j_2474));
                  {
                    V v_field_2477 = v_t_2475.f[1];
                    int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
                    if ((v_tag_2476 == ((int64_t)0ULL))) {
                      V v_x31_2479 = v_field_2477;
                      switch (heff_tag_of(v_x31_2479)) {
                      case TAG_MkPair: {
                        V v_x_2480 = heff_field(v_x31_2479, 0);
                        V v_j_2481 = heff_field(v_x31_2479, 1);
                        heff_take_n(v_x31_2479, 3ULL, 2);
                        HeffT2 v_t_2482 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2481));
                        {
                          V v_field_2484 = v_t_2482.f[1];
                          int64_t v_tag_2483 = ((int64_t)v_t_2482.f[0]);
                          if ((v_tag_2483 == ((int64_t)0ULL))) {
                            V v_x31_2486 = v_field_2484;
                            switch (heff_tag_of(v_x31_2486)) {
                            case TAG_MkPair: {
                              V v_x_2487 = heff_field(v_x31_2486, 0);
                              V v_j_2488 = heff_field(v_x31_2486, 1);
                              heff_take_n(v_x31_2486, 3ULL, 2);
                              HeffT2 v_t_2489 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_2487; V a_2 = v_z_241; V a_3 = v_j_2488; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2487); r_; });
                              {
                                V v_field_2491 = v_t_2489.f[1];
                                int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
                                if ((v_tag_2490 == ((int64_t)0ULL))) {
                                  V v_x31_2493 = v_field_2491;
                                  switch (heff_tag_of(v_x31_2493)) {
                                  case TAG_MkPair: {
                                    V v_x_2494 = heff_field(v_x31_2493, 0);
                                    V v_j_2495 = heff_field(v_x31_2493, 1);
                                    heff_take_n(v_x31_2493, 3ULL, 2);
                                    V v_t_2496 = heff_tag_at_n(v_ru_24x31_2472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2480, v_x_2494}), v_j_2495});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2496}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2493)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_2472_24MkPair, 2);
                                  heff_drop(v_x_2480);
                                  heff_drop(v_field_2491);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2486)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop_cell(v_ru_24x31_2472_24MkPair, 2);
                            heff_drop(v_x_2480);
                            heff_drop(v_field_2484);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2479)}});
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop_cell(v_ru_24x31_2472_24MkPair, 2);
                      heff_drop(v_field_2477);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2472)}});
                }
              } else {
                heff_drop(v_z_241);
                heff_drop(v_field_2470);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_2498 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_z_242));
              {
                V v_field_24100 = v_t_2498.f[1];
                int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
                if ((v_tag_2499 == ((int64_t)0ULL))) {
                  V v_x31_24102 = v_field_24100;
                  switch (heff_tag_of(v_x31_24102)) {
                  case TAG_MkPair: {
                    V v_x_24103 = heff_field(v_x31_24102, 0);
                    V v_j_24104 = heff_field(v_x31_24102, 1);
                    V v_ru_24x31_24102_24MkPair = heff_take_reuse_n(v_x31_24102, 3ULL, 2);
                    V v_t_24105 = heff_tag_at_n(v_ru_24x31_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_24103}), v_j_24104});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24105}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_24102)}});
                  }
                } else {
                  heff_drop(v_field_24100);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                HeffT2 v_t_24107 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                {
                  V v_field_24109 = v_t_24107.f[1];
                  int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
                  if ((v_tag_24108 == ((int64_t)0ULL))) {
                    V v_x31_24111 = v_field_24109;
                    switch (heff_tag_of(v_x31_24111)) {
                    case TAG_MkPair: {
                      V v_x_24112 = heff_field(v_x31_24111, 0);
                      V v_j_24113 = heff_field(v_x31_24111, 1);
                      V v_ru_24x31_24111_24MkPair = heff_take_reuse_n(v_x31_24111, 3ULL, 2);
                      HeffT2 v_t_24114 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24112, heff_dup(v_z_241), v_j_24113));
                      {
                        V v_field_24116 = v_t_24114.f[1];
                        int64_t v_tag_24115 = ((int64_t)v_t_24114.f[0]);
                        if ((v_tag_24115 == ((int64_t)0ULL))) {
                          V v_x31_24118 = v_field_24116;
                          switch (heff_tag_of(v_x31_24118)) {
                          case TAG_MkPair: {
                            V v_x_24119 = heff_field(v_x31_24118, 0);
                            V v_j_24120 = heff_field(v_x31_24118, 1);
                            heff_take_n(v_x31_24118, 3ULL, 2);
                            HeffT2 v_t_24121 = ({ V a_0 = v_z_241; V a_1 = v_j_24120; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                            {
                              V v_field_24123 = v_t_24121.f[1];
                              int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
                              if ((v_tag_24122 == ((int64_t)0ULL))) {
                                V v_x31_24125 = v_field_24123;
                                switch (heff_tag_of(v_x31_24125)) {
                                case TAG_MkPair: {
                                  V v_x_24126 = heff_field(v_x31_24125, 0);
                                  V v_j_24127 = heff_field(v_x31_24125, 1);
                                  heff_take_n(v_x31_24125, 3ULL, 2);
                                  V v_t_24128 = heff_tag_at_n(v_ru_24x31_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_24119, v_x_24126}), v_j_24127});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24128}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24125)}});
                                }
                              } else {
                                heff_drop_cell(v_ru_24x31_24111_24MkPair, 2);
                                heff_drop(v_x_24119);
                                heff_drop(v_field_24123);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24118)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop_cell(v_ru_24x31_24111_24MkPair, 2);
                          heff_drop(v_field_24116);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_24111)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_field_24109);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  HeffT2 v_t_24130 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                  {
                    V v_field_24132 = v_t_24130.f[1];
                    int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
                    if ((v_tag_24131 == ((int64_t)0ULL))) {
                      V v_x31_24134 = v_field_24132;
                      switch (heff_tag_of(v_x31_24134)) {
                      case TAG_MkPair: {
                        V v_x_24135 = heff_field(v_x31_24134, 0);
                        V v_j_24136 = heff_field(v_x31_24134, 1);
                        V v_ru_24x31_24134_24MkPair = heff_take_reuse_n(v_x31_24134, 3ULL, 2);
                        HeffT2 v_t_24137 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_24136));
                        {
                          V v_field_24139 = v_t_24137.f[1];
                          int64_t v_tag_24138 = ((int64_t)v_t_24137.f[0]);
                          if ((v_tag_24138 == ((int64_t)0ULL))) {
                            V v_x31_24141 = v_field_24139;
                            switch (heff_tag_of(v_x31_24141)) {
                            case TAG_MkPair: {
                              V v_x_24142 = heff_field(v_x31_24141, 0);
                              V v_j_24143 = heff_field(v_x31_24141, 1);
                              V v_ru_24x31_24141_24MkPair = heff_take_reuse_n(v_x31_24141, 3ULL, 2);
                              HeffT2 v_t_24144 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_24142, v_z_241, v_j_24143));
                              {
                                V v_field_24146 = v_t_24144.f[1];
                                int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
                                if ((v_tag_24145 == ((int64_t)0ULL))) {
                                  V v_x31_24148 = v_field_24146;
                                  switch (heff_tag_of(v_x31_24148)) {
                                  case TAG_MkPair: {
                                    V v_x_24149 = heff_field(v_x31_24148, 0);
                                    V v_j_24150 = heff_field(v_x31_24148, 1);
                                    heff_take_n(v_x31_24148, 3ULL, 2);
                                    V v_t_24151 = heff_tag_at_n(v_ru_24x31_24141_24MkPair, TAG_STag, 2, (V[]){v_x_24135, heff_arrayFromList(v_x_24149)});
                                    V v_f_24152 = heff_tag_at_n(v_ru_24x31_24134_24MkPair, TAG_MkPair, 2, (V[]){v_t_24151, v_j_24150});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24152}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24148)}});
                                  }
                                } else {
                                  heff_drop(v_x_24135);
                                  heff_drop_cell(v_ru_24x31_24134_24MkPair, 2);
                                  heff_drop_cell(v_ru_24x31_24141_24MkPair, 2);
                                  heff_drop(v_field_24146);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24141)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_x_24135);
                            heff_drop_cell(v_ru_24x31_24134_24MkPair, 2);
                            heff_drop(v_field_24139);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24134)}});
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop(v_field_24132);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    HeffT2 v_t_24154 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                    {
                      V v_field_24156 = v_t_24154.f[1];
                      int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
                      if ((v_tag_24155 == ((int64_t)0ULL))) {
                        V v_x31_24158 = v_field_24156;
                        switch (heff_tag_of(v_x31_24158)) {
                        case TAG_MkPair: {
                          V v_x_24159 = heff_field(v_x31_24158, 0);
                          V v_j_24160 = heff_field(v_x31_24158, 1);
                          V v_ru_24x31_24158_24MkPair = heff_take_reuse_n(v_x31_24158, 3ULL, 2);
                          HeffT2 v_t_24161 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24159, heff_dup(v_z_241), v_j_24160));
                          {
                            V v_field_24163 = v_t_24161.f[1];
                            int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
                            if ((v_tag_24162 == ((int64_t)0ULL))) {
                              V v_x31_24165 = v_field_24163;
                              switch (heff_tag_of(v_x31_24165)) {
                              case TAG_MkPair: {
                                V v_x_24166 = heff_field(v_x31_24165, 0);
                                V v_j_24167 = heff_field(v_x31_24165, 1);
                                heff_take_n(v_x31_24165, 3ULL, 2);
                                HeffT2 v_t_24168 = (g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(v_z_241, v_j_24167));
                                {
                                  V v_field_24170 = v_t_24168.f[1];
                                  int64_t v_tag_24169 = ((int64_t)v_t_24168.f[0]);
                                  if ((v_tag_24169 == ((int64_t)0ULL))) {
                                    V v_x31_24172 = v_field_24170;
                                    switch (heff_tag_of(v_x31_24172)) {
                                    case TAG_MkPair: {
                                      V v_x_24173 = heff_field(v_x31_24172, 0);
                                      V v_j_24174 = heff_field(v_x31_24172, 1);
                                      heff_take_n(v_x31_24172, 3ULL, 2);
                                      V v_t_24175 = heff_tag_at_n(v_ru_24x31_24158_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24166, v_x_24173}), v_j_24174});
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24175}});
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24172)}});
                                    }
                                  } else {
                                    heff_drop_cell(v_ru_24x31_24158_24MkPair, 2);
                                    heff_drop(v_x_24166);
                                    heff_drop(v_field_24170);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24165)}});
                              }
                            } else {
                              heff_drop(v_z_241);
                              heff_drop_cell(v_ru_24x31_24158_24MkPair, 2);
                              heff_drop(v_field_24163);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24158)}});
                        }
                      } else {
                        heff_drop(v_z_241);
                        heff_drop(v_field_24156);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      HeffT2 v_t_24177 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                      {
                        V v_field_24179 = v_t_24177.f[1];
                        int64_t v_tag_24178 = ((int64_t)v_t_24177.f[0]);
                        if ((v_tag_24178 == ((int64_t)0ULL))) {
                          V v_x31_24181 = v_field_24179;
                          switch (heff_tag_of(v_x31_24181)) {
                          case TAG_MkPair: {
                            V v_x_24182 = heff_field(v_x31_24181, 0);
                            V v_j_24183 = heff_field(v_x31_24181, 1);
                            V v_ru_24x31_24181_24MkPair = heff_take_reuse_n(v_x31_24181, 3ULL, 2);
                            HeffT2 v_t_24184 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24182, heff_dup(v_z_241), v_j_24183));
                            {
                              V v_field_24186 = v_t_24184.f[1];
                              int64_t v_tag_24185 = ((int64_t)v_t_24184.f[0]);
                              if ((v_tag_24185 == ((int64_t)0ULL))) {
                                V v_x31_24188 = v_field_24186;
                                switch (heff_tag_of(v_x31_24188)) {
                                case TAG_MkPair: {
                                  V v_x_24189 = heff_field(v_x31_24188, 0);
                                  V v_j_24190 = heff_field(v_x31_24188, 1);
                                  heff_take_n(v_x31_24188, 3ULL, 2);
                                  HeffT2 v_t_24191 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_j_24190));
                                  {
                                    V v_field_24193 = v_t_24191.f[1];
                                    int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
                                    if ((v_tag_24192 == ((int64_t)0ULL))) {
                                      V v_x31_24195 = v_field_24193;
                                      switch (heff_tag_of(v_x31_24195)) {
                                      case TAG_MkPair: {
                                        V v_x_24196 = heff_field(v_x31_24195, 0);
                                        V v_j_24197 = heff_field(v_x31_24195, 1);
                                        heff_take_n(v_x31_24195, 3ULL, 2);
                                        HeffT2 v_t_24198 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24197));
                                        {
                                          V v_field_24200 = v_t_24198.f[1];
                                          int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
                                          if ((v_tag_24199 == ((int64_t)0ULL))) {
                                            V v_x31_24202 = v_field_24200;
                                            switch (heff_tag_of(v_x31_24202)) {
                                            case TAG_MkPair: {
                                              V v_x_24203 = heff_field(v_x31_24202, 0);
                                              V v_j_24204 = heff_field(v_x31_24202, 1);
                                              heff_take_n(v_x31_24202, 3ULL, 2);
                                              HeffT2 v_t_24205 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24203, v_z_241, v_j_24204));
                                              {
                                                V v_field_24207 = v_t_24205.f[1];
                                                int64_t v_tag_24206 = ((int64_t)v_t_24205.f[0]);
                                                if ((v_tag_24206 == ((int64_t)0ULL))) {
                                                  V v_x31_24209 = v_field_24207;
                                                  switch (heff_tag_of(v_x31_24209)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24210 = heff_field(v_x31_24209, 0);
                                                    V v_j_24211 = heff_field(v_x31_24209, 1);
                                                    heff_take_n(v_x31_24209, 3ULL, 2);
                                                    V v_t_24212 = heff_tag_at_n(v_ru_24x31_24181_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24189, v_x_24196, v_x_24210}), v_j_24211});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24212}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24209)}});
                                                  }
                                                } else {
                                                  heff_drop_cell(v_ru_24x31_24181_24MkPair, 2);
                                                  heff_drop(v_x_24189);
                                                  heff_drop(v_x_24196);
                                                  heff_drop(v_field_24207);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24202)}});
                                            }
                                          } else {
                                            heff_drop(v_z_241);
                                            heff_drop_cell(v_ru_24x31_24181_24MkPair, 2);
                                            heff_drop(v_x_24189);
                                            heff_drop(v_x_24196);
                                            heff_drop(v_field_24200);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24195)}});
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop_cell(v_ru_24x31_24181_24MkPair, 2);
                                      heff_drop(v_x_24189);
                                      heff_drop(v_field_24193);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24188)}});
                                }
                              } else {
                                heff_drop(v_z_241);
                                heff_drop_cell(v_ru_24x31_24181_24MkPair, 2);
                                heff_drop(v_field_24186);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24181)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop(v_field_24179);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24214 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24216 = v_t_24214.f[1];
                          int64_t v_tag_24215 = ((int64_t)v_t_24214.f[0]);
                          if ((v_tag_24215 == ((int64_t)0ULL))) {
                            V v_x31_24218 = v_field_24216;
                            switch (heff_tag_of(v_x31_24218)) {
                            case TAG_MkPair: {
                              V v_x_24219 = heff_field(v_x31_24218, 0);
                              V v_j_24220 = heff_field(v_x31_24218, 1);
                              V v_ru_24x31_24218_24MkPair = heff_take_reuse_n(v_x31_24218, 3ULL, 2);
                              HeffT2 v_t_24221 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24219, v_z_241, v_j_24220));
                              {
                                V v_field_24223 = v_t_24221.f[1];
                                int64_t v_tag_24222 = ((int64_t)v_t_24221.f[0]);
                                if ((v_tag_24222 == ((int64_t)0ULL))) {
                                  V v_x31_24225 = v_field_24223;
                                  switch (heff_tag_of(v_x31_24225)) {
                                  case TAG_MkPair: {
                                    V v_x_24226 = heff_field(v_x31_24225, 0);
                                    V v_j_24227 = heff_field(v_x31_24225, 1);
                                    heff_take_n(v_x31_24225, 3ULL, 2);
                                    V v_t_24228 = heff_tag_at_n(v_ru_24x31_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){v_x_24226}), v_j_24227});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24228}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24225)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_24218_24MkPair, 2);
                                  heff_drop(v_field_24223);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24218)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24216);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11), 2)) {
                          heff_drop(v_x2_240);
                          heff_drop(v_z_241);
                          V v_t_24230 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_242});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24230}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12), 2)) {
                            heff_drop(v_x2_240);
                            heff_drop(v_z_241);
                            V v_t_24232 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_242});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24232}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13), 2)) {
                              heff_drop(v_x2_240);
                              HeffT2 v_t_24234 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                              {
                                V v_field_24236 = v_t_24234.f[1];
                                int64_t v_tag_24235 = ((int64_t)v_t_24234.f[0]);
                                if ((v_tag_24235 == ((int64_t)0ULL))) {
                                  V v_x31_24238 = v_field_24236;
                                  switch (heff_tag_of(v_x31_24238)) {
                                  case TAG_MkPair: {
                                    V v_x_24239 = heff_field(v_x31_24238, 0);
                                    V v_j_24240 = heff_field(v_x31_24238, 1);
                                    V v_ru_24x31_24238_24MkPair = heff_take_reuse_n(v_x31_24238, 3ULL, 2);
                                    HeffT2 v_t_24241 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24239, v_z_241, v_j_24240));
                                    {
                                      V v_field_24243 = v_t_24241.f[1];
                                      int64_t v_tag_24242 = ((int64_t)v_t_24241.f[0]);
                                      if ((v_tag_24242 == ((int64_t)0ULL))) {
                                        V v_x31_24245 = v_field_24243;
                                        switch (heff_tag_of(v_x31_24245)) {
                                        case TAG_MkPair: {
                                          V v_x_24246 = heff_field(v_x31_24245, 0);
                                          V v_j_24247 = heff_field(v_x31_24245, 1);
                                          heff_take_n(v_x31_24245, 3ULL, 2);
                                          V v_t_24248 = heff_tag_at_n(v_ru_24x31_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRec, 1, (V[]){v_x_24246}), v_j_24247});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24248}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24245)}});
                                        }
                                      } else {
                                        heff_drop_cell(v_ru_24x31_24238_24MkPair, 2);
                                        heff_drop(v_field_24243);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24238)}});
                                  }
                                } else {
                                  heff_drop(v_z_241);
                                  heff_drop(v_field_24236);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14), 2)) {
                                heff_drop(v_x2_240);
                                HeffT2 v_t_24250 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                                {
                                  V v_field_24252 = v_t_24250.f[1];
                                  int64_t v_tag_24251 = ((int64_t)v_t_24250.f[0]);
                                  if ((v_tag_24251 == ((int64_t)0ULL))) {
                                    V v_x31_24254 = v_field_24252;
                                    switch (heff_tag_of(v_x31_24254)) {
                                    case TAG_MkPair: {
                                      V v_x_24255 = heff_field(v_x31_24254, 0);
                                      V v_j_24256 = heff_field(v_x31_24254, 1);
                                      V v_ru_24x31_24254_24MkPair = heff_take_reuse_n(v_x31_24254, 3ULL, 2);
                                      HeffT2 v_t_24257 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24255, heff_dup(v_z_241), v_j_24256));
                                      {
                                        V v_field_24259 = v_t_24257.f[1];
                                        int64_t v_tag_24258 = ((int64_t)v_t_24257.f[0]);
                                        if ((v_tag_24258 == ((int64_t)0ULL))) {
                                          V v_x31_24261 = v_field_24259;
                                          switch (heff_tag_of(v_x31_24261)) {
                                          case TAG_MkPair: {
                                            V v_x_24262 = heff_field(v_x31_24261, 0);
                                            V v_j_24263 = heff_field(v_x31_24261, 1);
                                            heff_take_n(v_x31_24261, 3ULL, 2);
                                            HeffT2 v_t_24264 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24263));
                                            {
                                              V v_field_24266 = v_t_24264.f[1];
                                              int64_t v_tag_24265 = ((int64_t)v_t_24264.f[0]);
                                              if ((v_tag_24265 == ((int64_t)0ULL))) {
                                                V v_x31_24268 = v_field_24266;
                                                switch (heff_tag_of(v_x31_24268)) {
                                                case TAG_MkPair: {
                                                  V v_x_24269 = heff_field(v_x31_24268, 0);
                                                  V v_j_24270 = heff_field(v_x31_24268, 1);
                                                  heff_take_n(v_x31_24268, 3ULL, 2);
                                                  HeffT2 v_t_24271 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_24269; V a_2 = v_z_241; V a_3 = v_j_24270; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24269); r_; });
                                                  {
                                                    V v_field_24273 = v_t_24271.f[1];
                                                    int64_t v_tag_24272 = ((int64_t)v_t_24271.f[0]);
                                                    if ((v_tag_24272 == ((int64_t)0ULL))) {
                                                      V v_x31_24275 = v_field_24273;
                                                      switch (heff_tag_of(v_x31_24275)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24276 = heff_field(v_x31_24275, 0);
                                                        V v_j_24277 = heff_field(v_x31_24275, 1);
                                                        heff_take_n(v_x31_24275, 3ULL, 2);
                                                        V v_t_24278 = heff_tag_at_n(v_ru_24x31_24254_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24262, v_x_24276}), v_j_24277});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24278}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24275)}});
                                                      }
                                                    } else {
                                                      heff_drop_cell(v_ru_24x31_24254_24MkPair, 2);
                                                      heff_drop(v_x_24262);
                                                      heff_drop(v_field_24273);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24268)}});
                                                }
                                              } else {
                                                heff_drop(v_z_241);
                                                heff_drop_cell(v_ru_24x31_24254_24MkPair, 2);
                                                heff_drop(v_x_24262);
                                                heff_drop(v_field_24266);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24261)}});
                                          }
                                        } else {
                                          heff_drop(v_z_241);
                                          heff_drop_cell(v_ru_24x31_24254_24MkPair, 2);
                                          heff_drop(v_field_24259);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24254)}});
                                    }
                                  } else {
                                    heff_drop(v_z_241);
                                    heff_drop(v_field_24252);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15), 2)) {
                                  heff_drop(v_x2_240);
                                  HeffT2 v_t_24280 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                  {
                                    V v_field_24282 = v_t_24280.f[1];
                                    int64_t v_tag_24281 = ((int64_t)v_t_24280.f[0]);
                                    if ((v_tag_24281 == ((int64_t)0ULL))) {
                                      V v_x31_24284 = v_field_24282;
                                      switch (heff_tag_of(v_x31_24284)) {
                                      case TAG_MkPair: {
                                        V v_x_24285 = heff_field(v_x31_24284, 0);
                                        V v_j_24286 = heff_field(v_x31_24284, 1);
                                        V v_ru_24x31_24284_24MkPair = heff_take_reuse_n(v_x31_24284, 3ULL, 2);
                                        HeffT2 v_t_24287 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24286));
                                        {
                                          V v_field_24289 = v_t_24287.f[1];
                                          int64_t v_tag_24288 = ((int64_t)v_t_24287.f[0]);
                                          if ((v_tag_24288 == ((int64_t)0ULL))) {
                                            V v_x31_24291 = v_field_24289;
                                            switch (heff_tag_of(v_x31_24291)) {
                                            case TAG_MkPair: {
                                              V v_x_24292 = heff_field(v_x31_24291, 0);
                                              V v_j_24293 = heff_field(v_x31_24291, 1);
                                              heff_take_n(v_x31_24291, 3ULL, 2);
                                              HeffT2 v_t_24294 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24292, v_z_241, v_j_24293));
                                              {
                                                V v_field_24296 = v_t_24294.f[1];
                                                int64_t v_tag_24295 = ((int64_t)v_t_24294.f[0]);
                                                if ((v_tag_24295 == ((int64_t)0ULL))) {
                                                  V v_x31_24298 = v_field_24296;
                                                  switch (heff_tag_of(v_x31_24298)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24299 = heff_field(v_x31_24298, 0);
                                                    V v_j_24300 = heff_field(v_x31_24298, 1);
                                                    heff_take_n(v_x31_24298, 3ULL, 2);
                                                    V v_t_24301 = heff_tag_at_n(v_ru_24x31_24284_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24285, v_x_24299}), v_j_24300});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24301}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24298)}});
                                                  }
                                                } else {
                                                  heff_drop(v_x_24285);
                                                  heff_drop_cell(v_ru_24x31_24284_24MkPair, 2);
                                                  heff_drop(v_field_24296);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24291)}});
                                            }
                                          } else {
                                            heff_drop(v_z_241);
                                            heff_drop(v_x_24285);
                                            heff_drop_cell(v_ru_24x31_24284_24MkPair, 2);
                                            heff_drop(v_field_24289);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24284)}});
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop(v_field_24282);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16), 2)) {
                                    heff_drop(v_x2_240);
                                    HeffT2 v_t_24303 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                    {
                                      V v_field_24305 = v_t_24303.f[1];
                                      int64_t v_tag_24304 = ((int64_t)v_t_24303.f[0]);
                                      if ((v_tag_24304 == ((int64_t)0ULL))) {
                                        V v_x31_24307 = v_field_24305;
                                        switch (heff_tag_of(v_x31_24307)) {
                                        case TAG_MkPair: {
                                          V v_x_24308 = heff_field(v_x31_24307, 0);
                                          V v_j_24309 = heff_field(v_x31_24307, 1);
                                          V v_ru_24x31_24307_24MkPair = heff_take_reuse_n(v_x31_24307, 3ULL, 2);
                                          V v_t_24310 = heff_tag_at_n(v_ru_24x31_24307_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24308}), v_j_24309});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24310}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24307)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24305);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17), 2)) {
                                      heff_drop(v_x2_240);
                                      HeffT2 v_t_24312 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                      {
                                        V v_field_24314 = v_t_24312.f[1];
                                        int64_t v_tag_24313 = ((int64_t)v_t_24312.f[0]);
                                        if ((v_tag_24313 == ((int64_t)0ULL))) {
                                          V v_x31_24316 = v_field_24314;
                                          switch (heff_tag_of(v_x31_24316)) {
                                          case TAG_MkPair: {
                                            V v_x_24317 = heff_field(v_x31_24316, 0);
                                            V v_j_24318 = heff_field(v_x31_24316, 1);
                                            V v_ru_24x31_24316_24MkPair = heff_take_reuse_n(v_x31_24316, 3ULL, 2);
                                            V v_t_24319 = ({ V a_0 = v_x_24317; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24317); r_; });
                                            V v_x_24320 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24319});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24316_24MkPair, TAG_MkPair, 2, (V[]){v_x_24320, v_j_24318})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24316)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24314);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18), 2)) {
                                        heff_drop(v_x2_240);
                                        HeffT2 v_t_24322 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                        {
                                          V v_field_24324 = v_t_24322.f[1];
                                          int64_t v_tag_24323 = ((int64_t)v_t_24322.f[0]);
                                          if ((v_tag_24323 == ((int64_t)0ULL))) {
                                            V v_x31_24326 = v_field_24324;
                                            switch (heff_tag_of(v_x31_24326)) {
                                            case TAG_MkPair: {
                                              V v_x_24327 = heff_field(v_x31_24326, 0);
                                              V v_j_24328 = heff_field(v_x31_24326, 1);
                                              V v_ru_24x31_24326_24MkPair = heff_take_reuse_n(v_x31_24326, 3ULL, 2);
                                              V v_x2_24329 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19); V a_1 = v_x_24327; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20), v_x_24327, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24327); r_; });
                                              V v_t_24332;
                                              switch (heff_tag_of(v_x2_24329)) {
                                              case TAG_Nil: {
                                                v_t_24332 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21);
                                                break;
                                              }
                                              case TAG_Cons: {
                                                V v_x_24330 = heff_field(v_x2_24329, 0);
                                                V v_xs_24331 = heff_field(v_x2_24329, 1);
                                                heff_take_n(v_x2_24329, 3ULL, 2);
                                                v_t_24332 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22); V a_1 = v_x_24330; V a_2 = v_xs_24331; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24331); r_; });
                                                break;
                                              }
                                              default: heff_nomatch(v_x2_24329);
                                              }
                                              double v_t_24333 = ({ V a_0 = v_t_24332; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24332); r_; });
                                              V v_x_24334 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24333)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24326_24MkPair, TAG_MkPair, 2, (V[]){v_x_24334, v_j_24328})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24326)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24324);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23), 2)) {
                                          heff_drop(v_x2_240);
                                          HeffT2 v_t_24336 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                          {
                                            V v_field_24338 = v_t_24336.f[1];
                                            int64_t v_tag_24337 = ((int64_t)v_t_24336.f[0]);
                                            if ((v_tag_24337 == ((int64_t)0ULL))) {
                                              V v_x31_24340 = v_field_24338;
                                              switch (heff_tag_of(v_x31_24340)) {
                                              case TAG_MkPair: {
                                                V v_x_24341 = heff_field(v_x31_24340, 0);
                                                V v_j_24342 = heff_field(v_x31_24340, 1);
                                                V v_ru_24x31_24340_24MkPair = heff_take_reuse_n(v_x31_24340, 3ULL, 2);
                                                V v_t_24343 = heff_tag_at_n(v_ru_24x31_24340_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24341}), v_j_24342});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24343}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24340)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24338);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str24), 2)) {
                                            heff_drop(v_x2_240);
                                            HeffT2 v_t_24345 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                            {
                                              V v_field_24347 = v_t_24345.f[1];
                                              int64_t v_tag_24346 = ((int64_t)v_t_24345.f[0]);
                                              if ((v_tag_24346 == ((int64_t)0ULL))) {
                                                V v_x31_24349 = v_field_24347;
                                                switch (heff_tag_of(v_x31_24349)) {
                                                case TAG_MkPair: {
                                                  V v_x_24350 = heff_field(v_x31_24349, 0);
                                                  V v_j_24351 = heff_field(v_x31_24349, 1);
                                                  V v_ru_24x31_24349_24MkPair = heff_take_reuse_n(v_x31_24349, 3ULL, 2);
                                                  V v_t_24352 = heff_tag_at_n(v_ru_24x31_24349_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24350}), v_j_24351});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24352}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24349)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24347);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str25), 2)) {
                                              heff_drop(v_x2_240);
                                              HeffT2 v_t_24354 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                              {
                                                V v_field_24356 = v_t_24354.f[1];
                                                int64_t v_tag_24355 = ((int64_t)v_t_24354.f[0]);
                                                if ((v_tag_24355 == ((int64_t)0ULL))) {
                                                  V v_x31_24358 = v_field_24356;
                                                  switch (heff_tag_of(v_x31_24358)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24359 = heff_field(v_x31_24358, 0);
                                                    V v_j_24360 = heff_field(v_x31_24358, 1);
                                                    V v_ru_24x31_24358_24MkPair = heff_take_reuse_n(v_x31_24358, 3ULL, 2);
                                                    V v_t_24361 = ({ V a_0 = v_x_24359; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24359); r_; });
                                                    V v_x_24362 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24361});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24358_24MkPair, TAG_MkPair, 2, (V[]){v_x_24362, v_j_24360})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24358)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24356);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str26), 2)) {
                                                heff_drop(v_x2_240);
                                                HeffT2 v_t_24364 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_241, v_z_242));
                                                {
                                                  V v_field_24366 = v_t_24364.f[1];
                                                  int64_t v_tag_24365 = ((int64_t)v_t_24364.f[0]);
                                                  if ((v_tag_24365 == ((int64_t)0ULL))) {
                                                    V v_x31_24368 = v_field_24366;
                                                    switch (heff_tag_of(v_x31_24368)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24369 = heff_field(v_x31_24368, 0);
                                                      V v_j_24370 = heff_field(v_x31_24368, 1);
                                                      V v_ru_24x31_24368_24MkPair = heff_take_reuse_n(v_x31_24368, 3ULL, 2);
                                                      HeffT2 v_t_24371 = ({ V a_0 = v_z_241; V a_1 = v_j_24370; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                                      {
                                                        V v_field_24373 = v_t_24371.f[1];
                                                        int64_t v_tag_24372 = ((int64_t)v_t_24371.f[0]);
                                                        if ((v_tag_24372 == ((int64_t)0ULL))) {
                                                          V v_x31_24375 = v_field_24373;
                                                          switch (heff_tag_of(v_x31_24375)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24376 = heff_field(v_x31_24375, 0);
                                                            V v_j_24377 = heff_field(v_x31_24375, 1);
                                                            V v_ru_24x31_24375_24MkPair = heff_take_reuse_n(v_x31_24375, 3ULL, 2);
                                                            V v_t_24378 = ({ V a_0 = v_x_24376; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24376); r_; });
                                                            V v_x_24379 = heff_tag_at_n(v_ru_24x31_24375_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24369, v_t_24378});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24368_24MkPair, TAG_MkPair, 2, (V[]){v_x_24379, v_j_24377})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24375)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24369);
                                                          heff_drop_cell(v_ru_24x31_24368_24MkPair, 2);
                                                          heff_drop(v_field_24373);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24368)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_241);
                                                    heff_drop(v_field_24366);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str27))) {
                                                  HeffT2 v_t_24381 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                                  {
                                                    V v_field_24383 = v_t_24381.f[1];
                                                    int64_t v_tag_24382 = ((int64_t)v_t_24381.f[0]);
                                                    if ((v_tag_24382 == ((int64_t)0ULL))) {
                                                      V v_x31_24385 = v_field_24383;
                                                      switch (heff_tag_of(v_x31_24385)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24386 = heff_field(v_x31_24385, 0);
                                                        V v_j_24387 = heff_field(v_x31_24385, 1);
                                                        V v_ru_24x31_24385_24MkPair = heff_take_reuse_n(v_x31_24385, 3ULL, 2);
                                                        V v_x2_24388 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str28); V a_1 = v_x_24386; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str29), v_x_24386, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24386); r_; });
                                                        V v_t_24391;
                                                        switch (heff_tag_of(v_x2_24388)) {
                                                        case TAG_Nil: {
                                                          v_t_24391 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str30);
                                                          break;
                                                        }
                                                        case TAG_Cons: {
                                                          V v_x_24389 = heff_field(v_x2_24388, 0);
                                                          V v_xs_24390 = heff_field(v_x2_24388, 1);
                                                          heff_take_n(v_x2_24388, 3ULL, 2);
                                                          v_t_24391 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str31); V a_1 = v_x_24389; V a_2 = v_xs_24390; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24390); r_; });
                                                          break;
                                                        }
                                                        default: heff_nomatch(v_x2_24388);
                                                        }
                                                        double v_t_24392 = ({ V a_0 = v_t_24391; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24391); r_; });
                                                        V v_x_24393 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24392)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24385_24MkPair, TAG_MkPair, 2, (V[]){v_x_24393, v_j_24387})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24385)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24383);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_247, v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              V v_f_2416 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2414), v_j_2415});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
            }
          } else {
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_245 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          V v_x31_249 = v_field_247;
          switch (heff_tag_of(v_x31_249)) {
          case TAG_MkPair: {
            V v_x_2410 = heff_field(v_x31_249, 0);
            V v_j_2411 = heff_field(v_x31_249, 1);
            V v_ru_24x31_249_24MkPair = heff_take_reuse_n(v_x31_249, 3ULL, 2);
            HeffT2 v_t_2412 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2410, v_z_241, v_j_2411));
            {
              V v_field_2414 = v_t_2412.f[1];
              int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
              if ((v_tag_2413 == ((int64_t)0ULL))) {
                V v_x31_2416 = v_field_2414;
                switch (heff_tag_of(v_x31_2416)) {
                case TAG_MkPair: {
                  V v_x_2417 = heff_field(v_x31_2416, 0);
                  V v_j_2418 = heff_field(v_x31_2416, 1);
                  heff_take_n(v_x31_2416, 3ULL, 2);
                  V v_t_2419 = heff_tag_at_n(v_ru_24x31_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2417}), v_j_2418});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2419}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
                }
              } else {
                heff_drop_cell(v_ru_24x31_249_24MkPair, 2);
                heff_drop(v_field_2414);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_249)}});
          }
        } else {
          heff_drop(v_z_241);
          heff_drop(v_field_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2421 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_x31_2425 = v_field_2423;
            switch (heff_tag_of(v_x31_2425)) {
            case TAG_MkPair: {
              V v_x_2426 = heff_field(v_x31_2425, 0);
              V v_j_2427 = heff_field(v_x31_2425, 1);
              V v_ru_24x31_2425_24MkPair = heff_take_reuse_n(v_x31_2425, 3ULL, 2);
              HeffT2 v_t_2428 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2427));
              {
                V v_field_2430 = v_t_2428.f[1];
                int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                if ((v_tag_2429 == ((int64_t)0ULL))) {
                  V v_x31_2432 = v_field_2430;
                  switch (heff_tag_of(v_x31_2432)) {
                  case TAG_MkPair: {
                    V v_x_2433 = heff_field(v_x31_2432, 0);
                    V v_j_2434 = heff_field(v_x31_2432, 1);
                    heff_take_n(v_x31_2432, 3ULL, 2);
                    HeffT2 v_t_2435 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2433, heff_dup(v_z_241), v_j_2434));
                    {
                      V v_field_2437 = v_t_2435.f[1];
                      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
                      if ((v_tag_2436 == ((int64_t)0ULL))) {
                        V v_x31_2439 = v_field_2437;
                        switch (heff_tag_of(v_x31_2439)) {
                        case TAG_MkPair: {
                          V v_x_2440 = heff_field(v_x31_2439, 0);
                          V v_j_2441 = heff_field(v_x31_2439, 1);
                          heff_take_n(v_x31_2439, 3ULL, 2);
                          HeffT2 v_t_2442 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2441));
                          {
                            V v_field_2444 = v_t_2442.f[1];
                            int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
                            if ((v_tag_2443 == ((int64_t)0ULL))) {
                              V v_x31_2446 = v_field_2444;
                              switch (heff_tag_of(v_x31_2446)) {
                              case TAG_MkPair: {
                                V v_x_2447 = heff_field(v_x31_2446, 0);
                                V v_j_2448 = heff_field(v_x31_2446, 1);
                                heff_take_n(v_x31_2446, 3ULL, 2);
                                HeffT2 v_t_2449 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)); V a_1 = v_x_2447; V a_2 = heff_dup(v_z_241); V a_3 = v_j_2448; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2447); r_; });
                                {
                                  V v_field_2451 = v_t_2449.f[1];
                                  int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
                                  if ((v_tag_2450 == ((int64_t)0ULL))) {
                                    V v_x31_2453 = v_field_2451;
                                    switch (heff_tag_of(v_x31_2453)) {
                                    case TAG_MkPair: {
                                      V v_x_2454 = heff_field(v_x31_2453, 0);
                                      V v_j_2455 = heff_field(v_x31_2453, 1);
                                      heff_take_n(v_x31_2453, 3ULL, 2);
                                      HeffT2 v_t_2456 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_241, v_j_2455));
                                      {
                                        V v_field_2458 = v_t_2456.f[1];
                                        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                        if ((v_tag_2457 == ((int64_t)0ULL))) {
                                          V v_x31_2460 = v_field_2458;
                                          switch (heff_tag_of(v_x31_2460)) {
                                          case TAG_MkPair: {
                                            V v_x_2461 = heff_field(v_x31_2460, 0);
                                            V v_j_2462 = heff_field(v_x31_2460, 1);
                                            heff_take_n(v_x31_2460, 3ULL, 2);
                                            HeffT2 v_t_2463 = (g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(v_z_241, v_j_2462));
                                            {
                                              V v_field_2465 = v_t_2463.f[1];
                                              int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                                              if ((v_tag_2464 == ((int64_t)0ULL))) {
                                                V v_x31_2467 = v_field_2465;
                                                switch (heff_tag_of(v_x31_2467)) {
                                                case TAG_MkPair: {
                                                  V v_x_2468 = heff_field(v_x31_2467, 0);
                                                  V v_j_2469 = heff_field(v_x31_2467, 1);
                                                  heff_take_n(v_x31_2467, 3ULL, 2);
                                                  V v_t_2470 = heff_tag_at_n(v_ru_24x31_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2426, v_x_2440, v_x_2454, v_x_2461, v_x_2468}), v_j_2469});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2470}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_2467)}});
                                                }
                                              } else {
                                                heff_drop(v_x_2426);
                                                heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                                                heff_drop(v_x_2440);
                                                heff_drop(v_x_2454);
                                                heff_drop(v_x_2461);
                                                heff_drop(v_field_2465);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_2460)}});
                                          }
                                        } else {
                                          heff_drop(v_z_241);
                                          heff_drop(v_x_2426);
                                          heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                                          heff_drop(v_x_2440);
                                          heff_drop(v_x_2454);
                                          heff_drop(v_field_2458);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_2453)}});
                                    }
                                  } else {
                                    heff_drop(v_z_241);
                                    heff_drop(v_x_2426);
                                    heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                                    heff_drop(v_x_2440);
                                    heff_drop(v_field_2451);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2446)}});
                              }
                            } else {
                              heff_drop(v_z_241);
                              heff_drop(v_x_2426);
                              heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                              heff_drop(v_x_2440);
                              heff_drop(v_field_2444);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2439)}});
                        }
                      } else {
                        heff_drop(v_z_241);
                        heff_drop(v_x_2426);
                        heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                        heff_drop(v_field_2437);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2432)}});
                  }
                } else {
                  heff_drop(v_z_241);
                  heff_drop(v_x_2426);
                  heff_drop_cell(v_ru_24x31_2425_24MkPair, 2);
                  heff_drop(v_field_2430);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2425)}});
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2423);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2472 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
          {
            V v_field_2474 = v_t_2472.f[1];
            int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
            if ((v_tag_2473 == ((int64_t)0ULL))) {
              V v_x31_2476 = v_field_2474;
              switch (heff_tag_of(v_x31_2476)) {
              case TAG_MkPair: {
                V v_x_2477 = heff_field(v_x31_2476, 0);
                V v_j_2478 = heff_field(v_x31_2476, 1);
                V v_ru_24x31_2476_24MkPair = heff_take_reuse_n(v_x31_2476, 3ULL, 2);
                HeffT2 v_t_2479 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), heff_dup(v_z_241), v_j_2478));
                {
                  V v_field_2481 = v_t_2479.f[1];
                  int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
                  if ((v_tag_2480 == ((int64_t)0ULL))) {
                    V v_x31_2483 = v_field_2481;
                    switch (heff_tag_of(v_x31_2483)) {
                    case TAG_MkPair: {
                      V v_x_2484 = heff_field(v_x31_2483, 0);
                      V v_j_2485 = heff_field(v_x31_2483, 1);
                      heff_take_n(v_x31_2483, 3ULL, 2);
                      HeffT2 v_t_2486 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_j_2485));
                      {
                        V v_field_2488 = v_t_2486.f[1];
                        int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                        if ((v_tag_2487 == ((int64_t)0ULL))) {
                          V v_x31_2490 = v_field_2488;
                          switch (heff_tag_of(v_x31_2490)) {
                          case TAG_MkPair: {
                            V v_x_2491 = heff_field(v_x31_2490, 0);
                            V v_j_2492 = heff_field(v_x31_2490, 1);
                            heff_take_n(v_x31_2490, 3ULL, 2);
                            V v_t_2493 = heff_tag_at_n(v_ru_24x31_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2477, v_x_2484, v_x_2491}), v_j_2492});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2493}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2490)}});
                          }
                        } else {
                          heff_drop(v_x_2477);
                          heff_drop_cell(v_ru_24x31_2476_24MkPair, 2);
                          heff_drop(v_x_2484);
                          heff_drop(v_field_2488);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2483)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_x_2477);
                    heff_drop_cell(v_ru_24x31_2476_24MkPair, 2);
                    heff_drop(v_field_2481);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2476)}});
              }
            } else {
              heff_drop(v_z_241);
              heff_drop(v_field_2474);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT2 v_t_2495 = (g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_24cpr(v_z_241, v_z_242));
            {
              V v_field_2497 = v_t_2495.f[1];
              int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
              if ((v_tag_2496 == ((int64_t)0ULL))) {
                V v_x31_2499 = v_field_2497;
                switch (heff_tag_of(v_x31_2499)) {
                case TAG_MkPair: {
                  V v_x_24100 = heff_field(v_x31_2499, 0);
                  V v_j_24101 = heff_field(v_x31_2499, 1);
                  V v_ru_24x31_2499_24MkPair = heff_take_reuse_n(v_x31_2499, 3ULL, 2);
                  V v_t_24102 = heff_tag_at_n(v_ru_24x31_2499_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_24100}), v_j_24101});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24102}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2499)}});
                }
              } else {
                heff_drop(v_field_2497);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_24104 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
              {
                V v_field_24106 = v_t_24104.f[1];
                int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
                if ((v_tag_24105 == ((int64_t)0ULL))) {
                  V v_x31_24108 = v_field_24106;
                  switch (heff_tag_of(v_x31_24108)) {
                  case TAG_MkPair: {
                    V v_x_24109 = heff_field(v_x31_24108, 0);
                    V v_j_24110 = heff_field(v_x31_24108, 1);
                    V v_ru_24x31_24108_24MkPair = heff_take_reuse_n(v_x31_24108, 3ULL, 2);
                    HeffT2 v_t_24111 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24109, v_z_241, v_j_24110));
                    {
                      V v_field_24113 = v_t_24111.f[1];
                      int64_t v_tag_24112 = ((int64_t)v_t_24111.f[0]);
                      if ((v_tag_24112 == ((int64_t)0ULL))) {
                        V v_x31_24115 = v_field_24113;
                        switch (heff_tag_of(v_x31_24115)) {
                        case TAG_MkPair: {
                          V v_x_24116 = heff_field(v_x31_24115, 0);
                          V v_j_24117 = heff_field(v_x31_24115, 1);
                          heff_take_n(v_x31_24115, 3ULL, 2);
                          V v_t_24118 = heff_tag_at_n(v_ru_24x31_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_24116}), v_j_24117});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24118}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24115)}});
                        }
                      } else {
                        heff_drop_cell(v_ru_24x31_24108_24MkPair, 2);
                        heff_drop(v_field_24113);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_24108)}});
                  }
                } else {
                  heff_drop(v_z_241);
                  heff_drop(v_field_24106);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                heff_drop(v_z_241);
                V v_t_24120 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_242});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24120}});
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  heff_drop(v_z_241);
                  V v_t_24122 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_242});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24122}});
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    heff_drop(v_z_241);
                    V v_t_24124 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_242});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24124}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      heff_drop(v_z_241);
                      V v_t_24126 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_242});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24126}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24128 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24130 = v_t_24128.f[1];
                          int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
                          if ((v_tag_24129 == ((int64_t)0ULL))) {
                            V v_x31_24132 = v_field_24130;
                            switch (heff_tag_of(v_x31_24132)) {
                            case TAG_MkPair: {
                              V v_x_24133 = heff_field(v_x31_24132, 0);
                              V v_j_24134 = heff_field(v_x31_24132, 1);
                              V v_ru_24x31_24132_24MkPair = heff_take_reuse_n(v_x31_24132, 3ULL, 2);
                              HeffT2 v_t_24135 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24133, v_z_241, v_j_24134));
                              {
                                V v_field_24137 = v_t_24135.f[1];
                                int64_t v_tag_24136 = ((int64_t)v_t_24135.f[0]);
                                if ((v_tag_24136 == ((int64_t)0ULL))) {
                                  V v_x31_24139 = v_field_24137;
                                  switch (heff_tag_of(v_x31_24139)) {
                                  case TAG_MkPair: {
                                    V v_x_24140 = heff_field(v_x31_24139, 0);
                                    V v_j_24141 = heff_field(v_x31_24139, 1);
                                    heff_take_n(v_x31_24139, 3ULL, 2);
                                    V v_t_24142 = heff_tag_at_n(v_ru_24x31_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_24140}), v_j_24141});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24142}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24139)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_24132_24MkPair, 2);
                                  heff_drop(v_field_24137);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24132)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24130);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11))) {
                          HeffT2 v_t_24144 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                          {
                            V v_field_24146 = v_t_24144.f[1];
                            int64_t v_tag_24145 = ((int64_t)v_t_24144.f[0]);
                            if ((v_tag_24145 == ((int64_t)0ULL))) {
                              V v_x31_24148 = v_field_24146;
                              switch (heff_tag_of(v_x31_24148)) {
                              case TAG_MkPair: {
                                V v_x_24149 = heff_field(v_x31_24148, 0);
                                V v_j_24150 = heff_field(v_x31_24148, 1);
                                V v_ru_24x31_24148_24MkPair = heff_take_reuse_n(v_x31_24148, 3ULL, 2);
                                V v_t_24151 = heff_tag_at_n(v_ru_24x31_24148_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_24149}), v_j_24150});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24151}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24148)}});
                              }
                            } else {
                              heff_drop(v_field_24146);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}