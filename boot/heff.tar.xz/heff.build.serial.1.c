// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(V, V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V, V, V);
V g_heff_2eelab_2eprimitive_2ecompilerTable_get(void);
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void);
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
double g_heff_2esyntax_2esurface_2efloatOfText_w(V);
V g_heff_2esyntax_2esurface_2efloatOfText(V);
V g_heff_2esyntax_2esurface_2efloatOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfText_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_243, 0));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, v_lit_240), v_x_243);
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, v_a_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s295180745x1731850163(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_lit_240), v_a_246);
      V v_t_2410 = ({ V a_0 = v_a_247; V a_1 = v_a_245; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_a_247); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SmallU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1), v_rest_241})});
    }
    case TAG_LargeU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3), v_rest_241})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_x2_240, 0);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_243), v_rest_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4), v_t_244});
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_dflt_249 = heff_field(v_x2_240, 4);
    V v_t_2410;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_dflt_249)) {
    case TAG_Nothing: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2412 = heff_field(v_dflt_249, 0);
      V v_t_2413 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2412), v_rest_241));
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12), v_t_2413});
      break;
    }
    default: heff_nomatch(v_dflt_249);
    }
    V v_rest_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2414});
    V v_rest_2423;
    switch (heff_tag_of(v_cod_247)) {
    case TAG_MkAbs: {
      V v_x_2416 = heff_field(v_cod_247, 0);
      V v_e_2417 = heff_field(v_cod_247, 1);
      V v_t_2418 = heff_intShow(heff_strLength_lent(v_x_2416, 0));
      V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13)), heff_dup(v_x_2416));
      V v_t_2420 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2417, v_rest_2415));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2420})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2421 = heff_field(v_cod_247, 0);
      V v_t_2422 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2421, v_rest_2415));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15), v_t_2422});
      break;
    }
    default: heff_nomatch(v_cod_247);
    }
    V v_t_2424 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_246, v_rest_2423));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2424})});
  }
  case TAG_SRecord: {
    V v_level_2425 = heff_field(v_x2_240, 0);
    V v_fs_2426 = heff_field(v_x2_240, 1);
    V v_ds_2427 = heff_field(v_x2_240, 2);
    V v_keys_2428 = heff_dup(heff_rfield(v_ds_2427, 0));
    V v_values_2429 = heff_dup(heff_rfield(v_ds_2427, 2));
    V v_keys_2430 = heff_dup(heff_rfield(v_fs_2426, 0));
    V v_values_2431 = heff_dup(heff_rfield(v_fs_2426, 2));
    V v_t_2432;
    switch (heff_tag_of(v_level_2425)) {
    case TAG_Small: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17);
      break;
    }
    case TAG_Large: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2432 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19);
      break;
    }
    default: heff_nomatch(v_level_2425);
    }
    V v_xs_2433 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2428), heff_arrayToList(v_values_2429)));
    V v_i_2434 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2433));
    V v_t_2435 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20), v_xs_2433, v_rest_241));
    V v_rest_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2434), v_t_2435});
    V v_xs_2437 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2430), heff_arrayToList(v_values_2431)));
    V v_i_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2437));
    V v_t_2439 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s31373062x905074275(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21), v_xs_2437, v_rest_2436));
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), v_t_2439});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2440})});
  }
  case TAG_SSum: {
    V v_vs_2441 = heff_field(v_x2_240, 0);
    V v_keys_2442 = heff_dup(heff_rfield(v_vs_2441, 0));
    V v_values_2443 = heff_dup(heff_rfield(v_vs_2441, 2));
    V v_xs_2444 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2442), heff_arrayToList(v_values_2443)));
    V v_i_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2444));
    V v_t_2446 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s901450926x1699219855(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2444, v_rest_241));
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2445), v_t_2446});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24), v_t_2447});
  }
  case TAG_SIsTy: {
    V v_t2_2448 = heff_field(v_x2_240, 0);
    V v_cell_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25), heff_hole()});
    V v_u_2450 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2448, v_rest_241, heff_dup(v_cell_2449)));
    heff_drop(v_u_2450);
    return v_cell_2449;
  }
  case TAG_SPrimInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26), v_rest_241});
  }
  case TAG_SPrimFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27), v_rest_241});
  }
  case TAG_SPrimString: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28), v_rest_241});
  }
  case TAG_SPrimRune: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29), v_rest_241});
  }
  case TAG_SPrimArray: {
    V v_t2_2451 = heff_field(v_x2_240, 0);
    V v_cell_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30), heff_hole()});
    V v_u_2453 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2451, v_rest_241, heff_dup(v_cell_2452)));
    heff_drop(v_u_2453);
    return v_cell_2452;
  }
  case TAG_SFixed: {
    V v_w_2454 = heff_field(v_x2_240, 0);
    V v_t_2455;
    switch (heff_tag_of(v_w_2454)) {
    case TAG_I8: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31);
      break;
    }
    case TAG_I16: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32);
      break;
    }
    case TAG_I32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33);
      break;
    }
    case TAG_I64: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34);
      break;
    }
    case TAG_U8: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35);
      break;
    }
    case TAG_U16: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36);
      break;
    }
    case TAG_U32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37);
      break;
    }
    case TAG_U64: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38);
      break;
    }
    case TAG_F32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39);
      break;
    }
    default: heff_nomatch(v_w_2454);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_242), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0), v_t_243});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_245 = heff_intShow(heff_strLength_lent(v_x_244, 0));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1)), v_x_244);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_rest_241})});
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3), v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_x2_240, 0);
    V v_a_2410 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2411 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2410, v_rest_241));
    V v_t_2412 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_f_249, v_rest_2411));
    return heff_tag_at_n(v_ru_24x2_240_24SApp, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4), v_t_2412});
  }
  case TAG_SLam: {
    V v_t_2413 = heff_field(v_x2_240, 0);
    V v_b_2414 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2422;
    switch (heff_tag_of(v_b_2414)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2414, 0);
      V v_e_2416 = heff_field(v_b_2414, 1);
      V v_ru_24b_2414_24MkAbs = heff_take_reuse_n(v_b_2414, 3ULL, 2);
      V v_t_2417 = heff_intShow(heff_strLength_lent(v_x_2415, 0));
      V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5)), v_x_2415);
      V v_t_2419 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2416, v_rest_241));
      v_rest_2422 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6), heff_tag_at_n(v_ru_24b_2414_24MkAbs, TAG_Cons, 2, (V[]){v_t_2418, v_t_2419})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2420 = heff_field(v_b_2414, 0);
      heff_take_n(v_b_2414, 1ULL, 1);
      V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2420, v_rest_241));
      v_rest_2422 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7), v_t_2421});
      break;
    }
    default: heff_nomatch(v_b_2414);
    }
    V v_t_2423 = ({ V a_0 = v_t_2413; V a_1 = v_rest_2422; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8), v_t_2423});
  }
  case TAG_SCons: {
    V v_d_2424 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_keys_2425 = heff_take_field(v_d_2424, 0);
    V v_values_2426 = heff_get_n(v_d_2424, 2, 3);
    V v_xs_2427 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2425), heff_arrayToList(v_values_2426)));
    V v_i_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2427));
    V v_t_2429 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9), v_xs_2427, v_rest_241));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2428), v_t_2429});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10), v_t_2430});
  }
  case TAG_SProj: {
    V v_e2_2431 = heff_field(v_x2_240, 0);
    V v_l_2432 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2433 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11), heff_hole()});
    V v_t_2434 = heff_intShow(heff_strLength_lent(v_l_2432, 0));
    V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12)), v_l_2432);
    V v_u_2436 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2431, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_rest_241}), heff_dup(v_cell_2433)));
    heff_drop(v_u_2436);
    return v_cell_2433;
  }
  case TAG_STag: {
    V v_t_2437 = heff_field(v_x2_240, 0);
    V v_args_2438 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439 = heff_intShow(heff_strLength_lent(v_t_2437, 0));
    V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13)), v_t_2437);
    V v_xs_2441 = heff_arrayToList(v_args_2438);
    V v_i_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = ({ V a_0 = v_xs_2441; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2441); r_; });
    V v_t_2444 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2444})});
  }
  case TAG_SMatch: {
    V v_e2_2445 = heff_field(v_x2_240, 0);
    V v_cs_2446 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_keys_2447 = heff_take_field(v_cs_2446, 0);
    V v_values_2448 = heff_get_n(v_cs_2446, 2, 3);
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2447), heff_arrayToList(v_values_2448)));
    V v_i_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16), v_xs_2449, v_rest_241));
    V v_rest_2452 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    V v_t_2453 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2445, v_rest_2452));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17), v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e2_2454 = heff_field(v_x2_240, 0);
    V v_l_2455 = heff_field(v_x2_240, 1);
    V v_v_2456 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2457 = heff_intShow(heff_strLength_lent(v_l_2455, 0));
    V v_t_2458 = heff_strAppend(heff_strAppend(v_t_2457, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18)), v_l_2455);
    V v_t_2459 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2456, v_rest_241));
    V v_rest_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2459});
    V v_t_2461 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2454, v_rest_2460));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19), v_t_2461});
  }
  case TAG_SIs: {
    V v_e2_2462 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20), heff_hole()});
    V v_u_2464 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2462, v_rest_241, heff_dup(v_cell_2463)));
    heff_drop(v_u_2464);
    return v_cell_2463;
  }
  case TAG_SOpaque: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21), v_rest_241});
  }
  case TAG_SAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22), v_rest_241});
  }
  case TAG_SRec: {
    V v_e2_2465 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23), heff_hole()});
    V v_u_2467 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2465, v_rest_241, heff_dup(v_cell_2466)));
    heff_drop(v_u_2467);
    return v_cell_2466;
  }
  case TAG_SFix: {
    V v_t_2468 = heff_field(v_x2_240, 0);
    V v_b_2469 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2477;
    switch (heff_tag_of(v_b_2469)) {
    case TAG_MkAbs: {
      V v_x_2470 = heff_field(v_b_2469, 0);
      V v_e_2471 = heff_field(v_b_2469, 1);
      V v_ru_24b_2469_24MkAbs = heff_take_reuse_n(v_b_2469, 3ULL, 2);
      V v_t_2472 = heff_intShow(heff_strLength_lent(v_x_2470, 0));
      V v_t_2473 = heff_strAppend(heff_strAppend(v_t_2472, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24)), v_x_2470);
      V v_t_2474 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2471, v_rest_241));
      v_rest_2477 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25), heff_tag_at_n(v_ru_24b_2469_24MkAbs, TAG_Cons, 2, (V[]){v_t_2473, v_t_2474})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2475 = heff_field(v_b_2469, 0);
      heff_take_n(v_b_2469, 1ULL, 1);
      V v_t_2476 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2475, v_rest_241));
      v_rest_2477 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26), v_t_2476});
      break;
    }
    default: heff_nomatch(v_b_2469);
    }
    V v_t_2478 = ({ V a_0 = v_t_2468; V a_1 = v_rest_2477; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2468); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27), v_t_2478});
  }
  case TAG_SImplicit: {
    V v_x_2479 = heff_field(v_x2_240, 0);
    V v_e2_2480 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2481 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28), heff_hole()});
    V v_t_2482 = heff_intShow(heff_strLength_lent(v_x_2479, 0));
    V v_t_2483 = heff_strAppend(heff_strAppend(v_t_2482, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29)), v_x_2479);
    V v_cell_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, heff_hole()});
    V v_u_2485 = heff_setField(heff_dup(v_cell_2481), MK_INT(1LL), heff_dup(v_cell_2484));
    heff_drop(v_u_2485);
    V v_u_2486 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2480, v_rest_241, v_cell_2484));
    heff_drop(v_u_2486);
    return v_cell_2481;
  }
  case TAG_SPrim: {
    V v_x_2487 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2488 = ({ V a_0 = v_x_2487; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x_2487); r_; });
    V v_t_2489 = heff_intShow(heff_strLength_lent(v_s_2488, 0));
    V v_t_2490 = heff_strAppend(heff_strAppend(v_t_2489, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30)), v_s_2488);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, v_rest_241})});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32), v_rest_241});
  }
  case TAG_SLitInt: {
    V v_i_2494 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2495 = heff_intShow(v_i_2494);
    V v_t_2496 = heff_intShow(heff_strLength_lent(v_s_2495, 0));
    V v_t_2497 = heff_strAppend(heff_strAppend(v_t_2496, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33)), v_s_2495);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_rest_241})});
  }
  case TAG_SLitFloat: {
    V v_x_2498 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_2499 = heff_floatShow(v_x_2498);
    V v_t_24100 = heff_intShow(heff_strLength_lent(v_s_2499, 0));
    V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35)), v_s_2499);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24101, v_rest_241})});
  }
  case TAG_SLitString: {
    V v_s_24102 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24103 = heff_intShow(heff_strLength_lent(v_s_24102, 0));
    V v_t_24104 = heff_strAppend(heff_strAppend(v_t_24103, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37)), v_s_24102);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24104, v_rest_241})});
  }
  case TAG_SLitBytes: {
    V v_s_24105 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24106 = heff_intShow(heff_strLength_lent(v_s_24105, 0));
    V v_t_24107 = heff_strAppend(heff_strAppend(v_t_24106, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39)), v_s_24105);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, v_rest_241})});
  }
  case TAG_SLitRune: {
    V v_c_24108 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24109 = heff_intShow(v_c_24108);
    V v_t_24110 = heff_intShow(heff_strLength_lent(v_s_24109, 0));
    V v_t_24111 = heff_strAppend(heff_strAppend(v_t_24110, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41)), v_s_24109);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, v_rest_241})});
  }
  case TAG_SLitFixed: {
    V v_w_24112 = heff_field(v_x2_240, 0);
    V v_n_24113 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24114;
    switch (heff_tag_of(v_w_24112)) {
    case TAG_I8: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43);
      break;
    }
    case TAG_I16: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44);
      break;
    }
    case TAG_I32: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45);
      break;
    }
    case TAG_I64: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46);
      break;
    }
    case TAG_U8: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47);
      break;
    }
    case TAG_U16: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48);
      break;
    }
    case TAG_U32: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49);
      break;
    }
    case TAG_U64: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50);
      break;
    }
    case TAG_F32: {
      v_t_24114 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51);
      break;
    }
    default: heff_nomatch(v_w_24112);
    }
    V v_s_24115 = heff_intShow(v_n_24113);
    V v_t_24116 = heff_intShow(heff_strLength_lent(v_s_24115, 0));
    V v_t_24117 = heff_strAppend(heff_strAppend(v_t_24116, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52)), v_s_24115);
    V v_t_24118 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24114, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53), v_t_24118});
  }
  case TAG_SLitFloat32: {
    V v_x_24119 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24120 = heff_floatShow(v_x_24119);
    V v_t_24121 = heff_intShow(heff_strLength_lent(v_s_24120, 0));
    V v_t_24122 = heff_strAppend(heff_strAppend(v_t_24121, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54)), v_s_24120);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24122, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_243 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_243), v_rest_241});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0), v_t_244}));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_x_245, 0));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1)), v_x_245);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_SCode: {
    V v_t_249 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_249); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3), v_t_2410}));
  }
  case TAG_SApp: {
    V v_f_2411 = heff_field(v_x2_240, 0);
    V v_a_2412 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_rest_2413 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2412, v_rest_241));
    V v_t_2414 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_f_2411, v_rest_2413));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4), v_t_2414}));
  }
  case TAG_SLam: {
    V v_t_2415 = heff_field(v_x2_240, 0);
    V v_b_2416 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2424;
    switch (heff_tag_of(v_b_2416)) {
    case TAG_MkAbs: {
      V v_x_2417 = heff_field(v_b_2416, 0);
      V v_e_2418 = heff_field(v_b_2416, 1);
      V v_ru_24b_2416_24MkAbs = heff_take_reuse_n(v_b_2416, 3ULL, 2);
      V v_t_2419 = heff_intShow(heff_strLength_lent(v_x_2417, 0));
      V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5)), v_x_2417);
      V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2418, v_rest_241));
      v_rest_2424 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6), heff_tag_at_n(v_ru_24b_2416_24MkAbs, TAG_Cons, 2, (V[]){v_t_2420, v_t_2421})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2422 = heff_field(v_b_2416, 0);
      heff_take_n(v_b_2416, 1ULL, 1);
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2422, v_rest_241));
      v_rest_2424 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7), v_t_2423});
      break;
    }
    default: heff_nomatch(v_b_2416);
    }
    V v_t_2425 = ({ V a_0 = v_t_2415; V a_1 = v_rest_2424; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8), v_t_2425}));
  }
  case TAG_SCons: {
    V v_d_2426 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_keys_2427 = heff_take_field(v_d_2426, 0);
    V v_values_2428 = heff_get_n(v_d_2426, 2, 3);
    V v_xs_2429 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2427), heff_arrayToList(v_values_2428)));
    V v_i_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2429));
    V v_t_2431 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2036168485x277199920(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9), v_xs_2429, v_rest_241));
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2430), v_t_2431});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10), v_t_2432}));
  }
  case TAG_SProj: {
    V v_e2_2433 = heff_field(v_x2_240, 0);
    V v_l_2434 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2435 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11), heff_hole()});
    V v_u_2436 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2435));
    heff_drop(v_u_2436);
    V v_t_2437 = heff_intShow(heff_strLength_lent(v_l_2434, 0));
    V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12)), v_l_2434);
    V t_0 = v_e2_2433;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_rest_241});
    V t_2 = v_cell_2435;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_STag: {
    V v_t_2439 = heff_field(v_x2_240, 0);
    V v_args_2440 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2441 = heff_intShow(heff_strLength_lent(v_t_2439, 0));
    V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13)), v_t_2439);
    V v_xs_2443 = heff_arrayToList(v_args_2440);
    V v_i_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2443));
    V v_t_2445 = ({ V a_0 = v_xs_2443; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2443); r_; });
    V v_t_2446 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2444), v_t_2445});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2446})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2447);
  }
  case TAG_SMatch: {
    V v_e2_2448 = heff_field(v_x2_240, 0);
    V v_cs_2449 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_keys_2450 = heff_take_field(v_cs_2449, 0);
    V v_values_2451 = heff_get_n(v_cs_2449, 2, 3);
    V v_xs_2452 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2450), heff_arrayToList(v_values_2451)));
    V v_i_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2452));
    V v_t_2454 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s562630124x1981162671(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16), v_xs_2452, v_rest_241));
    V v_rest_2455 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2453), v_t_2454});
    V v_t_2456 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2448, v_rest_2455));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17), v_t_2456}));
  }
  case TAG_SSpecialize: {
    V v_e2_2457 = heff_field(v_x2_240, 0);
    V v_l_2458 = heff_field(v_x2_240, 1);
    V v_v_2459 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2460 = heff_intShow(heff_strLength_lent(v_l_2458, 0));
    V v_t_2461 = heff_strAppend(heff_strAppend(v_t_2460, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18)), v_l_2458);
    V v_t_2462 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2459, v_rest_241));
    V v_rest_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, v_t_2462});
    V v_t_2464 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2457, v_rest_2463));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19), v_t_2464}));
  }
  case TAG_SIs: {
    V v_e2_2465 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20), heff_hole()});
    V v_u_2467 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2466));
    heff_drop(v_u_2467);
    V t_0 = v_e2_2465;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2466;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21), v_rest_241}));
  }
  case TAG_SAbandon: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22), v_rest_241}));
  }
  case TAG_SRec: {
    V v_e2_2468 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2469 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23), heff_hole()});
    V v_u_2470 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2469));
    heff_drop(v_u_2470);
    V t_0 = v_e2_2468;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2469;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_t_2471 = heff_field(v_x2_240, 0);
    V v_b_2472 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2480;
    switch (heff_tag_of(v_b_2472)) {
    case TAG_MkAbs: {
      V v_x_2473 = heff_field(v_b_2472, 0);
      V v_e_2474 = heff_field(v_b_2472, 1);
      V v_ru_24b_2472_24MkAbs = heff_take_reuse_n(v_b_2472, 3ULL, 2);
      V v_t_2475 = heff_intShow(heff_strLength_lent(v_x_2473, 0));
      V v_t_2476 = heff_strAppend(heff_strAppend(v_t_2475, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24)), v_x_2473);
      V v_t_2477 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2474, v_rest_241));
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25), heff_tag_at_n(v_ru_24b_2472_24MkAbs, TAG_Cons, 2, (V[]){v_t_2476, v_t_2477})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2478 = heff_field(v_b_2472, 0);
      heff_take_n(v_b_2472, 1ULL, 1);
      V v_t_2479 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2478, v_rest_241));
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26), v_t_2479});
      break;
    }
    default: heff_nomatch(v_b_2472);
    }
    V v_t_2481 = ({ V a_0 = v_t_2471; V a_1 = v_rest_2480; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2471); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27), v_t_2481}));
  }
  case TAG_SImplicit: {
    V v_x_2482 = heff_field(v_x2_240, 0);
    V v_e2_2483 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2484 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28), heff_hole()});
    V v_u_2485 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2484));
    heff_drop(v_u_2485);
    V v_t_2486 = heff_intShow(heff_strLength_lent(v_x_2482, 0));
    V v_t_2487 = heff_strAppend(heff_strAppend(v_t_2486, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29)), v_x_2482);
    V v_cell_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, heff_hole()});
    V v_u_2489 = heff_setField(v_cell_2484, MK_INT(1LL), heff_dup(v_cell_2488));
    heff_drop(v_u_2489);
    V t_0 = v_e2_2483;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2488;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2490 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2491 = ({ V a_0 = v_x_2490; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x_2490); r_; });
    V v_t_2492 = heff_intShow(heff_strLength_lent(v_s_2491, 0));
    V v_t_2493 = heff_strAppend(heff_strAppend(v_t_2492, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30)), v_s_2491);
    V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2493, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2494);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32), v_rest_241}));
  }
  case TAG_SLitInt: {
    V v_i_2498 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2499 = heff_intShow(v_i_2498);
    V v_t_24100 = heff_intShow(heff_strLength_lent(v_s_2499, 0));
    V v_t_24101 = heff_strAppend(heff_strAppend(v_t_24100, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33)), v_s_2499);
    V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24101, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24102);
  }
  case TAG_SLitFloat: {
    V v_x_24103 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24104 = heff_floatShow(v_x_24103);
    V v_t_24105 = heff_intShow(heff_strLength_lent(v_s_24104, 0));
    V v_t_24106 = heff_strAppend(heff_strAppend(v_t_24105, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35)), v_s_24104);
    V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24107);
  }
  case TAG_SLitString: {
    V v_s_24108 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24109 = heff_intShow(heff_strLength_lent(v_s_24108, 0));
    V v_t_24110 = heff_strAppend(heff_strAppend(v_t_24109, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37)), v_s_24108);
    V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24111);
  }
  case TAG_SLitBytes: {
    V v_s_24112 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24113 = heff_intShow(heff_strLength_lent(v_s_24112, 0));
    V v_t_24114 = heff_strAppend(heff_strAppend(v_t_24113, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39)), v_s_24112);
    V v_t_24115 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24114, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24115);
  }
  case TAG_SLitRune: {
    V v_c_24116 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24117 = heff_intShow(v_c_24116);
    V v_t_24118 = heff_intShow(heff_strLength_lent(v_s_24117, 0));
    V v_t_24119 = heff_strAppend(heff_strAppend(v_t_24118, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41)), v_s_24117);
    V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24119, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24120);
  }
  case TAG_SLitFixed: {
    V v_w_24121 = heff_field(v_x2_240, 0);
    V v_n_24122 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24123;
    switch (heff_tag_of(v_w_24121)) {
    case TAG_I8: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43);
      break;
    }
    case TAG_I16: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44);
      break;
    }
    case TAG_I32: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45);
      break;
    }
    case TAG_I64: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46);
      break;
    }
    case TAG_U8: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47);
      break;
    }
    case TAG_U16: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48);
      break;
    }
    case TAG_U32: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49);
      break;
    }
    case TAG_U64: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50);
      break;
    }
    case TAG_F32: {
      v_t_24123 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51);
      break;
    }
    default: heff_nomatch(v_w_24121);
    }
    V v_s_24124 = heff_intShow(v_n_24122);
    V v_t_24125 = heff_intShow(heff_strLength_lent(v_s_24124, 0));
    V v_t_24126 = heff_strAppend(heff_strAppend(v_t_24125, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52)), v_s_24124);
    V v_t_24127 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24123, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53), v_t_24127}));
  }
  case TAG_SLitFloat32: {
    V v_x_24128 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24129 = heff_floatShow(v_x_24128);
    V v_t_24130 = heff_intShow(heff_strLength_lent(v_s_24129, 0));
    V v_t_24131 = heff_strAppend(heff_strAppend(v_t_24130, ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54)), v_s_24129);
    V v_t_24132 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24131, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24132);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_24cpr_str1, 1, "_");

HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V v_d_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_24cpr_str0), 2)) {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_242), v_z_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_247 = v_field_246;
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_x3_2410 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_j_249}));
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            heff_drop(v_x_248);
            heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_x31_2411 = heff_field(v_x3_2410, 0);
            heff_take_n(v_x3_2410, 1ULL, 1);
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
              V v_t_2414 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkAbs, 2, (V[]){v_x_248, v_x_2412}), v_j_2413});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x3_2410)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
        }
      } else {
        heff_drop(v_d_240);
        heff_drop(v_z_242);
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_24cpr_str1), 2)) {
      V v_x3_2415 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_2415)) {
      case TAG_Nothing: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_x31_2416 = heff_field(v_x3_2415, 0);
        V v_ru_24x3_2415_24Just = heff_take_reuse_n(v_x3_2415, 1ULL, 1);
        switch (heff_tag_of(v_x31_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x31_2416, 0);
          V v_j_2418 = heff_field(v_x31_2416, 1);
          V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_2415_24Just, TAG_AbsConst, 1, (V[]){v_x_2417}), v_j_2418});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2419}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_2416)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_2415)}});
      }
    } else {
      heff_drop(v_d_240);
      return ({ V a_0 = v_z_242; V a_1 = v_z_243; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
    }
  }
}
Clo g_heff_2ebuild_2eserial_2etermOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etermOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eserial_2etermOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2etermOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str1, 1, "n");
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_lam1, 2, 0};
Clo g_heff_2ebuild_2eserial_2edefaultOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2edefaultOf(V v_k_240, V v_x2_241) {
top: ;
  if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str0), 2)) {
    return heff_clo_n(g_heff_2ebuild_2eserial_2edefaultOf_lam0, 2, 1, (V[]){v_k_240});
  } else {
    heff_drop_rec(v_k_240, 2);
    if (heff_strEq_c_lent(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str1), 2)) {
      return ((V)&g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo);
    } else {
      return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2edefaultOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_i_243 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_242, v_i_243}));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_244, 0);
    V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x31_245, 0);
      V v_j_247 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){v_x_246}), v_j_247});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_i_2410 = args[1];
  heff_drop(v_s_249);
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_i_2410});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
}
Clo g_heff_2ebuild_2eserial_2etakeFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeFields_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeFields(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_get_n(v_k_240, 1, 2), v_x_247, v_s_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2412 = v_field_2411;
            switch (heff_tag_of(v_x31_2412)) {
            case TAG_MkPair: {
              V v_x_2413 = heff_field(v_x31_2412, 0);
              V v_j_2414 = heff_field(v_x31_2412, 1);
              heff_take_n(v_x31_2412, 3ULL, 2);
              V v_t_2415 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2413), v_j_2414});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
            }
            default: return heff_nomatch(v_x31_2412);
            }
          } else {
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeFields(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etypeOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eserial_2etypeOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2etypeOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23, 3, "f32");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    HeffT2 v_t_243 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x31_246 = v_field_245;
        switch (heff_tag_of(v_x31_246)) {
        case TAG_MkPair: {
          V v_x_247 = heff_field(v_x31_246, 0);
          V v_j_248 = heff_field(v_x31_246, 1);
          V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
          V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_247}), v_j_248});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
        }
      } else {
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_2410 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x31_2413 = v_field_2412;
          switch (heff_tag_of(v_x31_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x31_2413, 0);
            V v_j_2415 = heff_field(v_x31_2413, 1);
            V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
            V v_t_2416 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2414}), v_j_2415});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
          }
        } else {
          heff_drop(v_field_2412);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2417 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_x31_2420 = v_field_2419;
            switch (heff_tag_of(v_x31_2420)) {
            case TAG_MkPair: {
              V v_x_2421 = heff_field(v_x31_2420, 0);
              V v_j_2422 = heff_field(v_x31_2420, 1);
              V v_ru_24x31_2420_24MkPair = heff_take_reuse_n(v_x31_2420, 3ULL, 2);
              HeffT2 v_t_2423 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2421, v_z_241, v_j_2422));
              {
                V v_field_2425 = v_t_2423.f[1];
                int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                if ((v_tag_2424 == ((int64_t)0ULL))) {
                  V v_x31_2426 = v_field_2425;
                  switch (heff_tag_of(v_x31_2426)) {
                  case TAG_MkPair: {
                    V v_x_2427 = heff_field(v_x31_2426, 0);
                    V v_j_2428 = heff_field(v_x31_2426, 1);
                    heff_take_n(v_x31_2426, 3ULL, 2);
                    V v_t_2429 = heff_tag_at_n(v_ru_24x31_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_x_2427}), v_j_2428});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2429}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2426)}});
                  }
                } else {
                  heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                  heff_drop(v_field_2425);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2420)}});
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2419);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2430 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
          {
            V v_field_2432 = v_t_2430.f[1];
            int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
            if ((v_tag_2431 == ((int64_t)0ULL))) {
              V v_x31_2433 = v_field_2432;
              switch (heff_tag_of(v_x31_2433)) {
              case TAG_MkPair: {
                V v_x_2434 = heff_field(v_x31_2433, 0);
                V v_j_2435 = heff_field(v_x31_2433, 1);
                V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
                HeffT2 v_t_2436 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2434, heff_dup(v_z_241), v_j_2435));
                {
                  V v_field_2438 = v_t_2436.f[1];
                  int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
                  if ((v_tag_2437 == ((int64_t)0ULL))) {
                    V v_x31_2439 = v_field_2438;
                    switch (heff_tag_of(v_x31_2439)) {
                    case TAG_MkPair: {
                      V v_x_2440 = heff_field(v_x31_2439, 0);
                      V v_j_2441 = heff_field(v_x31_2439, 1);
                      V v_ru_24x31_2439_24MkPair = heff_take_reuse_n(v_x31_2439, 3ULL, 2);
                      HeffT2 v_t_2442 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2441));
                      {
                        V v_field_2444 = v_t_2442.f[1];
                        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
                        if ((v_tag_2443 == ((int64_t)0ULL))) {
                          V v_x31_2445 = v_field_2444;
                          switch (heff_tag_of(v_x31_2445)) {
                          case TAG_MkPair: {
                            V v_x_2446 = heff_field(v_x31_2445, 0);
                            V v_j_2447 = heff_field(v_x31_2445, 1);
                            heff_take_n(v_x31_2445, 3ULL, 2);
                            HeffT2 v_t_2448 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2446, v_z_241, v_j_2447));
                            {
                              V v_field_2450 = v_t_2448.f[1];
                              int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
                              if ((v_tag_2449 == ((int64_t)0ULL))) {
                                V v_x31_2451 = v_field_2450;
                                switch (heff_tag_of(v_x31_2451)) {
                                case TAG_MkPair: {
                                  V v_x_2452 = heff_field(v_x31_2451, 0);
                                  V v_j_2453 = heff_field(v_x31_2451, 1);
                                  heff_take_n(v_x31_2451, 3ULL, 2);
                                  V v_t_2454 = heff_tag_at_n(v_ru_24x31_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2439_24MkPair, TAG_SApp, 2, (V[]){v_x_2440, v_x_2452}), v_j_2453});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2454}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_2451)}});
                                }
                              } else {
                                heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                                heff_drop(v_x_2440);
                                heff_drop_cell(v_ru_24x31_2439_24MkPair, 2);
                                heff_drop(v_field_2450);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2445)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                          heff_drop(v_x_2440);
                          heff_drop_cell(v_ru_24x31_2439_24MkPair, 2);
                          heff_drop(v_field_2444);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2439)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                    heff_drop(v_field_2438);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2433)}});
              }
            } else {
              heff_drop(v_z_241);
              heff_drop(v_field_2432);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT2 v_t_2455 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
            {
              V v_field_2457 = v_t_2455.f[1];
              int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
              if ((v_tag_2456 == ((int64_t)0ULL))) {
                V v_x31_2458 = v_field_2457;
                switch (heff_tag_of(v_x31_2458)) {
                case TAG_MkPair: {
                  V v_x_2459 = heff_field(v_x31_2458, 0);
                  V v_j_2460 = heff_field(v_x31_2458, 1);
                  V v_ru_24x31_2458_24MkPair = heff_take_reuse_n(v_x31_2458, 3ULL, 2);
                  HeffT2 v_t_2461 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2459, heff_dup(v_z_241), v_j_2460));
                  {
                    V v_field_2463 = v_t_2461.f[1];
                    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                    if ((v_tag_2462 == ((int64_t)0ULL))) {
                      V v_x31_2464 = v_field_2463;
                      switch (heff_tag_of(v_x31_2464)) {
                      case TAG_MkPair: {
                        V v_x_2465 = heff_field(v_x31_2464, 0);
                        V v_j_2466 = heff_field(v_x31_2464, 1);
                        V v_ru_24x31_2464_24MkPair = heff_take_reuse_n(v_x31_2464, 3ULL, 2);
                        HeffT2 v_t_2467 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2466));
                        {
                          V v_field_2469 = v_t_2467.f[1];
                          int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
                          if ((v_tag_2468 == ((int64_t)0ULL))) {
                            V v_x31_2470 = v_field_2469;
                            switch (heff_tag_of(v_x31_2470)) {
                            case TAG_MkPair: {
                              V v_x_2471 = heff_field(v_x31_2470, 0);
                              V v_j_2472 = heff_field(v_x31_2470, 1);
                              heff_take_n(v_x31_2470, 3ULL, 2);
                              HeffT2 v_t_2473 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_2471; V a_2 = v_z_241; V a_3 = v_j_2472; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2471); r_; });
                              {
                                V v_field_2475 = v_t_2473.f[1];
                                int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
                                if ((v_tag_2474 == ((int64_t)0ULL))) {
                                  V v_x31_2476 = v_field_2475;
                                  switch (heff_tag_of(v_x31_2476)) {
                                  case TAG_MkPair: {
                                    V v_x_2477 = heff_field(v_x31_2476, 0);
                                    V v_j_2478 = heff_field(v_x31_2476, 1);
                                    heff_take_n(v_x31_2476, 3ULL, 2);
                                    V v_t_2479 = heff_tag_at_n(v_ru_24x31_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2464_24MkPair, TAG_SLam, 2, (V[]){v_x_2465, v_x_2477}), v_j_2478});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2479}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2476)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_2458_24MkPair, 2);
                                  heff_drop(v_x_2465);
                                  heff_drop_cell(v_ru_24x31_2464_24MkPair, 2);
                                  heff_drop(v_field_2475);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2470)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop_cell(v_ru_24x31_2458_24MkPair, 2);
                            heff_drop(v_x_2465);
                            heff_drop_cell(v_ru_24x31_2464_24MkPair, 2);
                            heff_drop(v_field_2469);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2464)}});
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop_cell(v_ru_24x31_2458_24MkPair, 2);
                      heff_drop(v_field_2463);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2458)}});
                }
              } else {
                heff_drop(v_z_241);
                heff_drop(v_field_2457);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_2480 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_z_242));
              {
                V v_field_2482 = v_t_2480.f[1];
                int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
                if ((v_tag_2481 == ((int64_t)0ULL))) {
                  V v_x31_2483 = v_field_2482;
                  switch (heff_tag_of(v_x31_2483)) {
                  case TAG_MkPair: {
                    V v_x_2484 = heff_field(v_x31_2483, 0);
                    V v_j_2485 = heff_field(v_x31_2483, 1);
                    V v_ru_24x31_2483_24MkPair = heff_take_reuse_n(v_x31_2483, 3ULL, 2);
                    V v_t_2486 = heff_tag_at_n(v_ru_24x31_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2484}), v_j_2485});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2486}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2483)}});
                  }
                } else {
                  heff_drop(v_field_2482);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                HeffT2 v_t_2487 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                {
                  V v_field_2489 = v_t_2487.f[1];
                  int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
                  if ((v_tag_2488 == ((int64_t)0ULL))) {
                    V v_x31_2490 = v_field_2489;
                    switch (heff_tag_of(v_x31_2490)) {
                    case TAG_MkPair: {
                      V v_x_2491 = heff_field(v_x31_2490, 0);
                      V v_j_2492 = heff_field(v_x31_2490, 1);
                      V v_ru_24x31_2490_24MkPair = heff_take_reuse_n(v_x31_2490, 3ULL, 2);
                      HeffT2 v_t_2493 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2491, heff_dup(v_z_241), v_j_2492));
                      {
                        V v_field_2495 = v_t_2493.f[1];
                        int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
                        if ((v_tag_2494 == ((int64_t)0ULL))) {
                          V v_x31_2496 = v_field_2495;
                          switch (heff_tag_of(v_x31_2496)) {
                          case TAG_MkPair: {
                            V v_x_2497 = heff_field(v_x31_2496, 0);
                            V v_j_2498 = heff_field(v_x31_2496, 1);
                            V v_ru_24x31_2496_24MkPair = heff_take_reuse_n(v_x31_2496, 3ULL, 2);
                            HeffT2 v_t_2499 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_j_2498));
                            {
                              V v_field_24101 = v_t_2499.f[1];
                              int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
                              if ((v_tag_24100 == ((int64_t)0ULL))) {
                                V v_x31_24102 = v_field_24101;
                                switch (heff_tag_of(v_x31_24102)) {
                                case TAG_MkPair: {
                                  V v_x_24103 = heff_field(v_x31_24102, 0);
                                  V v_j_24104 = heff_field(v_x31_24102, 1);
                                  heff_take_n(v_x31_24102, 3ULL, 2);
                                  V v_t_24105 = heff_tag_at_n(v_ru_24x31_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_2496_24MkPair, TAG_SProj, 2, (V[]){v_x_2497, v_x_24103}), v_j_24104});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24105}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24102)}});
                                }
                              } else {
                                heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                                heff_drop(v_x_2497);
                                heff_drop_cell(v_ru_24x31_2496_24MkPair, 2);
                                heff_drop(v_field_24101);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2496)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                          heff_drop(v_field_2495);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2490)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_field_2489);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  HeffT2 v_t_24106 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                  {
                    V v_field_24108 = v_t_24106.f[1];
                    int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
                    if ((v_tag_24107 == ((int64_t)0ULL))) {
                      V v_x31_24109 = v_field_24108;
                      switch (heff_tag_of(v_x31_24109)) {
                      case TAG_MkPair: {
                        V v_x_24110 = heff_field(v_x31_24109, 0);
                        V v_j_24111 = heff_field(v_x31_24109, 1);
                        V v_ru_24x31_24109_24MkPair = heff_take_reuse_n(v_x31_24109, 3ULL, 2);
                        HeffT2 v_t_24112 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_24111));
                        {
                          V v_field_24114 = v_t_24112.f[1];
                          int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
                          if ((v_tag_24113 == ((int64_t)0ULL))) {
                            V v_x31_24115 = v_field_24114;
                            switch (heff_tag_of(v_x31_24115)) {
                            case TAG_MkPair: {
                              V v_x_24116 = heff_field(v_x31_24115, 0);
                              V v_j_24117 = heff_field(v_x31_24115, 1);
                              V v_ru_24x31_24115_24MkPair = heff_take_reuse_n(v_x31_24115, 3ULL, 2);
                              HeffT2 v_t_24118 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_24116, v_z_241, v_j_24117));
                              {
                                V v_field_24120 = v_t_24118.f[1];
                                int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
                                if ((v_tag_24119 == ((int64_t)0ULL))) {
                                  V v_x31_24121 = v_field_24120;
                                  switch (heff_tag_of(v_x31_24121)) {
                                  case TAG_MkPair: {
                                    V v_x_24122 = heff_field(v_x31_24121, 0);
                                    V v_j_24123 = heff_field(v_x31_24121, 1);
                                    heff_take_n(v_x31_24121, 3ULL, 2);
                                    V v_t_24124 = heff_tag_at_n(v_ru_24x31_24115_24MkPair, TAG_STag, 2, (V[]){v_x_24110, heff_arrayFromList(v_x_24122)});
                                    V v_f_24125 = heff_tag_at_n(v_ru_24x31_24109_24MkPair, TAG_MkPair, 2, (V[]){v_t_24124, v_j_24123});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24125}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24121)}});
                                  }
                                } else {
                                  heff_drop(v_x_24110);
                                  heff_drop_cell(v_ru_24x31_24109_24MkPair, 2);
                                  heff_drop_cell(v_ru_24x31_24115_24MkPair, 2);
                                  heff_drop(v_field_24120);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24115)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_x_24110);
                            heff_drop_cell(v_ru_24x31_24109_24MkPair, 2);
                            heff_drop(v_field_24114);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24109)}});
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop(v_field_24108);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    HeffT2 v_t_24126 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                    {
                      V v_field_24128 = v_t_24126.f[1];
                      int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
                      if ((v_tag_24127 == ((int64_t)0ULL))) {
                        V v_x31_24129 = v_field_24128;
                        switch (heff_tag_of(v_x31_24129)) {
                        case TAG_MkPair: {
                          V v_x_24130 = heff_field(v_x31_24129, 0);
                          V v_j_24131 = heff_field(v_x31_24129, 1);
                          V v_ru_24x31_24129_24MkPair = heff_take_reuse_n(v_x31_24129, 3ULL, 2);
                          HeffT2 v_t_24132 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24130, heff_dup(v_z_241), v_j_24131));
                          {
                            V v_field_24134 = v_t_24132.f[1];
                            int64_t v_tag_24133 = ((int64_t)v_t_24132.f[0]);
                            if ((v_tag_24133 == ((int64_t)0ULL))) {
                              V v_x31_24135 = v_field_24134;
                              switch (heff_tag_of(v_x31_24135)) {
                              case TAG_MkPair: {
                                V v_x_24136 = heff_field(v_x31_24135, 0);
                                V v_j_24137 = heff_field(v_x31_24135, 1);
                                V v_ru_24x31_24135_24MkPair = heff_take_reuse_n(v_x31_24135, 3ULL, 2);
                                V v_s_24138 = v_z_241;
                                V v_i_24139 = v_j_24137;
                                HeffT2 v_t_24140 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_24138, v_i_24139));
                                V v_x3_24156;
                                {
                                  V v_field_24142 = v_t_24140.f[1];
                                  int64_t v_tag_24141 = ((int64_t)v_t_24140.f[0]);
                                  if ((v_tag_24141 == ((int64_t)0ULL))) {
                                    V v_x31_24143 = v_field_24142;
                                    switch (heff_tag_of(v_x31_24143)) {
                                    case TAG_MkPair: {
                                      V v_x_24144 = heff_field(v_x31_24143, 0);
                                      V v_j_24145 = heff_field(v_x31_24143, 1);
                                      V v_ru_24x31_24143_24MkPair = heff_take_reuse_n(v_x31_24143, 3ULL, 2);
                                      HeffT2 v_t_24146 = (g_heff_2ebuild_2edecoder_2etimes_24s1245912748x532029890_24cpr(v_x_24144, v_s_24138, v_j_24145));
                                      {
                                        V v_field_24148 = v_t_24146.f[1];
                                        int64_t v_tag_24147 = ((int64_t)v_t_24146.f[0]);
                                        if ((v_tag_24147 == ((int64_t)0ULL))) {
                                          V v_x31_24149 = v_field_24148;
                                          switch (heff_tag_of(v_x31_24149)) {
                                          case TAG_MkPair: {
                                            V v_x_24150 = heff_field(v_x31_24149, 0);
                                            V v_j_24151 = heff_field(v_x31_24149, 1);
                                            V v_ru_24x31_24149_24MkPair = heff_take_reuse_n(v_x31_24149, 3ULL, 2);
                                            V v_t_24152 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x31_24143_24MkPair, heff_dup(v_x_24150)));
                                            V v_t_24153 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_24150));
                                            V v_t_24154 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x31_24149_24MkPair, v_x_24150));
                                            V v_x_24155 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_24152), v_t_24153, heff_arrayFromList(v_t_24154)});
                                            v_x3_24156 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_24129_24MkPair, TAG_MkPair, 2, (V[]){v_x_24155, v_j_24151})});
                                            break;
                                          }
                                          default: heff_nomatch(v_x31_24149);
                                          }
                                        } else {
                                          heff_drop_cell(v_ru_24x31_24129_24MkPair, 2);
                                          heff_drop_cell(v_ru_24x31_24143_24MkPair, 2);
                                          heff_drop(v_field_24148);
                                          v_x3_24156 = NTAG(TAG_Nothing);
                                        }
                                      }
                                      break;
                                    }
                                    default: heff_nomatch(v_x31_24143);
                                    }
                                  } else {
                                    heff_drop_cell(v_ru_24x31_24129_24MkPair, 2);
                                    heff_drop(v_s_24138);
                                    heff_drop(v_field_24142);
                                    v_x3_24156 = NTAG(TAG_Nothing);
                                  }
                                }
                                switch (heff_tag_of(v_x3_24156)) {
                                case TAG_Nothing: {
                                  heff_drop(v_x_24136);
                                  heff_drop_cell(v_ru_24x31_24135_24MkPair, 2);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                                case TAG_Just: {
                                  V v_x31_24157 = heff_field(v_x3_24156, 0);
                                  heff_take_n(v_x3_24156, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24157)) {
                                  case TAG_MkPair: {
                                    V v_x_24158 = heff_field(v_x31_24157, 0);
                                    V v_j_24159 = heff_field(v_x31_24157, 1);
                                    V v_ru_24x31_24157_24MkPair = heff_take_reuse_n(v_x31_24157, 3ULL, 2);
                                    V v_t_24160 = heff_tag_at_n(v_ru_24x31_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24157_24MkPair, TAG_SMatch, 2, (V[]){v_x_24136, v_x_24158}), v_j_24159});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24160}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24157)}});
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x3_24156)}});
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24135)}});
                              }
                            } else {
                              heff_drop(v_z_241);
                              heff_drop_cell(v_ru_24x31_24129_24MkPair, 2);
                              heff_drop(v_field_24134);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24129)}});
                        }
                      } else {
                        heff_drop(v_z_241);
                        heff_drop(v_field_24128);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      HeffT2 v_t_24161 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                      {
                        V v_field_24163 = v_t_24161.f[1];
                        int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
                        if ((v_tag_24162 == ((int64_t)0ULL))) {
                          V v_x31_24164 = v_field_24163;
                          switch (heff_tag_of(v_x31_24164)) {
                          case TAG_MkPair: {
                            V v_x_24165 = heff_field(v_x31_24164, 0);
                            V v_j_24166 = heff_field(v_x31_24164, 1);
                            V v_ru_24x31_24164_24MkPair = heff_take_reuse_n(v_x31_24164, 3ULL, 2);
                            HeffT2 v_t_24167 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24165, heff_dup(v_z_241), v_j_24166));
                            {
                              V v_field_24169 = v_t_24167.f[1];
                              int64_t v_tag_24168 = ((int64_t)v_t_24167.f[0]);
                              if ((v_tag_24168 == ((int64_t)0ULL))) {
                                V v_x31_24170 = v_field_24169;
                                switch (heff_tag_of(v_x31_24170)) {
                                case TAG_MkPair: {
                                  V v_x_24171 = heff_field(v_x31_24170, 0);
                                  V v_j_24172 = heff_field(v_x31_24170, 1);
                                  heff_take_n(v_x31_24170, 3ULL, 2);
                                  HeffT2 v_t_24173 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_j_24172));
                                  {
                                    V v_field_24175 = v_t_24173.f[1];
                                    int64_t v_tag_24174 = ((int64_t)v_t_24173.f[0]);
                                    if ((v_tag_24174 == ((int64_t)0ULL))) {
                                      V v_x31_24176 = v_field_24175;
                                      switch (heff_tag_of(v_x31_24176)) {
                                      case TAG_MkPair: {
                                        V v_x_24177 = heff_field(v_x31_24176, 0);
                                        V v_j_24178 = heff_field(v_x31_24176, 1);
                                        heff_take_n(v_x31_24176, 3ULL, 2);
                                        HeffT2 v_t_24179 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24178));
                                        {
                                          V v_field_24181 = v_t_24179.f[1];
                                          int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
                                          if ((v_tag_24180 == ((int64_t)0ULL))) {
                                            V v_x31_24182 = v_field_24181;
                                            switch (heff_tag_of(v_x31_24182)) {
                                            case TAG_MkPair: {
                                              V v_x_24183 = heff_field(v_x31_24182, 0);
                                              V v_j_24184 = heff_field(v_x31_24182, 1);
                                              heff_take_n(v_x31_24182, 3ULL, 2);
                                              HeffT2 v_t_24185 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24183, v_z_241, v_j_24184));
                                              {
                                                V v_field_24187 = v_t_24185.f[1];
                                                int64_t v_tag_24186 = ((int64_t)v_t_24185.f[0]);
                                                if ((v_tag_24186 == ((int64_t)0ULL))) {
                                                  V v_x31_24188 = v_field_24187;
                                                  switch (heff_tag_of(v_x31_24188)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24189 = heff_field(v_x31_24188, 0);
                                                    V v_j_24190 = heff_field(v_x31_24188, 1);
                                                    heff_take_n(v_x31_24188, 3ULL, 2);
                                                    V v_t_24191 = heff_tag_at_n(v_ru_24x31_24164_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24171, v_x_24177, v_x_24189}), v_j_24190});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24191}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24188)}});
                                                  }
                                                } else {
                                                  heff_drop_cell(v_ru_24x31_24164_24MkPair, 2);
                                                  heff_drop(v_x_24171);
                                                  heff_drop(v_x_24177);
                                                  heff_drop(v_field_24187);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24182)}});
                                            }
                                          } else {
                                            heff_drop(v_z_241);
                                            heff_drop_cell(v_ru_24x31_24164_24MkPair, 2);
                                            heff_drop(v_x_24171);
                                            heff_drop(v_x_24177);
                                            heff_drop(v_field_24181);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24176)}});
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop_cell(v_ru_24x31_24164_24MkPair, 2);
                                      heff_drop(v_x_24171);
                                      heff_drop(v_field_24175);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24170)}});
                                }
                              } else {
                                heff_drop(v_z_241);
                                heff_drop_cell(v_ru_24x31_24164_24MkPair, 2);
                                heff_drop(v_field_24169);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24164)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop(v_field_24163);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24192 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24194 = v_t_24192.f[1];
                          int64_t v_tag_24193 = ((int64_t)v_t_24192.f[0]);
                          if ((v_tag_24193 == ((int64_t)0ULL))) {
                            V v_x31_24195 = v_field_24194;
                            switch (heff_tag_of(v_x31_24195)) {
                            case TAG_MkPair: {
                              V v_x_24196 = heff_field(v_x31_24195, 0);
                              V v_j_24197 = heff_field(v_x31_24195, 1);
                              V v_ru_24x31_24195_24MkPair = heff_take_reuse_n(v_x31_24195, 3ULL, 2);
                              HeffT2 v_t_24198 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24196, v_z_241, v_j_24197));
                              {
                                V v_field_24200 = v_t_24198.f[1];
                                int64_t v_tag_24199 = ((int64_t)v_t_24198.f[0]);
                                if ((v_tag_24199 == ((int64_t)0ULL))) {
                                  V v_x31_24201 = v_field_24200;
                                  switch (heff_tag_of(v_x31_24201)) {
                                  case TAG_MkPair: {
                                    V v_x_24202 = heff_field(v_x31_24201, 0);
                                    V v_j_24203 = heff_field(v_x31_24201, 1);
                                    heff_take_n(v_x31_24201, 3ULL, 2);
                                    V v_t_24204 = heff_tag_at_n(v_ru_24x31_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){v_x_24202}), v_j_24203});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24204}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24201)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_24195_24MkPair, 2);
                                  heff_drop(v_field_24200);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24195)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24194);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11), 2)) {
                          heff_drop(v_x2_240);
                          heff_drop(v_z_241);
                          V v_t_24205 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_242});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24205}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12), 2)) {
                            heff_drop(v_x2_240);
                            heff_drop(v_z_241);
                            V v_t_24206 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_242});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24206}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13), 2)) {
                              heff_drop(v_x2_240);
                              HeffT2 v_t_24207 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                              {
                                V v_field_24209 = v_t_24207.f[1];
                                int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
                                if ((v_tag_24208 == ((int64_t)0ULL))) {
                                  V v_x31_24210 = v_field_24209;
                                  switch (heff_tag_of(v_x31_24210)) {
                                  case TAG_MkPair: {
                                    V v_x_24211 = heff_field(v_x31_24210, 0);
                                    V v_j_24212 = heff_field(v_x31_24210, 1);
                                    V v_ru_24x31_24210_24MkPair = heff_take_reuse_n(v_x31_24210, 3ULL, 2);
                                    HeffT2 v_t_24213 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24211, v_z_241, v_j_24212));
                                    {
                                      V v_field_24215 = v_t_24213.f[1];
                                      int64_t v_tag_24214 = ((int64_t)v_t_24213.f[0]);
                                      if ((v_tag_24214 == ((int64_t)0ULL))) {
                                        V v_x31_24216 = v_field_24215;
                                        switch (heff_tag_of(v_x31_24216)) {
                                        case TAG_MkPair: {
                                          V v_x_24217 = heff_field(v_x31_24216, 0);
                                          V v_j_24218 = heff_field(v_x31_24216, 1);
                                          heff_take_n(v_x31_24216, 3ULL, 2);
                                          V v_t_24219 = heff_tag_at_n(v_ru_24x31_24210_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRec, 1, (V[]){v_x_24217}), v_j_24218});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24219}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24216)}});
                                        }
                                      } else {
                                        heff_drop_cell(v_ru_24x31_24210_24MkPair, 2);
                                        heff_drop(v_field_24215);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24210)}});
                                  }
                                } else {
                                  heff_drop(v_z_241);
                                  heff_drop(v_field_24209);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14), 2)) {
                                heff_drop(v_x2_240);
                                HeffT2 v_t_24220 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                                {
                                  V v_field_24222 = v_t_24220.f[1];
                                  int64_t v_tag_24221 = ((int64_t)v_t_24220.f[0]);
                                  if ((v_tag_24221 == ((int64_t)0ULL))) {
                                    V v_x31_24223 = v_field_24222;
                                    switch (heff_tag_of(v_x31_24223)) {
                                    case TAG_MkPair: {
                                      V v_x_24224 = heff_field(v_x31_24223, 0);
                                      V v_j_24225 = heff_field(v_x31_24223, 1);
                                      V v_ru_24x31_24223_24MkPair = heff_take_reuse_n(v_x31_24223, 3ULL, 2);
                                      HeffT2 v_t_24226 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24224, heff_dup(v_z_241), v_j_24225));
                                      {
                                        V v_field_24228 = v_t_24226.f[1];
                                        int64_t v_tag_24227 = ((int64_t)v_t_24226.f[0]);
                                        if ((v_tag_24227 == ((int64_t)0ULL))) {
                                          V v_x31_24229 = v_field_24228;
                                          switch (heff_tag_of(v_x31_24229)) {
                                          case TAG_MkPair: {
                                            V v_x_24230 = heff_field(v_x31_24229, 0);
                                            V v_j_24231 = heff_field(v_x31_24229, 1);
                                            V v_ru_24x31_24229_24MkPair = heff_take_reuse_n(v_x31_24229, 3ULL, 2);
                                            HeffT2 v_t_24232 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24231));
                                            {
                                              V v_field_24234 = v_t_24232.f[1];
                                              int64_t v_tag_24233 = ((int64_t)v_t_24232.f[0]);
                                              if ((v_tag_24233 == ((int64_t)0ULL))) {
                                                V v_x31_24235 = v_field_24234;
                                                switch (heff_tag_of(v_x31_24235)) {
                                                case TAG_MkPair: {
                                                  V v_x_24236 = heff_field(v_x31_24235, 0);
                                                  V v_j_24237 = heff_field(v_x31_24235, 1);
                                                  heff_take_n(v_x31_24235, 3ULL, 2);
                                                  HeffT2 v_t_24238 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_24236; V a_2 = v_z_241; V a_3 = v_j_24237; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24236); r_; });
                                                  {
                                                    V v_field_24240 = v_t_24238.f[1];
                                                    int64_t v_tag_24239 = ((int64_t)v_t_24238.f[0]);
                                                    if ((v_tag_24239 == ((int64_t)0ULL))) {
                                                      V v_x31_24241 = v_field_24240;
                                                      switch (heff_tag_of(v_x31_24241)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24242 = heff_field(v_x31_24241, 0);
                                                        V v_j_24243 = heff_field(v_x31_24241, 1);
                                                        heff_take_n(v_x31_24241, 3ULL, 2);
                                                        V v_t_24244 = heff_tag_at_n(v_ru_24x31_24223_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24229_24MkPair, TAG_SFix, 2, (V[]){v_x_24230, v_x_24242}), v_j_24243});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24244}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24241)}});
                                                      }
                                                    } else {
                                                      heff_drop_cell(v_ru_24x31_24223_24MkPair, 2);
                                                      heff_drop(v_x_24230);
                                                      heff_drop_cell(v_ru_24x31_24229_24MkPair, 2);
                                                      heff_drop(v_field_24240);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24235)}});
                                                }
                                              } else {
                                                heff_drop(v_z_241);
                                                heff_drop_cell(v_ru_24x31_24223_24MkPair, 2);
                                                heff_drop(v_x_24230);
                                                heff_drop_cell(v_ru_24x31_24229_24MkPair, 2);
                                                heff_drop(v_field_24234);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24229)}});
                                          }
                                        } else {
                                          heff_drop(v_z_241);
                                          heff_drop_cell(v_ru_24x31_24223_24MkPair, 2);
                                          heff_drop(v_field_24228);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24223)}});
                                    }
                                  } else {
                                    heff_drop(v_z_241);
                                    heff_drop(v_field_24222);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15), 2)) {
                                  heff_drop(v_x2_240);
                                  HeffT2 v_t_24245 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
                                  {
                                    V v_field_24247 = v_t_24245.f[1];
                                    int64_t v_tag_24246 = ((int64_t)v_t_24245.f[0]);
                                    if ((v_tag_24246 == ((int64_t)0ULL))) {
                                      V v_x31_24248 = v_field_24247;
                                      switch (heff_tag_of(v_x31_24248)) {
                                      case TAG_MkPair: {
                                        V v_x_24249 = heff_field(v_x31_24248, 0);
                                        V v_j_24250 = heff_field(v_x31_24248, 1);
                                        V v_ru_24x31_24248_24MkPair = heff_take_reuse_n(v_x31_24248, 3ULL, 2);
                                        HeffT2 v_t_24251 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24250));
                                        {
                                          V v_field_24253 = v_t_24251.f[1];
                                          int64_t v_tag_24252 = ((int64_t)v_t_24251.f[0]);
                                          if ((v_tag_24252 == ((int64_t)0ULL))) {
                                            V v_x31_24254 = v_field_24253;
                                            switch (heff_tag_of(v_x31_24254)) {
                                            case TAG_MkPair: {
                                              V v_x_24255 = heff_field(v_x31_24254, 0);
                                              V v_j_24256 = heff_field(v_x31_24254, 1);
                                              V v_ru_24x31_24254_24MkPair = heff_take_reuse_n(v_x31_24254, 3ULL, 2);
                                              HeffT2 v_t_24257 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24255, v_z_241, v_j_24256));
                                              {
                                                V v_field_24259 = v_t_24257.f[1];
                                                int64_t v_tag_24258 = ((int64_t)v_t_24257.f[0]);
                                                if ((v_tag_24258 == ((int64_t)0ULL))) {
                                                  V v_x31_24260 = v_field_24259;
                                                  switch (heff_tag_of(v_x31_24260)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24261 = heff_field(v_x31_24260, 0);
                                                    V v_j_24262 = heff_field(v_x31_24260, 1);
                                                    heff_take_n(v_x31_24260, 3ULL, 2);
                                                    V v_t_24263 = heff_tag_at_n(v_ru_24x31_24248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x31_24254_24MkPair, TAG_SImplicit, 2, (V[]){v_x_24249, v_x_24261}), v_j_24262});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24263}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24260)}});
                                                  }
                                                } else {
                                                  heff_drop(v_x_24249);
                                                  heff_drop_cell(v_ru_24x31_24248_24MkPair, 2);
                                                  heff_drop_cell(v_ru_24x31_24254_24MkPair, 2);
                                                  heff_drop(v_field_24259);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24254)}});
                                            }
                                          } else {
                                            heff_drop(v_z_241);
                                            heff_drop(v_x_24249);
                                            heff_drop_cell(v_ru_24x31_24248_24MkPair, 2);
                                            heff_drop(v_field_24253);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24248)}});
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop(v_field_24247);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16), 2)) {
                                    heff_drop(v_x2_240);
                                    HeffT2 v_t_24264 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                    {
                                      V v_field_24266 = v_t_24264.f[1];
                                      int64_t v_tag_24265 = ((int64_t)v_t_24264.f[0]);
                                      if ((v_tag_24265 == ((int64_t)0ULL))) {
                                        V v_x31_24267 = v_field_24266;
                                        switch (heff_tag_of(v_x31_24267)) {
                                        case TAG_MkPair: {
                                          V v_x_24268 = heff_field(v_x31_24267, 0);
                                          V v_j_24269 = heff_field(v_x31_24267, 1);
                                          V v_ru_24x31_24267_24MkPair = heff_take_reuse_n(v_x31_24267, 3ULL, 2);
                                          HeffT2 v_t_24270 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2ecompilerTable_get()); V a_1 = v_x_24268; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
                                          {
                                            V v_field_24272 = v_t_24270.f[1];
                                            int64_t v_tag_24271 = ((int64_t)v_t_24270.f[0]);
                                            HeffT2 v_t_24273 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryTable_get()); V a_1 = v_x_24268; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_24268); r_; });
                                            {
                                              V v_field_24275 = v_t_24273.f[1];
                                              int64_t v_tag_24274 = ((int64_t)v_t_24273.f[0]);
                                              if ((v_tag_24274 == ((int64_t)0ULL))) {
                                                heff_drop(v_field_24272);
                                                V v_x_24276 = v_field_24275;
                                                V v_t_24277 = heff_tag_at_n(v_ru_24x31_24267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24276}), v_j_24269});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24277}});
                                              } else {
                                                heff_drop(v_field_24275);
                                                if ((v_tag_24271 == ((int64_t)0ULL))) {
                                                  V v_x_24278 = v_field_24272;
                                                  V v_t_24279 = heff_tag_at_n(v_ru_24x31_24267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24278}), v_j_24269});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24279}});
                                                } else {
                                                  heff_drop(v_j_24269);
                                                  heff_drop_cell(v_ru_24x31_24267_24MkPair, 2);
                                                  heff_drop(v_field_24272);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24267)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24266);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17), 2)) {
                                      heff_drop(v_x2_240);
                                      HeffT2 v_t_24280 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                      {
                                        V v_field_24282 = v_t_24280.f[1];
                                        int64_t v_tag_24281 = ((int64_t)v_t_24280.f[0]);
                                        if ((v_tag_24281 == ((int64_t)0ULL))) {
                                          V v_x31_24283 = v_field_24282;
                                          switch (heff_tag_of(v_x31_24283)) {
                                          case TAG_MkPair: {
                                            V v_x_24284 = heff_field(v_x31_24283, 0);
                                            V v_j_24285 = heff_field(v_x31_24283, 1);
                                            V v_ru_24x31_24283_24MkPair = heff_take_reuse_n(v_x31_24283, 3ULL, 2);
                                            V v_t_24286 = ({ V a_0 = v_x_24284; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24284); r_; });
                                            V v_x_24287 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24286});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24283_24MkPair, TAG_MkPair, 2, (V[]){v_x_24287, v_j_24285})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24283)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24282);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18), 2)) {
                                        heff_drop(v_x2_240);
                                        HeffT2 v_t_24288 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                        {
                                          V v_field_24290 = v_t_24288.f[1];
                                          int64_t v_tag_24289 = ((int64_t)v_t_24288.f[0]);
                                          if ((v_tag_24289 == ((int64_t)0ULL))) {
                                            V v_x31_24291 = v_field_24290;
                                            switch (heff_tag_of(v_x31_24291)) {
                                            case TAG_MkPair: {
                                              V v_x_24292 = heff_field(v_x31_24291, 0);
                                              V v_j_24293 = heff_field(v_x31_24291, 1);
                                              V v_ru_24x31_24291_24MkPair = heff_take_reuse_n(v_x31_24291, 3ULL, 2);
                                              double v_t_24294 = ({ V a_0 = v_x_24292; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24292); r_; });
                                              V v_x_24295 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24294)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24291_24MkPair, TAG_MkPair, 2, (V[]){v_x_24295, v_j_24293})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24291)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24290);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19), 2)) {
                                          heff_drop(v_x2_240);
                                          HeffT2 v_t_24296 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                          {
                                            V v_field_24298 = v_t_24296.f[1];
                                            int64_t v_tag_24297 = ((int64_t)v_t_24296.f[0]);
                                            if ((v_tag_24297 == ((int64_t)0ULL))) {
                                              V v_x31_24299 = v_field_24298;
                                              switch (heff_tag_of(v_x31_24299)) {
                                              case TAG_MkPair: {
                                                V v_x_24300 = heff_field(v_x31_24299, 0);
                                                V v_j_24301 = heff_field(v_x31_24299, 1);
                                                V v_ru_24x31_24299_24MkPair = heff_take_reuse_n(v_x31_24299, 3ULL, 2);
                                                V v_t_24302 = heff_tag_at_n(v_ru_24x31_24299_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24300}), v_j_24301});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24302}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24299)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24298);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20), 2)) {
                                            heff_drop(v_x2_240);
                                            HeffT2 v_t_24303 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                            {
                                              V v_field_24305 = v_t_24303.f[1];
                                              int64_t v_tag_24304 = ((int64_t)v_t_24303.f[0]);
                                              if ((v_tag_24304 == ((int64_t)0ULL))) {
                                                V v_x31_24306 = v_field_24305;
                                                switch (heff_tag_of(v_x31_24306)) {
                                                case TAG_MkPair: {
                                                  V v_x_24307 = heff_field(v_x31_24306, 0);
                                                  V v_j_24308 = heff_field(v_x31_24306, 1);
                                                  V v_ru_24x31_24306_24MkPair = heff_take_reuse_n(v_x31_24306, 3ULL, 2);
                                                  V v_t_24309 = heff_tag_at_n(v_ru_24x31_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24307}), v_j_24308});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24309}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24306)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24305);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21), 2)) {
                                              heff_drop(v_x2_240);
                                              HeffT2 v_t_24310 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                              {
                                                V v_field_24312 = v_t_24310.f[1];
                                                int64_t v_tag_24311 = ((int64_t)v_t_24310.f[0]);
                                                if ((v_tag_24311 == ((int64_t)0ULL))) {
                                                  V v_x31_24313 = v_field_24312;
                                                  switch (heff_tag_of(v_x31_24313)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24314 = heff_field(v_x31_24313, 0);
                                                    V v_j_24315 = heff_field(v_x31_24313, 1);
                                                    V v_ru_24x31_24313_24MkPair = heff_take_reuse_n(v_x31_24313, 3ULL, 2);
                                                    V v_t_24316 = ({ V a_0 = v_x_24314; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24314); r_; });
                                                    V v_x_24317 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24316});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24313_24MkPair, TAG_MkPair, 2, (V[]){v_x_24317, v_j_24315})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24313)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24312);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22), 2)) {
                                                heff_drop(v_x2_240);
                                                HeffT2 v_t_24318 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_241, v_z_242));
                                                {
                                                  V v_field_24320 = v_t_24318.f[1];
                                                  int64_t v_tag_24319 = ((int64_t)v_t_24318.f[0]);
                                                  if ((v_tag_24319 == ((int64_t)0ULL))) {
                                                    V v_x31_24321 = v_field_24320;
                                                    switch (heff_tag_of(v_x31_24321)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24322 = heff_field(v_x31_24321, 0);
                                                      V v_j_24323 = heff_field(v_x31_24321, 1);
                                                      V v_ru_24x31_24321_24MkPair = heff_take_reuse_n(v_x31_24321, 3ULL, 2);
                                                      HeffT2 v_t_24324 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_j_24323));
                                                      {
                                                        V v_field_24326 = v_t_24324.f[1];
                                                        int64_t v_tag_24325 = ((int64_t)v_t_24324.f[0]);
                                                        if ((v_tag_24325 == ((int64_t)0ULL))) {
                                                          V v_x31_24327 = v_field_24326;
                                                          switch (heff_tag_of(v_x31_24327)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24328 = heff_field(v_x31_24327, 0);
                                                            V v_j_24329 = heff_field(v_x31_24327, 1);
                                                            V v_ru_24x31_24327_24MkPair = heff_take_reuse_n(v_x31_24327, 3ULL, 2);
                                                            V v_t_24330 = ({ V a_0 = v_x_24328; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24328); r_; });
                                                            V v_x_24331 = heff_tag_at_n(v_ru_24x31_24327_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24322, v_t_24330});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24321_24MkPair, TAG_MkPair, 2, (V[]){v_x_24331, v_j_24329})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24327)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24322);
                                                          heff_drop_cell(v_ru_24x31_24321_24MkPair, 2);
                                                          heff_drop(v_field_24326);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24321)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_241);
                                                    heff_drop(v_field_24320);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23))) {
                                                  HeffT2 v_t_24332 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                                  {
                                                    V v_field_24334 = v_t_24332.f[1];
                                                    int64_t v_tag_24333 = ((int64_t)v_t_24332.f[0]);
                                                    if ((v_tag_24333 == ((int64_t)0ULL))) {
                                                      V v_x31_24335 = v_field_24334;
                                                      switch (heff_tag_of(v_x31_24335)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24336 = heff_field(v_x31_24335, 0);
                                                        V v_j_24337 = heff_field(v_x31_24335, 1);
                                                        V v_ru_24x31_24335_24MkPair = heff_take_reuse_n(v_x31_24335, 3ULL, 2);
                                                        double v_t_24338 = ({ V a_0 = v_x_24336; double r_ = (g_heff_2esyntax_2esurface_2efloatOfText_w(a_0)); heff_drop(v_x_24336); r_; });
                                                        V v_x_24339 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24338)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24335_24MkPair, TAG_MkPair, 2, (V[]){v_x_24339, v_j_24337})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24335)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24334);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
      {
        V v_field_245 = v_t_243.f[1];
        int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          V v_x31_246 = v_field_245;
          switch (heff_tag_of(v_x31_246)) {
          case TAG_MkPair: {
            V v_x_247 = heff_field(v_x31_246, 0);
            V v_j_248 = heff_field(v_x31_246, 1);
            V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
            HeffT2 v_t_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_247, v_z_241, v_j_248));
            {
              V v_field_2411 = v_t_249.f[1];
              int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
              if ((v_tag_2410 == ((int64_t)0ULL))) {
                V v_x31_2412 = v_field_2411;
                switch (heff_tag_of(v_x31_2412)) {
                case TAG_MkPair: {
                  V v_x_2413 = heff_field(v_x31_2412, 0);
                  V v_j_2414 = heff_field(v_x31_2412, 1);
                  heff_take_n(v_x31_2412, 3ULL, 2);
                  V v_t_2415 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2413}), v_j_2414});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
                }
              } else {
                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                heff_drop(v_field_2411);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
          }
        } else {
          heff_drop(v_z_241);
          heff_drop(v_field_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x31_2419 = v_field_2418;
            switch (heff_tag_of(v_x31_2419)) {
            case TAG_MkPair: {
              V v_x_2420 = heff_field(v_x31_2419, 0);
              V v_j_2421 = heff_field(v_x31_2419, 1);
              V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
              HeffT2 v_t_2422 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2421));
              {
                V v_field_2424 = v_t_2422.f[1];
                int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
                if ((v_tag_2423 == ((int64_t)0ULL))) {
                  V v_x31_2425 = v_field_2424;
                  switch (heff_tag_of(v_x31_2425)) {
                  case TAG_MkPair: {
                    V v_x_2426 = heff_field(v_x31_2425, 0);
                    V v_j_2427 = heff_field(v_x31_2425, 1);
                    heff_take_n(v_x31_2425, 3ULL, 2);
                    HeffT2 v_t_2428 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2426, heff_dup(v_z_241), v_j_2427));
                    {
                      V v_field_2430 = v_t_2428.f[1];
                      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                      if ((v_tag_2429 == ((int64_t)0ULL))) {
                        V v_x31_2431 = v_field_2430;
                        switch (heff_tag_of(v_x31_2431)) {
                        case TAG_MkPair: {
                          V v_x_2432 = heff_field(v_x31_2431, 0);
                          V v_j_2433 = heff_field(v_x31_2431, 1);
                          heff_take_n(v_x31_2431, 3ULL, 2);
                          HeffT2 v_t_2434 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2433));
                          {
                            V v_field_2436 = v_t_2434.f[1];
                            int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
                            if ((v_tag_2435 == ((int64_t)0ULL))) {
                              V v_x31_2437 = v_field_2436;
                              switch (heff_tag_of(v_x31_2437)) {
                              case TAG_MkPair: {
                                V v_x_2438 = heff_field(v_x31_2437, 0);
                                V v_j_2439 = heff_field(v_x31_2437, 1);
                                heff_take_n(v_x31_2437, 3ULL, 2);
                                HeffT2 v_t_2440 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)); V a_1 = v_x_2438; V a_2 = heff_dup(v_z_241); V a_3 = v_j_2439; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2438); r_; });
                                {
                                  V v_field_2442 = v_t_2440.f[1];
                                  int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                                  if ((v_tag_2441 == ((int64_t)0ULL))) {
                                    V v_x31_2443 = v_field_2442;
                                    switch (heff_tag_of(v_x31_2443)) {
                                    case TAG_MkPair: {
                                      V v_x_2444 = heff_field(v_x31_2443, 0);
                                      V v_j_2445 = heff_field(v_x31_2443, 1);
                                      heff_take_n(v_x31_2443, 3ULL, 2);
                                      HeffT2 v_t_2446 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_241, v_j_2445));
                                      {
                                        V v_field_2448 = v_t_2446.f[1];
                                        int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
                                        if ((v_tag_2447 == ((int64_t)0ULL))) {
                                          V v_x31_2449 = v_field_2448;
                                          switch (heff_tag_of(v_x31_2449)) {
                                          case TAG_MkPair: {
                                            V v_x_2450 = heff_field(v_x31_2449, 0);
                                            V v_j_2451 = heff_field(v_x31_2449, 1);
                                            heff_take_n(v_x31_2449, 3ULL, 2);
                                            V v_s_2452 = v_z_241;
                                            V v_i_2453 = v_j_2451;
                                            HeffT2 v_t_2454 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2452, v_i_2453));
                                            V v_x3_2460;
                                            {
                                              V v_field_2456 = v_t_2454.f[1];
                                              int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                                              if ((v_tag_2455 == ((int64_t)0ULL))) {
                                                V v_x31_2457 = v_field_2456;
                                                switch (heff_tag_of(v_x31_2457)) {
                                                case TAG_MkPair: {
                                                  V v_x_2458 = heff_field(v_x31_2457, 0);
                                                  V v_j_2459 = heff_field(v_x31_2457, 1);
                                                  heff_take_n(v_x31_2457, 3ULL, 2);
                                                  v_x3_2460 = ({ V a_0 = v_x_2458; V a_1 = v_s_2452; V a_2 = v_j_2459; V r_ = (g_heff_2ebuild_2eserial_2edefaultOf_24s397466146x871957558(a_0, a_1, a_2)); heff_drop(v_x_2458); r_; });
                                                  break;
                                                }
                                                default: heff_nomatch(v_x31_2457);
                                                }
                                              } else {
                                                heff_drop(v_s_2452);
                                                heff_drop(v_field_2456);
                                                v_x3_2460 = NTAG(TAG_Nothing);
                                              }
                                            }
                                            switch (heff_tag_of(v_x3_2460)) {
                                            case TAG_Nothing: {
                                              heff_drop(v_x_2420);
                                              heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                                              heff_drop(v_x_2432);
                                              heff_drop(v_x_2444);
                                              heff_drop(v_x_2450);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                            case TAG_Just: {
                                              V v_x31_2461 = heff_field(v_x3_2460, 0);
                                              heff_take_n(v_x3_2460, 1ULL, 1);
                                              switch (heff_tag_of(v_x31_2461)) {
                                              case TAG_MkPair: {
                                                V v_x_2462 = heff_field(v_x31_2461, 0);
                                                V v_j_2463 = heff_field(v_x31_2461, 1);
                                                heff_take_n(v_x31_2461, 3ULL, 2);
                                                V v_t_2464 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2420, v_x_2432, v_x_2444, v_x_2450, v_x_2462}), v_j_2463});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2464}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_2461)}});
                                              }
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x3_2460)}});
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_2449)}});
                                          }
                                        } else {
                                          heff_drop(v_z_241);
                                          heff_drop(v_x_2420);
                                          heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                                          heff_drop(v_x_2432);
                                          heff_drop(v_x_2444);
                                          heff_drop(v_field_2448);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_2443)}});
                                    }
                                  } else {
                                    heff_drop(v_z_241);
                                    heff_drop(v_x_2420);
                                    heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                                    heff_drop(v_x_2432);
                                    heff_drop(v_field_2442);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2437)}});
                              }
                            } else {
                              heff_drop(v_z_241);
                              heff_drop(v_x_2420);
                              heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                              heff_drop(v_x_2432);
                              heff_drop(v_field_2436);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2431)}});
                        }
                      } else {
                        heff_drop(v_z_241);
                        heff_drop(v_x_2420);
                        heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                        heff_drop(v_field_2430);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2425)}});
                  }
                } else {
                  heff_drop(v_z_241);
                  heff_drop(v_x_2420);
                  heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                  heff_drop(v_field_2424);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2418);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2465 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
          {
            V v_field_2467 = v_t_2465.f[1];
            int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
            if ((v_tag_2466 == ((int64_t)0ULL))) {
              V v_x31_2468 = v_field_2467;
              switch (heff_tag_of(v_x31_2468)) {
              case TAG_MkPair: {
                V v_x_2469 = heff_field(v_x31_2468, 0);
                V v_j_2470 = heff_field(v_x31_2468, 1);
                V v_ru_24x31_2468_24MkPair = heff_take_reuse_n(v_x31_2468, 3ULL, 2);
                HeffT2 v_t_2471 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), heff_dup(v_z_241), v_j_2470));
                {
                  V v_field_2473 = v_t_2471.f[1];
                  int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
                  if ((v_tag_2472 == ((int64_t)0ULL))) {
                    V v_x31_2474 = v_field_2473;
                    switch (heff_tag_of(v_x31_2474)) {
                    case TAG_MkPair: {
                      V v_x_2475 = heff_field(v_x31_2474, 0);
                      V v_j_2476 = heff_field(v_x31_2474, 1);
                      heff_take_n(v_x31_2474, 3ULL, 2);
                      HeffT2 v_t_2477 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_j_2476));
                      {
                        V v_field_2479 = v_t_2477.f[1];
                        int64_t v_tag_2478 = ((int64_t)v_t_2477.f[0]);
                        if ((v_tag_2478 == ((int64_t)0ULL))) {
                          V v_x31_2480 = v_field_2479;
                          switch (heff_tag_of(v_x31_2480)) {
                          case TAG_MkPair: {
                            V v_x_2481 = heff_field(v_x31_2480, 0);
                            V v_j_2482 = heff_field(v_x31_2480, 1);
                            heff_take_n(v_x31_2480, 3ULL, 2);
                            V v_t_2483 = heff_tag_at_n(v_ru_24x31_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2469, v_x_2475, v_x_2481}), v_j_2482});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2483}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2480)}});
                          }
                        } else {
                          heff_drop(v_x_2469);
                          heff_drop_cell(v_ru_24x31_2468_24MkPair, 2);
                          heff_drop(v_x_2475);
                          heff_drop(v_field_2479);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2474)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_x_2469);
                    heff_drop_cell(v_ru_24x31_2468_24MkPair, 2);
                    heff_drop(v_field_2473);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2468)}});
              }
            } else {
              heff_drop(v_z_241);
              heff_drop(v_field_2467);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            V v_s_2484 = v_z_241;
            V v_i_2485 = v_z_242;
            HeffT2 v_t_2486 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2484, v_i_2485));
            V v_x3_24102;
            {
              V v_field_2488 = v_t_2486.f[1];
              int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
              if ((v_tag_2487 == ((int64_t)0ULL))) {
                V v_x31_2489 = v_field_2488;
                switch (heff_tag_of(v_x31_2489)) {
                case TAG_MkPair: {
                  V v_x_2490 = heff_field(v_x31_2489, 0);
                  V v_j_2491 = heff_field(v_x31_2489, 1);
                  V v_ru_24x31_2489_24MkPair = heff_take_reuse_n(v_x31_2489, 3ULL, 2);
                  HeffT2 v_t_2492 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_24cpr(v_x_2490, v_s_2484, v_j_2491));
                  {
                    V v_field_2494 = v_t_2492.f[1];
                    int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                    if ((v_tag_2493 == ((int64_t)0ULL))) {
                      V v_x31_2495 = v_field_2494;
                      switch (heff_tag_of(v_x31_2495)) {
                      case TAG_MkPair: {
                        V v_x_2496 = heff_field(v_x31_2495, 0);
                        V v_j_2497 = heff_field(v_x31_2495, 1);
                        V v_ru_24x31_2495_24MkPair = heff_take_reuse_n(v_x31_2495, 3ULL, 2);
                        V v_t_2498 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x31_2495_24MkPair, heff_dup(v_x_2496)));
                        V v_t_2499 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2496));
                        V v_t_24100 = (g_list_2emap_24s1173914895x100384474(v_x_2496));
                        V v_x_24101 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2498), v_t_2499, heff_arrayFromList(v_t_24100)});
                        v_x3_24102 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2489_24MkPair, TAG_MkPair, 2, (V[]){v_x_24101, v_j_2497})});
                        break;
                      }
                      default: heff_nomatch(v_x31_2495);
                      }
                    } else {
                      heff_drop_cell(v_ru_24x31_2489_24MkPair, 2);
                      heff_drop(v_field_2494);
                      v_x3_24102 = NTAG(TAG_Nothing);
                    }
                  }
                  break;
                }
                default: heff_nomatch(v_x31_2489);
                }
              } else {
                heff_drop(v_s_2484);
                heff_drop(v_field_2488);
                v_x3_24102 = NTAG(TAG_Nothing);
              }
            }
            switch (heff_tag_of(v_x3_24102)) {
            case TAG_Nothing: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_x31_24103 = heff_field(v_x3_24102, 0);
              V v_ru_24x3_24102_24Just = heff_take_reuse_n(v_x3_24102, 1ULL, 1);
              switch (heff_tag_of(v_x31_24103)) {
              case TAG_MkPair: {
                V v_x_24104 = heff_field(v_x31_24103, 0);
                V v_j_24105 = heff_field(v_x31_24103, 1);
                V v_ru_24x31_24103_24MkPair = heff_take_reuse_n(v_x31_24103, 3ULL, 2);
                V v_t_24106 = heff_tag_at_n(v_ru_24x31_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_24102_24Just, TAG_SSum, 1, (V[]){v_x_24104}), v_j_24105});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24106}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_24103)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x3_24102)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_24107 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
              {
                V v_field_24109 = v_t_24107.f[1];
                int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
                if ((v_tag_24108 == ((int64_t)0ULL))) {
                  V v_x31_24110 = v_field_24109;
                  switch (heff_tag_of(v_x31_24110)) {
                  case TAG_MkPair: {
                    V v_x_24111 = heff_field(v_x31_24110, 0);
                    V v_j_24112 = heff_field(v_x31_24110, 1);
                    V v_ru_24x31_24110_24MkPair = heff_take_reuse_n(v_x31_24110, 3ULL, 2);
                    HeffT2 v_t_24113 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24111, v_z_241, v_j_24112));
                    {
                      V v_field_24115 = v_t_24113.f[1];
                      int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
                      if ((v_tag_24114 == ((int64_t)0ULL))) {
                        V v_x31_24116 = v_field_24115;
                        switch (heff_tag_of(v_x31_24116)) {
                        case TAG_MkPair: {
                          V v_x_24117 = heff_field(v_x31_24116, 0);
                          V v_j_24118 = heff_field(v_x31_24116, 1);
                          heff_take_n(v_x31_24116, 3ULL, 2);
                          V v_t_24119 = heff_tag_at_n(v_ru_24x31_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_24117}), v_j_24118});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24119}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24116)}});
                        }
                      } else {
                        heff_drop_cell(v_ru_24x31_24110_24MkPair, 2);
                        heff_drop(v_field_24115);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_24110)}});
                  }
                } else {
                  heff_drop(v_z_241);
                  heff_drop(v_field_24109);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                heff_drop(v_z_241);
                V v_t_24120 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_242});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24120}});
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  heff_drop(v_z_241);
                  V v_t_24121 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_242});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24121}});
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    heff_drop(v_z_241);
                    V v_t_24122 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_242});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24122}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      heff_drop(v_z_241);
                      V v_t_24123 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_242});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24123}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24124 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24126 = v_t_24124.f[1];
                          int64_t v_tag_24125 = ((int64_t)v_t_24124.f[0]);
                          if ((v_tag_24125 == ((int64_t)0ULL))) {
                            V v_x31_24127 = v_field_24126;
                            switch (heff_tag_of(v_x31_24127)) {
                            case TAG_MkPair: {
                              V v_x_24128 = heff_field(v_x31_24127, 0);
                              V v_j_24129 = heff_field(v_x31_24127, 1);
                              V v_ru_24x31_24127_24MkPair = heff_take_reuse_n(v_x31_24127, 3ULL, 2);
                              HeffT2 v_t_24130 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24128, v_z_241, v_j_24129));
                              {
                                V v_field_24132 = v_t_24130.f[1];
                                int64_t v_tag_24131 = ((int64_t)v_t_24130.f[0]);
                                if ((v_tag_24131 == ((int64_t)0ULL))) {
                                  V v_x31_24133 = v_field_24132;
                                  switch (heff_tag_of(v_x31_24133)) {
                                  case TAG_MkPair: {
                                    V v_x_24134 = heff_field(v_x31_24133, 0);
                                    V v_j_24135 = heff_field(v_x31_24133, 1);
                                    heff_take_n(v_x31_24133, 3ULL, 2);
                                    V v_t_24136 = heff_tag_at_n(v_ru_24x31_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_24134}), v_j_24135});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24136}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24133)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_24127_24MkPair, 2);
                                  heff_drop(v_field_24132);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24127)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24126);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11))) {
                          HeffT2 v_t_24137 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                          {
                            V v_field_24139 = v_t_24137.f[1];
                            int64_t v_tag_24138 = ((int64_t)v_t_24137.f[0]);
                            if ((v_tag_24138 == ((int64_t)0ULL))) {
                              V v_x31_24140 = v_field_24139;
                              switch (heff_tag_of(v_x31_24140)) {
                              case TAG_MkPair: {
                                V v_x_24141 = heff_field(v_x31_24140, 0);
                                V v_j_24142 = heff_field(v_x31_24140, 1);
                                V v_ru_24x31_24140_24MkPair = heff_take_reuse_n(v_x31_24140, 3ULL, 2);
                                V v_t_24143 = heff_tag_at_n(v_ru_24x31_24140_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_24141}), v_j_24142});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24143}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24140)}});
                              }
                            } else {
                              heff_drop(v_field_24139);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}