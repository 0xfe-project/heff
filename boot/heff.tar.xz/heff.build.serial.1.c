// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define LBL_el 9998
#define LBL_ty 10476
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2eabsOf_24cpr(V, V, V, V);
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eserial_2etakeFixed_24cpr(V, V);
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V, V, V);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength_lent(v_a_246, 0));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      V v_t_2410 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_247, v_a_245));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_rest_245;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2411 = heff_intShow(heff_strLength_lent(v_a_249, 0));
      V v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(v_lit_240, v_a_249));
      V v_t_2419;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_a_2410, 0);
        V v_a_2414 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2415 = heff_arrayToList(v_a_2413);
        V v_a_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2414, v_a_248));
        V v_a_2417 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2415));
        V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(v_lit_243, v_a_2415, v_a_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2417), v_t_2418});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2412, v_t_2419});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ebuild_2eserial_2etermOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etermOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ebuild_2eserial_2etermOf_24cpr(v_k_240, v_x2_241, v_z_242, v_z_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2eserial_2etermOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str24, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str25, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str26, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str27, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str28, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str29, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str31, 0, "");

HeffT2 g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    HeffT2 v_t_243 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2eint_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x31_246 = v_field_245;
        switch (heff_tag_of(v_x31_246)) {
        case TAG_MkPair: {
          V v_x_247 = heff_field(v_x31_246, 0);
          V v_j_248 = heff_field(v_x31_246, 1);
          V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
          V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_247}), v_j_248});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_249}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
        }
      } else {
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_2410 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x31_2413 = v_field_2412;
          switch (heff_tag_of(v_x31_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x31_2413, 0);
            V v_j_2415 = heff_field(v_x31_2413, 1);
            V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
            V v_t_2416 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2414}), v_j_2415});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2416}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_2413)}});
          }
        } else {
          heff_drop(v_field_2412);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2417 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
        {
          V v_field_2419 = v_t_2417.f[1];
          int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
          if ((v_tag_2418 == ((int64_t)0ULL))) {
            V v_x31_2420 = v_field_2419;
            switch (heff_tag_of(v_x31_2420)) {
            case TAG_MkPair: {
              V v_x_2421 = heff_field(v_x31_2420, 0);
              V v_j_2422 = heff_field(v_x31_2420, 1);
              V v_ru_24x31_2420_24MkPair = heff_take_reuse_n(v_x31_2420, 3ULL, 2);
              HeffT2 v_t_2423 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2421, v_z_241, v_j_2422));
              {
                V v_field_2425 = v_t_2423.f[1];
                int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                if ((v_tag_2424 == ((int64_t)0ULL))) {
                  V v_x31_2426 = v_field_2425;
                  switch (heff_tag_of(v_x31_2426)) {
                  case TAG_MkPair: {
                    V v_x_2427 = heff_field(v_x31_2426, 0);
                    V v_j_2428 = heff_field(v_x31_2426, 1);
                    heff_take_n(v_x31_2426, 3ULL, 2);
                    V v_t_2429 = heff_tag_at_n(v_ru_24x31_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_x_2427}), v_j_2428});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2429}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2426)}});
                  }
                } else {
                  heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                  heff_drop(v_field_2425);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2420)}});
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2419);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2430 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
          {
            V v_field_2432 = v_t_2430.f[1];
            int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
            if ((v_tag_2431 == ((int64_t)0ULL))) {
              V v_x31_2433 = v_field_2432;
              switch (heff_tag_of(v_x31_2433)) {
              case TAG_MkPair: {
                V v_x_2434 = heff_field(v_x31_2433, 0);
                V v_j_2435 = heff_field(v_x31_2433, 1);
                V v_ru_24x31_2433_24MkPair = heff_take_reuse_n(v_x31_2433, 3ULL, 2);
                HeffT2 v_t_2436 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2434, heff_dup(v_z_241), v_j_2435));
                {
                  V v_field_2438 = v_t_2436.f[1];
                  int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
                  if ((v_tag_2437 == ((int64_t)0ULL))) {
                    V v_x31_2439 = v_field_2438;
                    switch (heff_tag_of(v_x31_2439)) {
                    case TAG_MkPair: {
                      V v_x_2440 = heff_field(v_x31_2439, 0);
                      V v_j_2441 = heff_field(v_x31_2439, 1);
                      heff_take_n(v_x31_2439, 3ULL, 2);
                      HeffT2 v_t_2442 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2441));
                      {
                        V v_field_2444 = v_t_2442.f[1];
                        int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
                        if ((v_tag_2443 == ((int64_t)0ULL))) {
                          V v_x31_2445 = v_field_2444;
                          switch (heff_tag_of(v_x31_2445)) {
                          case TAG_MkPair: {
                            V v_x_2446 = heff_field(v_x31_2445, 0);
                            V v_j_2447 = heff_field(v_x31_2445, 1);
                            heff_take_n(v_x31_2445, 3ULL, 2);
                            HeffT2 v_t_2448 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2446, v_z_241, v_j_2447));
                            {
                              V v_field_2450 = v_t_2448.f[1];
                              int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
                              if ((v_tag_2449 == ((int64_t)0ULL))) {
                                V v_x31_2451 = v_field_2450;
                                switch (heff_tag_of(v_x31_2451)) {
                                case TAG_MkPair: {
                                  V v_x_2452 = heff_field(v_x31_2451, 0);
                                  V v_j_2453 = heff_field(v_x31_2451, 1);
                                  heff_take_n(v_x31_2451, 3ULL, 2);
                                  V v_t_2454 = heff_tag_at_n(v_ru_24x31_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2440, v_x_2452}), v_j_2453});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2454}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_2451)}});
                                }
                              } else {
                                heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                                heff_drop(v_x_2440);
                                heff_drop(v_field_2450);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2445)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                          heff_drop(v_x_2440);
                          heff_drop(v_field_2444);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2439)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop_cell(v_ru_24x31_2433_24MkPair, 2);
                    heff_drop(v_field_2438);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2433)}});
              }
            } else {
              heff_drop(v_z_241);
              heff_drop(v_field_2432);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT2 v_t_2455 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
            {
              V v_field_2457 = v_t_2455.f[1];
              int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
              if ((v_tag_2456 == ((int64_t)0ULL))) {
                V v_x31_2458 = v_field_2457;
                switch (heff_tag_of(v_x31_2458)) {
                case TAG_MkPair: {
                  V v_x_2459 = heff_field(v_x31_2458, 0);
                  V v_j_2460 = heff_field(v_x31_2458, 1);
                  V v_ru_24x31_2458_24MkPair = heff_take_reuse_n(v_x31_2458, 3ULL, 2);
                  HeffT2 v_t_2461 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2459, heff_dup(v_z_241), v_j_2460));
                  {
                    V v_field_2463 = v_t_2461.f[1];
                    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                    if ((v_tag_2462 == ((int64_t)0ULL))) {
                      V v_x31_2464 = v_field_2463;
                      switch (heff_tag_of(v_x31_2464)) {
                      case TAG_MkPair: {
                        V v_x_2465 = heff_field(v_x31_2464, 0);
                        V v_j_2466 = heff_field(v_x31_2464, 1);
                        heff_take_n(v_x31_2464, 3ULL, 2);
                        HeffT2 v_t_2467 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2466));
                        {
                          V v_field_2469 = v_t_2467.f[1];
                          int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
                          if ((v_tag_2468 == ((int64_t)0ULL))) {
                            V v_x31_2470 = v_field_2469;
                            switch (heff_tag_of(v_x31_2470)) {
                            case TAG_MkPair: {
                              V v_x_2471 = heff_field(v_x31_2470, 0);
                              V v_j_2472 = heff_field(v_x31_2470, 1);
                              heff_take_n(v_x31_2470, 3ULL, 2);
                              HeffT2 v_t_2473 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_2471; V a_2 = v_z_241; V a_3 = v_j_2472; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2471); r_; });
                              {
                                V v_field_2475 = v_t_2473.f[1];
                                int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
                                if ((v_tag_2474 == ((int64_t)0ULL))) {
                                  V v_x31_2476 = v_field_2475;
                                  switch (heff_tag_of(v_x31_2476)) {
                                  case TAG_MkPair: {
                                    V v_x_2477 = heff_field(v_x31_2476, 0);
                                    V v_j_2478 = heff_field(v_x31_2476, 1);
                                    heff_take_n(v_x31_2476, 3ULL, 2);
                                    V v_t_2479 = heff_tag_at_n(v_ru_24x31_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2465, v_x_2477}), v_j_2478});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2479}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2476)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_2458_24MkPair, 2);
                                  heff_drop(v_x_2465);
                                  heff_drop(v_field_2475);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2470)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop_cell(v_ru_24x31_2458_24MkPair, 2);
                            heff_drop(v_x_2465);
                            heff_drop(v_field_2469);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2464)}});
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop_cell(v_ru_24x31_2458_24MkPair, 2);
                      heff_drop(v_field_2463);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2458)}});
                }
              } else {
                heff_drop(v_z_241);
                heff_drop(v_field_2457);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_2480 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_z_242));
              {
                V v_field_2482 = v_t_2480.f[1];
                int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
                if ((v_tag_2481 == ((int64_t)0ULL))) {
                  V v_x31_2483 = v_field_2482;
                  switch (heff_tag_of(v_x31_2483)) {
                  case TAG_MkPair: {
                    V v_x_2484 = heff_field(v_x31_2483, 0);
                    V v_j_2485 = heff_field(v_x31_2483, 1);
                    V v_ru_24x31_2483_24MkPair = heff_take_reuse_n(v_x31_2483, 3ULL, 2);
                    V v_t_2486 = heff_tag_at_n(v_ru_24x31_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2484}), v_j_2485});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2486}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2483)}});
                  }
                } else {
                  heff_drop(v_field_2482);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                HeffT2 v_t_2487 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                {
                  V v_field_2489 = v_t_2487.f[1];
                  int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
                  if ((v_tag_2488 == ((int64_t)0ULL))) {
                    V v_x31_2490 = v_field_2489;
                    switch (heff_tag_of(v_x31_2490)) {
                    case TAG_MkPair: {
                      V v_x_2491 = heff_field(v_x31_2490, 0);
                      V v_j_2492 = heff_field(v_x31_2490, 1);
                      V v_ru_24x31_2490_24MkPair = heff_take_reuse_n(v_x31_2490, 3ULL, 2);
                      HeffT2 v_t_2493 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_2491, heff_dup(v_z_241), v_j_2492));
                      {
                        V v_field_2495 = v_t_2493.f[1];
                        int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
                        if ((v_tag_2494 == ((int64_t)0ULL))) {
                          V v_x31_2496 = v_field_2495;
                          switch (heff_tag_of(v_x31_2496)) {
                          case TAG_MkPair: {
                            V v_x_2497 = heff_field(v_x31_2496, 0);
                            V v_j_2498 = heff_field(v_x31_2496, 1);
                            heff_take_n(v_x31_2496, 3ULL, 2);
                            HeffT2 v_t_2499 = ({ V a_0 = v_z_241; V a_1 = v_j_2498; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                            {
                              V v_field_24101 = v_t_2499.f[1];
                              int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
                              if ((v_tag_24100 == ((int64_t)0ULL))) {
                                V v_x31_24102 = v_field_24101;
                                switch (heff_tag_of(v_x31_24102)) {
                                case TAG_MkPair: {
                                  V v_x_24103 = heff_field(v_x31_24102, 0);
                                  V v_j_24104 = heff_field(v_x31_24102, 1);
                                  heff_take_n(v_x31_24102, 3ULL, 2);
                                  V v_t_24105 = heff_tag_at_n(v_ru_24x31_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2497, v_x_24103}), v_j_24104});
                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24105}});
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24102)}});
                                }
                              } else {
                                heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                                heff_drop(v_x_2497);
                                heff_drop(v_field_24101);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2496)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop_cell(v_ru_24x31_2490_24MkPair, 2);
                          heff_drop(v_field_2495);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2490)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_field_2489);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  HeffT2 v_t_24106 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                  {
                    V v_field_24108 = v_t_24106.f[1];
                    int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
                    if ((v_tag_24107 == ((int64_t)0ULL))) {
                      V v_x31_24109 = v_field_24108;
                      switch (heff_tag_of(v_x31_24109)) {
                      case TAG_MkPair: {
                        V v_x_24110 = heff_field(v_x31_24109, 0);
                        V v_j_24111 = heff_field(v_x31_24109, 1);
                        V v_ru_24x31_24109_24MkPair = heff_take_reuse_n(v_x31_24109, 3ULL, 2);
                        HeffT2 v_t_24112 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_24111));
                        {
                          V v_field_24114 = v_t_24112.f[1];
                          int64_t v_tag_24113 = ((int64_t)v_t_24112.f[0]);
                          if ((v_tag_24113 == ((int64_t)0ULL))) {
                            V v_x31_24115 = v_field_24114;
                            switch (heff_tag_of(v_x31_24115)) {
                            case TAG_MkPair: {
                              V v_x_24116 = heff_field(v_x31_24115, 0);
                              V v_j_24117 = heff_field(v_x31_24115, 1);
                              V v_ru_24x31_24115_24MkPair = heff_take_reuse_n(v_x31_24115, 3ULL, 2);
                              HeffT2 v_t_24118 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_24116, v_z_241, v_j_24117));
                              {
                                V v_field_24120 = v_t_24118.f[1];
                                int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
                                if ((v_tag_24119 == ((int64_t)0ULL))) {
                                  V v_x31_24121 = v_field_24120;
                                  switch (heff_tag_of(v_x31_24121)) {
                                  case TAG_MkPair: {
                                    V v_x_24122 = heff_field(v_x31_24121, 0);
                                    V v_j_24123 = heff_field(v_x31_24121, 1);
                                    heff_take_n(v_x31_24121, 3ULL, 2);
                                    V v_t_24124 = heff_tag_at_n(v_ru_24x31_24115_24MkPair, TAG_STag, 2, (V[]){v_x_24110, heff_arrayFromList(v_x_24122)});
                                    V v_f_24125 = heff_tag_at_n(v_ru_24x31_24109_24MkPair, TAG_MkPair, 2, (V[]){v_t_24124, v_j_24123});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24125}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24121)}});
                                  }
                                } else {
                                  heff_drop(v_x_24110);
                                  heff_drop_cell(v_ru_24x31_24109_24MkPair, 2);
                                  heff_drop_cell(v_ru_24x31_24115_24MkPair, 2);
                                  heff_drop(v_field_24120);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24115)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_x_24110);
                            heff_drop_cell(v_ru_24x31_24109_24MkPair, 2);
                            heff_drop(v_field_24114);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_24109)}});
                      }
                    } else {
                      heff_drop(v_z_241);
                      heff_drop(v_field_24108);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    HeffT2 v_t_24126 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                    {
                      V v_field_24128 = v_t_24126.f[1];
                      int64_t v_tag_24127 = ((int64_t)v_t_24126.f[0]);
                      if ((v_tag_24127 == ((int64_t)0ULL))) {
                        V v_x31_24129 = v_field_24128;
                        switch (heff_tag_of(v_x31_24129)) {
                        case TAG_MkPair: {
                          V v_x_24130 = heff_field(v_x31_24129, 0);
                          V v_j_24131 = heff_field(v_x31_24129, 1);
                          V v_ru_24x31_24129_24MkPair = heff_take_reuse_n(v_x31_24129, 3ULL, 2);
                          HeffT2 v_t_24132 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24130, heff_dup(v_z_241), v_j_24131));
                          {
                            V v_field_24134 = v_t_24132.f[1];
                            int64_t v_tag_24133 = ((int64_t)v_t_24132.f[0]);
                            if ((v_tag_24133 == ((int64_t)0ULL))) {
                              V v_x31_24135 = v_field_24134;
                              switch (heff_tag_of(v_x31_24135)) {
                              case TAG_MkPair: {
                                V v_x_24136 = heff_field(v_x31_24135, 0);
                                V v_j_24137 = heff_field(v_x31_24135, 1);
                                heff_take_n(v_x31_24135, 3ULL, 2);
                                HeffT2 v_t_24138 = (g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_24cpr(v_z_241, v_j_24137));
                                {
                                  V v_field_24140 = v_t_24138.f[1];
                                  int64_t v_tag_24139 = ((int64_t)v_t_24138.f[0]);
                                  if ((v_tag_24139 == ((int64_t)0ULL))) {
                                    V v_x31_24141 = v_field_24140;
                                    switch (heff_tag_of(v_x31_24141)) {
                                    case TAG_MkPair: {
                                      V v_x_24142 = heff_field(v_x31_24141, 0);
                                      V v_j_24143 = heff_field(v_x31_24141, 1);
                                      heff_take_n(v_x31_24141, 3ULL, 2);
                                      V v_t_24144 = heff_tag_at_n(v_ru_24x31_24129_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24136, v_x_24142}), v_j_24143});
                                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24144}});
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24141)}});
                                    }
                                  } else {
                                    heff_drop_cell(v_ru_24x31_24129_24MkPair, 2);
                                    heff_drop(v_x_24136);
                                    heff_drop(v_field_24140);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24135)}});
                              }
                            } else {
                              heff_drop(v_z_241);
                              heff_drop_cell(v_ru_24x31_24129_24MkPair, 2);
                              heff_drop(v_field_24134);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_24129)}});
                        }
                      } else {
                        heff_drop(v_z_241);
                        heff_drop(v_field_24128);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      HeffT2 v_t_24145 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                      {
                        V v_field_24147 = v_t_24145.f[1];
                        int64_t v_tag_24146 = ((int64_t)v_t_24145.f[0]);
                        if ((v_tag_24146 == ((int64_t)0ULL))) {
                          V v_x31_24148 = v_field_24147;
                          switch (heff_tag_of(v_x31_24148)) {
                          case TAG_MkPair: {
                            V v_x_24149 = heff_field(v_x31_24148, 0);
                            V v_j_24150 = heff_field(v_x31_24148, 1);
                            V v_ru_24x31_24148_24MkPair = heff_take_reuse_n(v_x31_24148, 3ULL, 2);
                            HeffT2 v_t_24151 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24149, heff_dup(v_z_241), v_j_24150));
                            {
                              V v_field_24153 = v_t_24151.f[1];
                              int64_t v_tag_24152 = ((int64_t)v_t_24151.f[0]);
                              if ((v_tag_24152 == ((int64_t)0ULL))) {
                                V v_x31_24154 = v_field_24153;
                                switch (heff_tag_of(v_x31_24154)) {
                                case TAG_MkPair: {
                                  V v_x_24155 = heff_field(v_x31_24154, 0);
                                  V v_j_24156 = heff_field(v_x31_24154, 1);
                                  heff_take_n(v_x31_24154, 3ULL, 2);
                                  HeffT2 v_t_24157 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_j_24156));
                                  {
                                    V v_field_24159 = v_t_24157.f[1];
                                    int64_t v_tag_24158 = ((int64_t)v_t_24157.f[0]);
                                    if ((v_tag_24158 == ((int64_t)0ULL))) {
                                      V v_x31_24160 = v_field_24159;
                                      switch (heff_tag_of(v_x31_24160)) {
                                      case TAG_MkPair: {
                                        V v_x_24161 = heff_field(v_x31_24160, 0);
                                        V v_j_24162 = heff_field(v_x31_24160, 1);
                                        heff_take_n(v_x31_24160, 3ULL, 2);
                                        HeffT2 v_t_24163 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24162));
                                        {
                                          V v_field_24165 = v_t_24163.f[1];
                                          int64_t v_tag_24164 = ((int64_t)v_t_24163.f[0]);
                                          if ((v_tag_24164 == ((int64_t)0ULL))) {
                                            V v_x31_24166 = v_field_24165;
                                            switch (heff_tag_of(v_x31_24166)) {
                                            case TAG_MkPair: {
                                              V v_x_24167 = heff_field(v_x31_24166, 0);
                                              V v_j_24168 = heff_field(v_x31_24166, 1);
                                              heff_take_n(v_x31_24166, 3ULL, 2);
                                              HeffT2 v_t_24169 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24167, v_z_241, v_j_24168));
                                              {
                                                V v_field_24171 = v_t_24169.f[1];
                                                int64_t v_tag_24170 = ((int64_t)v_t_24169.f[0]);
                                                if ((v_tag_24170 == ((int64_t)0ULL))) {
                                                  V v_x31_24172 = v_field_24171;
                                                  switch (heff_tag_of(v_x31_24172)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24173 = heff_field(v_x31_24172, 0);
                                                    V v_j_24174 = heff_field(v_x31_24172, 1);
                                                    heff_take_n(v_x31_24172, 3ULL, 2);
                                                    V v_t_24175 = heff_tag_at_n(v_ru_24x31_24148_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24155, v_x_24161, v_x_24173}), v_j_24174});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24175}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24172)}});
                                                  }
                                                } else {
                                                  heff_drop_cell(v_ru_24x31_24148_24MkPair, 2);
                                                  heff_drop(v_x_24155);
                                                  heff_drop(v_x_24161);
                                                  heff_drop(v_field_24171);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24166)}});
                                            }
                                          } else {
                                            heff_drop(v_z_241);
                                            heff_drop_cell(v_ru_24x31_24148_24MkPair, 2);
                                            heff_drop(v_x_24155);
                                            heff_drop(v_x_24161);
                                            heff_drop(v_field_24165);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24160)}});
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop_cell(v_ru_24x31_24148_24MkPair, 2);
                                      heff_drop(v_x_24155);
                                      heff_drop(v_field_24159);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                }
                                default: return ((HeffT2){{heff_nomatch(v_x31_24154)}});
                                }
                              } else {
                                heff_drop(v_z_241);
                                heff_drop_cell(v_ru_24x31_24148_24MkPair, 2);
                                heff_drop(v_field_24153);
                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                              }
                            }
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_24148)}});
                          }
                        } else {
                          heff_drop(v_z_241);
                          heff_drop(v_field_24147);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24176 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24178 = v_t_24176.f[1];
                          int64_t v_tag_24177 = ((int64_t)v_t_24176.f[0]);
                          if ((v_tag_24177 == ((int64_t)0ULL))) {
                            V v_x31_24179 = v_field_24178;
                            switch (heff_tag_of(v_x31_24179)) {
                            case TAG_MkPair: {
                              V v_x_24180 = heff_field(v_x31_24179, 0);
                              V v_j_24181 = heff_field(v_x31_24179, 1);
                              V v_ru_24x31_24179_24MkPair = heff_take_reuse_n(v_x31_24179, 3ULL, 2);
                              HeffT2 v_t_24182 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24180, v_z_241, v_j_24181));
                              {
                                V v_field_24184 = v_t_24182.f[1];
                                int64_t v_tag_24183 = ((int64_t)v_t_24182.f[0]);
                                if ((v_tag_24183 == ((int64_t)0ULL))) {
                                  V v_x31_24185 = v_field_24184;
                                  switch (heff_tag_of(v_x31_24185)) {
                                  case TAG_MkPair: {
                                    V v_x_24186 = heff_field(v_x31_24185, 0);
                                    V v_j_24187 = heff_field(v_x31_24185, 1);
                                    heff_take_n(v_x31_24185, 3ULL, 2);
                                    V v_t_24188 = heff_tag_at_n(v_ru_24x31_24179_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){v_x_24186}), v_j_24187});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24188}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24185)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_24179_24MkPair, 2);
                                  heff_drop(v_field_24184);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24179)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24178);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str11), 2)) {
                          heff_drop(v_x2_240);
                          heff_drop(v_z_241);
                          V v_t_24189 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_242});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24189}});
                        } else {
                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str12), 2)) {
                            heff_drop(v_x2_240);
                            heff_drop(v_z_241);
                            V v_t_24190 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_242});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24190}});
                          } else {
                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str13), 2)) {
                              heff_drop(v_x2_240);
                              HeffT2 v_t_24191 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                              {
                                V v_field_24193 = v_t_24191.f[1];
                                int64_t v_tag_24192 = ((int64_t)v_t_24191.f[0]);
                                if ((v_tag_24192 == ((int64_t)0ULL))) {
                                  V v_x31_24194 = v_field_24193;
                                  switch (heff_tag_of(v_x31_24194)) {
                                  case TAG_MkPair: {
                                    V v_x_24195 = heff_field(v_x31_24194, 0);
                                    V v_j_24196 = heff_field(v_x31_24194, 1);
                                    V v_ru_24x31_24194_24MkPair = heff_take_reuse_n(v_x31_24194, 3ULL, 2);
                                    HeffT2 v_t_24197 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24195, v_z_241, v_j_24196));
                                    {
                                      V v_field_24199 = v_t_24197.f[1];
                                      int64_t v_tag_24198 = ((int64_t)v_t_24197.f[0]);
                                      if ((v_tag_24198 == ((int64_t)0ULL))) {
                                        V v_x31_24200 = v_field_24199;
                                        switch (heff_tag_of(v_x31_24200)) {
                                        case TAG_MkPair: {
                                          V v_x_24201 = heff_field(v_x31_24200, 0);
                                          V v_j_24202 = heff_field(v_x31_24200, 1);
                                          heff_take_n(v_x31_24200, 3ULL, 2);
                                          V v_t_24203 = heff_tag_at_n(v_ru_24x31_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRec, 1, (V[]){v_x_24201}), v_j_24202});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24203}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24200)}});
                                        }
                                      } else {
                                        heff_drop_cell(v_ru_24x31_24194_24MkPair, 2);
                                        heff_drop(v_field_24199);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24194)}});
                                  }
                                } else {
                                  heff_drop(v_z_241);
                                  heff_drop(v_field_24193);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str14), 2)) {
                                heff_drop(v_x2_240);
                                HeffT2 v_t_24204 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                                {
                                  V v_field_24206 = v_t_24204.f[1];
                                  int64_t v_tag_24205 = ((int64_t)v_t_24204.f[0]);
                                  if ((v_tag_24205 == ((int64_t)0ULL))) {
                                    V v_x31_24207 = v_field_24206;
                                    switch (heff_tag_of(v_x31_24207)) {
                                    case TAG_MkPair: {
                                      V v_x_24208 = heff_field(v_x31_24207, 0);
                                      V v_j_24209 = heff_field(v_x31_24207, 1);
                                      V v_ru_24x31_24207_24MkPair = heff_take_reuse_n(v_x31_24207, 3ULL, 2);
                                      HeffT2 v_t_24210 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24208, heff_dup(v_z_241), v_j_24209));
                                      {
                                        V v_field_24212 = v_t_24210.f[1];
                                        int64_t v_tag_24211 = ((int64_t)v_t_24210.f[0]);
                                        if ((v_tag_24211 == ((int64_t)0ULL))) {
                                          V v_x31_24213 = v_field_24212;
                                          switch (heff_tag_of(v_x31_24213)) {
                                          case TAG_MkPair: {
                                            V v_x_24214 = heff_field(v_x31_24213, 0);
                                            V v_j_24215 = heff_field(v_x31_24213, 1);
                                            heff_take_n(v_x31_24213, 3ULL, 2);
                                            HeffT2 v_t_24216 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24215));
                                            {
                                              V v_field_24218 = v_t_24216.f[1];
                                              int64_t v_tag_24217 = ((int64_t)v_t_24216.f[0]);
                                              if ((v_tag_24217 == ((int64_t)0ULL))) {
                                                V v_x31_24219 = v_field_24218;
                                                switch (heff_tag_of(v_x31_24219)) {
                                                case TAG_MkPair: {
                                                  V v_x_24220 = heff_field(v_x31_24219, 0);
                                                  V v_j_24221 = heff_field(v_x31_24219, 1);
                                                  heff_take_n(v_x31_24219, 3ULL, 2);
                                                  HeffT2 v_t_24222 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)); V a_1 = v_x_24220; V a_2 = v_z_241; V a_3 = v_j_24221; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_24220); r_; });
                                                  {
                                                    V v_field_24224 = v_t_24222.f[1];
                                                    int64_t v_tag_24223 = ((int64_t)v_t_24222.f[0]);
                                                    if ((v_tag_24223 == ((int64_t)0ULL))) {
                                                      V v_x31_24225 = v_field_24224;
                                                      switch (heff_tag_of(v_x31_24225)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24226 = heff_field(v_x31_24225, 0);
                                                        V v_j_24227 = heff_field(v_x31_24225, 1);
                                                        heff_take_n(v_x31_24225, 3ULL, 2);
                                                        V v_t_24228 = heff_tag_at_n(v_ru_24x31_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24214, v_x_24226}), v_j_24227});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24228}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24225)}});
                                                      }
                                                    } else {
                                                      heff_drop_cell(v_ru_24x31_24207_24MkPair, 2);
                                                      heff_drop(v_x_24214);
                                                      heff_drop(v_field_24224);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24219)}});
                                                }
                                              } else {
                                                heff_drop(v_z_241);
                                                heff_drop_cell(v_ru_24x31_24207_24MkPair, 2);
                                                heff_drop(v_x_24214);
                                                heff_drop(v_field_24218);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24213)}});
                                          }
                                        } else {
                                          heff_drop(v_z_241);
                                          heff_drop_cell(v_ru_24x31_24207_24MkPair, 2);
                                          heff_drop(v_field_24212);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_24207)}});
                                    }
                                  } else {
                                    heff_drop(v_z_241);
                                    heff_drop(v_field_24206);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              } else {
                                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str15), 2)) {
                                  heff_drop(v_x2_240);
                                  HeffT2 v_t_24229 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
                                  {
                                    V v_field_24231 = v_t_24229.f[1];
                                    int64_t v_tag_24230 = ((int64_t)v_t_24229.f[0]);
                                    if ((v_tag_24230 == ((int64_t)0ULL))) {
                                      V v_x31_24232 = v_field_24231;
                                      switch (heff_tag_of(v_x31_24232)) {
                                      case TAG_MkPair: {
                                        V v_x_24233 = heff_field(v_x31_24232, 0);
                                        V v_j_24234 = heff_field(v_x31_24232, 1);
                                        V v_ru_24x31_24232_24MkPair = heff_take_reuse_n(v_x31_24232, 3ULL, 2);
                                        HeffT2 v_t_24235 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_24234));
                                        {
                                          V v_field_24237 = v_t_24235.f[1];
                                          int64_t v_tag_24236 = ((int64_t)v_t_24235.f[0]);
                                          if ((v_tag_24236 == ((int64_t)0ULL))) {
                                            V v_x31_24238 = v_field_24237;
                                            switch (heff_tag_of(v_x31_24238)) {
                                            case TAG_MkPair: {
                                              V v_x_24239 = heff_field(v_x31_24238, 0);
                                              V v_j_24240 = heff_field(v_x31_24238, 1);
                                              heff_take_n(v_x31_24238, 3ULL, 2);
                                              HeffT2 v_t_24241 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_24239, v_z_241, v_j_24240));
                                              {
                                                V v_field_24243 = v_t_24241.f[1];
                                                int64_t v_tag_24242 = ((int64_t)v_t_24241.f[0]);
                                                if ((v_tag_24242 == ((int64_t)0ULL))) {
                                                  V v_x31_24244 = v_field_24243;
                                                  switch (heff_tag_of(v_x31_24244)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24245 = heff_field(v_x31_24244, 0);
                                                    V v_j_24246 = heff_field(v_x31_24244, 1);
                                                    heff_take_n(v_x31_24244, 3ULL, 2);
                                                    V v_t_24247 = heff_tag_at_n(v_ru_24x31_24232_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24233, v_x_24245}), v_j_24246});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24247}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24244)}});
                                                  }
                                                } else {
                                                  heff_drop(v_x_24233);
                                                  heff_drop_cell(v_ru_24x31_24232_24MkPair, 2);
                                                  heff_drop(v_field_24243);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24238)}});
                                            }
                                          } else {
                                            heff_drop(v_z_241);
                                            heff_drop(v_x_24233);
                                            heff_drop_cell(v_ru_24x31_24232_24MkPair, 2);
                                            heff_drop(v_field_24237);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      }
                                      default: return ((HeffT2){{heff_nomatch(v_x31_24232)}});
                                      }
                                    } else {
                                      heff_drop(v_z_241);
                                      heff_drop(v_field_24231);
                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str16), 2)) {
                                    heff_drop(v_x2_240);
                                    HeffT2 v_t_24248 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                    {
                                      V v_field_24250 = v_t_24248.f[1];
                                      int64_t v_tag_24249 = ((int64_t)v_t_24248.f[0]);
                                      if ((v_tag_24249 == ((int64_t)0ULL))) {
                                        V v_x31_24251 = v_field_24250;
                                        switch (heff_tag_of(v_x31_24251)) {
                                        case TAG_MkPair: {
                                          V v_x_24252 = heff_field(v_x31_24251, 0);
                                          V v_j_24253 = heff_field(v_x31_24251, 1);
                                          V v_ru_24x31_24251_24MkPair = heff_take_reuse_n(v_x31_24251, 3ULL, 2);
                                          V v_t_24254 = heff_tag_at_n(v_ru_24x31_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24252}), v_j_24253});
                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24254}});
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_24251)}});
                                        }
                                      } else {
                                        heff_drop(v_field_24250);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  } else {
                                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str17), 2)) {
                                      heff_drop(v_x2_240);
                                      HeffT2 v_t_24255 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                      {
                                        V v_field_24257 = v_t_24255.f[1];
                                        int64_t v_tag_24256 = ((int64_t)v_t_24255.f[0]);
                                        if ((v_tag_24256 == ((int64_t)0ULL))) {
                                          V v_x31_24258 = v_field_24257;
                                          switch (heff_tag_of(v_x31_24258)) {
                                          case TAG_MkPair: {
                                            V v_x_24259 = heff_field(v_x31_24258, 0);
                                            V v_j_24260 = heff_field(v_x31_24258, 1);
                                            V v_ru_24x31_24258_24MkPair = heff_take_reuse_n(v_x31_24258, 3ULL, 2);
                                            V v_t_24261 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24259); r_; });
                                            V v_x_24262 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24261});
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24258_24MkPair, TAG_MkPair, 2, (V[]){v_x_24262, v_j_24260})}});
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_24258)}});
                                          }
                                        } else {
                                          heff_drop(v_field_24257);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str18), 2)) {
                                        heff_drop(v_x2_240);
                                        HeffT2 v_t_24263 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                        {
                                          V v_field_24265 = v_t_24263.f[1];
                                          int64_t v_tag_24264 = ((int64_t)v_t_24263.f[0]);
                                          if ((v_tag_24264 == ((int64_t)0ULL))) {
                                            V v_x31_24266 = v_field_24265;
                                            switch (heff_tag_of(v_x31_24266)) {
                                            case TAG_MkPair: {
                                              V v_x_24267 = heff_field(v_x31_24266, 0);
                                              V v_j_24268 = heff_field(v_x31_24266, 1);
                                              V v_ru_24x31_24266_24MkPair = heff_take_reuse_n(v_x31_24266, 3ULL, 2);
                                              V v_x2_24269 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str19); V a_1 = v_x_24267; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str20), v_x_24267, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24267); r_; });
                                              V v_t_24272;
                                              switch (heff_tag_of(v_x2_24269)) {
                                              case TAG_Nil: {
                                                v_t_24272 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str21);
                                                break;
                                              }
                                              case TAG_Cons: {
                                                V v_x_24270 = heff_field(v_x2_24269, 0);
                                                V v_xs_24271 = heff_field(v_x2_24269, 1);
                                                heff_take_n(v_x2_24269, 3ULL, 2);
                                                v_t_24272 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str22); V a_1 = v_x_24270; V a_2 = v_xs_24271; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24271); r_; });
                                                break;
                                              }
                                              default: heff_nomatch(v_x2_24269);
                                              }
                                              double v_t_24273 = ({ V a_0 = v_t_24272; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24272); r_; });
                                              V v_x_24274 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24273)});
                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24266_24MkPair, TAG_MkPair, 2, (V[]){v_x_24274, v_j_24268})}});
                                            }
                                            default: return ((HeffT2){{heff_nomatch(v_x31_24266)}});
                                            }
                                          } else {
                                            heff_drop(v_field_24265);
                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                          }
                                        }
                                      } else {
                                        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str23), 2)) {
                                          heff_drop(v_x2_240);
                                          HeffT2 v_t_24275 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                          {
                                            V v_field_24277 = v_t_24275.f[1];
                                            int64_t v_tag_24276 = ((int64_t)v_t_24275.f[0]);
                                            if ((v_tag_24276 == ((int64_t)0ULL))) {
                                              V v_x31_24278 = v_field_24277;
                                              switch (heff_tag_of(v_x31_24278)) {
                                              case TAG_MkPair: {
                                                V v_x_24279 = heff_field(v_x31_24278, 0);
                                                V v_j_24280 = heff_field(v_x31_24278, 1);
                                                V v_ru_24x31_24278_24MkPair = heff_take_reuse_n(v_x31_24278, 3ULL, 2);
                                                V v_t_24281 = heff_tag_at_n(v_ru_24x31_24278_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24279}), v_j_24280});
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24281}});
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_24278)}});
                                              }
                                            } else {
                                              heff_drop(v_field_24277);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str24), 2)) {
                                            heff_drop(v_x2_240);
                                            HeffT2 v_t_24282 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                            {
                                              V v_field_24284 = v_t_24282.f[1];
                                              int64_t v_tag_24283 = ((int64_t)v_t_24282.f[0]);
                                              if ((v_tag_24283 == ((int64_t)0ULL))) {
                                                V v_x31_24285 = v_field_24284;
                                                switch (heff_tag_of(v_x31_24285)) {
                                                case TAG_MkPair: {
                                                  V v_x_24286 = heff_field(v_x31_24285, 0);
                                                  V v_j_24287 = heff_field(v_x31_24285, 1);
                                                  V v_ru_24x31_24285_24MkPair = heff_take_reuse_n(v_x31_24285, 3ULL, 2);
                                                  V v_t_24288 = heff_tag_at_n(v_ru_24x31_24285_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24286}), v_j_24287});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24288}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_24285)}});
                                                }
                                              } else {
                                                heff_drop(v_field_24284);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          } else {
                                            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str25), 2)) {
                                              heff_drop(v_x2_240);
                                              HeffT2 v_t_24289 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                              {
                                                V v_field_24291 = v_t_24289.f[1];
                                                int64_t v_tag_24290 = ((int64_t)v_t_24289.f[0]);
                                                if ((v_tag_24290 == ((int64_t)0ULL))) {
                                                  V v_x31_24292 = v_field_24291;
                                                  switch (heff_tag_of(v_x31_24292)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24293 = heff_field(v_x31_24292, 0);
                                                    V v_j_24294 = heff_field(v_x31_24292, 1);
                                                    V v_ru_24x31_24292_24MkPair = heff_take_reuse_n(v_x31_24292, 3ULL, 2);
                                                    V v_t_24295 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24293); r_; });
                                                    V v_x_24296 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24295});
                                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24292_24MkPair, TAG_MkPair, 2, (V[]){v_x_24296, v_j_24294})}});
                                                  }
                                                  default: return ((HeffT2){{heff_nomatch(v_x31_24292)}});
                                                  }
                                                } else {
                                                  heff_drop(v_field_24291);
                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str26), 2)) {
                                                heff_drop(v_x2_240);
                                                HeffT2 v_t_24297 = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(v_z_241, v_z_242));
                                                {
                                                  V v_field_24299 = v_t_24297.f[1];
                                                  int64_t v_tag_24298 = ((int64_t)v_t_24297.f[0]);
                                                  if ((v_tag_24298 == ((int64_t)0ULL))) {
                                                    V v_x31_24300 = v_field_24299;
                                                    switch (heff_tag_of(v_x31_24300)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24301 = heff_field(v_x31_24300, 0);
                                                      V v_j_24302 = heff_field(v_x31_24300, 1);
                                                      V v_ru_24x31_24300_24MkPair = heff_take_reuse_n(v_x31_24300, 3ULL, 2);
                                                      HeffT2 v_t_24303 = ({ V a_0 = v_z_241; V a_1 = v_j_24302; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                                      {
                                                        V v_field_24305 = v_t_24303.f[1];
                                                        int64_t v_tag_24304 = ((int64_t)v_t_24303.f[0]);
                                                        if ((v_tag_24304 == ((int64_t)0ULL))) {
                                                          V v_x31_24306 = v_field_24305;
                                                          switch (heff_tag_of(v_x31_24306)) {
                                                          case TAG_MkPair: {
                                                            V v_x_24307 = heff_field(v_x31_24306, 0);
                                                            V v_j_24308 = heff_field(v_x31_24306, 1);
                                                            V v_ru_24x31_24306_24MkPair = heff_take_reuse_n(v_x31_24306, 3ULL, 2);
                                                            V v_t_24309 = ({ V a_0 = v_x_24307; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_x_24307); r_; });
                                                            V v_x_24310 = heff_tag_at_n(v_ru_24x31_24306_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24301, v_t_24309});
                                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24300_24MkPair, TAG_MkPair, 2, (V[]){v_x_24310, v_j_24308})}});
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_24306)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_x_24301);
                                                          heff_drop_cell(v_ru_24x31_24300_24MkPair, 2);
                                                          heff_drop(v_field_24305);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_24300)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_z_241);
                                                    heff_drop(v_field_24299);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str27))) {
                                                  HeffT2 v_t_24311 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                                                  {
                                                    V v_field_24313 = v_t_24311.f[1];
                                                    int64_t v_tag_24312 = ((int64_t)v_t_24311.f[0]);
                                                    if ((v_tag_24312 == ((int64_t)0ULL))) {
                                                      V v_x31_24314 = v_field_24313;
                                                      switch (heff_tag_of(v_x31_24314)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24315 = heff_field(v_x31_24314, 0);
                                                        V v_j_24316 = heff_field(v_x31_24314, 1);
                                                        V v_ru_24x31_24314_24MkPair = heff_take_reuse_n(v_x31_24314, 3ULL, 2);
                                                        V v_x2_24317 = ({ V b_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str28); V a_1 = v_x_24315; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str29), v_x_24315, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_x_24315); r_; });
                                                        V v_t_24320;
                                                        switch (heff_tag_of(v_x2_24317)) {
                                                        case TAG_Nil: {
                                                          v_t_24320 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str30);
                                                          break;
                                                        }
                                                        case TAG_Cons: {
                                                          V v_x_24318 = heff_field(v_x2_24317, 0);
                                                          V v_xs_24319 = heff_field(v_x2_24317, 1);
                                                          heff_take_n(v_x2_24317, 3ULL, 2);
                                                          v_t_24320 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr_str31); V a_1 = v_x_24318; V a_2 = v_xs_24319; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24319); r_; });
                                                          break;
                                                        }
                                                        default: heff_nomatch(v_x2_24317);
                                                        }
                                                        double v_t_24321 = ({ V a_0 = v_t_24320; double r_ = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(a_0)); heff_drop(v_t_24320); r_; });
                                                        V v_x_24322 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24321)});
                                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_24314_24MkPair, TAG_MkPair, 2, (V[]){v_x_24322, v_j_24316})}});
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_24314)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_field_24313);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eserial_2etakeFields_24s1394680213x1941859555_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2etimes_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_246, v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              V v_f_2414 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_2412), v_j_2413});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11, 2, "px");

HeffT2 g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str0), 2)) {
    heff_drop(v_x2_240);
    return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
  } else {
    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str1), 2)) {
      heff_drop(v_x2_240);
      HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
      {
        V v_field_245 = v_t_243.f[1];
        int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          V v_x31_246 = v_field_245;
          switch (heff_tag_of(v_x31_246)) {
          case TAG_MkPair: {
            V v_x_247 = heff_field(v_x31_246, 0);
            V v_j_248 = heff_field(v_x31_246, 1);
            V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
            HeffT2 v_t_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_24cpr(v_x_247, v_z_241, v_j_248));
            {
              V v_field_2411 = v_t_249.f[1];
              int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
              if ((v_tag_2410 == ((int64_t)0ULL))) {
                V v_x31_2412 = v_field_2411;
                switch (heff_tag_of(v_x31_2412)) {
                case TAG_MkPair: {
                  V v_x_2413 = heff_field(v_x31_2412, 0);
                  V v_j_2414 = heff_field(v_x31_2412, 1);
                  heff_take_n(v_x31_2412, 3ULL, 2);
                  V v_t_2415 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2413}), v_j_2414});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
                }
              } else {
                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                heff_drop(v_field_2411);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
          }
        } else {
          heff_drop(v_z_241);
          heff_drop(v_field_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str2), 2)) {
        heff_drop(v_x2_240);
        HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_x31_2419 = v_field_2418;
            switch (heff_tag_of(v_x31_2419)) {
            case TAG_MkPair: {
              V v_x_2420 = heff_field(v_x31_2419, 0);
              V v_j_2421 = heff_field(v_x31_2419, 1);
              V v_ru_24x31_2419_24MkPair = heff_take_reuse_n(v_x31_2419, 3ULL, 2);
              HeffT2 v_t_2422 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2421));
              {
                V v_field_2424 = v_t_2422.f[1];
                int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
                if ((v_tag_2423 == ((int64_t)0ULL))) {
                  V v_x31_2425 = v_field_2424;
                  switch (heff_tag_of(v_x31_2425)) {
                  case TAG_MkPair: {
                    V v_x_2426 = heff_field(v_x31_2425, 0);
                    V v_j_2427 = heff_field(v_x31_2425, 1);
                    heff_take_n(v_x31_2425, 3ULL, 2);
                    HeffT2 v_t_2428 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2426, heff_dup(v_z_241), v_j_2427));
                    {
                      V v_field_2430 = v_t_2428.f[1];
                      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
                      if ((v_tag_2429 == ((int64_t)0ULL))) {
                        V v_x31_2431 = v_field_2430;
                        switch (heff_tag_of(v_x31_2431)) {
                        case TAG_MkPair: {
                          V v_x_2432 = heff_field(v_x31_2431, 0);
                          V v_j_2433 = heff_field(v_x31_2431, 1);
                          heff_take_n(v_x31_2431, 3ULL, 2);
                          HeffT2 v_t_2434 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_j_2433));
                          {
                            V v_field_2436 = v_t_2434.f[1];
                            int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
                            if ((v_tag_2435 == ((int64_t)0ULL))) {
                              V v_x31_2437 = v_field_2436;
                              switch (heff_tag_of(v_x31_2437)) {
                              case TAG_MkPair: {
                                V v_x_2438 = heff_field(v_x31_2437, 0);
                                V v_j_2439 = heff_field(v_x31_2437, 1);
                                heff_take_n(v_x31_2437, 3ULL, 2);
                                HeffT2 v_t_2440 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)); V a_1 = v_x_2438; V a_2 = heff_dup(v_z_241); V a_3 = v_j_2439; HeffT2 r_ = (g_heff_2ebuild_2eserial_2eabsOf_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_x_2438); r_; });
                                {
                                  V v_field_2442 = v_t_2440.f[1];
                                  int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                                  if ((v_tag_2441 == ((int64_t)0ULL))) {
                                    V v_x31_2443 = v_field_2442;
                                    switch (heff_tag_of(v_x31_2443)) {
                                    case TAG_MkPair: {
                                      V v_x_2444 = heff_field(v_x31_2443, 0);
                                      V v_j_2445 = heff_field(v_x31_2443, 1);
                                      heff_take_n(v_x31_2443, 3ULL, 2);
                                      HeffT2 v_t_2446 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_24cpr(v_z_241, v_j_2445));
                                      {
                                        V v_field_2448 = v_t_2446.f[1];
                                        int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
                                        if ((v_tag_2447 == ((int64_t)0ULL))) {
                                          V v_x31_2449 = v_field_2448;
                                          switch (heff_tag_of(v_x31_2449)) {
                                          case TAG_MkPair: {
                                            V v_x_2450 = heff_field(v_x31_2449, 0);
                                            V v_j_2451 = heff_field(v_x31_2449, 1);
                                            heff_take_n(v_x31_2449, 3ULL, 2);
                                            HeffT2 v_t_2452 = (g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_24cpr(v_z_241, v_j_2451));
                                            {
                                              V v_field_2454 = v_t_2452.f[1];
                                              int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
                                              if ((v_tag_2453 == ((int64_t)0ULL))) {
                                                V v_x31_2455 = v_field_2454;
                                                switch (heff_tag_of(v_x31_2455)) {
                                                case TAG_MkPair: {
                                                  V v_x_2456 = heff_field(v_x31_2455, 0);
                                                  V v_j_2457 = heff_field(v_x31_2455, 1);
                                                  heff_take_n(v_x31_2455, 3ULL, 2);
                                                  V v_t_2458 = heff_tag_at_n(v_ru_24x31_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2420, v_x_2432, v_x_2444, v_x_2450, v_x_2456}), v_j_2457});
                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2458}});
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_2455)}});
                                                }
                                              } else {
                                                heff_drop(v_x_2420);
                                                heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                                                heff_drop(v_x_2432);
                                                heff_drop(v_x_2444);
                                                heff_drop(v_x_2450);
                                                heff_drop(v_field_2454);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_2449)}});
                                          }
                                        } else {
                                          heff_drop(v_z_241);
                                          heff_drop(v_x_2420);
                                          heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                                          heff_drop(v_x_2432);
                                          heff_drop(v_x_2444);
                                          heff_drop(v_field_2448);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_2443)}});
                                    }
                                  } else {
                                    heff_drop(v_z_241);
                                    heff_drop(v_x_2420);
                                    heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                                    heff_drop(v_x_2432);
                                    heff_drop(v_field_2442);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2437)}});
                              }
                            } else {
                              heff_drop(v_z_241);
                              heff_drop(v_x_2420);
                              heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                              heff_drop(v_x_2432);
                              heff_drop(v_field_2436);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2431)}});
                        }
                      } else {
                        heff_drop(v_z_241);
                        heff_drop(v_x_2420);
                        heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                        heff_drop(v_field_2430);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2425)}});
                  }
                } else {
                  heff_drop(v_z_241);
                  heff_drop(v_x_2420);
                  heff_drop_cell(v_ru_24x31_2419_24MkPair, 2);
                  heff_drop(v_field_2424);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2419)}});
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_field_2418);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str3), 2)) {
          heff_drop(v_x2_240);
          HeffT2 v_t_2459 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_24cpr(v_z_241, v_z_242));
          {
            V v_field_2461 = v_t_2459.f[1];
            int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
            if ((v_tag_2460 == ((int64_t)0ULL))) {
              V v_x31_2462 = v_field_2461;
              switch (heff_tag_of(v_x31_2462)) {
              case TAG_MkPair: {
                V v_x_2463 = heff_field(v_x31_2462, 0);
                V v_j_2464 = heff_field(v_x31_2462, 1);
                V v_ru_24x31_2462_24MkPair = heff_take_reuse_n(v_x31_2462, 3ULL, 2);
                HeffT2 v_t_2465 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), heff_dup(v_z_241), v_j_2464));
                {
                  V v_field_2467 = v_t_2465.f[1];
                  int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                  if ((v_tag_2466 == ((int64_t)0ULL))) {
                    V v_x31_2468 = v_field_2467;
                    switch (heff_tag_of(v_x31_2468)) {
                    case TAG_MkPair: {
                      V v_x_2469 = heff_field(v_x31_2468, 0);
                      V v_j_2470 = heff_field(v_x31_2468, 1);
                      heff_take_n(v_x31_2468, 3ULL, 2);
                      HeffT2 v_t_2471 = (g_heff_2ebuild_2eserial_2etakeDict_24cpr(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_j_2470));
                      {
                        V v_field_2473 = v_t_2471.f[1];
                        int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
                        if ((v_tag_2472 == ((int64_t)0ULL))) {
                          V v_x31_2474 = v_field_2473;
                          switch (heff_tag_of(v_x31_2474)) {
                          case TAG_MkPair: {
                            V v_x_2475 = heff_field(v_x31_2474, 0);
                            V v_j_2476 = heff_field(v_x31_2474, 1);
                            heff_take_n(v_x31_2474, 3ULL, 2);
                            V v_t_2477 = heff_tag_at_n(v_ru_24x31_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2463, v_x_2469, v_x_2475}), v_j_2476});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2477}});
                          }
                          default: return ((HeffT2){{heff_nomatch(v_x31_2474)}});
                          }
                        } else {
                          heff_drop(v_x_2463);
                          heff_drop_cell(v_ru_24x31_2462_24MkPair, 2);
                          heff_drop(v_x_2469);
                          heff_drop(v_field_2473);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2468)}});
                    }
                  } else {
                    heff_drop(v_z_241);
                    heff_drop(v_x_2463);
                    heff_drop_cell(v_ru_24x31_2462_24MkPair, 2);
                    heff_drop(v_field_2467);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2462)}});
              }
            } else {
              heff_drop(v_z_241);
              heff_drop(v_field_2461);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str4), 2)) {
            heff_drop(v_x2_240);
            HeffT2 v_t_2478 = (g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_24cpr(v_z_241, v_z_242));
            {
              V v_field_2480 = v_t_2478.f[1];
              int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
              if ((v_tag_2479 == ((int64_t)0ULL))) {
                V v_x31_2481 = v_field_2480;
                switch (heff_tag_of(v_x31_2481)) {
                case TAG_MkPair: {
                  V v_x_2482 = heff_field(v_x31_2481, 0);
                  V v_j_2483 = heff_field(v_x31_2481, 1);
                  V v_ru_24x31_2481_24MkPair = heff_take_reuse_n(v_x31_2481, 3ULL, 2);
                  V v_t_2484 = heff_tag_at_n(v_ru_24x31_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2482}), v_j_2483});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2484}});
                }
                default: return ((HeffT2){{heff_nomatch(v_x31_2481)}});
                }
              } else {
                heff_drop(v_field_2480);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str5), 2)) {
              heff_drop(v_x2_240);
              HeffT2 v_t_2485 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
              {
                V v_field_2487 = v_t_2485.f[1];
                int64_t v_tag_2486 = ((int64_t)v_t_2485.f[0]);
                if ((v_tag_2486 == ((int64_t)0ULL))) {
                  V v_x31_2488 = v_field_2487;
                  switch (heff_tag_of(v_x31_2488)) {
                  case TAG_MkPair: {
                    V v_x_2489 = heff_field(v_x31_2488, 0);
                    V v_j_2490 = heff_field(v_x31_2488, 1);
                    V v_ru_24x31_2488_24MkPair = heff_take_reuse_n(v_x31_2488, 3ULL, 2);
                    HeffT2 v_t_2491 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_2489, v_z_241, v_j_2490));
                    {
                      V v_field_2493 = v_t_2491.f[1];
                      int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
                      if ((v_tag_2492 == ((int64_t)0ULL))) {
                        V v_x31_2494 = v_field_2493;
                        switch (heff_tag_of(v_x31_2494)) {
                        case TAG_MkPair: {
                          V v_x_2495 = heff_field(v_x31_2494, 0);
                          V v_j_2496 = heff_field(v_x31_2494, 1);
                          heff_take_n(v_x31_2494, 3ULL, 2);
                          V v_t_2497 = heff_tag_at_n(v_ru_24x31_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2495}), v_j_2496});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2497}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2494)}});
                        }
                      } else {
                        heff_drop_cell(v_ru_24x31_2488_24MkPair, 2);
                        heff_drop(v_field_2493);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2488)}});
                  }
                } else {
                  heff_drop(v_z_241);
                  heff_drop(v_field_2487);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            } else {
              if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str6), 2)) {
                heff_drop(v_x2_240);
                heff_drop(v_z_241);
                V v_t_2498 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_242});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2498}});
              } else {
                if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str7), 2)) {
                  heff_drop(v_x2_240);
                  heff_drop(v_z_241);
                  V v_t_2499 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_242});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2499}});
                } else {
                  if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str8), 2)) {
                    heff_drop(v_x2_240);
                    heff_drop(v_z_241);
                    V v_t_24100 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_242});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24100}});
                  } else {
                    if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str9), 2)) {
                      heff_drop(v_x2_240);
                      heff_drop(v_z_241);
                      V v_t_24101 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_242});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24101}});
                    } else {
                      if (heff_strEq_c_lent(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str10), 2)) {
                        heff_drop(v_x2_240);
                        HeffT2 v_t_24102 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_z_241, v_z_242));
                        {
                          V v_field_24104 = v_t_24102.f[1];
                          int64_t v_tag_24103 = ((int64_t)v_t_24102.f[0]);
                          if ((v_tag_24103 == ((int64_t)0ULL))) {
                            V v_x31_24105 = v_field_24104;
                            switch (heff_tag_of(v_x31_24105)) {
                            case TAG_MkPair: {
                              V v_x_24106 = heff_field(v_x31_24105, 0);
                              V v_j_24107 = heff_field(v_x31_24105, 1);
                              V v_ru_24x31_24105_24MkPair = heff_take_reuse_n(v_x31_24105, 3ULL, 2);
                              HeffT2 v_t_24108 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr(v_x_24106, v_z_241, v_j_24107));
                              {
                                V v_field_24110 = v_t_24108.f[1];
                                int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
                                if ((v_tag_24109 == ((int64_t)0ULL))) {
                                  V v_x31_24111 = v_field_24110;
                                  switch (heff_tag_of(v_x31_24111)) {
                                  case TAG_MkPair: {
                                    V v_x_24112 = heff_field(v_x31_24111, 0);
                                    V v_j_24113 = heff_field(v_x31_24111, 1);
                                    heff_take_n(v_x31_24111, 3ULL, 2);
                                    V v_t_24114 = heff_tag_at_n(v_ru_24x31_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_24112}), v_j_24113});
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24114}});
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_24111)}});
                                  }
                                } else {
                                  heff_drop_cell(v_ru_24x31_24105_24MkPair, 2);
                                  heff_drop(v_field_24110);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_24105)}});
                            }
                          } else {
                            heff_drop(v_z_241);
                            heff_drop(v_field_24104);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      } else {
                        if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_24cpr_str11))) {
                          HeffT2 v_t_24115 = ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2eserial_2etakeFixed_24cpr(a_0, a_1)); heff_drop(v_z_241); r_; });
                          {
                            V v_field_24117 = v_t_24115.f[1];
                            int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
                            if ((v_tag_24116 == ((int64_t)0ULL))) {
                              V v_x31_24118 = v_field_24117;
                              switch (heff_tag_of(v_x31_24118)) {
                              case TAG_MkPair: {
                                V v_x_24119 = heff_field(v_x31_24118, 0);
                                V v_j_24120 = heff_field(v_x31_24118, 1);
                                V v_ru_24x31_24118_24MkPair = heff_take_reuse_n(v_x31_24118, 3ULL, 2);
                                V v_t_24121 = heff_tag_at_n(v_ru_24x31_24118_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_24119}), v_j_24120});
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_24121}});
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_24118)}});
                              }
                            } else {
                              heff_drop(v_field_24117);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}