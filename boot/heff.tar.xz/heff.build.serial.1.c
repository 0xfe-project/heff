// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403_clo;
V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2eint(V, V);
V g_heff_2ebuild_2edecoder_2eint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eint_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2etimes(V, V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ebuild_2eserial_2eabsOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2eabsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eabsOf_clo;
V g_heff_2ebuild_2eserial_2edefaultOf(V, V);
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2edefaultOf_clo;
V g_heff_2ebuild_2eserial_2edk_get(void);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V, V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(V, V, V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo;
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo;
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo;
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(V, V, V);
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps_clo;
V g_heff_2ebuild_2eserial_2etakeAlt(V, V, V);
V g_heff_2ebuild_2eserial_2etakeAlt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeAlt_clo;
V g_heff_2ebuild_2eserial_2etakeDict(V, V, V);
V g_heff_2ebuild_2eserial_2etakeDict_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeDict_clo;
V g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819(V, V);
V g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_clo;
V g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826(V, V);
V g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826_clo;
V g_heff_2ebuild_2eserial_2etakeFields(V, V, V);
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFields_clo;
V g_heff_2ebuild_2eserial_2etakeFixed(V, V);
V g_heff_2ebuild_2eserial_2etakeFixed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etakeFixed_clo;
V g_heff_2ebuild_2eserial_2etermOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_clo;
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V, V, V);
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo;
V g_heff_2ebuild_2eserial_2etypeOf(V, V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_clo;
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V, V, V);
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efind_24s1236173780x2048419812(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efind_24s1236173780x2048419812_entry(V self, V *a);
extern Clo g_list_2efind_24s1236173780x2048419812_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      V v_t_2410 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_247, v_a_245));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(V v_lit_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_rest_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_a_245 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(heff_dup(v_lit_240), v_xs_244, v_rest_242));
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 0);
      V v_a_247 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_strLength(heff_dup(v_a_246)));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(v_lit_240, v_a_246));
      V v_t_2410 = ({ V a_0 = v_a_247; V a_1 = v_a_245; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_a_247); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(v_xs_243, v_rest_241));
    HEFF_LAST return g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_x_242, v_t_244);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeListGo_24s1301209160x693500462(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11, 1, "n");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17, 1, "0");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18, 1, "1");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19, 1, "2");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40, 2, "px");
Clo g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SU: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SmallU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str0), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str1), v_rest_241})});
    }
    case TAG_LargeU: {
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str3), v_rest_241})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_SDecode: {
    V v_e_243 = heff_field(v_x2_240, 0);
    V v_t_244 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_e_243), v_rest_241));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str4), v_t_244});
  }
  case TAG_SFunction: {
    V v_level_245 = heff_field(v_x2_240, 0);
    V v_dom_246 = heff_field(v_x2_240, 1);
    V v_cod_247 = heff_field(v_x2_240, 2);
    V v_implicit_248 = heff_field(v_x2_240, 3);
    V v_dflt_249 = heff_field(v_x2_240, 4);
    V v_t_2410;
    switch (heff_tag_of(v_level_245)) {
    case TAG_Small: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str5);
      break;
    }
    case TAG_Large: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str6);
      break;
    }
    case TAG_TopL: {
      v_t_2410 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str7);
      break;
    }
    default: heff_nomatch(v_level_245);
    }
    V v_t_2411;
    switch (heff_tag_of(v_implicit_248)) {
    case TAG_Expl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str8);
      break;
    }
    case TAG_Impl: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str9);
      break;
    }
    case TAG_Inst: {
      v_t_2411 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str10);
      break;
    }
    default: heff_nomatch(v_implicit_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_dflt_249)) {
    case TAG_Nothing: {
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str11), v_rest_241});
      break;
    }
    case TAG_Just: {
      V v_d_2412 = heff_field(v_dflt_249, 0);
      V v_t_2413 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(heff_dup(v_d_2412), v_rest_241));
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str12), v_t_2413});
      break;
    }
    default: heff_nomatch(v_dflt_249);
    }
    V v_rest_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2414});
    V v_rest_2423;
    switch (heff_tag_of(v_cod_247)) {
    case TAG_MkAbs: {
      V v_x_2416 = heff_field(v_cod_247, 0);
      V v_e_2417 = heff_field(v_cod_247, 1);
      V v_t_2418 = heff_intShow(heff_strLength(heff_dup(v_x_2416)));
      V v_t_2419 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str13), heff_dup(v_x_2416)));
      V v_t_2420 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2417, v_rest_2415));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2420})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2421 = heff_field(v_cod_247, 0);
      V v_t_2422 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_e_2421, v_rest_2415));
      v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str15), v_t_2422});
      break;
    }
    default: heff_nomatch(v_cod_247);
    }
    V v_t_2424 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(v_dom_246, v_rest_2423));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str16), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2424})});
  }
  case TAG_SRecord: {
    V v_level_2425 = heff_field(v_x2_240, 0);
    V v_fs_2426 = heff_field(v_x2_240, 1);
    V v_ds_2427 = heff_field(v_x2_240, 2);
    V v_t_2428;
    switch (heff_tag_of(v_level_2425)) {
    case TAG_Small: {
      v_t_2428 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str17);
      break;
    }
    case TAG_Large: {
      v_t_2428 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str18);
      break;
    }
    case TAG_TopL: {
      v_t_2428 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str19);
      break;
    }
    default: heff_nomatch(v_level_2425);
    }
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2427, 0)));
    V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_ds_2427, 2)));
    V v_xs_2431 = (g_heff_2eutil_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_i_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2431));
    V v_t_2433 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str20), v_xs_2431, v_rest_241));
    V v_rest_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2432), v_t_2433});
    V v_t_2435 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2426, 0)));
    V v_t_2436 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2426, 2)));
    V v_xs_2437 = (g_heff_2eutil_2edict_2ezipKV(v_t_2435, v_t_2436));
    V v_i_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2437));
    V v_t_2439 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s782198334x1634023596(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str21), v_xs_2437, v_rest_2434));
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), v_t_2439});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str22), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2440})});
  }
  case TAG_SSum: {
    V v_vs_2441 = heff_field(v_x2_240, 0);
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2441, 0)));
    V v_t_2443 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2441, 2)));
    V v_xs_2444 = (g_heff_2eutil_2edict_2ezipKV(v_t_2442, v_t_2443));
    V v_i_2445 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2444));
    V v_t_2446 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s373909276x1731127212(((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str23), MK_INT(1LL), MK_INT(0LL), v_xs_2444, v_rest_241));
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2445), v_t_2446});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str24), v_t_2447});
  }
  case TAG_SIsTy: {
    V v_t2_2448 = heff_field(v_x2_240, 0);
    V v_cell_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str25), heff_hole()});
    V v_u_2450 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2448, v_rest_241, heff_dup(v_cell_2449)));
    heff_drop(v_u_2450);
    return v_cell_2449;
  }
  case TAG_SPrimInt: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str26), v_rest_241});
  }
  case TAG_SPrimFloat: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str27), v_rest_241});
  }
  case TAG_SPrimString: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str28), v_rest_241});
  }
  case TAG_SPrimRune: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str29), v_rest_241});
  }
  case TAG_SPrimArray: {
    V v_t2_2451 = heff_field(v_x2_240, 0);
    V v_cell_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str30), heff_hole()});
    V v_u_2453 = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_24dps(v_t2_2451, v_rest_241, heff_dup(v_cell_2452)));
    heff_drop(v_u_2453);
    return v_cell_2452;
  }
  case TAG_SFixed: {
    V v_w_2454 = heff_field(v_x2_240, 0);
    V v_t_2455;
    switch (heff_tag_of(v_w_2454)) {
    case TAG_I8: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str31);
      break;
    }
    case TAG_I16: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str32);
      break;
    }
    case TAG_I32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str33);
      break;
    }
    case TAG_I64: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str34);
      break;
    }
    case TAG_U8: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str35);
      break;
    }
    case TAG_U16: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str36);
      break;
    }
    case TAG_U32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str37);
      break;
    }
    case TAG_U64: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str38);
      break;
    }
    case TAG_F32: {
      v_t_2455 = ((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str39);
      break;
    }
    default: heff_nomatch(v_w_2454);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry, 6, 0};

V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244, V v_rest_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    return v_rest_245;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), heff_dup(v_lit_243), v_xs_247, v_rest_245));
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_246, 0);
      V v_a_2410 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24MkPair = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2411 = heff_intShow(heff_strLength(heff_dup(v_a_249)));
      V v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(v_lit_240, v_a_249));
      V v_t_2419;
      switch (heff_tag_of(v_a_2410)) {
      case TAG_MkPair: {
        V v_a_2413 = heff_field(v_a_2410, 0);
        V v_a_2414 = heff_field(v_a_2410, 1);
        heff_take_n(v_a_2410, 3ULL, 2);
        V v_a_2415 = heff_arrayToList(v_a_2413);
        V v_a_2416 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2414, v_a_248));
        V v_a_2417 = (g_list_2efoldl_24s65689923x209800052(v_lit_241, v_lit_242, v_a_2415));
        V v_t_2418 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s1301421868x136053454(v_lit_243, v_a_2415, v_a_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){heff_intShow(v_a_2417), v_t_2418});
        break;
      }
      default: heff_nomatch(v_a_2410);
      }
      return heff_tag_at_n(v_ru_24x_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2412, v_t_2419});
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry, 2, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(V v_x2_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_242), v_rest_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str0), v_t_243});
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_244)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str1), v_x_244));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_rest_241})});
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_247); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str3), v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_x2_240, 0);
    V v_a_2410 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SApp = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2411 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2410, v_rest_241));
    V v_t_2412 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_f_249, v_rest_2411));
    return heff_tag_at_n(v_ru_24x2_240_24SApp, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str4), v_t_2412});
  }
  case TAG_SLam: {
    V v_t_2413 = heff_field(v_x2_240, 0);
    V v_b_2414 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2422;
    switch (heff_tag_of(v_b_2414)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2414, 0);
      V v_e_2416 = heff_field(v_b_2414, 1);
      heff_take_n(v_b_2414, 3ULL, 2);
      V v_t_2417 = heff_intShow(heff_strLength(heff_dup(v_x_2415)));
      V v_t_2418 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str5), v_x_2415));
      V v_t_2419 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2416, v_rest_241));
      v_rest_2422 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str6), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2419})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2420 = heff_field(v_b_2414, 0);
      heff_take_n(v_b_2414, 1ULL, 1);
      V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2420, v_rest_241));
      v_rest_2422 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str7), v_t_2421});
      break;
    }
    default: heff_nomatch(v_b_2414);
    }
    V v_t_2423 = ({ V a_0 = v_t_2413; V a_1 = v_rest_2422; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str8), v_t_2423});
  }
  case TAG_SCons: {
    V v_d_2424 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2425 = heff_arrayToList(heff_take_field(v_d_2424, 0));
    V v_t_2426 = heff_arrayToList(heff_get_n(v_d_2424, 2, 3));
    V v_xs_2427 = (g_heff_2eutil_2edict_2ezipKV(v_t_2425, v_t_2426));
    V v_i_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2427));
    V v_t_2429 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str9), v_xs_2427, v_rest_241));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2428), v_t_2429});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str10), v_t_2430});
  }
  case TAG_SProj: {
    V v_e2_2431 = heff_field(v_x2_240, 0);
    V v_l_2432 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2433 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str11), heff_hole()});
    V v_t_2434 = heff_intShow(heff_strLength(heff_dup(v_l_2432)));
    V v_t_2435 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str12), v_l_2432));
    V v_u_2436 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2431, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_rest_241}), heff_dup(v_cell_2433)));
    heff_drop(v_u_2436);
    return v_cell_2433;
  }
  case TAG_STag: {
    V v_t_2437 = heff_field(v_x2_240, 0);
    V v_as_2438 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439 = heff_intShow(heff_strLength(heff_dup(v_t_2437)));
    V v_t_2440 = heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str13), v_t_2437));
    V v_xs_2441 = heff_arrayToList(v_as_2438);
    V v_i_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2441));
    V v_t_2443 = ({ V a_0 = v_xs_2441; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2441); r_; });
    V v_t_2444 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2442), v_t_2443});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2444})});
  }
  case TAG_SMatch: {
    V v_e2_2445 = heff_field(v_x2_240, 0);
    V v_cs_2446 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2447 = heff_arrayToList(heff_take_field(v_cs_2446, 0));
    V v_t_2448 = heff_arrayToList(heff_get_n(v_cs_2446, 2, 3));
    V v_xs_2449 = (g_heff_2eutil_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_i_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2449));
    V v_t_2451 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str16), v_xs_2449, v_rest_241));
    V v_rest_2452 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2450), v_t_2451});
    V v_t_2453 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2445, v_rest_2452));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str17), v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e2_2454 = heff_field(v_x2_240, 0);
    V v_l_2455 = heff_field(v_x2_240, 1);
    V v_v_2456 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2457 = heff_intShow(heff_strLength(heff_dup(v_l_2455)));
    V v_t_2458 = heff_strAppend(v_t_2457, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str18), v_l_2455));
    V v_t_2459 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2456, v_rest_241));
    V v_rest_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2459});
    V v_t_2461 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2454, v_rest_2460));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str19), v_t_2461});
  }
  case TAG_SIs: {
    V v_e2_2462 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str20), heff_hole()});
    V v_u_2464 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2462, v_rest_241, heff_dup(v_cell_2463)));
    heff_drop(v_u_2464);
    return v_cell_2463;
  }
  case TAG_SOpaque: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str21), v_rest_241});
  }
  case TAG_SAbandon: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str22), v_rest_241});
  }
  case TAG_SRec: {
    V v_e2_2465 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str23), heff_hole()});
    V v_u_2467 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2465, v_rest_241, heff_dup(v_cell_2466)));
    heff_drop(v_u_2467);
    return v_cell_2466;
  }
  case TAG_SFix: {
    V v_t_2468 = heff_field(v_x2_240, 0);
    V v_b_2469 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2477;
    switch (heff_tag_of(v_b_2469)) {
    case TAG_MkAbs: {
      V v_x_2470 = heff_field(v_b_2469, 0);
      V v_e_2471 = heff_field(v_b_2469, 1);
      heff_take_n(v_b_2469, 3ULL, 2);
      V v_t_2472 = heff_intShow(heff_strLength(heff_dup(v_x_2470)));
      V v_t_2473 = heff_strAppend(v_t_2472, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str24), v_x_2470));
      V v_t_2474 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2471, v_rest_241));
      v_rest_2477 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2474})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2475 = heff_field(v_b_2469, 0);
      heff_take_n(v_b_2469, 1ULL, 1);
      V v_t_2476 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2475, v_rest_241));
      v_rest_2477 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str26), v_t_2476});
      break;
    }
    default: heff_nomatch(v_b_2469);
    }
    V v_t_2478 = ({ V a_0 = v_t_2468; V a_1 = v_rest_2477; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2468); r_; });
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str27), v_t_2478});
  }
  case TAG_SImplicit: {
    V v_x_2479 = heff_field(v_x2_240, 0);
    V v_e2_2480 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2481 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str28), heff_hole()});
    V v_t_2482 = heff_intShow(heff_strLength(heff_dup(v_x_2479)));
    V v_t_2483 = heff_strAppend(v_t_2482, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str29), v_x_2479));
    V v_cell_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, heff_hole()});
    V v_u_2485 = heff_setField(heff_dup(v_cell_2481), MK_INT(1LL), heff_dup(v_cell_2484));
    heff_drop(v_u_2485);
    V v_u_2486 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(v_e2_2480, v_rest_241, v_cell_2484));
    heff_drop(v_u_2486);
    return v_cell_2481;
  }
  case TAG_SPrim: {
    V v_x_2487 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2488 = heff_intShow(heff_strLength(heff_dup(v_x_2487)));
    V v_t_2489 = heff_strAppend(v_t_2488, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str30), v_x_2487));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, v_rest_241})});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str32), v_rest_241});
  }
  case TAG_SLitInt: {
    V v_i_2493 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2494 = heff_intShow(v_i_2493);
    V v_t_2495 = heff_intShow(heff_strLength(heff_dup(v_s_2494)));
    V v_t_2496 = heff_strAppend(v_t_2495, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str33), v_s_2494));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2496, v_rest_241})});
  }
  case TAG_SLitFloat: {
    V v_x_2497 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_2498 = heff_floatShow(v_x_2497);
    V v_t_2499 = heff_intShow(heff_strLength(heff_dup(v_s_2498)));
    V v_t_24100 = heff_strAppend(v_t_2499, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str35), v_s_2498));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, v_rest_241})});
  }
  case TAG_SLitString: {
    V v_s_24101 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24102 = heff_intShow(heff_strLength(heff_dup(v_s_24101)));
    V v_t_24103 = heff_strAppend(v_t_24102, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str37), v_s_24101));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, v_rest_241})});
  }
  case TAG_SLitBytes: {
    V v_s_24104 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24105 = heff_intShow(heff_strLength(heff_dup(v_s_24104)));
    V v_t_24106 = heff_strAppend(v_t_24105, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str39), v_s_24104));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, v_rest_241})});
  }
  case TAG_SLitRune: {
    V v_c_24107 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24108 = heff_intShow(v_c_24107);
    V v_t_24109 = heff_intShow(heff_strLength(heff_dup(v_s_24108)));
    V v_t_24110 = heff_strAppend(v_t_24109, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str41), v_s_24108));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, v_rest_241})});
  }
  case TAG_SLitFixed: {
    V v_w_24111 = heff_field(v_x2_240, 0);
    V v_n_24112 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24113;
    switch (heff_tag_of(v_w_24111)) {
    case TAG_I8: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str43);
      break;
    }
    case TAG_I16: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str44);
      break;
    }
    case TAG_I32: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str45);
      break;
    }
    case TAG_I64: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str46);
      break;
    }
    case TAG_U8: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str47);
      break;
    }
    case TAG_U16: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str48);
      break;
    }
    case TAG_U32: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str49);
      break;
    }
    case TAG_U64: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str50);
      break;
    }
    case TAG_F32: {
      v_t_24113 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str51);
      break;
    }
    default: heff_nomatch(v_w_24111);
    }
    V v_s_24114 = heff_intShow(v_n_24112);
    V v_t_24115 = heff_intShow(heff_strLength(heff_dup(v_s_24114)));
    V v_t_24116 = heff_strAppend(v_t_24115, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str52), v_s_24114));
    V v_t_24117 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24113, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24116, v_rest_241})});
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str53), v_t_24117});
  }
  case TAG_SLitFloat32: {
    V v_x_24118 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24119 = heff_floatShow(v_x_24118);
    V v_t_24120 = heff_intShow(heff_strLength(heff_dup(v_s_24119)));
    V v_t_24121 = heff_strAppend(v_t_24120, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str54), v_s_24119));
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24121, v_rest_241})});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32, 4, "meta");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51, 7, "Float32");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55, 3, "f32");
Clo g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry, 3, 0};

V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(V v_x2_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_SLocal: {
    V v_i_243 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_243), v_rest_241});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str0), v_t_244}));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_246 = heff_intShow(heff_strLength(heff_dup(v_x_245)));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str1), v_x_245));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str2), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_248);
  }
  case TAG_SCode: {
    V v_t_249 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_249); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str3), v_t_2410}));
  }
  case TAG_SApp: {
    V v_f_2411 = heff_field(v_x2_240, 0);
    V v_a_2412 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_rest_2413 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_a_2412, v_rest_241));
    V v_t_2414 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_f_2411, v_rest_2413));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str4), v_t_2414}));
  }
  case TAG_SLam: {
    V v_t_2415 = heff_field(v_x2_240, 0);
    V v_b_2416 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLam = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2424;
    switch (heff_tag_of(v_b_2416)) {
    case TAG_MkAbs: {
      V v_x_2417 = heff_field(v_b_2416, 0);
      V v_e_2418 = heff_field(v_b_2416, 1);
      heff_take_n(v_b_2416, 3ULL, 2);
      V v_t_2419 = heff_intShow(heff_strLength(heff_dup(v_x_2417)));
      V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str5), v_x_2417));
      V v_t_2421 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2418, v_rest_241));
      v_rest_2424 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str6), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2421})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2422 = heff_field(v_b_2416, 0);
      heff_take_n(v_b_2416, 1ULL, 1);
      V v_t_2423 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2422, v_rest_241));
      v_rest_2424 = heff_tag_at_n(v_ru_24x2_240_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str7), v_t_2423});
      break;
    }
    default: heff_nomatch(v_b_2416);
    }
    V v_t_2425 = ({ V a_0 = v_t_2415; V a_1 = v_rest_2424; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2415); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str8), v_t_2425}));
  }
  case TAG_SCons: {
    V v_d_2426 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2427 = heff_arrayToList(heff_take_field(v_d_2426, 0));
    V v_t_2428 = heff_arrayToList(heff_get_n(v_d_2426, 2, 3));
    V v_xs_2429 = (g_heff_2eutil_2edict_2ezipKV(v_t_2427, v_t_2428));
    V v_i_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2429));
    V v_t_2431 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s558176397x1805484590(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str9), v_xs_2429, v_rest_241));
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2430), v_t_2431});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str10), v_t_2432}));
  }
  case TAG_SProj: {
    V v_e2_2433 = heff_field(v_x2_240, 0);
    V v_l_2434 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SProj = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2435 = heff_tag_at_n(v_ru_24x2_240_24SProj, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str11), heff_hole()});
    V v_u_2436 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2435));
    heff_drop(v_u_2436);
    V v_t_2437 = heff_intShow(heff_strLength(heff_dup(v_l_2434)));
    V v_t_2438 = heff_strAppend(v_t_2437, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str12), v_l_2434));
    V t_0 = v_e2_2433;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_rest_241});
    V t_2 = v_cell_2435;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_STag: {
    V v_t_2439 = heff_field(v_x2_240, 0);
    V v_as_2440 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24STag = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2441 = heff_intShow(heff_strLength(heff_dup(v_t_2439)));
    V v_t_2442 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str13), v_t_2439));
    V v_xs_2443 = heff_arrayToList(v_as_2440);
    V v_i_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2443));
    V v_t_2445 = ({ V a_0 = v_xs_2443; V a_1 = v_rest_241; V r_ = (g_heff_2ebuild_2eserial_2eencodeListGo_24s371364471x739052008(a_0, a_1)); heff_drop(v_xs_2443); r_; });
    V v_t_2446 = heff_tag_at_n(v_ru_24x2_240_24STag, TAG_Cons, 2, (V[]){heff_intShow(v_i_2444), v_t_2445});
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str14), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2446})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2447);
  }
  case TAG_SMatch: {
    V v_e2_2448 = heff_field(v_x2_240, 0);
    V v_cs_2449 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SMatch = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2450 = heff_arrayToList(heff_take_field(v_cs_2449, 0));
    V v_t_2451 = heff_arrayToList(heff_get_n(v_cs_2449, 2, 3));
    V v_xs_2452 = (g_heff_2eutil_2edict_2ezipKV(v_t_2450, v_t_2451));
    V v_i_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2452));
    V v_t_2454 = (g_heff_2ebuild_2eserial_2eencodeListGo_24s2016426606x925519819(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str15), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str16), v_xs_2452, v_rest_241));
    V v_rest_2455 = heff_tag_at_n(v_ru_24x2_240_24SMatch, TAG_Cons, 2, (V[]){heff_intShow(v_i_2453), v_t_2454});
    V v_t_2456 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2448, v_rest_2455));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str17), v_t_2456}));
  }
  case TAG_SSpecialize: {
    V v_e2_2457 = heff_field(v_x2_240, 0);
    V v_l_2458 = heff_field(v_x2_240, 1);
    V v_v_2459 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2460 = heff_intShow(heff_strLength(heff_dup(v_l_2458)));
    V v_t_2461 = heff_strAppend(v_t_2460, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str18), v_l_2458));
    V v_t_2462 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_v_2459, v_rest_241));
    V v_rest_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, v_t_2462});
    V v_t_2464 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e2_2457, v_rest_2463));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str19), v_t_2464}));
  }
  case TAG_SIs: {
    V v_e2_2465 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str20), heff_hole()});
    V v_u_2467 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2466));
    heff_drop(v_u_2467);
    V t_0 = v_e2_2465;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2466;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str21), v_rest_241}));
  }
  case TAG_SAbandon: {
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str22), v_rest_241}));
  }
  case TAG_SRec: {
    V v_e2_2468 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_cell_2469 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str23), heff_hole()});
    V v_u_2470 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2469));
    heff_drop(v_u_2470);
    V t_0 = v_e2_2468;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2469;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_t_2471 = heff_field(v_x2_240, 0);
    V v_b_2472 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SFix = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_rest_2480;
    switch (heff_tag_of(v_b_2472)) {
    case TAG_MkAbs: {
      V v_x_2473 = heff_field(v_b_2472, 0);
      V v_e_2474 = heff_field(v_b_2472, 1);
      heff_take_n(v_b_2472, 3ULL, 2);
      V v_t_2475 = heff_intShow(heff_strLength(heff_dup(v_x_2473)));
      V v_t_2476 = heff_strAppend(v_t_2475, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str24), v_x_2473));
      V v_t_2477 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2474, v_rest_241));
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str25), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_t_2477})});
      break;
    }
    case TAG_AbsConst: {
      V v_e_2478 = heff_field(v_b_2472, 0);
      heff_take_n(v_b_2472, 1ULL, 1);
      V v_t_2479 = (g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631(v_e_2478, v_rest_241));
      v_rest_2480 = heff_tag_at_n(v_ru_24x2_240_24SFix, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str26), v_t_2479});
      break;
    }
    default: heff_nomatch(v_b_2472);
    }
    V v_t_2481 = ({ V a_0 = v_t_2471; V a_1 = v_rest_2480; V r_ = (g_heff_2ebuild_2eserial_2eencodeTypeF_24s741406419x1767900264(a_0, a_1)); heff_drop(v_t_2471); r_; });
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str27), v_t_2481}));
  }
  case TAG_SImplicit: {
    V v_x_2482 = heff_field(v_x2_240, 0);
    V v_e2_2483 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SImplicit = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2484 = heff_tag_at_n(v_ru_24x2_240_24SImplicit, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str28), heff_hole()});
    V v_u_2485 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2484));
    heff_drop(v_u_2485);
    V v_t_2486 = heff_intShow(heff_strLength(heff_dup(v_x_2482)));
    V v_t_2487 = heff_strAppend(v_t_2486, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str29), v_x_2482));
    V v_cell_2488 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, heff_hole()});
    V v_u_2489 = heff_setField(v_cell_2484, MK_INT(1LL), heff_dup(v_cell_2488));
    heff_drop(v_u_2489);
    V t_0 = v_e2_2483;
    V t_1 = v_rest_241;
    V t_2 = v_cell_2488;
    v_x2_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2490 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2491 = heff_intShow(heff_strLength(heff_dup(v_x_2490)));
    V v_t_2492 = heff_strAppend(v_t_2491, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str30), v_x_2490));
    V v_t_2493 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2492, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2493);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x2_240, 0ULL, 3);
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str32), v_rest_241}));
  }
  case TAG_SLitInt: {
    V v_i_2497 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_2498 = heff_intShow(v_i_2497);
    V v_t_2499 = heff_intShow(heff_strLength(heff_dup(v_s_2498)));
    V v_t_24100 = heff_strAppend(v_t_2499, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str33), v_s_2498));
    V v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str34), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24101);
  }
  case TAG_SLitFloat: {
    V v_x_24102 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24103 = heff_floatShow(v_x_24102);
    V v_t_24104 = heff_intShow(heff_strLength(heff_dup(v_s_24103)));
    V v_t_24105 = heff_strAppend(v_t_24104, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str35), v_s_24103));
    V v_t_24106 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str36), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24105, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24106);
  }
  case TAG_SLitString: {
    V v_s_24107 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24108 = heff_intShow(heff_strLength(heff_dup(v_s_24107)));
    V v_t_24109 = heff_strAppend(v_t_24108, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str37), v_s_24107));
    V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str38), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24110);
  }
  case TAG_SLitBytes: {
    V v_s_24111 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_24112 = heff_intShow(heff_strLength(heff_dup(v_s_24111)));
    V v_t_24113 = heff_strAppend(v_t_24112, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str39), v_s_24111));
    V v_t_24114 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24114);
  }
  case TAG_SLitRune: {
    V v_c_24115 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_s_24116 = heff_intShow(v_c_24115);
    V v_t_24117 = heff_intShow(heff_strLength(heff_dup(v_s_24116)));
    V v_t_24118 = heff_strAppend(v_t_24117, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str41), v_s_24116));
    V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str42), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24119);
  }
  case TAG_SLitFixed: {
    V v_w_24120 = heff_field(v_x2_240, 0);
    V v_n_24121 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24SLitFixed = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24122;
    switch (heff_tag_of(v_w_24120)) {
    case TAG_I8: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str43);
      break;
    }
    case TAG_I16: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str44);
      break;
    }
    case TAG_I32: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str45);
      break;
    }
    case TAG_I64: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str46);
      break;
    }
    case TAG_U8: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str47);
      break;
    }
    case TAG_U16: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str48);
      break;
    }
    case TAG_U32: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str49);
      break;
    }
    case TAG_U64: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str50);
      break;
    }
    case TAG_F32: {
      v_t_24122 = ((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str51);
      break;
    }
    default: heff_nomatch(v_w_24120);
    }
    V v_s_24123 = heff_intShow(v_n_24121);
    V v_t_24124 = heff_intShow(heff_strLength(heff_dup(v_s_24123)));
    V v_t_24125 = heff_strAppend(v_t_24124, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str52), v_s_24123));
    V v_t_24126 = heff_tag_at_n(v_ru_24x2_240_24SLitFixed, TAG_Cons, 2, (V[]){v_t_24122, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24125, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str53), v_t_24126}));
  }
  case TAG_SLitFloat32: {
    V v_x_24127 = heff_tget_v(v_x2_240, 0);
    heff_take_na(v_x2_240, 0ULL, 1);
    V v_s_24128 = heff_floatShow(v_x_24127);
    V v_t_24129 = heff_intShow(heff_strLength(heff_dup(v_s_24128)));
    V v_t_24130 = heff_strAppend(v_t_24129, heff_strAppend(((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str54), v_s_24128));
    V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, v_rest_241})});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_24131);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eencodeTermF_24s1482776925x1843077631_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str0, 4, "Int8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str1, 5, "Int16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str2, 5, "Int32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str3, 5, "Int64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ebuild_2eserial_2etakeFixed_str8, 7, "Float32");
Clo g_heff_2ebuild_2eserial_2etakeFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeFixed_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeFixed(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eword(v_s_240, v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x1_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str0); V a_1 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str1); V a_2 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str2); V a_3 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str3); V a_4 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str4); V a_5 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str5); V a_6 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str6); V a_7 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str7); V a_8 = ((V)&g_heff_2ebuild_2eserial_2etakeFixed_str8); V a_9 = v_x_244; V b_10 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind_24s1236173780x2048419812(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_j_245);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_j_245})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eserial_2etakeFixed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeFixed(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eserial_2eabsOf_str1, 1, "_");
Clo g_heff_2ebuild_2eserial_2eabsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2eabsOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2eabsOf(V v_d_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2eabsOf_str0))) {
    heff_drop(v_x2_241);
    V v_x3_245 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_d_240);
      heff_drop(v_z_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_x3_249 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_j_248}));
        switch (heff_tag_of(v_x3_249)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_245_24Just, 1);
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2410 = heff_field(v_x3_249, 0);
          heff_take_n(v_x3_249, 1ULL, 1);
          switch (heff_tag_of(v_x31_2410)) {
          case TAG_MkPair: {
            V v_x_2411 = heff_field(v_x31_2410, 0);
            V v_j_2412 = heff_field(v_x31_2410, 1);
            heff_take_n(v_x31_2410, 3ULL, 2);
            V v_t_2413 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_247, v_x_2411}), v_j_2412});
            return heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_2413});
          }
          default: return heff_nomatch(v_x31_2410);
          }
        }
        default: return heff_nomatch(v_x3_249);
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  } else {
    if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2eabsOf_str1))) {
      V v_x3_2415 = heff_tr(heff_call(v_d_240, 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_2415)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2416 = heff_field(v_x3_2415, 0);
        V v_ru_24x3_2415_24Just = heff_take_reuse_n(v_x3_2415, 1ULL, 1);
        switch (heff_tag_of(v_x31_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x31_2416, 0);
          V v_j_2418 = heff_field(v_x31_2416, 1);
          V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2417}), v_j_2418});
          return heff_tag_at_n(v_ru_24x3_2415_24Just, TAG_Just, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_x31_2416);
        }
      }
      default: return heff_nomatch(v_x3_2415);
      }
    } else {
      heff_drop(v_d_240);
      return ({ V a_0 = v_z_242; V a_1 = v_z_243; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
    }
  }
}
V g_heff_2ebuild_2eserial_2eabsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2eabsOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eserial_2etakeDict_lam0(V self, V *args);
Clo g_heff_2ebuild_2eserial_2etakeDict_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeDict_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeDict(V v_d_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_i_242));
  V v_x3_2418;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop(v_d_240);
    heff_drop(v_s_241);
    v_x3_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      v_x3_2418 = (g_heff_2ebuild_2edecoder_2etimes(heff_clo_n(g_heff_2ebuild_2eserial_2etakeDict_lam0, 2, 1, (V[]){v_d_240}), v_x_245, v_s_241, v_j_246));
      break;
    }
    default: heff_nomatch(v_x31_244);
    }
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_x3_2418)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2419 = heff_field(v_x3_2418, 0);
    V v_ru_24x3_2418_24Just = heff_take_reuse_n(v_x3_2418, 1ULL, 1);
    switch (heff_tag_of(v_x31_2419)) {
    case TAG_MkPair: {
      V v_x_2420 = heff_field(v_x31_2419, 0);
      V v_j_2421 = heff_field(v_x31_2419, 1);
      heff_take_n(v_x31_2419, 3ULL, 2);
      V v_t_2422 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2420)));
      V v_t_2423 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2420));
      V v_t_2424 = (g_list_2emap_24s1173914895x100384474(v_x_2420));
      V v_x_2425 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2422), v_t_2423, heff_arrayFromList(v_t_2424)});
      return heff_tag_at_n(v_ru_24x3_2418_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_j_2421})});
    }
    default: return heff_nomatch(v_x31_2419);
    }
  }
  default: return heff_nomatch(v_x3_2418);
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeDict(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2eserial_2etakeDict_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_i_248 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_249 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_247), v_i_248));
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nothing: {
    heff_drop(v_s_247);
    heff_drop(v_d_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2410 = heff_field(v_x3_249, 0);
    V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
    switch (heff_tag_of(v_x31_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x31_2410, 0);
      V v_j_2412 = heff_field(v_x31_2410, 1);
      V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
      V v_x3_2413 = heff_tr(heff_call(v_d_240, 2, (V[]){v_s_247, v_j_2412}));
      switch (heff_tag_of(v_x3_2413)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_249_24Just, 1);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2414 = heff_field(v_x3_2413, 0);
        heff_take_n(v_x3_2413, 1ULL, 1);
        switch (heff_tag_of(v_x31_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x31_2414, 0);
          V v_j_2416 = heff_field(v_x31_2414, 1);
          heff_take_n(v_x31_2414, 3ULL, 2);
          V v_t_2417 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_x_2415}), v_j_2416});
          return heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_t_2417});
        }
        default: return heff_nomatch(v_x31_2414);
        }
      }
      default: return heff_nomatch(v_x3_2413);
      }
    }
    default: return heff_nomatch(v_x31_2410);
    }
  }
  default: return heff_nomatch(v_x3_249);
  }
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str22, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str23, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str24, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str25, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str26, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str27, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_str29, 0, "");
Clo g_heff_2ebuild_2eserial_2etermOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etermOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str0))) {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_x2_241);
    V v_x3_245 = (g_heff_2ebuild_2edecoder_2eint(v_z_242, v_z_243));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_246 = heff_field(v_x3_245, 0);
      V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_247}), v_j_248});
        return heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_t_249});
      }
      default: return heff_nomatch(v_x31_246);
      }
    }
    default: return heff_nomatch(v_x3_245);
    }
  } else {
    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str1))) {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_x2_241);
      V v_x3_2411 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2412 = heff_field(v_x3_2411, 0);
        V v_ru_24x3_2411_24Just = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
        switch (heff_tag_of(v_x31_2412)) {
        case TAG_MkPair: {
          V v_x_2413 = heff_field(v_x31_2412, 0);
          V v_j_2414 = heff_field(v_x31_2412, 1);
          V v_ru_24x31_2412_24MkPair = heff_take_reuse_n(v_x31_2412, 3ULL, 2);
          V v_t_2415 = heff_tag_at_n(v_ru_24x31_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2413}), v_j_2414});
          return heff_tag_at_n(v_ru_24x3_2411_24Just, TAG_Just, 1, (V[]){v_t_2415});
        }
        default: return heff_nomatch(v_x31_2412);
        }
      }
      default: return heff_nomatch(v_x3_2411);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str2))) {
        heff_drop(v_x2_241);
        V v_x3_2417 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
        switch (heff_tag_of(v_x3_2417)) {
        case TAG_Nothing: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2418 = heff_field(v_x3_2417, 0);
          V v_ru_24x3_2417_24Just = heff_take_reuse_n(v_x3_2417, 1ULL, 1);
          switch (heff_tag_of(v_x31_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x31_2418, 0);
            V v_j_2420 = heff_field(v_x31_2418, 1);
            V v_ru_24x31_2418_24MkPair = heff_take_reuse_n(v_x31_2418, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x31_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_x_2419}), v_j_2420});
            return heff_tag_at_n(v_ru_24x3_2417_24Just, TAG_Just, 1, (V[]){v_t_2421});
          }
          default: return heff_nomatch(v_x31_2418);
          }
        }
        default: return heff_nomatch(v_x3_2417);
        }
      } else {
        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str3))) {
          heff_drop(v_x2_241);
          V v_x3_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
          switch (heff_tag_of(v_x3_2423)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2424 = heff_field(v_x3_2423, 0);
            V v_ru_24x3_2423_24Just = heff_take_reuse_n(v_x3_2423, 1ULL, 1);
            switch (heff_tag_of(v_x31_2424)) {
            case TAG_MkPair: {
              V v_x_2425 = heff_field(v_x31_2424, 0);
              V v_j_2426 = heff_field(v_x31_2424, 1);
              V v_ru_24x31_2424_24MkPair = heff_take_reuse_n(v_x31_2424, 3ULL, 2);
              V v_x3_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_2426}));
              switch (heff_tag_of(v_x3_2427)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x3_2423_24Just, 1);
                heff_drop(v_x_2425);
                heff_drop_cell(v_ru_24x31_2424_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2428 = heff_field(v_x3_2427, 0);
                heff_take_n(v_x3_2427, 1ULL, 1);
                switch (heff_tag_of(v_x31_2428)) {
                case TAG_MkPair: {
                  V v_x_2429 = heff_field(v_x31_2428, 0);
                  V v_j_2430 = heff_field(v_x31_2428, 1);
                  heff_take_n(v_x31_2428, 3ULL, 2);
                  V v_t_2431 = heff_tag_at_n(v_ru_24x31_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2425, v_x_2429}), v_j_2430});
                  return heff_tag_at_n(v_ru_24x3_2423_24Just, TAG_Just, 1, (V[]){v_t_2431});
                }
                default: return heff_nomatch(v_x31_2428);
                }
              }
              default: return heff_nomatch(v_x3_2427);
              }
            }
            default: return heff_nomatch(v_x31_2424);
            }
          }
          default: return heff_nomatch(v_x3_2423);
          }
        } else {
          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str4))) {
            heff_drop(v_x2_241);
            V v_x3_2433 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
            switch (heff_tag_of(v_x3_2433)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2434 = heff_field(v_x3_2433, 0);
              V v_ru_24x3_2433_24Just = heff_take_reuse_n(v_x3_2433, 1ULL, 1);
              switch (heff_tag_of(v_x31_2434)) {
              case TAG_MkPair: {
                V v_x_2435 = heff_field(v_x31_2434, 0);
                V v_j_2436 = heff_field(v_x31_2434, 1);
                V v_ru_24x31_2434_24MkPair = heff_take_reuse_n(v_x31_2434, 3ULL, 2);
                V v_x3_2437 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_242), v_j_2436));
                V v_x3_2441;
                switch (heff_tag_of(v_x3_2437)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_z_242);
                  v_x3_2441 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_x31_2438 = heff_field(v_x3_2437, 0);
                  heff_take_n(v_x3_2437, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2438)) {
                  case TAG_MkPair: {
                    V v_x_2439 = heff_field(v_x31_2438, 0);
                    V v_j_2440 = heff_field(v_x31_2438, 1);
                    heff_take_n(v_x31_2438, 3ULL, 2);
                    v_x3_2441 = (g_heff_2ebuild_2eserial_2eabsOf(heff_get_n(v_k_240, 0, 2), v_x_2439, v_z_242, v_j_2440));
                    break;
                  }
                  default: heff_nomatch(v_x31_2438);
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2437);
                }
                switch (heff_tag_of(v_x3_2441)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24x3_2433_24Just, 1);
                  heff_drop(v_x_2435);
                  heff_drop_cell(v_ru_24x31_2434_24MkPair, 2);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2442 = heff_field(v_x3_2441, 0);
                  heff_take_n(v_x3_2441, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2442)) {
                  case TAG_MkPair: {
                    V v_x_2443 = heff_field(v_x31_2442, 0);
                    V v_j_2444 = heff_field(v_x31_2442, 1);
                    heff_take_n(v_x31_2442, 3ULL, 2);
                    V v_t_2445 = heff_tag_at_n(v_ru_24x31_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2435, v_x_2443}), v_j_2444});
                    return heff_tag_at_n(v_ru_24x3_2433_24Just, TAG_Just, 1, (V[]){v_t_2445});
                  }
                  default: return heff_nomatch(v_x31_2442);
                  }
                }
                default: return heff_nomatch(v_x3_2441);
                }
              }
              default: return heff_nomatch(v_x31_2434);
              }
            }
            default: return heff_nomatch(v_x3_2433);
            }
          } else {
            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str5))) {
              heff_drop(v_x2_241);
              V v_x3_2447 = (g_heff_2ebuild_2eserial_2etakeDict(heff_get_n(v_k_240, 0, 2), v_z_242, v_z_243));
              switch (heff_tag_of(v_x3_2447)) {
              case TAG_Nothing: {
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2448 = heff_field(v_x3_2447, 0);
                V v_ru_24x3_2447_24Just = heff_take_reuse_n(v_x3_2447, 1ULL, 1);
                switch (heff_tag_of(v_x31_2448)) {
                case TAG_MkPair: {
                  V v_x_2449 = heff_field(v_x31_2448, 0);
                  V v_j_2450 = heff_field(v_x31_2448, 1);
                  V v_ru_24x31_2448_24MkPair = heff_take_reuse_n(v_x31_2448, 3ULL, 2);
                  V v_t_2451 = heff_tag_at_n(v_ru_24x31_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2449}), v_j_2450});
                  return heff_tag_at_n(v_ru_24x3_2447_24Just, TAG_Just, 1, (V[]){v_t_2451});
                }
                default: return heff_nomatch(v_x31_2448);
                }
              }
              default: return heff_nomatch(v_x3_2447);
              }
            } else {
              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str6))) {
                heff_drop(v_x2_241);
                V v_x3_2453 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                switch (heff_tag_of(v_x3_2453)) {
                case TAG_Nothing: {
                  heff_drop(v_z_242);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2454 = heff_field(v_x3_2453, 0);
                  V v_ru_24x3_2453_24Just = heff_take_reuse_n(v_x3_2453, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2454)) {
                  case TAG_MkPair: {
                    V v_x_2455 = heff_field(v_x31_2454, 0);
                    V v_j_2456 = heff_field(v_x31_2454, 1);
                    V v_ru_24x31_2454_24MkPair = heff_take_reuse_n(v_x31_2454, 3ULL, 2);
                    V v_x3_2457 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_j_2456));
                    switch (heff_tag_of(v_x3_2457)) {
                    case TAG_Nothing: {
                      heff_drop_cell(v_ru_24x3_2453_24Just, 1);
                      heff_drop(v_x_2455);
                      heff_drop_cell(v_ru_24x31_2454_24MkPair, 2);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2458 = heff_field(v_x3_2457, 0);
                      heff_take_n(v_x3_2457, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2458)) {
                      case TAG_MkPair: {
                        V v_x_2459 = heff_field(v_x31_2458, 0);
                        V v_j_2460 = heff_field(v_x31_2458, 1);
                        heff_take_n(v_x31_2458, 3ULL, 2);
                        V v_t_2461 = heff_tag_at_n(v_ru_24x31_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2455, v_x_2459}), v_j_2460});
                        return heff_tag_at_n(v_ru_24x3_2453_24Just, TAG_Just, 1, (V[]){v_t_2461});
                      }
                      default: return heff_nomatch(v_x31_2458);
                      }
                    }
                    default: return heff_nomatch(v_x3_2457);
                    }
                  }
                  default: return heff_nomatch(v_x31_2454);
                  }
                }
                default: return heff_nomatch(v_x3_2453);
                }
              } else {
                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str7))) {
                  heff_drop(v_x2_241);
                  V v_x3_2463 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                  switch (heff_tag_of(v_x3_2463)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_z_242);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2464 = heff_field(v_x3_2463, 0);
                    V v_ru_24x3_2463_24Just = heff_take_reuse_n(v_x3_2463, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2464)) {
                    case TAG_MkPair: {
                      V v_x_2465 = heff_field(v_x31_2464, 0);
                      V v_j_2466 = heff_field(v_x31_2464, 1);
                      V v_ru_24x31_2464_24MkPair = heff_take_reuse_n(v_x31_2464, 3ULL, 2);
                      V v_x3_2467 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_242), v_j_2466));
                      V v_x3_2471;
                      switch (heff_tag_of(v_x3_2467)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        v_x3_2471 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_2468 = heff_field(v_x3_2467, 0);
                        heff_take_n(v_x3_2467, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2468)) {
                        case TAG_MkPair: {
                          V v_x_2469 = heff_field(v_x31_2468, 0);
                          V v_j_2470 = heff_field(v_x31_2468, 1);
                          heff_take_n(v_x31_2468, 3ULL, 2);
                          v_x3_2471 = (g_heff_2ebuild_2edecoder_2etimes(heff_get_n(v_k_240, 0, 2), v_x_2469, v_z_242, v_j_2470));
                          break;
                        }
                        default: heff_nomatch(v_x31_2468);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_2467);
                      }
                      switch (heff_tag_of(v_x3_2471)) {
                      case TAG_Nothing: {
                        heff_drop_cell(v_ru_24x3_2463_24Just, 1);
                        heff_drop(v_x_2465);
                        heff_drop_cell(v_ru_24x31_2464_24MkPair, 2);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_2472 = heff_field(v_x3_2471, 0);
                        heff_take_n(v_x3_2471, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2472)) {
                        case TAG_MkPair: {
                          V v_x_2473 = heff_field(v_x31_2472, 0);
                          V v_j_2474 = heff_field(v_x31_2472, 1);
                          heff_take_n(v_x31_2472, 3ULL, 2);
                          V v_t_2475 = heff_tag_at_n(v_ru_24x31_2464_24MkPair, TAG_STag, 2, (V[]){v_x_2465, heff_arrayFromList(v_x_2473)});
                          return heff_tag_at_n(v_ru_24x3_2463_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2475, v_j_2474})});
                        }
                        default: return heff_nomatch(v_x31_2472);
                        }
                      }
                      default: return heff_nomatch(v_x3_2471);
                      }
                    }
                    default: return heff_nomatch(v_x31_2464);
                    }
                  }
                  default: return heff_nomatch(v_x3_2463);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str8))) {
                    heff_drop(v_x2_241);
                    V v_x3_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                    switch (heff_tag_of(v_x3_2477)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2478 = heff_field(v_x3_2477, 0);
                      V v_ru_24x3_2477_24Just = heff_take_reuse_n(v_x3_2477, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2478)) {
                      case TAG_MkPair: {
                        V v_x_2479 = heff_field(v_x31_2478, 0);
                        V v_j_2480 = heff_field(v_x31_2478, 1);
                        V v_ru_24x31_2478_24MkPair = heff_take_reuse_n(v_x31_2478, 3ULL, 2);
                        V v_t_2481 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeAlt_clo), 1, (V[]){v_k_240}));
                        V v_x3_2482 = (g_heff_2ebuild_2eserial_2etakeDict(v_t_2481, v_z_242, v_j_2480));
                        switch (heff_tag_of(v_x3_2482)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x3_2477_24Just, 1);
                          heff_drop(v_x_2479);
                          heff_drop_cell(v_ru_24x31_2478_24MkPair, 2);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2483 = heff_field(v_x3_2482, 0);
                          heff_take_n(v_x3_2482, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2483)) {
                          case TAG_MkPair: {
                            V v_x_2484 = heff_field(v_x31_2483, 0);
                            V v_j_2485 = heff_field(v_x31_2483, 1);
                            heff_take_n(v_x31_2483, 3ULL, 2);
                            V v_t_2486 = heff_tag_at_n(v_ru_24x31_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_2479, v_x_2484}), v_j_2485});
                            return heff_tag_at_n(v_ru_24x3_2477_24Just, TAG_Just, 1, (V[]){v_t_2486});
                          }
                          default: return heff_nomatch(v_x31_2483);
                          }
                        }
                        default: return heff_nomatch(v_x3_2482);
                        }
                      }
                      default: return heff_nomatch(v_x31_2478);
                      }
                    }
                    default: return heff_nomatch(v_x3_2477);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str9))) {
                      heff_drop(v_x2_241);
                      V v_x3_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                      switch (heff_tag_of(v_x3_2488)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_k_240, 2);
                        heff_drop(v_z_242);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_2489 = heff_field(v_x3_2488, 0);
                        V v_ru_24x3_2488_24Just = heff_take_reuse_n(v_x3_2488, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2489)) {
                        case TAG_MkPair: {
                          V v_x_2490 = heff_field(v_x31_2489, 0);
                          V v_j_2491 = heff_field(v_x31_2489, 1);
                          V v_ru_24x31_2489_24MkPair = heff_take_reuse_n(v_x31_2489, 3ULL, 2);
                          V v_x3_2492 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_j_2491));
                          switch (heff_tag_of(v_x3_2492)) {
                          case TAG_Nothing: {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_z_242);
                            heff_drop_cell(v_ru_24x3_2488_24Just, 1);
                            heff_drop(v_x_2490);
                            heff_drop_cell(v_ru_24x31_2489_24MkPair, 2);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_2493 = heff_field(v_x3_2492, 0);
                            heff_take_n(v_x3_2492, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2493)) {
                            case TAG_MkPair: {
                              V v_x_2494 = heff_field(v_x31_2493, 0);
                              V v_j_2495 = heff_field(v_x31_2493, 1);
                              heff_take_n(v_x31_2493, 3ULL, 2);
                              V v_x3_2496 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_2495}));
                              switch (heff_tag_of(v_x3_2496)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24x3_2488_24Just, 1);
                                heff_drop(v_x_2490);
                                heff_drop_cell(v_ru_24x31_2489_24MkPair, 2);
                                heff_drop(v_x_2494);
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_2497 = heff_field(v_x3_2496, 0);
                                heff_take_n(v_x3_2496, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2497)) {
                                case TAG_MkPair: {
                                  V v_x_2498 = heff_field(v_x31_2497, 0);
                                  V v_j_2499 = heff_field(v_x31_2497, 1);
                                  heff_take_n(v_x31_2497, 3ULL, 2);
                                  V v_t_24100 = heff_tag_at_n(v_ru_24x31_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2490, v_x_2494, v_x_2498}), v_j_2499});
                                  return heff_tag_at_n(v_ru_24x3_2488_24Just, TAG_Just, 1, (V[]){v_t_24100});
                                }
                                default: return heff_nomatch(v_x31_2497);
                                }
                              }
                              default: return heff_nomatch(v_x3_2496);
                              }
                            }
                            default: return heff_nomatch(v_x31_2493);
                            }
                          }
                          default: return heff_nomatch(v_x3_2492);
                          }
                        }
                        default: return heff_nomatch(v_x31_2489);
                        }
                      }
                      default: return heff_nomatch(v_x3_2488);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str10))) {
                        heff_drop(v_x2_241);
                        V v_x3_24102 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_24102)) {
                        case TAG_Nothing: {
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_24103 = heff_field(v_x3_24102, 0);
                          V v_ru_24x3_24102_24Just = heff_take_reuse_n(v_x3_24102, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24103)) {
                          case TAG_MkPair: {
                            V v_x_24104 = heff_field(v_x31_24103, 0);
                            V v_j_24105 = heff_field(v_x31_24103, 1);
                            V v_ru_24x31_24103_24MkPair = heff_take_reuse_n(v_x31_24103, 3ULL, 2);
                            V v_t_24106 = heff_tag_at_n(v_ru_24x31_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){v_x_24104}), v_j_24105});
                            return heff_tag_at_n(v_ru_24x3_24102_24Just, TAG_Just, 1, (V[]){v_t_24106});
                          }
                          default: return heff_nomatch(v_x31_24103);
                          }
                        }
                        default: return heff_nomatch(v_x3_24102);
                        }
                      } else {
                        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str11))) {
                          heff_drop_rec(v_k_240, 2);
                          heff_drop(v_x2_241);
                          heff_drop(v_z_242);
                          V v_t_24108 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_243});
                          return heff_tag_n(TAG_Just, 1, (V[]){v_t_24108});
                        } else {
                          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str12))) {
                            heff_drop_rec(v_k_240, 2);
                            heff_drop(v_x2_241);
                            heff_drop(v_z_242);
                            V v_t_24110 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_243});
                            return heff_tag_n(TAG_Just, 1, (V[]){v_t_24110});
                          } else {
                            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str13))) {
                              heff_drop(v_x2_241);
                              V v_x3_24112 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
                              switch (heff_tag_of(v_x3_24112)) {
                              case TAG_Nothing: {
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_24113 = heff_field(v_x3_24112, 0);
                                V v_ru_24x3_24112_24Just = heff_take_reuse_n(v_x3_24112, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24113)) {
                                case TAG_MkPair: {
                                  V v_x_24114 = heff_field(v_x31_24113, 0);
                                  V v_j_24115 = heff_field(v_x31_24113, 1);
                                  V v_ru_24x31_24113_24MkPair = heff_take_reuse_n(v_x31_24113, 3ULL, 2);
                                  V v_t_24116 = heff_tag_at_n(v_ru_24x31_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRec, 1, (V[]){v_x_24114}), v_j_24115});
                                  return heff_tag_at_n(v_ru_24x3_24112_24Just, TAG_Just, 1, (V[]){v_t_24116});
                                }
                                default: return heff_nomatch(v_x31_24113);
                                }
                              }
                              default: return heff_nomatch(v_x3_24112);
                              }
                            } else {
                              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str14))) {
                                heff_drop(v_x2_241);
                                V v_x3_24118 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 2, (V[]){heff_dup(v_z_242), v_z_243}));
                                switch (heff_tag_of(v_x3_24118)) {
                                case TAG_Nothing: {
                                  heff_drop_rec(v_k_240, 2);
                                  heff_drop(v_z_242);
                                  return NTAG(TAG_Nothing);
                                }
                                case TAG_Just: {
                                  V v_x31_24119 = heff_field(v_x3_24118, 0);
                                  V v_ru_24x3_24118_24Just = heff_take_reuse_n(v_x3_24118, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24119)) {
                                  case TAG_MkPair: {
                                    V v_x_24120 = heff_field(v_x31_24119, 0);
                                    V v_j_24121 = heff_field(v_x31_24119, 1);
                                    V v_ru_24x31_24119_24MkPair = heff_take_reuse_n(v_x31_24119, 3ULL, 2);
                                    V v_x3_24122 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_242), v_j_24121));
                                    V v_x3_24126;
                                    switch (heff_tag_of(v_x3_24122)) {
                                    case TAG_Nothing: {
                                      heff_drop_rec(v_k_240, 2);
                                      heff_drop(v_z_242);
                                      v_x3_24126 = NTAG(TAG_Nothing);
                                      break;
                                    }
                                    case TAG_Just: {
                                      V v_x31_24123 = heff_field(v_x3_24122, 0);
                                      heff_take_n(v_x3_24122, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24123)) {
                                      case TAG_MkPair: {
                                        V v_x_24124 = heff_field(v_x31_24123, 0);
                                        V v_j_24125 = heff_field(v_x31_24123, 1);
                                        heff_take_n(v_x31_24123, 3ULL, 2);
                                        v_x3_24126 = (g_heff_2ebuild_2eserial_2eabsOf(heff_get_n(v_k_240, 0, 2), v_x_24124, v_z_242, v_j_24125));
                                        break;
                                      }
                                      default: heff_nomatch(v_x31_24123);
                                      }
                                      break;
                                    }
                                    default: heff_nomatch(v_x3_24122);
                                    }
                                    switch (heff_tag_of(v_x3_24126)) {
                                    case TAG_Nothing: {
                                      heff_drop_cell(v_ru_24x3_24118_24Just, 1);
                                      heff_drop(v_x_24120);
                                      heff_drop_cell(v_ru_24x31_24119_24MkPair, 2);
                                      return NTAG(TAG_Nothing);
                                    }
                                    case TAG_Just: {
                                      V v_x31_24127 = heff_field(v_x3_24126, 0);
                                      heff_take_n(v_x3_24126, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24127)) {
                                      case TAG_MkPair: {
                                        V v_x_24128 = heff_field(v_x31_24127, 0);
                                        V v_j_24129 = heff_field(v_x31_24127, 1);
                                        heff_take_n(v_x31_24127, 3ULL, 2);
                                        V v_t_24130 = heff_tag_at_n(v_ru_24x31_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24120, v_x_24128}), v_j_24129});
                                        return heff_tag_at_n(v_ru_24x3_24118_24Just, TAG_Just, 1, (V[]){v_t_24130});
                                      }
                                      default: return heff_nomatch(v_x31_24127);
                                      }
                                    }
                                    default: return heff_nomatch(v_x3_24126);
                                    }
                                  }
                                  default: return heff_nomatch(v_x31_24119);
                                  }
                                }
                                default: return heff_nomatch(v_x3_24118);
                                }
                              } else {
                                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str15))) {
                                  heff_drop(v_x2_241);
                                  V v_x3_24132 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_242), v_z_243));
                                  switch (heff_tag_of(v_x3_24132)) {
                                  case TAG_Nothing: {
                                    heff_drop_rec(v_k_240, 2);
                                    heff_drop(v_z_242);
                                    return NTAG(TAG_Nothing);
                                  }
                                  case TAG_Just: {
                                    V v_x31_24133 = heff_field(v_x3_24132, 0);
                                    V v_ru_24x3_24132_24Just = heff_take_reuse_n(v_x3_24132, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24133)) {
                                    case TAG_MkPair: {
                                      V v_x_24134 = heff_field(v_x31_24133, 0);
                                      V v_j_24135 = heff_field(v_x31_24133, 1);
                                      V v_ru_24x31_24133_24MkPair = heff_take_reuse_n(v_x31_24133, 3ULL, 2);
                                      V v_x3_24136 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_j_24135}));
                                      switch (heff_tag_of(v_x3_24136)) {
                                      case TAG_Nothing: {
                                        heff_drop_cell(v_ru_24x3_24132_24Just, 1);
                                        heff_drop(v_x_24134);
                                        heff_drop_cell(v_ru_24x31_24133_24MkPair, 2);
                                        return NTAG(TAG_Nothing);
                                      }
                                      case TAG_Just: {
                                        V v_x31_24137 = heff_field(v_x3_24136, 0);
                                        heff_take_n(v_x3_24136, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24137)) {
                                        case TAG_MkPair: {
                                          V v_x_24138 = heff_field(v_x31_24137, 0);
                                          V v_j_24139 = heff_field(v_x31_24137, 1);
                                          heff_take_n(v_x31_24137, 3ULL, 2);
                                          V v_t_24140 = heff_tag_at_n(v_ru_24x31_24133_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24134, v_x_24138}), v_j_24139});
                                          return heff_tag_at_n(v_ru_24x3_24132_24Just, TAG_Just, 1, (V[]){v_t_24140});
                                        }
                                        default: return heff_nomatch(v_x31_24137);
                                        }
                                      }
                                      default: return heff_nomatch(v_x3_24136);
                                      }
                                    }
                                    default: return heff_nomatch(v_x31_24133);
                                    }
                                  }
                                  default: return heff_nomatch(v_x3_24132);
                                  }
                                } else {
                                  heff_drop_rec(v_k_240, 2);
                                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str16))) {
                                    heff_drop(v_x2_241);
                                    V v_x3_24142 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                    switch (heff_tag_of(v_x3_24142)) {
                                    case TAG_Nothing: {
                                      return NTAG(TAG_Nothing);
                                    }
                                    case TAG_Just: {
                                      V v_x31_24143 = heff_field(v_x3_24142, 0);
                                      V v_ru_24x3_24142_24Just = heff_take_reuse_n(v_x3_24142, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24143)) {
                                      case TAG_MkPair: {
                                        V v_x_24144 = heff_field(v_x31_24143, 0);
                                        V v_j_24145 = heff_field(v_x31_24143, 1);
                                        V v_ru_24x31_24143_24MkPair = heff_take_reuse_n(v_x31_24143, 3ULL, 2);
                                        V v_t_24146 = heff_tag_at_n(v_ru_24x31_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24144}), v_j_24145});
                                        return heff_tag_at_n(v_ru_24x3_24142_24Just, TAG_Just, 1, (V[]){v_t_24146});
                                      }
                                      default: return heff_nomatch(v_x31_24143);
                                      }
                                    }
                                    default: return heff_nomatch(v_x3_24142);
                                    }
                                  } else {
                                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str17))) {
                                      heff_drop(v_x2_241);
                                      V v_x3_24148 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                      switch (heff_tag_of(v_x3_24148)) {
                                      case TAG_Nothing: {
                                        return NTAG(TAG_Nothing);
                                      }
                                      case TAG_Just: {
                                        V v_x31_24149 = heff_field(v_x3_24148, 0);
                                        V v_ru_24x3_24148_24Just = heff_take_reuse_n(v_x3_24148, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24149)) {
                                        case TAG_MkPair: {
                                          V v_x_24150 = heff_field(v_x31_24149, 0);
                                          V v_j_24151 = heff_field(v_x31_24149, 1);
                                          heff_take_n(v_x31_24149, 3ULL, 2);
                                          V v_t_24152 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24150));
                                          V v_x_24153 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24152});
                                          return heff_tag_at_n(v_ru_24x3_24148_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24153, v_j_24151})});
                                        }
                                        default: return heff_nomatch(v_x31_24149);
                                        }
                                      }
                                      default: return heff_nomatch(v_x3_24148);
                                      }
                                    } else {
                                      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str18))) {
                                        heff_drop(v_x2_241);
                                        V v_x3_24155 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                        switch (heff_tag_of(v_x3_24155)) {
                                        case TAG_Nothing: {
                                          return NTAG(TAG_Nothing);
                                        }
                                        case TAG_Just: {
                                          V v_x31_24156 = heff_field(v_x3_24155, 0);
                                          V v_ru_24x3_24155_24Just = heff_take_reuse_n(v_x3_24155, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24156)) {
                                          case TAG_MkPair: {
                                            V v_x_24157 = heff_field(v_x31_24156, 0);
                                            V v_j_24158 = heff_field(v_x31_24156, 1);
                                            heff_take_n(v_x31_24156, 3ULL, 2);
                                            V v_x2_24159 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_str19), v_x_24157, MK_INT(0LL), NTAG(TAG_Nil)));
                                            V v_t_24162;
                                            switch (heff_tag_of(v_x2_24159)) {
                                            case TAG_Nil: {
                                              v_t_24162 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str20);
                                              break;
                                            }
                                            case TAG_Cons: {
                                              V v_x_24160 = heff_field(v_x2_24159, 0);
                                              V v_xs_24161 = heff_field(v_x2_24159, 1);
                                              heff_take_n(v_x2_24159, 3ULL, 2);
                                              v_t_24162 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str21); V a_1 = v_x_24160; V a_2 = v_xs_24161; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24161); r_; });
                                              break;
                                            }
                                            default: heff_nomatch(v_x2_24159);
                                            }
                                            double v_t_24163 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24162));
                                            V v_x_24164 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24163)});
                                            return heff_tag_at_n(v_ru_24x3_24155_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24164, v_j_24158})});
                                          }
                                          default: return heff_nomatch(v_x31_24156);
                                          }
                                        }
                                        default: return heff_nomatch(v_x3_24155);
                                        }
                                      } else {
                                        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str22))) {
                                          heff_drop(v_x2_241);
                                          V v_x3_24166 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                          switch (heff_tag_of(v_x3_24166)) {
                                          case TAG_Nothing: {
                                            return NTAG(TAG_Nothing);
                                          }
                                          case TAG_Just: {
                                            V v_x31_24167 = heff_field(v_x3_24166, 0);
                                            V v_ru_24x3_24166_24Just = heff_take_reuse_n(v_x3_24166, 1ULL, 1);
                                            switch (heff_tag_of(v_x31_24167)) {
                                            case TAG_MkPair: {
                                              V v_x_24168 = heff_field(v_x31_24167, 0);
                                              V v_j_24169 = heff_field(v_x31_24167, 1);
                                              V v_ru_24x31_24167_24MkPair = heff_take_reuse_n(v_x31_24167, 3ULL, 2);
                                              V v_t_24170 = heff_tag_at_n(v_ru_24x31_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24168}), v_j_24169});
                                              return heff_tag_at_n(v_ru_24x3_24166_24Just, TAG_Just, 1, (V[]){v_t_24170});
                                            }
                                            default: return heff_nomatch(v_x31_24167);
                                            }
                                          }
                                          default: return heff_nomatch(v_x3_24166);
                                          }
                                        } else {
                                          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str23))) {
                                            heff_drop(v_x2_241);
                                            V v_x3_24172 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                            switch (heff_tag_of(v_x3_24172)) {
                                            case TAG_Nothing: {
                                              return NTAG(TAG_Nothing);
                                            }
                                            case TAG_Just: {
                                              V v_x31_24173 = heff_field(v_x3_24172, 0);
                                              V v_ru_24x3_24172_24Just = heff_take_reuse_n(v_x3_24172, 1ULL, 1);
                                              switch (heff_tag_of(v_x31_24173)) {
                                              case TAG_MkPair: {
                                                V v_x_24174 = heff_field(v_x31_24173, 0);
                                                V v_j_24175 = heff_field(v_x31_24173, 1);
                                                V v_ru_24x31_24173_24MkPair = heff_take_reuse_n(v_x31_24173, 3ULL, 2);
                                                V v_t_24176 = heff_tag_at_n(v_ru_24x31_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24174}), v_j_24175});
                                                return heff_tag_at_n(v_ru_24x3_24172_24Just, TAG_Just, 1, (V[]){v_t_24176});
                                              }
                                              default: return heff_nomatch(v_x31_24173);
                                              }
                                            }
                                            default: return heff_nomatch(v_x3_24172);
                                            }
                                          } else {
                                            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str24))) {
                                              heff_drop(v_x2_241);
                                              V v_x3_24178 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                              switch (heff_tag_of(v_x3_24178)) {
                                              case TAG_Nothing: {
                                                return NTAG(TAG_Nothing);
                                              }
                                              case TAG_Just: {
                                                V v_x31_24179 = heff_field(v_x3_24178, 0);
                                                V v_ru_24x3_24178_24Just = heff_take_reuse_n(v_x3_24178, 1ULL, 1);
                                                switch (heff_tag_of(v_x31_24179)) {
                                                case TAG_MkPair: {
                                                  V v_x_24180 = heff_field(v_x31_24179, 0);
                                                  V v_j_24181 = heff_field(v_x31_24179, 1);
                                                  heff_take_n(v_x31_24179, 3ULL, 2);
                                                  V v_t_24182 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24180));
                                                  V v_x_24183 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24182});
                                                  return heff_tag_at_n(v_ru_24x3_24178_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24183, v_j_24181})});
                                                }
                                                default: return heff_nomatch(v_x31_24179);
                                                }
                                              }
                                              default: return heff_nomatch(v_x3_24178);
                                              }
                                            } else {
                                              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etermOf_str25))) {
                                                heff_drop(v_x2_241);
                                                V v_x3_24185 = (g_heff_2ebuild_2eserial_2etakeFixed(heff_dup(v_z_242), v_z_243));
                                                switch (heff_tag_of(v_x3_24185)) {
                                                case TAG_Nothing: {
                                                  heff_drop(v_z_242);
                                                  return NTAG(TAG_Nothing);
                                                }
                                                case TAG_Just: {
                                                  V v_x31_24186 = heff_field(v_x3_24185, 0);
                                                  V v_ru_24x3_24185_24Just = heff_take_reuse_n(v_x3_24185, 1ULL, 1);
                                                  switch (heff_tag_of(v_x31_24186)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24187 = heff_field(v_x31_24186, 0);
                                                    V v_j_24188 = heff_field(v_x31_24186, 1);
                                                    V v_ru_24x31_24186_24MkPair = heff_take_reuse_n(v_x31_24186, 3ULL, 2);
                                                    V v_x3_24189 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_j_24188));
                                                    switch (heff_tag_of(v_x3_24189)) {
                                                    case TAG_Nothing: {
                                                      heff_drop_cell(v_ru_24x3_24185_24Just, 1);
                                                      heff_drop(v_x_24187);
                                                      heff_drop_cell(v_ru_24x31_24186_24MkPair, 2);
                                                      return NTAG(TAG_Nothing);
                                                    }
                                                    case TAG_Just: {
                                                      V v_x31_24190 = heff_field(v_x3_24189, 0);
                                                      heff_take_n(v_x3_24189, 1ULL, 1);
                                                      switch (heff_tag_of(v_x31_24190)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24191 = heff_field(v_x31_24190, 0);
                                                        V v_j_24192 = heff_field(v_x31_24190, 1);
                                                        heff_take_n(v_x31_24190, 3ULL, 2);
                                                        V v_t_24193 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24191));
                                                        V v_x_24194 = heff_tag_at_n(v_ru_24x31_24186_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24187, v_t_24193});
                                                        return heff_tag_at_n(v_ru_24x3_24185_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24194, v_j_24192})});
                                                      }
                                                      default: return heff_nomatch(v_x31_24190);
                                                      }
                                                    }
                                                    default: return heff_nomatch(v_x3_24189);
                                                    }
                                                  }
                                                  default: return heff_nomatch(v_x31_24186);
                                                  }
                                                }
                                                default: return heff_nomatch(v_x3_24185);
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etermOf_str26))) {
                                                  V v_x3_24196 = (g_heff_2ebuild_2edecoder_2estr(v_z_242, v_z_243));
                                                  switch (heff_tag_of(v_x3_24196)) {
                                                  case TAG_Nothing: {
                                                    return NTAG(TAG_Nothing);
                                                  }
                                                  case TAG_Just: {
                                                    V v_x31_24197 = heff_field(v_x3_24196, 0);
                                                    V v_ru_24x3_24196_24Just = heff_take_reuse_n(v_x3_24196, 1ULL, 1);
                                                    switch (heff_tag_of(v_x31_24197)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24198 = heff_field(v_x31_24197, 0);
                                                      V v_j_24199 = heff_field(v_x31_24197, 1);
                                                      heff_take_n(v_x31_24197, 3ULL, 2);
                                                      V v_x2_24200 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_str27), v_x_24198, MK_INT(0LL), NTAG(TAG_Nil)));
                                                      V v_t_24203;
                                                      switch (heff_tag_of(v_x2_24200)) {
                                                      case TAG_Nil: {
                                                        v_t_24203 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str28);
                                                        break;
                                                      }
                                                      case TAG_Cons: {
                                                        V v_x_24201 = heff_field(v_x2_24200, 0);
                                                        V v_xs_24202 = heff_field(v_x2_24200, 1);
                                                        heff_take_n(v_x2_24200, 3ULL, 2);
                                                        v_t_24203 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_str29); V a_1 = v_x_24201; V a_2 = v_xs_24202; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24202); r_; });
                                                        break;
                                                      }
                                                      default: heff_nomatch(v_x2_24200);
                                                      }
                                                      double v_t_24204 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24203));
                                                      V v_x_24205 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24204)});
                                                      return heff_tag_at_n(v_ru_24x3_24196_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24205, v_j_24199})});
                                                    }
                                                    default: return heff_nomatch(v_x31_24197);
                                                    }
                                                  }
                                                  default: return heff_nomatch(v_x3_24196);
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_242; V a_1 = v_z_243; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etermOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2eserial_2edefaultOf_str1, 1, "n");
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args);
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args); static Clo g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_lam1, 2, 0};
Clo g_heff_2ebuild_2eserial_2edefaultOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2edefaultOf_entry, 2, 0};

V g_heff_2ebuild_2eserial_2edefaultOf(V v_k_240, V v_x2_241) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str0))) {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ebuild_2eserial_2edefaultOf_lam0, 2, 1, (V[]){v_k_240});
  } else {
    heff_drop_rec(v_k_240, 2);
    if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2edefaultOf_str1))) {
      return ((V)&g_heff_2ebuild_2eserial_2edefaultOf_lam1_clo);
    } else {
      return ((V)&g_heff_2ebuild_2edecoder_2efail_clo);
    }
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2edefaultOf(a[0], a[1]);
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_i_244 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_245 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_s_243, v_i_244}));
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_246 = heff_field(v_x3_245, 0);
    V v_ru_24x3_245_24Just = heff_take_reuse_n(v_x3_245, 1ULL, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x31_246, 0);
      V v_j_248 = heff_field(v_x31_246, 1);
      V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
      V v_t_249 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_245_24Just, TAG_Just, 1, (V[]){v_x_247}), v_j_248});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ebuild_2eserial_2edefaultOf_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_i_2412 = args[1];
  heff_drop(v_s_2411);
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_i_2412});
  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
}
Clo g_heff_2ebuild_2eserial_2etakeFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeFields_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etakeFields(V v_k_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_i_242));
  V v_x3_247;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_s_241);
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    heff_take_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      v_x3_247 = (g_heff_2ebuild_2edecoder_2etimes(heff_get_n(v_k_240, 1, 2), v_x_245, v_s_241, v_j_246));
      break;
    }
    default: heff_nomatch(v_x31_244);
    }
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_248 = heff_field(v_x3_247, 0);
    V v_ru_24x3_247_24Just = heff_take_reuse_n(v_x3_247, 1ULL, 1);
    switch (heff_tag_of(v_x31_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x31_248, 0);
      V v_j_2410 = heff_field(v_x31_248, 1);
      V v_ru_24x31_248_24MkPair = heff_take_reuse_n(v_x31_248, 3ULL, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x31_248_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_x_249), v_j_2410});
      return heff_tag_at_n(v_ru_24x3_247_24Just, TAG_Just, 1, (V[]){v_t_2411});
    }
    default: return heff_nomatch(v_x31_248);
    }
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2ebuild_2eserial_2etakeFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeFields(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_str11, 2, "px");
Clo g_heff_2ebuild_2eserial_2etypeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_entry, 4, 0};

V g_heff_2ebuild_2eserial_2etypeOf(V v_k_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str0))) {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_x2_241);
    return (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028(v_z_242, v_z_243));
  } else {
    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str1))) {
      heff_drop(v_x2_241);
      V v_x3_246 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 2, (V[]){v_z_242, v_z_243}));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
          V v_t_2410 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_x_248}), v_j_249});
          return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){v_t_2410});
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str2))) {
        heff_drop(v_x2_241);
        V v_x3_2412 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_z_242), v_z_243));
        switch (heff_tag_of(v_x3_2412)) {
        case TAG_Nothing: {
          heff_drop_rec(v_k_240, 2);
          heff_drop(v_z_242);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2413 = heff_field(v_x3_2412, 0);
          V v_ru_24x3_2412_24Just = heff_take_reuse_n(v_x3_2412, 1ULL, 1);
          switch (heff_tag_of(v_x31_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x31_2413, 0);
            V v_j_2415 = heff_field(v_x31_2413, 1);
            V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
            V v_x3_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 2, (V[]){heff_dup(v_z_242), v_j_2415}));
            switch (heff_tag_of(v_x3_2416)) {
            case TAG_Nothing: {
              heff_drop_rec(v_k_240, 2);
              heff_drop(v_z_242);
              heff_drop_cell(v_ru_24x3_2412_24Just, 1);
              heff_drop(v_x_2414);
              heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2417 = heff_field(v_x3_2416, 0);
              heff_take_n(v_x3_2416, 1ULL, 1);
              switch (heff_tag_of(v_x31_2417)) {
              case TAG_MkPair: {
                V v_x_2418 = heff_field(v_x31_2417, 0);
                V v_j_2419 = heff_field(v_x31_2417, 1);
                heff_take_n(v_x31_2417, 3ULL, 2);
                V v_x3_2420 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_242), v_j_2419));
                V v_x3_2424;
                switch (heff_tag_of(v_x3_2420)) {
                case TAG_Nothing: {
                  v_x3_2424 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_x31_2421 = heff_field(v_x3_2420, 0);
                  heff_take_n(v_x3_2420, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2421)) {
                  case TAG_MkPair: {
                    V v_x_2422 = heff_field(v_x31_2421, 0);
                    V v_j_2423 = heff_field(v_x31_2421, 1);
                    heff_take_n(v_x31_2421, 3ULL, 2);
                    v_x3_2424 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(v_k_240, 1)), v_x_2422, heff_dup(v_z_242), v_j_2423));
                    break;
                  }
                  default: heff_nomatch(v_x31_2421);
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2420);
                }
                switch (heff_tag_of(v_x3_2424)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_z_242);
                  heff_drop_cell(v_ru_24x3_2412_24Just, 1);
                  heff_drop(v_x_2414);
                  heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                  heff_drop(v_x_2418);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2425 = heff_field(v_x3_2424, 0);
                  heff_take_n(v_x3_2424, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2425)) {
                  case TAG_MkPair: {
                    V v_x_2426 = heff_field(v_x31_2425, 0);
                    V v_j_2427 = heff_field(v_x31_2425, 1);
                    heff_take_n(v_x31_2425, 3ULL, 2);
                    V v_x3_2428 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(heff_dup(v_z_242), v_j_2427));
                    switch (heff_tag_of(v_x3_2428)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_z_242);
                      heff_drop_cell(v_ru_24x3_2412_24Just, 1);
                      heff_drop(v_x_2414);
                      heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                      heff_drop(v_x_2418);
                      heff_drop(v_x_2426);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2429 = heff_field(v_x3_2428, 0);
                      heff_take_n(v_x3_2428, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2429)) {
                      case TAG_MkPair: {
                        V v_x_2430 = heff_field(v_x31_2429, 0);
                        V v_j_2431 = heff_field(v_x31_2429, 1);
                        heff_take_n(v_x31_2429, 3ULL, 2);
                        V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2edefaultOf_clo), 1, (V[]){v_k_240}));
                        V v_x3_2433 = heff_tr(g_heff_2ebuild_2edecoder_2ebind_24s1493159771x567775698(v_t_2432, v_z_242, v_j_2431));
                        switch (heff_tag_of(v_x3_2433)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x3_2412_24Just, 1);
                          heff_drop(v_x_2414);
                          heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                          heff_drop(v_x_2418);
                          heff_drop(v_x_2426);
                          heff_drop(v_x_2430);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2434 = heff_field(v_x3_2433, 0);
                          heff_take_n(v_x3_2433, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2434)) {
                          case TAG_MkPair: {
                            V v_x_2435 = heff_field(v_x31_2434, 0);
                            V v_j_2436 = heff_field(v_x31_2434, 1);
                            heff_take_n(v_x31_2434, 3ULL, 2);
                            V v_t_2437 = heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2414, v_x_2418, v_x_2426, v_x_2430, v_x_2435}), v_j_2436});
                            return heff_tag_at_n(v_ru_24x3_2412_24Just, TAG_Just, 1, (V[]){v_t_2437});
                          }
                          default: return heff_nomatch(v_x31_2434);
                          }
                        }
                        default: return heff_nomatch(v_x3_2433);
                        }
                      }
                      default: return heff_nomatch(v_x31_2429);
                      }
                    }
                    default: return heff_nomatch(v_x3_2428);
                    }
                  }
                  default: return heff_nomatch(v_x31_2425);
                  }
                }
                default: return heff_nomatch(v_x3_2424);
                }
              }
              default: return heff_nomatch(v_x31_2417);
              }
            }
            default: return heff_nomatch(v_x3_2416);
            }
          }
          default: return heff_nomatch(v_x31_2413);
          }
        }
        default: return heff_nomatch(v_x3_2412);
        }
      } else {
        if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str3))) {
          heff_drop(v_x2_241);
          V v_x3_2439 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_z_242), v_z_243));
          switch (heff_tag_of(v_x3_2439)) {
          case TAG_Nothing: {
            heff_drop_rec(v_k_240, 2);
            heff_drop(v_z_242);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2440 = heff_field(v_x3_2439, 0);
            V v_ru_24x3_2439_24Just = heff_take_reuse_n(v_x3_2439, 1ULL, 1);
            switch (heff_tag_of(v_x31_2440)) {
            case TAG_MkPair: {
              V v_x_2441 = heff_field(v_x31_2440, 0);
              V v_j_2442 = heff_field(v_x31_2440, 1);
              V v_ru_24x31_2440_24MkPair = heff_take_reuse_n(v_x31_2440, 3ULL, 2);
              V v_x3_2443 = (g_heff_2ebuild_2eserial_2etakeDict(heff_take_field(v_k_240, 1), heff_dup(v_z_242), v_j_2442));
              switch (heff_tag_of(v_x3_2443)) {
              case TAG_Nothing: {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_z_242);
                heff_drop_cell(v_ru_24x3_2439_24Just, 1);
                heff_drop(v_x_2441);
                heff_drop_cell(v_ru_24x31_2440_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2444 = heff_field(v_x3_2443, 0);
                heff_take_n(v_x3_2443, 1ULL, 1);
                switch (heff_tag_of(v_x31_2444)) {
                case TAG_MkPair: {
                  V v_x_2445 = heff_field(v_x31_2444, 0);
                  V v_j_2446 = heff_field(v_x31_2444, 1);
                  heff_take_n(v_x31_2444, 3ULL, 2);
                  V v_x3_2447 = (g_heff_2ebuild_2eserial_2etakeDict(heff_get_n(v_k_240, 0, 2), v_z_242, v_j_2446));
                  switch (heff_tag_of(v_x3_2447)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x3_2439_24Just, 1);
                    heff_drop(v_x_2441);
                    heff_drop_cell(v_ru_24x31_2440_24MkPair, 2);
                    heff_drop(v_x_2445);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2448 = heff_field(v_x3_2447, 0);
                    heff_take_n(v_x3_2447, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2448)) {
                    case TAG_MkPair: {
                      V v_x_2449 = heff_field(v_x31_2448, 0);
                      V v_j_2450 = heff_field(v_x31_2448, 1);
                      heff_take_n(v_x31_2448, 3ULL, 2);
                      V v_t_2451 = heff_tag_at_n(v_ru_24x31_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2441, v_x_2445, v_x_2449}), v_j_2450});
                      return heff_tag_at_n(v_ru_24x3_2439_24Just, TAG_Just, 1, (V[]){v_t_2451});
                    }
                    default: return heff_nomatch(v_x31_2448);
                    }
                  }
                  default: return heff_nomatch(v_x3_2447);
                  }
                }
                default: return heff_nomatch(v_x31_2444);
                }
              }
              default: return heff_nomatch(v_x3_2443);
              }
            }
            default: return heff_nomatch(v_x31_2440);
            }
          }
          default: return heff_nomatch(v_x3_2439);
          }
        } else {
          if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str4))) {
            heff_drop(v_x2_241);
            V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ebuild_2eserial_2etakeFields_clo), 1, (V[]){v_k_240}));
            V v_x3_2454 = (g_heff_2ebuild_2eserial_2etakeDict(v_t_2453, v_z_242, v_z_243));
            switch (heff_tag_of(v_x3_2454)) {
            case TAG_Nothing: {
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2455 = heff_field(v_x3_2454, 0);
              V v_ru_24x3_2454_24Just = heff_take_reuse_n(v_x3_2454, 1ULL, 1);
              switch (heff_tag_of(v_x31_2455)) {
              case TAG_MkPair: {
                V v_x_2456 = heff_field(v_x31_2455, 0);
                V v_j_2457 = heff_field(v_x31_2455, 1);
                V v_ru_24x31_2455_24MkPair = heff_take_reuse_n(v_x31_2455, 3ULL, 2);
                V v_t_2458 = heff_tag_at_n(v_ru_24x31_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2456}), v_j_2457});
                return heff_tag_at_n(v_ru_24x3_2454_24Just, TAG_Just, 1, (V[]){v_t_2458});
              }
              default: return heff_nomatch(v_x31_2455);
              }
            }
            default: return heff_nomatch(v_x3_2454);
            }
          } else {
            if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str5))) {
              heff_drop(v_x2_241);
              V v_x3_2460 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
              switch (heff_tag_of(v_x3_2460)) {
              case TAG_Nothing: {
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2461 = heff_field(v_x3_2460, 0);
                V v_ru_24x3_2460_24Just = heff_take_reuse_n(v_x3_2460, 1ULL, 1);
                switch (heff_tag_of(v_x31_2461)) {
                case TAG_MkPair: {
                  V v_x_2462 = heff_field(v_x31_2461, 0);
                  V v_j_2463 = heff_field(v_x31_2461, 1);
                  V v_ru_24x31_2461_24MkPair = heff_take_reuse_n(v_x31_2461, 3ULL, 2);
                  V v_t_2464 = heff_tag_at_n(v_ru_24x31_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2462}), v_j_2463});
                  return heff_tag_at_n(v_ru_24x3_2460_24Just, TAG_Just, 1, (V[]){v_t_2464});
                }
                default: return heff_nomatch(v_x31_2461);
                }
              }
              default: return heff_nomatch(v_x3_2460);
              }
            } else {
              if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str6))) {
                heff_drop_rec(v_k_240, 2);
                heff_drop(v_x2_241);
                heff_drop(v_z_242);
                V v_t_2466 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_243});
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2466});
              } else {
                if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str7))) {
                  heff_drop_rec(v_k_240, 2);
                  heff_drop(v_x2_241);
                  heff_drop(v_z_242);
                  V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_243});
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2468});
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str8))) {
                    heff_drop_rec(v_k_240, 2);
                    heff_drop(v_x2_241);
                    heff_drop(v_z_242);
                    V v_t_2470 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_243});
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2470});
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str9))) {
                      heff_drop_rec(v_k_240, 2);
                      heff_drop(v_x2_241);
                      heff_drop(v_z_242);
                      V v_t_2472 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_243});
                      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2472});
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_241), ((V)&g_heff_2ebuild_2eserial_2etypeOf_str10))) {
                        heff_drop(v_x2_241);
                        V v_x3_2474 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 2, (V[]){v_z_242, v_z_243}));
                        switch (heff_tag_of(v_x3_2474)) {
                        case TAG_Nothing: {
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2475 = heff_field(v_x3_2474, 0);
                          V v_ru_24x3_2474_24Just = heff_take_reuse_n(v_x3_2474, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2475)) {
                          case TAG_MkPair: {
                            V v_x_2476 = heff_field(v_x31_2475, 0);
                            V v_j_2477 = heff_field(v_x31_2475, 1);
                            V v_ru_24x31_2475_24MkPair = heff_take_reuse_n(v_x31_2475, 3ULL, 2);
                            V v_t_2478 = heff_tag_at_n(v_ru_24x31_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2476}), v_j_2477});
                            return heff_tag_at_n(v_ru_24x3_2474_24Just, TAG_Just, 1, (V[]){v_t_2478});
                          }
                          default: return heff_nomatch(v_x31_2475);
                          }
                        }
                        default: return heff_nomatch(v_x3_2474);
                        }
                      } else {
                        heff_drop_rec(v_k_240, 2);
                        if (heff_strEq_c(v_x2_241, ((V)&g_heff_2ebuild_2eserial_2etypeOf_str11))) {
                          V v_x3_2480 = (g_heff_2ebuild_2eserial_2etakeFixed(v_z_242, v_z_243));
                          switch (heff_tag_of(v_x3_2480)) {
                          case TAG_Nothing: {
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_2481 = heff_field(v_x3_2480, 0);
                            V v_ru_24x3_2480_24Just = heff_take_reuse_n(v_x3_2480, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2481)) {
                            case TAG_MkPair: {
                              V v_x_2482 = heff_field(v_x31_2481, 0);
                              V v_j_2483 = heff_field(v_x31_2481, 1);
                              V v_ru_24x31_2481_24MkPair = heff_take_reuse_n(v_x31_2481, 3ULL, 2);
                              V v_t_2484 = heff_tag_at_n(v_ru_24x31_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_2482}), v_j_2483});
                              return heff_tag_at_n(v_ru_24x3_2480_24Just, TAG_Just, 1, (V[]){v_t_2484});
                            }
                            default: return heff_nomatch(v_x31_2481);
                            }
                          }
                          default: return heff_nomatch(v_x3_2480);
                          }
                        } else {
                          return ({ V a_0 = v_z_242; V a_1 = v_z_243; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_242); heff_drop(v_z_243); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etypeOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str0, 3, "loc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str1, 3, "glo");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str2, 3, "cod");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str3, 3, "app");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str4, 3, "lam");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str5, 3, "con");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str6, 3, "prj");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str7, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str8, 3, "mat");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str9, 3, "spe");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str10, 2, "is");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str11, 3, "opq");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str12, 3, "abn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str13, 3, "rec");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str14, 3, "fix");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str15, 3, "imp");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str16, 3, "prm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str17, 3, "int");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str18, 3, "flt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str19, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str22, 3, "str");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str23, 3, "byt");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str24, 2, "rn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str25, 3, "fxl");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str26, 3, "f32");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str27, 1, "_");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str29, 0, "");
Clo g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str0))) {
    heff_drop(v_x2_240);
    V v_x3_244 = (g_heff_2ebuild_2edecoder_2eint(v_z_241, v_z_242));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        V v_t_248 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_x_246}), v_j_247});
        return heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){v_t_248});
      }
      default: return heff_nomatch(v_x31_245);
      }
    }
    default: return heff_nomatch(v_x3_244);
    }
  } else {
    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str1))) {
      heff_drop(v_x2_240);
      V v_x3_2410 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
      switch (heff_tag_of(v_x3_2410)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2411 = heff_field(v_x3_2410, 0);
        V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
        switch (heff_tag_of(v_x31_2411)) {
        case TAG_MkPair: {
          V v_x_2412 = heff_field(v_x31_2411, 0);
          V v_j_2413 = heff_field(v_x31_2411, 1);
          V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
          V v_t_2414 = heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2412}), v_j_2413});
          return heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_Just, 1, (V[]){v_t_2414});
        }
        default: return heff_nomatch(v_x31_2411);
        }
      }
      default: return heff_nomatch(v_x3_2410);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str2))) {
        heff_drop(v_x2_240);
        V v_x3_2416 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
        V v_x3_2420;
        switch (heff_tag_of(v_x3_2416)) {
        case TAG_Nothing: {
          heff_drop(v_z_241);
          v_x3_2420 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x31_2417 = heff_field(v_x3_2416, 0);
          heff_take_n(v_x3_2416, 1ULL, 1);
          switch (heff_tag_of(v_x31_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x31_2417, 0);
            V v_j_2419 = heff_field(v_x31_2417, 1);
            heff_take_n(v_x31_2417, 3ULL, 2);
            v_x3_2420 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2418, v_z_241, v_j_2419));
            break;
          }
          default: heff_nomatch(v_x31_2417);
          }
          break;
        }
        default: heff_nomatch(v_x3_2416);
        }
        switch (heff_tag_of(v_x3_2420)) {
        case TAG_Nothing: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2421 = heff_field(v_x3_2420, 0);
          V v_ru_24x3_2420_24Just = heff_take_reuse_n(v_x3_2420, 1ULL, 1);
          switch (heff_tag_of(v_x31_2421)) {
          case TAG_MkPair: {
            V v_x_2422 = heff_field(v_x31_2421, 0);
            V v_j_2423 = heff_field(v_x31_2421, 1);
            V v_ru_24x31_2421_24MkPair = heff_take_reuse_n(v_x31_2421, 3ULL, 2);
            V v_t_2424 = heff_tag_at_n(v_ru_24x31_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_x_2422}), v_j_2423});
            return heff_tag_at_n(v_ru_24x3_2420_24Just, TAG_Just, 1, (V[]){v_t_2424});
          }
          default: return heff_nomatch(v_x31_2421);
          }
        }
        default: return heff_nomatch(v_x3_2420);
        }
      } else {
        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str3))) {
          heff_drop(v_x2_240);
          V v_x3_2426 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
          V v_x3_2430;
          switch (heff_tag_of(v_x3_2426)) {
          case TAG_Nothing: {
            v_x3_2430 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2427 = heff_field(v_x3_2426, 0);
            heff_take_n(v_x3_2426, 1ULL, 1);
            switch (heff_tag_of(v_x31_2427)) {
            case TAG_MkPair: {
              V v_x_2428 = heff_field(v_x31_2427, 0);
              V v_j_2429 = heff_field(v_x31_2427, 1);
              heff_take_n(v_x31_2427, 3ULL, 2);
              v_x3_2430 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2428, heff_dup(v_z_241), v_j_2429));
              break;
            }
            default: heff_nomatch(v_x31_2427);
            }
            break;
          }
          default: heff_nomatch(v_x3_2426);
          }
          switch (heff_tag_of(v_x3_2430)) {
          case TAG_Nothing: {
            heff_drop(v_z_241);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2431 = heff_field(v_x3_2430, 0);
            V v_ru_24x3_2430_24Just = heff_take_reuse_n(v_x3_2430, 1ULL, 1);
            switch (heff_tag_of(v_x31_2431)) {
            case TAG_MkPair: {
              V v_x_2432 = heff_field(v_x31_2431, 0);
              V v_j_2433 = heff_field(v_x31_2431, 1);
              V v_ru_24x31_2431_24MkPair = heff_take_reuse_n(v_x31_2431, 3ULL, 2);
              V v_x3_2434 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_j_2433));
              V v_x3_2438;
              switch (heff_tag_of(v_x3_2434)) {
              case TAG_Nothing: {
                heff_drop(v_z_241);
                v_x3_2438 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2435 = heff_field(v_x3_2434, 0);
                heff_take_n(v_x3_2434, 1ULL, 1);
                switch (heff_tag_of(v_x31_2435)) {
                case TAG_MkPair: {
                  V v_x_2436 = heff_field(v_x31_2435, 0);
                  V v_j_2437 = heff_field(v_x31_2435, 1);
                  heff_take_n(v_x31_2435, 3ULL, 2);
                  v_x3_2438 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2436, v_z_241, v_j_2437));
                  break;
                }
                default: heff_nomatch(v_x31_2435);
                }
                break;
              }
              default: heff_nomatch(v_x3_2434);
              }
              switch (heff_tag_of(v_x3_2438)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x3_2430_24Just, 1);
                heff_drop(v_x_2432);
                heff_drop_cell(v_ru_24x31_2431_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2439 = heff_field(v_x3_2438, 0);
                heff_take_n(v_x3_2438, 1ULL, 1);
                switch (heff_tag_of(v_x31_2439)) {
                case TAG_MkPair: {
                  V v_x_2440 = heff_field(v_x31_2439, 0);
                  V v_j_2441 = heff_field(v_x31_2439, 1);
                  heff_take_n(v_x31_2439, 3ULL, 2);
                  V v_t_2442 = heff_tag_at_n(v_ru_24x31_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_x_2432, v_x_2440}), v_j_2441});
                  return heff_tag_at_n(v_ru_24x3_2430_24Just, TAG_Just, 1, (V[]){v_t_2442});
                }
                default: return heff_nomatch(v_x31_2439);
                }
              }
              default: return heff_nomatch(v_x3_2438);
              }
            }
            default: return heff_nomatch(v_x31_2431);
            }
          }
          default: return heff_nomatch(v_x3_2430);
          }
        } else {
          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str4))) {
            heff_drop(v_x2_240);
            V v_x3_2444 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
            V v_x3_2448;
            switch (heff_tag_of(v_x3_2444)) {
            case TAG_Nothing: {
              v_x3_2448 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_x31_2445 = heff_field(v_x3_2444, 0);
              heff_take_n(v_x3_2444, 1ULL, 1);
              switch (heff_tag_of(v_x31_2445)) {
              case TAG_MkPair: {
                V v_x_2446 = heff_field(v_x31_2445, 0);
                V v_j_2447 = heff_field(v_x31_2445, 1);
                heff_take_n(v_x31_2445, 3ULL, 2);
                v_x3_2448 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2446, heff_dup(v_z_241), v_j_2447));
                break;
              }
              default: heff_nomatch(v_x31_2445);
              }
              break;
            }
            default: heff_nomatch(v_x3_2444);
            }
            switch (heff_tag_of(v_x3_2448)) {
            case TAG_Nothing: {
              heff_drop(v_z_241);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2449 = heff_field(v_x3_2448, 0);
              V v_ru_24x3_2448_24Just = heff_take_reuse_n(v_x3_2448, 1ULL, 1);
              switch (heff_tag_of(v_x31_2449)) {
              case TAG_MkPair: {
                V v_x_2450 = heff_field(v_x31_2449, 0);
                V v_j_2451 = heff_field(v_x31_2449, 1);
                V v_ru_24x31_2449_24MkPair = heff_take_reuse_n(v_x31_2449, 3ULL, 2);
                V v_x3_2452 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_j_2451));
                V v_x3_2456;
                switch (heff_tag_of(v_x3_2452)) {
                case TAG_Nothing: {
                  heff_drop(v_z_241);
                  v_x3_2456 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_x31_2453 = heff_field(v_x3_2452, 0);
                  heff_take_n(v_x3_2452, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2453)) {
                  case TAG_MkPair: {
                    V v_x_2454 = heff_field(v_x31_2453, 0);
                    V v_j_2455 = heff_field(v_x31_2453, 1);
                    heff_take_n(v_x31_2453, 3ULL, 2);
                    v_x3_2456 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_2454, v_z_241, v_j_2455));
                    break;
                  }
                  default: heff_nomatch(v_x31_2453);
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2452);
                }
                switch (heff_tag_of(v_x3_2456)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24x3_2448_24Just, 1);
                  heff_drop(v_x_2450);
                  heff_drop_cell(v_ru_24x31_2449_24MkPair, 2);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2457 = heff_field(v_x3_2456, 0);
                  heff_take_n(v_x3_2456, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2457)) {
                  case TAG_MkPair: {
                    V v_x_2458 = heff_field(v_x31_2457, 0);
                    V v_j_2459 = heff_field(v_x31_2457, 1);
                    heff_take_n(v_x31_2457, 3ULL, 2);
                    V v_t_2460 = heff_tag_at_n(v_ru_24x31_2449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_x_2450, v_x_2458}), v_j_2459});
                    return heff_tag_at_n(v_ru_24x3_2448_24Just, TAG_Just, 1, (V[]){v_t_2460});
                  }
                  default: return heff_nomatch(v_x31_2457);
                  }
                }
                default: return heff_nomatch(v_x3_2456);
                }
              }
              default: return heff_nomatch(v_x31_2449);
              }
            }
            default: return heff_nomatch(v_x3_2448);
            }
          } else {
            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str5))) {
              heff_drop(v_x2_240);
              V v_x3_2462 = (g_heff_2ebuild_2eserial_2etakeDict(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_z_242));
              switch (heff_tag_of(v_x3_2462)) {
              case TAG_Nothing: {
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2463 = heff_field(v_x3_2462, 0);
                V v_ru_24x3_2462_24Just = heff_take_reuse_n(v_x3_2462, 1ULL, 1);
                switch (heff_tag_of(v_x31_2463)) {
                case TAG_MkPair: {
                  V v_x_2464 = heff_field(v_x31_2463, 0);
                  V v_j_2465 = heff_field(v_x31_2463, 1);
                  V v_ru_24x31_2463_24MkPair = heff_take_reuse_n(v_x31_2463, 3ULL, 2);
                  V v_t_2466 = heff_tag_at_n(v_ru_24x31_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SCons, 1, (V[]){v_x_2464}), v_j_2465});
                  return heff_tag_at_n(v_ru_24x3_2462_24Just, TAG_Just, 1, (V[]){v_t_2466});
                }
                default: return heff_nomatch(v_x31_2463);
                }
              }
              default: return heff_nomatch(v_x3_2462);
              }
            } else {
              if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str6))) {
                heff_drop(v_x2_240);
                V v_x3_2468 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
                V v_x3_2472;
                switch (heff_tag_of(v_x3_2468)) {
                case TAG_Nothing: {
                  v_x3_2472 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_x31_2469 = heff_field(v_x3_2468, 0);
                  heff_take_n(v_x3_2468, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2469)) {
                  case TAG_MkPair: {
                    V v_x_2470 = heff_field(v_x31_2469, 0);
                    V v_j_2471 = heff_field(v_x31_2469, 1);
                    heff_take_n(v_x31_2469, 3ULL, 2);
                    v_x3_2472 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2470, heff_dup(v_z_241), v_j_2471));
                    break;
                  }
                  default: heff_nomatch(v_x31_2469);
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2468);
                }
                switch (heff_tag_of(v_x3_2472)) {
                case TAG_Nothing: {
                  heff_drop(v_z_241);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2473 = heff_field(v_x3_2472, 0);
                  V v_ru_24x3_2472_24Just = heff_take_reuse_n(v_x3_2472, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2473)) {
                  case TAG_MkPair: {
                    V v_x_2474 = heff_field(v_x31_2473, 0);
                    V v_j_2475 = heff_field(v_x31_2473, 1);
                    V v_ru_24x31_2473_24MkPair = heff_take_reuse_n(v_x31_2473, 3ULL, 2);
                    V v_x3_2476 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_j_2475));
                    switch (heff_tag_of(v_x3_2476)) {
                    case TAG_Nothing: {
                      heff_drop_cell(v_ru_24x3_2472_24Just, 1);
                      heff_drop(v_x_2474);
                      heff_drop_cell(v_ru_24x31_2473_24MkPair, 2);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2477 = heff_field(v_x3_2476, 0);
                      heff_take_n(v_x3_2476, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2477)) {
                      case TAG_MkPair: {
                        V v_x_2478 = heff_field(v_x31_2477, 0);
                        V v_j_2479 = heff_field(v_x31_2477, 1);
                        heff_take_n(v_x31_2477, 3ULL, 2);
                        V v_t_2480 = heff_tag_at_n(v_ru_24x31_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SProj, 2, (V[]){v_x_2474, v_x_2478}), v_j_2479});
                        return heff_tag_at_n(v_ru_24x3_2472_24Just, TAG_Just, 1, (V[]){v_t_2480});
                      }
                      default: return heff_nomatch(v_x31_2477);
                      }
                    }
                    default: return heff_nomatch(v_x3_2476);
                    }
                  }
                  default: return heff_nomatch(v_x31_2473);
                  }
                }
                default: return heff_nomatch(v_x3_2472);
                }
              } else {
                if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str7))) {
                  heff_drop(v_x2_240);
                  V v_x3_2482 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_241), v_z_242));
                  switch (heff_tag_of(v_x3_2482)) {
                  case TAG_Nothing: {
                    heff_drop(v_z_241);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2483 = heff_field(v_x3_2482, 0);
                    V v_ru_24x3_2482_24Just = heff_take_reuse_n(v_x3_2482, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2483)) {
                    case TAG_MkPair: {
                      V v_x_2484 = heff_field(v_x31_2483, 0);
                      V v_j_2485 = heff_field(v_x31_2483, 1);
                      V v_ru_24x31_2483_24MkPair = heff_take_reuse_n(v_x31_2483, 3ULL, 2);
                      V v_x3_2486 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_241), v_j_2485));
                      V v_x3_2490;
                      switch (heff_tag_of(v_x3_2486)) {
                      case TAG_Nothing: {
                        heff_drop(v_z_241);
                        v_x3_2490 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_2487 = heff_field(v_x3_2486, 0);
                        heff_take_n(v_x3_2486, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2487)) {
                        case TAG_MkPair: {
                          V v_x_2488 = heff_field(v_x31_2487, 0);
                          V v_j_2489 = heff_field(v_x31_2487, 1);
                          heff_take_n(v_x31_2487, 3ULL, 2);
                          v_x3_2490 = (g_heff_2ebuild_2edecoder_2etimes(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_2488, v_z_241, v_j_2489));
                          break;
                        }
                        default: heff_nomatch(v_x31_2487);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_2486);
                      }
                      switch (heff_tag_of(v_x3_2490)) {
                      case TAG_Nothing: {
                        heff_drop_cell(v_ru_24x3_2482_24Just, 1);
                        heff_drop(v_x_2484);
                        heff_drop_cell(v_ru_24x31_2483_24MkPair, 2);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_2491 = heff_field(v_x3_2490, 0);
                        heff_take_n(v_x3_2490, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2491)) {
                        case TAG_MkPair: {
                          V v_x_2492 = heff_field(v_x31_2491, 0);
                          V v_j_2493 = heff_field(v_x31_2491, 1);
                          heff_take_n(v_x31_2491, 3ULL, 2);
                          V v_t_2494 = heff_tag_at_n(v_ru_24x31_2483_24MkPair, TAG_STag, 2, (V[]){v_x_2484, heff_arrayFromList(v_x_2492)});
                          return heff_tag_at_n(v_ru_24x3_2482_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2494, v_j_2493})});
                        }
                        default: return heff_nomatch(v_x31_2491);
                        }
                      }
                      default: return heff_nomatch(v_x3_2490);
                      }
                    }
                    default: return heff_nomatch(v_x31_2483);
                    }
                  }
                  default: return heff_nomatch(v_x3_2482);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str8))) {
                    heff_drop(v_x2_240);
                    V v_x3_2496 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
                    V v_x3_24100;
                    switch (heff_tag_of(v_x3_2496)) {
                    case TAG_Nothing: {
                      v_x3_24100 = NTAG(TAG_Nothing);
                      break;
                    }
                    case TAG_Just: {
                      V v_x31_2497 = heff_field(v_x3_2496, 0);
                      heff_take_n(v_x3_2496, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2497)) {
                      case TAG_MkPair: {
                        V v_x_2498 = heff_field(v_x31_2497, 0);
                        V v_j_2499 = heff_field(v_x31_2497, 1);
                        heff_take_n(v_x31_2497, 3ULL, 2);
                        v_x3_24100 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_2498, heff_dup(v_z_241), v_j_2499));
                        break;
                      }
                      default: heff_nomatch(v_x31_2497);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x3_2496);
                    }
                    switch (heff_tag_of(v_x3_24100)) {
                    case TAG_Nothing: {
                      heff_drop(v_z_241);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_24101 = heff_field(v_x3_24100, 0);
                      V v_ru_24x3_24100_24Just = heff_take_reuse_n(v_x3_24100, 1ULL, 1);
                      switch (heff_tag_of(v_x31_24101)) {
                      case TAG_MkPair: {
                        V v_x_24102 = heff_field(v_x31_24101, 0);
                        V v_j_24103 = heff_field(v_x31_24101, 1);
                        V v_ru_24x31_24101_24MkPair = heff_take_reuse_n(v_x31_24101, 3ULL, 2);
                        V v_x3_24104 = (g_heff_2ebuild_2eserial_2etakeDict_24s4476416x244075826(v_z_241, v_j_24103));
                        switch (heff_tag_of(v_x3_24104)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x3_24100_24Just, 1);
                          heff_drop(v_x_24102);
                          heff_drop_cell(v_ru_24x31_24101_24MkPair, 2);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_24105 = heff_field(v_x3_24104, 0);
                          heff_take_n(v_x3_24104, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24105)) {
                          case TAG_MkPair: {
                            V v_x_24106 = heff_field(v_x31_24105, 0);
                            V v_j_24107 = heff_field(v_x31_24105, 1);
                            heff_take_n(v_x31_24105, 3ULL, 2);
                            V v_t_24108 = heff_tag_at_n(v_ru_24x31_24101_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SMatch, 2, (V[]){v_x_24102, v_x_24106}), v_j_24107});
                            return heff_tag_at_n(v_ru_24x3_24100_24Just, TAG_Just, 1, (V[]){v_t_24108});
                          }
                          default: return heff_nomatch(v_x31_24105);
                          }
                        }
                        default: return heff_nomatch(v_x3_24104);
                        }
                      }
                      default: return heff_nomatch(v_x31_24101);
                      }
                    }
                    default: return heff_nomatch(v_x3_24100);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str9))) {
                      heff_drop(v_x2_240);
                      V v_x3_24110 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
                      V v_x3_24114;
                      switch (heff_tag_of(v_x3_24110)) {
                      case TAG_Nothing: {
                        v_x3_24114 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_24111 = heff_field(v_x3_24110, 0);
                        heff_take_n(v_x3_24110, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24111)) {
                        case TAG_MkPair: {
                          V v_x_24112 = heff_field(v_x31_24111, 0);
                          V v_j_24113 = heff_field(v_x31_24111, 1);
                          heff_take_n(v_x31_24111, 3ULL, 2);
                          v_x3_24114 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24112, heff_dup(v_z_241), v_j_24113));
                          break;
                        }
                        default: heff_nomatch(v_x31_24111);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_24110);
                      }
                      switch (heff_tag_of(v_x3_24114)) {
                      case TAG_Nothing: {
                        heff_drop(v_z_241);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_24115 = heff_field(v_x3_24114, 0);
                        V v_ru_24x3_24114_24Just = heff_take_reuse_n(v_x3_24114, 1ULL, 1);
                        switch (heff_tag_of(v_x31_24115)) {
                        case TAG_MkPair: {
                          V v_x_24116 = heff_field(v_x31_24115, 0);
                          V v_j_24117 = heff_field(v_x31_24115, 1);
                          V v_ru_24x31_24115_24MkPair = heff_take_reuse_n(v_x31_24115, 3ULL, 2);
                          V v_x3_24118 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_241), v_j_24117));
                          switch (heff_tag_of(v_x3_24118)) {
                          case TAG_Nothing: {
                            heff_drop(v_z_241);
                            heff_drop_cell(v_ru_24x3_24114_24Just, 1);
                            heff_drop(v_x_24116);
                            heff_drop_cell(v_ru_24x31_24115_24MkPair, 2);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_24119 = heff_field(v_x3_24118, 0);
                            heff_take_n(v_x3_24118, 1ULL, 1);
                            switch (heff_tag_of(v_x31_24119)) {
                            case TAG_MkPair: {
                              V v_x_24120 = heff_field(v_x31_24119, 0);
                              V v_j_24121 = heff_field(v_x31_24119, 1);
                              heff_take_n(v_x31_24119, 3ULL, 2);
                              V v_x3_24122 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_j_24121));
                              V v_x3_24126;
                              switch (heff_tag_of(v_x3_24122)) {
                              case TAG_Nothing: {
                                heff_drop(v_z_241);
                                v_x3_24126 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x31_24123 = heff_field(v_x3_24122, 0);
                                heff_take_n(v_x3_24122, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24123)) {
                                case TAG_MkPair: {
                                  V v_x_24124 = heff_field(v_x31_24123, 0);
                                  V v_j_24125 = heff_field(v_x31_24123, 1);
                                  heff_take_n(v_x31_24123, 3ULL, 2);
                                  v_x3_24126 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24124, v_z_241, v_j_24125));
                                  break;
                                }
                                default: heff_nomatch(v_x31_24123);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x3_24122);
                              }
                              switch (heff_tag_of(v_x3_24126)) {
                              case TAG_Nothing: {
                                heff_drop_cell(v_ru_24x3_24114_24Just, 1);
                                heff_drop(v_x_24116);
                                heff_drop_cell(v_ru_24x31_24115_24MkPair, 2);
                                heff_drop(v_x_24120);
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_24127 = heff_field(v_x3_24126, 0);
                                heff_take_n(v_x3_24126, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24127)) {
                                case TAG_MkPair: {
                                  V v_x_24128 = heff_field(v_x31_24127, 0);
                                  V v_j_24129 = heff_field(v_x31_24127, 1);
                                  heff_take_n(v_x31_24127, 3ULL, 2);
                                  V v_t_24130 = heff_tag_at_n(v_ru_24x31_24115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_24116, v_x_24120, v_x_24128}), v_j_24129});
                                  return heff_tag_at_n(v_ru_24x3_24114_24Just, TAG_Just, 1, (V[]){v_t_24130});
                                }
                                default: return heff_nomatch(v_x31_24127);
                                }
                              }
                              default: return heff_nomatch(v_x3_24126);
                              }
                            }
                            default: return heff_nomatch(v_x31_24119);
                            }
                          }
                          default: return heff_nomatch(v_x3_24118);
                          }
                        }
                        default: return heff_nomatch(v_x31_24115);
                        }
                      }
                      default: return heff_nomatch(v_x3_24114);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str10))) {
                        heff_drop(v_x2_240);
                        V v_x3_24132 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
                        V v_x3_24136;
                        switch (heff_tag_of(v_x3_24132)) {
                        case TAG_Nothing: {
                          heff_drop(v_z_241);
                          v_x3_24136 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x31_24133 = heff_field(v_x3_24132, 0);
                          heff_take_n(v_x3_24132, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24133)) {
                          case TAG_MkPair: {
                            V v_x_24134 = heff_field(v_x31_24133, 0);
                            V v_j_24135 = heff_field(v_x31_24133, 1);
                            heff_take_n(v_x31_24133, 3ULL, 2);
                            v_x3_24136 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24134, v_z_241, v_j_24135));
                            break;
                          }
                          default: heff_nomatch(v_x31_24133);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x3_24132);
                        }
                        switch (heff_tag_of(v_x3_24136)) {
                        case TAG_Nothing: {
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_24137 = heff_field(v_x3_24136, 0);
                          V v_ru_24x3_24136_24Just = heff_take_reuse_n(v_x3_24136, 1ULL, 1);
                          switch (heff_tag_of(v_x31_24137)) {
                          case TAG_MkPair: {
                            V v_x_24138 = heff_field(v_x31_24137, 0);
                            V v_j_24139 = heff_field(v_x31_24137, 1);
                            V v_ru_24x31_24137_24MkPair = heff_take_reuse_n(v_x31_24137, 3ULL, 2);
                            V v_t_24140 = heff_tag_at_n(v_ru_24x31_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIs, 1, (V[]){v_x_24138}), v_j_24139});
                            return heff_tag_at_n(v_ru_24x3_24136_24Just, TAG_Just, 1, (V[]){v_t_24140});
                          }
                          default: return heff_nomatch(v_x31_24137);
                          }
                        }
                        default: return heff_nomatch(v_x3_24136);
                        }
                      } else {
                        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str11))) {
                          heff_drop(v_x2_240);
                          heff_drop(v_z_241);
                          V v_t_24142 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SOpaque), v_z_242});
                          return heff_tag_n(TAG_Just, 1, (V[]){v_t_24142});
                        } else {
                          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str12))) {
                            heff_drop(v_x2_240);
                            heff_drop(v_z_241);
                            V v_t_24144 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SAbandon), v_z_242});
                            return heff_tag_n(TAG_Just, 1, (V[]){v_t_24144});
                          } else {
                            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str13))) {
                              heff_drop(v_x2_240);
                              V v_x3_24146 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
                              V v_x3_24150;
                              switch (heff_tag_of(v_x3_24146)) {
                              case TAG_Nothing: {
                                heff_drop(v_z_241);
                                v_x3_24150 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x31_24147 = heff_field(v_x3_24146, 0);
                                heff_take_n(v_x3_24146, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24147)) {
                                case TAG_MkPair: {
                                  V v_x_24148 = heff_field(v_x31_24147, 0);
                                  V v_j_24149 = heff_field(v_x31_24147, 1);
                                  heff_take_n(v_x31_24147, 3ULL, 2);
                                  v_x3_24150 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24148, v_z_241, v_j_24149));
                                  break;
                                }
                                default: heff_nomatch(v_x31_24147);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x3_24146);
                              }
                              switch (heff_tag_of(v_x3_24150)) {
                              case TAG_Nothing: {
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_24151 = heff_field(v_x3_24150, 0);
                                V v_ru_24x3_24150_24Just = heff_take_reuse_n(v_x3_24150, 1ULL, 1);
                                switch (heff_tag_of(v_x31_24151)) {
                                case TAG_MkPair: {
                                  V v_x_24152 = heff_field(v_x31_24151, 0);
                                  V v_j_24153 = heff_field(v_x31_24151, 1);
                                  V v_ru_24x31_24151_24MkPair = heff_take_reuse_n(v_x31_24151, 3ULL, 2);
                                  V v_t_24154 = heff_tag_at_n(v_ru_24x31_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRec, 1, (V[]){v_x_24152}), v_j_24153});
                                  return heff_tag_at_n(v_ru_24x3_24150_24Just, TAG_Just, 1, (V[]){v_t_24154});
                                }
                                default: return heff_nomatch(v_x31_24151);
                                }
                              }
                              default: return heff_nomatch(v_x3_24150);
                              }
                            } else {
                              if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str14))) {
                                heff_drop(v_x2_240);
                                V v_x3_24156 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
                                V v_x3_24160;
                                switch (heff_tag_of(v_x3_24156)) {
                                case TAG_Nothing: {
                                  v_x3_24160 = NTAG(TAG_Nothing);
                                  break;
                                }
                                case TAG_Just: {
                                  V v_x31_24157 = heff_field(v_x3_24156, 0);
                                  heff_take_n(v_x3_24156, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24157)) {
                                  case TAG_MkPair: {
                                    V v_x_24158 = heff_field(v_x31_24157, 0);
                                    V v_j_24159 = heff_field(v_x31_24157, 1);
                                    heff_take_n(v_x31_24157, 3ULL, 2);
                                    v_x3_24160 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_24158, heff_dup(v_z_241), v_j_24159));
                                    break;
                                  }
                                  default: heff_nomatch(v_x31_24157);
                                  }
                                  break;
                                }
                                default: heff_nomatch(v_x3_24156);
                                }
                                switch (heff_tag_of(v_x3_24160)) {
                                case TAG_Nothing: {
                                  heff_drop(v_z_241);
                                  return NTAG(TAG_Nothing);
                                }
                                case TAG_Just: {
                                  V v_x31_24161 = heff_field(v_x3_24160, 0);
                                  V v_ru_24x3_24160_24Just = heff_take_reuse_n(v_x3_24160, 1ULL, 1);
                                  switch (heff_tag_of(v_x31_24161)) {
                                  case TAG_MkPair: {
                                    V v_x_24162 = heff_field(v_x31_24161, 0);
                                    V v_j_24163 = heff_field(v_x31_24161, 1);
                                    V v_ru_24x31_24161_24MkPair = heff_take_reuse_n(v_x31_24161, 3ULL, 2);
                                    V v_x3_24164 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_j_24163));
                                    V v_x3_24168;
                                    switch (heff_tag_of(v_x3_24164)) {
                                    case TAG_Nothing: {
                                      heff_drop(v_z_241);
                                      v_x3_24168 = NTAG(TAG_Nothing);
                                      break;
                                    }
                                    case TAG_Just: {
                                      V v_x31_24165 = heff_field(v_x3_24164, 0);
                                      heff_take_n(v_x3_24164, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24165)) {
                                      case TAG_MkPair: {
                                        V v_x_24166 = heff_field(v_x31_24165, 0);
                                        V v_j_24167 = heff_field(v_x31_24165, 1);
                                        heff_take_n(v_x31_24165, 3ULL, 2);
                                        v_x3_24168 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_x_24166, v_z_241, v_j_24167));
                                        break;
                                      }
                                      default: heff_nomatch(v_x31_24165);
                                      }
                                      break;
                                    }
                                    default: heff_nomatch(v_x3_24164);
                                    }
                                    switch (heff_tag_of(v_x3_24168)) {
                                    case TAG_Nothing: {
                                      heff_drop_cell(v_ru_24x3_24160_24Just, 1);
                                      heff_drop(v_x_24162);
                                      heff_drop_cell(v_ru_24x31_24161_24MkPair, 2);
                                      return NTAG(TAG_Nothing);
                                    }
                                    case TAG_Just: {
                                      V v_x31_24169 = heff_field(v_x3_24168, 0);
                                      heff_take_n(v_x3_24168, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24169)) {
                                      case TAG_MkPair: {
                                        V v_x_24170 = heff_field(v_x31_24169, 0);
                                        V v_j_24171 = heff_field(v_x31_24169, 1);
                                        heff_take_n(v_x31_24169, 3ULL, 2);
                                        V v_t_24172 = heff_tag_at_n(v_ru_24x31_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFix, 2, (V[]){v_x_24162, v_x_24170}), v_j_24171});
                                        return heff_tag_at_n(v_ru_24x3_24160_24Just, TAG_Just, 1, (V[]){v_t_24172});
                                      }
                                      default: return heff_nomatch(v_x31_24169);
                                      }
                                    }
                                    default: return heff_nomatch(v_x3_24168);
                                    }
                                  }
                                  default: return heff_nomatch(v_x31_24161);
                                  }
                                }
                                default: return heff_nomatch(v_x3_24160);
                                }
                              } else {
                                if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str15))) {
                                  heff_drop(v_x2_240);
                                  V v_x3_24174 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_241), v_z_242));
                                  switch (heff_tag_of(v_x3_24174)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_z_241);
                                    return NTAG(TAG_Nothing);
                                  }
                                  case TAG_Just: {
                                    V v_x31_24175 = heff_field(v_x3_24174, 0);
                                    V v_ru_24x3_24174_24Just = heff_take_reuse_n(v_x3_24174, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_24175)) {
                                    case TAG_MkPair: {
                                      V v_x_24176 = heff_field(v_x31_24175, 0);
                                      V v_j_24177 = heff_field(v_x31_24175, 1);
                                      V v_ru_24x31_24175_24MkPair = heff_take_reuse_n(v_x31_24175, 3ULL, 2);
                                      V v_x3_24178 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_j_24177));
                                      V v_x3_24182;
                                      switch (heff_tag_of(v_x3_24178)) {
                                      case TAG_Nothing: {
                                        heff_drop(v_z_241);
                                        v_x3_24182 = NTAG(TAG_Nothing);
                                        break;
                                      }
                                      case TAG_Just: {
                                        V v_x31_24179 = heff_field(v_x3_24178, 0);
                                        heff_take_n(v_x3_24178, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24179)) {
                                        case TAG_MkPair: {
                                          V v_x_24180 = heff_field(v_x31_24179, 0);
                                          V v_j_24181 = heff_field(v_x31_24179, 1);
                                          heff_take_n(v_x31_24179, 3ULL, 2);
                                          v_x3_24182 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_24180, v_z_241, v_j_24181));
                                          break;
                                        }
                                        default: heff_nomatch(v_x31_24179);
                                        }
                                        break;
                                      }
                                      default: heff_nomatch(v_x3_24178);
                                      }
                                      switch (heff_tag_of(v_x3_24182)) {
                                      case TAG_Nothing: {
                                        heff_drop_cell(v_ru_24x3_24174_24Just, 1);
                                        heff_drop(v_x_24176);
                                        heff_drop_cell(v_ru_24x31_24175_24MkPair, 2);
                                        return NTAG(TAG_Nothing);
                                      }
                                      case TAG_Just: {
                                        V v_x31_24183 = heff_field(v_x3_24182, 0);
                                        heff_take_n(v_x3_24182, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24183)) {
                                        case TAG_MkPair: {
                                          V v_x_24184 = heff_field(v_x31_24183, 0);
                                          V v_j_24185 = heff_field(v_x31_24183, 1);
                                          heff_take_n(v_x31_24183, 3ULL, 2);
                                          V v_t_24186 = heff_tag_at_n(v_ru_24x31_24175_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SImplicit, 2, (V[]){v_x_24176, v_x_24184}), v_j_24185});
                                          return heff_tag_at_n(v_ru_24x3_24174_24Just, TAG_Just, 1, (V[]){v_t_24186});
                                        }
                                        default: return heff_nomatch(v_x31_24183);
                                        }
                                      }
                                      default: return heff_nomatch(v_x3_24182);
                                      }
                                    }
                                    default: return heff_nomatch(v_x31_24175);
                                    }
                                  }
                                  default: return heff_nomatch(v_x3_24174);
                                  }
                                } else {
                                  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str16))) {
                                    heff_drop(v_x2_240);
                                    V v_x3_24188 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
                                    switch (heff_tag_of(v_x3_24188)) {
                                    case TAG_Nothing: {
                                      return NTAG(TAG_Nothing);
                                    }
                                    case TAG_Just: {
                                      V v_x31_24189 = heff_field(v_x3_24188, 0);
                                      V v_ru_24x3_24188_24Just = heff_take_reuse_n(v_x3_24188, 1ULL, 1);
                                      switch (heff_tag_of(v_x31_24189)) {
                                      case TAG_MkPair: {
                                        V v_x_24190 = heff_field(v_x31_24189, 0);
                                        V v_j_24191 = heff_field(v_x31_24189, 1);
                                        V v_ru_24x31_24189_24MkPair = heff_take_reuse_n(v_x31_24189, 3ULL, 2);
                                        V v_t_24192 = heff_tag_at_n(v_ru_24x31_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_24190}), v_j_24191});
                                        return heff_tag_at_n(v_ru_24x3_24188_24Just, TAG_Just, 1, (V[]){v_t_24192});
                                      }
                                      default: return heff_nomatch(v_x31_24189);
                                      }
                                    }
                                    default: return heff_nomatch(v_x3_24188);
                                    }
                                  } else {
                                    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str17))) {
                                      heff_drop(v_x2_240);
                                      V v_x3_24194 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
                                      switch (heff_tag_of(v_x3_24194)) {
                                      case TAG_Nothing: {
                                        return NTAG(TAG_Nothing);
                                      }
                                      case TAG_Just: {
                                        V v_x31_24195 = heff_field(v_x3_24194, 0);
                                        V v_ru_24x3_24194_24Just = heff_take_reuse_n(v_x3_24194, 1ULL, 1);
                                        switch (heff_tag_of(v_x31_24195)) {
                                        case TAG_MkPair: {
                                          V v_x_24196 = heff_field(v_x31_24195, 0);
                                          V v_j_24197 = heff_field(v_x31_24195, 1);
                                          heff_take_n(v_x31_24195, 3ULL, 2);
                                          V v_t_24198 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24196));
                                          V v_x_24199 = heff_tag_n(TAG_SLitInt, 1, (V[]){v_t_24198});
                                          return heff_tag_at_n(v_ru_24x3_24194_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24199, v_j_24197})});
                                        }
                                        default: return heff_nomatch(v_x31_24195);
                                        }
                                      }
                                      default: return heff_nomatch(v_x3_24194);
                                      }
                                    } else {
                                      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str18))) {
                                        heff_drop(v_x2_240);
                                        V v_x3_24201 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
                                        switch (heff_tag_of(v_x3_24201)) {
                                        case TAG_Nothing: {
                                          return NTAG(TAG_Nothing);
                                        }
                                        case TAG_Just: {
                                          V v_x31_24202 = heff_field(v_x3_24201, 0);
                                          V v_ru_24x3_24201_24Just = heff_take_reuse_n(v_x3_24201, 1ULL, 1);
                                          switch (heff_tag_of(v_x31_24202)) {
                                          case TAG_MkPair: {
                                            V v_x_24203 = heff_field(v_x31_24202, 0);
                                            V v_j_24204 = heff_field(v_x31_24202, 1);
                                            heff_take_n(v_x31_24202, 3ULL, 2);
                                            V v_x2_24205 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str19), v_x_24203, MK_INT(0LL), NTAG(TAG_Nil)));
                                            V v_t_24208;
                                            switch (heff_tag_of(v_x2_24205)) {
                                            case TAG_Nil: {
                                              v_t_24208 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str20);
                                              break;
                                            }
                                            case TAG_Cons: {
                                              V v_x_24206 = heff_field(v_x2_24205, 0);
                                              V v_xs_24207 = heff_field(v_x2_24205, 1);
                                              heff_take_n(v_x2_24205, 3ULL, 2);
                                              v_t_24208 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str21); V a_1 = v_x_24206; V a_2 = v_xs_24207; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24207); r_; });
                                              break;
                                            }
                                            default: heff_nomatch(v_x2_24205);
                                            }
                                            double v_t_24209 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24208));
                                            V v_x_24210 = heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_t_24209)});
                                            return heff_tag_at_n(v_ru_24x3_24201_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24210, v_j_24204})});
                                          }
                                          default: return heff_nomatch(v_x31_24202);
                                          }
                                        }
                                        default: return heff_nomatch(v_x3_24201);
                                        }
                                      } else {
                                        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str22))) {
                                          heff_drop(v_x2_240);
                                          V v_x3_24212 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
                                          switch (heff_tag_of(v_x3_24212)) {
                                          case TAG_Nothing: {
                                            return NTAG(TAG_Nothing);
                                          }
                                          case TAG_Just: {
                                            V v_x31_24213 = heff_field(v_x3_24212, 0);
                                            V v_ru_24x3_24212_24Just = heff_take_reuse_n(v_x3_24212, 1ULL, 1);
                                            switch (heff_tag_of(v_x31_24213)) {
                                            case TAG_MkPair: {
                                              V v_x_24214 = heff_field(v_x31_24213, 0);
                                              V v_j_24215 = heff_field(v_x31_24213, 1);
                                              V v_ru_24x31_24213_24MkPair = heff_take_reuse_n(v_x31_24213, 3ULL, 2);
                                              V v_t_24216 = heff_tag_at_n(v_ru_24x31_24213_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_x_24214}), v_j_24215});
                                              return heff_tag_at_n(v_ru_24x3_24212_24Just, TAG_Just, 1, (V[]){v_t_24216});
                                            }
                                            default: return heff_nomatch(v_x31_24213);
                                            }
                                          }
                                          default: return heff_nomatch(v_x3_24212);
                                          }
                                        } else {
                                          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str23))) {
                                            heff_drop(v_x2_240);
                                            V v_x3_24218 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
                                            switch (heff_tag_of(v_x3_24218)) {
                                            case TAG_Nothing: {
                                              return NTAG(TAG_Nothing);
                                            }
                                            case TAG_Just: {
                                              V v_x31_24219 = heff_field(v_x3_24218, 0);
                                              V v_ru_24x3_24218_24Just = heff_take_reuse_n(v_x3_24218, 1ULL, 1);
                                              switch (heff_tag_of(v_x31_24219)) {
                                              case TAG_MkPair: {
                                                V v_x_24220 = heff_field(v_x31_24219, 0);
                                                V v_j_24221 = heff_field(v_x31_24219, 1);
                                                V v_ru_24x31_24219_24MkPair = heff_take_reuse_n(v_x31_24219, 3ULL, 2);
                                                V v_t_24222 = heff_tag_at_n(v_ru_24x31_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SLitBytes, 1, (V[]){v_x_24220}), v_j_24221});
                                                return heff_tag_at_n(v_ru_24x3_24218_24Just, TAG_Just, 1, (V[]){v_t_24222});
                                              }
                                              default: return heff_nomatch(v_x31_24219);
                                              }
                                            }
                                            default: return heff_nomatch(v_x3_24218);
                                            }
                                          } else {
                                            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str24))) {
                                              heff_drop(v_x2_240);
                                              V v_x3_24224 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
                                              switch (heff_tag_of(v_x3_24224)) {
                                              case TAG_Nothing: {
                                                return NTAG(TAG_Nothing);
                                              }
                                              case TAG_Just: {
                                                V v_x31_24225 = heff_field(v_x3_24224, 0);
                                                V v_ru_24x3_24224_24Just = heff_take_reuse_n(v_x3_24224, 1ULL, 1);
                                                switch (heff_tag_of(v_x31_24225)) {
                                                case TAG_MkPair: {
                                                  V v_x_24226 = heff_field(v_x31_24225, 0);
                                                  V v_j_24227 = heff_field(v_x31_24225, 1);
                                                  heff_take_n(v_x31_24225, 3ULL, 2);
                                                  V v_t_24228 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24226));
                                                  V v_x_24229 = heff_tag_n(TAG_SLitRune, 1, (V[]){v_t_24228});
                                                  return heff_tag_at_n(v_ru_24x3_24224_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24229, v_j_24227})});
                                                }
                                                default: return heff_nomatch(v_x31_24225);
                                                }
                                              }
                                              default: return heff_nomatch(v_x3_24224);
                                              }
                                            } else {
                                              if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str25))) {
                                                heff_drop(v_x2_240);
                                                V v_x3_24231 = (g_heff_2ebuild_2eserial_2etakeFixed(heff_dup(v_z_241), v_z_242));
                                                switch (heff_tag_of(v_x3_24231)) {
                                                case TAG_Nothing: {
                                                  heff_drop(v_z_241);
                                                  return NTAG(TAG_Nothing);
                                                }
                                                case TAG_Just: {
                                                  V v_x31_24232 = heff_field(v_x3_24231, 0);
                                                  V v_ru_24x3_24231_24Just = heff_take_reuse_n(v_x3_24231, 1ULL, 1);
                                                  switch (heff_tag_of(v_x31_24232)) {
                                                  case TAG_MkPair: {
                                                    V v_x_24233 = heff_field(v_x31_24232, 0);
                                                    V v_j_24234 = heff_field(v_x31_24232, 1);
                                                    V v_ru_24x31_24232_24MkPair = heff_take_reuse_n(v_x31_24232, 3ULL, 2);
                                                    V v_x3_24235 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_j_24234));
                                                    switch (heff_tag_of(v_x3_24235)) {
                                                    case TAG_Nothing: {
                                                      heff_drop_cell(v_ru_24x3_24231_24Just, 1);
                                                      heff_drop(v_x_24233);
                                                      heff_drop_cell(v_ru_24x31_24232_24MkPair, 2);
                                                      return NTAG(TAG_Nothing);
                                                    }
                                                    case TAG_Just: {
                                                      V v_x31_24236 = heff_field(v_x3_24235, 0);
                                                      heff_take_n(v_x3_24235, 1ULL, 1);
                                                      switch (heff_tag_of(v_x31_24236)) {
                                                      case TAG_MkPair: {
                                                        V v_x_24237 = heff_field(v_x31_24236, 0);
                                                        V v_j_24238 = heff_field(v_x31_24236, 1);
                                                        heff_take_n(v_x31_24236, 3ULL, 2);
                                                        V v_t_24239 = (g_heff_2esyntax_2esurface_2eintOfText(v_x_24237));
                                                        V v_x_24240 = heff_tag_at_n(v_ru_24x31_24232_24MkPair, TAG_SLitFixed, 2, (V[]){v_x_24233, v_t_24239});
                                                        return heff_tag_at_n(v_ru_24x3_24231_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24240, v_j_24238})});
                                                      }
                                                      default: return heff_nomatch(v_x31_24236);
                                                      }
                                                    }
                                                    default: return heff_nomatch(v_x3_24235);
                                                    }
                                                  }
                                                  default: return heff_nomatch(v_x31_24232);
                                                  }
                                                }
                                                default: return heff_nomatch(v_x3_24231);
                                                }
                                              } else {
                                                if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str26))) {
                                                  V v_x3_24242 = (g_heff_2ebuild_2edecoder_2estr(v_z_241, v_z_242));
                                                  switch (heff_tag_of(v_x3_24242)) {
                                                  case TAG_Nothing: {
                                                    return NTAG(TAG_Nothing);
                                                  }
                                                  case TAG_Just: {
                                                    V v_x31_24243 = heff_field(v_x3_24242, 0);
                                                    V v_ru_24x3_24242_24Just = heff_take_reuse_n(v_x3_24242, 1ULL, 1);
                                                    switch (heff_tag_of(v_x31_24243)) {
                                                    case TAG_MkPair: {
                                                      V v_x_24244 = heff_field(v_x31_24243, 0);
                                                      V v_j_24245 = heff_field(v_x31_24243, 1);
                                                      heff_take_n(v_x31_24243, 3ULL, 2);
                                                      V v_x2_24246 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str27), v_x_24244, MK_INT(0LL), NTAG(TAG_Nil)));
                                                      V v_t_24249;
                                                      switch (heff_tag_of(v_x2_24246)) {
                                                      case TAG_Nil: {
                                                        v_t_24249 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str28);
                                                        break;
                                                      }
                                                      case TAG_Cons: {
                                                        V v_x_24247 = heff_field(v_x2_24246, 0);
                                                        V v_xs_24248 = heff_field(v_x2_24246, 1);
                                                        heff_take_n(v_x2_24246, 3ULL, 2);
                                                        v_t_24249 = ({ V a_0 = ((V)&g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_str29); V a_1 = v_x_24247; V a_2 = v_xs_24248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24248); r_; });
                                                        break;
                                                      }
                                                      default: heff_nomatch(v_x2_24246);
                                                      }
                                                      double v_t_24250 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_24249));
                                                      V v_x_24251 = heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(v_t_24250)});
                                                      return heff_tag_at_n(v_ru_24x3_24242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24251, v_j_24245})});
                                                    }
                                                    default: return heff_nomatch(v_x31_24243);
                                                    }
                                                  }
                                                  default: return heff_nomatch(v_x3_24242);
                                                  }
                                                } else {
                                                  return ({ V a_0 = v_z_241; V a_1 = v_z_242; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_entry, 2, 0};

V g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_i_241));
  V v_x3_246;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    v_x3_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      v_x3_246 = (g_heff_2ebuild_2edecoder_2etimes_24s347552273x772218004(v_x_244, v_s_240, v_j_245));
      break;
    }
    default: heff_nomatch(v_x31_243);
    }
    break;
  }
  default: heff_nomatch(v_x3_242);
  }
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_247 = heff_field(v_x3_246, 0);
    V v_ru_24x3_246_24Just = heff_take_reuse_n(v_x3_246, 1ULL, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_247, 0);
      V v_j_249 = heff_field(v_x31_247, 1);
      heff_take_n(v_x31_247, 3ULL, 2);
      V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_248)));
      V v_t_2411 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_248));
      V v_t_2412 = (g_list_2emap_24s1173914895x100384474(v_x_248));
      V v_x_2413 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2410), v_t_2411, heff_arrayFromList(v_t_2412)});
      return heff_tag_at_n(v_ru_24x3_246_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_j_249})});
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str0, 1, "u");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str1, 2, "de");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str2, 2, "fn");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str3, 2, "rc");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str4, 2, "sm");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str5, 3, "ist");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str6, 2, "pi");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str7, 2, "pf");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str8, 2, "ps");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str9, 2, "pr");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str10, 2, "pa");
HEFF_LIT(g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str11, 2, "px");
Clo g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry, 3, 0};

V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(V v_x2_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str0))) {
    heff_drop(v_x2_240);
    return (g_heff_2ebuild_2edecoder_2ebind_24s1741458215x1655616028(v_z_241, v_z_242));
  } else {
    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str1))) {
      heff_drop(v_x2_240);
      V v_x3_245 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
      V v_x3_249;
      switch (heff_tag_of(v_x3_245)) {
      case TAG_Nothing: {
        heff_drop(v_z_241);
        v_x3_249 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_246 = heff_field(v_x3_245, 0);
        heff_take_n(v_x3_245, 1ULL, 1);
        switch (heff_tag_of(v_x31_246)) {
        case TAG_MkPair: {
          V v_x_247 = heff_field(v_x31_246, 0);
          V v_j_248 = heff_field(v_x31_246, 1);
          heff_take_n(v_x31_246, 3ULL, 2);
          v_x3_249 = (g_heff_2ebuild_2eserial_2etermOf_24s953581102x117906358(v_x_247, v_z_241, v_j_248));
          break;
        }
        default: heff_nomatch(v_x31_246);
        }
        break;
      }
      default: heff_nomatch(v_x3_245);
      }
      switch (heff_tag_of(v_x3_249)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2410 = heff_field(v_x3_249, 0);
        V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
        switch (heff_tag_of(v_x31_2410)) {
        case TAG_MkPair: {
          V v_x_2411 = heff_field(v_x31_2410, 0);
          V v_j_2412 = heff_field(v_x31_2410, 1);
          V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 3ULL, 2);
          V v_t_2413 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2411}), v_j_2412});
          return heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_t_2413});
        }
        default: return heff_nomatch(v_x31_2410);
        }
      }
      default: return heff_nomatch(v_x3_249);
      }
    } else {
      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str2))) {
        heff_drop(v_x2_240);
        V v_x3_2415 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_z_241), v_z_242));
        switch (heff_tag_of(v_x3_2415)) {
        case TAG_Nothing: {
          heff_drop(v_z_241);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2416 = heff_field(v_x3_2415, 0);
          V v_ru_24x3_2415_24Just = heff_take_reuse_n(v_x3_2415, 1ULL, 1);
          switch (heff_tag_of(v_x31_2416)) {
          case TAG_MkPair: {
            V v_x_2417 = heff_field(v_x31_2416, 0);
            V v_j_2418 = heff_field(v_x31_2416, 1);
            V v_ru_24x31_2416_24MkPair = heff_take_reuse_n(v_x31_2416, 3ULL, 2);
            V v_x3_2419 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_j_2418));
            V v_x3_2423;
            switch (heff_tag_of(v_x3_2419)) {
            case TAG_Nothing: {
              v_x3_2423 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_x31_2420 = heff_field(v_x3_2419, 0);
              heff_take_n(v_x3_2419, 1ULL, 1);
              switch (heff_tag_of(v_x31_2420)) {
              case TAG_MkPair: {
                V v_x_2421 = heff_field(v_x31_2420, 0);
                V v_j_2422 = heff_field(v_x31_2420, 1);
                heff_take_n(v_x31_2420, 3ULL, 2);
                v_x3_2423 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2421, heff_dup(v_z_241), v_j_2422));
                break;
              }
              default: heff_nomatch(v_x31_2420);
              }
              break;
            }
            default: heff_nomatch(v_x3_2419);
            }
            switch (heff_tag_of(v_x3_2423)) {
            case TAG_Nothing: {
              heff_drop(v_z_241);
              heff_drop_cell(v_ru_24x3_2415_24Just, 1);
              heff_drop(v_x_2417);
              heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2424 = heff_field(v_x3_2423, 0);
              heff_take_n(v_x3_2423, 1ULL, 1);
              switch (heff_tag_of(v_x31_2424)) {
              case TAG_MkPair: {
                V v_x_2425 = heff_field(v_x31_2424, 0);
                V v_j_2426 = heff_field(v_x31_2424, 1);
                heff_take_n(v_x31_2424, 3ULL, 2);
                V v_x3_2427 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_j_2426));
                V v_x3_2431;
                switch (heff_tag_of(v_x3_2427)) {
                case TAG_Nothing: {
                  v_x3_2431 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_x31_2428 = heff_field(v_x3_2427, 0);
                  heff_take_n(v_x3_2427, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2428)) {
                  case TAG_MkPair: {
                    V v_x_2429 = heff_field(v_x31_2428, 0);
                    V v_j_2430 = heff_field(v_x31_2428, 1);
                    heff_take_n(v_x31_2428, 3ULL, 2);
                    v_x3_2431 = (g_heff_2ebuild_2eserial_2eabsOf(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), v_x_2429, heff_dup(v_z_241), v_j_2430));
                    break;
                  }
                  default: heff_nomatch(v_x31_2428);
                  }
                  break;
                }
                default: heff_nomatch(v_x3_2427);
                }
                switch (heff_tag_of(v_x3_2431)) {
                case TAG_Nothing: {
                  heff_drop(v_z_241);
                  heff_drop_cell(v_ru_24x3_2415_24Just, 1);
                  heff_drop(v_x_2417);
                  heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                  heff_drop(v_x_2425);
                  return NTAG(TAG_Nothing);
                }
                case TAG_Just: {
                  V v_x31_2432 = heff_field(v_x3_2431, 0);
                  heff_take_n(v_x3_2431, 1ULL, 1);
                  switch (heff_tag_of(v_x31_2432)) {
                  case TAG_MkPair: {
                    V v_x_2433 = heff_field(v_x31_2432, 0);
                    V v_j_2434 = heff_field(v_x31_2432, 1);
                    heff_take_n(v_x31_2432, 3ULL, 2);
                    V v_x3_2435 = (g_heff_2ebuild_2edecoder_2ebind_24s319162623x1284410193(heff_dup(v_z_241), v_j_2434));
                    switch (heff_tag_of(v_x3_2435)) {
                    case TAG_Nothing: {
                      heff_drop(v_z_241);
                      heff_drop_cell(v_ru_24x3_2415_24Just, 1);
                      heff_drop(v_x_2417);
                      heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                      heff_drop(v_x_2425);
                      heff_drop(v_x_2433);
                      return NTAG(TAG_Nothing);
                    }
                    case TAG_Just: {
                      V v_x31_2436 = heff_field(v_x3_2435, 0);
                      heff_take_n(v_x3_2435, 1ULL, 1);
                      switch (heff_tag_of(v_x31_2436)) {
                      case TAG_MkPair: {
                        V v_x_2437 = heff_field(v_x31_2436, 0);
                        V v_j_2438 = heff_field(v_x31_2436, 1);
                        heff_take_n(v_x31_2436, 3ULL, 2);
                        V v_x3_2439 = (g_heff_2ebuild_2edecoder_2ebind_24s2082925062x256752403(v_z_241, v_j_2438));
                        switch (heff_tag_of(v_x3_2439)) {
                        case TAG_Nothing: {
                          heff_drop_cell(v_ru_24x3_2415_24Just, 1);
                          heff_drop(v_x_2417);
                          heff_drop_cell(v_ru_24x31_2416_24MkPair, 2);
                          heff_drop(v_x_2425);
                          heff_drop(v_x_2433);
                          heff_drop(v_x_2437);
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2440 = heff_field(v_x3_2439, 0);
                          heff_take_n(v_x3_2439, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2440)) {
                          case TAG_MkPair: {
                            V v_x_2441 = heff_field(v_x31_2440, 0);
                            V v_j_2442 = heff_field(v_x31_2440, 1);
                            heff_take_n(v_x31_2440, 3ULL, 2);
                            V v_t_2443 = heff_tag_at_n(v_ru_24x31_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFunction, 5, (V[]){v_x_2417, v_x_2425, v_x_2433, v_x_2437, v_x_2441}), v_j_2442});
                            return heff_tag_at_n(v_ru_24x3_2415_24Just, TAG_Just, 1, (V[]){v_t_2443});
                          }
                          default: return heff_nomatch(v_x31_2440);
                          }
                        }
                        default: return heff_nomatch(v_x3_2439);
                        }
                      }
                      default: return heff_nomatch(v_x31_2436);
                      }
                    }
                    default: return heff_nomatch(v_x3_2435);
                    }
                  }
                  default: return heff_nomatch(v_x31_2432);
                  }
                }
                default: return heff_nomatch(v_x3_2431);
                }
              }
              default: return heff_nomatch(v_x31_2424);
              }
            }
            default: return heff_nomatch(v_x3_2423);
            }
          }
          default: return heff_nomatch(v_x31_2416);
          }
        }
        default: return heff_nomatch(v_x3_2415);
        }
      } else {
        if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str3))) {
          heff_drop(v_x2_240);
          V v_x3_2445 = (g_heff_2ebuild_2edecoder_2ebind_24s169832946x1785627174(heff_dup(v_z_241), v_z_242));
          switch (heff_tag_of(v_x3_2445)) {
          case TAG_Nothing: {
            heff_drop(v_z_241);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2446 = heff_field(v_x3_2445, 0);
            V v_ru_24x3_2445_24Just = heff_take_reuse_n(v_x3_2445, 1ULL, 1);
            switch (heff_tag_of(v_x31_2446)) {
            case TAG_MkPair: {
              V v_x_2447 = heff_field(v_x31_2446, 0);
              V v_j_2448 = heff_field(v_x31_2446, 1);
              V v_ru_24x31_2446_24MkPair = heff_take_reuse_n(v_x31_2446, 3ULL, 2);
              V v_x3_2449 = (g_heff_2ebuild_2eserial_2etakeDict(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 1)), heff_dup(v_z_241), v_j_2448));
              switch (heff_tag_of(v_x3_2449)) {
              case TAG_Nothing: {
                heff_drop(v_z_241);
                heff_drop_cell(v_ru_24x3_2445_24Just, 1);
                heff_drop(v_x_2447);
                heff_drop_cell(v_ru_24x31_2446_24MkPair, 2);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2450 = heff_field(v_x3_2449, 0);
                heff_take_n(v_x3_2449, 1ULL, 1);
                switch (heff_tag_of(v_x31_2450)) {
                case TAG_MkPair: {
                  V v_x_2451 = heff_field(v_x31_2450, 0);
                  V v_j_2452 = heff_field(v_x31_2450, 1);
                  heff_take_n(v_x31_2450, 3ULL, 2);
                  V v_x3_2453 = (g_heff_2ebuild_2eserial_2etakeDict(heff_dup(heff_rfield(g_heff_2ebuild_2eserial_2edk_get(), 0)), v_z_241, v_j_2452));
                  switch (heff_tag_of(v_x3_2453)) {
                  case TAG_Nothing: {
                    heff_drop_cell(v_ru_24x3_2445_24Just, 1);
                    heff_drop(v_x_2447);
                    heff_drop_cell(v_ru_24x31_2446_24MkPair, 2);
                    heff_drop(v_x_2451);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2454 = heff_field(v_x3_2453, 0);
                    heff_take_n(v_x3_2453, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2454)) {
                    case TAG_MkPair: {
                      V v_x_2455 = heff_field(v_x31_2454, 0);
                      V v_j_2456 = heff_field(v_x31_2454, 1);
                      heff_take_n(v_x31_2454, 3ULL, 2);
                      V v_t_2457 = heff_tag_at_n(v_ru_24x31_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_x_2447, v_x_2451, v_x_2455}), v_j_2456});
                      return heff_tag_at_n(v_ru_24x3_2445_24Just, TAG_Just, 1, (V[]){v_t_2457});
                    }
                    default: return heff_nomatch(v_x31_2454);
                    }
                  }
                  default: return heff_nomatch(v_x3_2453);
                  }
                }
                default: return heff_nomatch(v_x31_2450);
                }
              }
              default: return heff_nomatch(v_x3_2449);
              }
            }
            default: return heff_nomatch(v_x31_2446);
            }
          }
          default: return heff_nomatch(v_x3_2445);
          }
        } else {
          if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str4))) {
            heff_drop(v_x2_240);
            V v_x3_2459 = (g_heff_2ebuild_2eserial_2etakeDict_24s1548253140x458575819(v_z_241, v_z_242));
            switch (heff_tag_of(v_x3_2459)) {
            case TAG_Nothing: {
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_x31_2460 = heff_field(v_x3_2459, 0);
              V v_ru_24x3_2459_24Just = heff_take_reuse_n(v_x3_2459, 1ULL, 1);
              switch (heff_tag_of(v_x31_2460)) {
              case TAG_MkPair: {
                V v_x_2461 = heff_field(v_x31_2460, 0);
                V v_j_2462 = heff_field(v_x31_2460, 1);
                V v_ru_24x31_2460_24MkPair = heff_take_reuse_n(v_x31_2460, 3ULL, 2);
                V v_t_2463 = heff_tag_at_n(v_ru_24x31_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SSum, 1, (V[]){v_x_2461}), v_j_2462});
                return heff_tag_at_n(v_ru_24x3_2459_24Just, TAG_Just, 1, (V[]){v_t_2463});
              }
              default: return heff_nomatch(v_x31_2460);
              }
            }
            default: return heff_nomatch(v_x3_2459);
            }
          } else {
            if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str5))) {
              heff_drop(v_x2_240);
              V v_x3_2465 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
              V v_x3_2469;
              switch (heff_tag_of(v_x3_2465)) {
              case TAG_Nothing: {
                heff_drop(v_z_241);
                v_x3_2469 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2466 = heff_field(v_x3_2465, 0);
                heff_take_n(v_x3_2465, 1ULL, 1);
                switch (heff_tag_of(v_x31_2466)) {
                case TAG_MkPair: {
                  V v_x_2467 = heff_field(v_x31_2466, 0);
                  V v_j_2468 = heff_field(v_x31_2466, 1);
                  heff_take_n(v_x31_2466, 3ULL, 2);
                  v_x3_2469 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2467, v_z_241, v_j_2468));
                  break;
                }
                default: heff_nomatch(v_x31_2466);
                }
                break;
              }
              default: heff_nomatch(v_x3_2465);
              }
              switch (heff_tag_of(v_x3_2469)) {
              case TAG_Nothing: {
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2470 = heff_field(v_x3_2469, 0);
                V v_ru_24x3_2469_24Just = heff_take_reuse_n(v_x3_2469, 1ULL, 1);
                switch (heff_tag_of(v_x31_2470)) {
                case TAG_MkPair: {
                  V v_x_2471 = heff_field(v_x31_2470, 0);
                  V v_j_2472 = heff_field(v_x31_2470, 1);
                  V v_ru_24x31_2470_24MkPair = heff_take_reuse_n(v_x31_2470, 3ULL, 2);
                  V v_t_2473 = heff_tag_at_n(v_ru_24x31_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2471}), v_j_2472});
                  return heff_tag_at_n(v_ru_24x3_2469_24Just, TAG_Just, 1, (V[]){v_t_2473});
                }
                default: return heff_nomatch(v_x31_2470);
                }
              }
              default: return heff_nomatch(v_x3_2469);
              }
            } else {
              if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str6))) {
                heff_drop(v_x2_240);
                heff_drop(v_z_241);
                V v_t_2475 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimInt), v_z_242});
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2475});
              } else {
                if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str7))) {
                  heff_drop(v_x2_240);
                  heff_drop(v_z_241);
                  V v_t_2477 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimFloat), v_z_242});
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2477});
                } else {
                  if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str8))) {
                    heff_drop(v_x2_240);
                    heff_drop(v_z_241);
                    V v_t_2479 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimString), v_z_242});
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2479});
                  } else {
                    if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str9))) {
                      heff_drop(v_x2_240);
                      heff_drop(v_z_241);
                      V v_t_2481 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_SPrimRune), v_z_242});
                      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2481});
                    } else {
                      if (heff_strEq_c(heff_dup(v_x2_240), ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str10))) {
                        heff_drop(v_x2_240);
                        V v_x3_2483 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_z_241), v_z_242));
                        V v_x3_2487;
                        switch (heff_tag_of(v_x3_2483)) {
                        case TAG_Nothing: {
                          heff_drop(v_z_241);
                          v_x3_2487 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_Just: {
                          V v_x31_2484 = heff_field(v_x3_2483, 0);
                          heff_take_n(v_x3_2483, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2484)) {
                          case TAG_MkPair: {
                            V v_x_2485 = heff_field(v_x31_2484, 0);
                            V v_j_2486 = heff_field(v_x31_2484, 1);
                            heff_take_n(v_x31_2484, 3ULL, 2);
                            v_x3_2487 = (g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(v_x_2485, v_z_241, v_j_2486));
                            break;
                          }
                          default: heff_nomatch(v_x31_2484);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x3_2483);
                        }
                        switch (heff_tag_of(v_x3_2487)) {
                        case TAG_Nothing: {
                          return NTAG(TAG_Nothing);
                        }
                        case TAG_Just: {
                          V v_x31_2488 = heff_field(v_x3_2487, 0);
                          V v_ru_24x3_2487_24Just = heff_take_reuse_n(v_x3_2487, 1ULL, 1);
                          switch (heff_tag_of(v_x31_2488)) {
                          case TAG_MkPair: {
                            V v_x_2489 = heff_field(v_x31_2488, 0);
                            V v_j_2490 = heff_field(v_x31_2488, 1);
                            V v_ru_24x31_2488_24MkPair = heff_take_reuse_n(v_x31_2488, 3ULL, 2);
                            V v_t_2491 = heff_tag_at_n(v_ru_24x31_2488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2489}), v_j_2490});
                            return heff_tag_at_n(v_ru_24x3_2487_24Just, TAG_Just, 1, (V[]){v_t_2491});
                          }
                          default: return heff_nomatch(v_x31_2488);
                          }
                        }
                        default: return heff_nomatch(v_x3_2487);
                        }
                      } else {
                        if (heff_strEq_c(v_x2_240, ((V)&g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_str11))) {
                          V v_x3_2493 = (g_heff_2ebuild_2eserial_2etakeFixed(v_z_241, v_z_242));
                          switch (heff_tag_of(v_x3_2493)) {
                          case TAG_Nothing: {
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_2494 = heff_field(v_x3_2493, 0);
                            V v_ru_24x3_2493_24Just = heff_take_reuse_n(v_x3_2493, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2494)) {
                            case TAG_MkPair: {
                              V v_x_2495 = heff_field(v_x31_2494, 0);
                              V v_j_2496 = heff_field(v_x31_2494, 1);
                              V v_ru_24x31_2494_24MkPair = heff_take_reuse_n(v_x31_2494, 3ULL, 2);
                              V v_t_2497 = heff_tag_at_n(v_ru_24x31_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){v_x_2495}), v_j_2496});
                              return heff_tag_at_n(v_ru_24x3_2493_24Just, TAG_Just, 1, (V[]){v_t_2497});
                            }
                            default: return heff_nomatch(v_x31_2494);
                            }
                          }
                          default: return heff_nomatch(v_x3_2493);
                          }
                        } else {
                          return ({ V a_0 = v_z_241; V a_1 = v_z_242; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eserial_2etypeOf_24s1982421657x44126081(a[0], a[1], a[2]);
}