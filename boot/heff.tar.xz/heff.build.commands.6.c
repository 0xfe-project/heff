// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_MakeDirectory 16793
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_diff 9578700
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_file 9638467
#define LBL_got 312070
#define LBL_hashes 722717031
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_outPath 1272254166
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_root 10001833
#define LBL_shipTo 1043811586
#define LBL_ships 310766033
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_top 324559
#define LBL_watches 1357821955
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
V g_co_2eop_24s1622770744x67950580(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1622770744x67950580_entry(V self, V *a);
extern Clo g_co_2eop_24s1622770744x67950580_clo;
V g_co_2eop_24s868939913x277534373(V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s868939913x277534373_entry(V self, V *a);
extern Clo g_co_2eop_24s868939913x277534373_clo;
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846(V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012(V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972(V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2eintegrationText(V, V);
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
HeffT2 g_heff_2ebuild_2eproject_2ereadBuild_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
V g_list_2eany_24s2129318370x1621070635(V, V);
V g_list_2eany_24s2129318370x1621070635_entry(V self, V *a);
extern Clo g_list_2eany_24s2129318370x1621070635_clo;
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
V g_list_2efilter_24s770154907x42702486(V);
V g_list_2efilter_24s770154907x42702486_entry(V self, V *a);
extern Clo g_list_2efilter_24s770154907x42702486_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1149369025x804005338(V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1149369025x804005338_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1149369025x804005338_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s170418522x132668694(V);
V g_list_2emap_24s170418522x132668694_entry(V self, V *a);
extern Clo g_list_2emap_24s170418522x132668694_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2esortBy_24s390982605x1732870695(V);
V g_list_2esortBy_24s390982605x1732870695_entry(V self, V *a);
extern Clo g_list_2esortBy_24s390982605x1732870695_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str0, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str1, 17, "        expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str2, 17, "        but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str3, 17, "        diff     ");
Clo g_heff_2ebuild_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = ({ V a_0 = v_color_240; V a_1 = v_expected_243; V a_2 = v_got_244; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_expected_243); heff_drop(v_got_244); r_; });
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str1), heff_take_field(v_m_245, 0));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str2), heff_take_field(v_m_245, 1));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str3), heff_get_n(v_m_245, 2, 3));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efailLines(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str2, 17, "integrationMain [");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str3, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str4, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str5, 13, "Integrations\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str6, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str7, 2, "\012\012");
Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eintegrationText_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eintegrationText(V v_q_240, V v_ts_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s467798769x1763085075(v_ts_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str3)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str4), heff_strAppend(heff_dup(v_q_240), v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str5), heff_strAppend(heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get()), v_t_247));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str6), heff_strAppend(v_q_240, v_t_248));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str7), heff_strAppend(heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get()), v_t_249));
}
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eintegrationText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epassedOver_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epassedOver_str1, 0, "");
Clo g_heff_2ebuild_2ecommands_2epassedOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epassedOver_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epassedOver(V v_opts_240, V v_os_241) {
top: ;
  V v_t_243 = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2ecommands_2epassedOver_str0)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_x1_244 = (g_list_2efilter_24s770154907x42702486(heff_dup(v_os_241)));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nil: {
      V v_p_245 = heff_get_n(v_opts_240, 1, 4);
      V v_t_2415;
      if (heff_strEq_c_lent(v_p_245, ((V)&g_heff_2ebuild_2ecommands_2epassedOver_str1), 2)) {
        heff_drop(v_p_245);
        v_t_2415 = NTAG(TAG_Nil);
      } else {
        V v_t_247 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_245); r_; });
        V v_t_248 = (g_list_2emap_24s1007499915x73800978(v_t_247));
        HeffT2 v_t_249 = (g_regex_2eallRead_24cpr(v_t_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_why_2413 = v_field_2411;
            heff_drop(v_why_2413);
            v_t_2415 = NTAG(TAG_Nil);
          } else {
            V v_sel_2414 = v_field_2411;
            v_t_2415 = v_sel_2414;
          }
        }
      }
      V v_x1_2416 = ({ V a_0 = v_t_2415; V a_1 = v_os_241; V r_ = (g_list_2eany_24s2129318370x1621070635(a_0, a_1)); heff_drop(v_t_2415); heff_drop(v_os_241); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2416) == NTAG(TAG_True)));
      heff_drop(v_x1_2416);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_244, 0ULL, 2);
      heff_drop_rec(v_opts_240, 4);
      heff_drop(v_os_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_244);
    }
  } else {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_os_241);
    heff_drop(v_t_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epassedOver(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str3, 1, ".");
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam6, 2, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam1, 2, 4, (V[]){v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam2(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam4(V self, V *args) {
  V v_s_2418 = args[0];
  return v_s_2418;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam6(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam8(V self, V *args) {
  V v_t_2439 = args[0];
  return v_t_2439;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam9(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447;
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Nothing: {
    v_t_2447 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x_2445, 0ULL, 1);
    v_t_2447 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2445);
  }
  V f_ = v_k_2438;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam7(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_path_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2436, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam8_clo)})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_2437, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam9, 1, 1, (V[]){v_k_2438})));
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam11(V self, V *args) {
  V v_n_2452 = args[0];
  V v_st_2427 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = ({ V a_0 = v_st_2427; V a_1 = v_p_248; V a_2 = v_n_2452; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2427); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_t_2453});
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam10(V self, V *args) {
  V v_x_2449 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_ns_2433 = heff_env(self)[4];
  V v_st_2427 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2449) == NTAG(TAG_True))) {
    heff_drop(v_x_2449);
    heff_drop(v_ns_2433);
    heff_drop(v_st_2427);
    heff_drop(v_p_248);
    V v_t_2450 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(v_rest_246, v_acc_241));
    V f_ = v_t_2450;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2449);
    V v_t_2451 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str3); V a_3 = v_ns_2433; V r_ = (g_list_2efilter_24s2101000672x961294372(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2454 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam11, 1, 2, (V[]){v_st_2427, v_p_248}), v_t_2451));
    V v_t_2455 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(v_t_2454, v_acc_241));
    V f_ = v_t_2455;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2427;
  if (heff_strEq_c(v_x_2425, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str0))) {
    v_st_2427 = NTAG(TAG_Windows);
  } else {
    v_st_2427 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    heff_drop(v_top_247);
    heff_drop(v_st_2427);
    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_248, 0)) - ((int64_t)3ULL));
    V v_t_2429 = heff_strSlice(heff_dup(v_p_248), heff_box_word(v_t_2428), heff_strLength_lent(v_p_248, 0));
    if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str1))) {
      V v_t_2431 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      V f_ = v_t_2431;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_248);
      V v_t_2432 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127(v_rest_246, v_acc_241));
      V f_ = v_t_2432;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2433 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    V v_c_2448;
    if ((heff_dup(v_top_247) == NTAG(TAG_True))) {
      heff_drop(v_top_247);
      v_c_2448 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam6_clo);
    } else {
      heff_drop(v_top_247);
      V v_path_2436 = (g_std_2epath_2ejoin(v_st_2427, heff_dup(v_p_248), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_str2)));
      v_c_2448 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam7, 2, 1, (V[]){v_path_2436});
    }
    V f_ = v_c_2448;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam10, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_ns_2433, v_st_2427, v_p_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam4_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(v_t_2424, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam5, 1, 7, (V[]){v_x_2417, v_p_248, v_rest_246, v_acc_241, v_hd_249, v_k_2410, v_top_247})));
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_p_248 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_top_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){heff_dup(v_p_248), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1816718535x734239127_lam3, 1, 6, (V[]){v_hd_249, v_p_248, v_rest_246, v_acc_241, v_k_2410, v_top_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str0, 5, "-- | ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454(V v_file_240, V v_badL_241, V v_cs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_cs_242), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam0, 1, 5, (V[]){v_cs_242, heff_dup(v_badL_241), v_hd_243, v_k_244, v_file_240})));
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam1(V self, V *args) {
  V v_ok_2422 = args[0];
  return v_ok_2422;
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_2428) == NTAG(TAG_True))) {
    heff_drop(v_x_2428);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2428);
    V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_hd_243, v_k_244));
  }
}
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_badL_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_file_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  HeffT2 v_t_246 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_c_2410 = v_field_248;
      V v_t_2411;
      if ((heff_dup(v_badL_241) == NTAG(TAG_True))) {
        heff_drop(v_cs_242);
        heff_drop(v_badL_241);
        v_t_2411 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_241);
        v_t_2411 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1996724342x1838336560(a_0)); heff_drop(v_cs_242); r_; });
      }
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_file_240);
        heff_drop_rec(v_c_2410, 13);
        heff_drop(v_t_2411);
        V v_t_2412 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
        V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
        V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
        V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
        V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), v_hd_243, v_k_244));
      } else {
        heff_drop(v_t_2411);
        V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_c_2410, 5)), 4, 9);
        V v_t_2419 = (g_heff_2ebuild_2edriver_2ewatchesOf(heff_dup(v_c_2410), v_t_2418));
        V v_t_2420 = (g_list_2esortBy_24s390982605x1732870695(v_t_2419));
        V v_str_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str1); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str2); V a_3 = MK_INT(0LL); V b_4 = ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_str3); V b_5 = MK_INT(0LL); V a_6 = heff_get_n(v_c_2410, 3, 13); V a_7 = v_t_2420; V r_ = (g_list_2efoldl_24s1149369025x804005338(a_0, a_1, b_2, a_3, b_4, b_5, a_6, a_7)); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(v_t_2420); r_; });
        V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_file_240, v_str_2421, ((V)&g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam1_clo)})});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteDiags_24s757113459x283056454_lam2, 1, 2, (V[]){v_k_244, v_hd_243})));
      }
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badL_241);
      heff_drop(v_file_240);
      heff_drop(v_field_248);
      V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_hd_243, v_k_244));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622(V v_name_240, V v_outPath_241, V v_file_242, V v_done_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam0, 2, 5, (V[]){v_c_244, v_file_242, heff_dup(v_name_240), v_outPath_241, v_done_243});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_x_248 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = (g_list_2emap_24s170418522x132668694(heff_dup(heff_rfield(v_x_2410, 0))));
  V v_t_2412 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_x_247, 2), heff_take_field(v_x_2410, 1), v_t_2411});
  return ({ V a_0 = v_t_2412; V a_1 = heff_get_n(v_x_247, 0, 5); V a_2 = v_file_242; V a_3 = v_name_240; V a_4 = v_outPath_241; V a_5 = v_done_243; V b_6 = heff_intLt(MK_INT(0LL), v_x_248); V a_7 = heff_get_n(v_x_2410, 0, 2); V a_8 = v_hd_245; V a_9 = v_k_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s1384708091x128762446(a_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7, a_8, a_9)); heff_drop(v_name_240); heff_drop(b_6); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_outPath_241 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_x_247)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam3, 1, 8, (V[]){v_x_247, v_file_242, v_name_240, v_outPath_241, v_done_243, v_x_248, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_str0), heff_dup(heff_rfield(v_x_247, 1)), MK_INT(0LL), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam2, 1, 7, (V[]){v_x_247, v_hd_245, v_file_242, v_name_240, v_outPath_241, v_done_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_lam1, 1, 6, (V[]){v_hd_245, v_file_242, v_name_240, v_outPath_241, v_done_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str1, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str2, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str4, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str5, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str6, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str7, 16, ": esm, page or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str8, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972(V v_o_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str0))) {
    V v_outPath_242 = heff_take_field(v_o_240, 1);
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str1), heff_strAppend(heff_dup(v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str2)));
    V v_t_244 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str3)), NTAG(TAG_MkUnit)});
    V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})}));
    return ({ V b_0 = heff_dup(heff_rfield(v_o_240, 2)); V a_1 = v_outPath_242; V a_2 = heff_get_n(v_o_240, 0, 4); V a_3 = v_t_2410; V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str4))) {
      V v_t_2412 = heff_take_field(v_o_240, 2);
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        return (g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1118202158x1954615012(heff_dup(heff_rfield(v_o_240, 0)), heff_get_n(v_o_240, 1, 4)));
      }
      case TAG_Just: {
        heff_take_n(v_t_2412, 0ULL, 1);
        heff_drop_rec(v_o_240, 4);
        return ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam0_clo);
      }
      default: return heff_nomatch(v_t_2412);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str6))) {
        return (g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846(heff_dup(heff_rfield(v_o_240, 2)), heff_dup(heff_rfield(v_o_240, 1)), heff_get_n(v_o_240, 0, 4)));
      } else {
        return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam2, 2, 1, (V[]){v_o_240});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972(a[0]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_2414, v_k_2415));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str5), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam1, 1, 2, (V[]){v_hd_2414, v_k_2415})));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam3(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_hd_2430, v_k_2431));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam2(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = heff_strAppend(heff_get_n(v_o_240, 3, 4), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str7));
  V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str8), v_t_2432), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_str9));
  V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s922059318x1925246972_lam3, 1, 2, (V[]){v_hd_2430, v_k_2431})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_str1, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_243);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    HeffT2 v_t_248 = (g_heff_2ebuild_2eproject_2ereadBuild_24cpr(v_text_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2412 = v_field_2410;
        V v_t_2413 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_str0), v_x_243));
        V v_p_2414 = (g_std_2epath_2ejoin(v_st_240, v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_str1)));
        V v_t_2415 = (g_std_2epath_2ejoin(v_st_240, heff_get_n(v_t_241, 0, 6), v_p_2414));
        V v_str_2416 = ({ V a_0 = v_t_2415; V a_1 = v_text_247; V a_2 = v_p_2412; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_text_247); r_; });
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam1, 2, 2, (V[]){v_str_2416, v_acc_242});
      } else {
        heff_drop(v_text_247);
        V v_a_2428 = v_field_2410;
        V v_c_2429 = (g_heff_2ebuild_2ecommands_2enotInProject_24s552863568x1303384487(v_st_240, heff_dup(v_t_241), heff_dup(heff_rfield(v_a_2428, 2))));
        return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam3, 2, 6, (V[]){v_c_2429, heff_dup(v_st_240), v_t_241, v_acc_242, v_x_243, v_a_2428});
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2427 = ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2418;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_str_2416 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2416, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_str2)), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_2417, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam2, 1, 2, (V[]){v_acc_242, v_k_2418})));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2428 = heff_env(self)[4];
  V v_hd_2430 = heff_env(self)[5];
  V v_k_2431 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_acc_242; V a_3 = v_x_243; V a_4 = v_a_2428; V a_5 = v_x_2432; V a_6 = v_hd_2430; V a_7 = v_k_2431; V r_ = (g_heff_2ebuild_2ecommands_2eappShips_24s1960464979x1900423355(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2428 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2429;
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214_lam4, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2428, v_hd_2430, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_str0, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_str1, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(V v_prog_240, V v_st_241, V v_t_242, V v_rd_243, V v_acc_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_rd_243);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_244, 0)));
    V v_x_247 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_acc_244, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam0, 2, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x5_245, 0);
    V v_rest_2411 = heff_field(v_x5_245, 1);
    heff_take_n(v_x5_245, 3ULL, 2);
    V v_t_2412 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_str0), heff_dup(v_x_2410)));
    V v_p_2413 = (g_std_2epath_2ejoin(v_st_241, v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_str1)));
    V v_path_2414 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_2413));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam1, 2, 8, (V[]){v_path_2414, heff_dup(v_st_241), v_t_242, v_acc_244, v_x_2410, v_rd_243, v_prog_240, v_rest_2411});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam2(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_rd_243 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_rest_2411 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_k_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_243), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2426}));
  return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_rd_243; V a_4 = v_x_2425; V a_5 = v_rest_2411; V a_6 = heff_dup(v_hd_2415); V a_7 = v_k_2416; V a_8 = v_t_2427; V a_9 = v_hd_2415; V r_ = (g_co_2eop_24s1622770744x67950580(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_st_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_rd_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_k_2416 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2424 = (g_heff_2ebuild_2ecommands_2eappRead_24s298845835x1756559214(v_st_241, heff_dup(v_t_242), v_acc_244, v_x_2410, v_x_2423));
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam4, 1, 7, (V[]){v_rd_243, v_prog_240, v_st_241, v_t_242, v_rest_2411, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_path_2414 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_rd_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2414, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam2_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_lam3, 1, 9, (V[]){v_st_241, v_t_242, v_acc_244, v_x_2410, v_hd_2415, v_rd_243, v_prog_240, v_rest_2411, v_k_2416})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030(V v_prog_240, V v_st_241, V v_t_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_progs_243);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam0_clo);
  }
  case TAG_Just: {
    V v_home_247 = heff_field(v_x5_244, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_total_2410 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_249));
    V v_t_2412 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_str0), heff_dup(v_home_247)), v_total_2410, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam1_clo)});
    V v_t_2413 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2412}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam2, 2, 6, (V[]){v_t_2413, v_prog_240, v_progs_243, heff_dup(v_st_241), v_t_242, heff_dup(v_home_247)});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  heff_drop(v_a_245);
  V f_ = v_a_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_t_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s94900133x232571340(v_t_2418, v_hd_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam5, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_progs_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_247 = heff_env(self)[4];
  V v_hd_2414 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2416), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2417}));
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2420));
  V v_t_2425 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_247; V a_4 = v_x_2416; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam4, 2, 1, (V[]){v_t_2418}); V a_6 = v_t_2421; V r_ = (g_heff_2ebuild_2ecommands_2eshipAll_24s1776056313x435715961(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_241); heff_drop(v_t_2421); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_t_2413 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_progs_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_home_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_lam3, 1, 7, (V[]){v_prog_240, v_progs_243, v_st_241, v_t_242, v_home_247, v_hd_2414, v_k_2415})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665(V v_prog_240, V v_st_241, V v_t_242, V v_done_243, V v_progs_244, V v_z_245, V v_z_246) {
top: ;
  V v_p_247 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_str1)));
  V v_path_248 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_247));
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_248, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam1, 1, 7, (V[]){v_progs_244, v_prog_240, v_z_245, v_st_241, v_t_242, v_done_243, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam0(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam2(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_prog_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_t_2420 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_t_2422 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_t_2420; V a_4 = v_progs_244; V a_5 = heff_dup(v_hd_2423); V a_6 = v_k_2424; V a_7 = v_t_2422; V a_8 = v_hd_2423; V r_ = (g_co_2eop_24s868939913x277534373(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_241); heff_drop(v_progs_244); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_done_243 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2420 = (g_heff_2ebuild_2ecommands_2eshipIn_24s1734817291x755108819(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), v_done_243, heff_dup(v_progs_244), heff_rfield(v_t_242, 4)));
  V v_t_2421 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2419), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2421}));
  V v_t_2425 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_st_241); V a_2 = heff_dup(v_t_242); V a_3 = v_x_2419; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam4, 2, 6, (V[]){v_prog_240, v_st_241, v_t_242, v_t_2420, heff_dup(v_progs_244), v_t_2422}); V a_5 = v_progs_244; V r_ = (g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_z_245;
  heff_room[1] = v_z_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2415);
  V v_total_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_str2), v_total_2416, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s16226792x2097880665_lam3, 1, 7, (V[]){v_prog_240, v_st_241, v_t_242, v_done_243, v_progs_244, v_z_245, v_z_246})));
}