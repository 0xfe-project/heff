// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_diff 9578700
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_got 312070
#define LBL_group 299987609
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_modules 1459291593
#define LBL_output 941629484
#define LBL_packages 1496006433
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo;
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_clo;
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_clo;
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403(V, V, V);
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_clo;
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818(V, V);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944(V, V);
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2eintegrationText(V, V);
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s2129318370x1621070635(V, V);
V g_list_2eany_24s2129318370x1621070635_entry(V self, V *a);
extern Clo g_list_2eany_24s2129318370x1621070635_clo;
HeffT2 g_list_2efind_24s1973550603x1701528639_24cpr(V, V);
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s83609107x876953159(V);
V g_list_2ekeepIf_24s83609107x876953159_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s83609107x876953159_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f310588246x1624488069(V, V, V, V);
V g_list_2emap_24f310588246x1624488069_entry(V self, V *a);
extern Clo g_list_2emap_24f310588246x1624488069_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s631322900x900609068(V);
V g_list_2emap_24s631322900x900609068_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_clo;
V g_list_2emap_24s763976875x1978337183(V);
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_clo;
V g_list_2esortBy_24s735547525x1777295590(V);
V g_list_2esortBy_24s735547525x1777295590_entry(V self, V *a);
extern Clo g_list_2esortBy_24s735547525x1777295590_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str0, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str1, 17, "        expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str2, 17, "        but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str3, 17, "        diff     ");
Clo g_heff_2ebuild_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = ({ V a_0 = v_color_240; V a_1 = v_expected_243; V a_2 = v_got_244; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_expected_243); heff_drop(v_got_244); r_; });
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str1), heff_take_field(v_m_245, 0));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str2), heff_take_field(v_m_245, 1));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str3), heff_get_n(v_m_245, 2, 3));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efailLines(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str2, 17, "integrationMain [");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str3, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str4, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str5, 13, "Integrations\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str6, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str7, 2, "\012\012");
Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eintegrationText_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eintegrationText(V v_q_240, V v_ts_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s467798769x1763085075(v_ts_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str3)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str4), heff_strAppend(heff_dup(v_q_240), v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str5), heff_strAppend(heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get()), v_t_247));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str6), heff_strAppend(v_q_240, v_t_248));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str7), heff_strAppend(heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get()), v_t_249));
}
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eintegrationText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epassedOver_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epassedOver_str1, 0, "");
Clo g_heff_2ebuild_2ecommands_2epassedOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epassedOver_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epassedOver(V v_opts_240, V v_os_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2ecommands_2epassedOver_str0))) {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_os_241);
    return NTAG(TAG_False);
  } else {
    V v_x1_243 = (g_list_2ekeepIf_24s83609107x876953159(heff_dup(v_os_241)));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      V v_p_244 = heff_get_n(v_opts_240, 1, 4);
      V v_t_2414;
      if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ebuild_2ecommands_2epassedOver_str1), 2)) {
        heff_drop(v_p_244);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_244; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_244); r_; });
        V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
        HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_why_2412 = v_field_2410;
            heff_drop(v_why_2412);
            v_t_2414 = NTAG(TAG_Nil);
          } else {
            V v_sel_2413 = v_field_2410;
            v_t_2414 = v_sel_2413;
          }
        }
      }
      V v_x1_2415 = ({ V a_0 = v_t_2414; V a_1 = v_os_241; V r_ = (g_list_2eany_24s2129318370x1621070635(a_0, a_1)); heff_drop(v_t_2414); heff_drop(v_os_241); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
      heff_drop(v_x1_2415);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_243, 0ULL, 2);
      heff_drop_rec(v_opts_240, 4);
      heff_drop(v_os_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
}
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epassedOver(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(a[0]);
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    v_x_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2411 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    HeffT2 v_t_2412 = ({ V a_0 = v_src_2411; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_src_2411); r_; });
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2410_24Just, 1);
        V v_p_2416 = v_field_2414;
        heff_drop(v_p_2416);
        v_x_2424 = NTAG(TAG_Nothing);
      } else {
        V v_x_2417 = v_field_2414;
        HeffT2 v_t_2418 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2417));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2410_24Just, 1);
            V v_x_2422 = v_field_2420;
            heff_drop(v_x_2422);
            v_x_2424 = NTAG(TAG_Nothing);
          } else {
            V v_p_2423 = v_field_2420;
            v_x_2424 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2423, 1, 4)});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2425 = ({ V a_0 = v_x_2424; V a_1 = heff_dup(heff_rfield(v_x_246, 4)); V r_ = (g_heff_2ebuild_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2424); r_; });
  V v_x_2426 = (g_list_2efoldl_24s571074576x1179600767(v_x_246, v_t_2425));
  V f_ = v_k_243;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_247; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_248); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_242;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam4, 1, 2, (V[]){v_x_246, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam3, 1, 3, (V[]){v_hd_242, v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s976637535x2124960492(v_x_244, v_file_240));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str0, 2, ".o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str1, 11, "-femit-bin=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str2, 2, "-O");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str3, 9, "build-obj");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(V v_prog_240, V v_z_241, V v_mode_242, V v_x3_243, V v_made_244) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_made_244));
    V v_x_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_f_249 = heff_field(v_x3_243, 0);
    V v_rest_2410 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam1, 2, 6, (V[]){v_f_249, v_mode_242, v_prog_240, v_z_241, v_rest_2410, v_made_244});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam2(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_mode_242 = heff_env(self)[2];
  V v_rest_2410 = heff_env(self)[3];
  V v_o_2414 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = heff_take_field(v_x_2420, 0);
  V v_t_2424;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Exited: {
    V v_n_2422 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    v_t_2424 = heff_intEq(v_n_2422, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2420, 3);
    heff_drop(v_t_2424);
    V v_t_2425 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(v_prog_240, v_z_241, v_mode_242, v_rest_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_o_2414, v_made_244})));
    V f_ = v_t_2425;
    heff_room[0] = v_hd_2411;
    heff_room[1] = v_k_2412;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_prog_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    heff_drop(v_rest_2410);
    heff_drop(v_o_2414);
    heff_drop(v_made_244);
    heff_drop(v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2420, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_2411, heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam4, 1, 1, (V[]){v_k_2412})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_f_249 = heff_env(self)[0];
  V v_mode_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_z_241 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_f_249, 0)) - ((int64_t)4ULL));
  V v_o_2414 = heff_strAppend(heff_strSlice_lent(v_f_249, MK_INT(0LL), heff_box_word(v_t_2413), 6), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str0));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str1), heff_dup(v_o_2414)), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str2), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_mode_242), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_f_249, v_t_2416})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_z_241), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_str4), v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam2_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2419, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_lam3, 1, 8, (V[]){v_prog_240, v_z_241, v_mode_242, v_rest_2410, v_o_2414, v_made_244, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_str0, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_d_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_st_247 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_248 = (g_std_2epath_2eparse(v_st_247, v_d_246));
    V v_t_249 = (g_std_2epath_2eparse(v_st_247, heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_str0))));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_s_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
    V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2411; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2412); r_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1, 2, 4, (V[]){v_c_2413, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_m_244);
    v_t_2420 = v_x_2418;
    break;
  }
  case TAG_Just: {
    V v_text_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_text_2419}), v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_2415;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2414 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  V v_k_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(v_ps_240, v_rest_245));
  V f_ = v_c_2417;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam3, 1, 3, (V[]){v_x_2416, v_m_244, v_k_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_2414, v_m_244, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_str1, 4, "heff");
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(V v_rep_240, V v_opts_241, V v_f_242, V v_x3_243, V v_l_244, V v_z_245, V v_z_246) {
top: ;
  if ((heff_dup(v_x3_243) == NTAG(TAG_True))) {
    if (heff_strEq_c(heff_get_n(v_opts_241, 1, 4), ((V)&g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_str0))) {
      V v_c_248 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_244)));
      return heff_tail(v_c_248, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam0, 1, 4, (V[]){v_l_244, v_f_242, v_z_245, v_z_246})});
    } else {
      heff_drop(v_f_242);
      heff_drop_rec(v_l_244, 5);
      heff_drop(v_z_245);
      return heff_tail(v_z_246, 1, (V[]){heff_tag_n(TAG_Settled, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())})});
    }
  } else {
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_str1), heff_dup(heff_rfield(v_l_244, 1)), MK_INT(0LL), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam2, 1, 6, (V[]){v_l_244, v_z_245, heff_dup(v_rep_240), v_opts_241, v_f_242, v_z_246})));
  }
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(a0, a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = heff_tag_n(TAG_Settled, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_get_n(v_l_244, 1, 5);
  V v_t_2413;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nil: {
    v_t_2413 = ({ V b_0 = heff_get_n(v_x_249, 0, 2); V r_ = (g_list_2eany_24s1740858080x874135214(b_0)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2410, 0ULL, 2);
    heff_drop_rec(v_x_249, 2);
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  return ({ V a_0 = v_f_242; V a_1 = v_t_2413; V a_2 = v_z_245; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam1, 1, 1, (V[]){v_z_246}); V r_ = (g_heff_2ebuild_2ecommands_2etestExpecting_24s1975464018x388635193(a_0, a_1, a_2, a_3)); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_l_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_l_244; V a_4 = heff_get_n(v_x_2417, 0, 2); V a_5 = v_z_245; V a_6 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2etestOneC_24s2036773909x1237028266(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_240); r_; });
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  V v_c_2416 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_244)));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_lam3, 1, 6, (V[]){v_rep_240, v_opts_241, v_f_242, v_l_244, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str3, 19, ": it does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str4, 19, ": it does not check");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558(V v_rep_240, V v_failed_241, V v_l_242, V v_name_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str0), heff_dup(heff_rfield(v_l_242, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam0, 1, 9, (V[]){v_l_242, v_hd_247, v_rep_240, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_sources_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2415 = (g_list_2efind_24s1973550603x1701528639_24cpr(heff_dup(v_c_2414), v_sources_2412));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2417;
      V v_t_2420 = (g_heff_2ebuild_2edriver_2erefusedIn(v_x_2413, v_s_2419));
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2414, v_t_2420));
    } else {
      heff_drop(v_x_2413);
      heff_drop(v_field_2417);
      return v_c_2414;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_file_245 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_l_242 = heff_env(self)[7];
  V v_name_243 = heff_env(self)[8];
  V v_outPath_244 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2423);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop_rec(v_x_2411, 2);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    HeffT2 v_t_2425 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x_2421));
    V v_t_2430;
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        heff_drop(v_file_245);
        V v_x_2429 = v_field_2427;
        v_t_2430 = v_x_2429;
      } else {
        heff_drop(v_field_2427);
        v_t_2430 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str3));
      }
    }
    V f_ = v_failed_241;
    heff_room[0] = v_t_2430;
    heff_room[1] = v_hd_247;
    heff_room[2] = v_k_248;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    V v_t_2431 = (g_list_2eany_24s1740858080x874135214(v_x_2421));
    if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2411, 2);
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_name_243);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2431);
      HeffT2 v_t_2432 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_x_2421));
      V v_t_2437;
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          heff_drop(v_file_245);
          V v_x_2436 = v_field_2434;
          v_t_2437 = v_x_2436;
        } else {
          heff_drop(v_field_2434);
          v_t_2437 = heff_strAppend(v_file_245, ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str4));
        }
      }
      V f_ = v_failed_241;
      heff_room[0] = v_t_2437;
      heff_room[1] = v_hd_247;
      heff_room[2] = v_k_248;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    } else {
      heff_drop(v_t_2431);
      V v_t_2438 = (g_list_2emap_24s1698496827x1884878103(heff_take_field(v_x_2411, 0)));
      V v_t_2439 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_242, 2), heff_get_n(v_x_2411, 1, 2), v_t_2438});
      return (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(v_t_2439, heff_get_n(v_l_242, 0, 5), v_file_245, v_name_243, v_outPath_244, v_failed_241, v_done_246, v_x_2421, v_hd_247, v_k_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_file_245 = heff_env(self)[4];
  V v_failed_241 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_name_243 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_sources_2412 = heff_dup(heff_rfield(v_l_242, 0));
  V v_x_2413 = (g_list_2emap_24f310588246x1624488069(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_str2), heff_dup(v_sources_2412)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam2, 1, 2, (V[]){v_sources_2412, v_x_2413}), heff_dup(heff_rfield(v_x_2411, 0))));
  V v_c_2422 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_x_2421)));
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam3, 1, 11, (V[]){v_x_249, v_x_2421, v_file_245, v_failed_241, v_hd_247, v_k_248, v_x_2411, v_l_242, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_file_245 = heff_env(self)[3];
  V v_failed_241 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_name_243 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_242)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_lam1, 1, 10, (V[]){v_l_242, v_rep_240, v_hd_247, v_x_249, v_file_245, v_failed_241, v_k_248, v_name_243, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818(V v_rep_240, V v_file_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_file_241));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam0, 2, 2, (V[]){v_c_242, v_rep_240});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  HeffT2 v_t_2412 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_249));
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_c_2416 = v_field_2414;
      V v_t_2417 = (g_heff_2ebuild_2equery_2eexplain(v_c_2416));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(v_t_2417, v_hd_243, v_k_244));
    } else {
      heff_drop(v_field_2414);
      V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_cs_249)));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam4, 1, 3, (V[]){v_cs_249, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam3, 1, 3, (V[]){v_rep_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_rep_240, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexplainCmd_24s1100142936x1348032818_lam1, 1, 3, (V[]){v_hd_243, v_rep_240, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str3, 13, "writing pages");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str4, 8, "index.md");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str7, 46, "---\012title: API\012sidebar:\012  label: Modules\012---\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str8, 81, "The modules, each a page: what it exposes, with its type and its documentation.\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str9, 27, " pages and their index, in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str10, 10, "heff doc: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str11, 1, "\012");
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403(V v_prog_240, V v_x1_241, V v_cs_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    V v_x2_243 = (g_list_2emap_24s763976875x1978337183(v_cs_242));
    V v_str_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_str_246 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_str_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_tag_n(TAG_Write, 2, (V[]){v_str_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  }
  case TAG_Just: {
    V v_dir_2414 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam0, 2, 3, (V[]){v_cs_242, v_prog_240, v_dir_2414});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam3(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2447);
  V v_t_2448 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_cs_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_cs_242); r_; });
  V v_t_2449 = heff_strAppend(heff_intShow(v_t_2448), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str9), v_dir_2414));
  V v_str_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str10), v_t_2449);
  V v_t_2451 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2450, ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str11)), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_cs_242 = heff_env(self)[3];
  V v_dir_2414 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_End, 2, (V[]){v_x_2432, NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2445}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2446, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam7, 1, 4, (V[]){v_cs_242, v_dir_2414, v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_2427 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_x_2432 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2433);
  V v_t_2434 = (g_std_2epath_2eparse(v_st_2427, heff_dup(v_dir_2414)));
  V v_t_2435 = (g_std_2epath_2eparse(v_st_2427, ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str4)));
  V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
  V v_t_2437 = ({ V a_0 = v_st_2427; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); heff_drop(v_t_2436); r_; });
  V v_t_2438 = (g_list_2esortBy_24s735547525x1777295590(heff_dup(v_cs_242)));
  V v_x2_2439 = (g_list_2emap_24s631322900x900609068(v_t_2438));
  V v_t_2442;
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_Nil: {
    v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_xs_2441 = heff_field(v_x2_2439, 1);
    heff_take_n(v_x2_2439, 3ULL, 2);
    v_t_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str6); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2439);
  }
  V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str7), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str8), v_t_2442));
  return (g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(v_t_2437, v_t_2443, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam6, 1, 6, (V[]){v_x_2432, v_prog_240, v_hd_2415, v_cs_242, v_dir_2414, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_st_2427 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(heff_dup(v_prog_240), heff_dup(v_x_2432), heff_dup(v_dir_2414), heff_dup(v_cs_242), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam5, 1, 7, (V[]){v_st_2427, v_dir_2414, v_cs_242, v_hd_2415, v_x_2432, v_prog_240, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_dir_2414 = heff_env(self)[3];
  V v_k_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2427;
  if (heff_strEq_c(v_x_2425, ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str2))) {
    v_st_2427 = NTAG(TAG_Windows);
  } else {
    v_st_2427 = NTAG(TAG_Posix);
  }
  V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_242));
  V v_total_2429 = heff_intAdd(v_t_2428, MK_INT(1LL));
  V v_t_2431 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_str3), v_total_2429, ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam3_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2431, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam4, 1, 6, (V[]){v_prog_240, v_dir_2414, v_cs_242, v_hd_2415, v_st_2427, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_cs_242 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_dir_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam1_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2424, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s1115053147x1380566403_lam2, 1, 5, (V[]){v_cs_242, v_prog_240, v_hd_2415, v_dir_2414, v_k_2416})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859(V v_prog_240, V v_st_241, V v_t_242, V v_done_243, V v_progs_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_progs_244);
    return v_done_243;
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_245, 0);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_244)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_total_249 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_248));
    V v_t_2411 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_str0), heff_dup(v_home_246)), v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam0_clo)});
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2411}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam1, 2, 7, (V[]){v_t_2412, v_prog_240, v_progs_244, heff_dup(v_st_241), v_t_242, heff_dup(v_home_246), v_done_243});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_done_243 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V f_ = v_done_243;
  heff_room[0] = v_hd_2421;
  heff_room[1] = v_k_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2417 = heff_env(self)[0];
  V v_done_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2417, heff_dup(v_hd_2421), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam4, 1, 3, (V[]){v_done_243, v_hd_2421, v_k_2422})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_progs_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_246 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2415), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2416}));
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_244));
  V v_xs_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2419));
  V v_t_2424 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_246; V a_4 = v_x_2415; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam3, 2, 2, (V[]){v_t_2417, v_done_243}); V a_6 = v_t_2420; V r_ = (g_heff_2ebuild_2ecommands_2eshipAll_24s1404657929x1473885251(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_241); heff_drop(v_t_2420); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_progs_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_home_246 = heff_env(self)[5];
  V v_done_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s615738393x1686646143(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1273375929x1661251859_lam2, 1, 8, (V[]){v_prog_240, v_progs_244, v_st_241, v_t_242, v_home_246, v_done_243, v_hd_2413, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str1, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str5, 6, ": git ");
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944(V v_what_240, V v_argv_241) {
top: ;
  V v_t_242 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_243;
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    v_t_243 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str0);
  } else {
    heff_drop(v_t_242);
    v_t_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_244 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str1), heff_dup(v_argv_241), v_t_243, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_246 = heff_tag_n(TAG_Run, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam1, 2, 3, (V[]){v_a_246, v_argv_241, v_what_240});
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_take_field(v_x_2415, 0);
  V v_t_2419;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Exited: {
    V v_n_2417 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2419 = heff_intEq(v_n_2417, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_x_2430;
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2415, 3);
    heff_drop(v_argv_241);
    heff_drop(v_what_240);
    heff_drop(v_t_2419);
    v_x_2430 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2419);
    V v_t_2422;
    switch (heff_tag_of(v_argv_241)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_argv_241, 0);
      V v_xs_2421 = heff_field(v_argv_241, 1);
      heff_take_n(v_argv_241, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str3); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_argv_241);
    }
    V v_s_2423 = heff_get_n(v_x_2415, 2, 3);
    V v_t_2424 = (g_prelude_2eskipSpaces(v_s_2423, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_s_2423, 0)) - ((int64_t)1ULL));
    V v_t_2426 = (g_prelude_2eskipSpaces(v_s_2423, heff_box_word(v_t_2425), MK_INT(-1LL)));
    V v_t_2427 = heff_strSlice(v_s_2423, v_t_2424, heff_intAdd(v_t_2426, MK_INT(1LL)));
    V v_t_2428 = heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str4), v_t_2427));
    V v_t_2429 = heff_strAppend(v_what_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_str5), v_t_2428));
    v_x_2430 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2429});
  }
  V f_ = v_k_248;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_argv_241 = heff_env(self)[1];
  V v_what_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2egitOk_24s1849707033x1603609944_lam2, 1, 3, (V[]){v_argv_241, v_what_240, v_k_248})));
}