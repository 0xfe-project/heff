// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_bin 307073
#define LBL_copies 592412158
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_emits 297985818
#define LBL_ended 298010324
#define LBL_errors 652506774
#define LBL_fuel 9649789
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_mods 9852536
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_sources 357464573
#define LBL_top 324559
#define LBL_zig 330130
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_paths__hashes__modules__fuel[] = {LBL_paths, LBL_hashes, LBL_modules, LBL_fuel};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999_clo;
V g_heff_2ebuild_2ecommands_2eruntimeOf(V, V, V);
V g_heff_2ebuild_2ecommands_2eruntimeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eruntimeOf_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efits(V, V);
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efits_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s107931167x1978109134(V);
V g_list_2emap_24s107931167x1978109134_entry(V self, V *a);
extern Clo g_list_2emap_24s107931167x1978109134_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str3, 12, "the package ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str4, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str5, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str7, 13, " is for heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str8, 19, ", and this heff is ");
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_running_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_242, 5)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str0))) {
      heff_drop_rec(v_project_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_t_244 = v_deps_243;
    } else {
      v_t_244 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_project_242, v_deps_243});
    }
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_244));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){v_running_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffErrors(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_running_240 = heff_env(self)[0];
  V v_heff_248 = heff_take_field(v_x_247, 5);
  V v_own_249 = heff_take_field(v_x_247, 3);
  V v_path_2410 = heff_get_n(v_x_247, 0, 7);
  V v_wanted_2411 = v_heff_248;
  V v_t_2456;
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop(v_own_249);
    heff_drop(v_path_2410);
    heff_drop(v_wanted_2411);
    v_t_2456 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2412 = heff_field(v_running_240, 0);
    V v_ru_24running_240_24Just = heff_take_reuse_n(v_running_240, 1ULL, 1);
    V v_who_2413;
    if (heff_strEq_c(v_own_249, ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str1))) {
      heff_drop(v_path_2410);
      v_who_2413 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str2);
    } else {
      v_who_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str3), v_path_2410);
    }
    V v_wanted_2414 = heff_dup(v_wanted_2411);
    V v_running_2415 = heff_dup(v_running_2412);
    HeffT5 v_t_2416 = ({ V a_0 = v_wanted_2411; HeffT5 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_wanted_2411); r_; });
    {
      V v_field_2418 = v_t_2416.f[1];
      V v_field_2419 = v_t_2416.f[2];
      V v_field_2420 = v_t_2416.f[3];
      V v_field_2421 = v_t_2416.f[4];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      HeffT5 v_t_2422 = ({ V a_0 = v_running_2412; HeffT5 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_running_2412); r_; });
      {
        V v_field_2424 = v_t_2422.f[1];
        V v_field_2425 = v_t_2422.f[2];
        V v_field_2426 = v_t_2422.f[3];
        V v_field_2427 = v_t_2422.f[4];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        V v_t_2454;
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_field_2420, v_field_2421})});
          V v_w_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2418, v_t_2428});
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2425, heff_tag_n(TAG_Cons, 2, (V[]){v_field_2426, v_field_2427})});
            V v_r_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2424, v_t_2430});
            V v_x1_2432 = v_w_2429;
            V v_x2_2433 = v_r_2431;
            V v_t_2450;
            switch (heff_tag_of(v_x1_2432)) {
            case TAG_Nil: {
              heff_drop(v_x2_2433);
              v_t_2450 = NTAG(TAG_False);
              break;
            }
            case TAG_Cons: {
              V v_wa_2434 = heff_field(v_x1_2432, 0);
              V v_x12_2435 = heff_field(v_x1_2432, 1);
              heff_take_n(v_x1_2432, 3ULL, 2);
              switch (heff_tag_of(v_x12_2435)) {
              case TAG_Nil: {
                heff_drop(v_x2_2433);
                heff_drop(v_wa_2434);
                v_t_2450 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                V v_wb_2436 = heff_field(v_x12_2435, 0);
                V v_x122_2437 = heff_field(v_x12_2435, 1);
                heff_take_n(v_x12_2435, 3ULL, 2);
                switch (heff_tag_of(v_x122_2437)) {
                case TAG_Nil: {
                  heff_drop(v_x2_2433);
                  heff_drop(v_wa_2434);
                  heff_drop(v_wb_2436);
                  v_t_2450 = NTAG(TAG_False);
                  break;
                }
                case TAG_Cons: {
                  V v_wc_2438 = heff_field(v_x122_2437, 0);
                  V v_x1222_2439 = heff_field(v_x122_2437, 1);
                  heff_take_n(v_x122_2437, 3ULL, 2);
                  switch (heff_tag_of(v_x1222_2439)) {
                  case TAG_Nil: {
                    switch (heff_tag_of(v_x2_2433)) {
                    case TAG_Nil: {
                      heff_drop(v_wa_2434);
                      heff_drop(v_wb_2436);
                      heff_drop(v_wc_2438);
                      v_t_2450 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_Cons: {
                      V v_ra_2440 = heff_field(v_x2_2433, 0);
                      V v_x22_2441 = heff_field(v_x2_2433, 1);
                      heff_take_n(v_x2_2433, 3ULL, 2);
                      switch (heff_tag_of(v_x22_2441)) {
                      case TAG_Nil: {
                        heff_drop(v_wa_2434);
                        heff_drop(v_wb_2436);
                        heff_drop(v_wc_2438);
                        heff_drop(v_ra_2440);
                        v_t_2450 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_Cons: {
                        V v_rb_2442 = heff_field(v_x22_2441, 0);
                        V v_x222_2443 = heff_field(v_x22_2441, 1);
                        heff_take_n(v_x22_2441, 3ULL, 2);
                        switch (heff_tag_of(v_x222_2443)) {
                        case TAG_Nil: {
                          heff_drop(v_wa_2434);
                          heff_drop(v_wb_2436);
                          heff_drop(v_wc_2438);
                          heff_drop(v_ra_2440);
                          heff_drop(v_rb_2442);
                          v_t_2450 = NTAG(TAG_False);
                          break;
                        }
                        case TAG_Cons: {
                          V v_rc_2444 = heff_field(v_x222_2443, 0);
                          V v_x2222_2445 = heff_field(v_x222_2443, 1);
                          heff_take_n(v_x222_2443, 3ULL, 2);
                          switch (heff_tag_of(v_x2222_2445)) {
                          case TAG_Nil: {
                            v_t_2450 = heff_bool((heff_intEq_c_lent(v_wa_2434, MK_INT(0LL), 2) ? (heff_intEq_c_lent(v_ra_2440, MK_INT(0LL), 2) && (heff_intEq_c_lent(v_rb_2442, v_wb_2436, 0) && heff_intLe_c_lent(v_wc_2438, v_rc_2444, 0))) : (heff_intEq_c_lent(v_ra_2440, v_wa_2434, 0) && (heff_intLt_c_lent(v_wb_2436, v_rb_2442, 0) || (heff_intEq_c_lent(v_rb_2442, v_wb_2436, 0) && heff_intLe_c_lent(v_wc_2438, v_rc_2444, 0))))));
                            heff_drop(v_wa_2434);
                            heff_drop(v_wb_2436);
                            heff_drop(v_wc_2438);
                            heff_drop(v_ra_2440);
                            heff_drop(v_rb_2442);
                            heff_drop(v_rc_2444);
                            break;
                          }
                          case TAG_Cons: {
                            heff_take_n(v_x2222_2445, 0ULL, 2);
                            heff_drop(v_wa_2434);
                            heff_drop(v_wb_2436);
                            heff_drop(v_wc_2438);
                            heff_drop(v_ra_2440);
                            heff_drop(v_rb_2442);
                            heff_drop(v_rc_2444);
                            v_t_2450 = NTAG(TAG_False);
                            break;
                          }
                          default: heff_nomatch(v_x2222_2445);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x222_2443);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x22_2441);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x2_2433);
                    }
                    break;
                  }
                  case TAG_Cons: {
                    heff_take_n(v_x1222_2439, 0ULL, 2);
                    heff_drop(v_x2_2433);
                    heff_drop(v_wa_2434);
                    heff_drop(v_wb_2436);
                    heff_drop(v_wc_2438);
                    v_t_2450 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_x1222_2439);
                  }
                  break;
                }
                default: heff_nomatch(v_x122_2437);
                }
                break;
              }
              default: heff_nomatch(v_x12_2435);
              }
              break;
            }
            default: heff_nomatch(v_x1_2432);
            }
            if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24running_240_24Just, 1);
              heff_drop(v_who_2413);
              heff_drop(v_wanted_2414);
              heff_drop(v_running_2415);
              heff_drop(v_t_2450);
              v_t_2454 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_t_2450);
              V v_t_2451;
              if (heff_strEq_c(heff_strSlice_lent(v_wanted_2414, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str4))) {
                v_t_2451 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str5);
              } else {
                v_t_2451 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str6);
              }
              V v_t_2452 = heff_strAppend(heff_strAppend(v_who_2413, ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str7)), v_wanted_2414);
              V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2452, v_t_2451), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str8));
              v_t_2454 = heff_tag_at_n(v_ru_24running_240_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_t_2453, v_running_2415)});
            }
          } else {
            heff_drop_cell(v_ru_24running_240_24Just, 1);
            heff_drop(v_who_2413);
            heff_drop(v_wanted_2414);
            heff_drop(v_running_2415);
            heff_drop(v_field_2424);
            heff_drop(v_field_2425);
            heff_drop(v_field_2426);
            heff_drop(v_field_2427);
            heff_drop_tag(v_w_2429, 2);
            v_t_2454 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24running_240_24Just, 1);
          heff_drop(v_who_2413);
          heff_drop(v_wanted_2414);
          heff_drop(v_running_2415);
          heff_drop(v_field_2418);
          heff_drop(v_field_2419);
          heff_drop(v_field_2420);
          heff_drop(v_field_2421);
          heff_drop(v_field_2424);
          heff_drop(v_field_2425);
          heff_drop(v_field_2426);
          heff_drop(v_field_2427);
          v_t_2454 = NTAG(TAG_Nothing);
        }
        switch (heff_tag_of(v_t_2454)) {
        case TAG_Nothing: {
          v_t_2456 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_why_2455 = heff_field(v_t_2454, 0);
          heff_take_n(v_t_2454, 1ULL, 1);
          v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2455, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_t_2454);
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2e_2b_2b(v_t_2456, v_acc_246));
}
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_str0, 8, "HEFF_LIB");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_str2, 3, "lib");
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_str0), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s535099379x685970669(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_a_2420 = (g_heff_2ebuild_2ecommands_2eownRoot(heff_dup(v_st_2418), v_x_2419));
  V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_a_2420));
  V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2418), ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_str2)));
  V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
  heff_clo_take(self, 2);
  V v_x_2424 = ({ V a_0 = v_st_2418; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2423); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_str1))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s860931088x562283651(v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam4, 1, 2, (V[]){v_st_2418, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam2_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    heff_clo_take(self, 2);
    return (g_co_2eop_24s535099379x685970669(v_t_2416, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Just: {
    V v_lib_2425 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_hd_240);
    V f_ = v_k_241;
    args[0] = v_lib_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s535099379x685970669(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2417));
  V v_t_2419;
  heff_clo_take(self, 2);
  if (heff_strEq_c(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_str0))) {
    v_t_2419 = NTAG(TAG_Windows);
  } else {
    v_t_2419 = NTAG(TAG_Posix);
  }
  V v_x_2420 = ({ V a_0 = v_t_2419; V a_1 = v_x_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); heff_drop(v_x_2418); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(v_t_2416, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856_lam3, 1, 2, (V[]){v_x_249, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str0, 2, ".o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str1, 11, "-femit-bin=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str2, 2, "-O");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str3, 9, "build-obj");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162(V v_z_240, V v_mode_241, V v_x3_242, V v_made_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_z_240);
    heff_drop(v_mode_241);
    heff_drop(v_z_244);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_made_243));
    V v_x_247 = heff_tag_n(TAG_Right, 1, (V[]){v_t_246});
    return heff_tail(v_z_245, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_f_248 = heff_field(v_x3_242, 0);
    V v_rest_249 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_f_248, 0)) - ((int64_t)4ULL));
    V v_o_2411 = heff_strAppend(heff_strSlice_lent(v_f_248, MK_INT(0LL), heff_box_word(v_t_2410), 6), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str0));
    V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str1), heff_dup(v_o_2411)), NTAG(TAG_Nil)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str2), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_mode_241), v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_f_248, v_t_2413})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_z_240), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_str4), v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam0_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s535099379x685970669(v_t_2417, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam1, 1, 7, (V[]){v_z_240, v_mode_241, v_rest_249, v_o_2411, v_made_243, v_z_244, v_z_245})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam0(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_240 = heff_env(self)[0];
  V v_mode_241 = heff_env(self)[1];
  V v_rest_249 = heff_env(self)[2];
  V v_o_2411 = heff_env(self)[3];
  V v_made_243 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  V v_t_2419 = heff_dup(heff_rfield(v_x_2418, 0));
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Exited: {
    V v_n_2420 = heff_field(v_t_2419, 0);
    heff_take_n(v_t_2419, 1ULL, 1);
    if (heff_intEq_c(v_n_2420, MK_INT(0LL))) {
      heff_drop_rec(v_x_2418, 3);
      heff_clo_take(self, 7);
      return (g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162(v_z_240, v_mode_241, v_rest_249, heff_tag_n(TAG_Cons, 2, (V[]){v_o_2411, v_made_243}), v_z_244, v_z_245));
    } else {
      heff_clo_take(self, 7);
      heff_drop(v_z_240);
      heff_drop(v_mode_241);
      heff_drop(v_rest_249);
      heff_drop(v_o_2411);
      heff_drop(v_made_243);
      heff_drop(v_z_244);
      V f_ = v_z_245;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2418});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2419, 0ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_z_240);
    heff_drop(v_mode_241);
    heff_drop(v_rest_249);
    heff_drop(v_o_2411);
    heff_drop(v_made_243);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2418});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_TimedOut: {
    heff_clo_take(self, 7);
    heff_drop(v_z_240);
    heff_drop(v_mode_241);
    heff_drop(v_rest_249);
    heff_drop(v_o_2411);
    heff_drop(v_made_243);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2418});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2419, 0ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_z_240);
    heff_drop(v_mode_241);
    heff_drop(v_rest_249);
    heff_drop(v_o_2411);
    heff_drop(v_made_243);
    heff_drop(v_z_244);
    V f_ = v_z_245;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2418});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2419);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_str1, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(V v_path_240, V v_text_241) {
top: ;
  V v_t_242 = heff_intShow(heff_strLength_lent(v_text_241, 0));
  V v_t_243 = heff_strAppend(heff_strAppend(heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_str0)), v_t_242);
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_str1))));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_245, heff_dup(v_text_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam1, 2, 3, (V[]){v_a_247, v_path_240, v_text_241});
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_text_241 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_k_249; V a_1 = v_path_240; V a_2 = v_text_241; V a_3 = v_hd_248; V a_4 = heff_tag_re_n(v_ru_24x_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2416}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_241); r_; });
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      V v_err_2418 = heff_field(v_y_2417, 0);
      V v_ru_24y_2417_24Left = heff_take_reuse_n(v_y_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2415_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_k_249; V a_1 = v_path_240; V a_2 = v_text_241; V a_3 = v_hd_248; V a_4 = heff_tag_re_n(v_ru_24y_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2418}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_241); r_; });
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_k_249; V a_1 = v_path_240; V a_2 = v_text_241; V a_3 = v_hd_248; V a_4 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Right, 1, (V[]){v_x_2419}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_241); r_; });
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_a_247 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_text_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_lam2, 1, 4, (V[]){v_k_249, v_path_240, v_text_241, v_hd_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str2, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str4, 8, "heff.zig");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745(V v_bi_240, V v_dir_241, V v_zig_242, V v_id_243, V v_texts_244, V v_backs_245, V v_done_246, V v_out_247, V v_z_248, V v_z_249) {
top: ;
  V v_groups_2410 = heff_take_field(v_out_247, 2);
  V v_copies_2411 = heff_take_field(v_out_247, 3);
  V v_emits_2412 = heff_take_field(v_out_247, 4);
  V v_parts_2413 = heff_take_field(v_out_247, 0);
  V v_errors_2414 = heff_get_n(v_out_247, 1, 5);
  V v_paths_2415 = heff_take_field(v_bi_240, 0);
  V v_modules_2416 = heff_get_n(v_bi_240, 2, 4);
  V v_t_2452;
  if (heff_strEq_c_lent(v_id_243, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str0), 2)) {
    heff_drop(v_id_243);
    heff_drop(v_backs_245);
    heff_drop(v_groups_2410);
    heff_drop(v_copies_2411);
    heff_drop(v_emits_2412);
    heff_drop(v_paths_2415);
    heff_drop(v_modules_2416);
    v_t_2452 = v_done_246;
  } else {
    V v_s_2417 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2415)));
    V v_path_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2417));
    V v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2418; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2418); r_; });
    V v_a_2421 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam0_clo)});
    v_t_2452 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam1, 2, 10, (V[]){v_a_2421, heff_dup(v_texts_244), v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_243, v_backs_245, v_paths_2415, v_done_246});
  }
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str4), v_zig_242}), v_parts_2413});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s279022681x1881045746(v_dir_241, v_t_2452, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_errors_2414}), v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam0(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_drop(v_x_2436);
  heff_clo_take(self, 3);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam4(V self, V *args) {
  V v_x_2444 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_drop(v_x_2444);
  heff_clo_take(self, 3);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam5(V self, V *args) {
  V v_x_2451 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_drop(v_x_2451);
  heff_clo_take(self, 3);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2422;
  heff_room[1] = v_k_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_texts_244 = heff_env(self)[0];
  V v_modules_2416 = heff_env(self)[1];
  V v_groups_2410 = heff_env(self)[2];
  V v_copies_2411 = heff_env(self)[3];
  V v_emits_2412 = heff_env(self)[4];
  V v_id_243 = heff_env(self)[5];
  V v_backs_245 = heff_env(self)[6];
  V v_paths_2415 = heff_env(self)[7];
  V v_hd_2422 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  V v_k_2423 = heff_env(self)[10];
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    heff_clo_take(self, 11);
    V v_t_2431 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_244); r_; });
    V v_t_2432 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str1), NTAG(TAG_MkUnit)));
    V v_t_2433 = ({ V a_0 = v_t_2432; V a_1 = v_modules_2416; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2416); r_; });
    V v_t_2434 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2410, v_copies_2411, v_emits_2412, NTAG(TAG_Nil)});
    V v_t_2435 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2433, v_backs_245}), v_t_2434));
    return ({ V a_0 = v_paths_2415; V a_1 = v_t_2431; V a_2 = v_t_2435; V a_3 = heff_dup(v_hd_2422); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam3, 1, 3, (V[]){v_done_246, v_hd_2422, v_k_2423}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2431); heff_drop(v_t_2435); r_; });
  }
  case TAG_Right: {
    V v_y_2437 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 1);
    switch (heff_tag_of(v_y_2437)) {
    case TAG_Left: {
      heff_take_n(v_y_2437, 0ULL, 1);
      heff_clo_take(self, 11);
      V v_t_2439 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_244); r_; });
      V v_t_2440 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str2), NTAG(TAG_MkUnit)));
      V v_t_2441 = ({ V a_0 = v_t_2440; V a_1 = v_modules_2416; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2416); r_; });
      V v_t_2442 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2410, v_copies_2411, v_emits_2412, NTAG(TAG_Nil)});
      V v_t_2443 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2441, v_backs_245}), v_t_2442));
      return ({ V a_0 = v_paths_2415; V a_1 = v_t_2439; V a_2 = v_t_2443; V a_3 = heff_dup(v_hd_2422); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam4, 1, 3, (V[]){v_done_246, v_hd_2422, v_k_2423}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2439); heff_drop(v_t_2443); r_; });
    }
    case TAG_Right: {
      heff_take_n(v_y_2437, 0ULL, 1);
      heff_clo_take(self, 11);
      V v_t_2446 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_244); r_; });
      V v_t_2447 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_str3), NTAG(TAG_MkUnit)));
      V v_t_2448 = ({ V a_0 = v_t_2447; V a_1 = v_modules_2416; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2416); r_; });
      V v_t_2449 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2410, v_copies_2411, v_emits_2412, NTAG(TAG_Nil)});
      V v_t_2450 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2448, v_backs_245}), v_t_2449));
      return ({ V a_0 = v_paths_2415; V a_1 = v_t_2446; V a_2 = v_t_2450; V a_3 = heff_dup(v_hd_2422); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam5, 1, 3, (V[]){v_done_246, v_hd_2422, v_k_2423}); V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s80238109x1094652459(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2446); heff_drop(v_t_2450); r_; });
    }
    default: return heff_nomatch(v_y_2437);
    }
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_a_2421 = heff_env(self)[0];
  V v_texts_244 = heff_env(self)[1];
  V v_modules_2416 = heff_env(self)[2];
  V v_groups_2410 = heff_env(self)[3];
  V v_copies_2411 = heff_env(self)[4];
  V v_emits_2412 = heff_env(self)[5];
  V v_id_243 = heff_env(self)[6];
  V v_backs_245 = heff_env(self)[7];
  V v_paths_2415 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2421})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2428, heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1854779248x454183745_lam2, 1, 11, (V[]){v_texts_244, v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_243, v_backs_245, v_paths_2415, v_hd_2422, v_done_246, v_k_2423})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s1760561067x613639476(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_249, v_x_2414));
  heff_clo_take(self, 10);
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_rt_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2414; V a_9 = v_t_2415; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  V v_c_2413;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_str0), 2)) {
    v_c_2413 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam1_clo);
  } else {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2413 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s618556933x867255999(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2412));
  }
  heff_clo_take(self, 9);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290(V v_lit_240, V v_lit_241, V v_fuel_242, V v_l_243, V v_outPath_244, V v_file_245, V v_done_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_str0), heff_dup(heff_rfield(v_l_243, 1)), MK_INT(0LL), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam0, 1, 9, (V[]){v_l_243, v_hd_247, v_fuel_242, v_lit_240, v_k_248, v_lit_241, v_file_245, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  V v_sources_2414 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2417 = ({ V a_0 = heff_dup(v_c_2416); V a_1 = v_sources_2414; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2414); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_s_2420 = v_field_2419;
      V v_t_2421 = ({ V a_0 = v_x_2415; V a_1 = v_s_2420; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2415); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2416, v_t_2421));
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_field_2419);
      return v_c_2416;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam4(V self, V *args) {
  V v_a_2442 = args[0];
  V v_z_2443 = args[1];
  V v_z_2444 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_drop(v_a_2442);
  heff_clo_take(self, 1);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_z_2443, v_z_2444));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_cs_2423 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_247 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_done_2412 = heff_env(self)[5];
  V v_l_243 = heff_env(self)[6];
  V v_hashes_2413 = heff_env(self)[7];
  V v_fuel_242 = heff_env(self)[8];
  V v_lit_241 = heff_env(self)[9];
  V v_file_245 = heff_env(self)[10];
  V v_outPath_244 = heff_env(self)[11];
  V v_done_246 = heff_env(self)[12];
  heff_drop(v_x_2424);
  heff_clo_take(self, 13);
  if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
    heff_drop(v_done_2412);
    heff_drop_rec(v_l_243, 5);
    heff_drop(v_hashes_2413);
    heff_drop(v_fuel_242);
    heff_drop(v_lit_241);
    heff_drop(v_file_245);
    heff_drop(v_outPath_244);
    heff_drop(v_done_246);
    V v_x2_2425 = ({ V a_0 = v_cs_2423; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2423); r_; });
    heff_drop(v_x2_2425);
    V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_247, v_k_248));
  } else {
    V v_t_2432 = (g_list_2eany_24s1740858080x874135214(v_cs_2423));
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_done_2412);
      heff_drop_rec(v_l_243, 5);
      heff_drop(v_hashes_2413);
      heff_drop(v_fuel_242);
      heff_drop(v_lit_241);
      heff_drop(v_file_245);
      heff_drop(v_outPath_244);
      heff_drop(v_done_246);
      heff_drop(v_t_2432);
      V v_x2_2433 = ({ V a_0 = v_cs_2423; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_cs_2423); r_; });
      heff_drop(v_x2_2433);
      V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_247, v_k_248));
    } else {
      heff_drop(v_t_2432);
      V v_t_2440 = (g_list_2emap_24s1698496827x1884878103(v_done_2412));
      V v_t_2441 = heff_rec_n(4, shape_paths__hashes__modules__fuel, (V[]){heff_take_field(v_l_243, 2), v_hashes_2413, v_t_2440, v_fuel_242});
      return ({ V a_0 = v_lit_241; V a_1 = v_t_2441; V a_2 = heff_get_n(v_l_243, 0, 5); V a_3 = v_file_245; V a_4 = v_outPath_244; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam4, 3, 1, (V[]){v_lit_240}); V a_6 = v_done_246; V a_7 = v_cs_2423; V a_8 = v_hd_247; V a_9 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s252331588x416767530(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_cs_2423); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_fuel_242 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_file_245 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  V v_done_2412 = heff_take_field(v_x_2411, 0);
  V v_hashes_2413 = heff_get_n(v_x_2411, 1, 2);
  V v_sources_2414 = heff_dup(heff_rfield(v_l_243, 0));
  V v_x_2415 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_str2), heff_dup(v_sources_2414)));
  V v_x_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam2, 1, 2, (V[]){v_sources_2414, v_x_2415}), heff_dup(v_done_2412)));
  V v_cs_2423;
  if ((heff_dup(v_fuel_242) == NTAG(TAG_True))) {
    v_cs_2423 = v_x_2422;
  } else {
    v_cs_2423 = (g_list_2emap_24s107931167x1978109134(v_x_2422));
  }
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(heff_dup(v_cs_2423), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam3, 1, 13, (V[]){v_x_249, v_cs_2423, v_lit_240, v_hd_247, v_k_248, v_done_2412, v_l_243, v_hashes_2413, v_fuel_242, v_lit_241, v_file_245, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_fuel_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_file_245 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  V v_t_2410 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_l_243)));
  heff_clo_take(self, 9);
  V f_ = v_t_2410;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_lam1, 1, 10, (V[]){v_l_243, v_fuel_242, v_hd_247, v_x_249, v_lit_240, v_k_248, v_lit_241, v_file_245, v_outPath_244, v_done_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071(V v_host_240, V v_s_241, V v_z_242, V v_z_243) {
top: ;
  V v_p_244 = heff_dup(heff_rfield(v_s_241, 2));
  int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_244, 0)) - ((int64_t)3ULL));
  V v_t_246 = heff_strSlice_lent(v_p_244, heff_box_word(v_t_245), heff_strLength_lent(v_p_244, 0), 6);
  V v_t_248;
  if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_str0))) {
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_244, 0)) - ((int64_t)3ULL));
    v_t_248 = heff_strSlice(v_p_244, MK_INT(0LL), heff_box_word(v_t_247));
  } else {
    v_t_248 = v_p_244;
  }
  V v_s_249 = heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_str1));
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_249));
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
  V v_a_2413 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam0_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam1, 1, 4, (V[]){v_s_241, v_z_242, v_z_243, heff_dup(v_host_240)})));
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_host_240 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_s_241; V a_1 = v_z_242; V a_2 = v_z_243; V a_3 = v_host_240; V a_4 = heff_tag_re_n(v_ru_24x_2419_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2420}); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_host_240); r_; });
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Right = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      V v_err_2422 = heff_field(v_y_2421, 0);
      V v_ru_24y_2421_24Left = heff_take_reuse_n(v_y_2421, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2419_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_s_241; V a_1 = v_z_242; V a_2 = v_z_243; V a_3 = v_host_240; V a_4 = heff_tag_re_n(v_ru_24y_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2422}); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_host_240); r_; });
    }
    case TAG_Right: {
      V v_x_2423 = heff_field(v_y_2421, 0);
      heff_take_n(v_y_2421, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_s_241; V a_1 = v_z_242; V a_2 = v_z_243; V a_3 = v_host_240; V a_4 = heff_tag_at_n(v_ru_24x_2419_24Right, TAG_Right, 1, (V[]){v_x_2423}); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_host_240); r_; });
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729(V v_chk_240, V v_acc_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2echeckModule_24s1704887709x493135436(heff_dup(v_chk_240), v_acc_241, heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_lam0, 1, 4, (V[]){v_chk_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_chk_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_chk_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s293005658x2129711729(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str0, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str1, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str2, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str3, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_lam0, 1, 0};
Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587(V v_z_240, V v_flags_241, V v_links_242, V v_files_243, V v_out_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Left: {
    V v_r_248 = heff_field(v_x6_245, 0);
    heff_take_n(v_x6_245, 1ULL, 1);
    heff_drop(v_z_240);
    heff_drop(v_flags_241);
    heff_drop(v_links_242);
    heff_drop(v_files_243);
    heff_drop(v_out_244);
    heff_drop(v_z_246);
    return heff_tail(v_z_247, 1, (V[]){v_r_248});
  }
  case TAG_Right: {
    V v_os_249 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Right = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str0), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_out_244, v_t_2410})});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_links_242, v_t_2411));
    V v_t_2413 = (g_prelude_2e_2b_2b(v_os_249, v_t_2412));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_files_243, v_t_2413));
    V v_t_2415 = (g_prelude_2e_2b_2b(v_flags_241, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str2), v_t_2414})));
    V v_argv_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str3), v_t_2415});
    V v_t_2418 = heff_tag_at_n(v_ru_24x6_245_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){v_z_240, ((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_str4), v_argv_2416, ((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_lam0_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s297957795x1045074450(v_t_2419, v_z_246, v_z_247));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ezigLinked_24s805603941x1681939587_lam0(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_str1, 4, ".new");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_244);
    V v_t_248 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_242, NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam0, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
  }
  case TAG_Just: {
    V v_n_2411 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2413 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_242, heff_dup(v_n_2411), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam1_clo)})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s535099379x685970669(v_t_2414, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam2, 1, 7, (V[]){v_st_240, v_t_241, v_n_2411, v_p_246, v_x_244, v_next_243, v_p_247})));
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_drop(v_x_2410);
  heff_clo_take(self, 3);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam3(V self, V *args) {
  V v_r_2423 = args[0];
  return v_r_2423;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_n_2411 = heff_env(self)[3];
  V v_x_2420 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  V v_next_243 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_x_2431 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    heff_clo_take(self, 9);
    return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_244; V a_3 = v_n_2411; V a_4 = v_x_2420; V a_5 = v_p_246; V a_6 = v_x_2415; V a_7 = v_next_243; V a_8 = v_p_247; V b_9 = heff_tag_re_n(v_ru_24x_2430_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2431}); V r_ = (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Right = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    switch (heff_tag_of(v_y_2432)) {
    case TAG_Left: {
      V v_err_2433 = heff_field(v_y_2432, 0);
      V v_ru_24y_2432_24Left = heff_take_reuse_n(v_y_2432, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2430_24Right, 1);
      heff_clo_take(self, 9);
      return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_244; V a_3 = v_n_2411; V a_4 = v_x_2420; V a_5 = v_p_246; V a_6 = v_x_2415; V a_7 = v_next_243; V a_8 = v_p_247; V b_9 = heff_tag_re_n(v_ru_24y_2432_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2433}); V r_ = (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_y_2432, 0);
      heff_take_n(v_y_2432, 1ULL, 1);
      heff_clo_take(self, 9);
      return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_x_244; V a_3 = v_n_2411; V a_4 = v_x_2420; V a_5 = v_p_246; V a_6 = v_x_2415; V a_7 = v_next_243; V a_8 = v_p_247; V b_9 = heff_tag_at_n(v_ru_24x_2430_24Right, TAG_Right, 1, (V[]){v_x_2434}); V r_ = (g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9)); heff_drop(b_9); r_; });
    }
    default: return heff_nomatch(v_y_2432);
    }
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_2411 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 1))));
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_str0), heff_dup(v_n_2411)), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_str1));
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2417));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2416, v_t_2418));
  V v_x_2420 = ({ V a_0 = v_st_240; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_path_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2420)));
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
  V v_a_2424 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam3_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2429, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s570754186x313784037_lam4, 1, 9, (V[]){v_st_240, v_t_241, v_x_244, v_n_2411, v_x_2420, v_p_246, v_x_2415, v_next_243, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156(V v_st_240, V v_t_241, V v_home_242, V v_dir_243, V v_next_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s967569420x452938856(heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam0, 1, 7, (V[]){v_st_240, v_home_242, v_dir_243, v_hd_245, v_k_246, v_t_241, v_next_244})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam1(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_x_2428 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    heff_clo_take(self, 6);
    return (g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0(v_st_240, v_home_242, v_hd_245, v_k_246, v_t_241, v_next_244, heff_tag_re_n(v_ru_24x_2427_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2428})));
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    switch (heff_tag_of(v_y_2429)) {
    case TAG_Left: {
      V v_err_2430 = heff_field(v_y_2429, 0);
      V v_ru_24y_2429_24Left = heff_take_reuse_n(v_y_2429, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2427_24Right, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0(v_st_240, v_home_242, v_hd_245, v_k_246, v_t_241, v_next_244, heff_tag_re_n(v_ru_24y_2429_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2430})));
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_y_2429, 0);
      heff_take_n(v_y_2429, 1ULL, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_2ek_24l0(v_st_240, v_home_242, v_hd_245, v_k_246, v_t_241, v_next_244, heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Right, 1, (V[]){v_x_2431})));
    }
    default: return heff_nomatch(v_y_2429);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_str0)));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_s_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_247));
  heff_clo_take(self, 7);
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_243));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  V v_t_2416 = ({ V a_0 = v_st_240; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2eutil_2ehostpath_2enormalize(heff_dup(v_st_240), v_t_2416));
  V v_text_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_str1));
  V v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
  V v_a_2421 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2419, v_text_2418, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam1_clo)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2426, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1836603822x1021975156_lam2, 1, 6, (V[]){v_st_240, v_home_242, v_hd_245, v_k_246, v_t_241, v_next_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str0, 31, " is not a computation, `Co h a`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str1, 14, "no definition ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str5, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str7, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1(V v_tok_240, V v_lit_241, V v_bi_242, V v_file_243, V v_outPath_244, V v_rt_245, V v_failed_246, V v_done_247, V v_c_248, V v_available_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_248)));
  V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2413));
  V v_handled_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_lam0, 1, 1, (V[]){heff_dup(v_available_249)}), v_t_2414));
  HeffT2 v_t_2417 = (g_list_2efind_24s279352081x1530195138_24cpr(v_lit_241, heff_rfield(v_c_248, 7)));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    V v_t_2426;
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_o_2420 = v_field_2419;
      HeffT2 v_t_2421 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(heff_dup(v_c_248), heff_rfield(v_o_2420, 1)));
      {
        V v_field_2423 = v_t_2421.f[1];
        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
        if ((v_tag_2422 == ((int64_t)0ULL))) {
          heff_drop_cell(v_tok_240, 1);
          V v_eff_2424 = v_field_2423;
          V v_t_2425 = heff_rec_n(3, shape_name__key__effect, (V[]){v_lit_241, heff_get_n(v_o_2420, 1, 2), v_eff_2424});
          v_t_2426 = ({ V a_0 = v_handled_2416; V a_1 = v_t_2425; V r_ = (g_heff_2ebuild_2edriver_2efits(a_0, a_1)); heff_drop(v_handled_2416); r_; });
        } else {
          heff_drop(v_handled_2416);
          heff_drop_rec(v_o_2420, 2);
          heff_drop(v_field_2423);
          v_t_2426 = heff_tag_at_n(v_tok_240, TAG_Left, 1, (V[]){heff_strAppend(v_lit_241, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str0))});
        }
      }
    } else {
      heff_drop(v_handled_2416);
      heff_drop(v_field_2419);
      v_t_2426 = heff_tag_at_n(v_tok_240, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str1), v_lit_241)});
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Left: {
      V v_why_2427 = heff_field(v_t_2426, 0);
      V v_ru_24t_2426_24Left = heff_take_reuse_n(v_t_2426, 1ULL, 1);
      heff_drop_rec(v_bi_242, 4);
      heff_drop(v_outPath_244);
      heff_drop_rec(v_rt_245, 4);
      heff_drop(v_done_247);
      heff_drop_rec(v_c_248, 14);
      heff_drop(v_available_249);
      V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str2), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str3));
      V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, heff_dup(v_why_2427)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str4));
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_at_n(v_ru_24t_2426_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_z_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_lam1, 1, 5, (V[]){v_file_243, v_failed_246, v_why_2427, v_z_2410, v_z_2411})));
    }
    case TAG_Right: {
      V v_r_2438 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      heff_drop(v_file_243);
      heff_drop(v_failed_246);
      int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
      V v_t_2440 = heff_strSlice_lent(v_outPath_244, heff_box_word(v_t_2439), heff_strLength_lent(v_outPath_244, 0), 6);
      if (heff_strEq_c(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str7))) {
        int64_t v_t_2441 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s472493999x415116268(v_bi_242, heff_strSlice(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2441)), v_rt_245, v_done_247, v_c_248, v_available_249, v_r_2438, v_z_2410, v_z_2411));
      } else {
        V v_t_2442 = (g_heff_2ebuild_2ecommands_2eruntimeOf(heff_rfield(v_bi_242, 3), v_available_249, heff_dup(v_rt_245)));
        V v_t_2443 = heff_get_n(heff_get_n(v_c_248, 5, 14), 0, 10);
        V v_t_2444 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_get_n(v_bi_242, 3, 4), v_t_2442, v_available_249, v_t_2443, heff_take_field(v_r_2438, 0), heff_get_n(v_r_2438, 1, 2)));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1736748095x1222258348(v_outPath_244, heff_get_n(v_rt_245, 1, 4), v_done_247, v_t_2444, v_z_2410, v_z_2411));
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_lam0(V self, V *args) {
  V v_k_2415 = args[0];
  V v_available_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_249; V a_1 = v_k_2415; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_249); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_lam1(V self, V *args) {
  V v_x_2436 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2427 = heff_env(self)[2];
  V v_z_2410 = heff_env(self)[3];
  V v_z_2411 = heff_env(self)[4];
  heff_drop(v_x_2436);
  heff_clo_take(self, 5);
  V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str5), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1034210625x1782479736_24tok1_str6));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2437, v_why_2427);
  heff_room[1] = v_z_2410;
  heff_room[2] = v_z_2411;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}