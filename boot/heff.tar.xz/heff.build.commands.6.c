// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_c 317
#define LBL_copies 592412158
#define LBL_diags 296935042
#define LBL_effect 641056956
#define LBL_emitted 749050271
#define LBL_errors 652506774
#define LBL_fresh 299054408
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_info 9732469
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_units 312791945
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_info[] = {LBL_info};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_output__groups__copies__jss[] = {LBL_output, LBL_groups, LBL_copies, LBL_jss};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_clo;
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054(V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2efits(V, V);
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efits_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ecompile_2eemit_2eemitKeptIn(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitKeptIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitKeptIn_clo;
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2efusedOf(V, V);
V g_heff_2ecompile_2elower_2efusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2efusedOf_clo;
HeffT3 g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr(V, V, V);
HeffT4 g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(V, V, V, V);
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s279352081x1530195138_24cpr(V, V);
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1246062630x1975509602(V, V);
V g_list_2efoldl_24s1246062630x1975509602_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1246062630x1975509602_clo;
V g_list_2efoldl_24s1272156913x1766532544(V, V);
V g_list_2efoldl_24s1272156913x1766532544_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1272156913x1766532544_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1707192740x1747748619(V, V);
V g_list_2efoldl_24s1707192740x1747748619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1707192740x1747748619_clo;
V g_list_2efoldl_24s552376067x1255995125(V, V);
V g_list_2efoldl_24s552376067x1255995125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s552376067x1255995125_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1730403549x1479772376(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1730403549x1479772376_entry(V self, V *a);
extern Clo g_list_2emap_24f1730403549x1479772376_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1325317589x1506218481(V, V, V);
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_clo;
V g_list_2emap_24s159228909x554161698(V, V, V, V);
V g_list_2emap_24s159228909x554161698_entry(V self, V *a);
extern Clo g_list_2emap_24s159228909x554161698_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s328934344x1728860012(V, V);
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_clo;
V g_list_2emap_24s456574265x331130481(V, V, V, V, V);
V g_list_2emap_24s456574265x331130481_entry(V self, V *a);
extern Clo g_list_2emap_24s456574265x331130481_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2efilesystem_2ecopy_24s224212859x272253807(V, V, V);
V g_std_2efilesystem_2ecopy_24s224212859x272253807_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ecopy_24s224212859x272253807_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2emove_24s1592691554x274375227(V, V, V);
V g_std_2efilesystem_2emove_24s1592691554x274375227_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emove_24s1592691554x274375227_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str3, 12, "the package ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str4, 13, " is for heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str5, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str6, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str8, 19, ", and this heff is ");
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_running_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_242, 5)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str0))) {
      heff_drop_rec(v_project_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_t_244 = v_deps_243;
    } else {
      v_t_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
    }
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_244));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){v_running_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_245; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffErrors(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_246 = args[0];
  V v_x_247 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_heff_248 = heff_take_field(v_x_247, 5);
  V v_own_249 = heff_take_field(v_x_247, 3);
  V v_path_2410 = heff_get_n(v_x_247, 0, 7);
  V v_wanted_2411 = v_heff_248;
  V v_t_2456;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop(v_own_249);
    heff_drop(v_path_2410);
    heff_drop(v_wanted_2411);
    v_t_2456 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2412 = heff_field(v_running_240, 0);
    V v_ru_24running_240_24Just = heff_take_reuse_n(v_running_240, 1ULL, 1);
    V v_who_2413;
    if (heff_strEq_c(v_own_249, ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str1))) {
      heff_drop(v_path_2410);
      v_who_2413 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str2);
    } else {
      v_who_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str3), v_path_2410);
    }
    V v_wanted_2414 = heff_dup(v_wanted_2411);
    V v_running_2415 = heff_dup(v_running_2412);
    HeffT5 v_t_2416 = ({ V a_0 = v_wanted_2411; HeffT5 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_wanted_2411); r_; });
    V v_t_2454;
    {
      V v_field_2418 = v_t_2416.f[1];
      V v_field_2419 = v_t_2416.f[2];
      V v_field_2420 = v_t_2416.f[3];
      V v_field_2421 = v_t_2416.f[4];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      HeffT5 v_t_2422 = ({ V a_0 = v_running_2412; HeffT5 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_running_2412); r_; });
      {
        V v_field_2424 = v_t_2422.f[1];
        V v_field_2425 = v_t_2422.f[2];
        V v_field_2426 = v_t_2422.f[3];
        V v_field_2427 = v_t_2422.f[4];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_field_2420, v_field_2421})});
          V v_w_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2418, v_t_2428});
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2425, heff_tag_n(TAG_Cons, 2, (V[]){v_field_2426, v_field_2427})});
            V v_r_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2424, v_t_2430});
            V v_x1_2432 = v_w_2429;
            V v_x2_2433 = v_r_2431;
            V v_t_2450;
            switch (heff_tag_of(v_x1_2432)) {
            case TAG_Nil: {
              heff_drop(v_x2_2433);
              v_t_2450 = NTAG(TAG_False);
              break;
            }
            case TAG_Cons: {
              V v_wa_2434 = heff_field(v_x1_2432, 0);
              V v_x12_2435 = heff_field(v_x1_2432, 1);
              heff_take_n(v_x1_2432, 3ULL, 2);
              switch (heff_tag_of(v_x12_2435)) {
              case TAG_Nil: {
                heff_drop(v_x2_2433);
                heff_drop(v_wa_2434);
                v_t_2450 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                V v_wb_2436 = heff_field(v_x12_2435, 0);
                V v_x122_2437 = heff_field(v_x12_2435, 1);
                heff_take_n(v_x12_2435, 3ULL, 2);
                switch (heff_tag_of(v_x122_2437)) {
                case TAG_Nil: {
                  heff_drop(v_x2_2433);
                  heff_drop(v_wa_2434);
                  heff_drop(v_wb_2436);
                  v_t_2450 = NTAG(TAG_False);
                  break;
                }
                case TAG_Cons: {
                  V v_wc_2438 = heff_field(v_x122_2437, 0);
                  V v_x1222_2439 = heff_field(v_x122_2437, 1);
                  heff_take_n(v_x122_2437, 3ULL, 2);
                  switch (heff_tag_of(v_x1222_2439)) {
                  case TAG_Nil: {
                    switch (heff_tag_of(v_x2_2433)) {
                    case TAG_Nil: {
                      heff_drop(v_wa_2434);
                      heff_drop(v_wb_2436);
                      heff_drop(v_wc_2438);
                      v_t_2450 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_Cons: {
                      V v_ra_2440 = heff_field(v_x2_2433, 0);
                      V v_x22_2441 = heff_field(v_x2_2433, 1);
                      heff_take_n(v_x2_2433, 3ULL, 2);
                      switch (heff_tag_of(v_x22_2441)) {
                      case TAG_Nil: {
                        heff_drop(v_wa_2434);
                        heff_drop(v_wb_2436);
                        heff_drop(v_wc_2438);
                        heff_drop(v_ra_2440);
                        v_t_2450 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_Cons: {
                        V v_rb_2442 = heff_field(v_x22_2441, 0);
                        V v_x222_2443 = heff_field(v_x22_2441, 1);
                        heff_take_n(v_x22_2441, 3ULL, 2);
                        switch (heff_tag_of(v_x222_2443)) {
                        case TAG_Nil: {
                          heff_drop(v_wa_2434);
                          heff_drop(v_wb_2436);
                          heff_drop(v_wc_2438);
                          heff_drop(v_ra_2440);
                          heff_drop(v_rb_2442);
                          v_t_2450 = NTAG(TAG_False);
                          break;
                        }
                        case TAG_Cons: {
                          V v_rc_2444 = heff_field(v_x222_2443, 0);
                          V v_x2222_2445 = heff_field(v_x222_2443, 1);
                          heff_take_n(v_x222_2443, 3ULL, 2);
                          switch (heff_tag_of(v_x2222_2445)) {
                          case TAG_Nil: {
                            v_t_2450 = heff_bool((heff_intEq_c_lent(v_wa_2434, MK_INT(0LL), 2) ? (heff_intEq_c_lent(v_ra_2440, MK_INT(0LL), 2) && (heff_intEq_c_lent(v_rb_2442, v_wb_2436, 0) && heff_intLe_c_lent(v_wc_2438, v_rc_2444, 0))) : (heff_intEq_c_lent(v_ra_2440, v_wa_2434, 0) && (heff_intLt_c_lent(v_wb_2436, v_rb_2442, 0) || (heff_intEq_c_lent(v_rb_2442, v_wb_2436, 0) && heff_intLe_c_lent(v_wc_2438, v_rc_2444, 0))))));
                            heff_drop(v_wa_2434);
                            heff_drop(v_wb_2436);
                            heff_drop(v_wc_2438);
                            heff_drop(v_ra_2440);
                            heff_drop(v_rb_2442);
                            heff_drop(v_rc_2444);
                            break;
                          }
                          case TAG_Cons: {
                            heff_take_n(v_x2222_2445, 0ULL, 2);
                            heff_drop(v_wa_2434);
                            heff_drop(v_wb_2436);
                            heff_drop(v_wc_2438);
                            heff_drop(v_ra_2440);
                            heff_drop(v_rb_2442);
                            heff_drop(v_rc_2444);
                            v_t_2450 = NTAG(TAG_False);
                            break;
                          }
                          default: heff_nomatch(v_x2222_2445);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x222_2443);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x22_2441);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x2_2433);
                    }
                    break;
                  }
                  case TAG_Cons: {
                    heff_take_n(v_x1222_2439, 0ULL, 2);
                    heff_drop(v_x2_2433);
                    heff_drop(v_wa_2434);
                    heff_drop(v_wb_2436);
                    heff_drop(v_wc_2438);
                    v_t_2450 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_x1222_2439);
                  }
                  break;
                }
                default: heff_nomatch(v_x122_2437);
                }
                break;
              }
              default: heff_nomatch(v_x12_2435);
              }
              break;
            }
            default: heff_nomatch(v_x1_2432);
            }
            if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24running_240_24Just, 1);
              heff_drop(v_who_2413);
              heff_drop(v_wanted_2414);
              heff_drop(v_running_2415);
              heff_drop(v_t_2450);
              v_t_2454 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_t_2450);
              V v_t_2451 = heff_strAppend(heff_strAppend(v_who_2413, ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str4)), heff_dup(v_wanted_2414));
              V v_t_2452;
              if (heff_strEq_c(heff_strSlice(v_wanted_2414, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str5))) {
                v_t_2452 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str6);
              } else {
                v_t_2452 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str7);
              }
              V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2451, v_t_2452), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str8));
              v_t_2454 = heff_tag_at_n(v_ru_24running_240_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_t_2453, v_running_2415)});
            }
          } else {
            heff_drop_cell(v_ru_24running_240_24Just, 1);
            heff_drop(v_who_2413);
            heff_drop(v_wanted_2414);
            heff_drop(v_running_2415);
            heff_drop(v_field_2424);
            heff_drop(v_field_2425);
            heff_drop(v_field_2426);
            heff_drop(v_field_2427);
            heff_drop_tag(v_w_2429, 2);
            v_t_2454 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24running_240_24Just, 1);
          heff_drop(v_who_2413);
          heff_drop(v_wanted_2414);
          heff_drop(v_running_2415);
          heff_drop(v_field_2418);
          heff_drop(v_field_2419);
          heff_drop(v_field_2420);
          heff_drop(v_field_2421);
          heff_drop(v_field_2424);
          heff_drop(v_field_2425);
          heff_drop(v_field_2426);
          heff_drop(v_field_2427);
          v_t_2454 = NTAG(TAG_Nothing);
        }
      }
    }
    switch (heff_tag_of(v_t_2454)) {
    case TAG_Nothing: {
      v_t_2456 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_why_2455 = heff_field(v_t_2454, 0);
      heff_take_n(v_t_2454, 1ULL, 1);
      v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2455, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2454);
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2e_2b_2b(v_t_2456, v_acc_246));
}
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(V v_e_240, V v_ps_241, V v_olds_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_ps_241, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam0_clo);
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_m_248 = heff_field(v_x31_246, 0);
      V v_text_249 = heff_field(v_x31_246, 1);
      HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_olds_242, v_m_248));
      V v_t_2414;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_x_2413 = v_field_2412;
          v_t_2414 = v_x_2413;
        } else {
          heff_drop(v_field_2412);
          v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_str0);
        }
      }
      V v_c_2423;
      if (heff_strEq_c_lent(v_text_249, v_t_2414, 2)) {
        v_c_2423 = ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam1_clo);
      } else {
        V v_d_2417 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
        V v_st_2418 = heff_dup(heff_rfield(v_ps_241, 5));
        V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_d_2417));
        V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_strAppend(heff_dup(v_m_248), ((V)&g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_str1))));
        V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
        V v_t_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
        v_c_2423 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911(heff_dup(v_e_240), v_t_2422, heff_dup(v_text_249)));
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam2, 2, 5, (V[]){v_c_2423, v_e_240, v_ps_241, heff_dup(v_olds_242), heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_olds_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2426);
  V v_t_2427 = ({ V a_0 = v_e_240; V a_1 = v_ps_241; V a_2 = v_olds_242; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(a_0, a_1, a_2, a_3)); heff_drop(v_olds_242); heff_drop(v_rest_247); r_; });
  V f_ = v_t_2427;
  heff_room[0] = v_hd_2424;
  heff_room[1] = v_k_2425;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_olds_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_lam3, 1, 6, (V[]){v_e_240, v_ps_241, v_olds_242, v_rest_247, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str0, 31, " is not a computation, `Co h a`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str1, 14, "no definition ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str2, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str5, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str7, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010(V v_lit_240, V v_e_241, V v_bi_242, V v_file_243, V v_outPath_244, V v_rt_245, V v_failed_246, V v_done_247, V v_c_248, V v_available_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_248)));
  V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2413));
  V v_handled_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_lam0, 1, 1, (V[]){heff_dup(v_available_249)}), v_t_2414));
  HeffT2 v_t_2417 = (g_list_2efind_24s279352081x1530195138_24cpr(v_lit_240, heff_rfield(v_c_248, 7)));
  V v_t_2426;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_o_2420 = v_field_2419;
      HeffT2 v_t_2421 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(heff_dup(v_c_248), heff_rfield(v_o_2420, 1)));
      {
        V v_field_2423 = v_t_2421.f[1];
        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
        if ((v_tag_2422 == ((int64_t)0ULL))) {
          V v_eff_2424 = v_field_2423;
          V v_t_2425 = heff_rec_n(3, shape_name__key__effect, (V[]){v_lit_240, heff_get_n(v_o_2420, 1, 2), v_eff_2424});
          v_t_2426 = ({ V a_0 = v_handled_2416; V a_1 = v_t_2425; V r_ = (g_heff_2ebuild_2edriver_2efits(a_0, a_1)); heff_drop(v_handled_2416); r_; });
        } else {
          heff_drop(v_handled_2416);
          heff_drop_rec(v_o_2420, 2);
          heff_drop(v_field_2423);
          v_t_2426 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str0))});
        }
      }
    } else {
      heff_drop(v_handled_2416);
      heff_drop(v_field_2419);
      v_t_2426 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str1), v_lit_240)});
    }
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Left: {
    V v_why_2427 = heff_field(v_t_2426, 0);
    V v_ru_24t_2426_24Left = heff_take_reuse_n(v_t_2426, 1ULL, 1);
    heff_drop(v_bi_242);
    heff_drop(v_outPath_244);
    heff_drop_rec(v_rt_245, 2);
    heff_drop(v_done_247);
    heff_drop_rec(v_c_248, 14);
    heff_drop(v_available_249);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str2), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str3));
    V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, heff_dup(v_why_2427)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str4));
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_at_n(v_ru_24t_2426_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s310169282x2049378029(v_e_241, heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_lam1, 1, 5, (V[]){v_file_243, v_failed_246, v_why_2427, v_z_2410, v_z_2411})));
  }
  case TAG_Right: {
    V v_r_2439 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    heff_drop(v_file_243);
    heff_drop(v_failed_246);
    int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
    V v_t_2441 = heff_strSlice(heff_dup(v_outPath_244), heff_box_word(v_t_2440), heff_strLength_lent(v_outPath_244, 0));
    if (heff_strEq_c(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str7))) {
      int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
      return (g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275(v_e_241, v_bi_242, heff_strSlice(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2442)), v_rt_245, v_done_247, v_c_248, v_available_249, v_r_2439, v_z_2410, v_z_2411));
    } else {
      heff_drop(v_bi_242);
      V v_t_2443 = heff_get_n(heff_get_n(v_c_248, 5, 14), 0, 10);
      V v_t_2444 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_take_field(v_rt_245, 0), v_available_249, v_t_2443, heff_take_field(v_r_2439, 0), heff_get_n(v_r_2439, 1, 2)));
      return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039(v_e_241, v_outPath_244, heff_get_n(v_rt_245, 1, 2), v_done_247, v_t_2444, v_z_2410, v_z_2411));
    }
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_lam0(V self, V *args) {
  V v_k_2415 = args[0];
  V v_available_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_249; V a_1 = v_k_2415; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_249); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_lam1(V self, V *args) {
  V v_x_2437 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2427 = heff_env(self)[2];
  V v_z_2410 = heff_env(self)[3];
  V v_z_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str5), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_str6));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2438, v_why_2427);
  heff_room[1] = v_z_2410;
  heff_room[2] = v_z_2411;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_str0, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(V v_e_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_244, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_str0)), NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_lam0, 1, 4, (V[]){v_e_240, v_rest_245, v_p_242, v_p_243}));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2413);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(v_e_240, v_rest_245, v_p_242, v_p_243));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str7, 1, ".");
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104(V v_e_240, V v_bi_241, V v_outPath_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  V v_key_249 = heff_take_field(v_r_246, 0);
  V v_effect_2410 = heff_get_n(v_r_246, 1, 2);
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(heff_dup(v_e_240), heff_dup(heff_rfield(v_bi_241, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam0, 1, 10, (V[]){v_bi_241, v_e_240, v_hd_247, v_available_245, v_c_244, v_key_249, v_effect_2410, v_outPath_242, v_done_243, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam3(V self, V *args) {
  V v_acc_2458 = args[0];
  V v_k_2459 = args[1];
  V v_shorts_2457 = heff_env(self)[0];
  V v_facts_2452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2eemit_2einfoOne(v_shorts_2457, v_facts_2452, v_acc_2458, v_k_2459));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_available_245 = heff_env(self)[1];
  V v_c_244 = heff_env(self)[2];
  V v_key_249 = heff_env(self)[3];
  V v_effect_2410 = heff_env(self)[4];
  V v_bi_241 = heff_env(self)[5];
  V v_e_240 = heff_env(self)[6];
  V v_outPath_242 = heff_env(self)[7];
  V v_done_243 = heff_env(self)[8];
  V v_hd_247 = heff_env(self)[9];
  V v_k_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2411, v_x_2416));
  V v_available_2418 = v_available_245;
  V v_g_2419 = heff_get_n(heff_get_n(v_c_244, 5, 14), 0, 10);
  V v_key_2420 = v_key_249;
  V v_eff_2421 = v_effect_2410;
  V v_vers_2422 = heff_dup(heff_rfield(v_bi_241, 1));
  V v_m_2423 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2411, v_x_2416));
  V v_t_2424 = ({ V a_0 = v_m_2423; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2423); r_; });
  V v_bs_2425 = (g_list_2emap_24s1173914895x100384474(v_t_2424));
  V v_t_2426 = (g_list_2efoldl_24s1707192740x1747748619(heff_dup(g_std_2eordmap_2eempty_get()), v_bs_2425));
  V v_t_2427 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2425; V r_ = (g_list_2efoldl_24s552376067x1255995125(a_0, a_1)); heff_drop(v_bs_2425); r_; });
  V v_ks_2428 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2426, v_t_2427});
  V v_m_2429 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2411, v_x_2416));
  V v_t_2430 = ({ V a_0 = v_m_2429; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2429); r_; });
  V v_bs_2431 = (g_list_2emap_24s1173914895x100384474(v_t_2430));
  V v_kept_2432 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2431; V r_ = (g_list_2efoldl_24s1246062630x1975509602(a_0, a_1)); heff_drop(v_bs_2431); r_; });
  V v_t_2433 = (g_heff_2eelab_2eeffect_2eleaves(v_eff_2421));
  V v_xs_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str2); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str3); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str4); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str5); V a_6 = v_t_2433; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
  V v_t_2435 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_2434));
  V v_provs_2436 = ({ V a_0 = v_available_2418; V a_1 = v_t_2435; V r_ = (g_heff_2ecompile_2eemit_2eprovsForGo(a_0, a_1)); heff_drop(v_available_2418); r_; });
  V v_eff_2437 = v_eff_2421;
  V v_key_2438 = heff_dup(v_key_2420);
  V v_kept_2439 = v_kept_2432;
  HeffT4 v_t_2440 = (g_heff_2ecompile_2elower_2elowerProgramKept_24cpr(v_g_2419, v_key_2420, v_vers_2422, v_ks_2428));
  V v_t_2465;
  {
    V v_field_2441 = v_t_2440.f[0];
    V v_field_2442 = v_t_2440.f[1];
    V v_field_2443 = v_t_2440.f[2];
    V v_field_2444 = v_t_2440.f[3];
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
    V v_t_2447 = (g_heff_2ecompile_2elower_2efusedOf(v_t_2446, v_field_2441));
    HeffT3 v_t_2448 = (g_heff_2ecompile_2elower_2efusedWith_24s413320342x1752151587_24cpr(v_t_2445, v_field_2442, v_t_2447));
    {
      V v_field_2449 = v_t_2448.f[0];
      V v_field_2450 = v_t_2448.f[1];
      V v_field_2451 = v_t_2448.f[2];
      V v_facts_2452 = v_field_2450;
      V v_defs_2453 = v_field_2449;
      V v_roots_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
      V v_kept_2455 = v_kept_2439;
      V v_keys_2456 = (g_list_2emap_24s1835183789x486277886(heff_dup(v_defs_2453)));
      V v_shorts_2457 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str6); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str7); V b_3 = MK_INT(0LL); V a_4 = heff_dup(v_keys_2456); V r_ = (g_list_2emap_24s456574265x331130481(b_0, a_1, b_2, b_3, a_4)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2460 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam3, 2, 2, (V[]){v_shorts_2457, v_facts_2452}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_keys_2456; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_keys_2456); r_; });
      V v_ek_2461 = ({ V a_0 = heff_rec_n(1, shape_info, (V[]){v_t_2460}); V a_1 = v_defs_2453; V a_2 = v_roots_2454; V a_3 = v_kept_2455; V r_ = (g_heff_2ecompile_2eemit_2eemitKeptIn(a_0, a_1, a_2, a_3)); heff_drop(v_defs_2453); r_; });
      V v_emitted_2462 = heff_take_field(v_ek_2461, 0);
      V v_fresh_2463 = heff_get_n(v_ek_2461, 1, 2);
      V v_t_2464 = ({ V a_0 = v_provs_2436; V a_1 = v_eff_2437; V a_2 = v_key_2438; V a_3 = v_emitted_2462; V r_ = (g_heff_2ecompile_2eemit_2erunSource(a_0, a_1, a_2, a_3)); heff_drop(v_key_2438); r_; });
      v_t_2465 = heff_rec_n(4, shape_output__groups__copies__jss, (V[]){heff_rec_n(2, shape_source__errors, (V[]){v_t_2464, v_field_2451}), v_field_2443, v_field_2444, v_fresh_2463});
    }
  }
  return ({ V a_0 = v_e_240; V a_1 = v_bi_241; V a_2 = v_outPath_242; V a_3 = v_x_2411; V a_4 = v_x_2416; V a_5 = v_t_2417; V a_6 = v_done_243; V a_7 = v_t_2465; V a_8 = v_hd_247; V a_9 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s2132019624x2059210236(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_x_2416); r_; });
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_bi_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_available_245 = heff_env(self)[3];
  V v_c_244 = heff_env(self)[4];
  V v_key_249 = heff_env(self)[5];
  V v_effect_2410 = heff_env(self)[6];
  V v_outPath_242 = heff_env(self)[7];
  V v_done_243 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2415;
  if (heff_strEq_c_lent(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str0), 2)) {
    v_c_2415 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam1_clo);
  } else {
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_str1), heff_dup(heff_rfield(v_bi_241, 2))});
    v_c_2415 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(heff_dup(v_e_240), heff_dup(heff_rfield(v_bi_241, 0)), v_t_2414));
  }
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104_lam2, 1, 11, (V[]){v_x_2411, v_available_245, v_c_244, v_key_249, v_effect_2410, v_bi_241, v_e_240, v_outPath_242, v_done_243, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476(V v_e_240, V v_bi_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_c_246, V v_available_247, V v_z_248, V v_z_249) {
top: ;
  V v_t_2410 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_246)));
  V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2411));
  V v_t_2414 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_lam0, 1, 1, (V[]){heff_dup(v_available_247)}), v_t_2412));
  HeffT2 v_t_2415 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2414, heff_dup(v_c_246), v_name_243));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop(v_bi_241);
      heff_drop(v_outPath_244);
      heff_drop(v_done_245);
      heff_drop(v_c_246);
      heff_drop(v_available_247);
      V v_why_2418 = v_field_2417;
      V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_str0), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_str1));
      V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, v_why_2418), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_str2));
      V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2420, NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_lam1, 1, 3, (V[]){v_e_240, v_z_248, v_z_249})));
    } else {
      heff_drop(v_file_242);
      V v_r_2436 = v_field_2417;
      return (g_heff_2ebuild_2ecommands_2ejsKept_24s291196084x1891705104(v_e_240, v_bi_241, v_outPath_244, v_done_245, v_c_246, v_available_247, v_r_2436, v_z_248, v_z_249));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_lam0(V self, V *args) {
  V v_k_2413 = args[0];
  V v_available_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_247; V a_1 = v_k_2413; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_247); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1058670786x1658332476_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_str1, 4, "page");
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947(V v_e_240, V v_bi_241, V v_sources_242, V v_file_243, V v_name_244, V v_outPath_245, V v_done_246, V v_badL_247, V v_checked_248, V v_z_249, V v_z_2410) {
top: ;
  V v_c_2411 = ({ V a_0 = heff_dup(v_e_240); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_str0); V a_2 = heff_dup(v_sources_242); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam0, 1, 11, (V[]){v_sources_242, v_checked_248, v_e_240, v_z_249, heff_dup(v_badL_247), v_z_2410, v_bi_241, v_file_243, heff_dup(v_name_244), v_outPath_245, v_done_246})});
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947(a[0], a[1], a[2], a[3], a4, a[5], a[6], a7, a[8], a[9], a[10]); heff_drop(a4); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam1(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_c_2415); V a_1 = v_sources_242; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_242); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2418;
      V v_t_2420 = ({ V a_0 = v_x_2414; V a_1 = v_s_2419; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2414); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2420));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_badL_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_249 = heff_env(self)[2];
  V v_z_2410 = heff_env(self)[3];
  V v_x_2421 = heff_env(self)[4];
  V v_bi_241 = heff_env(self)[5];
  V v_sources_242 = heff_env(self)[6];
  V v_file_243 = heff_env(self)[7];
  V v_name_244 = heff_env(self)[8];
  V v_outPath_245 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2422);
  if ((heff_dup(v_badL_247) == NTAG(TAG_True))) {
    heff_drop(v_badL_247);
    heff_drop(v_x_2421);
    heff_drop(v_bi_241);
    heff_drop(v_sources_242);
    heff_drop(v_file_243);
    heff_drop(v_name_244);
    heff_drop(v_outPath_245);
    heff_drop(v_done_246);
    V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_z_249, v_z_2410));
  } else {
    heff_drop(v_badL_247);
    V v_t_2430 = (g_list_2eany_24s1740858080x874135214(v_x_2421));
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_x_2421);
      heff_drop(v_bi_241);
      heff_drop(v_sources_242);
      heff_drop(v_file_243);
      heff_drop(v_name_244);
      heff_drop(v_outPath_245);
      heff_drop(v_done_246);
      heff_drop(v_t_2430);
      V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_z_249, v_z_2410));
    } else {
      heff_drop(v_t_2430);
      return ({ V a_0 = v_e_240; V a_1 = v_bi_241; V a_2 = v_sources_242; V a_3 = v_file_243; V a_4 = v_name_244; V a_5 = v_outPath_245; V a_6 = v_done_246; V a_7 = v_x_2421; V a_8 = v_z_249; V a_9 = v_z_2410; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLast_24s593692247x1447963058(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_name_244); heff_drop(v_x_2421); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sources_242 = heff_env(self)[0];
  V v_checked_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_badL_247 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  V v_bi_241 = heff_env(self)[6];
  V v_file_243 = heff_env(self)[7];
  V v_name_244 = heff_env(self)[8];
  V v_outPath_245 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2413 = (g_list_2emap_24s159228909x554161698(((V)&g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_str1), heff_dup(v_sources_242), v_x_2412, heff_dup(v_sources_242)));
  V v_x_2414 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2413));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam1, 1, 2, (V[]){heff_dup(v_sources_242), v_x_2414}), v_checked_248));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_x_2421), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileDiags_24s937475166x896963947_lam2, 1, 11, (V[]){v_badL_247, v_e_240, v_z_249, v_z_2410, v_x_2421, v_bi_241, v_sources_242, v_file_243, v_name_244, v_outPath_245, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(V v_e_240, V v_chk_241, V v_acc_242, V v_x3_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_chk_241);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    HEFF_LAST return g_heff_2ebuild_2ecommands_2echeckModule_24s1155151349x1707872620(heff_dup(v_e_240), heff_dup(v_chk_241), v_acc_242, heff_dup(v_f_246), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_lam0, 1, 5, (V[]){v_e_240, v_chk_241, heff_dup(v_rest_247), v_p_244, v_p_245}));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_e_240; V a_1 = v_chk_241; V a_2 = v_x_248; V a_3 = v_rest_247; V a_4 = v_p_244; V a_5 = v_p_245; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s473922857x1838044191(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_247); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str5, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str6, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530(V v_e_240, V v_st_241, V v_t_242, V v_acc_243, V v_x_244, V v_a_245, V v_missing_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_missing_246)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_z_247);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_244, v_a_245}), heff_take_field(v_acc_243, 0)});
    V v_t_2410 = ({ V rv_0 = v_t_249; V rr_ = heff_rec_reuse_nf(v_acc_243, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_248, 1, (V[]){v_t_2410});
  }
  case TAG_Cons: {
    heff_drop(v_a_245);
    V v_t_2413 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_241, v_t_242, v_x_244, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str0)));
    V v_x2_2414 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str1), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str2), v_missing_246));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str4); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str5)), v_t_2417);
    V v_str_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str6));
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2419, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_str7)), NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_z_247, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_lam0, 1, 2, (V[]){v_acc_243, v_z_248})));
  }
  default: return heff_nomatch(v_missing_246);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_lam0(V self, V *args) {
  V v_x_2427 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_intAdd(heff_take_field(v_acc_243, 1), MK_INT(1LL));
  V v_t_2429 = ({ V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_acc_243, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_248;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_str0, 24, "putting the programs in ");
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029(V v_e_240, V v_st_241, V v_t_242, V v_next_243, V v_progs_244) {
top: ;
  V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(heff_rfield(v_t_242, 1))));
  V v_c_246 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_245; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_245); r_; });
  V v_t_247 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2411 = heff_tr(heff_call(v_c_246, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam1, 2, 6, (V[]){v_c_2411, heff_dup(v_progs_244), v_t_242, v_e_240, v_st_241, v_next_243});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam3(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2425);
  V f_ = v_next_243;
  heff_room[0] = v_hd_2421;
  heff_room[1] = v_k_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_2421), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam6, 1, 3, (V[]){v_next_243, v_hd_2421, v_k_2422})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_next_243 = heff_env(self)[3];
  V v_progs_244 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2426 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = heff_dup(v_x_2420); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam5, 2, 3, (V[]){v_x_2420, v_e_240, v_next_243}); V a_5 = v_progs_244; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s2079335484x1275150962(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_244); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2414);
  V v_total_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_244));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_str0), heff_dup(heff_rfield(v_t_242, 1)));
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2416, v_total_2415, ((V)&g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam3_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2419, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam4, 1, 7, (V[]){v_e_240, v_st_241, v_t_242, v_next_243, v_progs_244, v_hd_2412, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_progs_244 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceIn_24s267746407x1645404029_lam2, 1, 7, (V[]){v_progs_244, v_t_242, v_e_240, v_hd_2412, v_st_241, v_next_243, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str3, 4, ".old");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str4, 12, "cannot copy ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str5, 4, " to ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam4, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam6, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam8, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam11, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam13, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239(V v_e_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_n_246, V v_hd_247, V v_k_248) {
top: ;
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_244, heff_dup(v_n_246), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2411, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam1, 1, 8, (V[]){v_st_241, v_home_243, v_n_246, v_e_240, v_hd_247, v_t_242, v_k_248, v_next_245})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam0(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_2435 = args[1];
  V v_k_2436 = args[2];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_2448 = args[1];
  V v_k_2449 = args[2];
  heff_drop(v_hd_2448);
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2457 = args[1];
  V v_k_2458 = args[2];
  heff_drop(v_hd_2457);
  V f_ = v_k_2458;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2456});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam10(V self, V *args) {
  V v_x_2475 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam9(V self, V *args) {
  V v_x_2460 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2460);
  V v_t_2461 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_get_n(v_t_242, 0, 6)));
  V v_t_2462 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_246));
  V v_t_2463 = (g_std_2epath_2ejoin(v_t_2461, v_t_2462));
  V v_t_2464 = ({ V a_0 = v_st_241; V a_1 = v_t_2463; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2463); r_; });
  V v_t_2465 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str4), v_t_2464), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str5));
  V v_why_2466 = heff_strAppend(v_t_2465, v_x_2417);
  V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str6), v_why_2466), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str7));
  V v_t_2468 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2467, NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam10, 1, 3, (V[]){v_e_240, v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam11(V self, V *args) {
  V v_x_2492 = args[0];
  V v_hd_2493 = args[1];
  V v_k_2494 = args[2];
  heff_drop(v_hd_2493);
  V f_ = v_k_2494;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2492});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam13(V self, V *args) {
  V v_x_24105 = args[0];
  V v_hd_24106 = args[1];
  V v_k_24107 = args[2];
  heff_drop(v_hd_24106);
  V f_ = v_k_24107;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24105});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam16(V self, V *args) {
  V v_x_24121 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_24117 = heff_env(self)[1];
  V v_k_24118 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24121);
  V f_ = v_next_245;
  heff_room[0] = v_hd_24117;
  heff_room[1] = v_k_24118;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam15(V self, V *args) {
  V v_hd_24117 = args[0];
  V v_k_24118 = args[1];
  V v_x_2412 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24119 = heff_tag_n(TAG_End, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_24120 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24120}), heff_dup(v_hd_24117), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam16, 1, 3, (V[]){v_next_245, v_hd_24117, v_k_24118})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam14(V self, V *args) {
  V v_x_24109 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_x_2422 = heff_env(self)[6];
  V v_x_2412 = heff_env(self)[7];
  V v_next_245 = heff_env(self)[8];
  V v_hd_247 = heff_env(self)[9];
  V v_k_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_24110 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_home_243));
  V v_t_24111 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_n_246));
  V v_t_24112 = (g_std_2epath_2ejoin(v_t_24110, v_t_24111));
  V v_t_24113 = ({ V a_0 = v_st_241; V a_1 = v_t_24112; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_24112); r_; });
  V v_t_24116;
  switch (heff_tag_of(v_x_24109)) {
  case TAG_Left: {
    heff_take_n(v_x_24109, 0ULL, 1);
    v_t_24116 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_24109, 0ULL, 1);
    v_t_24116 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_24109);
  }
  return ({ V a_0 = heff_dup(v_e_240); V a_1 = v_t_242; V a_2 = v_x_2417; V a_3 = v_x_2422; V a_4 = v_t_24113; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam15, 2, 3, (V[]){v_x_2412, v_e_240, v_next_245}); V a_6 = v_t_24116; V a_7 = v_hd_247; V a_8 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_24116); r_; });
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam12(V self, V *args) {
  V v_x_2496 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_home_243 = heff_env(self)[2];
  V v_n_246 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_x_2422 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_k_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2496);
  V v_path_2497 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
  V v_t_2498 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_home_243)));
  V v_t_2499 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_246)));
  V v_t_24100 = (g_std_2epath_2ejoin(v_t_2498, v_t_2499));
  V v_s_24101 = ({ V a_0 = v_st_241; V a_1 = v_t_24100; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24100); r_; });
  V v_to_24102 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_24101));
  V v_c_24103 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2497; V a_2 = v_to_24102; V r_ = (g_std_2efilesystem_2emove_24s1592691554x274375227(a_0, a_1, a_2)); heff_drop(v_path_2497); heff_drop(v_to_24102); r_; });
  V v_t_24104 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_24108 = heff_tr(heff_call(v_c_24103, 2, (V[]){v_t_24104, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam13_clo)}));
  V f_ = v_c_24108;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam14, 1, 11, (V[]){v_st_241, v_home_243, v_n_246, v_e_240, v_t_242, v_x_2417, v_x_2422, v_x_2412, v_next_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_n_246 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_home_243 = heff_env(self)[7];
  V v_x_2422 = heff_env(self)[8];
  V v_x_2412 = heff_env(self)[9];
  V v_next_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2451)) {
  case TAG_Left: {
    heff_take_n(v_x_2451, 0ULL, 1);
    heff_drop(v_home_243);
    heff_drop(v_x_2422);
    heff_drop(v_x_2412);
    heff_drop(v_next_245);
    V v_path_2453 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
    V v_c_2454 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2453; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2453); r_; });
    V v_t_2455 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2459 = heff_tr(heff_call(v_c_2454, 2, (V[]){v_t_2455, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam8_clo)}));
    V f_ = v_c_2459;
    heff_room[0] = heff_dup(v_hd_247);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam9, 1, 7, (V[]){v_st_241, v_t_242, v_n_246, v_x_2417, v_e_240, v_hd_247, v_k_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2451, 0ULL, 1);
    V v_t_2484 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_home_243)));
    V v_t_2485 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_246)));
    V v_t_2486 = (g_std_2epath_2ejoin(v_t_2484, v_t_2485));
    V v_s_2487 = ({ V a_0 = v_st_241; V a_1 = v_t_2486; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2486); r_; });
    V v_path_2488 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2487));
    V v_to_2489 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2422)));
    V v_c_2490 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2488; V a_2 = v_to_2489; V r_ = (g_std_2efilesystem_2emove_24s1592691554x274375227(a_0, a_1, a_2)); heff_drop(v_path_2488); heff_drop(v_to_2489); r_; });
    V v_t_2491 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2495 = heff_tr(heff_call(v_c_2490, 2, (V[]){v_t_2491, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam11_clo)}));
    V f_ = v_c_2495;
    heff_room[0] = heff_dup(v_hd_247);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam12, 1, 11, (V[]){v_x_2417, v_st_241, v_home_243, v_n_246, v_e_240, v_hd_247, v_t_242, v_x_2422, v_x_2412, v_next_245, v_k_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2451);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_home_243 = heff_env(self)[7];
  V v_x_2422 = heff_env(self)[8];
  V v_x_2412 = heff_env(self)[9];
  V v_next_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2438);
  V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 0))));
  V v_t_2440 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_246)));
  V v_t_2441 = (g_std_2epath_2ejoin(v_t_2439, v_t_2440));
  V v_s_2442 = ({ V a_0 = v_st_241; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2441); r_; });
  V v_path_2443 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2442));
  V v_to_2444 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
  V v_c_2445 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2443; V a_2 = v_to_2444; V r_ = (g_std_2efilesystem_2ecopy_24s224212859x272253807(a_0, a_1, a_2)); heff_drop(v_path_2443); heff_drop(v_to_2444); r_; });
  V v_t_2446 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2450 = heff_tr(heff_call(v_c_2445, 2, (V[]){v_t_2446, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam6_clo)}));
  V f_ = v_c_2450;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam7, 1, 11, (V[]){v_x_2417, v_e_240, v_hd_247, v_st_241, v_t_242, v_n_246, v_k_248, v_home_243, v_x_2422, v_x_2412, v_next_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_n_246 = heff_env(self)[5];
  V v_x_2417 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  V v_home_243 = heff_env(self)[8];
  V v_x_2412 = heff_env(self)[9];
  V v_next_245 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2430);
  V v_path_2431 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2422)));
  V v_c_2432 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2431; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2431); r_; });
  V v_t_2433 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2437 = heff_tr(heff_call(v_c_2432, 2, (V[]){v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam4_clo)}));
  V f_ = v_c_2437;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam5, 1, 11, (V[]){v_st_241, v_t_242, v_n_246, v_x_2417, v_e_240, v_hd_247, v_k_248, v_home_243, v_x_2422, v_x_2412, v_next_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_home_243 = heff_env(self)[1];
  V v_n_246 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_next_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_home_243)));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str0), heff_dup(v_n_246)), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str1));
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_t_2414));
  V v_t_2416 = (g_std_2epath_2ejoin(v_t_2413, v_t_2415));
  V v_x_2417 = ({ V a_0 = v_st_241; V a_1 = v_t_2416; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_home_243)));
  V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str2), heff_dup(v_n_246)), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_str3));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_t_2419));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2418, v_t_2420));
  V v_x_2422 = ({ V a_0 = v_st_241; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2417)));
  V v_c_2424 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2423; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2423); r_; });
  V v_t_2425 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam2_clo)}));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s403003247x556184239_lam3, 1, 11, (V[]){v_x_2422, v_e_240, v_hd_247, v_st_241, v_t_242, v_n_246, v_x_2417, v_k_248, v_home_243, v_x_2412, v_next_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_str1, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164(V v_e_240, V v_x1_241, V v_bad_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam0, 2, 1, (V[]){v_bad_242});
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x1_241, 0);
    V v_rest_246 = heff_field(v_x1_241, 1);
    V v_t_247 = ({ V a_0 = MK_INT(0LL); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(97LL); V b_4 = MK_INT(0LL); V b_5 = MK_INT(0LL); V a_6 = MK_INT(122LL); V a_7 = MK_INT(65LL); V b_8 = MK_INT(0LL); V b_9 = MK_INT(0LL); V a_10 = MK_INT(90LL); V a_11 = heff_dup(heff_rfield(v_c_245, 7)); V r_ = (g_list_2emap_24f1730403549x1479772376(a_0, b_1, b_2, a_3, b_4, b_5, a_6, a_7, b_8, b_9, a_10, a_11)); heff_drop(b_1); heff_drop(b_2); heff_drop(b_4); heff_drop(b_5); heff_drop(b_8); heff_drop(b_9); r_; });
    V v_c_248 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1983750801x303238129(heff_dup(v_e_240), heff_dup(v_c_245), v_t_247));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam1, 2, 5, (V[]){v_c_248, heff_dup(v_c_245), v_e_240, heff_dup(v_rest_246), v_bad_242});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_bad_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_bad_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_bad_242 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = ({ V a_0 = v_e_240; V a_1 = v_rest_246; V a_2 = heff_intAdd(v_bad_242, v_x_2413); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2414;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_bad_242 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2411);
  V v_t_2412 = (g_list_2emap_24s328934344x1728860012(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_str1), heff_take_field(v_c_245, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), heff_get_n(v_c_245, 0, 14), v_t_2412, MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam3, 1, 5, (V[]){v_e_240, v_rest_246, v_bad_242, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_bad_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s553018125x501180164_lam2, 1, 6, (V[]){v_c_245, v_e_240, v_hd_249, v_rest_246, v_bad_242, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648(V v_e_240, V v_bi_241, V v_dir_242, V v_rt_243, V v_c_244, V v_available_245, V v_r_246, V v_id_247, V v_texts_248, V v_backs_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_key_2412 = heff_take_field(v_r_246, 0);
  V v_effect_2413 = heff_get_n(v_r_246, 1, 2);
  V v_zig_2414 = heff_take_field(v_rt_243, 1);
  V v_c_2415 = heff_get_n(v_rt_243, 0, 2);
  V v_t_2416 = heff_get_n(heff_get_n(v_c_244, 5, 14), 0, 10);
  V v_t_2417 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2418 = (g_list_2emap_24s1173914895x100384474(v_t_2417));
  V v_t_2419 = (g_list_2efoldl_24s1707192740x1747748619(heff_dup(g_std_2eordmap_2eempty_get()), v_bs_2418));
  V v_t_2420 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2418; V r_ = (g_list_2efoldl_24s552376067x1255995125(a_0, a_1)); heff_drop(v_bs_2418); r_; });
  V v_t_2421 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2422 = (g_list_2emap_24s1173914895x100384474(v_t_2421));
  V v_t_2423 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2422; V r_ = (g_list_2efoldl_24s1272156913x1766532544(a_0, a_1)); heff_drop(v_bs_2422); r_; });
  V v_t_2424 = (g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(v_c_2415, v_available_245, v_t_2416, v_key_2412, v_effect_2413, heff_dup(heff_rfield(v_bi_241, 1)), heff_rec_n(2, shape_units__copies, (V[]){v_t_2419, v_t_2420}), v_t_2423));
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s1303345561x600913534(v_e_240, v_bi_241, v_dir_242, v_zig_2414, v_id_247, v_texts_248, v_backs_249, v_t_2424, v_z_2410, v_z_2411));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10], a[11]); heff_drop(a8); return r;
}