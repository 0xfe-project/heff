// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_NotRun 12703
#define TAG_ReadFile 6783
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_c 317
#define LBL_copies 592412158
#define LBL_diff 9578700
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_globals 352931696
#define LBL_got 312070
#define LBL_hashes 722717031
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_source 1050636102
#define LBL_text 10052084
#define LBL_top 324559
#define LBL_units 312791945
#define LBL_value 313331083
#define LBL_watch 314261737
#define LBL_zig 330130
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s1424406191x184069130(V, V, V, V, V, V, V);
V g_co_2eop_24s1424406191x184069130_entry(V self, V *a);
extern Clo g_co_2eop_24s1424406191x184069130_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eop_24s655614836x79419354(V, V, V, V, V, V, V, V);
V g_co_2eop_24s655614836x79419354_entry(V self, V *a);
extern Clo g_co_2eop_24s655614836x79419354_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_clo;
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2eintegrationText(V, V);
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182_clo;
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_clo;
V g_heff_2ecompile_2eemit_2ecompileProgramKept(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_list_2eany_24s2129318370x1621070635(V, V);
V g_list_2eany_24s2129318370x1621070635_entry(V self, V *a);
extern Clo g_list_2eany_24s2129318370x1621070635_clo;
V g_list_2efilter_24s770154907x42702486(V);
V g_list_2efilter_24s770154907x42702486_entry(V self, V *a);
extern Clo g_list_2efilter_24s770154907x42702486_clo;
V g_list_2efoldl_24s1022228162x792599878(V, V);
V g_list_2efoldl_24s1022228162x792599878_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1022228162x792599878_clo;
V g_list_2efoldl_24s1032373580x351779613(V, V);
V g_list_2efoldl_24s1032373580x351779613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1032373580x351779613_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s239465670x1559235816(V, V);
V g_list_2efoldl_24s239465670x1559235816_entry(V self, V *a);
extern Clo g_list_2efoldl_24s239465670x1559235816_clo;
V g_list_2efoldl_24s753718309x1738270184(V, V);
V g_list_2efoldl_24s753718309x1738270184_entry(V self, V *a);
extern Clo g_list_2efoldl_24s753718309x1738270184_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str0, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str1, 17, "        expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str2, 17, "        but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str3, 17, "        diff     ");
Clo g_heff_2ebuild_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = ({ V a_0 = v_color_240; V a_1 = v_expected_243; V a_2 = v_got_244; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_expected_243); heff_drop(v_got_244); r_; });
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str1), heff_take_field(v_m_245, 0));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str2), heff_take_field(v_m_245, 1));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str3), heff_get_n(v_m_245, 2, 3));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efailLines(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str2, 17, "integrationMain [");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str3, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str4, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str5, 13, "Integrations\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str6, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eintegrationText_str7, 2, "\012\012");
Clo g_heff_2ebuild_2ecommands_2eintegrationText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eintegrationText_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eintegrationText(V v_q_240, V v_ts_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s467798769x1763085075(v_ts_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str3)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str4), heff_strAppend(heff_dup(v_q_240), v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str5), heff_strAppend(heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get()), v_t_247));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str6), heff_strAppend(v_q_240, v_t_248));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eintegrationText_str7), heff_strAppend(heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get()), v_t_249));
}
V g_heff_2ebuild_2ecommands_2eintegrationText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eintegrationText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epassedOver_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epassedOver_str1, 0, "");
Clo g_heff_2ebuild_2ecommands_2epassedOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epassedOver_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epassedOver(V v_opts_240, V v_os_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 1)), ((V)&g_heff_2ebuild_2ecommands_2epassedOver_str0))) {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_os_241);
    return NTAG(TAG_False);
  } else {
    V v_x1_243 = (g_list_2efilter_24s770154907x42702486(heff_dup(v_os_241)));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      V v_p_244 = heff_get_n(v_opts_240, 1, 4);
      V v_t_2414;
      if (heff_strEq_c_lent(v_p_244, ((V)&g_heff_2ebuild_2ecommands_2epassedOver_str1), 2)) {
        heff_drop(v_p_244);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_244; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_244); r_; });
        V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
        HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_why_2412 = v_field_2410;
            heff_drop(v_why_2412);
            v_t_2414 = NTAG(TAG_Nil);
          } else {
            V v_sel_2413 = v_field_2410;
            v_t_2414 = v_sel_2413;
          }
        }
      }
      V v_x1_2415 = ({ V a_0 = v_t_2414; V a_1 = v_os_241; V r_ = (g_list_2eany_24s2129318370x1621070635(a_0, a_1)); heff_drop(v_t_2414); heff_drop(v_os_241); r_; });
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
      heff_drop(v_x1_2415);
      return v_ret_24bool;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_243, 0ULL, 2);
      heff_drop_rec(v_opts_240, 4);
      heff_drop(v_os_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
}
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epassedOver(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_str0), v_l_245));
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s655614836x79419354(v_m_240, v_rest_246, v_n_242, MK_INT(1LL), heff_dup(v_p_243), v_p_244, heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_p_243));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_246 = v_field_244;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam0, 2, 2, (V[]){v_path_246, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2423})});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_248;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_path_246 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
  V v_t_2410 = heff_strSlice(heff_dup(v_path_246), heff_box_word(v_t_249), heff_strLength_lent(v_path_246, 0));
  V v_t_2413;
  if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_str0))) {
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
    v_t_2413 = heff_strSlice(v_path_246, MK_INT(0LL), heff_box_word(v_t_2412));
  } else {
    v_t_2413 = v_path_246;
  }
  V v_t_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_str1)), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam1_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s495635622x733177935(v_t_2421, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam2, 1, 2, (V[]){v_m_241, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s544713773x36400484_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_outPath_240, heff_dup(heff_rfield(v_o_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam1, 1, 4, (V[]){v_o_242, v_hd_243, heff_dup(v_bad_241), v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_o_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2413);
    if ((heff_dup(v_bad_241) == NTAG(TAG_True))) {
      heff_drop(v_bad_241);
      heff_drop_rec(v_o_242, 2);
      V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_hd_243, v_k_244));
    } else {
      heff_drop(v_bad_241);
      V v_t_2422 = heff_get_n(v_o_242, 1, 2);
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nil: {
        heff_drop(v_hd_243);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2422_24Cons = heff_take_reuse_n(v_t_2422, 0ULL, 2);
        V v_t_2425 = heff_tag_at_n(v_ru_24t_2422_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_243, v_k_244));
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
  } else {
    heff_drop(v_x_2413);
    heff_drop(v_bad_241);
    heff_drop_rec(v_o_242, 2);
    V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_243, v_k_244));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s4454247x637712429_lam2, 1, 5, (V[]){v_x_2413, v_bad_241, v_hd_243, v_k_244, v_o_242})));
}
Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_id_247, V v_texts_248, V v_backs_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = heff_get_n(heff_get_n(v_c_244, 5, 14), 0, 9);
  V v_t_2413 = (g_std_2emap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2414 = (g_list_2emap_24s1173914895x100384474(v_t_2413));
  V v_t_2415 = (g_list_2efoldl_24s1022228162x792599878(heff_dup(g_std_2emap_2eempty_get()), v_bs_2414));
  V v_t_2416 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2414; V r_ = (g_list_2efoldl_24s1032373580x351779613(a_0, a_1)); heff_drop(v_bs_2414); r_; });
  V v_t_2417 = (g_std_2emap_2etoListOnto(v_backs_249, NTAG(TAG_Nil)));
  V v_bs_2418 = (g_list_2emap_24s1173914895x100384474(v_t_2417));
  V v_t_2419 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2418; V r_ = (g_list_2efoldl_24s239465670x1559235816(a_0, a_1)); heff_drop(v_bs_2418); r_; });
  V v_t_2420 = ({ V a_0 = heff_take_field(v_rt_242, 0); V a_1 = v_available_245; V a_2 = v_t_2412; V a_3 = heff_take_field(v_r_246, 0); V a_4 = heff_get_n(v_r_246, 1, 2); V a_5 = heff_dup(heff_rfield(v_bi_240, 1)); V a_6 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2415, v_t_2416}); V a_7 = v_t_2419; V r_ = (g_heff_2ecompile_2eemitc_2ecompileProgramPartsKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2419); r_; });
  return (g_heff_2ebuild_2ecommands_2ekeptWritten_24s64789904x1456571182(v_bi_240, v_dir_241, heff_get_n(v_rt_242, 1, 2), v_id_247, v_texts_248, v_backs_249, v_done_243, v_t_2420, v_z_2410, v_z_2411));
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10], a[11]); heff_drop(a8); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str0, 2, ".o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str1, 11, "-femit-bin=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str2, 2, "-O");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str3, 9, "build-obj");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(V v_prog_240, V v_z_241, V v_mode_242, V v_x3_243, V v_made_244) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_made_244));
    V v_x_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_f_249 = heff_field(v_x3_243, 0);
    V v_rest_2410 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam1, 2, 6, (V[]){v_f_249, v_mode_242, v_prog_240, v_z_241, v_rest_2410, v_made_244});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam2(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_mode_242 = heff_env(self)[2];
  V v_rest_2410 = heff_env(self)[3];
  V v_o_2414 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = heff_take_field(v_x_2420, 0);
  V v_t_2424;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Exited: {
    V v_n_2422 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    v_t_2424 = heff_intEq(v_n_2422, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2421, 0ULL, 1);
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2424 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2420, 3);
    heff_drop(v_t_2424);
    V v_t_2425 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903(v_prog_240, v_z_241, v_mode_242, v_rest_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_o_2414, v_made_244})));
    V f_ = v_t_2425;
    heff_room[0] = v_hd_2411;
    heff_room[1] = v_k_2412;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_prog_240);
    heff_drop(v_z_241);
    heff_drop(v_mode_242);
    heff_drop(v_rest_2410);
    heff_drop(v_o_2414);
    heff_drop(v_made_244);
    heff_drop(v_t_2424);
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2420, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_2411, heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam4, 1, 1, (V[]){v_k_2412})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_f_249 = heff_env(self)[0];
  V v_mode_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_z_241 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_made_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_f_249, 0)) - ((int64_t)4ULL));
  V v_o_2414 = heff_strAppend(heff_strSlice_lent(v_f_249, MK_INT(0LL), heff_box_word(v_t_2413), 6), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str0));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str1), heff_dup(v_o_2414)), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str2), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_mode_242), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_f_249, v_t_2416})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_z_241), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_str4), v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam2_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2419, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s564322737x2068730903_lam3, 1, 8, (V[]){v_prog_240, v_z_241, v_mode_242, v_rest_2410, v_o_2414, v_made_244, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 4, 10);
    V v_t_2411 = ({ V a_0 = v_color_241; V a_1 = v_t_249; V a_2 = v_t_2410; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop(v_t_2410); r_; });
    V v_str_2412 = (g_heff_2ebuild_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam1, 2, 4, (V[]){v_str_2412, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V a_3 = heff_dup(v_hd_2413); V a_4 = v_k_2414; V a_5 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}); V a_6 = v_hd_2413; V r_ = (g_co_2eop_24s1424406191x184069130(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_color_241); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam3, 2, 0};
Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882(V v_sources_240, V v_m_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(v_sources_240, v_m_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_path_246 = v_field_244;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam0, 2, 2, (V[]){v_path_246, v_m_241});
    } else {
      heff_drop(v_m_241);
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam3_clo);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_m_241 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    heff_drop(v_m_241);
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_t_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_241, v_t_2423})});
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V f_ = v_k_248;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_path_246 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
  V v_t_2410 = heff_strSlice(heff_dup(v_path_246), heff_box_word(v_t_249), heff_strLength_lent(v_path_246, 0));
  V v_t_2413;
  if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_str0))) {
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_246, 0)) - ((int64_t)3ULL));
    v_t_2413 = heff_strSlice(v_path_246, MK_INT(0LL), heff_box_word(v_t_2412));
  } else {
    v_t_2413 = v_path_246;
  }
  V v_t_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_str1)), ((V)&g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam1_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s495635622x733177935(v_t_2421, v_hd_247, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam2, 1, 2, (V[]){v_m_241, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s702464651x1796124882_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501(V v_bi_240, V v_outPath_241, V v_done_242, V v_c_243, V v_available_244, V v_r_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam0, 1, 8, (V[]){v_bi_240, v_hd_246, v_c_243, v_available_244, v_r_245, v_outPath_241, v_done_242, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_available_244 = heff_env(self)[2];
  V v_r_245 = heff_env(self)[3];
  V v_bi_240 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_248, v_x_2414));
  V v_t_2416 = heff_get_n(heff_get_n(v_c_243, 5, 14), 0, 9);
  V v_m_2417 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_248, v_x_2414));
  V v_t_2418 = ({ V a_0 = v_m_2417; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2417); r_; });
  V v_bs_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
  V v_t_2420 = (g_list_2efoldl_24s1022228162x792599878(heff_dup(g_std_2emap_2eempty_get()), v_bs_2419));
  V v_t_2421 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2419; V r_ = (g_list_2efoldl_24s1032373580x351779613(a_0, a_1)); heff_drop(v_bs_2419); r_; });
  V v_m_2422 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_248, v_x_2414));
  V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
  V v_bs_2424 = (g_list_2emap_24s1173914895x100384474(v_t_2423));
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2424; V r_ = (g_list_2efoldl_24s753718309x1738270184(a_0, a_1)); heff_drop(v_bs_2424); r_; });
  V v_t_2426 = ({ V a_0 = v_available_244; V a_1 = v_t_2416; V a_2 = heff_take_field(v_r_245, 0); V a_3 = heff_get_n(v_r_245, 1, 2); V a_4 = heff_dup(heff_rfield(v_bi_240, 1)); V a_5 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2420, v_t_2421}); V a_6 = v_t_2425; V r_ = (g_heff_2ecompile_2eemit_2ecompileProgramKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2425); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_outPath_241; V a_2 = v_x_248; V a_3 = v_x_2414; V a_4 = v_t_2415; V a_5 = v_done_242; V a_6 = v_t_2426; V a_7 = v_hd_246; V a_8 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1409360186x1903727387(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_available_244 = heff_env(self)[3];
  V v_r_245 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2413;
  if (heff_strEq_c_lent(v_x_248, ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_str0), 2)) {
    v_c_2413 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam1_clo);
  } else {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2413 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2412));
  }
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1333473353x610429501_lam2, 1, 9, (V[]){v_x_248, v_c_243, v_available_244, v_r_245, v_bi_240, v_outPath_241, v_done_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(V v_rep_240, V v_prog_241, V v_chk_242, V v_acc_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_chk_242);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam0, 2, 1, (V[]){v_acc_243});
  }
  case TAG_Cons: {
    V v_f_247 = heff_field(v_x3_244, 0);
    V v_rest_248 = heff_field(v_x3_244, 1);
    V v_c_249 = (g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173(heff_dup(v_rep_240), heff_dup(v_prog_241), heff_dup(v_chk_242), v_acc_243, heff_dup(v_f_247)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam1, 2, 5, (V[]){v_c_249, v_rep_240, v_prog_241, v_chk_242, heff_dup(v_rest_248)});
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_chk_242 = heff_env(self)[2];
  V v_rest_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_chk_242; V a_3 = v_x_2412; V a_4 = v_rest_248; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_248); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_2410;
  heff_room[1] = v_k_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_chk_242 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s38283736x1844612414_lam2, 1, 6, (V[]){v_rep_240, v_prog_241, v_chk_242, v_rest_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}