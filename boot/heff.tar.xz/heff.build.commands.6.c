// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_backend 2032133329
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_hashes 722717031
#define LBL_heff 9694020
#define LBL_line 9817275
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_own 320000
#define LBL_packages 1496006433
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_src 323678
#define LBL_start 311115900
#define LBL_style 311138763
static uint32_t shape_paths__hashes__modules[] = {LBL_paths, LBL_hashes, LBL_modules};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1734868233x1940051977(V, V, V);
V g_co_2eop_24s1734868233x1940051977_entry(V self, V *a);
extern Clo g_co_2eop_24s1734868233x1940051977_clo;
V g_co_2eop_24s1772383553x418719539(V, V, V);
V g_co_2eop_24s1772383553x418719539_entry(V self, V *a);
extern Clo g_co_2eop_24s1772383553x418719539_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s321980040x1154251472(V, V, V, V, V);
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a);
extern Clo g_co_2eop_24s321980040x1154251472_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s59066675x636147158(V, V, V);
V g_co_2eop_24s59066675x636147158_entry(V self, V *a);
extern Clo g_co_2eop_24s59066675x636147158_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo;
V g_heff_2ebuild_2ecommands_2efirstErrorOf(V);
V g_heff_2ebuild_2ecommands_2efirstErrorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efirstErrorOf_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo;
V g_heff_2ebuild_2edriver_2erefusedIn(V, V);
V g_heff_2ebuild_2edriver_2erefusedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erefusedIn_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2elsp_2erender_2elineStartFrom(V, V, V);
V g_heff_2elsp_2erender_2elineStartFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineStartFrom_clo;
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2eoneLineIn(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2erender_2eoneLineIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eoneLineIn_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2erender_2espanLines(V, V, V, V, V, V);
V g_heff_2elsp_2erender_2espanLines_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2espanLines_clo;
V g_heff_2eutil_2ehostpath_2enormalize(V, V);
V g_heff_2eutil_2ehostpath_2enormalize_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2enormalize_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1524014098x1956473147(V, V, V, V);
V g_list_2emap_24f1524014098x1956473147_entry(V self, V *a);
extern Clo g_list_2emap_24f1524014098x1956473147_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str3, 12, "the package ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str4, 13, " is for heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str5, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str6, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str8, 19, ", and this heff is ");
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(a[0]);
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam4(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_x_2415 = args[1];
  V v_running_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_heff_2416 = heff_take_field(v_x_2415, 5);
  V v_own_2417 = heff_take_field(v_x_2415, 3);
  V v_path_2418 = heff_get_n(v_x_2415, 0, 7);
  V v_wanted_2419 = v_heff_2416;
  V v_t_2456;
  switch (heff_tag_of(v_running_248)) {
  case TAG_Nothing: {
    heff_drop(v_own_2417);
    heff_drop(v_path_2418);
    heff_drop(v_wanted_2419);
    v_t_2456 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2420 = heff_field(v_running_248, 0);
    V v_ru_24running_248_24Just = heff_take_reuse_n(v_running_248, 1ULL, 1);
    V v_who_2421;
    if (heff_strEq_c(v_own_2417, ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str1))) {
      heff_drop(v_path_2418);
      v_who_2421 = ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str2);
    } else {
      v_who_2421 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str3), v_path_2418);
    }
    V v_wanted_2422 = heff_dup(v_wanted_2419);
    V v_running_2423 = heff_dup(v_running_2420);
    HeffT2 v_t_2424 = ({ V a_0 = v_wanted_2419; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_wanted_2419); r_; });
    V v_t_2454;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      HeffT2 v_t_2427 = ({ V a_0 = v_running_2420; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_running_2420); r_; });
      {
        V v_field_2429 = v_t_2427.f[1];
        int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_w_2430 = v_field_2426;
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_r_2431 = v_field_2429;
            V v_x1_2432 = v_w_2430;
            V v_x2_2433 = v_r_2431;
            V v_t_2450;
            switch (heff_tag_of(v_x1_2432)) {
            case TAG_Nil: {
              heff_drop(v_x2_2433);
              v_t_2450 = NTAG(TAG_False);
              break;
            }
            case TAG_Cons: {
              V v_wa_2434 = heff_field(v_x1_2432, 0);
              V v_x12_2435 = heff_field(v_x1_2432, 1);
              heff_take_n(v_x1_2432, 3ULL, 2);
              switch (heff_tag_of(v_x12_2435)) {
              case TAG_Nil: {
                heff_drop(v_x2_2433);
                heff_drop(v_wa_2434);
                v_t_2450 = NTAG(TAG_False);
                break;
              }
              case TAG_Cons: {
                V v_wb_2436 = heff_field(v_x12_2435, 0);
                V v_x122_2437 = heff_field(v_x12_2435, 1);
                heff_take_n(v_x12_2435, 3ULL, 2);
                switch (heff_tag_of(v_x122_2437)) {
                case TAG_Nil: {
                  heff_drop(v_x2_2433);
                  heff_drop(v_wa_2434);
                  heff_drop(v_wb_2436);
                  v_t_2450 = NTAG(TAG_False);
                  break;
                }
                case TAG_Cons: {
                  V v_wc_2438 = heff_field(v_x122_2437, 0);
                  V v_x1222_2439 = heff_field(v_x122_2437, 1);
                  heff_take_n(v_x122_2437, 3ULL, 2);
                  switch (heff_tag_of(v_x1222_2439)) {
                  case TAG_Nil: {
                    switch (heff_tag_of(v_x2_2433)) {
                    case TAG_Nil: {
                      heff_drop(v_wa_2434);
                      heff_drop(v_wb_2436);
                      heff_drop(v_wc_2438);
                      v_t_2450 = NTAG(TAG_False);
                      break;
                    }
                    case TAG_Cons: {
                      V v_ra_2440 = heff_field(v_x2_2433, 0);
                      V v_x22_2441 = heff_field(v_x2_2433, 1);
                      heff_take_n(v_x2_2433, 3ULL, 2);
                      switch (heff_tag_of(v_x22_2441)) {
                      case TAG_Nil: {
                        heff_drop(v_wa_2434);
                        heff_drop(v_wb_2436);
                        heff_drop(v_wc_2438);
                        heff_drop(v_ra_2440);
                        v_t_2450 = NTAG(TAG_False);
                        break;
                      }
                      case TAG_Cons: {
                        V v_rb_2442 = heff_field(v_x22_2441, 0);
                        V v_x222_2443 = heff_field(v_x22_2441, 1);
                        heff_take_n(v_x22_2441, 3ULL, 2);
                        switch (heff_tag_of(v_x222_2443)) {
                        case TAG_Nil: {
                          heff_drop(v_wa_2434);
                          heff_drop(v_wb_2436);
                          heff_drop(v_wc_2438);
                          heff_drop(v_ra_2440);
                          heff_drop(v_rb_2442);
                          v_t_2450 = NTAG(TAG_False);
                          break;
                        }
                        case TAG_Cons: {
                          V v_rc_2444 = heff_field(v_x222_2443, 0);
                          V v_x2222_2445 = heff_field(v_x222_2443, 1);
                          heff_take_n(v_x222_2443, 3ULL, 2);
                          switch (heff_tag_of(v_x2222_2445)) {
                          case TAG_Nil: {
                            v_t_2450 = heff_bool((heff_intEq_c_lent(v_wa_2434, MK_INT(0LL), 2) ? (heff_intEq_c_lent(v_ra_2440, MK_INT(0LL), 2) && (heff_intEq_c_lent(v_rb_2442, v_wb_2436, 0) && heff_intLe_c_lent(v_wc_2438, v_rc_2444, 0))) : (heff_intEq_c_lent(v_ra_2440, v_wa_2434, 0) && (heff_intLt_c_lent(v_wb_2436, v_rb_2442, 0) || (heff_intEq_c_lent(v_rb_2442, v_wb_2436, 0) && heff_intLe_c_lent(v_wc_2438, v_rc_2444, 0))))));
                            heff_drop(v_wa_2434);
                            heff_drop(v_wb_2436);
                            heff_drop(v_wc_2438);
                            heff_drop(v_ra_2440);
                            heff_drop(v_rb_2442);
                            heff_drop(v_rc_2444);
                            break;
                          }
                          case TAG_Cons: {
                            heff_take_n(v_x2222_2445, 0ULL, 2);
                            heff_drop(v_wa_2434);
                            heff_drop(v_wb_2436);
                            heff_drop(v_wc_2438);
                            heff_drop(v_ra_2440);
                            heff_drop(v_rb_2442);
                            heff_drop(v_rc_2444);
                            v_t_2450 = NTAG(TAG_False);
                            break;
                          }
                          default: heff_nomatch(v_x2222_2445);
                          }
                          break;
                        }
                        default: heff_nomatch(v_x222_2443);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x22_2441);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x2_2433);
                    }
                    break;
                  }
                  case TAG_Cons: {
                    heff_take_n(v_x1222_2439, 0ULL, 2);
                    heff_drop(v_x2_2433);
                    heff_drop(v_wa_2434);
                    heff_drop(v_wb_2436);
                    heff_drop(v_wc_2438);
                    v_t_2450 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_x1222_2439);
                  }
                  break;
                }
                default: heff_nomatch(v_x122_2437);
                }
                break;
              }
              default: heff_nomatch(v_x12_2435);
              }
              break;
            }
            default: heff_nomatch(v_x1_2432);
            }
            if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
              heff_drop_cell(v_ru_24running_248_24Just, 1);
              heff_drop(v_who_2421);
              heff_drop(v_wanted_2422);
              heff_drop(v_running_2423);
              heff_drop(v_t_2450);
              v_t_2454 = NTAG(TAG_Nothing);
            } else {
              heff_drop(v_t_2450);
              V v_t_2451 = heff_strAppend(heff_strAppend(v_who_2421, ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str4)), heff_dup(v_wanted_2422));
              V v_t_2452;
              if (heff_strEq_c(heff_strSlice(v_wanted_2422, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str5))) {
                v_t_2452 = ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str6);
              } else {
                v_t_2452 = ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str7);
              }
              V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2451, v_t_2452), ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str8));
              v_t_2454 = heff_tag_at_n(v_ru_24running_248_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_t_2453, v_running_2423)});
            }
          } else {
            heff_drop_cell(v_ru_24running_248_24Just, 1);
            heff_drop(v_who_2421);
            heff_drop(v_wanted_2422);
            heff_drop(v_running_2423);
            heff_drop(v_field_2429);
            heff_drop(v_w_2430);
            v_t_2454 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24running_248_24Just, 1);
          heff_drop(v_who_2421);
          heff_drop(v_wanted_2422);
          heff_drop(v_running_2423);
          heff_drop(v_field_2426);
          heff_drop(v_field_2429);
          v_t_2454 = NTAG(TAG_Nothing);
        }
      }
    }
    switch (heff_tag_of(v_t_2454)) {
    case TAG_Nothing: {
      v_t_2456 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_why_2455 = heff_field(v_t_2454, 0);
      heff_take_n(v_t_2454, 1ULL, 1);
      v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2455, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_t_2454);
    }
    break;
  }
  default: heff_nomatch(v_running_248);
  }
  return (g_prelude_2e_2b_2b(v_t_2456, v_acc_2414));
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_running_248 = v_x_247;
  V v_x2_249 = heff_dup(heff_rfield(v_x_246, 4));
  V v_t_2457;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_running_248);
    v_t_2457 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_project_2410 = heff_field(v_x2_249, 0);
    V v_deps_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_2410, 5)), ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_str0))) {
      heff_drop_rec(v_project_2410, 7);
      heff_drop_cell(v_ru_24x2_249_24Cons, 2);
      v_t_2412 = v_deps_2411;
    } else {
      v_t_2412 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_project_2410, v_deps_2411});
    }
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2412));
    v_t_2457 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam4, 2, 1, (V[]){v_running_248}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  V v_x_2458 = (g_list_2efoldl_24s571074576x1179600767(v_x_246, v_t_2457));
  V f_ = v_k_243;
  args[0] = v_x_2458;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam6(V self, V *args) {
  V v_r_2463 = args[0];
  return v_r_2463;
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam8(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_x_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2475);
  V f_ = v_k_2476;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2474});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam7(V self, V *args) {
  V v_x_2471 = args[0];
  switch (heff_tag_of(v_x_2471)) {
  case TAG_Left: {
    V v_err_2472 = heff_field(v_x_2471, 0);
    V v_ru_24x_2471_24Left = heff_take_reuse_n(v_x_2471, 1ULL, 1);
    V v_t_2473 = heff_tag_at_n(v_ru_24x_2471_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2472})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2473));
  }
  case TAG_Right: {
    V v_x_2474 = heff_field(v_x_2471, 0);
    heff_take_n(v_x_2471, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam8, 2, 1, (V[]){v_x_2474});
  }
  default: return heff_nomatch(v_x_2471);
  }
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam9(V self, V *args) {
  V v_x_2478 = args[0];
  V v_k_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2478)) {
  case TAG_Left: {
    heff_take_n(v_x_2478, 0ULL, 1);
    V f_ = v_k_2459;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2480 = heff_field(v_x_2478, 0);
    V v_ru_24x_2478_24Right = heff_take_reuse_n(v_x_2478, 1ULL, 1);
    HeffT2 v_t_2481 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2480));
    {
      V v_field_2483 = v_t_2481.f[1];
      int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
      V v_x_2491;
      if ((v_tag_2482 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2478_24Right, 1);
        V v_p_2484 = v_field_2483;
        heff_drop(v_p_2484);
        v_x_2491 = NTAG(TAG_Nothing);
      } else {
        V v_x_2485 = v_field_2483;
        HeffT2 v_t_2486 = ({ V a_0 = v_x_2485; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2485); r_; });
        {
          V v_field_2488 = v_t_2486.f[1];
          int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
          if ((v_tag_2487 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2478_24Right, 1);
            V v_x_2489 = v_field_2488;
            heff_drop(v_x_2489);
            v_x_2491 = NTAG(TAG_Nothing);
          } else {
            V v_p_2490 = v_field_2488;
            v_x_2491 = heff_tag_at_n(v_ru_24x_2478_24Right, TAG_Just, 1, (V[]){heff_get_n(v_p_2490, 1, 4)});
          }
        }
      }
      V f_ = v_k_2459;
      args[0] = v_x_2491;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2478);
  }
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam5(V self, V *args) {
  V v_x_2460 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_2461 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2460));
  V v_t_2462 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2461; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2461); r_; });
  V v_a_2464 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2462, ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam6_clo)});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
  V v_c_2477 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2470}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam7_clo)));
  V f_ = v_c_2477;
  heff_room[0] = v_hd_242;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam9, 1, 1, (V[]){v_k_2459});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_k_2459 = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam3, 1, 2, (V[]){v_x_246, v_k_243});
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam5, 1, 2, (V[]){v_hd_242, v_k_2459})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1472769985x1077606860(v_x_244, v_file_240));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam2, 1, 2, (V[]){v_k_243, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str0, 4, "1;31");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str1, 4, "1;33");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str2, 4, "1;36");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str3, 2, "\033[");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str4, 1, "m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str5, 4, "\033[0m");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str7, 4, "1;31");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str8, 4, "1;33");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str9, 4, "1;36");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str17, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str19, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_diags_245 = heff_dup(heff_rfield(v_c_243, 6));
    V v_path_246 = heff_dup(heff_rfield(v_c_243, 1));
    V v_source_247 = heff_dup(heff_rfield(v_c_243, 3));
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){v_t_2414}));
    return heff_tail(heff_dup(heff_rfield(v_p_241, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam1, 1, 6, (V[]){v_diags_245, v_path_246, v_source_247, v_p_241, heff_dup(v_rest_244), v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam0(V self, V *args) {
  V v_b_248 = args[0];
  return v_b_248;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam3(V self, V *args) {
  V v_d_2425 = args[0];
  V v_path_2422 = heff_env(self)[0];
  V v_src_2423 = heff_env(self)[1];
  V v_color_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = (g_heff_2elsp_2erender_2ediagWhere(v_path_2422, v_src_2423, heff_dup(v_d_2425)));
  V v_color_2427 = v_color_2421;
  V v_src_2428 = v_src_2423;
  V v_d_2429 = v_d_2425;
  V v_s_2430 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_2429)));
  V v_t_2434;
  if ((heff_dup(v_color_2427) == NTAG(TAG_True))) {
    V v_t_2431 = heff_dup(heff_rfield(v_d_2429, 1));
    V v_t_2432;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_SError: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str0);
      break;
    }
    case TAG_SWarning: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str1);
      break;
    }
    case TAG_SDebug: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str2);
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str3), v_t_2432), ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str4));
    v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, v_s_2430), ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str5));
  } else {
    v_t_2434 = v_s_2430;
  }
  V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str6)), heff_take_field(v_d_2429, 2));
  V v_color_2436 = v_color_2427;
  V v_t_2437 = heff_take_field(v_d_2429, 1);
  V v_code_2438;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_SError: {
    v_code_2438 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str7);
    break;
  }
  case TAG_SWarning: {
    v_code_2438 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str8);
    break;
  }
  case TAG_SDebug: {
    v_code_2438 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str9);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_src_2439 = v_src_2428;
  V v_sp_2440 = heff_take_field(v_d_2429, 3);
  V v_color_2441 = v_color_2436;
  V v_code_2442 = v_code_2438;
  V v_src_2443 = heff_dup(v_src_2439);
  V v_sp_2444 = heff_dup(v_sp_2440);
  V v_j_2445 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str10), v_src_2439, MK_INT(0LL), 5);
  V v_t_2446;
  if (heff_intLt_c_lent(v_j_2445, MK_INT(0LL), 2)) {
    heff_drop(v_j_2445);
    v_t_2446 = NTAG(TAG_Nothing);
  } else {
    v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2445});
  }
  V v_s_2447 = (g_heff_2elsp_2erender_2elineColAt(v_src_2439, heff_dup(heff_rfield(v_sp_2440, 0)), MK_INT(0LL), MK_INT(0LL), v_t_2446));
  V v_x_2448 = heff_take_field(v_sp_2440, 0);
  V v_y_2449 = heff_intSub(heff_get_n(v_sp_2440, 1, 2), MK_INT(1LL));
  V v_t_2450;
  if (heff_intLe_c_lent(v_x_2448, v_y_2449, 0)) {
    heff_drop(v_x_2448);
    v_t_2450 = v_y_2449;
  } else {
    heff_drop(v_y_2449);
    v_t_2450 = v_x_2448;
  }
  V v_j_2451 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str11), v_src_2439, MK_INT(0LL), 5);
  V v_t_2452;
  if (heff_intLt_c_lent(v_j_2451, MK_INT(0LL), 2)) {
    heff_drop(v_j_2451);
    v_t_2452 = NTAG(TAG_Nothing);
  } else {
    v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2451});
  }
  V v_e_2453 = ({ V a_0 = v_src_2439; V a_1 = v_t_2450; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2452; V r_ = (g_heff_2elsp_2erender_2elineColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2439); r_; });
  V v_t_2474;
  if (heff_intEq_c(heff_dup(heff_rfield(v_s_2447, 0)), heff_dup(heff_rfield(v_e_2453, 0)))) {
    heff_drop_rec(v_e_2453, 3);
    V v_color_2454 = v_color_2441;
    V v_code_2455 = v_code_2442;
    V v_src_2456 = v_src_2443;
    V v_sp_2457 = v_sp_2444;
    V v_start_2458 = heff_take_field(v_sp_2457, 0);
    V v_end_2459 = heff_get_n(v_sp_2457, 1, 2);
    V v_t_2460 = heff_intAdd(heff_dup(heff_rfield(v_s_2447, 0)), MK_INT(1LL));
    V v_w_2461 = (g_heff_2elsp_2erender_2enumDigits(v_t_2460));
    V v_l_2462 = heff_get_n(v_s_2447, 0, 3);
    V v_t_2463;
    if (heff_intEq_c_lent(v_l_2462, MK_INT(0LL), 2)) {
      v_t_2463 = MK_INT(0LL);
    } else {
      v_t_2463 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2456, heff_dup(v_l_2462), MK_INT(0LL)));
    }
    V v_x_2464;
    if (heff_intEq_c_lent(v_l_2462, MK_INT(0LL), 2)) {
      v_x_2464 = MK_INT(0LL);
    } else {
      v_x_2464 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2456, heff_dup(v_l_2462), MK_INT(0LL)));
    }
    V v_y_2465 = v_start_2458;
    V v_t_2466;
    if (heff_intLe_c_lent(v_x_2464, v_y_2465, 0)) {
      heff_drop(v_x_2464);
      v_t_2466 = v_y_2465;
    } else {
      heff_drop(v_y_2465);
      v_t_2466 = v_x_2464;
    }
    V v_start_2467;
    if (heff_intEq_c_lent(v_l_2462, MK_INT(0LL), 2)) {
      v_start_2467 = MK_INT(0LL);
    } else {
      v_start_2467 = (g_heff_2elsp_2erender_2elineStartFrom(v_src_2456, heff_dup(v_l_2462), MK_INT(0LL)));
    }
    V v_j_2468 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str12), v_src_2456, v_start_2467, 5);
    V v_x_2469;
    if (heff_intLt_c_lent(v_j_2468, MK_INT(0LL), 2)) {
      heff_drop(v_j_2468);
      v_x_2469 = heff_strLength_lent(v_src_2456, 0);
    } else {
      v_x_2469 = v_j_2468;
    }
    V v_y_2470 = v_end_2459;
    V v_t_2471;
    if (heff_intLe_c_lent(v_x_2469, v_y_2470, 0)) {
      heff_drop(v_y_2470);
      v_t_2471 = v_x_2469;
    } else {
      heff_drop(v_x_2469);
      v_t_2471 = v_y_2470;
    }
    v_t_2474 = ({ V a_0 = v_color_2454; V a_1 = v_code_2455; V a_2 = v_src_2456; V a_3 = v_w_2461; V a_4 = v_l_2462; V a_5 = v_t_2463; V a_6 = v_t_2466; V a_7 = v_t_2471; V r_ = (g_heff_2elsp_2erender_2eoneLineIn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_color_2454); heff_drop(v_src_2456); r_; });
  } else {
    heff_drop(v_sp_2444);
    V v_t_2472 = heff_intAdd(heff_dup(heff_rfield(v_e_2453, 0)), MK_INT(1LL));
    V v_t_2473 = (g_heff_2elsp_2erender_2enumDigits(v_t_2472));
    v_t_2474 = (g_heff_2elsp_2erender_2espanLines(v_color_2441, v_code_2442, v_src_2443, v_t_2473, v_s_2447, v_e_2453));
  }
  V v_t_2475 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str13)), v_t_2474);
  V v_t_2476 = heff_get_n(v_d_2429, 4, 5);
  V v_t_2478;
  switch (heff_tag_of(v_t_2476)) {
  case TAG_Nothing: {
    v_t_2478 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str14);
    break;
  }
  case TAG_Just: {
    V v_n_2477 = heff_field(v_t_2476, 0);
    heff_take_n(v_t_2476, 1ULL, 1);
    v_t_2478 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str15), v_n_2477);
    break;
  }
  default: heff_nomatch(v_t_2476);
  }
  V v_t_2479 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str16)), heff_strAppend(v_t_2475, v_t_2478));
  return heff_strAppend(v_t_2479, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str17));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam4(V self, V *args) {
  V v_x_2485 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2485);
  return ({ V a_0 = v_rest_244; V a_1 = v_p_241; V a_2 = v_p_242; V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_rest_244); r_; });
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_diags_245 = heff_env(self)[0];
  V v_path_246 = heff_env(self)[1];
  V v_source_247 = heff_env(self)[2];
  V v_p_241 = heff_env(self)[3];
  V v_rest_244 = heff_env(self)[4];
  V v_p_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2484;
  switch (heff_tag_of(v_diags_245)) {
  case TAG_Nil: {
    heff_drop(v_x_2416);
    heff_drop(v_path_246);
    heff_drop(v_source_247);
    v_c_2484 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam2_clo);
    break;
  }
  case TAG_Cons: {
    V v_color_2421 = v_x_2416;
    V v_path_2422 = v_path_246;
    V v_src_2423 = v_source_247;
    V v_ds_2424 = v_diags_245;
    V v_x2_2480 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam3, 1, 3, (V[]){v_path_2422, v_src_2423, v_color_2421}), v_ds_2424));
    V v_str_2483;
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_Nil: {
      v_str_2483 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      V v_xs_2482 = heff_field(v_x2_2480, 1);
      heff_take_n(v_x2_2480, 3ULL, 2);
      v_str_2483 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_str19); V a_1 = v_x_2481; V a_2 = v_xs_2482; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2482); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2480);
    }
    v_c_2484 = heff_tr(heff_call(((V)&g_co_2eop_24s59066675x636147158_clo), 1, (V[]){v_str_2483}));
    break;
  }
  default: heff_nomatch(v_diags_245);
  }
  V f_ = v_c_2484;
  heff_room[0] = heff_dup(v_p_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_lam4, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_str0, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_d_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_st_247 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_247), v_d_246));
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_247), heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_str0))));
    V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
    V v_s_2411 = ({ V a_0 = v_st_247; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_247); heff_drop(v_t_2410); r_; });
    V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1_clo)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    V v_c_2428 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2_clo)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam4, 2, 4, (V[]){v_c_2428, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam1(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_x_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_err_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2423})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2424));
  }
  case TAG_Right: {
    V v_x_2425 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam3, 2, 1, (V[]){v_x_2425});
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_y_2434 = heff_env(self)[1];
  V v_k_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_y_2434}), v_x_2436});
  V f_ = v_k_2430;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2429 = heff_env(self)[2];
  V v_k_2430 = heff_env(self)[3];
  V v_m_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    heff_take_n(v_x_2431, 0ULL, 1);
    heff_drop(v_m_244);
    V v_c_2433 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(v_ps_240, v_rest_245));
    V f_ = v_c_2433;
    heff_room[0] = v_hd_2429;
    heff_room[1] = v_k_2430;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2434 = heff_field(v_x_2431, 0);
    heff_take_n(v_x_2431, 1ULL, 1);
    V v_c_2435 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(v_ps_240, v_rest_245));
    V f_ = v_c_2435;
    heff_room[0] = v_hd_2429;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam6, 1, 3, (V[]){v_m_244, v_y_2434, v_k_2430});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_lam5, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_2429, v_k_2430, v_m_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_errors_245 = heff_take_field(v_o_242, 1);
  V v_source_246 = heff_get_n(v_o_242, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(heff_dup(v_errors_245), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam0, 1, 6, (V[]){v_errors_245, v_outPath_240, v_source_246, v_hd_243, v_k_244, v_done_241})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam3, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2436);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_outPath_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_ru_24x_2425_24Left = heff_take_reuse_n(v_x_2425, 0ULL, 1);
    heff_drop(v_done_241);
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str0), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_str1));
    V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2427, NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2425_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
    V f_ = heff_dup(heff_rfield(v_hd_243, 1));
    heff_room[0] = v_t_2435;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam5, 1, 2, (V[]){v_hd_243, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2425, 0ULL, 1);
    heff_drop(v_outPath_240);
    V f_ = v_done_241;
    heff_room[0] = v_hd_243;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_245 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_source_246 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_done_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  switch (heff_tag_of(v_errors_245)) {
  case TAG_Nil: {
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_outPath_240)));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_249, v_source_246, ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam1_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam2_clo)));
    V f_ = v_c_2424;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_lam4, 1, 4, (V[]){v_outPath_240, v_hd_243, v_k_244, v_done_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_ru_24errors_245_24Cons = heff_take_reuse_n(v_errors_245, 0ULL, 2);
    heff_drop(v_outPath_240);
    heff_drop(v_source_246);
    heff_drop(v_done_241);
    return (g_co_2eop_24s40508559x1835373952_24tok2(v_ru_24errors_245_24Cons, MK_INT(1LL), v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_errors_245);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_str2, 93, "` is the browser's (lib/browser/), for JavaScript: a C program (--backend=c) cannot import it");
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290(V v_lit_240, V v_l_241, V v_name_242, V v_outPath_243, V v_file_244, V v_done_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_str0), heff_dup(heff_rfield(v_l_241, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam0, 1, 8, (V[]){v_l_241, v_hd_246, v_lit_240, v_k_247, v_file_244, v_name_242, v_outPath_243, v_done_245})));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam2(V self, V *args) {
  V v_c_2415 = args[0];
  V v_sources_2413 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = heff_dup(v_c_2415); V a_1 = v_sources_2413; HeffT2 r_ = (g_list_2efind_24s4435330x644005164_24cpr(a_0, a_1)); heff_drop(v_sources_2413); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_s_2419 = v_field_2418;
      V v_t_2420 = ({ V a_0 = v_x_2414; V a_1 = v_s_2419; V r_ = (g_heff_2ebuild_2edriver_2erefusedIn(a_0, a_1)); heff_drop(v_x_2414); r_; });
      return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_2415, v_t_2420));
    } else {
      heff_drop(v_x_2414);
      heff_drop(v_field_2418);
      return v_c_2415;
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam4(V self, V *args) {
  V v_a_2428 = args[0];
  V v_z_2429 = args[1];
  V v_z_2430 = args[2];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2428);
  return (g_co_2eop_24s1772383553x418719539(v_lit_240, v_z_2429, v_z_2430));
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_done_2411 = heff_env(self)[5];
  V v_l_241 = heff_env(self)[6];
  V v_hashes_2412 = heff_env(self)[7];
  V v_file_244 = heff_env(self)[8];
  V v_name_242 = heff_env(self)[9];
  V v_outPath_243 = heff_env(self)[10];
  V v_done_245 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2422);
  if (heff_intLt_c(MK_INT(0LL), v_x_248)) {
    heff_drop(v_done_2411);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_hashes_2412);
    heff_drop(v_file_244);
    heff_drop(v_name_242);
    heff_drop(v_outPath_243);
    heff_drop(v_done_245);
    V v_x2_2423 = ({ V a_0 = v_x_2421; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_x_2421); r_; });
    heff_drop(v_x2_2423);
    return (g_co_2eop_24s1772383553x418719539(v_lit_240, v_hd_246, v_k_247));
  } else {
    V v_t_2424 = (g_list_2eany_24s1740858080x874135214(v_x_2421));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_done_2411);
      heff_drop_rec(v_l_241, 5);
      heff_drop(v_hashes_2412);
      heff_drop(v_file_244);
      heff_drop(v_name_242);
      heff_drop(v_outPath_243);
      heff_drop(v_done_245);
      heff_drop(v_t_2424);
      V v_x2_2425 = ({ V a_0 = v_x_2421; V r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf(a_0)); heff_drop(v_x_2421); r_; });
      heff_drop(v_x2_2425);
      return (g_co_2eop_24s1772383553x418719539(v_lit_240, v_hd_246, v_k_247));
    } else {
      heff_drop(v_t_2424);
      V v_t_2426 = (g_list_2emap_24s1698496827x1884878103(v_done_2411));
      V v_t_2427 = heff_rec_n(3, shape_paths__hashes__modules, (V[]){heff_take_field(v_l_241, 2), v_hashes_2412, v_t_2426});
      return ({ V a_0 = v_t_2427; V b_1 = heff_get_n(v_l_241, 0, 5); V a_2 = v_file_244; V a_3 = v_name_242; V a_4 = v_outPath_243; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam4, 3, 1, (V[]){v_lit_240}); V a_6 = v_done_245; V a_7 = v_x_2421; V a_8 = v_hd_246; V a_9 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ecompileLastC_24s1473228425x1136841387(a_0, b_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(b_1); heff_drop(v_x_2421); r_; });
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_file_244 = heff_env(self)[5];
  V v_name_242 = heff_env(self)[6];
  V v_outPath_243 = heff_env(self)[7];
  V v_done_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_done_2411 = heff_take_field(v_x_2410, 0);
  V v_hashes_2412 = heff_get_n(v_x_2410, 1, 2);
  V v_sources_2413 = heff_dup(heff_rfield(v_l_241, 0));
  V v_x_2414 = (g_list_2emap_24f1524014098x1956473147(MK_INT(351LL), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_str1), ((V)&g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_str2), heff_dup(v_sources_2413)));
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam2, 1, 2, (V[]){v_sources_2413, v_x_2414}), heff_dup(v_done_2411)));
  return ({ V a_0 = v_x_2421; V a_1 = heff_dup(v_hd_246); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam3, 1, 12, (V[]){v_x_248, heff_dup(v_x_2421), v_lit_240, v_hd_246, v_k_247, v_done_2411, v_l_241, v_hashes_2412, v_file_244, v_name_242, v_outPath_243, v_done_245}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_x_2421); r_; });
}
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_file_244 = heff_env(self)[4];
  V v_name_242 = heff_env(self)[5];
  V v_outPath_243 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_249 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_l_241)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecLoadedOr_24s387177184x2093923290_lam1, 1, 9, (V[]){v_l_241, v_hd_246, v_x_248, v_lit_240, v_k_247, v_file_244, v_name_242, v_outPath_243, v_done_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692(V v_chk_240, V v_acc_241, V v_f_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam0, 2, 4, (V[]){v_c_243, v_f_242, v_acc_241, v_chk_240});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2411);
  V f_ = v_k_245;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam4(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam9(V self, V *args) {
  V v_c_2423 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_2424 = heff_take_field(v_c_2423, 1);
  V v_module_2425 = heff_get_n(v_c_2423, 0, 14);
  V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_x_2419, 2)), 1, 6);
  V v_t_2427 = (g_heff_2ebuild_2eload_2einside(heff_get_n(v_x_2419, 2, 5), v_t_2426, v_path_2424));
  if (((heff_dup(v_t_2427) == NTAG(TAG_True)) || ({ V v_t_2439 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242))); int c_ = heff_strEq_c_lent(v_module_2425, v_t_2439, 0); heff_drop(v_t_2439); c_; }))) {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop(v_t_2427);
    V v_x1_2428 = ({ V a_0 = v_module_2425; V b_1 = heff_get_n(v_acc_241, 0, 2); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, b_1)); heff_drop(v_module_2425); heff_drop(b_1); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
    heff_drop(v_x1_2428);
    return v_ret_24bool;
  } else {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop_rec(v_acc_241, 2);
    heff_drop(v_module_2425);
    heff_drop(v_t_2427);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam11(V self, V *args) {
  V v_x_2434 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2434);
  V v_t_2435 = (g_prelude_2e_2b_2b_24f427551988x255400191(heff_take_field(v_acc_241, 0), heff_dup(v_x_2429)));
  V v_t_2436 = heff_intAdd(heff_get_n(v_acc_241, 1, 2), v_x_2420);
  V v_t_2437 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2429; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_x_2429); r_; });
  V v_x_2438 = heff_rec_n(2, shape_seen__errors, (V[]){v_t_2435, heff_intAdd(v_t_2436, v_t_2437)});
  V f_ = v_k_245;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam10(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_x_2420 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get_n(v_hd_244, 1, 3);
  heff_room[0] = v_t_2433;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam11, 1, 4, (V[]){v_acc_241, v_x_2429, v_x_2420, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_x_2420 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2429 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam9, 1, 4, (V[]){v_x_2419, v_x_248, v_f_242, heff_dup(v_acc_241)}), heff_get_n(v_x_2422, 0, 2)));
  return ({ V a_0 = v_x_2429; V a_1 = heff_dup(v_hd_244); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam10, 1, 6, (V[]){v_x_2417, v_hd_244, v_acc_241, heff_dup(v_x_2429), v_x_2420, v_k_245}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_x_2429); r_; });
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam7(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_acc_241 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2421 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2419)));
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam8, 1, 8, (V[]){v_x_2419, v_x_248, v_f_242, v_acc_241, v_hd_244, v_x_2417, v_x_2420, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_str0), heff_dup(heff_rfield(v_x_2419, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam7, 1, 7, (V[]){v_x_2419, v_hd_244, v_x_248, v_f_242, v_acc_241, v_x_2417, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2418 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_242)));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam6, 1, 6, (V[]){v_hd_244, v_x_248, v_f_242, v_acc_241, v_x_2417, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_chk_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = heff_rfield(v_acc_241, 0); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_249); r_; });
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop(v_t_2410);
    return (g_co_2eop_24s1734868233x1940051977(v_chk_240, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam3, 1, 2, (V[]){v_k_245, v_acc_241})));
  } else {
    heff_drop(v_t_2410);
    V v_name_2412 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_240, v_name_2412, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam4_clo)})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2415}));
    V f_ = heff_dup(heff_rfield(v_hd_244, 1));
    heff_room[0] = v_t_2416;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam5, 1, 5, (V[]){v_f_242, v_hd_244, v_x_248, v_acc_241, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_x_246, heff_dup(v_f_242)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam2, 1, 5, (V[]){v_f_242, v_acc_241, v_chk_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692_lam1, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_chk_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(V v_chk_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2echeckModule_24s694910011x1009047692(heff_dup(v_chk_240), v_acc_241, heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam1, 2, 3, (V[]){v_c_247, v_chk_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_chk_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_chk_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_chk_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModules_24s1515489393x154090645_lam2, 1, 4, (V[]){v_chk_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_str1, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_pl_242);
    return v_next_243;
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_name_247 = heff_dup(heff_rfield(v_a_245, 0));
    V v_build_248 = heff_dup(heff_rfield(v_a_245, 1));
    V v_t_249 = heff_tr(g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_pl_242), v_next_243, v_rest_246));
    V v_t_2411;
    if (heff_strEq_c(heff_get_n(v_build_248, 0, 3), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_str0))) {
      v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_name_247)});
    } else {
      V v_t_2410 = heff_dup(heff_rfield(v_t_241, 3));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(heff_dup(v_name_247), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_str1))});
      } else {
        heff_drop(v_t_2410);
        v_t_2411 = NTAG(TAG_Nothing);
      }
    }
    return heff_tail(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_clo), 6, (V[]){v_st_240, v_t_241, v_pl_242, v_t_249, v_name_247, v_t_2411});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s1994464579x1436832262(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str2, 17, "building programs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str3, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam6, 2, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233(V v_st_240, V v_t_241, V v_progs_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str0)));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str1)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_p_248 = ({ V a_0 = v_st_240; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_248));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  V v_s_2412 = ({ V a_0 = v_st_240; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2411); r_; });
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
  V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2413; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2413); r_; });
  V v_a_2416 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam0_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_c_2429 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam1_clo)));
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam3, 1, 5, (V[]){v_progs_242, v_z_243, v_st_240, v_t_241, v_z_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam0(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    V v_err_2424 = heff_field(v_x_2423, 0);
    V v_ru_24x_2423_24Left = heff_take_reuse_n(v_x_2423, 1ULL, 1);
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2423_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2424})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2425));
  }
  case TAG_Right: {
    V v_x_2426 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam2, 2, 1, (V[]){v_x_2426});
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam4(V self, V *args) {
  V v_t_2432 = args[0];
  return v_t_2432;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam6(V self, V *args) {
  V v_a_2441 = args[0];
  V v_a_2442 = args[1];
  heff_drop(v_a_2441);
  V f_ = v_a_2442;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam8(V self, V *args) {
  V v_t_2450 = args[0];
  return v_t_2450;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_k_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2460);
  V f_ = v_k_2459;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam10(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s1531911654x724325922(v_x_2454, v_hd_2458, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam11, 1, 1, (V[]){v_k_2459})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_progs_2439 = heff_env(self)[0];
  V v_st_2437 = heff_env(self)[1];
  V v_t_2438 = heff_env(self)[2];
  V v_home_2443 = heff_env(self)[3];
  V v_hd_2448 = heff_env(self)[4];
  V v_k_2449 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_2439));
  V v_xs_2456 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2455; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2455); r_; });
  V v_t_2457 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2456));
  V v_t_2461 = ({ V a_0 = v_st_2437; V a_1 = v_t_2438; V a_2 = v_home_2443; V a_3 = heff_dup(v_x_2454); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam10, 2, 1, (V[]){v_x_2454}); V a_5 = v_t_2457; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2457); r_; });
  V f_ = v_t_2461;
  heff_room[0] = v_hd_2448;
  heff_room[1] = v_k_2449;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam7(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_t_2447 = heff_env(self)[0];
  V v_total_2446 = heff_env(self)[1];
  V v_progs_2439 = heff_env(self)[2];
  V v_st_2437 = heff_env(self)[3];
  V v_t_2438 = heff_env(self)[4];
  V v_home_2443 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2447, v_total_2446, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam8_clo)})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2448, 2)), 1, (V[]){v_t_2452}));
  V f_ = heff_dup(heff_rfield(v_hd_2448, 1));
  args[0] = v_t_2453;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam9, 1, 6, (V[]){v_progs_2439, v_st_2437, v_t_2438, v_home_2443, v_hd_2448, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam13(V self, V *args) {
  V v_x_2466 = args[0];
  V v_next_2463 = heff_env(self)[0];
  V v_hd_2464 = heff_env(self)[1];
  V v_k_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2466);
  V f_ = v_next_2463;
  heff_room[0] = v_hd_2464;
  heff_room[1] = v_k_2465;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam12(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_x_2436 = heff_env(self)[0];
  V v_next_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2436, heff_dup(v_hd_2464), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam13, 1, 3, (V[]){v_next_2463, v_hd_2464, v_k_2465})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_progs_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2437 = heff_dup(v_st_240);
  V v_t_2438 = heff_dup(v_t_241);
  V v_progs_2439 = heff_dup(v_progs_242);
  V v_x5_2440 = heff_dup(heff_rfield(v_t_241, 4));
  V v_t_2462;
  switch (heff_tag_of(v_x5_2440)) {
  case TAG_Nothing: {
    heff_drop(v_st_2437);
    heff_drop(v_t_2438);
    heff_drop(v_progs_2439);
    v_t_2462 = ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam6_clo);
    break;
  }
  case TAG_Just: {
    V v_home_2443 = heff_field(v_x5_2440, 0);
    heff_take_n(v_x5_2440, 1ULL, 1);
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_2439)));
    V v_xs_2445 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2444; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2444); r_; });
    V v_total_2446 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_2445));
    V v_t_2447 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str3), heff_dup(v_home_2443));
    v_t_2462 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam7, 2, 6, (V[]){v_t_2447, v_total_2446, v_progs_2439, v_st_2437, v_t_2438, v_home_2443});
    break;
  }
  default: heff_nomatch(v_x5_2440);
  }
  V v_next_2463 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417(heff_dup(v_st_240), heff_dup(v_t_241), v_t_2462, v_progs_242));
  V v_t_2467 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2436); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam12, 2, 2, (V[]){v_x_2436, v_next_2463}); V a_4 = v_progs_242; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_242); r_; });
  V f_ = v_t_2467;
  heff_room[0] = v_z_243;
  heff_room[1] = v_z_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_progs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2430);
  V v_total_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_242));
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_str2), v_total_2431, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam4_clo)})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){v_t_2434}));
  V f_ = heff_dup(heff_rfield(v_z_243, 1));
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1522885498x1234340233_lam5, 1, 5, (V[]){v_st_240, v_t_241, v_progs_242, v_z_243, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str2, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str6, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(V v_st_240, V v_t_241, V v_home_242, V v_dir_243, V v_next_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam0, 1, 7, (V[]){v_st_240, v_home_242, v_dir_243, v_hd_245, v_k_246, v_t_241, v_next_244})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam3(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_x_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    V v_err_2429 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Left = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    V v_t_2430 = heff_tag_at_n(v_ru_24x_2428_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2429})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2430));
  }
  case TAG_Right: {
    V v_x_2431 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam3, 2, 1, (V[]){v_x_2431});
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam5(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2451);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam6(V self, V *args) {
  V v_x_2467 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2467);
  V f_ = v_next_244;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 0ULL, 1);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_next_244);
    V v_t_2437 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_home_242));
    V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str2)));
    V v_t_2439 = (g_std_2epath_2ejoin(v_t_2437, v_t_2438));
    V v_t_2440 = ({ V a_0 = v_st_240; V a_1 = v_t_2439; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2439); r_; });
    V v_why_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str3), v_t_2440);
    V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str4), v_why_2441), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str5));
    V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2442, NTAG(TAG_MkUnit)});
    V v_t_2444 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})}));
    V f_ = heff_dup(heff_rfield(v_hd_245, 1));
    heff_room[0] = v_t_2450;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam5, 1, 2, (V[]){v_hd_245, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_2435_24Right = heff_take_reuse_n(v_x_2435, 0ULL, 1);
    V v_t_2453 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_home_242));
    V v_t_2454 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str6)));
    V v_t_2455 = (g_std_2epath_2ejoin(v_t_2453, v_t_2454));
    V v_path_2456 = ({ V a_0 = v_st_240; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2455); r_; });
    V v_t_2457 = heff_strAppend(heff_get_n(v_t_241, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str7));
    V v_t_2458 = heff_strAppend(heff_strAppend(v_t_2457, v_path_2456), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str8));
    V v_t_2459 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2458, NTAG(TAG_MkUnit)});
    V v_t_2460 = heff_tag_at_n(v_ru_24x_2435_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})}));
    V f_ = heff_dup(heff_rfield(v_hd_245, 1));
    heff_room[0] = v_t_2466;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam6, 1, 3, (V[]){v_next_244, v_hd_245, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2435);
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str0)));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_s_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_247));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_243));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  V v_t_2416 = ({ V a_0 = v_st_240; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_heff_2eutil_2ehostpath_2enormalize(heff_dup(v_st_240), v_t_2416));
  V v_text_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_str1));
  V v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
  V v_a_2421 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2419, v_text_2418, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam1_clo)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_c_2434 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam2_clo)));
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_lam4, 1, 6, (V[]){v_st_240, v_home_242, v_hd_245, v_k_246, v_t_241, v_next_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(V v_tok_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_str0), v_e_244), ((V)&g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_str1));
    V v_t_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_WriteErr, 2, (V[]){v_t_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s321980040x1154251472(v_rest_245, heff_dup(v_p_242), v_p_243, heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_p_242));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(a[0], a[1], a[2], a[3]);
}