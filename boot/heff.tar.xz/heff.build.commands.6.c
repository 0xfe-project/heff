// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_MkDir 57961
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Run 29975
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_cwd 308458
#define LBL_diff 9578700
#define LBL_done 9584713
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_expected 956903529
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_files 298792593
#define LBL_got 312070
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_out 319944
#define LBL_outPath 1272254166
#define LBL_own 320000
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_seen 10021698
#define LBL_src 323678
#define LBL_status 1054660381
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_version 583465758
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed};
static uint32_t shape_path__version__hash[] = {LBL_path, LBL_version, LBL_hash};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s591942356x1315919308(V, V, V, V, V, V, V, V);
V g_co_2eop_24s591942356x1315919308_entry(V self, V *a);
extern Clo g_co_2eop_24s591942356x1315919308_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088(V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_clo;
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eexpectedRes_get(void);
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(V);
V g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_clo;
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_clo;
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_heff_2ebuild_2equery_2etypeAt(V, V);
V g_heff_2ebuild_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypeAt_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s2128134357x1680551385(V, V);
V g_list_2efilter_24s2128134357x1680551385_entry(V self, V *a);
extern Clo g_list_2efilter_24s2128134357x1680551385_clo;
V g_list_2efilter_24s50027113x1989932102(V, V);
V g_list_2efilter_24s50027113x1989932102_entry(V self, V *a);
extern Clo g_list_2efilter_24s50027113x1989932102_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s513294106x1954328253(V, V, V, V);
V g_list_2efoldl_24s513294106x1954328253_entry(V self, V *a);
extern Clo g_list_2efoldl_24s513294106x1954328253_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f214727426x610923392(V, V);
V g_prelude_2e_2b_2b_24f214727426x610923392_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f214727426x610923392_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2epath_2eisUnder(V, V, V);
V g_std_2epath_2eisUnder_entry(V self, V *a);
extern Clo g_std_2epath_2eisUnder_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str2, 23, "package.hf: the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffErrors_str3, 12, "the package ");
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffErrors_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffErrors(V v_running_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_project_242 = heff_field(v_x2_241, 0);
    V v_deps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_project_242, 5)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str0))) {
      heff_drop_rec(v_project_242, 7);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_t_245 = v_deps_243;
    } else {
      v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_project_242, v_deps_243});
    }
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eheffErrors_lam0, 2, 1, (V[]){heff_dup(v_running_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eheffErrors(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eheffErrors_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_running_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_wanted_249 = heff_take_field(v_x_248, 5);
  V v_t_2420;
  switch (heff_tag_of(v_running_240)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_248, 7);
    heff_drop(v_wanted_249);
    v_t_2420 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_running_2410 = heff_field(v_running_240, 0);
    heff_take_n(v_running_240, 1ULL, 1);
    V v_t_2412;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 3)), ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str1))) {
      heff_drop_rec(v_x_248, 7);
      v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str2);
    } else {
      v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffErrors_str3), heff_get_n(v_x_248, 0, 7));
    }
    V v_t_2413 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_wanted_249)));
    V v_t_2414 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_running_2410)));
    HeffT2 v_t_2415 = ({ V a_0 = v_t_2412; V a_1 = v_wanted_249; V a_2 = v_running_2410; V a_3 = v_t_2413; V a_4 = v_t_2414; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2413); heff_drop(v_t_2414); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        V v_why_2419 = v_field_2417;
        v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_field_2417);
        v_t_2420 = NTAG(TAG_Nil);
      }
    }
    break;
  }
  default: heff_nomatch(v_running_240);
  }
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_247));
}
Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eelemStrM_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eelemStrM(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eelemStrM(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str0, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str1, 17, "        expected ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str2, 17, "        but got  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efailLines_str3, 17, "        diff     ");
Clo g_heff_2ebuild_2ecommands_2efailLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efailLines_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2efailLines(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_FailBecause: {
    V v_why_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str0), v_why_242), NTAG(TAG_Nil)});
  }
  case TAG_FailDiffer: {
    V v_expected_243 = heff_field(v_x2_241, 0);
    V v_got_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24FailDiffer = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = (g_heff_2elsp_2ereport_2emismatch(v_color_240, v_expected_243, v_got_244));
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str1), heff_take_field(v_m_245, 0));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str2), heff_take_field(v_m_245, 1));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efailLines_str3), heff_get_n(v_m_245, 2, 3));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24FailDiffer, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2efailLines(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(v_m_240), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str0), v_l_245));
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s591942356x1315919308(v_m_240, v_rest_246, v_n_242, MK_INT(1LL), heff_dup(v_p_243), v_p_244, v_t_2411, v_p_243));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam1, 1, 6, (V[]){v_n_245, heff_dup(v_parts_241), v_dir_240, v_p_243, v_rest_246, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3(V self, V *args) {
  V v_ok_2418 = args[0];
  return v_ok_2418;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2423);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = (g_list_2eany_24s1230506745x754542351(heff_dup(v_n_245), v_parts_241));
  V v_c_2422;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_2411);
    heff_drop(v_n_245);
    heff_drop(v_t_2412);
    v_c_2422 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam2_clo);
  } else {
    heff_drop(v_t_2412);
    V v_t_2416;
    if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_str0))) {
      v_t_2416 = NTAG(TAG_Windows);
    } else {
      v_t_2416 = NTAG(TAG_Posix);
    }
    V v_path_2417 = ({ V a_0 = v_t_2416; V a_1 = heff_dup(v_dir_240); V a_2 = v_n_245; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_path_2417, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam3_clo)})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    v_c_2422 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2421}));
  }
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s546164532x294936741_lam4, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str0, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str1, 21, "  errors, as expected");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str3, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str4, 28, "  checks, but expects errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str6, 43, ": checks, but its first line expects errors");
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269(V v_f_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  if ((heff_dup(v_x2_241) == NTAG(TAG_True))) {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str0), heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str1)));
    V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str2)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    return (g_co_2eop_24s954557541x749476273(v_t_248, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_lam0, 1, 1, (V[]){v_p_243})));
  } else {
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str3), heff_strAppend(heff_dup(v_f_240), ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str4)));
    V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str5)), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_lam1, 1, 2, (V[]){v_f_240, v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_249);
  V f_ = v_p_243;
  args[0] = heff_dup(g_heff_2ebuild_2ecommands_2eexpectedRes_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_f_240, ((V)&g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_str6)), NTAG(TAG_Nil)});
  V f_ = v_p_243;
  args[0] = heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), v_t_2416, MK_INT(0LL), MK_INT(0LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str1, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str2, 28, ": build it with `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str3, 16, " -o PROGRAM -lm`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str4, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088(V v_name_240, V v_outPath_241, V v_file_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_lam0, 2, 4, (V[]){v_c_243, v_outPath_241, heff_dup(v_name_240), v_file_242});
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_outPath_241 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)1ULL));
  V v_t_248 = heff_strSlice(heff_dup(v_outPath_241), heff_box_word(v_t_247), heff_strLength_lent(v_outPath_241, 0));
  V v_t_2410;
  if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str0))) {
    v_t_2410 = heff_strAppend(heff_dup(v_outPath_241), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str1));
  } else {
    v_t_2410 = heff_dup(v_outPath_241);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str3)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str4), heff_strAppend(heff_dup(v_outPath_241), v_t_2411));
  V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_str5)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2416}));
  return ({ V a_0 = v_x_246; V a_1 = v_name_240; V a_2 = v_outPath_241; V a_3 = v_file_242; V a_4 = v_t_2417; V a_5 = v_hd_244; V a_6 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_name_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088_lam1, 1, 5, (V[]){v_outPath_241, v_name_240, v_file_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str1, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str2, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str4, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str5, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str6, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str7, 16, ": esm, page or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str8, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(V v_o_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str0))) {
    V v_outPath_242 = heff_take_field(v_o_240, 1);
    V v_t_243 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str1), heff_strAppend(heff_dup(v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str2)));
    V v_t_244 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str3)), NTAG(TAG_MkUnit)});
    V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_247}));
    return ({ V b_0 = heff_dup(heff_rfield(v_o_240, 2)); V a_1 = v_outPath_242; V a_2 = heff_get_n(v_o_240, 0, 4); V a_3 = v_t_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str4))) {
      V v_t_2410 = heff_take_field(v_o_240, 2);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        return (g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s1760269769x37882584(heff_dup(heff_rfield(v_o_240, 0)), heff_get_n(v_o_240, 1, 4)));
      }
      case TAG_Just: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop_rec(v_o_240, 4);
        return ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0_clo);
      }
      default: return heff_nomatch(v_t_2410);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_240, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str6))) {
        return ({ V b_0 = heff_dup(heff_rfield(v_o_240, 2)); V a_1 = heff_dup(heff_rfield(v_o_240, 1)); V a_2 = heff_get_n(v_o_240, 0, 4); V r_ = (g_heff_2ebuild_2ecommands_2ecCmd_24s2080041351x1155210088(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      } else {
        return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam2, 2, 1, (V[]){v_o_240});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096(a[0]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s954557541x749476273(v_t_2422, v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str5), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam1, 1, 2, (V[]){v_hd_2412, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s954557541x749476273(v_t_2436, v_hd_2424, v_k_2425));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_strAppend(heff_get_n(v_o_240, 3, 4), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str7));
  V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str8), v_t_2426), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_str9));
  V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2427, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(v_t_2431, heff_dup(v_hd_2424), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1874124065x1495169096_lam3, 1, 2, (V[]){v_hd_2424, v_k_2425})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str1, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124(V v_file_240, V v_offs_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam0, 2, 2, (V[]){v_c_242, v_offs_241});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam5(V self, V *args) {
  V v_off_2416 = args[0];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2417 = (g_prelude_2eparseInt_24cpr(v_off_2416));
  V v_x2_2422;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_o_2421 = v_field_2419;
      v_x2_2422 = (g_heff_2ebuild_2equery_2etypeAt(v_c_2415, v_o_2421));
    } else {
      heff_drop(v_c_2415);
      heff_drop(v_field_2419);
      v_x2_2422 = NTAG(TAG_Nothing);
    }
  }
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str1);
  }
  case TAG_Just: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    heff_take_n(v_x2_2422, 1ULL, 1);
    return v_x_2423;
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_249));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_c_2415 = v_field_2413;
      V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam5, 1, 1, (V[]){v_c_2415}), v_offs_241));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_t_2424, v_hd_243, v_k_244));
    } else {
      heff_drop(v_offs_241);
      heff_drop(v_field_2413);
      V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_cs_249), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam4, 1, 4, (V[]){v_cs_249, v_offs_241, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam3, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_offs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s699856942x1772549124_lam1, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_str0, 5, ".hash");
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop_rec(v_root_241, 4);
    return ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2418 = (g_list_2efilter_24s2128134357x1680551385(heff_dup(heff_rfield(v_x_245, 0)), heff_take_field(v_root_241, 2)));
  V v_x_2436;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_241, 4);
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_245, 3);
      v_x_2436 = v_x_2410;
      break;
    }
    case TAG_Just: {
      V v_t_2419 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      V v_t_2420 = (g_prelude_2eskipSpaces(heff_dup(v_t_2419), MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_t_2419, 0)) - ((int64_t)1ULL));
      V v_t_2422 = (g_prelude_2eskipSpaces(heff_dup(v_t_2419), heff_box_word(v_t_2421), MK_INT(-1LL)));
      V v_t_2423 = heff_strSlice(v_t_2419, v_t_2420, heff_intAdd(v_t_2422, MK_INT(1LL)));
      V v_t_2424 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2423});
      v_x_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_x_2410});
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    break;
  }
  case TAG_Cons: {
    V v_r_2425 = heff_field(v_t_2418, 0);
    V v_ru_24t_2418_24Cons = heff_take_reuse_n(v_t_2418, 1ULL, 2);
    V v_t_2427 = (g_list_2efilter_24s50027113x1989932102(v_r_2425, heff_get_n(v_root_241, 3, 4)));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_x_2417)) {
      case TAG_Nothing: {
        heff_drop_rec(v_x_245, 3);
        heff_drop_cell(v_ru_24t_2418_24Cons, 2);
        v_x_2436 = v_x_2410;
        break;
      }
      case TAG_Just: {
        V v_t_2428 = heff_field(v_x_2417, 0);
        heff_take_n(v_x_2417, 1ULL, 1);
        V v_t_2429 = (g_prelude_2eskipSpaces(heff_dup(v_t_2428), MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2430 = (heff_unbox_word(heff_strLength_lent(v_t_2428, 0)) - ((int64_t)1ULL));
        V v_t_2431 = (g_prelude_2eskipSpaces(heff_dup(v_t_2428), heff_box_word(v_t_2430), MK_INT(-1LL)));
        V v_t_2432 = heff_strSlice(v_t_2428, v_t_2429, heff_intAdd(v_t_2431, MK_INT(1LL)));
        V v_t_2433 = heff_rec_n(3, shape_path__version__hash, (V[]){heff_take_field(v_x_245, 0), heff_get_n(v_x_245, 1, 3), v_t_2432});
        v_x_2436 = heff_tag_at_n(v_ru_24t_2418_24Cons, TAG_Cons, 2, (V[]){v_t_2433, v_x_2410});
        break;
      }
      default: heff_nomatch(v_x_2417);
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2427, 0ULL, 2);
      heff_drop(v_x_2417);
      heff_drop_rec(v_x_245, 3);
      heff_drop_cell(v_ru_24t_2418_24Cons, 2);
      v_x_2436 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V f_ = v_k_249;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(heff_rfield(v_x_245, 0)), heff_dup(heff_rfield(v_x_245, 1))));
  V v_path_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_str0));
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2412, ((V)&g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam3_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_248, heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam4, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esumsOf_24s1209038194x187069258_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str1, 1, ".");
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(V v_chk_240, V v_acc_241, V v_f_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam0, 2, 4, (V[]){v_c_243, v_f_242, v_acc_241, v_chk_240});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_245;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam9(V self, V *args) {
  V v_c_2422 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ps_2423 = heff_dup(heff_rfield(v_x_2418, 2));
  V v_d_2424 = heff_get_n(heff_get_n(v_x_2418, 2, 5), 1, 6);
  V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_d_2424, ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str1), 2) ? ({ V v_x1_2426 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(heff_rfield(v_c_2422, 0)), heff_rfield(v_acc_241, 0))); int c_ = !(heff_dup(v_x1_2426) == NTAG(TAG_True)); heff_drop(v_x1_2426); c_; }) : ({ V v_t_2427 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2423, 5), heff_dup(heff_rfield(v_ps_2423, 4)), heff_dup(v_d_2424))); int c_ = ({ V v_t_2428 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2423, 5), heff_dup(heff_rfield(v_ps_2423, 4)), heff_dup(heff_rfield(v_c_2422, 1)))); int c_ = ({ V v_t_2429 = (g_std_2epath_2eisUnder(heff_rfield(v_ps_2423, 5), heff_dup(v_t_2427), heff_dup(v_t_2428))); int c_ = ((heff_dup(v_t_2429) == NTAG(TAG_True)) ? ({ V v_x1_2430 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(heff_rfield(v_c_2422, 0)), heff_rfield(v_acc_241, 0))); int c_ = !(heff_dup(v_x1_2430) == NTAG(TAG_True)); heff_drop(v_x1_2430); c_; }) : ({ V v_t_2431 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242))); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_c_2422, 0)), heff_dup(v_t_2431)) && ({ V v_x1_2433 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(heff_rfield(v_c_2422, 0)), heff_rfield(v_acc_241, 0))); int c_ = !(heff_dup(v_x1_2433) == NTAG(TAG_True)); heff_drop(v_x1_2433); c_; })); heff_drop(v_t_2431); c_; })); heff_drop(v_t_2429); c_; }); heff_drop(v_t_2428); c_; }); heff_drop(v_t_2427); c_; })));
  heff_drop_rec(v_c_2422, 13);
  heff_drop_rec(v_acc_241, 2);
  heff_drop(v_x_248);
  heff_drop(v_f_242);
  heff_drop_rec(v_ps_2423, 6);
  heff_drop(v_d_2424);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam11(V self, V *args) {
  V v_x_2437 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_prelude_2e_2b_2b_24f214727426x610923392(heff_take_field(v_acc_241, 0), heff_dup(v_x_2434)));
  V v_t_2439 = heff_intAdd(heff_get_n(v_acc_241, 1, 2), v_x_2419);
  V v_t_2440 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2434; V r_ = (g_list_2efoldl_24s513294106x1954328253(a_0, a_1, a_2, a_3)); heff_drop(v_x_2434); r_; });
  V v_x_2441 = heff_rec_n(2, shape_seen__errors, (V[]){v_t_2438, heff_intAdd(v_t_2439, v_t_2440)});
  V f_ = v_k_245;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam10(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2436}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam11, 1, 4, (V[]){v_acc_241, v_x_2434, v_x_2419, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam8(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2434 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam9, 1, 4, (V[]){v_x_2418, heff_dup(v_acc_241), v_x_248, v_f_242}), heff_get_n(v_x_2421, 0, 2)));
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s702037471x114554739(heff_dup(v_x_2434), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam10, 1, 6, (V[]){v_x_2416, v_hd_244, v_acc_241, v_x_2434, v_x_2419, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2420 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_x_2418)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam8, 1, 8, (V[]){v_x_2418, v_acc_241, v_x_248, v_f_242, v_hd_244, v_x_2416, v_x_2419, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_str0), heff_dup(heff_rfield(v_x_2418, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam7, 1, 7, (V[]){v_x_2418, v_hd_244, v_acc_241, v_x_248, v_f_242, v_x_2416, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2417 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_f_242)));
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam6, 1, 6, (V[]){v_hd_244, v_acc_241, v_x_248, v_f_242, v_x_2416, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_chk_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
  V v_t_2410 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_t_249, heff_rfield(v_acc_241, 0)));
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    heff_drop(v_f_242);
    heff_drop(v_t_2410);
    V v_t_2411 = heff_tag_n(TAG_Complete, 2, (V[]){v_chk_240, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2411}), v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam3, 1, 2, (V[]){v_k_245, v_acc_241})));
  } else {
    heff_drop(v_t_2410);
    V v_name_2413 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_248), heff_dup(v_f_242)));
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_240, v_name_2413, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam4_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam5, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_x_248, v_k_245})));
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_247 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_x_246, heff_dup(v_f_242)));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam2, 1, 5, (V[]){v_f_242, v_acc_241, v_chk_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s1822648866x1847382811_lam1, 1, 5, (V[]){v_f_242, v_hd_244, v_acc_241, v_chk_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str3, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str5, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str6, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str7, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str8, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str9, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str10, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str11, 10, "heff build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str12, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str13, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str14, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str15, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str16, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str17, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str18, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str19, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str20, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str21, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str22, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam18(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962(V v_st_240, V v_t_241, V v_bp_242, V v_x_243, V v_a_244, V v_next_245, V v_p_246, V v_p_247) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_a_244, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str0))) {
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam1, 1, 7, (V[]){v_p_246, heff_dup(v_st_240), v_x_243, v_t_241, v_a_244, v_next_245, v_p_247})));
  } else {
    V v_t_2440 = heff_dup(heff_rfield(v_t_241, 3));
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_242, heff_dup(v_x_243), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9_clo)})});
      return (g_co_2eop_24s954557541x749476273(v_t_2442, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10, 1, 7, (V[]){v_p_246, heff_dup(v_st_240), v_x_243, v_t_241, v_a_244, v_next_245, v_p_247})));
    } else {
      heff_drop_rec(v_t_241, 6);
      heff_drop_rec(v_a_244, 3);
      heff_drop(v_t_2440);
      V v_t_2470 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str20), heff_strAppend(v_x_243, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str21)));
      V v_t_2471 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2470, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str22)), NTAG(TAG_MkUnit)});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      return (g_co_2eop_24s954557541x749476273(v_t_2474, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam18, 1, 4, (V[]){v_bp_242, v_p_246, v_next_245, v_p_247})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam0(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  V v_k_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2439);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2436;
  heff_room[1] = v_k_2437;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam7(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_x_2411 = heff_env(self)[0];
  V v_next_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2438}), heff_dup(v_hd_2436), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam8, 1, 3, (V[]){v_next_245, v_hd_2436, v_k_2437})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_t_2424 = heff_env(self)[3];
  V v_t_2428 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_hd_2432 = heff_env(self)[6];
  V v_k_2433 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2435);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str11); V a_1 = v_st_240; V a_2 = heff_get_n(v_t_241, 5, 6); V a_3 = heff_dup(v_x_2411); V a_4 = v_t_2424; V a_5 = v_t_2428; V a_6 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam7, 2, 2, (V[]){v_x_2411, v_next_245}); V a_7 = v_hd_2432; V a_8 = v_k_2433; V r_ = (g_heff_2ebuild_2ecommands_2ezigBuild_24s1706164242x91675310(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_x_2414 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_t_2424 = heff_env(self)[4];
  V v_t_2428 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2434 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2434}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam6, 1, 8, (V[]){v_st_240, v_t_241, v_x_2411, v_t_2424, v_t_2428, v_next_245, v_hd_2432, v_k_2433})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_outPath_2418 = heff_env(self)[1];
  V v_file_2421 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_241 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_t_2424 = heff_env(self)[7];
  V v_t_2428 = heff_env(self)[8];
  V v_next_245 = heff_env(self)[9];
  V v_p_246 = heff_env(self)[10];
  V v_p_247 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_244, 1, 3)});
  return ({ V a_0 = v_x_2430; V a_1 = v_t_2431; V a_2 = v_outPath_2418; V a_3 = v_file_2421; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam5, 2, 7, (V[]){v_x_2414, v_st_240, v_t_241, v_x_2411, v_t_2424, v_t_2428, v_next_245}); V a_5 = v_p_246; V a_6 = v_p_247; V r_ = (g_heff_2ebuild_2ecommands_2ecLoaded_24s174675656x1627270490(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_t_2431, 1); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str2), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str3)));
  V v_p_2416 = (g_std_2epath_2ejoin(v_st_240, v_t_2415, heff_dup(v_x_243)));
  V v_t_2417 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_2416));
  V v_outPath_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str4));
  V v_t_2419 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str5), heff_dup(v_x_243)));
  V v_p_2420 = (g_std_2epath_2ejoin(v_st_240, v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str6)));
  V v_file_2421 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_2420));
  V v_t_2422 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str7), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str8)));
  V v_p_2423 = (g_std_2epath_2ejoin(v_st_240, v_t_2422, heff_dup(v_x_243)));
  V v_t_2424 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_2423));
  V v_t_2425 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str9), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str10)));
  V v_p_2426 = (g_std_2epath_2ejoin(v_st_240, v_t_2425, heff_dup(v_x_243)));
  V v_t_2427 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_2426));
  V v_t_2428 = (g_std_2epath_2ejoin(v_st_240, v_t_2427, v_x_243));
  V v_c_2429 = (g_heff_2ebuild_2ecommands_2eload_24s1026228218x144433627(heff_dup(v_file_2421)));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam4, 1, 12, (V[]){v_a_244, v_outPath_2418, v_file_2421, v_x_2414, v_st_240, v_t_241, v_x_2411, v_t_2424, v_t_2428, v_next_245, v_p_246, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2411), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam2_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam3, 1, 8, (V[]){v_st_240, v_x_243, v_t_241, v_p_246, v_a_244, v_x_2411, v_next_245, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam9(V self, V *args) {
  V v_t_2441 = args[0];
  return v_t_2441;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11(V self, V *args) {
  V v_t_2444 = args[0];
  return v_t_2444;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13(V self, V *args) {
  V v_ok_2450 = args[0];
  return v_ok_2450;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam17(V self, V *args) {
  V v_x_2468 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_hd_2463 = heff_env(self)[1];
  V v_k_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2468);
  V f_ = v_next_245;
  heff_room[0] = v_hd_2463;
  heff_room[1] = v_k_2464;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_hd_2463 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_k_2464 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2466);
  V v_t_2467 = heff_tag_n(TAG_End, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2467}), heff_dup(v_hd_2463), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam17, 1, 3, (V[]){v_next_245, v_hd_2463, v_k_2464})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam15(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_x_2446 = heff_env(self)[0];
  V v_x_2443 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2465 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2465}), heff_dup(v_hd_2463), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam16, 1, 4, (V[]){v_x_2443, v_hd_2463, v_next_245, v_k_2464})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam14(V self, V *args) {
  V v_x_2454 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_x_2446 = heff_env(self)[4];
  V v_x_2443 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_246 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2454);
  V v_t_2455 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_244, 1, 3)});
  V v_t_2456 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str15), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str16)));
  V v_p_2457 = (g_std_2epath_2ejoin(v_st_240, v_t_2456, heff_dup(v_x_243)));
  V v_t_2458 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_2457));
  V v_t_2459 = (g_std_2epath_2ejoin(v_st_240, v_t_2458, heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str17))));
  V v_t_2460 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str18), v_x_243));
  V v_p_2461 = (g_std_2epath_2ejoin(v_st_240, v_t_2460, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str19)));
  V v_t_2462 = ({ V a_0 = v_st_240; V a_1 = heff_get_n(v_t_241, 0, 6); V a_2 = v_p_2461; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  V v_t_2469 = ({ V a_0 = v_t_2455; V a_1 = v_t_2459; V a_2 = v_t_2462; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam15, 2, 3, (V[]){v_x_2446, v_x_2443, v_next_245}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1487240683x1262776246(a_0, a_1, a_2, a_3)); heff_drop_tag(v_t_2455, 1); r_; });
  V f_ = v_t_2469;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12(V self, V *args) {
  V v_x_2446 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_x_2443 = heff_env(self)[5];
  V v_next_245 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2447 = (g_std_2epath_2ejoin(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str13), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str14)));
  V v_p_2448 = (g_std_2epath_2ejoin(v_st_240, v_t_2447, heff_dup(v_x_243)));
  V v_path_2449 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_241, 0)), v_p_2448));
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2449, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam13_clo)})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s954557541x749476273(v_t_2453, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam14, 1, 9, (V[]){v_a_244, v_st_240, v_x_243, v_t_241, v_x_2446, v_x_2443, v_next_245, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_next_245 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2443), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_str12), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam11_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2445, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam12, 1, 8, (V[]){v_st_240, v_x_243, v_t_241, v_p_246, v_a_244, v_x_2443, v_next_245, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19(V self, V *args) {
  V v_x_2477 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2477);
  V f_ = v_next_245;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam18(V self, V *args) {
  V v_x_2475 = args[0];
  V v_bp_242 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_245 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2475);
  V v_t_2476 = heff_tag_n(TAG_Complete, 2, (V[]){v_bp_242, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2476}), heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s1011232155x1286477962_lam19, 1, 3, (V[]){v_next_245, v_p_246, v_p_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_progs_243);
    return v_done_242;
  }
  case TAG_Just: {
    V v_home_245 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_total_248 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_247));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam0, 2, 6, (V[]){v_home_245, v_total_248, v_progs_243, v_st_240, v_t_241, v_done_242});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  V f_ = v_done_242;
  heff_room[0] = v_hd_2417;
  heff_room[1] = v_k_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2413 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2419}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam4, 1, 3, (V[]){v_done_242, v_hd_2417, v_k_2418})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_home_245 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2415));
  V v_t_2421 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_home_245; V a_3 = heff_dup(v_x_2413); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam3, 2, 2, (V[]){v_x_2413, v_done_242}); V a_5 = v_t_2416; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s724403493x1066130911(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2416); r_; });
  V f_ = v_t_2421;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_home_245 = heff_env(self)[0];
  V v_total_248 = heff_env(self)[1];
  V v_progs_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_done_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2412 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_str0), heff_dup(v_home_245)), v_total_248, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam1_clo)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2412}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1765187999x1654274584_lam2, 1, 7, (V[]){v_progs_243, v_st_240, v_t_241, v_home_245, v_done_242, v_hd_249, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(V v_st_240, V v_cmd_241, V v_t_242, V v_none_243, V v_done_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str0)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_c_249 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_248, NTAG(TAG_Nil)));
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam0, 1, 7, (V[]){v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s954557541x749476273(v_t_2435, v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7(V self, V *args) {
  V v_ns_2447 = args[0];
  return v_ns_2447;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9(V self, V *args) {
  V v_t_2455 = args[0];
  return v_t_2455;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam13(V self, V *args) {
  V v_x_2476 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2476);
  V v_t_2477 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  return (g_co_2eop_24s954557541x749476273(v_t_2480, v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam12(V self, V *args) {
  V v_x_2464 = args[0];
  V v_x_2462 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2464);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2462, 1)))) {
    heff_drop(v_none_243);
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_done_244);
    V v_n_2466 = heff_get_n(v_x_2462, 1, 2);
    V v_t_2468;
    if (heff_intEq_c(heff_dup(v_n_2466), MK_INT(1LL))) {
      heff_drop(v_n_2466);
      v_t_2468 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str17);
    } else {
      v_t_2468 = heff_strAppend(heff_intShow(v_n_2466), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str18));
    }
    V v_what_2469 = heff_strAppend(v_t_2468, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str19));
    V v_t_2470 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str20), heff_strAppend(v_what_2469, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str21)));
    V v_t_2471 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str22), heff_strAppend(v_cmd_241, v_t_2470));
    V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2471, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str23)), NTAG(TAG_MkUnit)});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    return (g_co_2eop_24s954557541x749476273(v_t_2475, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam13, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    heff_drop(v_cmd_241);
    V v_t_2481 = heff_dup(heff_rfield(v_x_2462, 0));
    switch (heff_tag_of(v_t_2481)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2462, 2);
      heff_drop(v_st_240);
      heff_drop_rec(v_t_242, 6);
      heff_drop(v_done_244);
      V f_ = v_none_243;
      heff_room[0] = v_z_245;
      heff_room[1] = v_z_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      heff_take_n(v_t_2481, 0ULL, 2);
      heff_drop(v_none_243);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1782837886x1332887624(v_st_240, v_t_242, v_done_244, heff_get_n(v_x_2462, 0, 2), v_z_245, v_z_246));
    }
    default: return heff_nomatch(v_t_2481);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam11(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_2457 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_none_243 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_t_242 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2463 = heff_tag_n(TAG_End, 2, (V[]){v_x_2457, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2463}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam12, 1, 8, (V[]){v_x_2462, v_cmd_241, v_z_245, v_z_246, v_none_243, v_st_240, v_t_242, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2451 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2458 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2460;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_Nothing: {
    v_t_2460 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2459 = heff_field(v_x_2451, 0);
    heff_take_n(v_x_2451, 1ULL, 1);
    v_t_2460 = v_x_2459;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_c_2461 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2457), v_t_2458, v_t_2460));
  V f_ = v_c_2461;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam11, 1, 8, (V[]){v_x_2457, v_z_245, v_cmd_241, v_z_246, v_none_243, v_st_240, v_t_242, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2453;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_Nothing: {
    v_t_2453 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2452 = heff_dup(heff_field(v_x_2451, 0));
    v_t_2453 = v_x_2452;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_total_2454 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2453; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2453); r_; });
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str16), v_total_2454, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam9_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2456, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam10, 1, 8, (V[]){v_x_2451, v_st_240, v_t_242, v_z_245, v_cmd_241, v_z_246, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2445);
  V v_path_2446 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str15)));
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){v_path_2446, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam7_clo)})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s954557541x749476273(v_t_2450, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam8, 1, 7, (V[]){v_z_245, v_st_240, v_t_242, v_cmd_241, v_z_246, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2419);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2417, 1)))) {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_none_243);
    heff_drop(v_done_244);
    V v_n_2421 = heff_get_n(v_x_2417, 1, 2);
    V v_t_2423;
    if (heff_intEq_c(heff_dup(v_n_2421), MK_INT(1LL))) {
      heff_drop(v_n_2421);
      v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str2);
    } else {
      v_t_2423 = heff_strAppend(heff_intShow(v_n_2421), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str3));
    }
    V v_what_2424 = heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str4));
    V v_t_2425 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str5), heff_strAppend(v_what_2424, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str6)));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str7), heff_strAppend(v_cmd_241, v_t_2425));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str8)), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s954557541x749476273(v_t_2430, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam5, 1, 2, (V[]){v_z_245, v_z_246})));
  } else {
    V v_n_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2417, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2438;
    if (heff_intEq_c(heff_dup(v_n_2436), MK_INT(1LL))) {
      heff_drop(v_n_2436);
      v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str9);
    } else {
      v_t_2438 = heff_strAppend(heff_intShow(v_n_2436), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str10));
    }
    V v_t_2439 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str11), heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str12)));
    V v_str_2440 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str13), heff_strAppend(heff_dup(v_cmd_241), v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2440, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str14)), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s954557541x749476273(v_t_2444, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam6, 1, 7, (V[]){v_st_240, v_t_242, v_z_245, v_cmd_241, v_z_246, v_none_243, v_done_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2418}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam4, 1, 8, (V[]){v_x_2417, v_cmd_241, v_z_245, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_none_243 = heff_env(self)[6];
  V v_done_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2415 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2416 = ({ V a_0 = heff_dup(v_x_2414); V a_1 = v_t_2415; V a_2 = v_x_2410; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a_0, a_1, a_2)); heff_drop(v_x_2410); r_; });
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam3, 1, 8, (V[]){v_x_2414, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_none_243 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_total_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2410));
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_str1), v_total_2411, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam1_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_lam2, 1, 8, (V[]){v_x_2410, v_z_245, v_cmd_241, v_z_246, v_st_240, v_t_242, v_none_243, v_done_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str0, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str1, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str2, 6, "status");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str8, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str12, 67, "heff publish: what is published is what is committed: commit first\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str13, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str14, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str15, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str16, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str2), v_t_245}), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam1, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241})));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s954557541x749476273(v_t_2437, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2449);
  V v_t_2450 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s954557541x749476273(v_t_2453, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  return (g_co_2eop_24s954557541x749476273(v_t_2465, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam8(V self, V *args) {
  V v_x_2469 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(v_v_240, v_pk_241, v_x_2469, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam7(V self, V *args) {
  V v_x_2468 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_x_2468; V a_1 = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()); V a_2 = heff_dup(v_hd_243); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam8, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244}); V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s444122823x427680548(a_0, a_1, a_2, a_3)); heff_drop(v_x_2468); r_; });
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_src_242 = heff_env(self)[4];
  V v_pk_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = heff_bool(!heff_intEq_c(heff_dup(heff_rfield(v_x_2411, 0)), MK_INT(0LL)));
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2419, 3);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    heff_drop(v_t_2421);
    V v_s_2422 = heff_get_n(v_x_2411, 2, 3);
    V v_t_2423 = (g_prelude_2eskipSpaces(heff_dup(v_s_2422), MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_s_2422, 0)) - ((int64_t)1ULL));
    V v_t_2425 = (g_prelude_2eskipSpaces(heff_dup(v_s_2422), heff_box_word(v_t_2424), MK_INT(-1LL)));
    V v_t_2426 = heff_strSlice(v_s_2422, v_t_2423, heff_intAdd(v_t_2425, MK_INT(1LL)));
    V v_why_2427 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str8), v_t_2426);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str9), v_why_2427), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str10));
    V v_t_2429 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s954557541x749476273(v_t_2432, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam4, 1, 2, (V[]){v_hd_243, v_k_244})));
  } else {
    heff_drop(v_t_2421);
    V v_s_2438 = heff_get_n(v_x_2411, 1, 3);
    V v_t_2439 = (g_prelude_2eskipSpaces(heff_dup(v_s_2438), MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_s_2438, 0)) - ((int64_t)1ULL));
    V v_t_2441 = (g_prelude_2eskipSpaces(heff_dup(v_s_2438), heff_box_word(v_t_2440), MK_INT(-1LL)));
    V v_t_2442 = heff_strSlice(v_s_2438, v_t_2439, heff_intAdd(v_t_2441, MK_INT(1LL)));
    V v_t_2444 = heff_bool(!heff_strEq_c_lent(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str11), 2));
    heff_drop(v_t_2442);
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2419, 3);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      heff_drop(v_t_2444);
      V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str12), NTAG(TAG_MkUnit)});
      V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      return (g_co_2eop_24s954557541x749476273(v_t_2448, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam5, 1, 2, (V[]){v_hd_243, v_k_244})));
    } else {
      heff_drop(v_t_2444);
      if (heff_intEq_c(heff_get_n(v_x_2419, 0, 3), MK_INT(0LL))) {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        V v_t_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str13), heff_strAppend(v_v_240, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str14)));
        V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str15), v_t_2455), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str16));
        V v_t_2457 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2456, NTAG(TAG_MkUnit)});
        V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
        V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
        V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
        return (g_co_2eop_24s954557541x749476273(v_t_2460, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam6, 1, 2, (V[]){v_hd_243, v_k_244})));
      } else {
        V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_c_2467 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_2466, NTAG(TAG_Nil)));
        V f_ = v_c_2467;
        heff_room[0] = heff_dup(v_hd_243);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam7, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_src_242 = heff_env(self)[3];
  V v_pk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str3), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str5), v_t_2412})});
  V v_t_2415 = heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_str7), v_t_2413}), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam2_clo)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s265852524x560396595_lam3, 1, 6, (V[]){v_x_2411, v_hd_243, v_k_244, v_v_240, v_src_242, v_pk_241})));
}