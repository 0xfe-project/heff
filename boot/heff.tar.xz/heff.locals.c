// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_heff_2elocals_2enone_val;
static int g_heff_2elocals_2enone_st;
static V g_heff_2elocals_2enone_init(void) {
  return heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2elocals_2enone_get(void) {
  if (g_heff_2elocals_2enone_st == 2) return g_heff_2elocals_2enone_val;
  if (g_heff_2elocals_2enone_st == 1) heff_fail("defined by itself");
  g_heff_2elocals_2enone_st = 1;
  g_heff_2elocals_2enone_val = heff_tr(g_heff_2elocals_2enone_init());
  g_heff_2elocals_2enone_st = 2;
  return g_heff_2elocals_2enone_val;
}
Clo g_heff_2elocals_2efindBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2efindBinder_entry, 2, 0};

V g_heff_2elocals_2efindBinder(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_b_242), LBL_name), heff_dup(v_x_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      heff_drop(v_t_244);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_b_242)});
    }
    case TAG_False: {
      heff_drop(v_t_244);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elocals_2efindBinder_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2efindBinder(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elocals_2epatternBinders_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_it1_241 = heff_field(v_p_240, 0);
    V v_sp_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse(v_p_240, 3ULL);
    switch (heff_tag_of(v_it1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_it1_241, 0);
      heff_take(v_it1_241, 1ULL);
      V v_t_244 = heff_strEq(heff_dup(v_x_243), ((V)&g_heff_2elocals_2epatternBinders_str0));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_sp_242);
        heff_drop(v_ru_24p_240_24At);
        heff_drop(v_x_243);
        heff_drop(v_t_244);
        return NTAG(TAG_Nil);
      }
      case TAG_False: {
        heff_drop(v_t_244);
        V v_t_245 = heff_rec(3, shape_190_299_93, (V[]){v_x_243, v_sp_242, NTAG(TAG_False)});
        return heff_tag_at(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_it1_241, 2);
      heff_take(v_it1_241, 4ULL);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24p_240_24At);
      V v_t_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_prelude_2efoldl_24s752(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_it1_241, 2);
      heff_take(v_it1_241, 4ULL);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24p_240_24At);
      V v_t_2413 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_prelude_2efoldl_24s752(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take(v_it1_241, 0ULL);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24p_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take(v_it1_241, 0ULL);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24p_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take(v_it1_241, 0ULL);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24p_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2417 = heff_field(v_it1_241, 0);
      heff_take(v_it1_241, 1ULL);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24p_240_24At);
      V v_t_2418 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_fs_2417));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_prelude_2efoldl_24s753(a_0, a_1)); heff_drop(v_t_2418); r_; });
    }
    case TAG_PatWord: {
      heff_take(v_it1_241, 0ULL);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24p_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2420 = heff_field(v_it1_241, 0);
      V v_it12_2421 = heff_field(v_it1_241, 1);
      V v_q_2422 = heff_field(v_it1_241, 2);
      heff_take(v_it1_241, 7ULL);
      heff_drop(v_sp_242);
      V v_t_2423 = heff_rec(3, shape_190_299_93, (V[]){v_x_2420, v_it12_2421, NTAG(TAG_False)});
      return heff_tag_at(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2423, (g_heff_2elocals_2epatternBinders(v_q_2422))});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2epatternBinders(a[0]);
}
Clo g_heff_2elocals_2eimplicitsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eimplicitsOf_entry, 1, 0};

V g_heff_2elocals_2eimplicitsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse(v_x1_240, 1ULL);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_x111_2415 = heff_field(v_x11_241, 0);
      V v_r_2416 = heff_field(v_x11_241, 1);
      heff_take(v_x11_241, 3ULL);
      switch (heff_tag_of(v_x111_2415)) {
      case TAG_PiNamed: {
        heff_take(v_x111_2415, 0ULL);
        heff_drop(v_ru_24x1_240_24At);
        heff_drop(v_r_2416);
        return NTAG(TAG_Nil);
      }
      case TAG_PiImplicit: {
        V v_x_2420 = heff_field(v_x111_2415, 0);
        V v_sp_2421 = heff_field(v_x111_2415, 1);
        heff_take(v_x111_2415, 3ULL);
        V v_t_2424 = heff_rec(3, shape_190_299_93, (V[]){v_x_2420, v_sp_2421, NTAG(TAG_False)});
        return heff_tag_at(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2424, (g_heff_2elocals_2eimplicitsOf(v_r_2416))});
      }
      case TAG_PiInstance: {
        V v_x_2425 = heff_field(v_x111_2415, 0);
        V v_sp_2426 = heff_field(v_x111_2415, 1);
        heff_take(v_x111_2415, 3ULL);
        V v_t_2429 = heff_rec(3, shape_190_299_93, (V[]){v_x_2425, v_sp_2426, NTAG(TAG_False)});
        return heff_tag_at(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2429, (g_heff_2elocals_2eimplicitsOf(v_r_2416))});
      }
      case TAG_PiAnon: {
        heff_take(v_x111_2415, 0ULL);
        heff_drop(v_ru_24x1_240_24At);
        heff_drop(v_r_2416);
        return NTAG(TAG_Nil);
      }
      default: return heff_nomatch(v_x111_2415);
      }
    }
    case TAG_ELam: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take(v_x11_241, 0ULL);
      heff_drop(v_ru_24x1_240_24At);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elocals_2eimplicitsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2eimplicitsOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elocals_2elamBinders_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elocals_2elamBinders_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_243 = heff_strEq(heff_dup(v_x_241), ((V)&g_heff_2elocals_2elamBinders_str0));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop(v_ru_24x1_240_24LamName);
      heff_drop(v_t_243);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      heff_drop(v_t_243);
      V v_t_244 = heff_rec(3, shape_190_299_93, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_LamImplicit: {
    V v_x_245 = heff_field(v_x1_240, 0);
    V v_sp_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse(v_x1_240, 3ULL);
    V v_t_247 = heff_strEq(heff_dup(v_x_245), ((V)&g_heff_2elocals_2elamBinders_str1));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_x_245);
      heff_drop(v_sp_246);
      heff_drop(v_ru_24x1_240_24LamImplicit);
      heff_drop(v_t_247);
      return NTAG(TAG_Nil);
    }
    case TAG_False: {
      heff_drop(v_t_247);
      V v_t_248 = heff_rec(3, shape_190_299_93, (V[]){v_x_245, v_sp_246, NTAG(TAG_False)});
      return heff_tag_at(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_LamAnn: {
    V v_x_249 = heff_field(v_x1_240, 0);
    V v_sp_2410 = heff_field(v_x1_240, 1);
    heff_take(v_x1_240, 3ULL);
    V v_t_2412 = heff_rec(3, shape_190_299_93, (V[]){v_x_249, v_sp_2410, NTAG(TAG_False)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2elocals_2eequationF_24s757_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eequationF_24s757_entry, 2, 0};

V g_heff_2elocals_2eequationF_24s757(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_prelude_2efoldl_24s752(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_prelude_2efoldl_24s0(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2elocals_2ewalkF_24s754(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2econcatList(v_bs_249, heff_get(heff_dup(v_b_2411), LBL_binders)));
      V v_t_2413 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2411, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2eequationF_24s757_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2eequationF_24s757(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2elocals_2eparamWalk_24s759_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eparamWalk_24s759_entry, 2, 0};

V g_heff_2elocals_2eparamWalk_24s759(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse(v_x3_241, 1ULL);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_t_246 = heff_field(v_x31_242, 2);
      heff_take(v_x31_242, 7ULL);
      V v_t_247 = (g_heff_2elocals_2efindBinder(v_x_244, v_env_240));
      V v_a_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop(v_ru_24x3_241_24At);
        heff_drop(v_xsp_245);
        heff_drop(v_t_247);
        v_a_2410 = heff_dup(g_heff_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_248 = heff_field(v_t_247, 0);
        heff_take(v_t_247, 1ULL);
        V v_t_249 = heff_tag_at(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_248, v_xsp_245}), NTAG(TAG_Nil)});
        v_a_2410 = heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_249});
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_b_2411 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_t_246));
      V v_t_2412 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2410), LBL_binders), heff_get(heff_dup(v_b_2411), LBL_binders)));
      V v_t_2413 = (g_prelude_2econcatList(heff_get(v_a_2410, LBL_uses), heff_get(v_b_2411, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2412, v_t_2413});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x31_242, 0);
      V v_xsp_2415 = heff_field(v_x31_242, 1);
      V v_t_2416 = heff_field(v_x31_242, 2);
      heff_take(v_x31_242, 7ULL);
      V v_t_2417 = (g_heff_2elocals_2efindBinder(v_x_2414, v_env_240));
      V v_a_2420;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop(v_ru_24x3_241_24At);
        heff_drop(v_xsp_2415);
        heff_drop(v_t_2417);
        v_a_2420 = heff_dup(g_heff_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2418 = heff_field(v_t_2417, 0);
        heff_take(v_t_2417, 1ULL);
        V v_t_2419 = heff_tag_at(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_2418, v_xsp_2415}), NTAG(TAG_Nil)});
        v_a_2420 = heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_2419});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      V v_b_2421 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_t_2416));
      V v_t_2422 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2420), LBL_binders), heff_get(heff_dup(v_b_2421), LBL_binders)));
      V v_t_2423 = (g_prelude_2econcatList(heff_get(v_a_2420, LBL_uses), heff_get(v_b_2421, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2422, v_t_2423});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2eparamWalk_24s759_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2eparamWalk_24s759(a[0], a[1]);
}
V g_heff_2elocals_2edeclF_24s758_lam0(V self, V *args);
V g_heff_2elocals_2edeclF_24s758_lam1(V self, V *args);
Clo g_heff_2elocals_2edeclF_24s758_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2edeclF_24s758_entry, 2, 0};

V g_heff_2elocals_2edeclF_24s758(V v_env_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_f_245 = heff_field(v_t_244, 0);
    V v_fsp_246 = heff_field(v_t_244, 1);
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take(v_t_244, 15ULL);
    V v_t_249 = (g_heff_2elocals_2efindBinder(v_f_245, v_env_240));
    V v_a_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_fsp_246);
      heff_drop(v_t_249);
      v_a_2412 = heff_dup(g_heff_2elocals_2enone_get());
      break;
    }
    case TAG_Just: {
      V v_b_2410 = heff_field(v_t_249, 0);
      heff_take(v_t_249, 1ULL);
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_2410, v_fsp_246}), NTAG(TAG_Nil)});
      v_a_2412 = heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_2411});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_a_2413 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_ty_247));
    V v_b_2419 = ({ V a_0 = heff_clo(g_heff_2elocals_2edeclF_24s758_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
    V v_t_2420 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2413), LBL_binders), heff_get(heff_dup(v_b_2419), LBL_binders)));
    V v_t_2421 = (g_prelude_2econcatList(heff_get(v_a_2413, LBL_uses), heff_get(v_b_2419, LBL_uses)));
    V v_b_2422 = heff_rec(2, shape_23_348, (V[]){v_t_2420, v_t_2421});
    V v_t_2423 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2412), LBL_binders), heff_get(heff_dup(v_b_2422), LBL_binders)));
    V v_t_2424 = (g_prelude_2econcatList(heff_get(v_a_2412, LBL_uses), heff_get(v_b_2422, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_2423, v_t_2424});
  }
  case TAG_DeclDefine: {
    V v_x_2425 = heff_field(v_t_244, 0);
    V v_xsp_2426 = heff_field(v_t_244, 1);
    V v_ps_2427 = heff_field(v_t_244, 2);
    V v_u_2428 = heff_field(v_t_244, 3);
    V v_body_2429 = heff_field(v_t_244, 4);
    heff_take(v_t_244, 31ULL);
    V v_t_2430 = (g_heff_2elocals_2efindBinder(v_x_2425, v_env_240));
    V v_a_2433;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Nothing: {
      heff_drop(v_xsp_2426);
      heff_drop(v_t_2430);
      v_a_2433 = heff_dup(g_heff_2elocals_2enone_get());
      break;
    }
    case TAG_Just: {
      V v_b_2431 = heff_field(v_t_2430, 0);
      heff_take(v_t_2430, 1ULL);
      V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_2431, v_xsp_2426}), NTAG(TAG_Nil)});
      v_a_2433 = heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_2432});
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    V v_a_2439 = ({ V a_0 = heff_clo(g_heff_2elocals_2edeclF_24s758_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_ps_2427; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2427); r_; });
    V v_a_2440 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_u_2428));
    V v_b_2441 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_body_2429));
    V v_t_2442 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2440), LBL_binders), heff_get(heff_dup(v_b_2441), LBL_binders)));
    V v_t_2443 = (g_prelude_2econcatList(heff_get(v_a_2440, LBL_uses), heff_get(v_b_2441, LBL_uses)));
    V v_b_2444 = heff_rec(2, shape_23_348, (V[]){v_t_2442, v_t_2443});
    V v_t_2445 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2439), LBL_binders), heff_get(heff_dup(v_b_2444), LBL_binders)));
    V v_t_2446 = (g_prelude_2econcatList(heff_get(v_a_2439, LBL_uses), heff_get(v_b_2444, LBL_uses)));
    V v_b_2447 = heff_rec(2, shape_23_348, (V[]){v_t_2445, v_t_2446});
    V v_t_2448 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2433), LBL_binders), heff_get(heff_dup(v_b_2447), LBL_binders)));
    V v_t_2449 = (g_prelude_2econcatList(heff_get(v_a_2433, LBL_uses), heff_get(v_b_2447, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_2448, v_t_2449});
  }
  case TAG_DeclTheory: {
    V v_body_2453 = heff_field(v_t_244, 3);
    heff_take(v_t_244, 8ULL);
    return (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_body_2453));
  }
  case TAG_DeclPrimitive: {
    V v_x_2454 = heff_field(v_t_244, 0);
    V v_xsp_2455 = heff_field(v_t_244, 1);
    V v_t_2456 = heff_field(v_t_244, 2);
    heff_take(v_t_244, 7ULL);
    V v_t_2457 = (g_heff_2elocals_2efindBinder(v_x_2454, v_env_240));
    V v_a_2460;
    switch (heff_tag_of(v_t_2457)) {
    case TAG_Nothing: {
      heff_drop(v_xsp_2455);
      heff_drop(v_t_2457);
      v_a_2460 = heff_dup(g_heff_2elocals_2enone_get());
      break;
    }
    case TAG_Just: {
      V v_b_2458 = heff_field(v_t_2457, 0);
      heff_take(v_t_2457, 1ULL);
      V v_t_2459 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_2458, v_xsp_2455}), NTAG(TAG_Nil)});
      v_a_2460 = heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_2459});
      break;
    }
    default: heff_nomatch(v_t_2457);
    }
    V v_b_2461 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_t_2456));
    V v_t_2462 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2460), LBL_binders), heff_get(heff_dup(v_b_2461), LBL_binders)));
    V v_t_2463 = (g_prelude_2econcatList(heff_get(v_a_2460, LBL_uses), heff_get(v_b_2461, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_2462, v_t_2463});
  }
  case TAG_DeclTest: {
    V v_x_2464 = heff_field(v_t_244, 0);
    V v_xsp_2465 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24DeclTest = heff_take_reuse(v_t_244, 3ULL);
    V v_t_2466 = ({ V a_0 = v_x_2464; V a_1 = v_env_240; V r_ = (g_heff_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
    switch (heff_tag_of(v_t_2466)) {
    case TAG_Nothing: {
      heff_drop(v_xsp_2465);
      heff_drop(v_ru_24t_244_24DeclTest);
      heff_drop(v_t_2466);
      return heff_dup(g_heff_2elocals_2enone_get());
    }
    case TAG_Just: {
      V v_b_2467 = heff_field(v_t_2466, 0);
      heff_take(v_t_2466, 1ULL);
      V v_t_2468 = heff_tag_at(v_ru_24t_244_24DeclTest, TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_2467, v_xsp_2465}), NTAG(TAG_Nil)});
      return heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_2468});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_DeclWatch: {
    V v_e_2469 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    return (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_e_2469));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elocals_2edeclF_24s758_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2edeclF_24s758(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elocals_2edeclF_24s758_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_eq_2415 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_2416 = ({ V a_0 = v_env_240; V a_1 = v_eq_2415; V r_ = (g_heff_2elocals_2eequationF_24s757(a_0, a_1)); heff_drop(v_eq_2415); r_; });
  V v_t_2417 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_2414), LBL_binders), heff_get(heff_dup(v_b_2416), LBL_binders)));
  V v_t_2418 = (g_prelude_2econcatList(heff_get(v_acc_2414, LBL_uses), heff_get(v_b_2416, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_2417, v_t_2418});
}
V g_heff_2elocals_2edeclF_24s758_lam1(V self, V *args) {
  V v_acc_2434 = args[0];
  V v_m_2435 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_2436 = (g_heff_2elocals_2eparamWalk_24s759(v_env_240, v_m_2435));
  V v_t_2437 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_2434), LBL_binders), heff_get(heff_dup(v_b_2436), LBL_binders)));
  V v_t_2438 = (g_prelude_2econcatList(heff_get(v_acc_2434, LBL_uses), heff_get(v_b_2436, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_2437, v_t_2438});
}
V g_heff_2elocals_2elocalDefF_24s756_lam0(V self, V *args);
Clo g_heff_2elocals_2elocalDefF_24s756_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2elocalDefF_24s756_entry, 2, 0};

V g_heff_2elocals_2elocalDefF_24s756(V v_env_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take(v_t_244, 12ULL);
    V v_a_249 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), heff_dup(v_ty_247)));
    V v_b_2430 = ({ V a_0 = heff_clo(g_heff_2elocals_2elocalDefF_24s756_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
    V v_t_2431 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_249), LBL_binders), heff_get(heff_dup(v_b_2430), LBL_binders)));
    V v_t_2432 = (g_prelude_2econcatList(heff_get(v_a_249, LBL_uses), heff_get(v_b_2430, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_2431, v_t_2432});
  }
  case TAG_DeclDefine: {
    heff_take(v_t_244, 0ULL);
    return (g_heff_2elocals_2edeclF_24s758(v_env_240, v_d_241));
  }
  case TAG_DeclTheory: {
    heff_take(v_t_244, 0ULL);
    return (g_heff_2elocals_2edeclF_24s758(v_env_240, v_d_241));
  }
  case TAG_DeclPrimitive: {
    heff_take(v_t_244, 0ULL);
    return (g_heff_2elocals_2edeclF_24s758(v_env_240, v_d_241));
  }
  case TAG_DeclTest: {
    heff_take(v_t_244, 0ULL);
    return (g_heff_2elocals_2edeclF_24s758(v_env_240, v_d_241));
  }
  case TAG_DeclWatch: {
    heff_take(v_t_244, 0ULL);
    return (g_heff_2elocals_2edeclF_24s758(v_env_240, v_d_241));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elocals_2elocalDefF_24s756_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2elocalDefF_24s756(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elocals_2elocalDefF_24s756_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_eq_2411 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  V v_ty_247 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_a_2421;
  switch (heff_tag_of(v_eq_2411)) {
  case TAG_At: {
    V v_x21_2412 = heff_dup(heff_field(v_eq_2411, 0));
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_fsp_2415 = heff_field(v_x21_2412, 1);
      heff_take(v_x21_2412, 3ULL);
      V v_t_2418 = (g_heff_2elocals_2efindBinder(v_f_2414, v_env_240));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        heff_drop(v_fsp_2415);
        heff_drop(v_t_2418);
        v_a_2421 = heff_dup(g_heff_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2419 = heff_field(v_t_2418, 0);
        heff_take(v_t_2418, 1ULL);
        V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_2419, v_fsp_2415}), NTAG(TAG_Nil)});
        v_a_2421 = heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_2420});
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    default: heff_nomatch(v_x21_2412);
    }
    break;
  }
  default: heff_nomatch(v_eq_2411);
  }
  V v_bs_2422 = (g_heff_2elocals_2eimplicitsOf(v_ty_247));
  V v_t_2423 = (g_prelude_2efoldl_24s0(v_env_240, v_bs_2422));
  V v_b_2424 = ({ V a_0 = v_t_2423; V a_1 = v_eq_2411; V r_ = (g_heff_2elocals_2eequationF_24s757(a_0, a_1)); heff_drop(v_eq_2411); r_; });
  V v_t_2425 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2421), LBL_binders), heff_get(heff_dup(v_b_2424), LBL_binders)));
  V v_t_2426 = (g_prelude_2econcatList(heff_get(v_a_2421, LBL_uses), heff_get(v_b_2424, LBL_uses)));
  V v_b_2427 = heff_rec(2, shape_23_348, (V[]){v_t_2425, v_t_2426});
  V v_t_2428 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_2410), LBL_binders), heff_get(heff_dup(v_b_2427), LBL_binders)));
  V v_t_2429 = (g_prelude_2econcatList(heff_get(v_acc_2410, LBL_uses), heff_get(v_b_2427, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_2428, v_t_2429});
}
Clo g_heff_2elocals_2elocalsF_24s755_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2elocalsF_24s755_entry, 3, 0};

V g_heff_2elocals_2elocalsF_24s755(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_body_242));
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x3_241, 0);
    V v_ds_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse(v_x3_241, 3ULL);
    V v_t_247;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_x_245 = heff_dup(heff_field(v_d_243, 0));
      v_t_247 = v_x_245;
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_bs_2428;
    switch (heff_tag_of(v_t_247)) {
    case TAG_DeclEquations: {
      V v_f_248 = heff_field(v_t_247, 0);
      V v_fsp_249 = heff_field(v_t_247, 1);
      heff_take(v_t_247, 3ULL);
      V v_t_2412 = heff_rec(3, shape_190_299_93, (V[]){v_f_248, v_fsp_249, NTAG(TAG_False)});
      v_bs_2428 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ru_24x3_241_24Cons);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ru_24x3_241_24Cons);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ru_24x3_241_24Cons);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ru_24x3_241_24Cons);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take(v_t_247, 0ULL);
      heff_drop(v_ru_24x3_241_24Cons);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_a_2429 = heff_rec(2, shape_23_348, (V[]){v_bs_2428, NTAG(TAG_Nil)});
    V v_t_2432;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_x_2430 = heff_dup(heff_field(v_d_243, 0));
      v_t_2432 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_bs_2453;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_DeclEquations: {
      V v_f_2433 = heff_field(v_t_2432, 0);
      V v_fsp_2434 = heff_field(v_t_2432, 1);
      heff_take(v_t_2432, 3ULL);
      V v_t_2437 = heff_rec(3, shape_190_299_93, (V[]){v_f_2433, v_fsp_2434, NTAG(TAG_False)});
      v_bs_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take(v_t_2432, 0ULL);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take(v_t_2432, 0ULL);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take(v_t_2432, 0ULL);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take(v_t_2432, 0ULL);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take(v_t_2432, 0ULL);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_t_2454 = (g_prelude_2efoldl_24s0(heff_dup(v_env_240), v_bs_2453));
    V v_a_2455 = (g_heff_2elocals_2elocalDefF_24s756(v_t_2454, v_d_243));
    V v_t_2458;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_x_2456 = heff_field(v_d_243, 0);
      heff_take(v_d_243, 1ULL);
      v_t_2458 = v_x_2456;
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_bs_2479;
    switch (heff_tag_of(v_t_2458)) {
    case TAG_DeclEquations: {
      V v_f_2459 = heff_field(v_t_2458, 0);
      V v_fsp_2460 = heff_field(v_t_2458, 1);
      heff_take(v_t_2458, 3ULL);
      V v_t_2463 = heff_rec(3, shape_190_299_93, (V[]){v_f_2459, v_fsp_2460, NTAG(TAG_False)});
      v_bs_2479 = heff_tag(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take(v_t_2458, 0ULL);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take(v_t_2458, 0ULL);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take(v_t_2458, 0ULL);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take(v_t_2458, 0ULL);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take(v_t_2458, 0ULL);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2458);
    }
    V v_t_2480 = (g_prelude_2efoldl_24s0(v_env_240, v_bs_2479));
    V v_b_2481 = (g_heff_2elocals_2elocalsF_24s755(v_t_2480, v_ds_244, v_body_242));
    V v_t_2482 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2455), LBL_binders), heff_get(heff_dup(v_b_2481), LBL_binders)));
    V v_t_2483 = (g_prelude_2econcatList(heff_get(v_a_2455, LBL_uses), heff_get(v_b_2481, LBL_uses)));
    V v_b_2484 = heff_rec(2, shape_23_348, (V[]){v_t_2482, v_t_2483});
    V v_t_2485 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2429), LBL_binders), heff_get(heff_dup(v_b_2484), LBL_binders)));
    V v_t_2486 = (g_prelude_2econcatList(heff_get(v_a_2429, LBL_uses), heff_get(v_b_2484, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_2485, v_t_2486});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2elocalsF_24s755_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2elocalsF_24s755(a[0], a[1], a[2]);
}
Clo g_heff_2elocals_2esigBlockF_24s760_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2esigBlockF_24s760_entry, 2, 0};

V g_heff_2elocals_2esigBlockF_24s760(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_x3_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse(v_x3_241, 3ULL);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse(v_x31_242, 1ULL);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        heff_take(v_x311_244, 7ULL);
        V v_a_249 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_a_248));
        V v_t_2410 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2411 = (g_heff_2elocals_2esigBlockF_24s760(heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_env_240}), v_rest_243));
        V v_t_2412 = heff_rec(3, shape_190_299_93, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2413 = heff_tag_at(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_t_2414 = (g_prelude_2econcatList(v_t_2413, heff_get(heff_dup(v_b_2411), LBL_binders)));
        V v_t_2415 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2411, LBL_uses)));
        V v_b_2416 = heff_rec(2, shape_23_348, (V[]){v_t_2414, v_t_2415});
        V v_t_2417 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_249), LBL_binders), heff_get(heff_dup(v_b_2416), LBL_binders)));
        V v_t_2418 = (g_prelude_2econcatList(heff_get(v_a_249, LBL_uses), heff_get(v_b_2416, LBL_uses)));
        return heff_rec(2, shape_23_348, (V[]){v_t_2417, v_t_2418});
      }
      case TAG_BadFieldDecl: {
        V v_f_2419 = heff_field(v_x311_244, 0);
        heff_take(v_x311_244, 1ULL);
        heff_drop(v_ru_24x3_241_24Cons);
        heff_drop(v_ru_24x31_242_24At);
        V v_a_2420 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_f_2419));
        V v_b_2421 = (g_heff_2elocals_2esigBlockF_24s760(v_env_240, v_rest_243));
        V v_t_2422 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2420), LBL_binders), heff_get(heff_dup(v_b_2421), LBL_binders)));
        V v_t_2423 = (g_prelude_2econcatList(heff_get(v_a_2420, LBL_uses), heff_get(v_b_2421, LBL_uses)));
        return heff_rec(2, shape_23_348, (V[]){v_t_2422, v_t_2423});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2esigBlockF_24s760_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2esigBlockF_24s760(a[0], a[1]);
}
Clo g_heff_2elocals_2edoBlockF_24s761_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2edoBlockF_24s761_entry, 2, 0};

V g_heff_2elocals_2edoBlockF_24s761(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    heff_drop(v_x3_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse(v_x3_241, 3ULL);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse(v_x31_242, 1ULL);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take(v_x311_244, 7ULL);
        V v_a_249 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_e_248));
        V v_t_2410 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2411 = (g_heff_2elocals_2edoBlockF_24s761(heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_env_240}), v_rest_243));
        V v_t_2412 = heff_rec(3, shape_190_299_93, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2413 = heff_tag_at(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_t_2414 = (g_prelude_2econcatList(v_t_2413, heff_get(heff_dup(v_b_2411), LBL_binders)));
        V v_t_2415 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2411, LBL_uses)));
        V v_b_2416 = heff_rec(2, shape_23_348, (V[]){v_t_2414, v_t_2415});
        V v_t_2417 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_249), LBL_binders), heff_get(heff_dup(v_b_2416), LBL_binders)));
        V v_t_2418 = (g_prelude_2econcatList(heff_get(v_a_249, LBL_uses), heff_get(v_b_2416, LBL_uses)));
        return heff_rec(2, shape_23_348, (V[]){v_t_2417, v_t_2418});
      }
      case TAG_StmtLet: {
        V v_p_2419 = heff_field(v_x311_244, 0);
        V v_e_2420 = heff_field(v_x311_244, 1);
        heff_take(v_x311_244, 3ULL);
        heff_drop(v_ru_24x3_241_24Cons);
        heff_drop(v_ru_24x31_242_24At);
        V v_a_2421 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_e_2420));
        V v_bs_2422 = (g_heff_2elocals_2epatternBinders(heff_dup(v_p_2419)));
        V v_a_2423 = heff_rec(2, shape_23_348, (V[]){v_bs_2422, NTAG(TAG_Nil)});
        V v_bs_2424 = (g_heff_2elocals_2epatternBinders(v_p_2419));
        V v_env_2425 = (g_prelude_2efoldl_24s0(v_env_240, v_bs_2424));
        V v_b_2426 = (g_heff_2elocals_2edoBlockF_24s761(v_env_2425, v_rest_243));
        V v_t_2427 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2423), LBL_binders), heff_get(heff_dup(v_b_2426), LBL_binders)));
        V v_t_2428 = (g_prelude_2econcatList(heff_get(v_a_2423, LBL_uses), heff_get(v_b_2426, LBL_uses)));
        V v_b_2429 = heff_rec(2, shape_23_348, (V[]){v_t_2427, v_t_2428});
        V v_t_2430 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2421), LBL_binders), heff_get(heff_dup(v_b_2429), LBL_binders)));
        V v_t_2431 = (g_prelude_2econcatList(heff_get(v_a_2421, LBL_uses), heff_get(v_b_2429, LBL_uses)));
        return heff_rec(2, shape_23_348, (V[]){v_t_2430, v_t_2431});
      }
      case TAG_StmtExpr: {
        V v_e_2432 = heff_field(v_x311_244, 0);
        heff_take(v_x311_244, 1ULL);
        heff_drop(v_ru_24x3_241_24Cons);
        heff_drop(v_ru_24x31_242_24At);
        V v_a_2433 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_e_2432));
        V v_b_2434 = (g_heff_2elocals_2edoBlockF_24s761(v_env_240, v_rest_243));
        V v_t_2435 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2433), LBL_binders), heff_get(heff_dup(v_b_2434), LBL_binders)));
        V v_t_2436 = (g_prelude_2econcatList(heff_get(v_a_2433, LBL_uses), heff_get(v_b_2434, LBL_uses)));
        return heff_rec(2, shape_23_348, (V[]){v_t_2435, v_t_2436});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2edoBlockF_24s761_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2edoBlockF_24s761(a[0], a[1]);
}
V g_heff_2elocals_2ewalkF_24s754_lam0(V self, V *args);
V g_heff_2elocals_2ewalkF_24s754_lam2(V self, V *args);
V g_heff_2elocals_2ewalkF_24s754_lam1(V self, V *args);
V g_heff_2elocals_2ewalkF_24s754_lam3(V self, V *args);
V g_heff_2elocals_2ewalkF_24s754_lam4(V self, V *args);
Clo g_heff_2elocals_2ewalkF_24s754_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2ewalkF_24s754_entry, 2, 0};

V g_heff_2elocals_2ewalkF_24s754(V v_env_240, V v_n_241) {
top: ;
  V v_it_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_dup(heff_field(v_n_241, 0));
    v_it_244 = v_x_242;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_it_244)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_it_244, 0);
    heff_take(v_it_244, 1ULL);
    V v_sp_248;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_247 = heff_field(v_n_241, 1);
      heff_take(v_n_241, 2ULL);
      v_sp_248 = v_s_247;
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_t_249 = ({ V a_0 = v_x_245; V a_1 = v_env_240; V r_ = (g_heff_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_sp_248);
      heff_drop(v_t_249);
      return heff_dup(g_heff_2elocals_2enone_get());
    }
    case TAG_Just: {
      V v_b_2410 = heff_field(v_t_249, 0);
      heff_take(v_t_249, 1ULL);
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_21_345, (V[]){v_b_2410, v_sp_248}), NTAG(TAG_Nil)});
      return heff_rec(2, shape_23_348, (V[]){NTAG(TAG_Nil), v_t_2411});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_EImplicitVar: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_ETag: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EInt: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EFloat: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EString: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EWord: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EApp: {
    V v_h_2418 = heff_field(v_it_244, 0);
    V v_args_2419 = heff_field(v_it_244, 1);
    heff_take(v_it_244, 3ULL);
    heff_drop(v_n_241);
    V v_a_2420 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_h_2418));
    V v_b_2426 = ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s754_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_args_2419; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_2419); r_; });
    V v_t_2427 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2420), LBL_binders), heff_get(heff_dup(v_b_2426), LBL_binders)));
    V v_t_2428 = (g_prelude_2econcatList(heff_get(v_a_2420, LBL_uses), heff_get(v_b_2426, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_2427, v_t_2428});
  }
  case TAG_EProject: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_ENamed: {
    V v_e_2431 = heff_field(v_it_244, 1);
    heff_take(v_it_244, 2ULL);
    heff_drop(v_n_241);
    V t_0 = v_env_240;
    V t_1 = v_e_2431;
    v_env_240 = t_0;
    v_n_241 = t_1;
    goto top;
  }
  case TAG_EPi: {
    V v_it1_2432 = heff_field(v_it_244, 0);
    V v_r_2433 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EPi = heff_take_reuse(v_it_244, 3ULL);
    heff_drop(v_n_241);
    switch (heff_tag_of(v_it1_2432)) {
    case TAG_PiNamed: {
      V v_x_2434 = heff_field(v_it1_2432, 0);
      V v_sp_2435 = heff_field(v_it1_2432, 1);
      V v_a_2436 = heff_field(v_it1_2432, 2);
      heff_take(v_it1_2432, 7ULL);
      V v_a_2437 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_a_2436));
      V v_t_2438 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_2434), heff_dup(v_sp_2435), NTAG(TAG_False)});
      V v_t_2439 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
      V v_env_2440 = (g_prelude_2efoldl_24s0(v_env_240, v_t_2439));
      V v_b_2441 = (g_heff_2elocals_2ewalkF_24s754(v_env_2440, v_r_2433));
      V v_t_2442 = heff_rec(3, shape_190_299_93, (V[]){v_x_2434, v_sp_2435, NTAG(TAG_False)});
      V v_t_2443 = heff_tag(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
      V v_t_2444 = (g_prelude_2econcatList(v_t_2443, heff_get(heff_dup(v_b_2441), LBL_binders)));
      V v_t_2445 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2441, LBL_uses)));
      V v_b_2446 = heff_rec(2, shape_23_348, (V[]){v_t_2444, v_t_2445});
      V v_t_2447 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2437), LBL_binders), heff_get(heff_dup(v_b_2446), LBL_binders)));
      V v_t_2448 = (g_prelude_2econcatList(heff_get(v_a_2437, LBL_uses), heff_get(v_b_2446, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2447, v_t_2448});
    }
    case TAG_PiImplicit: {
      V v_x_2449 = heff_field(v_it1_2432, 0);
      V v_sp_2450 = heff_field(v_it1_2432, 1);
      V v_a_2452 = heff_field(v_it1_2432, 3);
      heff_take(v_it1_2432, 11ULL);
      V v_a_2453 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_a_2452));
      V v_t_2454 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_2449), heff_dup(v_sp_2450), NTAG(TAG_False)});
      V v_t_2455 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
      V v_env_2456 = (g_prelude_2efoldl_24s0(v_env_240, v_t_2455));
      V v_b_2457 = (g_heff_2elocals_2ewalkF_24s754(v_env_2456, v_r_2433));
      V v_t_2458 = heff_rec(3, shape_190_299_93, (V[]){v_x_2449, v_sp_2450, NTAG(TAG_False)});
      V v_t_2459 = heff_tag(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
      V v_t_2460 = (g_prelude_2econcatList(v_t_2459, heff_get(heff_dup(v_b_2457), LBL_binders)));
      V v_t_2461 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2457, LBL_uses)));
      V v_b_2462 = heff_rec(2, shape_23_348, (V[]){v_t_2460, v_t_2461});
      V v_t_2463 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2453), LBL_binders), heff_get(heff_dup(v_b_2462), LBL_binders)));
      V v_t_2464 = (g_prelude_2econcatList(heff_get(v_a_2453, LBL_uses), heff_get(v_b_2462, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2463, v_t_2464});
    }
    case TAG_PiInstance: {
      V v_x_2465 = heff_field(v_it1_2432, 0);
      V v_sp_2466 = heff_field(v_it1_2432, 1);
      V v_a_2468 = heff_field(v_it1_2432, 3);
      heff_take(v_it1_2432, 11ULL);
      V v_a_2469 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_a_2468));
      V v_t_2470 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_2465), heff_dup(v_sp_2466), NTAG(TAG_False)});
      V v_t_2471 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
      V v_env_2472 = (g_prelude_2efoldl_24s0(v_env_240, v_t_2471));
      V v_b_2473 = (g_heff_2elocals_2ewalkF_24s754(v_env_2472, v_r_2433));
      V v_t_2474 = heff_rec(3, shape_190_299_93, (V[]){v_x_2465, v_sp_2466, NTAG(TAG_False)});
      V v_t_2475 = heff_tag(TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
      V v_t_2476 = (g_prelude_2econcatList(v_t_2475, heff_get(heff_dup(v_b_2473), LBL_binders)));
      V v_t_2477 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2473, LBL_uses)));
      V v_b_2478 = heff_rec(2, shape_23_348, (V[]){v_t_2476, v_t_2477});
      V v_t_2479 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2469), LBL_binders), heff_get(heff_dup(v_b_2478), LBL_binders)));
      V v_t_2480 = (g_prelude_2econcatList(heff_get(v_a_2469, LBL_uses), heff_get(v_b_2478, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2479, v_t_2480});
    }
    case TAG_PiAnon: {
      V v_a_2481 = heff_field(v_it1_2432, 0);
      heff_take(v_it1_2432, 1ULL);
      heff_drop(v_ru_24it_244_24EPi);
      V v_a_2482 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_a_2481));
      V v_b_2483 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_r_2433));
      V v_t_2484 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2482), LBL_binders), heff_get(heff_dup(v_b_2483), LBL_binders)));
      V v_t_2485 = (g_prelude_2econcatList(heff_get(v_a_2482, LBL_uses), heff_get(v_b_2483, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2484, v_t_2485});
    }
    default: return heff_nomatch(v_it1_2432);
    }
  }
  case TAG_ELam: {
    V v_it1_2486 = heff_field(v_it_244, 0);
    V v_r_2487 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELam = heff_take_reuse(v_it_244, 3ULL);
    heff_drop(v_n_241);
    switch (heff_tag_of(v_it1_2486)) {
    case TAG_LamName: {
      heff_drop(v_ru_24it_244_24ELam);
      V v_bs_2490 = (g_heff_2elocals_2elamBinders(v_it1_2486));
      V v_env_2491 = (g_prelude_2efoldl_24s0(v_env_240, heff_dup(v_bs_2490)));
      V v_b_2492 = (g_heff_2elocals_2ewalkF_24s754(v_env_2491, v_r_2487));
      V v_t_2493 = (g_prelude_2econcatList(v_bs_2490, heff_get(heff_dup(v_b_2492), LBL_binders)));
      V v_t_2494 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2492, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2493, v_t_2494});
    }
    case TAG_LamImplicit: {
      heff_drop(v_ru_24it_244_24ELam);
      V v_bs_2497 = (g_heff_2elocals_2elamBinders(v_it1_2486));
      V v_env_2498 = (g_prelude_2efoldl_24s0(v_env_240, heff_dup(v_bs_2497)));
      V v_b_2499 = (g_heff_2elocals_2ewalkF_24s754(v_env_2498, v_r_2487));
      V v_t_24100 = (g_prelude_2econcatList(v_bs_2497, heff_get(heff_dup(v_b_2499), LBL_binders)));
      V v_t_24101 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2499, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_24100, v_t_24101});
    }
    case TAG_LamAnn: {
      V v_x_24102 = heff_field(v_it1_2486, 0);
      V v_sp_24103 = heff_field(v_it1_2486, 1);
      V v_a_24104 = heff_field(v_it1_2486, 2);
      heff_take(v_it1_2486, 7ULL);
      V v_a_24105 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_a_24104));
      V v_t_24106 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_24102), heff_dup(v_sp_24103), NTAG(TAG_False)});
      V v_t_24107 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_t_24106, NTAG(TAG_Nil)});
      V v_env_24108 = (g_prelude_2efoldl_24s0(v_env_240, v_t_24107));
      V v_b_24109 = (g_heff_2elocals_2ewalkF_24s754(v_env_24108, v_r_2487));
      V v_t_24110 = heff_rec(3, shape_190_299_93, (V[]){v_x_24102, v_sp_24103, NTAG(TAG_False)});
      V v_t_24111 = heff_tag(TAG_Cons, 2, (V[]){v_t_24110, NTAG(TAG_Nil)});
      V v_t_24112 = (g_prelude_2econcatList(v_t_24111, heff_get(heff_dup(v_b_24109), LBL_binders)));
      V v_t_24113 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_24109, LBL_uses)));
      V v_b_24114 = heff_rec(2, shape_23_348, (V[]){v_t_24112, v_t_24113});
      V v_t_24115 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_24105), LBL_binders), heff_get(heff_dup(v_b_24114), LBL_binders)));
      V v_t_24116 = (g_prelude_2econcatList(heff_get(v_a_24105, LBL_uses), heff_get(v_b_24114, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_24115, v_t_24116});
    }
    default: return heff_nomatch(v_it1_2486);
    }
  }
  case TAG_EAnn: {
    V v_e_24117 = heff_field(v_it_244, 0);
    V v_t_24118 = heff_field(v_it_244, 1);
    heff_take(v_it_244, 3ULL);
    heff_drop(v_n_241);
    V v_a_24119 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_e_24117));
    V v_b_24120 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_t_24118));
    V v_t_24121 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_24119), LBL_binders), heff_get(heff_dup(v_b_24120), LBL_binders)));
    V v_t_24122 = (g_prelude_2econcatList(heff_get(v_a_24119, LBL_uses), heff_get(v_b_24120, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_24121, v_t_24122});
  }
  case TAG_ESpec: {
    V v_acc_24123 = heff_field(v_it_244, 0);
    V v_v_24126 = heff_field(v_it_244, 3);
    heff_take(v_it_244, 9ULL);
    heff_drop(v_n_241);
    V v_a_24127 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_acc_24123));
    V v_b_24128 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_v_24126));
    V v_t_24129 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_24127), LBL_binders), heff_get(heff_dup(v_b_24128), LBL_binders)));
    V v_t_24130 = (g_prelude_2econcatList(heff_get(v_a_24127, LBL_uses), heff_get(v_b_24128, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_24129, v_t_24130});
  }
  case TAG_ESig: {
    V v_fs_24131 = heff_field(v_it_244, 0);
    heff_take(v_it_244, 1ULL);
    heff_drop(v_n_241);
    return (g_heff_2elocals_2esigBlockF_24s760(v_env_240, v_fs_24131));
  }
  case TAG_ESum: {
    V v_vs_24132 = heff_field(v_it_244, 0);
    heff_take(v_it_244, 1ULL);
    heff_drop(v_n_241);
    return ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s754_lam1, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_vs_24132; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24132); r_; });
  }
  case TAG_EStruct: {
    V v_fs_24149 = heff_field(v_it_244, 0);
    heff_take(v_it_244, 1ULL);
    heff_drop(v_n_241);
    return ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s754_lam3, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_fs_24149; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24149); r_; });
  }
  case TAG_EMatch: {
    V v_s_24161 = heff_field(v_it_244, 0);
    V v_alts_24162 = heff_field(v_it_244, 1);
    heff_take(v_it_244, 3ULL);
    heff_drop(v_n_241);
    V v_a_24163 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_s_24161));
    V v_b_24178 = ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s754_lam4, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_alts_24162; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24162); r_; });
    V v_t_24179 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_24163), LBL_binders), heff_get(heff_dup(v_b_24178), LBL_binders)));
    V v_t_24180 = (g_prelude_2econcatList(heff_get(v_a_24163, LBL_uses), heff_get(v_b_24178, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_24179, v_t_24180});
  }
  case TAG_ELetIn: {
    V v_rhs_24181 = heff_field(v_it_244, 0);
    V v_a_24182 = heff_field(v_it_244, 1);
    heff_take(v_it_244, 3ULL);
    heff_drop(v_n_241);
    V v_a_24183 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_rhs_24181));
    V v_b_24193;
    switch (heff_tag_of(v_a_24182)) {
    case TAG_At: {
      V v_x31_24184 = heff_field(v_a_24182, 0);
      heff_take(v_a_24182, 1ULL);
      switch (heff_tag_of(v_x31_24184)) {
      case TAG_MkAlt: {
        V v_p_24186 = heff_field(v_x31_24184, 0);
        V v_r_24187 = heff_field(v_x31_24184, 1);
        heff_take(v_x31_24184, 3ULL);
        V v_bs_24188 = (g_heff_2elocals_2epatternBinders(v_p_24186));
        V v_env_24189 = (g_prelude_2efoldl_24s0(v_env_240, heff_dup(v_bs_24188)));
        V v_b_24190 = (g_heff_2elocals_2ewalkF_24s754(v_env_24189, v_r_24187));
        V v_t_24191 = (g_prelude_2econcatList(v_bs_24188, heff_get(heff_dup(v_b_24190), LBL_binders)));
        V v_t_24192 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_24190, LBL_uses)));
        v_b_24193 = heff_rec(2, shape_23_348, (V[]){v_t_24191, v_t_24192});
        break;
      }
      default: heff_nomatch(v_x31_24184);
      }
      break;
    }
    default: heff_nomatch(v_a_24182);
    }
    V v_t_24194 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_24183), LBL_binders), heff_get(heff_dup(v_b_24193), LBL_binders)));
    V v_t_24195 = (g_prelude_2econcatList(heff_get(v_a_24183, LBL_uses), heff_get(v_b_24193, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_24194, v_t_24195});
  }
  case TAG_EDo: {
    V v_stmts_24196 = heff_field(v_it_244, 0);
    heff_take(v_it_244, 1ULL);
    heff_drop(v_n_241);
    return (g_heff_2elocals_2edoBlockF_24s761(v_env_240, v_stmts_24196));
  }
  case TAG_ELocal: {
    V v_body_24197 = heff_field(v_it_244, 0);
    V v_defs_24198 = heff_field(v_it_244, 1);
    heff_take(v_it_244, 3ULL);
    heff_drop(v_n_241);
    return (g_heff_2elocals_2elocalsF_24s755(v_env_240, v_defs_24198, v_body_24197));
  }
  case TAG_EInvalid: {
    heff_take(v_it_244, 0ULL);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2elocals_2ewalkF_24s754_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2ewalkF_24s754(a[0], a[1]);
}
V g_heff_2elocals_2ewalkF_24s754_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_x_2422 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_2423 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_x_2422));
  V v_t_2424 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_2421), LBL_binders), heff_get(heff_dup(v_b_2423), LBL_binders)));
  V v_t_2425 = (g_prelude_2econcatList(heff_get(v_acc_2421, LBL_uses), heff_get(v_b_2423, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_2424, v_t_2425});
}
V g_heff_2elocals_2ewalkF_24s754_lam2(V self, V *args) {
  V v_acc_24140 = args[0];
  V v_x_24141 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_24142 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_x_24141));
  V v_t_24143 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_24140), LBL_binders), heff_get(heff_dup(v_b_24142), LBL_binders)));
  V v_t_24144 = (g_prelude_2econcatList(heff_get(v_acc_24140, LBL_uses), heff_get(v_b_24142, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_24143, v_t_24144});
}
V g_heff_2elocals_2ewalkF_24s754_lam1(V self, V *args) {
  V v_acc_24133 = args[0];
  V v_v_24134 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_24146;
  switch (heff_tag_of(v_v_24134)) {
  case TAG_At: {
    V v_it1_24135 = heff_field(v_v_24134, 0);
    heff_take(v_v_24134, 1ULL);
    switch (heff_tag_of(v_it1_24135)) {
    case TAG_TagVariant: {
      V v_args_24139 = heff_field(v_it1_24135, 2);
      heff_take(v_it1_24135, 4ULL);
      v_b_24146 = ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s754_lam2, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_args_24139; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24139); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24145 = heff_field(v_it1_24135, 0);
      heff_take(v_it1_24135, 1ULL);
      v_b_24146 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_e_24145));
      break;
    }
    default: heff_nomatch(v_it1_24135);
    }
    break;
  }
  default: heff_nomatch(v_v_24134);
  }
  V v_t_24147 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_24133), LBL_binders), heff_get(heff_dup(v_b_24146), LBL_binders)));
  V v_t_24148 = (g_prelude_2econcatList(heff_get(v_acc_24133, LBL_uses), heff_get(v_b_24146, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_24147, v_t_24148});
}
V g_heff_2elocals_2ewalkF_24s754_lam3(V self, V *args) {
  V v_acc_24150 = args[0];
  V v_f_24151 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_24158;
  switch (heff_tag_of(v_f_24151)) {
  case TAG_At: {
    V v_x31_24152 = heff_field(v_f_24151, 0);
    heff_take(v_f_24151, 1ULL);
    switch (heff_tag_of(v_x31_24152)) {
    case TAG_SetField: {
      V v_e_24156 = heff_field(v_x31_24152, 2);
      heff_take(v_x31_24152, 4ULL);
      v_b_24158 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_e_24156));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24157 = heff_field(v_x31_24152, 0);
      heff_take(v_x31_24152, 1ULL);
      v_b_24158 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_e_24157));
      break;
    }
    default: heff_nomatch(v_x31_24152);
    }
    break;
  }
  default: heff_nomatch(v_f_24151);
  }
  V v_t_24159 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_24150), LBL_binders), heff_get(heff_dup(v_b_24158), LBL_binders)));
  V v_t_24160 = (g_prelude_2econcatList(heff_get(v_acc_24150, LBL_uses), heff_get(v_b_24158, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_24159, v_t_24160});
}
V g_heff_2elocals_2ewalkF_24s754_lam4(V self, V *args) {
  V v_acc_24164 = args[0];
  V v_a_24165 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_24175;
  switch (heff_tag_of(v_a_24165)) {
  case TAG_At: {
    V v_x31_24166 = heff_field(v_a_24165, 0);
    heff_take(v_a_24165, 1ULL);
    switch (heff_tag_of(v_x31_24166)) {
    case TAG_MkAlt: {
      V v_p_24168 = heff_field(v_x31_24166, 0);
      V v_r_24169 = heff_field(v_x31_24166, 1);
      heff_take(v_x31_24166, 3ULL);
      V v_bs_24170 = (g_heff_2elocals_2epatternBinders(v_p_24168));
      V v_env_24171 = (g_prelude_2efoldl_24s0(v_env_240, heff_dup(v_bs_24170)));
      V v_b_24172 = (g_heff_2elocals_2ewalkF_24s754(v_env_24171, v_r_24169));
      V v_t_24173 = (g_prelude_2econcatList(v_bs_24170, heff_get(heff_dup(v_b_24172), LBL_binders)));
      V v_t_24174 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_24172, LBL_uses)));
      v_b_24175 = heff_rec(2, shape_23_348, (V[]){v_t_24173, v_t_24174});
      break;
    }
    default: heff_nomatch(v_x31_24166);
    }
    break;
  }
  default: heff_nomatch(v_a_24165);
  }
  V v_t_24176 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_24164), LBL_binders), heff_get(heff_dup(v_b_24175), LBL_binders)));
  V v_t_24177 = (g_prelude_2econcatList(heff_get(v_acc_24164, LBL_uses), heff_get(v_b_24175, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_24176, v_t_24177});
}
V g_heff_2elocals_2earguments_lam0(V self, V *args);
Clo g_heff_2elocals_2earguments_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2earguments_entry, 3, 0};

V g_heff_2elocals_2earguments(V v_env_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return (g_prelude_2efoldl(heff_clo(g_heff_2elocals_2earguments_lam0, 2, 1, (V[]){v_env_240}), heff_dup(g_heff_2elocals_2enone_get()), v_rest_242));
  }
  case TAG_Cons: {
    V v_a_248 = heff_field(v_x2_241, 0);
    V v_tl_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse(v_x2_241, 3ULL);
    switch (heff_tag_of(v_a_248)) {
    case TAG_At: {
      V v_it1_2410 = heff_field(v_a_248, 0);
      V v_ru_24a_248_24At = heff_take_reuse(v_a_248, 1ULL);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_ExplicitParam: {
        V v_x_2412 = heff_field(v_it1_2410, 0);
        V v_sp_2413 = heff_field(v_it1_2410, 1);
        V v_t_2414 = heff_field(v_it1_2410, 2);
        heff_take(v_it1_2410, 7ULL);
        V v_a_2415 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_t_2414));
        V v_t_2416 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_2412), heff_dup(v_sp_2413), NTAG(TAG_False)});
        V v_b_2417 = (g_heff_2elocals_2earguments(heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2418 = heff_rec(3, shape_190_299_93, (V[]){v_x_2412, v_sp_2413, NTAG(TAG_False)});
        V v_t_2419 = heff_tag_at(v_ru_24a_248_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2econcatList(v_t_2419, heff_get(heff_dup(v_b_2417), LBL_binders)));
        V v_t_2421 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2417, LBL_uses)));
        V v_b_2422 = heff_rec(2, shape_23_348, (V[]){v_t_2420, v_t_2421});
        V v_t_2423 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2415), LBL_binders), heff_get(heff_dup(v_b_2422), LBL_binders)));
        V v_t_2424 = (g_prelude_2econcatList(heff_get(v_a_2415, LBL_uses), heff_get(v_b_2422, LBL_uses)));
        return heff_rec(2, shape_23_348, (V[]){v_t_2423, v_t_2424});
      }
      case TAG_ImplicitParam: {
        V v_x_2425 = heff_field(v_it1_2410, 0);
        V v_sp_2426 = heff_field(v_it1_2410, 1);
        V v_t_2427 = heff_field(v_it1_2410, 2);
        heff_take(v_it1_2410, 7ULL);
        V v_a_2428 = (g_heff_2elocals_2ewalkF_24s754(heff_dup(v_env_240), v_t_2427));
        V v_t_2429 = heff_rec(3, shape_190_299_93, (V[]){heff_dup(v_x_2425), heff_dup(v_sp_2426), NTAG(TAG_False)});
        V v_b_2430 = (g_heff_2elocals_2earguments(heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2429, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2431 = heff_rec(3, shape_190_299_93, (V[]){v_x_2425, v_sp_2426, NTAG(TAG_False)});
        V v_t_2432 = heff_tag_at(v_ru_24a_248_24At, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
        V v_t_2433 = (g_prelude_2econcatList(v_t_2432, heff_get(heff_dup(v_b_2430), LBL_binders)));
        V v_t_2434 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2430, LBL_uses)));
        V v_b_2435 = heff_rec(2, shape_23_348, (V[]){v_t_2433, v_t_2434});
        V v_t_2436 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_2428), LBL_binders), heff_get(heff_dup(v_b_2435), LBL_binders)));
        V v_t_2437 = (g_prelude_2econcatList(heff_get(v_a_2428, LBL_uses), heff_get(v_b_2435, LBL_uses)));
        return heff_rec(2, shape_23_348, (V[]){v_t_2436, v_t_2437});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_a_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elocals_2earguments_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2earguments(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2elocals_2earguments_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_env_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_b_245 = (g_heff_2elocals_2ewalkF_24s754(v_env_240, v_x_244));
  V v_t_246 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_243), LBL_binders), heff_get(heff_dup(v_b_245), LBL_binders)));
  V v_t_247 = (g_prelude_2econcatList(heff_get(v_acc_243, LBL_uses), heff_get(v_b_245, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_246, v_t_247});
}
Clo g_heff_2elocals_2eequationF_24s762_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eequationF_24s762_entry, 2, 0};

V g_heff_2elocals_2eequationF_24s762(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_prelude_2efoldl_24s752(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_prelude_2efoldl_24s0(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2elocals_2ewalkF_24s754(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2econcatList(v_bs_249, heff_get(heff_dup(v_b_2411), LBL_binders)));
      V v_t_2413 = (g_prelude_2econcatList(NTAG(TAG_Nil), heff_get(v_b_2411, LBL_uses)));
      return heff_rec(2, shape_23_348, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2eequationF_24s762_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2eequationF_24s762(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elocals_2edeclaration_lam0(V self, V *args);
Clo g_heff_2elocals_2edeclaration_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2edeclaration_entry, 1, 0};

V g_heff_2elocals_2edeclaration(V v_d_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_d_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_DeclEquations: {
    V v_ty_246 = heff_field(v_t_243, 2);
    V v_eqs_247 = heff_field(v_t_243, 3);
    heff_take(v_t_243, 12ULL);
    V v_a_248 = (g_heff_2elocals_2ewalkF_24s754(NTAG(TAG_Nil), heff_dup(v_ty_246)));
    V v_b_2416 = ({ V a_0 = heff_clo(g_heff_2elocals_2edeclaration_lam0, 2, 1, (V[]){v_ty_246}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_eqs_247; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_247); r_; });
    V v_t_2417 = (g_prelude_2econcatList(heff_get(heff_dup(v_a_248), LBL_binders), heff_get(heff_dup(v_b_2416), LBL_binders)));
    V v_t_2418 = (g_prelude_2econcatList(heff_get(v_a_248, LBL_uses), heff_get(v_b_2416, LBL_uses)));
    return heff_rec(2, shape_23_348, (V[]){v_t_2417, v_t_2418});
  }
  case TAG_DeclDefine: {
    V v_ps_2421 = heff_field(v_t_243, 2);
    V v_ty_2422 = heff_field(v_t_243, 3);
    V v_body_2423 = heff_field(v_t_243, 4);
    heff_take(v_t_243, 28ULL);
    V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){v_body_2423, NTAG(TAG_Nil)});
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2421; V b_2 = heff_tag(TAG_Cons, 2, (V[]){v_ty_2422, v_t_2424}); V r_ = (g_heff_2elocals_2earguments(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  }
  case TAG_DeclTheory: {
    V v_ps_2427 = heff_field(v_t_243, 2);
    V v_body_2428 = heff_field(v_t_243, 3);
    heff_take(v_t_243, 12ULL);
    V v_t_2429 = heff_tag(TAG_Cons, 2, (V[]){v_body_2428, NTAG(TAG_Nil)});
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2427; V a_2 = v_t_2429; V r_ = (g_heff_2elocals_2earguments(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
  }
  case TAG_DeclPrimitive: {
    V v_t_2432 = heff_field(v_t_243, 2);
    heff_take(v_t_243, 4ULL);
    return (g_heff_2elocals_2ewalkF_24s754(NTAG(TAG_Nil), v_t_2432));
  }
  case TAG_DeclTest: {
    heff_take(v_t_243, 0ULL);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_DeclWatch: {
    V v_e_2435 = heff_field(v_t_243, 0);
    heff_take(v_t_243, 1ULL);
    return (g_heff_2elocals_2ewalkF_24s754(NTAG(TAG_Nil), v_e_2435));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elocals_2edeclaration_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2edeclaration(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2elocals_2edeclaration_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_eq_2410 = args[1];
  V v_ty_246 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_bs_2411 = (g_heff_2elocals_2eimplicitsOf(v_ty_246));
  V v_t_2412 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_bs_2411));
  V v_b_2413 = ({ V a_0 = v_t_2412; V a_1 = v_eq_2410; V r_ = (g_heff_2elocals_2eequationF_24s762(a_0, a_1)); heff_drop(v_eq_2410); r_; });
  V v_t_2414 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_249), LBL_binders), heff_get(heff_dup(v_b_2413), LBL_binders)));
  V v_t_2415 = (g_prelude_2econcatList(heff_get(v_acc_249, LBL_uses), heff_get(v_b_2413, LBL_uses)));
  return heff_rec(2, shape_23_348, (V[]){v_t_2414, v_t_2415});
}
V g_heff_2elocals_2emkLocal_lam0(V self, V *args);
Clo g_heff_2elocals_2emkLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2emkLocal_entry, 2, 0};

V g_heff_2elocals_2emkLocal(V v_us_240, V v_b_241) {
top: ;
  V v_t_246 = (g_prelude_2efilter(heff_clo(g_heff_2elocals_2emkLocal_lam0, 1, 1, (V[]){heff_dup(v_b_241)}), v_us_240));
  V v_t_247 = (g_prelude_2emap_24s763(v_t_246));
  return heff_rec(3, shape_190_21_348, (V[]){heff_get(heff_dup(v_b_241), LBL_name), heff_get(v_b_241, LBL_span), v_t_247});
}
V g_heff_2elocals_2emkLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2emkLocal(a[0], a[1]);
}
V g_heff_2elocals_2emkLocal_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_b_241 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_a_243 = heff_get(heff_get(v_u_242, LBL_binder), LBL_span);
  V v_b_244 = heff_get(v_b_241, LBL_span);
  V v_t_245 = heff_intEq(heff_get(heff_dup(v_a_243), LBL_start), heff_get(heff_dup(v_b_244), LBL_start));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_t_245);
    return heff_intEq(heff_get(v_a_243, LBL_end), heff_get(v_b_244, LBL_end));
  }
  case TAG_False: {
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    heff_drop(v_t_245);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_245);
  }
}