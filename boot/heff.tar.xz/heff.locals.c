// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_ImplicitParam 51130
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_TagVariant 25174
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_name 9869138
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_use 325633
#define LBL_uses 10094739
static uint32_t shape_binder__use[] = {LBL_binder, LBL_use};
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_name__binder__uses[] = {LBL_name, LBL_binder, LBL_uses};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
V g_heff_2elocals_2earguments(V, V, V);
V g_heff_2elocals_2earguments_entry(V self, V *a);
extern Clo g_heff_2elocals_2earguments_clo;
V g_heff_2elocals_2edeclF_24s615879240x201238942(V, V);
V g_heff_2elocals_2edeclF_24s615879240x201238942_entry(V self, V *a);
extern Clo g_heff_2elocals_2edeclF_24s615879240x201238942_clo;
V g_heff_2elocals_2edeclaration(V);
V g_heff_2elocals_2edeclaration_entry(V self, V *a);
extern Clo g_heff_2elocals_2edeclaration_clo;
V g_heff_2elocals_2edoBlockF_24s1899446753x1868157201(V, V);
V g_heff_2elocals_2edoBlockF_24s1899446753x1868157201_entry(V self, V *a);
extern Clo g_heff_2elocals_2edoBlockF_24s1899446753x1868157201_clo;
V g_heff_2elocals_2eequationF_24s1332935439x1073426537(V, V);
V g_heff_2elocals_2eequationF_24s1332935439x1073426537_entry(V self, V *a);
extern Clo g_heff_2elocals_2eequationF_24s1332935439x1073426537_clo;
V g_heff_2elocals_2eequationF_24s390091567x1420489091(V, V);
V g_heff_2elocals_2eequationF_24s390091567x1420489091_entry(V self, V *a);
extern Clo g_heff_2elocals_2eequationF_24s390091567x1420489091_clo;
V g_heff_2elocals_2efindBinder(V, V);
V g_heff_2elocals_2efindBinder_entry(V self, V *a);
extern Clo g_heff_2elocals_2efindBinder_clo;
V g_heff_2elocals_2eimplicitsOf(V);
V g_heff_2elocals_2eimplicitsOf_entry(V self, V *a);
extern Clo g_heff_2elocals_2eimplicitsOf_clo;
V g_heff_2elocals_2elamBinders(V);
V g_heff_2elocals_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2elocals_2elamBinders_clo;
V g_heff_2elocals_2elocalDefF_24s26111392x1300443413(V, V);
V g_heff_2elocals_2elocalDefF_24s26111392x1300443413_entry(V self, V *a);
extern Clo g_heff_2elocals_2elocalDefF_24s26111392x1300443413_clo;
V g_heff_2elocals_2elocalsF_24s81954161x867360906(V, V, V);
V g_heff_2elocals_2elocalsF_24s81954161x867360906_entry(V self, V *a);
extern Clo g_heff_2elocals_2elocalsF_24s81954161x867360906_clo;
V g_heff_2elocals_2emkLocal(V, V);
V g_heff_2elocals_2emkLocal_entry(V self, V *a);
extern Clo g_heff_2elocals_2emkLocal_clo;
V g_heff_2elocals_2enone_get(void);
V g_heff_2elocals_2eparamWalk_24s517444469x1053557268(V, V);
V g_heff_2elocals_2eparamWalk_24s517444469x1053557268_entry(V self, V *a);
extern Clo g_heff_2elocals_2eparamWalk_24s517444469x1053557268_clo;
V g_heff_2elocals_2epatternBinders(V);
V g_heff_2elocals_2epatternBinders_entry(V self, V *a);
extern Clo g_heff_2elocals_2epatternBinders_clo;
V g_heff_2elocals_2esigBlockF_24s751838273x104610517(V, V);
V g_heff_2elocals_2esigBlockF_24s751838273x104610517_entry(V self, V *a);
extern Clo g_heff_2elocals_2esigBlockF_24s751838273x104610517_clo;
V g_heff_2elocals_2ewalkF_24s56081104x1956273806(V, V);
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_entry(V self, V *a);
extern Clo g_heff_2elocals_2ewalkF_24s56081104x1956273806_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1009481344x1999114184(V, V);
V g_list_2efoldl_24s1009481344x1999114184_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1009481344x1999114184_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2020645692x239769631(V, V);
V g_list_2efoldl_24s2020645692x239769631_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2020645692x239769631_clo;
V g_list_2emap_24s1282605757x1399508316(V);
V g_list_2emap_24s1282605757x1399508316_entry(V self, V *a);
extern Clo g_list_2emap_24s1282605757x1399508316_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;

static V g_heff_2elocals_2enone_val;
static int g_heff_2elocals_2enone_st;
static V g_heff_2elocals_2enone_init(void) {
  return heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2elocals_2enone_get(void) {
  if (g_heff_2elocals_2enone_st == 2) return g_heff_2elocals_2enone_val;
  if (g_heff_2elocals_2enone_st == 1) heff_fail("defined by itself");
  g_heff_2elocals_2enone_st = 1;
  g_heff_2elocals_2enone_val = heff_tr(g_heff_2elocals_2enone_init());
  g_heff_2elocals_2enone_st = 2;
  return g_heff_2elocals_2enone_val;
}
Clo g_heff_2elocals_2efindBinder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2efindBinder_entry, 2, 0};

V g_heff_2elocals_2efindBinder(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_get(heff_dup(v_b_242), LBL_name), heff_dup(v_x_240))) {
      heff_drop(v_x_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_b_242)});
    } else {
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elocals_2efindBinder_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2efindBinder(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elocals_2epatternBinders_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2elocals_2epatternBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2epatternBinders_entry, 1, 0};

V g_heff_2elocals_2epatternBinders(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_it1_241 = heff_field(v_p_240, 0);
    V v_sp_242 = heff_field(v_p_240, 1);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 3ULL, 2);
    switch (heff_tag_of(v_it1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_243), ((V)&g_heff_2elocals_2epatternBinders_str0))) {
        heff_drop(v_sp_242);
        heff_drop_cell(v_ru_24p_240_24At, 2);
        heff_drop(v_x_243);
        return NTAG(TAG_Nil);
      } else {
        V v_t_245 = heff_rec(3, shape_name__span__field, (V[]){v_x_243, v_sp_242, NTAG(TAG_False)});
        return heff_tag_at(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
      }
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 4ULL, 3);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_248));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s1009481344x1999114184(a_0, a_1)); heff_drop(v_t_249); r_; });
    }
    case TAG_PatOp: {
      V v_ps_2412 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 4ULL, 3);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2412));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2413; V r_ = (g_list_2efoldl_24s1009481344x1999114184(a_0, a_1)); heff_drop(v_t_2413); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2418 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2418));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s2020645692x239769631(a_0, a_1)); heff_drop(v_t_2419); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2421 = heff_field(v_it1_241, 0);
      V v_it12_2422 = heff_field(v_it1_241, 1);
      V v_q_2423 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 7ULL, 3);
      heff_drop(v_sp_242);
      V v_t_2424 = heff_rec(3, shape_name__span__field, (V[]){v_x_2421, v_it12_2422, NTAG(TAG_False)});
      return heff_tag_at(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_t_2424, (g_heff_2elocals_2epatternBinders(v_q_2423))});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2elocals_2epatternBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2epatternBinders(a[0]);
}
Clo g_heff_2elocals_2eimplicitsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eimplicitsOf_entry, 1, 0};

V g_heff_2elocals_2eimplicitsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      V v_x111_2416 = heff_field(v_x11_241, 0);
      V v_r_2417 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x111_2416)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2416, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_r_2417);
        return NTAG(TAG_Nil);
      }
      case TAG_PiImplicit: {
        V v_x_2421 = heff_field(v_x111_2416, 0);
        V v_sp_2422 = heff_field(v_x111_2416, 1);
        heff_take_n(v_x111_2416, 3ULL, 5);
        V v_t_2426 = heff_rec(3, shape_name__span__field, (V[]){v_x_2421, v_sp_2422, NTAG(TAG_False)});
        return heff_tag_at(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2426, (g_heff_2elocals_2eimplicitsOf(v_r_2417))});
      }
      case TAG_PiInstance: {
        V v_x_2427 = heff_field(v_x111_2416, 0);
        V v_sp_2428 = heff_field(v_x111_2416, 1);
        heff_take_n(v_x111_2416, 3ULL, 4);
        V v_t_2431 = heff_rec(3, shape_name__span__field, (V[]){v_x_2427, v_sp_2428, NTAG(TAG_False)});
        return heff_tag_at(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2431, (g_heff_2elocals_2eimplicitsOf(v_r_2417))});
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2416, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24At, 2);
        heff_drop(v_r_2417);
        return NTAG(TAG_Nil);
      }
      default: return heff_nomatch(v_x111_2416);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elocals_2eimplicitsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2eimplicitsOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elocals_2elamBinders_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elocals_2elamBinders_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2elocals_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2elamBinders_entry, 1, 0};

V g_heff_2elocals_2elamBinders(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_LamName: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamName = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_241), ((V)&g_heff_2elocals_2elamBinders_str0))) {
      heff_drop(v_x_241);
      heff_drop(v_sp_242);
      heff_drop_cell(v_ru_24x1_240_24LamName, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_244 = heff_rec(3, shape_name__span__field, (V[]){v_x_241, v_sp_242, NTAG(TAG_False)});
      return heff_tag_at(v_ru_24x1_240_24LamName, TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamImplicit: {
    V v_x_245 = heff_field(v_x1_240, 0);
    V v_sp_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24LamImplicit = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_245), ((V)&g_heff_2elocals_2elamBinders_str1))) {
      heff_drop(v_x_245);
      heff_drop(v_sp_246);
      heff_drop_cell(v_ru_24x1_240_24LamImplicit, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_248 = heff_rec(3, shape_name__span__field, (V[]){v_x_245, v_sp_246, NTAG(TAG_False)});
      return heff_tag_at(v_ru_24x1_240_24LamImplicit, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    }
  }
  case TAG_LamAnn: {
    V v_x_249 = heff_field(v_x1_240, 0);
    V v_sp_2410 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 3);
    V v_t_2412 = heff_rec(3, shape_name__span__field, (V[]){v_x_249, v_sp_2410, NTAG(TAG_False)});
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elocals_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2elamBinders(a[0]);
}
Clo g_heff_2elocals_2esigBlockF_24s751838273x104610517_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2esigBlockF_24s751838273x104610517_entry, 2, 0};

V g_heff_2elocals_2esigBlockF_24s751838273x104610517(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_DeclareField: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_a_248 = heff_field(v_x311_244, 2);
        V v_d_249 = heff_field(v_x311_244, 3);
        heff_take_n(v_x311_244, 15ULL, 4);
        V v_a_2410 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_a_248));
        V v_b_2412;
        switch (heff_tag_of(v_d_249)) {
        case TAG_Nothing: {
          v_b_2412 = heff_dup(g_heff_2elocals_2enone_get());
          break;
        }
        case TAG_Just: {
          V v_x_2411 = heff_field(v_d_249, 0);
          heff_take_n(v_d_249, 1ULL, 1);
          v_b_2412 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_x_2411));
          break;
        }
        default: heff_nomatch(v_d_249);
        }
        V v_t_2413 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2410), LBL_binders), heff_get(heff_dup(v_b_2412), LBL_binders)));
        V v_t_2414 = (g_prelude_2e_2b_2b(heff_get(v_a_2410, LBL_uses), heff_get(v_b_2412, LBL_uses)));
        V v_a_2415 = heff_rec(2, shape_binders__uses, (V[]){v_t_2413, v_t_2414});
        V v_t_2416 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_True)});
        V v_b_2417 = (g_heff_2elocals_2esigBlockF_24s751838273x104610517(heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_env_240}), v_rest_243));
        V v_t_2418 = heff_rec(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_True)});
        V v_t_2419 = heff_tag_at(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, heff_get(heff_dup(v_b_2417), LBL_binders)));
        V v_t_2421 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2417, LBL_uses)));
        V v_b_2422 = heff_rec(2, shape_binders__uses, (V[]){v_t_2420, v_t_2421});
        V v_t_2423 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2415), LBL_binders), heff_get(heff_dup(v_b_2422), LBL_binders)));
        V v_t_2424 = (g_prelude_2e_2b_2b(heff_get(v_a_2415, LBL_uses), heff_get(v_b_2422, LBL_uses)));
        return heff_rec(2, shape_binders__uses, (V[]){v_t_2423, v_t_2424});
      }
      case TAG_BadFieldDecl: {
        V v_f_2425 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2426 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_f_2425));
        V v_b_2427 = (g_heff_2elocals_2esigBlockF_24s751838273x104610517(v_env_240, v_rest_243));
        V v_t_2428 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2426), LBL_binders), heff_get(heff_dup(v_b_2427), LBL_binders)));
        V v_t_2429 = (g_prelude_2e_2b_2b(heff_get(v_a_2426, LBL_uses), heff_get(v_b_2427, LBL_uses)));
        return heff_rec(2, shape_binders__uses, (V[]){v_t_2428, v_t_2429});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2esigBlockF_24s751838273x104610517_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2esigBlockF_24s751838273x104610517(a[0], a[1]);
}
Clo g_heff_2elocals_2edoBlockF_24s1899446753x1868157201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2edoBlockF_24s1899446753x1868157201_entry, 2, 0};

V g_heff_2elocals_2edoBlockF_24s1899446753x1868157201(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_env_240);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_Cons: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_rest_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_At: {
      V v_x311_244 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24At = heff_take_reuse_n(v_x31_242, 1ULL, 2);
      switch (heff_tag_of(v_x311_244)) {
      case TAG_StmtBind: {
        V v_x_246 = heff_field(v_x311_244, 0);
        V v_sp_247 = heff_field(v_x311_244, 1);
        V v_e_248 = heff_field(v_x311_244, 2);
        heff_take_n(v_x311_244, 7ULL, 3);
        V v_a_249 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_e_248));
        V v_t_2410 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_246), heff_dup(v_sp_247), NTAG(TAG_False)});
        V v_b_2411 = (g_heff_2elocals_2edoBlockF_24s1899446753x1868157201(heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_env_240}), v_rest_243));
        V v_t_2412 = heff_rec(3, shape_name__span__field, (V[]){v_x_246, v_sp_247, NTAG(TAG_False)});
        V v_t_2413 = heff_tag_at(v_ru_24x31_242_24At, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_get(heff_dup(v_b_2411), LBL_binders)));
        V v_t_2415 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2411, LBL_uses)));
        V v_b_2416 = heff_rec(2, shape_binders__uses, (V[]){v_t_2414, v_t_2415});
        V v_t_2417 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_249), LBL_binders), heff_get(heff_dup(v_b_2416), LBL_binders)));
        V v_t_2418 = (g_prelude_2e_2b_2b(heff_get(v_a_249, LBL_uses), heff_get(v_b_2416, LBL_uses)));
        return heff_rec(2, shape_binders__uses, (V[]){v_t_2417, v_t_2418});
      }
      case TAG_StmtLet: {
        V v_p_2419 = heff_field(v_x311_244, 0);
        V v_e_2420 = heff_field(v_x311_244, 1);
        heff_take_n(v_x311_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2421 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_e_2420));
        V v_bs_2422 = (g_heff_2elocals_2epatternBinders(heff_dup(v_p_2419)));
        V v_a_2423 = heff_rec(2, shape_binders__uses, (V[]){v_bs_2422, NTAG(TAG_Nil)});
        V v_bs_2424 = (g_heff_2elocals_2epatternBinders(v_p_2419));
        V v_env_2425 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2424));
        V v_b_2426 = (g_heff_2elocals_2edoBlockF_24s1899446753x1868157201(v_env_2425, v_rest_243));
        V v_t_2427 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2423), LBL_binders), heff_get(heff_dup(v_b_2426), LBL_binders)));
        V v_t_2428 = (g_prelude_2e_2b_2b(heff_get(v_a_2423, LBL_uses), heff_get(v_b_2426, LBL_uses)));
        V v_b_2429 = heff_rec(2, shape_binders__uses, (V[]){v_t_2427, v_t_2428});
        V v_t_2430 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2421), LBL_binders), heff_get(heff_dup(v_b_2429), LBL_binders)));
        V v_t_2431 = (g_prelude_2e_2b_2b(heff_get(v_a_2421, LBL_uses), heff_get(v_b_2429, LBL_uses)));
        return heff_rec(2, shape_binders__uses, (V[]){v_t_2430, v_t_2431});
      }
      case TAG_StmtExpr: {
        V v_e_2432 = heff_field(v_x311_244, 0);
        heff_take_n(v_x311_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop_cell(v_ru_24x31_242_24At, 2);
        V v_a_2433 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_e_2432));
        V v_b_2434 = (g_heff_2elocals_2edoBlockF_24s1899446753x1868157201(v_env_240, v_rest_243));
        V v_t_2435 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2433), LBL_binders), heff_get(heff_dup(v_b_2434), LBL_binders)));
        V v_t_2436 = (g_prelude_2e_2b_2b(heff_get(v_a_2433, LBL_uses), heff_get(v_b_2434, LBL_uses)));
        return heff_rec(2, shape_binders__uses, (V[]){v_t_2435, v_t_2436});
      }
      default: return heff_nomatch(v_x311_244);
      }
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2edoBlockF_24s1899446753x1868157201_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2edoBlockF_24s1899446753x1868157201(a[0], a[1]);
}
Clo g_heff_2elocals_2eequationF_24s1332935439x1073426537_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eequationF_24s1332935439x1073426537_entry, 2, 0};

V g_heff_2elocals_2eequationF_24s1332935439x1073426537(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1009481344x1999114184(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_get(heff_dup(v_b_2411), LBL_binders)));
      V v_t_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2411, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2eequationF_24s1332935439x1073426537_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2eequationF_24s1332935439x1073426537(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2elocals_2eparamWalk_24s517444469x1053557268_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eparamWalk_24s517444469x1053557268_entry, 2, 0};

V g_heff_2elocals_2eparamWalk_24s517444469x1053557268(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 1ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_t_246 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_247 = (g_heff_2elocals_2efindBinder(v_x_244, v_env_240));
      V v_a_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_245);
        v_a_2410 = heff_dup(g_heff_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_249 = heff_tag_at(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_248, v_xsp_245}), NTAG(TAG_Nil)});
        v_a_2410 = heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_249});
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_b_2411 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_t_246));
      V v_t_2412 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2410), LBL_binders), heff_get(heff_dup(v_b_2411), LBL_binders)));
      V v_t_2413 = (g_prelude_2e_2b_2b(heff_get(v_a_2410, LBL_uses), heff_get(v_b_2411, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x31_242, 0);
      V v_xsp_2415 = heff_field(v_x31_242, 1);
      V v_t_2416 = heff_field(v_x31_242, 2);
      heff_take_n(v_x31_242, 7ULL, 3);
      V v_t_2417 = (g_heff_2elocals_2efindBinder(v_x_2414, v_env_240));
      V v_a_2420;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop(v_xsp_2415);
        v_a_2420 = heff_dup(g_heff_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2418 = heff_field(v_t_2417, 0);
        heff_take_n(v_t_2417, 1ULL, 1);
        V v_t_2419 = heff_tag_at(v_ru_24x3_241_24At, TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_2418, v_xsp_2415}), NTAG(TAG_Nil)});
        v_a_2420 = heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2419});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      V v_b_2421 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_t_2416));
      V v_t_2422 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2420), LBL_binders), heff_get(heff_dup(v_b_2421), LBL_binders)));
      V v_t_2423 = (g_prelude_2e_2b_2b(heff_get(v_a_2420, LBL_uses), heff_get(v_b_2421, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2422, v_t_2423});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2eparamWalk_24s517444469x1053557268_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2eparamWalk_24s517444469x1053557268(a[0], a[1]);
}
V g_heff_2elocals_2edeclF_24s615879240x201238942_lam0(V self, V *args);
V g_heff_2elocals_2edeclF_24s615879240x201238942_lam1(V self, V *args);
Clo g_heff_2elocals_2edeclF_24s615879240x201238942_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2edeclF_24s615879240x201238942_entry, 2, 0};

V g_heff_2elocals_2edeclF_24s615879240x201238942(V v_env_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_f_245 = heff_field(v_t_244, 0);
    V v_fsp_246 = heff_field(v_t_244, 1);
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 15ULL, 4);
    V v_t_249 = (g_heff_2elocals_2efindBinder(v_f_245, v_env_240));
    V v_a_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_fsp_246);
      v_a_2412 = heff_dup(g_heff_2elocals_2enone_get());
      break;
    }
    case TAG_Just: {
      V v_b_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_2410, v_fsp_246}), NTAG(TAG_Nil)});
      v_a_2412 = heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2411});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_a_2413 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_ty_247));
    V v_b_2419 = ({ V a_0 = heff_clo(g_heff_2elocals_2edeclF_24s615879240x201238942_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
    V v_t_2420 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2413), LBL_binders), heff_get(heff_dup(v_b_2419), LBL_binders)));
    V v_t_2421 = (g_prelude_2e_2b_2b(heff_get(v_a_2413, LBL_uses), heff_get(v_b_2419, LBL_uses)));
    V v_b_2422 = heff_rec(2, shape_binders__uses, (V[]){v_t_2420, v_t_2421});
    V v_t_2423 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2412), LBL_binders), heff_get(heff_dup(v_b_2422), LBL_binders)));
    V v_t_2424 = (g_prelude_2e_2b_2b(heff_get(v_a_2412, LBL_uses), heff_get(v_b_2422, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_2423, v_t_2424});
  }
  case TAG_DeclDefine: {
    V v_x_2425 = heff_field(v_t_244, 0);
    V v_xsp_2426 = heff_field(v_t_244, 1);
    V v_ps_2427 = heff_field(v_t_244, 2);
    V v_u_2428 = heff_field(v_t_244, 3);
    V v_body_2429 = heff_field(v_t_244, 4);
    heff_take_n(v_t_244, 31ULL, 5);
    V v_t_2430 = (g_heff_2elocals_2efindBinder(v_x_2425, v_env_240));
    V v_a_2433;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Nothing: {
      heff_drop(v_xsp_2426);
      v_a_2433 = heff_dup(g_heff_2elocals_2enone_get());
      break;
    }
    case TAG_Just: {
      V v_b_2431 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_2431, v_xsp_2426}), NTAG(TAG_Nil)});
      v_a_2433 = heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2432});
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    V v_a_2439 = ({ V a_0 = heff_clo(g_heff_2elocals_2edeclF_24s615879240x201238942_lam1, 2, 1, (V[]){heff_dup(v_env_240)}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_ps_2427; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_ps_2427); r_; });
    V v_a_2440 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_u_2428));
    V v_b_2441 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_body_2429));
    V v_t_2442 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2440), LBL_binders), heff_get(heff_dup(v_b_2441), LBL_binders)));
    V v_t_2443 = (g_prelude_2e_2b_2b(heff_get(v_a_2440, LBL_uses), heff_get(v_b_2441, LBL_uses)));
    V v_b_2444 = heff_rec(2, shape_binders__uses, (V[]){v_t_2442, v_t_2443});
    V v_t_2445 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2439), LBL_binders), heff_get(heff_dup(v_b_2444), LBL_binders)));
    V v_t_2446 = (g_prelude_2e_2b_2b(heff_get(v_a_2439, LBL_uses), heff_get(v_b_2444, LBL_uses)));
    V v_b_2447 = heff_rec(2, shape_binders__uses, (V[]){v_t_2445, v_t_2446});
    V v_t_2448 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2433), LBL_binders), heff_get(heff_dup(v_b_2447), LBL_binders)));
    V v_t_2449 = (g_prelude_2e_2b_2b(heff_get(v_a_2433, LBL_uses), heff_get(v_b_2447, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_2448, v_t_2449});
  }
  case TAG_DeclTheory: {
    V v_body_2453 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 8ULL, 4);
    HEFF_LAST return g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_body_2453);
  }
  case TAG_DeclPrimitive: {
    V v_x_2454 = heff_field(v_t_244, 0);
    V v_xsp_2455 = heff_field(v_t_244, 1);
    V v_t_2456 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 7ULL, 3);
    V v_t_2457 = (g_heff_2elocals_2efindBinder(v_x_2454, v_env_240));
    V v_a_2460;
    switch (heff_tag_of(v_t_2457)) {
    case TAG_Nothing: {
      heff_drop(v_xsp_2455);
      v_a_2460 = heff_dup(g_heff_2elocals_2enone_get());
      break;
    }
    case TAG_Just: {
      V v_b_2458 = heff_field(v_t_2457, 0);
      heff_take_n(v_t_2457, 1ULL, 1);
      V v_t_2459 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_2458, v_xsp_2455}), NTAG(TAG_Nil)});
      v_a_2460 = heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2459});
      break;
    }
    default: heff_nomatch(v_t_2457);
    }
    V v_b_2461 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_t_2456));
    V v_t_2462 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2460), LBL_binders), heff_get(heff_dup(v_b_2461), LBL_binders)));
    V v_t_2463 = (g_prelude_2e_2b_2b(heff_get(v_a_2460, LBL_uses), heff_get(v_b_2461, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_2462, v_t_2463});
  }
  case TAG_DeclTest: {
    V v_x_2464 = heff_field(v_t_244, 0);
    V v_xsp_2465 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24DeclTest = heff_take_reuse_n(v_t_244, 3ULL, 2);
    V v_t_2466 = ({ V a_0 = v_x_2464; V a_1 = v_env_240; V r_ = (g_heff_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
    switch (heff_tag_of(v_t_2466)) {
    case TAG_Nothing: {
      heff_drop(v_xsp_2465);
      heff_drop_cell(v_ru_24t_244_24DeclTest, 2);
      return heff_dup(g_heff_2elocals_2enone_get());
    }
    case TAG_Just: {
      V v_b_2467 = heff_field(v_t_2466, 0);
      heff_take_n(v_t_2466, 1ULL, 1);
      V v_t_2468 = heff_tag_at(v_ru_24t_244_24DeclTest, TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_2467, v_xsp_2465}), NTAG(TAG_Nil)});
      return heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2468});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_DeclWatch: {
    V v_e_2469 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    HEFF_LAST return g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_e_2469);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elocals_2edeclF_24s615879240x201238942_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2edeclF_24s615879240x201238942(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elocals_2edeclF_24s615879240x201238942_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_eq_2415 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2416 = ({ V a_0 = v_env_240; V a_1 = v_eq_2415; V r_ = (g_heff_2elocals_2eequationF_24s1332935439x1073426537(a_0, a_1)); heff_drop(v_eq_2415); r_; });
  V v_t_2417 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_2414), LBL_binders), heff_get(heff_dup(v_b_2416), LBL_binders)));
  V v_t_2418 = (g_prelude_2e_2b_2b(heff_get(v_acc_2414, LBL_uses), heff_get(v_b_2416, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_2417, v_t_2418});
}
V g_heff_2elocals_2edeclF_24s615879240x201238942_lam1(V self, V *args) {
  V v_acc_2434 = args[0];
  V v_m_2435 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2436 = (g_heff_2elocals_2eparamWalk_24s517444469x1053557268(v_env_240, v_m_2435));
  V v_t_2437 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_2434), LBL_binders), heff_get(heff_dup(v_b_2436), LBL_binders)));
  V v_t_2438 = (g_prelude_2e_2b_2b(heff_get(v_acc_2434, LBL_uses), heff_get(v_b_2436, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_2437, v_t_2438});
}
V g_heff_2elocals_2elocalDefF_24s26111392x1300443413_lam0(V self, V *args);
Clo g_heff_2elocals_2elocalDefF_24s26111392x1300443413_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2elocalDefF_24s26111392x1300443413_entry, 2, 0};

V g_heff_2elocals_2elocalDefF_24s26111392x1300443413(V v_env_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 12ULL, 4);
    V v_a_249 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), heff_dup(v_ty_247)));
    V v_b_2430 = ({ V a_0 = heff_clo(g_heff_2elocals_2elocalDefF_24s26111392x1300443413_lam0, 2, 2, (V[]){v_env_240, v_ty_247}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_eqs_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_248); r_; });
    V v_t_2431 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_249), LBL_binders), heff_get(heff_dup(v_b_2430), LBL_binders)));
    V v_t_2432 = (g_prelude_2e_2b_2b(heff_get(v_a_249, LBL_uses), heff_get(v_b_2430, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_2431, v_t_2432});
  }
  case TAG_DeclDefine: {
    heff_take_n(v_t_244, 0ULL, 5);
    HEFF_LAST return g_heff_2elocals_2edeclF_24s615879240x201238942(v_env_240, v_d_241);
  }
  case TAG_DeclTheory: {
    heff_take_n(v_t_244, 0ULL, 4);
    HEFF_LAST return g_heff_2elocals_2edeclF_24s615879240x201238942(v_env_240, v_d_241);
  }
  case TAG_DeclPrimitive: {
    heff_take_n(v_t_244, 0ULL, 3);
    HEFF_LAST return g_heff_2elocals_2edeclF_24s615879240x201238942(v_env_240, v_d_241);
  }
  case TAG_DeclTest: {
    heff_take_n(v_t_244, 0ULL, 2);
    HEFF_LAST return g_heff_2elocals_2edeclF_24s615879240x201238942(v_env_240, v_d_241);
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_244, 0ULL, 1);
    HEFF_LAST return g_heff_2elocals_2edeclF_24s615879240x201238942(v_env_240, v_d_241);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2elocals_2elocalDefF_24s26111392x1300443413_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2elocalDefF_24s26111392x1300443413(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elocals_2elocalDefF_24s26111392x1300443413_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_eq_2411 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ty_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2421;
  switch (heff_tag_of(v_eq_2411)) {
  case TAG_At: {
    V v_x21_2412 = heff_dup(heff_field(v_eq_2411, 0));
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_fsp_2415 = heff_field(v_x21_2412, 1);
      heff_take_n(v_x21_2412, 3ULL, 4);
      V v_t_2418 = (g_heff_2elocals_2efindBinder(v_f_2414, v_env_240));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        heff_drop(v_fsp_2415);
        v_a_2421 = heff_dup(g_heff_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_b_2419 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_2419, v_fsp_2415}), NTAG(TAG_Nil)});
        v_a_2421 = heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2420});
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      break;
    }
    default: heff_nomatch(v_x21_2412);
    }
    break;
  }
  default: heff_nomatch(v_eq_2411);
  }
  V v_bs_2422 = (g_heff_2elocals_2eimplicitsOf(v_ty_247));
  V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2422));
  V v_b_2424 = ({ V a_0 = v_t_2423; V a_1 = v_eq_2411; V r_ = (g_heff_2elocals_2eequationF_24s1332935439x1073426537(a_0, a_1)); heff_drop(v_eq_2411); r_; });
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2421), LBL_binders), heff_get(heff_dup(v_b_2424), LBL_binders)));
  V v_t_2426 = (g_prelude_2e_2b_2b(heff_get(v_a_2421, LBL_uses), heff_get(v_b_2424, LBL_uses)));
  V v_b_2427 = heff_rec(2, shape_binders__uses, (V[]){v_t_2425, v_t_2426});
  V v_t_2428 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_2410), LBL_binders), heff_get(heff_dup(v_b_2427), LBL_binders)));
  V v_t_2429 = (g_prelude_2e_2b_2b(heff_get(v_acc_2410, LBL_uses), heff_get(v_b_2427, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_2428, v_t_2429});
}
Clo g_heff_2elocals_2elocalsF_24s81954161x867360906_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2elocalsF_24s81954161x867360906_entry, 3, 0};

V g_heff_2elocals_2elocalsF_24s81954161x867360906(V v_env_240, V v_x3_241, V v_body_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_body_242));
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x3_241, 0);
    V v_ds_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_x_245 = heff_dup(heff_field(v_d_243, 0));
      v_t_247 = v_x_245;
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_bs_2428;
    switch (heff_tag_of(v_t_247)) {
    case TAG_DeclEquations: {
      V v_f_248 = heff_field(v_t_247, 0);
      V v_fsp_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 4);
      V v_t_2412 = heff_rec(3, shape_name__span__field, (V[]){v_f_248, v_fsp_249, NTAG(TAG_False)});
      v_bs_2428 = heff_tag_at(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_247, 0ULL, 5);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_247, 0ULL, 4);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_247, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      v_bs_2428 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_a_2429 = heff_rec(2, shape_binders__uses, (V[]){v_bs_2428, NTAG(TAG_Nil)});
    V v_t_2432;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_x_2430 = heff_dup(heff_field(v_d_243, 0));
      v_t_2432 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_bs_2453;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_DeclEquations: {
      V v_f_2433 = heff_field(v_t_2432, 0);
      V v_fsp_2434 = heff_field(v_t_2432, 1);
      heff_take_n(v_t_2432, 3ULL, 4);
      V v_t_2437 = heff_rec(3, shape_name__span__field, (V[]){v_f_2433, v_fsp_2434, NTAG(TAG_False)});
      v_bs_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_2432, 0ULL, 5);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_2432, 0ULL, 4);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_2432, 0ULL, 3);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_2432, 0ULL, 2);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_2432, 0ULL, 1);
      v_bs_2453 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(heff_dup(v_env_240), v_bs_2453));
    V v_a_2455 = (g_heff_2elocals_2elocalDefF_24s26111392x1300443413(v_t_2454, v_d_243));
    V v_t_2458;
    switch (heff_tag_of(v_d_243)) {
    case TAG_At: {
      V v_x_2456 = heff_field(v_d_243, 0);
      heff_take_n(v_d_243, 1ULL, 2);
      v_t_2458 = v_x_2456;
      break;
    }
    default: heff_nomatch(v_d_243);
    }
    V v_bs_2479;
    switch (heff_tag_of(v_t_2458)) {
    case TAG_DeclEquations: {
      V v_f_2459 = heff_field(v_t_2458, 0);
      V v_fsp_2460 = heff_field(v_t_2458, 1);
      heff_take_n(v_t_2458, 3ULL, 4);
      V v_t_2463 = heff_rec(3, shape_name__span__field, (V[]){v_f_2459, v_fsp_2460, NTAG(TAG_False)});
      v_bs_2479 = heff_tag(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_2458, 0ULL, 5);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_2458, 0ULL, 4);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_2458, 0ULL, 3);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_2458, 0ULL, 2);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_2458, 0ULL, 1);
      v_bs_2479 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2458);
    }
    V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_bs_2479));
    V v_b_2481 = (g_heff_2elocals_2elocalsF_24s81954161x867360906(v_t_2480, v_ds_244, v_body_242));
    V v_t_2482 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2455), LBL_binders), heff_get(heff_dup(v_b_2481), LBL_binders)));
    V v_t_2483 = (g_prelude_2e_2b_2b(heff_get(v_a_2455, LBL_uses), heff_get(v_b_2481, LBL_uses)));
    V v_b_2484 = heff_rec(2, shape_binders__uses, (V[]){v_t_2482, v_t_2483});
    V v_t_2485 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2429), LBL_binders), heff_get(heff_dup(v_b_2484), LBL_binders)));
    V v_t_2486 = (g_prelude_2e_2b_2b(heff_get(v_a_2429, LBL_uses), heff_get(v_b_2484, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_2485, v_t_2486});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2elocalsF_24s81954161x867360906_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2elocalsF_24s81954161x867360906(a[0], a[1], a[2]);
}
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam0(V self, V *args);
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam2(V self, V *args);
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam1(V self, V *args);
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam3(V self, V *args);
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam4(V self, V *args);
Clo g_heff_2elocals_2ewalkF_24s56081104x1956273806_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2ewalkF_24s56081104x1956273806_entry, 2, 0};

V g_heff_2elocals_2ewalkF_24s56081104x1956273806(V v_env_240, V v_n_241) {
top: ;
  V v_it_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_dup(heff_field(v_n_241, 0));
    v_it_244 = v_x_242;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_it_244)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_sp_248;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_247 = heff_field(v_n_241, 1);
      heff_take_n(v_n_241, 2ULL, 2);
      v_sp_248 = v_s_247;
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_t_249 = ({ V a_0 = v_x_245; V a_1 = v_env_240; V r_ = (g_heff_2elocals_2efindBinder(a_0, a_1)); heff_drop(v_env_240); r_; });
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_sp_248);
      return heff_dup(g_heff_2elocals_2enone_get());
    }
    case TAG_Just: {
      V v_b_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_rec(2, shape_binder__use, (V[]){v_b_2410, v_sp_248}), NTAG(TAG_Nil)});
      return heff_rec(2, shape_binders__uses, (V[]){NTAG(TAG_Nil), v_t_2411});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_EImplicitVar: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_ETag: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EInt: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EFloat: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EString: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_ERune: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EWord: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_EApp: {
    V v_h_2419 = heff_field(v_it_244, 0);
    V v_args_2420 = heff_field(v_it_244, 1);
    heff_take_n(v_it_244, 3ULL, 2);
    heff_drop(v_n_241);
    V v_a_2421 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_h_2419));
    V v_b_2427 = ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam0, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_args_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_2420); r_; });
    V v_t_2428 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2421), LBL_binders), heff_get(heff_dup(v_b_2427), LBL_binders)));
    V v_t_2429 = (g_prelude_2e_2b_2b(heff_get(v_a_2421, LBL_uses), heff_get(v_b_2427, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_2428, v_t_2429});
  }
  case TAG_EProject: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_ENamed: {
    V v_e_2432 = heff_field(v_it_244, 1);
    heff_take_n(v_it_244, 2ULL, 2);
    heff_drop(v_n_241);
    V t_0 = v_env_240;
    V t_1 = v_e_2432;
    v_env_240 = t_0;
    v_n_241 = t_1;
    goto top;
  }
  case TAG_EPi: {
    V v_it1_2433 = heff_field(v_it_244, 0);
    V v_r_2434 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EPi = heff_take_reuse_n(v_it_244, 3ULL, 2);
    heff_drop(v_n_241);
    switch (heff_tag_of(v_it1_2433)) {
    case TAG_PiNamed: {
      V v_x_2435 = heff_field(v_it1_2433, 0);
      V v_sp_2436 = heff_field(v_it1_2433, 1);
      V v_a_2437 = heff_field(v_it1_2433, 2);
      heff_take_n(v_it1_2433, 7ULL, 3);
      V v_a_2438 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_a_2437));
      V v_t_2439 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_2435), heff_dup(v_sp_2436), NTAG(TAG_False)});
      V v_t_2440 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
      V v_env_2441 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2440));
      V v_b_2442 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_2441, v_r_2434));
      V v_t_2443 = heff_rec(3, shape_name__span__field, (V[]){v_x_2435, v_sp_2436, NTAG(TAG_False)});
      V v_t_2444 = heff_tag(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
      V v_t_2445 = (g_prelude_2e_2b_2b(v_t_2444, heff_get(heff_dup(v_b_2442), LBL_binders)));
      V v_t_2446 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2442, LBL_uses)));
      V v_b_2447 = heff_rec(2, shape_binders__uses, (V[]){v_t_2445, v_t_2446});
      V v_t_2448 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2438), LBL_binders), heff_get(heff_dup(v_b_2447), LBL_binders)));
      V v_t_2449 = (g_prelude_2e_2b_2b(heff_get(v_a_2438, LBL_uses), heff_get(v_b_2447, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2448, v_t_2449});
    }
    case TAG_PiImplicit: {
      V v_x_2450 = heff_field(v_it1_2433, 0);
      V v_sp_2451 = heff_field(v_it1_2433, 1);
      V v_a_2453 = heff_field(v_it1_2433, 3);
      V v_d_2454 = heff_field(v_it1_2433, 4);
      heff_take_n(v_it1_2433, 27ULL, 5);
      V v_a_2455 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_a_2453));
      V v_b_2457;
      switch (heff_tag_of(v_d_2454)) {
      case TAG_Nothing: {
        v_b_2457 = heff_dup(g_heff_2elocals_2enone_get());
        break;
      }
      case TAG_Just: {
        V v_x_2456 = heff_field(v_d_2454, 0);
        heff_take_n(v_d_2454, 1ULL, 1);
        v_b_2457 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_x_2456));
        break;
      }
      default: heff_nomatch(v_d_2454);
      }
      V v_t_2458 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2455), LBL_binders), heff_get(heff_dup(v_b_2457), LBL_binders)));
      V v_t_2459 = (g_prelude_2e_2b_2b(heff_get(v_a_2455, LBL_uses), heff_get(v_b_2457, LBL_uses)));
      V v_a_2460 = heff_rec(2, shape_binders__uses, (V[]){v_t_2458, v_t_2459});
      V v_t_2461 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_2450), heff_dup(v_sp_2451), NTAG(TAG_False)});
      V v_t_2462 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
      V v_env_2463 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2462));
      V v_b_2464 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_2463, v_r_2434));
      V v_t_2465 = heff_rec(3, shape_name__span__field, (V[]){v_x_2450, v_sp_2451, NTAG(TAG_False)});
      V v_t_2466 = heff_tag(TAG_Cons, 2, (V[]){v_t_2465, NTAG(TAG_Nil)});
      V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2466, heff_get(heff_dup(v_b_2464), LBL_binders)));
      V v_t_2468 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2464, LBL_uses)));
      V v_b_2469 = heff_rec(2, shape_binders__uses, (V[]){v_t_2467, v_t_2468});
      V v_t_2470 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2460), LBL_binders), heff_get(heff_dup(v_b_2469), LBL_binders)));
      V v_t_2471 = (g_prelude_2e_2b_2b(heff_get(v_a_2460, LBL_uses), heff_get(v_b_2469, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2470, v_t_2471});
    }
    case TAG_PiInstance: {
      V v_x_2472 = heff_field(v_it1_2433, 0);
      V v_sp_2473 = heff_field(v_it1_2433, 1);
      V v_a_2475 = heff_field(v_it1_2433, 3);
      heff_take_n(v_it1_2433, 11ULL, 4);
      V v_a_2476 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_a_2475));
      V v_t_2477 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_2472), heff_dup(v_sp_2473), NTAG(TAG_False)});
      V v_t_2478 = heff_tag_at(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
      V v_env_2479 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_2478));
      V v_b_2480 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_2479, v_r_2434));
      V v_t_2481 = heff_rec(3, shape_name__span__field, (V[]){v_x_2472, v_sp_2473, NTAG(TAG_False)});
      V v_t_2482 = heff_tag(TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
      V v_t_2483 = (g_prelude_2e_2b_2b(v_t_2482, heff_get(heff_dup(v_b_2480), LBL_binders)));
      V v_t_2484 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2480, LBL_uses)));
      V v_b_2485 = heff_rec(2, shape_binders__uses, (V[]){v_t_2483, v_t_2484});
      V v_t_2486 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2476), LBL_binders), heff_get(heff_dup(v_b_2485), LBL_binders)));
      V v_t_2487 = (g_prelude_2e_2b_2b(heff_get(v_a_2476, LBL_uses), heff_get(v_b_2485, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2486, v_t_2487});
    }
    case TAG_PiAnon: {
      V v_a_2488 = heff_field(v_it1_2433, 0);
      heff_take_n(v_it1_2433, 1ULL, 1);
      heff_drop_cell(v_ru_24it_244_24EPi, 2);
      V v_a_2489 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_a_2488));
      V v_b_2490 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_r_2434));
      V v_t_2491 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2489), LBL_binders), heff_get(heff_dup(v_b_2490), LBL_binders)));
      V v_t_2492 = (g_prelude_2e_2b_2b(heff_get(v_a_2489, LBL_uses), heff_get(v_b_2490, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2491, v_t_2492});
    }
    default: return heff_nomatch(v_it1_2433);
    }
  }
  case TAG_ELam: {
    V v_it1_2493 = heff_field(v_it_244, 0);
    V v_r_2494 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELam = heff_take_reuse_n(v_it_244, 3ULL, 2);
    heff_drop(v_n_241);
    switch (heff_tag_of(v_it1_2493)) {
    case TAG_LamName: {
      heff_drop_cell(v_ru_24it_244_24ELam, 2);
      V v_bs_2497 = (g_heff_2elocals_2elamBinders(v_it1_2493));
      V v_env_2498 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_2497)));
      V v_b_2499 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_2498, v_r_2494));
      V v_t_24100 = (g_prelude_2e_2b_2b(v_bs_2497, heff_get(heff_dup(v_b_2499), LBL_binders)));
      V v_t_24101 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2499, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_24100, v_t_24101});
    }
    case TAG_LamImplicit: {
      heff_drop_cell(v_ru_24it_244_24ELam, 2);
      V v_bs_24104 = (g_heff_2elocals_2elamBinders(v_it1_2493));
      V v_env_24105 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24104)));
      V v_b_24106 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_24105, v_r_2494));
      V v_t_24107 = (g_prelude_2e_2b_2b(v_bs_24104, heff_get(heff_dup(v_b_24106), LBL_binders)));
      V v_t_24108 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_24106, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_24107, v_t_24108});
    }
    case TAG_LamAnn: {
      V v_x_24109 = heff_field(v_it1_2493, 0);
      V v_sp_24110 = heff_field(v_it1_2493, 1);
      V v_a_24111 = heff_field(v_it1_2493, 2);
      heff_take_n(v_it1_2493, 7ULL, 3);
      V v_a_24112 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_a_24111));
      V v_t_24113 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_24109), heff_dup(v_sp_24110), NTAG(TAG_False)});
      V v_t_24114 = heff_tag_at(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_t_24113, NTAG(TAG_Nil)});
      V v_env_24115 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, v_t_24114));
      V v_b_24116 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_24115, v_r_2494));
      V v_t_24117 = heff_rec(3, shape_name__span__field, (V[]){v_x_24109, v_sp_24110, NTAG(TAG_False)});
      V v_t_24118 = heff_tag(TAG_Cons, 2, (V[]){v_t_24117, NTAG(TAG_Nil)});
      V v_t_24119 = (g_prelude_2e_2b_2b(v_t_24118, heff_get(heff_dup(v_b_24116), LBL_binders)));
      V v_t_24120 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_24116, LBL_uses)));
      V v_b_24121 = heff_rec(2, shape_binders__uses, (V[]){v_t_24119, v_t_24120});
      V v_t_24122 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_24112), LBL_binders), heff_get(heff_dup(v_b_24121), LBL_binders)));
      V v_t_24123 = (g_prelude_2e_2b_2b(heff_get(v_a_24112, LBL_uses), heff_get(v_b_24121, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_24122, v_t_24123});
    }
    default: return heff_nomatch(v_it1_2493);
    }
  }
  case TAG_EAnn: {
    V v_e_24124 = heff_field(v_it_244, 0);
    V v_t_24125 = heff_field(v_it_244, 1);
    heff_take_n(v_it_244, 3ULL, 2);
    heff_drop(v_n_241);
    V v_a_24126 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_e_24124));
    V v_b_24127 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_t_24125));
    V v_t_24128 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_24126), LBL_binders), heff_get(heff_dup(v_b_24127), LBL_binders)));
    V v_t_24129 = (g_prelude_2e_2b_2b(heff_get(v_a_24126, LBL_uses), heff_get(v_b_24127, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_24128, v_t_24129});
  }
  case TAG_ESpec: {
    V v_acc_24130 = heff_field(v_it_244, 0);
    V v_v_24133 = heff_field(v_it_244, 3);
    heff_take_n(v_it_244, 9ULL, 4);
    heff_drop(v_n_241);
    V v_a_24134 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_acc_24130));
    V v_b_24135 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_v_24133));
    V v_t_24136 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_24134), LBL_binders), heff_get(heff_dup(v_b_24135), LBL_binders)));
    V v_t_24137 = (g_prelude_2e_2b_2b(heff_get(v_a_24134, LBL_uses), heff_get(v_b_24135, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_24136, v_t_24137});
  }
  case TAG_ESig: {
    V v_fs_24138 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_n_241);
    HEFF_LAST return g_heff_2elocals_2esigBlockF_24s751838273x104610517(v_env_240, v_fs_24138);
  }
  case TAG_ESum: {
    V v_vs_24139 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_n_241);
    return ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam1, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_vs_24139; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_vs_24139); r_; });
  }
  case TAG_EStruct: {
    V v_fs_24156 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_n_241);
    return ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam3, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_fs_24156; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_24156); r_; });
  }
  case TAG_EMatch: {
    V v_s_24168 = heff_field(v_it_244, 0);
    V v_alts_24169 = heff_field(v_it_244, 1);
    heff_take_n(v_it_244, 3ULL, 2);
    heff_drop(v_n_241);
    V v_a_24170 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_s_24168));
    V v_b_24185 = ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam4, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_alts_24169; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_alts_24169); r_; });
    V v_t_24186 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_24170), LBL_binders), heff_get(heff_dup(v_b_24185), LBL_binders)));
    V v_t_24187 = (g_prelude_2e_2b_2b(heff_get(v_a_24170, LBL_uses), heff_get(v_b_24185, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_24186, v_t_24187});
  }
  case TAG_ELetIn: {
    V v_rhs_24188 = heff_field(v_it_244, 0);
    V v_a_24189 = heff_field(v_it_244, 1);
    heff_take_n(v_it_244, 3ULL, 2);
    heff_drop(v_n_241);
    V v_a_24190 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_rhs_24188));
    V v_b_24200;
    switch (heff_tag_of(v_a_24189)) {
    case TAG_At: {
      V v_x31_24191 = heff_field(v_a_24189, 0);
      heff_take_n(v_a_24189, 1ULL, 2);
      switch (heff_tag_of(v_x31_24191)) {
      case TAG_MkAlt: {
        V v_p_24193 = heff_field(v_x31_24191, 0);
        V v_r_24194 = heff_field(v_x31_24191, 1);
        heff_take_n(v_x31_24191, 3ULL, 2);
        V v_bs_24195 = (g_heff_2elocals_2epatternBinders(v_p_24193));
        V v_env_24196 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24195)));
        V v_b_24197 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_24196, v_r_24194));
        V v_t_24198 = (g_prelude_2e_2b_2b(v_bs_24195, heff_get(heff_dup(v_b_24197), LBL_binders)));
        V v_t_24199 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_24197, LBL_uses)));
        v_b_24200 = heff_rec(2, shape_binders__uses, (V[]){v_t_24198, v_t_24199});
        break;
      }
      default: heff_nomatch(v_x31_24191);
      }
      break;
    }
    default: heff_nomatch(v_a_24189);
    }
    V v_t_24201 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_24190), LBL_binders), heff_get(heff_dup(v_b_24200), LBL_binders)));
    V v_t_24202 = (g_prelude_2e_2b_2b(heff_get(v_a_24190, LBL_uses), heff_get(v_b_24200, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_24201, v_t_24202});
  }
  case TAG_EDo: {
    V v_stmts_24203 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_n_241);
    HEFF_LAST return g_heff_2elocals_2edoBlockF_24s1899446753x1868157201(v_env_240, v_stmts_24203);
  }
  case TAG_ELocal: {
    V v_body_24204 = heff_field(v_it_244, 0);
    V v_defs_24205 = heff_field(v_it_244, 1);
    heff_take_n(v_it_244, 3ULL, 2);
    heff_drop(v_n_241);
    return (g_heff_2elocals_2elocalsF_24s81954161x867360906(v_env_240, v_defs_24205, v_body_24204));
  }
  case TAG_EInvalid: {
    heff_take_n(v_it_244, 0ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_n_241);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2ewalkF_24s56081104x1956273806(a[0], a[1]);
}
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam0(V self, V *args) {
  V v_acc_2422 = args[0];
  V v_x_2423 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2424 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_x_2423));
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_2422), LBL_binders), heff_get(heff_dup(v_b_2424), LBL_binders)));
  V v_t_2426 = (g_prelude_2e_2b_2b(heff_get(v_acc_2422, LBL_uses), heff_get(v_b_2424, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_2425, v_t_2426});
}
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam2(V self, V *args) {
  V v_acc_24147 = args[0];
  V v_x_24148 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24149 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_x_24148));
  V v_t_24150 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_24147), LBL_binders), heff_get(heff_dup(v_b_24149), LBL_binders)));
  V v_t_24151 = (g_prelude_2e_2b_2b(heff_get(v_acc_24147, LBL_uses), heff_get(v_b_24149, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_24150, v_t_24151});
}
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam1(V self, V *args) {
  V v_acc_24140 = args[0];
  V v_v_24141 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24153;
  switch (heff_tag_of(v_v_24141)) {
  case TAG_At: {
    V v_it1_24142 = heff_field(v_v_24141, 0);
    heff_take_n(v_v_24141, 1ULL, 2);
    switch (heff_tag_of(v_it1_24142)) {
    case TAG_TagVariant: {
      V v_args_24146 = heff_field(v_it1_24142, 2);
      heff_take_n(v_it1_24142, 4ULL, 3);
      v_b_24153 = ({ V a_0 = heff_clo(g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam2, 2, 1, (V[]){v_env_240}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_args_24146; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_args_24146); r_; });
      break;
    }
    case TAG_BadVariant: {
      V v_e_24152 = heff_field(v_it1_24142, 0);
      heff_take_n(v_it1_24142, 1ULL, 1);
      v_b_24153 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_e_24152));
      break;
    }
    default: heff_nomatch(v_it1_24142);
    }
    break;
  }
  default: heff_nomatch(v_v_24141);
  }
  V v_t_24154 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_24140), LBL_binders), heff_get(heff_dup(v_b_24153), LBL_binders)));
  V v_t_24155 = (g_prelude_2e_2b_2b(heff_get(v_acc_24140, LBL_uses), heff_get(v_b_24153, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_24154, v_t_24155});
}
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam3(V self, V *args) {
  V v_acc_24157 = args[0];
  V v_f_24158 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24165;
  switch (heff_tag_of(v_f_24158)) {
  case TAG_At: {
    V v_x31_24159 = heff_field(v_f_24158, 0);
    heff_take_n(v_f_24158, 1ULL, 2);
    switch (heff_tag_of(v_x31_24159)) {
    case TAG_SetField: {
      V v_e_24163 = heff_field(v_x31_24159, 2);
      heff_take_n(v_x31_24159, 4ULL, 3);
      v_b_24165 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_e_24163));
      break;
    }
    case TAG_BadFieldSet: {
      V v_e_24164 = heff_field(v_x31_24159, 0);
      heff_take_n(v_x31_24159, 1ULL, 1);
      v_b_24165 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_e_24164));
      break;
    }
    default: heff_nomatch(v_x31_24159);
    }
    break;
  }
  default: heff_nomatch(v_f_24158);
  }
  V v_t_24166 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_24157), LBL_binders), heff_get(heff_dup(v_b_24165), LBL_binders)));
  V v_t_24167 = (g_prelude_2e_2b_2b(heff_get(v_acc_24157, LBL_uses), heff_get(v_b_24165, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_24166, v_t_24167});
}
V g_heff_2elocals_2ewalkF_24s56081104x1956273806_lam4(V self, V *args) {
  V v_acc_24171 = args[0];
  V v_a_24172 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_24182;
  switch (heff_tag_of(v_a_24172)) {
  case TAG_At: {
    V v_x31_24173 = heff_field(v_a_24172, 0);
    heff_take_n(v_a_24172, 1ULL, 2);
    switch (heff_tag_of(v_x31_24173)) {
    case TAG_MkAlt: {
      V v_p_24175 = heff_field(v_x31_24173, 0);
      V v_r_24176 = heff_field(v_x31_24173, 1);
      heff_take_n(v_x31_24173, 3ULL, 2);
      V v_bs_24177 = (g_heff_2elocals_2epatternBinders(v_p_24175));
      V v_env_24178 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_24177)));
      V v_b_24179 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_24178, v_r_24176));
      V v_t_24180 = (g_prelude_2e_2b_2b(v_bs_24177, heff_get(heff_dup(v_b_24179), LBL_binders)));
      V v_t_24181 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_24179, LBL_uses)));
      v_b_24182 = heff_rec(2, shape_binders__uses, (V[]){v_t_24180, v_t_24181});
      break;
    }
    default: heff_nomatch(v_x31_24173);
    }
    break;
  }
  default: heff_nomatch(v_a_24172);
  }
  V v_t_24183 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_24171), LBL_binders), heff_get(heff_dup(v_b_24182), LBL_binders)));
  V v_t_24184 = (g_prelude_2e_2b_2b(heff_get(v_acc_24171, LBL_uses), heff_get(v_b_24182, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_24183, v_t_24184});
}
V g_heff_2elocals_2earguments_lam0(V self, V *args);
Clo g_heff_2elocals_2earguments_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2earguments_entry, 3, 0};

V g_heff_2elocals_2earguments(V v_env_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl(heff_clo(g_heff_2elocals_2earguments_lam0, 2, 1, (V[]){v_env_240}), heff_dup(g_heff_2elocals_2enone_get()), v_rest_242);
  }
  case TAG_Cons: {
    V v_a_248 = heff_field(v_x2_241, 0);
    V v_tl_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_a_248)) {
    case TAG_At: {
      V v_it1_2410 = heff_field(v_a_248, 0);
      V v_ru_24a_248_24At = heff_take_reuse_n(v_a_248, 1ULL, 2);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_ExplicitParam: {
        V v_x_2412 = heff_field(v_it1_2410, 0);
        V v_sp_2413 = heff_field(v_it1_2410, 1);
        V v_t_2414 = heff_field(v_it1_2410, 2);
        heff_take_n(v_it1_2410, 7ULL, 3);
        V v_a_2415 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_t_2414));
        V v_t_2416 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_2412), heff_dup(v_sp_2413), NTAG(TAG_False)});
        V v_b_2417 = (g_heff_2elocals_2earguments(heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2418 = heff_rec(3, shape_name__span__field, (V[]){v_x_2412, v_sp_2413, NTAG(TAG_False)});
        V v_t_2419 = heff_tag_at(v_ru_24a_248_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, heff_get(heff_dup(v_b_2417), LBL_binders)));
        V v_t_2421 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2417, LBL_uses)));
        V v_b_2422 = heff_rec(2, shape_binders__uses, (V[]){v_t_2420, v_t_2421});
        V v_t_2423 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2415), LBL_binders), heff_get(heff_dup(v_b_2422), LBL_binders)));
        V v_t_2424 = (g_prelude_2e_2b_2b(heff_get(v_a_2415, LBL_uses), heff_get(v_b_2422, LBL_uses)));
        return heff_rec(2, shape_binders__uses, (V[]){v_t_2423, v_t_2424});
      }
      case TAG_ImplicitParam: {
        V v_x_2425 = heff_field(v_it1_2410, 0);
        V v_sp_2426 = heff_field(v_it1_2410, 1);
        V v_t_2427 = heff_field(v_it1_2410, 2);
        heff_take_n(v_it1_2410, 7ULL, 3);
        V v_a_2428 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(heff_dup(v_env_240), v_t_2427));
        V v_t_2429 = heff_rec(3, shape_name__span__field, (V[]){heff_dup(v_x_2425), heff_dup(v_sp_2426), NTAG(TAG_False)});
        V v_b_2430 = (g_heff_2elocals_2earguments(heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2429, v_env_240}), v_tl_249, v_rest_242));
        V v_t_2431 = heff_rec(3, shape_name__span__field, (V[]){v_x_2425, v_sp_2426, NTAG(TAG_False)});
        V v_t_2432 = heff_tag_at(v_ru_24a_248_24At, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
        V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2432, heff_get(heff_dup(v_b_2430), LBL_binders)));
        V v_t_2434 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2430, LBL_uses)));
        V v_b_2435 = heff_rec(2, shape_binders__uses, (V[]){v_t_2433, v_t_2434});
        V v_t_2436 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_2428), LBL_binders), heff_get(heff_dup(v_b_2435), LBL_binders)));
        V v_t_2437 = (g_prelude_2e_2b_2b(heff_get(v_a_2428, LBL_uses), heff_get(v_b_2435, LBL_uses)));
        return heff_rec(2, shape_binders__uses, (V[]){v_t_2436, v_t_2437});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_a_248);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elocals_2earguments_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2earguments(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2elocals_2earguments_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_245 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_240, v_x_244));
  V v_t_246 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_243), LBL_binders), heff_get(heff_dup(v_b_245), LBL_binders)));
  V v_t_247 = (g_prelude_2e_2b_2b(heff_get(v_acc_243, LBL_uses), heff_get(v_b_245, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_246, v_t_247});
}
Clo g_heff_2elocals_2eequationF_24s390091567x1420489091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2eequationF_24s390091567x1420489091_entry, 2, 0};

V g_heff_2elocals_2eequationF_24s390091567x1420489091(V v_env_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_MkEquation: {
      V v_ps_246 = heff_field(v_x31_242, 2);
      V v_rhs_247 = heff_field(v_x31_242, 3);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_246)));
      V v_bs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1009481344x1999114184(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_env_2410 = (g_list_2efoldl_24s1370882877x364361272(v_env_240, heff_dup(v_bs_249)));
      V v_b_2411 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(v_env_2410, heff_dup(v_rhs_247)));
      V v_t_2412 = (g_prelude_2e_2b_2b(v_bs_249, heff_get(heff_dup(v_b_2411), LBL_binders)));
      V v_t_2413 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), heff_get(v_b_2411, LBL_uses)));
      return heff_rec(2, shape_binders__uses, (V[]){v_t_2412, v_t_2413});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2elocals_2eequationF_24s390091567x1420489091_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2eequationF_24s390091567x1420489091(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2elocals_2edeclaration_lam0(V self, V *args);
Clo g_heff_2elocals_2edeclaration_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2edeclaration_entry, 1, 0};

V g_heff_2elocals_2edeclaration(V v_d_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_d_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_DeclEquations: {
    V v_ty_246 = heff_field(v_t_243, 2);
    V v_eqs_247 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 12ULL, 4);
    V v_a_248 = (g_heff_2elocals_2ewalkF_24s56081104x1956273806(NTAG(TAG_Nil), heff_dup(v_ty_246)));
    V v_b_2416 = ({ V a_0 = heff_clo(g_heff_2elocals_2edeclaration_lam0, 2, 1, (V[]){v_ty_246}); V a_1 = heff_dup(g_heff_2elocals_2enone_get()); V a_2 = v_eqs_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_eqs_247); r_; });
    V v_t_2417 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_a_248), LBL_binders), heff_get(heff_dup(v_b_2416), LBL_binders)));
    V v_t_2418 = (g_prelude_2e_2b_2b(heff_get(v_a_248, LBL_uses), heff_get(v_b_2416, LBL_uses)));
    return heff_rec(2, shape_binders__uses, (V[]){v_t_2417, v_t_2418});
  }
  case TAG_DeclDefine: {
    V v_ps_2421 = heff_field(v_t_243, 2);
    V v_ty_2422 = heff_field(v_t_243, 3);
    V v_body_2423 = heff_field(v_t_243, 4);
    heff_take_n(v_t_243, 28ULL, 5);
    V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){v_body_2423, NTAG(TAG_Nil)});
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2421; V b_2 = heff_tag(TAG_Cons, 2, (V[]){v_ty_2422, v_t_2424}); V r_ = (g_heff_2elocals_2earguments(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  }
  case TAG_DeclTheory: {
    V v_ps_2427 = heff_field(v_t_243, 2);
    V v_body_2428 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 12ULL, 4);
    V v_t_2429 = heff_tag(TAG_Cons, 2, (V[]){v_body_2428, NTAG(TAG_Nil)});
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_ps_2427; V a_2 = v_t_2429; V r_ = (g_heff_2elocals_2earguments(a_0, a_1, a_2)); heff_drop_tag(v_t_2429, 2); r_; });
  }
  case TAG_DeclPrimitive: {
    V v_t_2432 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    return (g_heff_2elocals_2ewalkF_24s56081104x1956273806(NTAG(TAG_Nil), v_t_2432));
  }
  case TAG_DeclTest: {
    heff_take_n(v_t_243, 0ULL, 2);
    return heff_dup(g_heff_2elocals_2enone_get());
  }
  case TAG_DeclWatch: {
    V v_e_2435 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    return (g_heff_2elocals_2ewalkF_24s56081104x1956273806(NTAG(TAG_Nil), v_e_2435));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2elocals_2edeclaration_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elocals_2edeclaration(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2elocals_2edeclaration_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_eq_2410 = args[1];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bs_2411 = (g_heff_2elocals_2eimplicitsOf(v_ty_246));
  V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_2411));
  V v_b_2413 = ({ V a_0 = v_t_2412; V a_1 = v_eq_2410; V r_ = (g_heff_2elocals_2eequationF_24s390091567x1420489091(a_0, a_1)); heff_drop(v_eq_2410); r_; });
  V v_t_2414 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_acc_249), LBL_binders), heff_get(heff_dup(v_b_2413), LBL_binders)));
  V v_t_2415 = (g_prelude_2e_2b_2b(heff_get(v_acc_249, LBL_uses), heff_get(v_b_2413, LBL_uses)));
  return heff_rec(2, shape_binders__uses, (V[]){v_t_2414, v_t_2415});
}
V g_heff_2elocals_2emkLocal_lam0(V self, V *args);
Clo g_heff_2elocals_2emkLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elocals_2emkLocal_entry, 2, 0};

V g_heff_2elocals_2emkLocal(V v_us_240, V v_b_241) {
top: ;
  V v_t_246 = (g_list_2efilter(heff_clo(g_heff_2elocals_2emkLocal_lam0, 1, 1, (V[]){heff_dup(v_b_241)}), v_us_240));
  V v_t_247 = (g_list_2emap_24s1282605757x1399508316(v_t_246));
  return heff_rec(3, shape_name__binder__uses, (V[]){heff_get(heff_dup(v_b_241), LBL_name), heff_get(v_b_241, LBL_span), v_t_247});
}
V g_heff_2elocals_2emkLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2elocals_2emkLocal(a[0], a[1]);
}
V g_heff_2elocals_2emkLocal_lam0(V self, V *args) {
  V v_u_242 = args[0];
  V v_b_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_243 = heff_get(heff_get(v_u_242, LBL_binder), LBL_span);
  V v_b_244 = heff_get(v_b_241, LBL_span);
  if (heff_intEq_c(heff_get(heff_dup(v_a_243), LBL_start), heff_get(heff_dup(v_b_244), LBL_start))) {
    return heff_intEq(heff_get(v_a_243, LBL_end), heff_get(v_b_244, LBL_end));
  } else {
    heff_drop(v_a_243);
    heff_drop(v_b_244);
    return NTAG(TAG_False);
  }
}