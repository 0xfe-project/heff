// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DData 48360
#define TAG_Get 18914
#define TAG_MkDAlts 45152
#define TAG_MkSep 6724
#define LBL_bind 9519364
#define LBL_malg 9839318
#define LBL_text 10052084
V g_heff_2esyntax_2ecst_2echeckAltNames(V, V);
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edataAlternative(V, V);
V g_heff_2esyntax_2ecst_2edataAlternative_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataAlternative_clo;
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_clo;
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_str0, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_str1, 1, "|");
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_entry, 6, 0};

V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0(V v_x_240, V v_x_241, V v_x_242, V v_universe_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam0, 1, 6, (V[]){v_x_240, v_x_241, v_x_242, v_universe_243, v_hd_244, v_k_245})});
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_universe_243 = heff_env(self)[4];
  V v_alts_249 = heff_env(self)[5];
  heff_drop(v_x_2418);
  heff_clo_take(self, 6);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_DData, 5, (V[]){v_x_241, v_x_240, v_x_242, v_universe_243, v_alts_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_universe_243 = heff_env(self)[4];
  V v_alts_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam3, 1, 6, (V[]){v_k_2417, v_x_241, v_x_240, v_x_242, v_universe_243, v_alts_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam1(V self, V *args) {
  V v_alts_249 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_universe_243 = heff_env(self)[3];
  V v_t_2414;
  switch (heff_tag_of(v_alts_249)) {
  case TAG_Nothing: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_2410 = heff_dup(heff_field(v_alts_249, 0));
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_MkDAlts: {
      V v_alts_2412 = heff_field(v_x11_2410, 1);
      heff_take_n(v_x11_2410, 2ULL, 3);
      v_t_2414 = v_alts_2412;
      break;
    }
    default: heff_nomatch(v_x11_2410);
    }
    break;
  }
  default: heff_nomatch(v_alts_249);
  }
  V v_c_2415 = ({ V a_0 = heff_rfield(v_x_240, 1); V a_1 = v_t_2414; V r_ = (g_heff_2esyntax_2ecst_2echeckAltNames(a_0, a_1)); heff_drop(v_t_2414); r_; });
  heff_clo_take(self, 4);
  return heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam2, 2, 6, (V[]){v_c_2415, v_x_241, v_x_240, v_x_242, v_universe_243, v_alts_249});
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_f_2419 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_t_2426;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_MkSep: {
    V v_items_2424 = heff_field(v_x_2423, 0);
    V v_seps_2425 = heff_field(v_x_2423, 1);
    heff_take_n(v_x_2423, 3ULL, 2);
    v_t_2426 = heff_tag_n(TAG_MkDAlts, 3, (V[]){v_x_2420, v_items_2424, v_seps_2425});
    break;
  }
  default: heff_nomatch(v_x_2423);
  }
  V f_ = v_f_2419;
  heff_room[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2426});
  heff_room[1] = v_hd_244;
  heff_room[2] = v_k_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_f_2419 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2421, NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_str1); V a_1 = v_t_2422; V a_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_hd_244); V a_4 = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam6, 1, 4, (V[]){v_x_2420, v_f_2419, v_hd_244, v_k_245}); V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_f_2419 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2edataAlternative(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam5, 1, 4, (V[]){v_hd_244, v_x_2420, v_f_2419, v_k_245})));
}
V g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_universe_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_f_2419 = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam1, 1, 4, (V[]){v_x_240, v_x_241, v_x_242, v_universe_243});
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_str0))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_2ef_24l0_lam4, 1, 3, (V[]){v_hd_244, v_f_2419, v_k_245})));
  } else {
    V f_ = v_f_2419;
    heff_room[0] = NTAG(TAG_Nothing);
    heff_room[1] = v_hd_244;
    heff_room[2] = v_k_245;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}