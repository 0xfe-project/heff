// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(V);
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_clo;
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eallList(V, V);
V g_heff_2ecompile_2eir_2eallList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallList_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V, V);
V g_heff_2ecompile_2eir_2econdExpr(V);
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdExpr_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ehasDefault(V);
V g_heff_2ecompile_2eir_2ehasDefault_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ehasDefault_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2enubI_24dps(V, V);
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_24dps_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s1158390340x316106132(V);
V g_prelude_2etraverse_24s1158390340x316106132_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1158390340x316106132_clo;
V g_prelude_2etraverse_24s1254646865x1442622806(V);
V g_prelude_2etraverse_24s1254646865x1442622806_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1254646865x1442622806_clo;
V g_prelude_2etraverse_24s130657301x1556233528(V);
V g_prelude_2etraverse_24s130657301x1556233528_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s130657301x1556233528_clo;
V g_prelude_2etraverse_24s1360711314x1560806682(V, V);
V g_prelude_2etraverse_24s1360711314x1560806682_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1360711314x1560806682_clo;

HeffT2 g_heff_2ecompile_2eir_2earmFor_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_a_242, 0);
      v_t_247 = heff_dup(v_t_244);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_t_240, 1)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_a_242)}});
    } else {
      V v_t_2411;
      switch (heff_tag_of(v_a_242)) {
      case TAG_MkArm: {
        V v_t_248 = heff_field(v_a_242, 0);
        v_t_2411 = heff_bool(heff_strEq_c(heff_dup(v_t_248), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
        break;
      }
      default: heff_nomatch(v_a_242);
      }
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_a_242)}});
      } else {
        heff_drop(v_t_2411);
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2eir_2eappendI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_entry, 2, 0};

V g_heff_2ecompile_2eir_2eappendI(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eir_2eappendI_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2enubI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_entry, 1, 0};

V g_heff_2ecompile_2eir_2enubI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2ecompile_2eir_2enubI_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI(a[0]);
}
Clo g_heff_2ecompile_2eir_2epushFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushFields(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 2ULL, 2);
      v_t_246 = v_e2_245;
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2ecompile_2eir_2epushFields_24dps(v_fs_243, v_rest_241, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epartsOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epartsOnto_entry, 2, 0};

V g_heff_2ecompile_2eir_2epartsOnto(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){v_b_245, v_rest_241});
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x1_240, 0);
    V v_args_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_args_247, v_rest_241));
    return heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_t_248});
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, v_rest_241})});
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x1_240_24ERecord, v_fs_2412, v_rest_241));
  }
  case TAG_EProj: {
    V v_e_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 4);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2414, v_rest_241});
  }
  case TAG_ETag: {
    V v_args_2419 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_args_2419, v_rest_241);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_x1_240, 0);
    V v_arms_2422 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2423 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2422, v_rest_241));
    return heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2421, v_t_2423});
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EPrimCall: {
    V v_args_2426 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EPrimCall, v_args_2426, v_rest_241));
  }
  case TAG_ECall: {
    V v_args_2428 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24ECall, v_args_2428, v_rest_241));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_rest_241;
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EAbandon: {
    return v_rest_241;
  }
  case TAG_EBool: {
    V v_c_2436 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_c_2436; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2436); r_; });
  }
  case TAG_ESet: {
    V v_a_2438 = heff_field(v_x1_240, 1);
    V v_b_2439 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_a_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2439, v_rest_241})});
  }
  case TAG_EValues: {
    V v_es_2440 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_es_2440, v_rest_241);
  }
  case TAG_EFix: {
    V v_b_2442 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EFix = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24EFix, TAG_Cons, 2, (V[]){v_b_2442, v_rest_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epartsOnto(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2eallList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallList_entry, 2, 0};

V g_heff_2ecompile_2eir_2eallList(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_es_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), heff_dup(v_e_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_f_240;
      V t_1 = v_es_243;
      v_f_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_f_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2eallList_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2eallList(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_fs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkPair: {
      V v_e_244 = heff_field(v_x21_241, 1);
      V v_a_245 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_e_244)));
      if (!(heff_dup(v_a_245) == NTAG(TAG_True))) {
        heff_drop(v_a_245);
        V t_0 = v_fs_242;
        v_x2_240 = t_0;
        goto top;
      } else {
        heff_drop(v_a_245);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallFields_24s1098924x1895007029(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_CTrue: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_CTrue), v_n_241}});
  }
  case TAG_CFalse: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_CFalse), v_n_241}});
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x4_242, 0);
    V v_x_244 = heff_field(v_x4_242, 1);
    V v_y_245 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24CRel = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_246 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_x_244));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_27_249 = v_field_247;
      V v_n1_2410 = v_field_248;
      HeffT2 v_t_2411 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n1_2410, v_y_245));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_y_27_2414 = v_field_2412;
        V v_n2_2415 = v_field_2413;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CRel, TAG_CRel, 3, (V[]){v_p_243, v_x_27_249, v_y_27_2414}), v_n2_2415}});
      }
    }
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CTest = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_x_2416));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_x_27_2420 = v_field_2418;
      V v_n1_2421 = v_field_2419;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CTest, TAG_CTest, 1, (V[]){v_x_27_2420}), v_n1_2421}});
    }
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CNot = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2423 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_241, v_c_2422));
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_field_2425 = v_t_2423.f[1];
      V v_c_2426 = v_field_2424;
      V v_n_2427 = v_field_2425;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CNot, TAG_CNot, 1, (V[]){v_c_2426}), v_n_2427}});
    }
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x4_242, 0);
    V v_b_2429 = heff_field(v_x4_242, 1);
    V v_c_2430 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24CIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2431 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(heff_dup(v_m_240), v_n_241, v_a_2428));
    {
      V v_field_2432 = v_t_2431.f[0];
      V v_field_2433 = v_t_2431.f[1];
      V v_c_2434 = v_field_2432;
      V v_n_2435 = v_field_2433;
      HeffT2 v_t_2436 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(heff_dup(v_m_240), v_n_2435, v_b_2429));
      {
        V v_field_2437 = v_t_2436.f[0];
        V v_field_2438 = v_t_2436.f[1];
        V v_c_2439 = v_field_2437;
        V v_n_2440 = v_field_2438;
        HeffT2 v_t_2441 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_2440, v_c_2430));
        {
          V v_field_2442 = v_t_2441.f[0];
          V v_field_2443 = v_t_2441.f[1];
          V v_c_2444 = v_field_2442;
          V v_n_2445 = v_field_2443;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CIf, TAG_CIf, 3, (V[]){v_c_2434, v_c_2439, v_c_2444}), v_n_2445}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2eisValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eisValue_entry, 1, 0};

V g_heff_2ecompile_2eir_2eisValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_t_2412 = (g_list_2emap_24s1044393341x1523302351(heff_dup(v_fs_2410)));
    return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x1_240, 1);
    V v_t_2420 = (g_list_2emap_24s584454411x1006678865(heff_dup(v_args_2418)));
    return ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_2435 = heff_field(v_x1_240, 0);
    V v_t_2436 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2435, NTAG(TAG_Nil)));
    V v_t_2437 = (g_list_2emap_24s584454411x1006678865(v_t_2436));
    return ({ V a_0 = v_t_2437; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2437); r_; });
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eisValue(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str2, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str3, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str7, 5, "False");
Clo g_heff_2ecompile_2eir_2econdExpr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdExpr_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdExpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_CFalse: {
    return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_b_243 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_t_244})});
  }
  case TAG_CTest: {
    V v_e_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_e_245;
  }
  case TAG_CNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_247 = (g_heff_2ecompile_2eir_2econdExpr(v_c_246));
    V v_t_248 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str2), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str3), NTAG(TAG_Nil), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str4), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str5), NTAG(TAG_Nil), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412})});
  }
  case TAG_CIf: {
    V v_a_2413 = heff_field(v_x1_240, 0);
    V v_b_2414 = heff_field(v_x1_240, 1);
    V v_c_2415 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2eir_2econdExpr(v_a_2413));
    V v_t_2417 = (g_heff_2ecompile_2eir_2econdExpr(v_b_2414));
    V v_f_2418 = (g_heff_2ecompile_2eir_2econdExpr(v_c_2415));
    V v_t_2419 = heff_tag_at_n(v_ru_24x1_240_24CIf, TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str6), NTAG(TAG_Nil), v_t_2417});
    V v_t_2420 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str7), NTAG(TAG_Nil), v_f_2418});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdExpr(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_246 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam2, 1, 3, (V[]){v_m_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2415 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2416 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam3, 1, 1, (V[]){v_m_2416});
  }
  case TAG_CNot: {
    V v_c_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2422 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_c_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam4, 1, 1, (V[]){v_m_2422});
  }
  case TAG_CIf: {
    V v_a_2427 = heff_field(v_x2_27_240, 0);
    V v_b_2428 = heff_field(v_x2_27_240, 1);
    V v_c_2429 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam5, 1, 3, (V[]){v_m_2430, v_b_2428, v_c_2429});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam1(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_y_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_249, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2419}), v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2425}), v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_c_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_m_2435 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_b_2428));
    V v_x2_2436 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_s_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_m_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s94404899x1389168221(v_c_2429));
      V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_s_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_s_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2433, v_x_2437, v_x_2441}), v_s_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam24(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam25(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam26(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_entry, 2, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_246), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_g_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_2413}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam3, 1, 3, (V[]){v_m_2415, v_f_240, v_args_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2426}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam4, 1, 4, (V[]){v_m_2428, v_x_2425, v_f_240, v_b_2427});
  }
  case TAG_ERecord: {
    V v_fs_2438 = heff_field(v_x2_241, 0);
    V v_ts_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2448 = (g_prelude_2etraverse_24s1360711314x1560806682(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam5, 1, 1, (V[]){v_f_240}), v_fs_2438));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam7, 1, 2, (V[]){v_m_2448, v_ts_2439});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x2_241, 0);
    V v_l_2454 = heff_field(v_x2_241, 1);
    V v_sh_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2457 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2453}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam8, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x2_241, 0);
    V v_args_2463 = heff_field(v_x2_241, 1);
    V v_ts_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2466 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_2465, v_args_2463));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam9, 1, 3, (V[]){v_m_2466, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_x2_241, 0);
    V v_arms_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2473 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2471}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam10, 1, 3, (V[]){v_m_2473, v_f_240, v_arms_2472});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2493 = heff_field(v_x2_241, 0);
    V v_args_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2496 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_2495, v_args_2494));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam14, 1, 2, (V[]){v_m_2496, v_p_2493});
  }
  case TAG_ECall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_args_24102 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24103 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24104 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_24103, v_args_24102));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam15, 1, 2, (V[]){v_m_24104, v_g_24101});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBool: {
    V v_c_24123 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24124 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24125 = (g_heff_2ecompile_2eir_2econdTraverse_24s88567922x941690(v_t_24124, v_c_24123));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam23, 1, 1, (V[]){v_m_24125});
  }
  case TAG_ESet: {
    V v_xs_24130 = heff_field(v_x2_241, 0);
    V v_a_24131 = heff_field(v_x2_241, 1);
    V v_b_24132 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24133 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_24131}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam24, 1, 4, (V[]){v_m_24133, v_f_240, v_xs_24130, v_b_24132});
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24143 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24144 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_24143, v_es_24142));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam25, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x2_241, 0);
    V v_b_24150 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24151 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_x_24149), NTAG(TAG_Nil)});
    V v_m_24152 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_24151, v_b_24150}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam26, 1, 2, (V[]){v_m_24152, v_x_24149});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_243});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_245});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_args_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2421 = (g_prelude_2etraverse_24s1360711314x1560806682(v_t_2420, v_args_2414));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_s_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_s_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_b_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
    V v_m_2434 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2433, v_b_2427}));
    V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2432}));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_s_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2425, v_x_2431, v_x_2436}), v_s_2437});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam6(V self, V *args) {
  V v_s_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_s_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2441, v_x_2446}), v_s_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam5(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_l_2441 = heff_field(v_x2_2440, 0);
    V v_e_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    V v_m_2443 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2442}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam6, 1, 2, (V[]){v_m_2443, v_l_2441});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam7(V self, V *args) {
  V v_s_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_ts_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_s_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2451, v_ts_2439}), v_s_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam8(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam9(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2469, v_ts_2464}), v_s_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam12(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_t_2479 = heff_env(self)[1];
  V v_vs_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2479, v_vs_2480, v_x_2485}), v_s_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam11(V self, V *args) {
  V v_x2_2478 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkArm: {
    V v_t_2479 = heff_field(v_x2_2478, 0);
    V v_vs_2480 = heff_field(v_x2_2478, 1);
    V v_b_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 7ULL, 3);
    V v_m_2482 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2480), v_b_2481}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam12, 1, 3, (V[]){v_m_2482, v_t_2479, v_vs_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam10(V self, V *args) {
  V v_s_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_arms_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_s_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_s_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    V v_m_2487 = (g_prelude_2etraverse_24s1360711314x1560806682(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam11, 1, 1, (V[]){v_f_240}), v_arms_2472));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_s_2477}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_EMatch, 2, (V[]){v_x_2476, v_x_2489}), v_s_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam13(V self, V *args) {
  V v_s_2492 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam14(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_p_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2493, v_x_2499}), v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam15(V self, V *args) {
  V v_s_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_g_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_s_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_s_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24101, v_x_24107}), v_s_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam16(V self, V *args) {
  V v_s_24110 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24110});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam17(V self, V *args) {
  V v_s_24112 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24112});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam18(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24114});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam19(V self, V *args) {
  V v_s_24116 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24116});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam20(V self, V *args) {
  V v_s_24119 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24119});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam21(V self, V *args) {
  V v_s_24121 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24121});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam22(V self, V *args) {
  V v_s_24122 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24122});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam23(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24128}), v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam24(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_24130 = heff_env(self)[2];
  V v_b_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_m_24138 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_24130), v_b_24132}));
    V v_x2_24139 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_s_24137}));
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_s_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24130, v_x_24136, v_x_24140}), v_s_24141});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam25(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24147}), v_s_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1205960121x2107293258_lam26(V self, V *args) {
  V v_s_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_s_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_s_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24149, v_x_24155}), v_s_24156});
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam22(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry, 1, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_240, 0);
    V v_b_246 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_g_2415 = heff_field(v_x2_240, 0);
    V v_args_2416 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2417 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_g_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam3, 1, 2, (V[]){v_m_2417, v_args_2416});
  }
  case TAG_ELet: {
    V v_x_2429 = heff_field(v_x2_240, 0);
    V v_a_2430 = heff_field(v_x2_240, 1);
    V v_b_2431 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2432 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_a_2430));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam4, 1, 3, (V[]){v_m_2432, v_b_2431, v_x_2429});
  }
  case TAG_ERecord: {
    V v_fs_2447 = heff_field(v_x2_240, 0);
    V v_ts_2448 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2449 = (g_prelude_2etraverse_24s1254646865x1442622806(v_fs_2447));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam5, 1, 2, (V[]){v_m_2449, v_ts_2448});
  }
  case TAG_EProj: {
    V v_e_2454 = heff_field(v_x2_240, 0);
    V v_l_2455 = heff_field(v_x2_240, 1);
    V v_sh_2456 = heff_field(v_x2_240, 2);
    V v_t_2457 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_m_2458 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_e_2454));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam6, 1, 4, (V[]){v_m_2458, v_l_2455, v_sh_2456, v_t_2457});
  }
  case TAG_ETag: {
    V v_t_2466 = heff_field(v_x2_240, 0);
    V v_args_2467 = heff_field(v_x2_240, 1);
    V v_ts_2468 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2469 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2467));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam7, 1, 3, (V[]){v_m_2469, v_t_2466, v_ts_2468});
  }
  case TAG_EMatch: {
    V v_s_2474 = heff_field(v_x2_240, 0);
    V v_arms_2475 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2476 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_s_2474));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam8, 1, 2, (V[]){v_m_2476, v_arms_2475});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EPrimCall: {
    V v_p_2490 = heff_field(v_x2_240, 0);
    V v_args_2491 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2492 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2491));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam10, 1, 2, (V[]){v_m_2492, v_p_2490});
  }
  case TAG_ECall: {
    V v_g_2497 = heff_field(v_x2_240, 0);
    V v_args_2498 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2499 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2498));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam11, 1, 2, (V[]){v_m_2499, v_g_2497});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam12, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBool: {
    V v_c_24118 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24119 = (g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(v_c_24118));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam19, 1, 1, (V[]){v_m_24119});
  }
  case TAG_ESet: {
    V v_xs_24124 = heff_field(v_x2_240, 0);
    V v_a_24125 = heff_field(v_x2_240, 1);
    V v_b_24126 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_24127 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_a_24125));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam20, 1, 3, (V[]){v_m_24127, v_b_24126, v_xs_24124});
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24143 = (g_prelude_2etraverse_24s130657301x1556233528(v_es_24142));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam21, 1, 1, (V[]){v_m_24143});
  }
  case TAG_EFix: {
    V v_x_24148 = heff_field(v_x2_240, 0);
    V v_b_24149 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24150 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_24149));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam22, 1, 2, (V[]){v_m_24150, v_x_24148});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(a[0]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_242});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_244});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  V v_x2_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    v_x2_2412 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_249_24MkPair, v_x_2410, v_n_2411));
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_n_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2413}), v_n_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_args_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  V v_x2_2422;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    v_x2_2422 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2419_24MkPair, v_x_2420, v_n_2421));
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_MkPair: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_n_2424 = heff_field(v_x2_2422, 1);
    V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
    V v_m_2425 = (g_prelude_2etraverse_24s130657301x1556233528(v_args_2416));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_n_2424}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_n_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_EApp, 2, (V[]){v_x_2423, v_x_2427}), v_n_2428});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam4(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_b_2431 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  V v_x2_2437;
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    v_x2_2437 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2434_24MkPair, v_x_2435, v_n_2436));
    break;
  }
  default: heff_nomatch(v_x2_2434);
  }
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_n_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_m_2440 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_2431));
    V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
    V v_x2_2444;
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_n_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      v_x2_2444 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2441_24MkPair, v_x_2442, v_n_2443));
      break;
    }
    default: heff_nomatch(v_x2_2441);
    }
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_MkPair: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      V v_n_2446 = heff_field(v_x2_2444, 1);
      heff_take_n(v_x2_2444, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2429, v_x_2438, v_x_2445}), v_n_2446});
    }
    default: return heff_nomatch(v_x2_2444);
    }
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam5(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  V v_ts_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2452, v_ts_2448}), v_n_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam6(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_l_2455 = heff_env(self)[1];
  V v_sh_2456 = heff_env(self)[2];
  V v_t_2457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  V v_x2_2463;
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    v_x2_2463 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2460_24MkPair, v_x_2461, v_n_2462));
    break;
  }
  default: heff_nomatch(v_x2_2460);
  }
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2464, v_l_2455, v_sh_2456, v_t_2457}), v_n_2465});
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam7(V self, V *args) {
  V v_n_2470 = args[0];
  V v_m_2469 = heff_env(self)[0];
  V v_t_2466 = heff_env(self)[1];
  V v_ts_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2471 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_n_2470}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x2_2471, 0);
    V v_n_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24MkPair = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2466, v_x_2472, v_ts_2468}), v_n_2473});
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam8(V self, V *args) {
  V v_n_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_arms_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_n_2477}));
  V v_x2_2481;
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_n_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    v_x2_2481 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_2478_24MkPair, v_x_2479, v_n_2480));
    break;
  }
  default: heff_nomatch(v_x2_2478);
  }
  switch (heff_tag_of(v_x2_2481)) {
  case TAG_MkPair: {
    V v_x_2482 = heff_field(v_x2_2481, 0);
    V v_n_2483 = heff_field(v_x2_2481, 1);
    V v_ru_24x2_2481_24MkPair = heff_take_reuse_n(v_x2_2481, 3ULL, 2);
    V v_m_2484 = (g_prelude_2etraverse_24s1158390340x316106132(v_arms_2475));
    V v_x2_2485 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_n_2483}));
    switch (heff_tag_of(v_x2_2485)) {
    case TAG_MkPair: {
      V v_x_2486 = heff_field(v_x2_2485, 0);
      V v_n_2487 = heff_field(v_x2_2485, 1);
      V v_ru_24x2_2485_24MkPair = heff_take_reuse_n(v_x2_2485, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2485_24MkPair, TAG_EMatch, 2, (V[]){v_x_2482, v_x_2486}), v_n_2487});
    }
    default: return heff_nomatch(v_x2_2485);
    }
  }
  default: return heff_nomatch(v_x2_2481);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam9(V self, V *args) {
  V v_n_2489 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2489});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam10(V self, V *args) {
  V v_n_2493 = args[0];
  V v_m_2492 = heff_env(self)[0];
  V v_p_2490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2494 = heff_tr(heff_call(v_m_2492, 1, (V[]){v_n_2493}));
  switch (heff_tag_of(v_x2_2494)) {
  case TAG_MkPair: {
    V v_x_2495 = heff_field(v_x2_2494, 0);
    V v_n_2496 = heff_field(v_x2_2494, 1);
    V v_ru_24x2_2494_24MkPair = heff_take_reuse_n(v_x2_2494, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2494_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2490, v_x_2495}), v_n_2496});
  }
  default: return heff_nomatch(v_x2_2494);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam11(V self, V *args) {
  V v_n_24100 = args[0];
  V v_m_2499 = heff_env(self)[0];
  V v_g_2497 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24101 = heff_tr(heff_call(v_m_2499, 1, (V[]){v_n_24100}));
  switch (heff_tag_of(v_x2_24101)) {
  case TAG_MkPair: {
    V v_x_24102 = heff_field(v_x2_24101, 0);
    V v_n_24103 = heff_field(v_x2_24101, 1);
    V v_ru_24x2_24101_24MkPair = heff_take_reuse_n(v_x2_24101, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24101_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2497, v_x_24102}), v_n_24103});
  }
  default: return heff_nomatch(v_x2_24101);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam12(V self, V *args) {
  V v_n_24105 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24105});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam13(V self, V *args) {
  V v_n_24107 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24107});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam14(V self, V *args) {
  V v_n_24109 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24109});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam15(V self, V *args) {
  V v_n_24111 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24111});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam16(V self, V *args) {
  V v_n_24114 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24114});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam17(V self, V *args) {
  V v_n_24116 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24116});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam18(V self, V *args) {
  V v_n_24117 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_24117});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam19(V self, V *args) {
  V v_n_24120 = args[0];
  V v_m_24119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24121 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_n_24120}));
  switch (heff_tag_of(v_x2_24121)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_field(v_x2_24121, 0);
    V v_n_24123 = heff_field(v_x2_24121, 1);
    V v_ru_24x2_24121_24MkPair = heff_take_reuse_n(v_x2_24121, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24121_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24122}), v_n_24123});
  }
  default: return heff_nomatch(v_x2_24121);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam20(V self, V *args) {
  V v_n_24128 = args[0];
  V v_m_24127 = heff_env(self)[0];
  V v_b_24126 = heff_env(self)[1];
  V v_xs_24124 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24129 = heff_tr(heff_call(v_m_24127, 1, (V[]){v_n_24128}));
  V v_x2_24132;
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_n_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    v_x2_24132 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_24129_24MkPair, v_x_24130, v_n_24131));
    break;
  }
  default: heff_nomatch(v_x2_24129);
  }
  switch (heff_tag_of(v_x2_24132)) {
  case TAG_MkPair: {
    V v_x_24133 = heff_field(v_x2_24132, 0);
    V v_n_24134 = heff_field(v_x2_24132, 1);
    V v_ru_24x2_24132_24MkPair = heff_take_reuse_n(v_x2_24132, 3ULL, 2);
    V v_m_24135 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_b_24126));
    V v_x2_24136 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_n_24134}));
    V v_x2_24139;
    switch (heff_tag_of(v_x2_24136)) {
    case TAG_MkPair: {
      V v_x_24137 = heff_field(v_x2_24136, 0);
      V v_n_24138 = heff_field(v_x2_24136, 1);
      V v_ru_24x2_24136_24MkPair = heff_take_reuse_n(v_x2_24136, 3ULL, 2);
      v_x2_24139 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_24136_24MkPair, v_x_24137, v_n_24138));
      break;
    }
    default: heff_nomatch(v_x2_24136);
    }
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_n_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24132_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24124, v_x_24133, v_x_24140}), v_n_24141});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24132);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam21(V self, V *args) {
  V v_n_24144 = args[0];
  V v_m_24143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24145 = heff_tr(heff_call(v_m_24143, 1, (V[]){v_n_24144}));
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_n_24147 = heff_field(v_x2_24145, 1);
    V v_ru_24x2_24145_24MkPair = heff_take_reuse_n(v_x2_24145, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24145_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24146}), v_n_24147});
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_lam22(V self, V *args) {
  V v_n_24151 = args[0];
  V v_m_24150 = heff_env(self)[0];
  V v_x_24148 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24152 = heff_tr(heff_call(v_m_24150, 1, (V[]){v_n_24151}));
  V v_x2_24155;
  switch (heff_tag_of(v_x2_24152)) {
  case TAG_MkPair: {
    V v_x_24153 = heff_field(v_x2_24152, 0);
    V v_n_24154 = heff_field(v_x2_24152, 1);
    V v_ru_24x2_24152_24MkPair = heff_take_reuse_n(v_x2_24152, 3ULL, 2);
    v_x2_24155 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24x2_24152_24MkPair, v_x_24153, v_n_24154));
    break;
  }
  default: heff_nomatch(v_x2_24152);
  }
  switch (heff_tag_of(v_x2_24155)) {
  case TAG_MkPair: {
    V v_x_24156 = heff_field(v_x2_24155, 0);
    V v_n_24157 = heff_field(v_x2_24155, 1);
    V v_ru_24x2_24155_24MkPair = heff_take_reuse_n(v_x2_24155, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24155_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24148, v_x_24156}), v_n_24157});
  }
  default: return heff_nomatch(v_x2_24155);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam7(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry, 6, 0};

V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_e_243, V v_d_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_x_246 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_a_247 = heff_strCompare_lent(v_x_246, v_lit_241, 0);
    if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
      heff_drop(v_lit_242);
      heff_drop(v_a_247);
      return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EVar, 1, (V[]){v_x_246}));
    } else {
      if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
        heff_drop(v_x_246);
        return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EVar, 1, (V[]){v_lit_242}));
      } else {
        heff_drop(v_lit_242);
        return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EVar, 1, (V[]){v_x_246}));
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_243, 0);
    V v_b_2410 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_cell_2411 = heff_tag_at_n(v_ru_24e_243_24ELam, TAG_ELam, 2, (V[]){v_xs_249, heff_hole()});
    V v_u_2412 = heff_setField(v_d_244, v_i_245, heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2410;
    V t_4 = v_cell_2411;
    V t_5 = MK_INT(1LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_243, 0);
    V v_args_2414 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2415 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_f_2413));
    V v_t_2417 = (g_list_2emap_24tok2(v_ru_24e_243_24EApp, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam0, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2414));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2415, v_t_2417}));
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_e_243, 0);
    V v_a_2419 = heff_field(v_e_243, 1);
    V v_b_2420 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2419));
    V v_cell_2422 = heff_tag_at_n(v_ru_24e_243_24ELet, TAG_ELet, 3, (V[]){v_x_2418, v_t_2421, heff_hole()});
    V v_u_2423 = heff_setField(v_d_244, v_i_245, heff_dup(v_cell_2422));
    heff_drop(v_u_2423);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2420;
    V t_4 = v_cell_2422;
    V t_5 = MK_INT(2LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_e_243, 0);
    V v_ts_2425 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24tok2(v_ru_24e_243_24ERecord, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam1, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_fs_2424));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2430, v_ts_2425}));
  }
  case TAG_EProj: {
    V v_e2_2431 = heff_field(v_e_243, 0);
    V v_l_2432 = heff_field(v_e_243, 1);
    V v_sh_2433 = heff_field(v_e_243, 2);
    V v_t_2434 = heff_field(v_e_243, 3);
    heff_take_n(v_e_243, 15ULL, 4);
    V v_t_2435 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, v_lit_242, v_e2_2431));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2435, v_l_2432, v_sh_2433, v_t_2434}));
  }
  case TAG_ETag: {
    V v_t_2436 = heff_field(v_e_243, 0);
    V v_args_2437 = heff_field(v_e_243, 1);
    V v_ts_2438 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam2, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2437));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2436, v_t_2440, v_ts_2438}));
  }
  case TAG_EMatch: {
    V v_s_2441 = heff_field(v_e_243, 0);
    V v_arms_2442 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2443 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_s_2441));
    V v_t_2449 = (g_list_2emap_24tok2(v_ru_24e_243_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam3, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_arms_2442));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2443, v_t_2449}));
  }
  case TAG_EPrim: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EPrimCall: {
    V v_p_2451 = heff_field(v_e_243, 0);
    V v_args_2452 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2454 = (g_list_2emap_24tok2(v_ru_24e_243_24EPrimCall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam4, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2452));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2451, v_t_2454}));
  }
  case TAG_ECall: {
    V v_g_2455 = heff_field(v_e_243, 0);
    V v_args_2456 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2458 = (g_list_2emap_24tok2(v_ru_24e_243_24ECall, heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam5, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_args_2456));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2455, v_t_2458}));
  }
  case TAG_EInt: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EFloat: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EStr: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EBytes: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EFixed: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EFloat32: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EAbandon: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  case TAG_EBool: {
    V v_c_2466 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2468 = (g_heff_2ecompile_2eir_2econdMap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam6, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_c_2466));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EBool, 1, (V[]){v_t_2468}));
  }
  case TAG_ESet: {
    V v_xs_2469 = heff_field(v_e_243, 0);
    V v_a_2470 = heff_field(v_e_243, 1);
    V v_b_2471 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ESet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2472 = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(v_lit_240, v_lit_241, heff_dup(v_lit_242), v_a_2470));
    V v_cell_2473 = heff_tag_at_n(v_ru_24e_243_24ESet, TAG_ESet, 3, (V[]){v_xs_2469, v_t_2472, heff_hole()});
    V v_u_2474 = heff_setField(v_d_244, v_i_245, heff_dup(v_cell_2473));
    heff_drop(v_u_2474);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_b_2471;
    V t_4 = v_cell_2473;
    V t_5 = MK_INT(2LL);
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_e_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2475 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V v_t_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam7, 1, 3, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241), v_lit_242}), v_es_2475));
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_EValues, 1, (V[]){v_t_2477}));
  }
  case TAG_EFix: {
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, v_i_245, v_e_243);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps(a0, a1, a[2], a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam0(V self, V *args) {
  V v_a_2416 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2416; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_p_2426, 0);
    V v_e2_2428 = heff_field(v_p_2426, 1);
    V v_ru_24p_2426_24MkPair = heff_take_reuse_n(v_p_2426, 3ULL, 2);
    V v_t_2429 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_e2_2428; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_at_n(v_ru_24p_2426_24MkPair, TAG_MkPair, 2, (V[]){v_l_2427, v_t_2429});
  }
  default: return heff_nomatch(v_p_2426);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2439; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam3(V self, V *args) {
  V v_a_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_field(v_a_2444, 0);
    V v_vs_2446 = heff_field(v_a_2444, 1);
    V v_b_2447 = heff_field(v_a_2444, 2);
    V v_ru_24a_2444_24MkArm = heff_take_reuse_n(v_a_2444, 7ULL, 3);
    V v_t_2448 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_b_2447; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
    return heff_tag_at_n(v_ru_24a_2444_24MkArm, TAG_MkArm, 3, (V[]){v_t_2445, v_vs_2446, v_t_2448});
  }
  default: return heff_nomatch(v_a_2444);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam4(V self, V *args) {
  V v_a_2453 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2453; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam5(V self, V *args) {
  V v_a_2457 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2457; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam6(V self, V *args) {
  V v_a_2467 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2467; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697_24dps_lam7(V self, V *args) {
  V v_a_2476 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_a_2476; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s387161813x704729697(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); heff_drop(v_lit_241); r_; });
}