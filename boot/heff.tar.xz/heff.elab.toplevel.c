// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Anonymous 24551
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BDelayedBy 11524
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_Catch 6517
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ExplicitParam 63083
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_ImplicitParam 51130
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SetField 47531
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_dflt 9576017
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_scope 310622830
#define LBL_scrutinee 73860976
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_name__key__prim__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_entry, LBL_failed};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__entry[] = {LBL_span, LBL_entry};
static uint32_t shape_span__name__typ__implicit[] = {LBL_span, LBL_name, LBL_typ, LBL_implicit};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2ebind_24s935789828x1526377372(V, V, V);
V g_co_2ebind_24s935789828x1526377372_entry(V self, V *a);
extern Clo g_co_2ebind_24s935789828x1526377372_clo;
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void);
V g_heff_2ecompile_2eprims_2eprims_get(void);
V g_heff_2eelab_2eclauses_2ecaseTreeOf(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1023056612x824831407(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1023056612x824831407_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1023056612x824831407_clo;
V g_heff_2eelab_2eclauses_2edesugar(V, V, V, V);
V g_heff_2eelab_2eclauses_2edesugar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edesugar_clo;
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
V g_heff_2eelab_2eenvironment_2emodify(V, V, V);
V g_heff_2eelab_2eenvironment_2emodify_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2emodify_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2ememoed_2edecode(V);
V g_heff_2eelab_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2edecode_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2easSmall(V, V);
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2easSmall_clo;
V g_heff_2eelab_2erules_2eautoRec(V, V, V);
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eautoRec_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2efunctionIntroSyn(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2erules_2enumLitSyn(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecordFormation(V);
V g_heff_2eelab_2erules_2erecordFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordFormation_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2esumIntro(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntro_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V);
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(V);
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V);
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V);
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eargBinding(V);
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eargBinding_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echeckUnsolved(V, V, V);
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkHeadOf(V, V);
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2edefineD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edefineD_clo;
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2edoPat(V);
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoPat_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eequationsBody(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo;
V g_heff_2eelab_2etoplevel_2eequationsD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_clo;
V g_heff_2eelab_2etoplevel_2eerrEntry(V, V, V);
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo;
V g_heff_2eelab_2etoplevel_2eflatPat(V);
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eflatPat_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2elamsOf(V, V);
V g_heff_2eelab_2etoplevel_2elamsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elamsOf_clo;
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V, V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2emetasInV(V, V);
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2emetasInV_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn(V);
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo;
V g_heff_2eelab_2etoplevel_2enominalTyp(V);
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
V g_heff_2eelab_2etoplevel_2eparamsOf(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsOf_clo;
V g_heff_2eelab_2etoplevel_2epatName(V);
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epatName_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2eshownV(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eshownV_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2etagSynonym(V);
V g_heff_2eelab_2etoplevel_2etagSynonym_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSynonym_clo;
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2eelab_2etoplevel_2etheoryD(V, V, V);
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etheoryD_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etopGo(V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL(V, V);
V g_heff_2eelab_2etoplevel_2etraverseEL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2etoplevel_2ewatchPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo;
V g_heff_2eelab_2etoplevel_2ewatchSyn(V);
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithOne(V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTermF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTermF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_strEq_c(heff_dup(v_x_245), v_k_241)) {
      heff_drop(v_x_245);
      return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_SLocal, 1, (V[]){v_d_242});
    } else {
      heff_drop(v_d_242);
      return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_SGlobal, 1, (V[]){v_x_245});
    }
  }
  case TAG_SCode: {
    V v_a_247 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_248 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_247}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_t_243, 0);
    V v_a_2410 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2411 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_249}));
    V v_t_2412 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_2410}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2411, v_t_2412});
  }
  case TAG_SLam: {
    V v_dom_2413 = heff_field(v_t_243, 0);
    V v_it2_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    switch (heff_tag_of(v_it2_2414)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_it2_2414, 0);
      V v_b_2416 = heff_field(v_it2_2414, 1);
      heff_take_n(v_it2_2414, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2413}));
      V v_t_2418 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2417, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2418})});
    }
    case TAG_AbsConst: {
      V v_b_2419 = heff_field(v_it2_2414, 0);
      heff_take_n(v_it2_2414, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2413}));
      V v_t_2421 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2419}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2420, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2421})});
    }
    default: return heff_nomatch(v_it2_2414);
    }
  }
  case TAG_SCons: {
    V v_c_2422 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_f_2423 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2424 = heff_take_field(v_c_2422, 2);
    V v_t_2427 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2424)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam0, 1, 2, (V[]){v_xs_2424, v_f_2423}));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_n(v_c_2422, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2428});
  }
  case TAG_SProj: {
    V v_e_2429 = heff_field(v_t_243, 0);
    V v_l_2430 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2431 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2429}));
    return heff_tag_at_n(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2431, v_l_2430});
  }
  case TAG_STag: {
    V v_tg_2432 = heff_field(v_t_243, 0);
    V v_as_2433 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_f_2434 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2433)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam1, 1, 2, (V[]){v_as_2433, v_f_2434}));
    return heff_tag_at_n(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_tg_2432, v_t_2437});
  }
  case TAG_SMatch: {
    V v_e_2438 = heff_field(v_t_243, 0);
    V v_cs_2439 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2440 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2438}));
    V v_xs_2441 = heff_take_field(v_cs_2439, 2);
    V v_t_2448 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2441)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam2, 1, 3, (V[]){v_xs_2441, v_d_242, v_r_240}));
    V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_n(v_cs_2439, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2440, v_t_2449});
  }
  case TAG_SSpecialize: {
    V v_e_2450 = heff_field(v_t_243, 0);
    V v_l_2451 = heff_field(v_t_243, 1);
    V v_v_2452 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_k_241);
    V v_t_2453 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2450}));
    V v_t_2454 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2452}));
    return heff_tag_at_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2453, v_l_2451, v_t_2454});
  }
  case TAG_SIs: {
    V v_e_2455 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_2456 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2455}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2456});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2457 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_2458 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2457}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2458});
  }
  case TAG_SFix: {
    V v_dom_2459 = heff_field(v_t_243, 0);
    V v_it2_2460 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    switch (heff_tag_of(v_it2_2460)) {
    case TAG_MkAbs: {
      V v_x_2461 = heff_field(v_it2_2460, 0);
      V v_b_2462 = heff_field(v_it2_2460, 1);
      heff_take_n(v_it2_2460, 3ULL, 2);
      V v_t_2463 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2459}));
      V v_t_2464 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2462}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2463, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2461, v_t_2464})});
    }
    case TAG_AbsConst: {
      V v_b_2465 = heff_field(v_it2_2460, 0);
      heff_take_n(v_it2_2460, 1ULL, 1);
      V v_t_2466 = heff_tr(heff_apply(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2459}));
      V v_t_2467 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2465}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2466, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2467})});
    }
    default: return heff_nomatch(v_it2_2460);
    }
  }
  case TAG_SImplicit: {
    V v_x_2468 = heff_field(v_t_243, 0);
    V v_e_2469 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2470 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2469}));
    return heff_tag_at_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2468, v_t_2470});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2472 = heff_field(v_t_243, 0);
    V v_ix_2473 = heff_field(v_t_243, 1);
    V v_ty2_2474 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_k_241);
    V v_t_2475 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty2_2474}));
    return heff_tag_at_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2472, v_ix_2473, v_t_2475});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eselfTermF(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args) {
  V v_i_2425 = args[0];
  V v_xs_2424 = heff_env(self)[0];
  V v_f_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_arrayIndex(v_xs_2424, v_i_2425);
  V f_ = v_f_2423;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args) {
  V v_i_2435 = args[0];
  V v_as_2433 = heff_env(self)[0];
  V v_f_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_arrayIndex(v_as_2433, v_i_2435);
  V f_ = v_f_2434;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args) {
  V v_i_2442 = args[0];
  V v_xs_2441 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2443 = heff_arrayIndex(v_xs_2441, v_i_2442);
  switch (heff_tag_of(v_p_2443)) {
  case TAG_MkPair: {
    V v_xs_2444 = heff_field(v_p_2443, 0);
    V v_b_2445 = heff_field(v_p_2443, 1);
    V v_ru_24p_2443_24MkPair = heff_take_reuse_n(v_p_2443, 3ULL, 2);
    V v_t_2446 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2444)));
    V v_t_2447 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_t_2446, v_b_2445}));
    return heff_tag_at_n(v_ru_24p_2443_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2444, v_t_2447});
  }
  default: return heff_nomatch(v_p_2443);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam3(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTypeF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTypeF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_it3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_it3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_it3_249, 0);
      V v_b_2413 = heff_field(v_it3_249, 1);
      heff_take_n(v_it3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_it3_249, 0);
      heff_take_n(v_it3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_it3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_f_2422 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2423 = heff_take_field(v_ft_2420, 2);
    V v_t_2426 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2423)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam0, 1, 2, (V[]){v_xs_2423, v_f_2422}));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_n(v_ft_2420, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2427, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2429 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_f_2433 = heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam1, 1, 1, (V[]){v_f_2429});
    V v_xs_2434 = heff_take_field(v_vs_2428, 2);
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2434)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam3, 1, 2, (V[]){v_xs_2434, v_f_2433}));
    V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_n(v_vs_2428, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2438});
  }
  case TAG_SIsTy: {
    V v_a_2439 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2440 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2439}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2440});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    V v_a_2441 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2442 = heff_tr(heff_apply(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2441}));
    return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2442});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eselfTypeF(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_xs_2423 = heff_env(self)[0];
  V v_f_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_arrayIndex(v_xs_2423, v_i_2424);
  V f_ = v_f_2422;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = v_f_2429;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args) {
  V v_xs_2430 = args[0];
  V v_f_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam2, 1, 2, (V[]){v_xs_2430, v_f_2429}));
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam3(V self, V *args) {
  V v_i_2435 = args[0];
  V v_xs_2434 = heff_env(self)[0];
  V v_f_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_arrayIndex(v_xs_2434, v_i_2435);
  V f_ = v_f_2433;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfWalk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eselfWalk(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam1, 2, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eselfWalk(a[0]);
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return (g_heff_2eelab_2etoplevel_2eselfTermF(v_t_243, v_k_240, v_d_241, v_t_242));
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return ({ V a_0 = v_t_246; V a_1 = v_k_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eselfTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalSyn(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2enominalSyn(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_res_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  V v_x1_2412 = heff_tr(heff_apply(heff_get_n(v_res_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2416});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_res_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    V v_ru_24x_247_24MkPair = heff_take_reuse_n(v_x_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_res_248, 0))});
    V v_t_2417 = heff_tag_at_n(v_ru_24x_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam3, 1, 1, (V[]){v_res_248})}), v_a_249});
    V f_ = v_k_246;
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkSyn: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_n(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_apply(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam1, 2, 1, (V[]){v_c_244});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalChk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalChk(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam0, 2, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2enominalChk(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args) {
  V v_u_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  V v_x1_2411 = heff_tr(heff_apply(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2415});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_x_248, 0))});
  V f_ = v_k_247;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam3, 1, 1, (V[]){v_x_248})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam2, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_245;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkChk: {
    V v_f_243 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_244 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_n(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_245 = heff_tr(heff_apply(v_f_243, 2, (V[]){v_t_244, v_a_242}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam1, 2, 1, (V[]){v_c_245});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalTyp_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalTyp(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2enominalTyp(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args) {
  V v_u_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  V v_x1_2410 = heff_tr(heff_apply(heff_get_n(v_x_247, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2414});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_SIsTy, 1, (V[]){heff_dup(heff_rfield(v_x_247, 0))});
  V f_ = v_k_246;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam3, 1, 1, (V[]){v_x_247})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_n(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_apply(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam1, 2, 1, (V[]){v_c_244});
}
Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echecksOnly_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echecksOnly(V v_c_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_c_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_c_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_CInf: {
    V v_i_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(v_i_244));
    V v_x1_246 = heff_get_n(v_t_245, 0, 2);
    V v_t_249;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_At: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 2);
      v_t_249 = v_x_247;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_IVar: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IRune: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_ISpec: {
      heff_take_n(v_t_249, 0ULL, 4);
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      heff_take_n(v_t_249, 0ULL, 4);
      return NTAG(TAG_True);
    }
    case TAG_IInvalid: {
      heff_take_n(v_t_249, 0ULL, 2);
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_ILitEq: {
      heff_take_n(v_t_249, 0ULL, 4);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_CType: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_CLam: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_CImplicitLam: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_CAnnLam: {
    heff_take_n(v_t_243, 0ULL, 4);
    return NTAG(TAG_True);
  }
  case TAG_CTag: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_CStruct: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_CMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_CLetIn: {
    heff_take_n(v_t_243, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_CLocal: {
    heff_take_n(v_t_243, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_CAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_CNominal: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2echecksOnly(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveringChk_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2erecoveringChk(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tr(heff_apply(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam0, 1, 1, (V[]){heff_dup(v_hd_241)})}));
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_244, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam1, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_247}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam2, 1, 1, (V[]){v_k_242})});
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveringChk(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam3(V self, V *args) {
  V v_e_2411 = args[0];
  V v_a_2412 = args[1];
  V v_hd_2413 = args[2];
  V v_k2_2414 = args[3];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2411);
  heff_drop(v_a_2412);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_d_2410})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_d_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    V v_t_2418 = ({ V b_0 = heff_tag_at_n(v_ru_24x_249_24Left, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam3, 4, 1, (V[]){v_d_2410})}); V r_ = (g_heff_2eelab_2erules_2erecovering(b_0)); heff_drop(b_0); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_c_2419 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2420 = ({ V a_0 = v_c_2419; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_c_2419); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2etoplevel_2etraverseEL(v_f_240, v_xs_245));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str0, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str1, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str2, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str3, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str4, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str5, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str6, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str7, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2epatName_str8, 54, (97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 111, 102, 32, 97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 111, 114, 32, 97, 32, 110, 97, 109, 101));
V g_heff_2eelab_2etoplevel_2epatName_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam9(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epatName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epatName_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2epatName(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam0, 2, 1, (V[]){heff_dup(v_x_243)});
    }
    case TAG_PatTag: {
      V v_sp_2411;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2410 = heff_field(v_p_240, 1);
        v_sp_2411 = heff_dup(v_s_2410);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam1, 2, 1, (V[]){v_sp_2411});
    }
    case TAG_PatOp: {
      V v_sp_2423;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_p_240, 1);
        v_sp_2423 = heff_dup(v_s_2422);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam2, 2, 1, (V[]){v_sp_2423});
    }
    case TAG_PatInt: {
      V v_sp_2433;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_p_240, 1);
        v_sp_2433 = heff_dup(v_s_2432);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam3, 2, 1, (V[]){v_sp_2433});
    }
    case TAG_PatFloat: {
      V v_sp_2443;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2442 = heff_field(v_p_240, 1);
        v_sp_2443 = heff_dup(v_s_2442);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam4, 2, 1, (V[]){v_sp_2443});
    }
    case TAG_PatString: {
      V v_sp_2453;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2452 = heff_field(v_p_240, 1);
        v_sp_2453 = heff_dup(v_s_2452);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam5, 2, 1, (V[]){v_sp_2453});
    }
    case TAG_PatRune: {
      V v_sp_2463;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_p_240, 1);
        v_sp_2463 = heff_dup(v_s_2462);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam6, 2, 1, (V[]){v_sp_2463});
    }
    case TAG_PatRecord: {
      V v_sp_2473;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2472 = heff_field(v_p_240, 1);
        v_sp_2473 = heff_dup(v_s_2472);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam7, 2, 1, (V[]){v_sp_2473});
    }
    case TAG_PatWord: {
      V v_sp_2483;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2482 = heff_field(v_p_240, 1);
        v_sp_2483 = heff_dup(v_s_2482);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam8, 2, 1, (V[]){v_sp_2483});
    }
    case TAG_PatAs: {
      V v_sp_2495;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2494 = heff_field(v_p_240, 1);
        v_sp_2495 = heff_dup(v_s_2494);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam9, 2, 1, (V[]){v_sp_2495});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2epatName(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2epatName_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_sp_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str0), v_sp_2411, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_sp_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str1), v_sp_2423, NTAG(TAG_Nothing)});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_apply(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2428}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_sp_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str2), v_sp_2433, NTAG(TAG_Nothing)});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tr(heff_apply(heff_take_field(v_hd_2434, 2), 1, (V[]){v_t_2438}));
  V f_ = heff_get_n(v_hd_2434, 1, 3);
  args[0] = v_t_2439;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam4(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k2_2445 = args[1];
  V v_sp_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str3), v_sp_2443, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_take_field(v_hd_2444, 2), 1, (V[]){v_t_2448}));
  V f_ = heff_get_n(v_hd_2444, 1, 3);
  args[0] = v_t_2449;
  args[1] = v_k2_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam5(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_sp_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str4), v_sp_2453, NTAG(TAG_Nothing)});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_apply(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2458}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2459;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam6(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_sp_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str5), v_sp_2463, NTAG(TAG_Nothing)});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_apply(heff_take_field(v_hd_2464, 2), 1, (V[]){v_t_2468}));
  V f_ = heff_get_n(v_hd_2464, 1, 3);
  args[0] = v_t_2469;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam7(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k2_2475 = args[1];
  V v_sp_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str6), v_sp_2473, NTAG(TAG_Nothing)});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_apply(heff_take_field(v_hd_2474, 2), 1, (V[]){v_t_2478}));
  V f_ = heff_get_n(v_hd_2474, 1, 3);
  args[0] = v_t_2479;
  args[1] = v_k2_2475;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam8(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k2_2485 = args[1];
  V v_sp_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str7), v_sp_2483, NTAG(TAG_Nothing)});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tr(heff_apply(heff_take_field(v_hd_2484, 2), 1, (V[]){v_t_2488}));
  V f_ = heff_get_n(v_hd_2484, 1, 3);
  args[0] = v_t_2489;
  args[1] = v_k2_2485;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam9(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k2_2497 = args[1];
  V v_sp_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str8), v_sp_2495, NTAG(TAG_Nothing)});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tr(heff_apply(heff_take_field(v_hd_2496, 2), 1, (V[]){v_t_24100}));
  V f_ = heff_get_n(v_hd_2496, 1, 3);
  args[0] = v_t_24101;
  args[1] = v_k2_2497;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2epatName(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str0, 1, (95));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str1, 1, (95));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str2, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str3, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str4, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str5, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str6, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str7, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str8, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str9, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edoPat_str10, 75, (97, 32, 96, 99, 97, 115, 101, 96, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 58, 32, 97, 32, 116, 97, 103, 32, 97, 112, 112, 108, 105, 101, 100, 32, 116, 111, 32, 112, 97, 116, 116, 101, 114, 110, 115, 44, 32, 97, 32, 108, 105, 116, 101, 114, 97, 108, 44, 32, 111, 114, 32, 96, 95, 96));
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edoPat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoPat(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_240)));
  V v_it_242 = heff_get_n(v_t_241, 0, 2);
  switch (heff_tag_of(v_it_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_PatVar: {
      V v_it11_245 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      if (heff_strEq_c(v_it11_245, ((V)&g_heff_2eelab_2etoplevel_2edoPat_str0))) {
        heff_drop(v_p_240);
        return ((V)&g_heff_2eelab_2etoplevel_2edoPat_lam0_clo);
      } else {
        V v_sp_2412;
        switch (heff_tag_of(v_p_240)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_p_240, 1);
          heff_take_n(v_p_240, 2ULL, 2);
          v_sp_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_p_240);
        }
        return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam1, 2, 1, (V[]){v_sp_2412});
      }
    }
    case TAG_PatTag: {
      V v_x_2419 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 3);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_240));
      V v_c_2423 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(heff_get_n(v_t_2422, 1, 2)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam2, 2, 2, (V[]){v_c_2423, v_x_2419});
    }
    case TAG_PatOp: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_2432;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam4, 2, 1, (V[]){v_sp_2432});
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2442;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam5, 2, 1, (V[]){v_sp_2442});
    }
    case TAG_PatFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2452;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2451 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam6, 2, 1, (V[]){v_sp_2452});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2462;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2461 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2462 = v_s_2461;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam7, 2, 1, (V[]){v_sp_2462});
    }
    case TAG_PatRune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2472;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2471 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2472 = v_s_2471;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam8, 2, 1, (V[]){v_sp_2472});
    }
    case TAG_PatRecord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2482;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2481 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2482 = v_s_2481;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam9, 2, 1, (V[]){v_sp_2482});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2492;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2491 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam10, 2, 1, (V[]){v_sp_2492});
    }
    case TAG_PatAs: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_24104;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_24103 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_24104 = v_s_24103;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam11, 2, 1, (V[]){v_sp_24104});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoPat(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2edoPat_str1), NTAG(TAG_Nil)});
  V f_ = v_k_248;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_sp_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str2), v_sp_2412, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam3, 1, 2, (V[]){v_k_2425, v_x_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_sp_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str3), v_sp_2432, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_apply(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2438;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_sp_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str4), v_sp_2442, NTAG(TAG_Nothing)});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_apply(heff_take_field(v_hd_2443, 2), 1, (V[]){v_t_2447}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2448;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_sp_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str5), v_sp_2452, NTAG(TAG_Nothing)});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_apply(heff_take_field(v_hd_2453, 2), 1, (V[]){v_t_2457}));
  V f_ = heff_get_n(v_hd_2453, 1, 3);
  args[0] = v_t_2458;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k2_2464 = args[1];
  V v_sp_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str6), v_sp_2462, NTAG(TAG_Nothing)});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_apply(heff_take_field(v_hd_2463, 2), 1, (V[]){v_t_2467}));
  V f_ = heff_get_n(v_hd_2463, 1, 3);
  args[0] = v_t_2468;
  args[1] = v_k2_2464;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k2_2474 = args[1];
  V v_sp_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str7), v_sp_2472, NTAG(TAG_Nothing)});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_apply(heff_take_field(v_hd_2473, 2), 1, (V[]){v_t_2477}));
  V f_ = heff_get_n(v_hd_2473, 1, 3);
  args[0] = v_t_2478;
  args[1] = v_k2_2474;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k2_2484 = args[1];
  V v_sp_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str8), v_sp_2482, NTAG(TAG_Nothing)});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_apply(heff_take_field(v_hd_2483, 2), 1, (V[]){v_t_2487}));
  V f_ = heff_get_n(v_hd_2483, 1, 3);
  args[0] = v_t_2488;
  args[1] = v_k2_2484;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k2_2494 = args[1];
  V v_sp_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str9), v_sp_2492, NTAG(TAG_Nothing)});
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tr(heff_apply(heff_take_field(v_hd_2493, 2), 1, (V[]){v_t_2497}));
  V f_ = heff_get_n(v_hd_2493, 1, 3);
  args[0] = v_t_2498;
  args[1] = v_k2_2494;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k2_24106 = args[1];
  V v_sp_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str10), v_sp_24104, NTAG(TAG_Nothing)});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tr(heff_apply(heff_take_field(v_hd_24105, 2), 1, (V[]){v_t_24109}));
  V f_ = heff_get_n(v_hd_24105, 1, 3);
  args[0] = v_t_24110;
  args[1] = v_k2_24106;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eannotatesData_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eannotatesData(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      return NTAG(TAG_False);
    }
    case TAG_IRune: {
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      V v_c_2410 = heff_field(v_x11_241, 0);
      V v_t_2414;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_x_2412 = heff_field(v_c_2410, 0);
        v_t_2414 = heff_dup(v_x_2412);
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      switch (heff_tag_of(v_t_2414)) {
      case TAG_CInf: {
        heff_take_n(v_t_2414, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_CType: {
        heff_take_n(v_t_2414, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_CLam: {
        heff_take_n(v_t_2414, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_t_2414, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_CAnnLam: {
        heff_take_n(v_t_2414, 0ULL, 4);
        return NTAG(TAG_False);
      }
      case TAG_CTag: {
        heff_take_n(v_t_2414, 0ULL, 3);
        return NTAG(TAG_True);
      }
      case TAG_CStruct: {
        heff_take_n(v_t_2414, 0ULL, 1);
        return NTAG(TAG_True);
      }
      case TAG_CMatch: {
        heff_take_n(v_t_2414, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_CLetIn: {
        heff_take_n(v_t_2414, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_CLocal: {
        heff_take_n(v_t_2414, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_CAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_CNominal: {
        heff_take_n(v_t_2414, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    case TAG_ISpec: {
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      return NTAG(TAG_False);
    }
    case TAG_IInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      return NTAG(TAG_False);
    }
    case TAG_ILitEq: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eannotatesData(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2421;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        v_t_2421 = NTAG(TAG_True);
        break;
      }
      case TAG_PatTag: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatOp: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatInt: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatFloat: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatString: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatRune: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatRecord: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatWord: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatAs: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2eflatPat_str0, 1, (95));
Clo g_heff_2eelab_2etoplevel_2eflatPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eflatPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eflatPat(V v_gr_240) {
top: ;
  V v_t_241 = heff_take_field(v_gr_240, 0);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 2);
    v_t_244 = v_x_242;
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_PatVar: {
    V v_x_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    if (heff_strEq_c(v_x_245, ((V)&g_heff_2eelab_2etoplevel_2eflatPat_str0))) {
      V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_gr_240, 1, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_intEq(v_t_247, MK_INT(0LL));
    } else {
      heff_drop_rec(v_gr_240, 2);
      return NTAG(TAG_False);
    }
  }
  case TAG_PatTag: {
    heff_take_n(v_t_244, 0ULL, 3);
    return ({ V b_0 = heff_get_n(v_gr_240, 1, 2); V r_ = (g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(b_0)); heff_drop(b_0); r_; });
  }
  case TAG_PatOp: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRune: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatWord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eflatPat(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2etagSpans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpans_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSpans(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 2);
        V v_acc_247 = (g_heff_2eelab_2etoplevel_2etagSpans(v_rest_242));
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_245));
        V v_it_249 = heff_get_n(v_t_248, 0, 2);
        switch (heff_tag_of(v_it_249)) {
        case TAG_At: {
          V v_it1_2410 = heff_field(v_it_249, 0);
          V v_tsp_2411 = heff_field(v_it_249, 1);
          heff_take_n(v_it_249, 3ULL, 2);
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_PatVar: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatTag: {
            V v_x_2413 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 3);
            return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_tsp_2411}), v_acc_247});
          }
          case TAG_PatOp: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatInt: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatFloat: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatString: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRune: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRecord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatWord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatAs: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          default: return heff_nomatch(v_it1_2410);
          }
        }
        default: return heff_nomatch(v_it_249);
        }
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSpans(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2elamsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elamsOf_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elamsOf(V v_n_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_SLocal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SCode: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLam: {
    V v_b2_248 = heff_field(v_b_241, 1);
    heff_take_n(v_b_241, 2ULL, 2);
    switch (heff_tag_of(v_b2_248)) {
    case TAG_MkAbs: {
      V v_b22_2410 = heff_field(v_b2_248, 1);
      heff_take_n(v_b2_248, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b22_2410;
      v_n_240 = t_0;
      v_b_241 = t_1;
      goto top;
    }
    case TAG_AbsConst: {
      V v_b21_2411 = heff_field(v_b2_248, 0);
      heff_take_n(v_b2_248, 1ULL, 1);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b21_2411;
      v_n_240 = t_0;
      v_b_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_b2_248);
    }
  }
  case TAG_SCons: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_STag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SSpecialize: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SIs: {
    V v_b1_2422 = heff_field(v_b_241, 0);
    heff_take_n(v_b_241, 1ULL, 1);
    V t_0 = v_n_240;
    V t_1 = v_b1_2422;
    v_n_240 = t_0;
    v_b_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SRec: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SImplicit: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SMetaApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitString: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitRune: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2eelab_2etoplevel_2elamsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elamsOf(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eparamsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eparamsOf_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eparamsOf(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SU: {
    V v_ru_24x3_242_24SU = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SU, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SDecode: {
    V v_ru_24x3_242_24SDecode = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SDecode, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SFunction: {
    V v_cod_247 = heff_field(v_x3_242, 2);
    V v_x34_248 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 12ULL, 5);
    switch (heff_tag_of(v_x34_248)) {
    case TAG_Expl: {
      V v_t_2413;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2411 = heff_field(v_cod_247, 1);
        heff_take_n(v_cod_247, 2ULL, 2);
        v_t_2413 = v_t_2411;
        break;
      }
      case TAG_AbsConst: {
        V v_t_2412 = heff_field(v_cod_247, 0);
        heff_take_n(v_cod_247, 1ULL, 1);
        v_t_2413 = v_t_2412;
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V t_0 = v_i_240;
      V t_1 = heff_intAdd(v_e_241, MK_INT(1LL));
      V t_2 = v_t_2413;
      v_i_240 = t_0;
      v_e_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Impl: {
      if (heff_intLt_c(MK_INT(0LL), heff_dup(v_e_241))) {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_cod_247);
        return NTAG(TAG_Nothing);
      } else {
        V v_t_2418;
        switch (heff_tag_of(v_cod_247)) {
        case TAG_MkAbs: {
          V v_t_2416 = heff_field(v_cod_247, 1);
          heff_take_n(v_cod_247, 2ULL, 2);
          v_t_2418 = v_t_2416;
          break;
        }
        case TAG_AbsConst: {
          V v_t_2417 = heff_field(v_cod_247, 0);
          heff_take_n(v_cod_247, 1ULL, 1);
          v_t_2418 = v_t_2417;
          break;
        }
        default: heff_nomatch(v_cod_247);
        }
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_t_2418;
        v_i_240 = t_0;
        v_e_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_Inst: {
      heff_drop(v_i_240);
      heff_drop(v_e_241);
      heff_drop(v_cod_247);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x34_248);
    }
  }
  case TAG_SRecord: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SSum: {
    V v_ru_24x3_242_24SSum = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SSum, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SIsTy: {
    V v_ru_24x3_242_24SIsTy = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SIsTy, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimInt: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimFloat: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimString: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimRune: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimArray: {
    V v_ru_24x3_242_24SPrimArray = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SPrimArray, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SFixed: {
    V v_ru_24x3_242_24SFixed = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SFixed, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eparamsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eparamsOf(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eparamsInOrder_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eparamsInOrder(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_intEq(v_i_241, v_k_240);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SLocal: {
      V v_j_245 = heff_field(v_x31_243, 0);
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_k_240), MK_INT(1LL)), heff_dup(v_i_241));
      if (heff_intEq_c(heff_dup(v_j_245), v_t_246)) {
        V t_0 = v_k_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_i_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_k_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eparamsInOrder(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2eelab_2etoplevel_2etagSynonym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSynonym_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSynonym(V v_ge_240) {
top: ;
  V v_it_241 = (g_heff_2eelab_2etoplevel_2eparamsOf(MK_INT(0LL), MK_INT(0LL), heff_take_field(v_ge_240, 1)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ge_240, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_242 = heff_field(v_it_241, 0);
    V v_ru_24it_241_24Just = heff_take_reuse_n(v_it_241, 1ULL, 1);
    switch (heff_tag_of(v_it1_242)) {
    case TAG_MkPair: {
      V v_i_243 = heff_field(v_it1_242, 0);
      V v_k_244 = heff_field(v_it1_242, 1);
      heff_take_n(v_it1_242, 3ULL, 2);
      V v_it_245 = (g_heff_2eelab_2etoplevel_2elamsOf(MK_INT(0LL), heff_get_n(v_ge_240, 0, 4)));
      switch (heff_tag_of(v_it_245)) {
      case TAG_MkPair: {
        V v_n_246 = heff_field(v_it_245, 0);
        V v_it2_247 = heff_field(v_it_245, 1);
        heff_take_n(v_it_245, 3ULL, 2);
        switch (heff_tag_of(v_it2_247)) {
        case TAG_SLocal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          V v_t_2418 = heff_field(v_it2_247, 0);
          V v_args_2419 = heff_field(v_it2_247, 1);
          heff_take_n(v_it2_247, 3ULL, 2);
          if (heff_intEq_c(v_n_246, heff_intAdd(v_i_243, heff_dup(v_k_244)))) {
            V v_t_2421 = ({ V a_0 = heff_dup(v_k_244); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_args_2419); V r_ = (g_heff_2eelab_2etoplevel_2eparamsInOrder(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            switch (heff_tag_of(v_t_2421)) {
            case TAG_True: {
              return heff_tag_at_n(v_ru_24it_241_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_k_244})});
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_241_24Just, 1);
              heff_drop(v_k_244);
              heff_drop(v_t_2418);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2421);
            }
          } else {
            heff_drop_cell(v_ru_24it_241_24Just, 1);
            heff_drop(v_k_244);
            heff_drop(v_t_2418);
            heff_drop(v_args_2419);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_SMatch: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SOpaque: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_247);
        }
      }
      default: return heff_nomatch(v_it_245);
      }
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2eelab_2etoplevel_2etagSynonym_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSynonym(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_heff_2eelab_2etoplevel_2ehasOpPat(heff_dup(v_x_241)));
    switch (heff_tag_of(v_a_243)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = (g_heff_2eelab_2etoplevel_2ehasOpPat(heff_dup(v_a_244)));
      switch (heff_tag_of(v_a_245)) {
      case TAG_True: {
        v_t_246 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_246 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ehasOpPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ehasOpPat(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatTag: {
    V v_ps_247 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    V v_x1_248 = ({ V a_0 = v_ps_247; V r_ = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(a_0)); heff_drop(v_ps_247); r_; });
    switch (heff_tag_of(v_x1_248)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_PatOp: {
    heff_take_n(v_t_243, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatRune: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    V v_fs_2416 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x1_2417 = ({ V a_0 = v_fs_2416; V r_ = (g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(a_0)); heff_drop(v_fs_2416); r_; });
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  case TAG_PatWord: {
    heff_take_n(v_t_243, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    V v_q_2421 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 4ULL, 3);
    V t_0 = v_q_2421;
    v_p_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ehasOpPat(a[0]);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str0, 17, (110, 111, 32, 115, 117, 99, 104, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str1, 9, (32, 105, 110, 32, 115, 99, 111, 112, 101));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str2, 1, (96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str3, 105, (96, 32, 105, 115, 32, 110, 111, 116, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101, 32, 102, 111, 114, 32, 97, 32, 116, 97, 103, 44, 32, 115, 111, 32, 110, 111, 32, 112, 97, 116, 116, 101, 114, 110, 32, 99, 97, 110, 32, 117, 115, 101, 32, 105, 116, 58, 32, 97, 110, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 105, 110, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 100, 101, 102, 105, 110, 101, 100, 32, 97, 115, 32, 111, 110, 101, 44, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str4, 14, (41, 32, 120, 32, 121, 32, 61, 32, 67, 32, 120, 32, 121, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str5, 1, (96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str6, 105, (96, 32, 105, 115, 32, 110, 111, 116, 32, 97, 110, 111, 116, 104, 101, 114, 32, 110, 97, 109, 101, 32, 102, 111, 114, 32, 97, 32, 116, 97, 103, 44, 32, 115, 111, 32, 110, 111, 32, 112, 97, 116, 116, 101, 114, 110, 32, 99, 97, 110, 32, 117, 115, 101, 32, 105, 116, 58, 32, 97, 110, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 105, 110, 32, 97, 32, 112, 97, 116, 116, 101, 114, 110, 32, 105, 115, 32, 100, 101, 102, 105, 110, 101, 100, 32, 97, 115, 32, 111, 110, 101, 44, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eopPat_str7, 14, (41, 32, 120, 32, 121, 32, 61, 32, 67, 32, 120, 32, 121, 96));
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eopPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eopPat_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eopPat(V v_g_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_it1_242 = heff_dup(heff_field(v_p_241, 0));
    V v_it2_243 = heff_dup(heff_field(v_p_241, 1));
    switch (heff_tag_of(v_it1_242)) {
    case TAG_PatVar: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 6);
      heff_drop(v_it2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam0, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatTag: {
      V v_t_247 = heff_field(v_it1_242, 0);
      V v_tsp_248 = heff_field(v_it1_242, 1);
      V v_args_249 = heff_field(v_it1_242, 2);
      heff_take_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_it2_243);
      V v_c_2411 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam1, 1, 1, (V[]){v_g_240}), v_args_249));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam2, 2, 3, (V[]){v_c_2411, v_t_247, v_tsp_248});
    }
    case TAG_PatOp: {
      V v_x_2422 = heff_field(v_it1_242, 0);
      V v_xsp_2423 = heff_field(v_it1_242, 1);
      V v_args_2424 = heff_field(v_it1_242, 2);
      heff_take_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_it2_243);
      V v_t_2425 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2422), heff_rfield(v_g_240, 2)));
      V v_it_2431;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nothing: {
        V v_t_2426 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2422), heff_rfield(v_g_240, 1)));
        switch (heff_tag_of(v_t_2426)) {
        case TAG_Nothing: {
          v_it_2431 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_e_2427 = heff_field(v_t_2426, 0);
          V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
          v_it_2431 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2422), v_e_2427})});
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        break;
      }
      case TAG_Just: {
        V v_k_2428 = heff_field(v_t_2425, 0);
        V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 1ULL, 1);
        V v_t_2429 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_2428), heff_rfield(v_g_240, 1)));
        switch (heff_tag_of(v_t_2429)) {
        case TAG_Nothing: {
          heff_drop(v_k_2428);
          heff_drop_cell(v_ru_24t_2425_24Just, 1);
          v_it_2431 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_e_2430 = heff_field(v_t_2429, 0);
          heff_take_n(v_t_2429, 1ULL, 1);
          v_it_2431 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2428, v_e_2430})});
          break;
        }
        default: heff_nomatch(v_t_2429);
        }
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      switch (heff_tag_of(v_it_2431)) {
      case TAG_Nothing: {
        heff_drop_rec(v_g_240, 6);
        heff_drop(v_args_2424);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam4, 2, 2, (V[]){v_x_2422, v_xsp_2423});
      }
      case TAG_Just: {
        V v_it1_2439 = heff_field(v_it_2431, 0);
        heff_take_n(v_it_2431, 1ULL, 1);
        switch (heff_tag_of(v_it1_2439)) {
        case TAG_MkPair: {
          V v_ge_2441 = heff_field(v_it1_2439, 1);
          heff_take_n(v_it1_2439, 2ULL, 2);
          V v_it_2442 = (g_heff_2eelab_2etoplevel_2etagSynonym(v_ge_2441));
          switch (heff_tag_of(v_it_2442)) {
          case TAG_Nothing: {
            heff_drop_rec(v_g_240, 6);
            heff_drop(v_args_2424);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam5, 2, 2, (V[]){v_x_2422, v_xsp_2423});
          }
          case TAG_Just: {
            V v_it1_2450 = heff_field(v_it_2442, 0);
            heff_take_n(v_it_2442, 1ULL, 1);
            switch (heff_tag_of(v_it1_2450)) {
            case TAG_MkPair: {
              V v_t_2451 = heff_field(v_it1_2450, 0);
              V v_k_2452 = heff_field(v_it1_2450, 1);
              heff_take_n(v_it1_2450, 3ULL, 2);
              V v_t_2453 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2424));
              if (heff_intEq_c(v_k_2452, v_t_2453)) {
                heff_drop(v_x_2422);
                V v_c_2456 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam6, 1, 1, (V[]){v_g_240}), v_args_2424));
                return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam7, 2, 3, (V[]){v_c_2456, v_t_2451, v_xsp_2423});
              } else {
                heff_drop_rec(v_g_240, 6);
                heff_drop(v_args_2424);
                heff_drop(v_t_2451);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam9, 2, 2, (V[]){v_x_2422, v_xsp_2423});
              }
            }
            default: return heff_nomatch(v_it1_2450);
            }
          }
          default: return heff_nomatch(v_it_2442);
          }
        }
        default: return heff_nomatch(v_it1_2439);
        }
      }
      default: return heff_nomatch(v_it_2431);
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 6);
      heff_drop(v_it2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam10, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatFloat: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 6);
      heff_drop(v_it2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam11, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 6);
      heff_drop(v_it2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam12, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRune: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 6);
      heff_drop(v_it2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam13, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRecord: {
      V v_fs_2486 = heff_field(v_it1_242, 0);
      heff_take_n(v_it1_242, 1ULL, 1);
      heff_drop_tag(v_p_241, 2);
      V v_c_2494 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam14, 1, 1, (V[]){v_g_240}), v_fs_2486));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam17, 2, 2, (V[]){v_c_2494, v_it2_243});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 6);
      heff_drop(v_it2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam19, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatAs: {
      V v_x_24102 = heff_field(v_it1_242, 0);
      V v_xsp_24103 = heff_field(v_it1_242, 1);
      V v_q_24104 = heff_field(v_it1_242, 2);
      heff_take_n(v_it1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      V v_c_24105 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_q_24104));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam20, 2, 4, (V[]){v_c_24105, v_x_24102, v_xsp_24103, v_it2_243});
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eopPat(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2410));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_tsp_248 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_247)}), heff_dup(v_tsp_248)});
  V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2415, v_x_2414));
  V v_b_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_At: {
    V v_s_2418 = heff_field(v_x1_2416, 1);
    heff_take_n(v_x1_2416, 2ULL, 2);
    v_b_2419 = v_s_2418;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_248, 0)); V rr_ = heff_rec_reuse_n(v_b_2419, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_247, v_tsp_248, v_x_2414}), v_t_2420});
  V f_ = v_k_2413;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_tsp_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam3, 1, 3, (V[]){v_t_247, v_tsp_248, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str0), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str1)));
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2434, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_apply(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2438;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str2), heff_strAppend(heff_dup(v_x_2422), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str3), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str4)))));
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2445, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_take_field(v_hd_2443, 2), 1, (V[]){v_t_2448}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2449;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args) {
  V v_m_2455 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2455));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_t_2451 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  V v_k_2458 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2451)}), heff_dup(v_xsp_2423)});
  V v_x1_2461 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2460, v_x_2459));
  V v_b_2464;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_At: {
    V v_s_2463 = heff_field(v_x1_2461, 1);
    heff_take_n(v_x1_2461, 2ULL, 2);
    v_b_2464 = v_s_2463;
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  V v_t_2465 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_2423, 0)); V rr_ = heff_rec_reuse_n(v_b_2464, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2451, v_xsp_2423, v_x_2459}), v_t_2465});
  V f_ = v_k_2458;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_c_2456 = heff_env(self)[0];
  V v_t_2451 = heff_env(self)[1];
  V v_xsp_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2456;
  args[0] = v_hd_2457;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam8, 1, 3, (V[]){v_t_2451, v_xsp_2423, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str5), heff_strAppend(heff_dup(v_x_2422), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str6), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str7)))));
  V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2469, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_apply(heff_take_field(v_hd_2467, 2), 1, (V[]){v_t_2472}));
  V f_ = heff_get_n(v_hd_2467, 1, 3);
  args[0] = v_t_2473;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2475);
  V f_ = v_k_2476;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2478);
  V f_ = v_k_2479;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2481);
  V f_ = v_k_2482;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2484);
  V f_ = v_k_2485;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args) {
  V v_x_2493 = args[0];
  V v_k_2492 = heff_env(self)[0];
  V v_x_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2492;
  args[0] = heff_tag_n(TAG_MkFieldPat, 2, (V[]){v_x_2488, v_x_2493});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_c_2490 = heff_env(self)[0];
  V v_x_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2490;
  args[0] = v_hd_2491;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam16, 1, 2, (V[]){v_k_2492, v_x_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args) {
  V v_m_2487 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2487)) {
  case TAG_MkFieldPat: {
    V v_x_2488 = heff_field(v_m_2487, 0);
    V v_p_2489 = heff_field(v_m_2487, 1);
    heff_take_n(v_m_2487, 3ULL, 2);
    V v_c_2490 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_p_2489));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam15, 2, 2, (V[]){v_c_2490, v_x_2488});
  }
  default: return heff_nomatch(v_m_2487);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args) {
  V v_x_2497 = args[0];
  V v_it2_243 = heff_env(self)[0];
  V v_k_2496 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2498 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatRecord, 1, (V[]){v_x_2497}), v_it2_243});
  V f_ = v_k_2496;
  args[0] = v_t_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args) {
  V v_hd_2495 = args[0];
  V v_k_2496 = args[1];
  V v_c_2494 = heff_env(self)[0];
  V v_it2_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2494;
  args[0] = v_hd_2495;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam18, 1, 2, (V[]){v_it2_243, v_k_2496});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24100);
  V f_ = v_k_24101;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_24102 = heff_env(self)[0];
  V v_xsp_24103 = heff_env(self)[1];
  V v_it2_243 = heff_env(self)[2];
  V v_k_24107 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatAs, 3, (V[]){v_x_24102, v_xsp_24103, v_x_24108}), v_it2_243});
  V f_ = v_k_24107;
  args[0] = v_t_24109;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k_24107 = args[1];
  V v_c_24105 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  V v_xsp_24103 = heff_env(self)[2];
  V v_it2_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24105;
  args[0] = v_hd_24106;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam21, 1, 4, (V[]){v_x_24102, v_xsp_24103, v_it2_243, v_k_24107});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(v_a_247));
        switch (heff_tag_of(v_a_249)) {
        case TAG_True: {
          v_a_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_a_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_a_2410)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_a_2410);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_a_247 = (g_heff_2eelab_2etoplevel_2ehasOpPat(heff_dup(v_a_245)));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_a_247)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_a_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_245)));
        v_t_248 = (g_heff_2eelab_2etoplevel_2eflatPat(v_t_247));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkHeadOf_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2echkHeadOf(V v_n_240, V v_j_241) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_i1_242 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_i1_242)) {
    case TAG_IVar: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_INominal: {
      V v_i11_2423 = heff_field(v_i1_242, 0);
      heff_take_n(v_i1_242, 1ULL, 1);
      v_t_2428 = v_i11_2423;
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    default: heff_nomatch(v_i1_242);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(v_t_2428));
  V v_it_2430 = heff_get_n(v_t_2429, 0, 2);
  switch (heff_tag_of(v_it_2430)) {
  case TAG_At: {
    V v_it1_2431 = heff_field(v_it_2430, 0);
    heff_take_n(v_it_2430, 1ULL, 2);
    switch (heff_tag_of(v_it1_2431)) {
    case TAG_IVar: {
      V v_x_2433 = heff_field(v_it1_2431, 0);
      heff_take_n(v_it1_2431, 1ULL, 1);
      V v_t_2436;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2435 = heff_dup(heff_field(v_n_240, 1));
        v_t_2436 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2439;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2440 = (g_heff_2eelab_2erules_2eapply(v_t_2439, v_j_241));
      return ({ V a_0 = v_t_2436; V a_1 = v_x_2433; V a_2 = v_t_2440; V r_ = (g_heff_2eelab_2erules_2eautoRec(a_0, a_1, a_2)); heff_drop(v_t_2440); r_; });
    }
    case TAG_IInt: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2444;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2444 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2444, v_j_241);
    }
    case TAG_IFloat: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2448;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2448, v_j_241);
    }
    case TAG_IString: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2451 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2452, v_j_241);
    }
    case TAG_IRune: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2456;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2455 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2456, v_j_241);
    }
    case TAG_IApp: {
      heff_take_n(v_it1_2431, 0ULL, 2);
      V v_t_2461;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2460 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2461 = v_s_2460;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2461, v_j_241);
    }
    case TAG_IAnn: {
      heff_take_n(v_it1_2431, 0ULL, 2);
      V v_t_2466;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2466 = v_s_2465;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2466, v_j_241);
    }
    case TAG_ISpec: {
      heff_take_n(v_it1_2431, 0ULL, 4);
      V v_t_2473;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2472 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2473 = v_s_2472;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2473, v_j_241);
    }
    case TAG_IAnnLam: {
      heff_take_n(v_it1_2431, 0ULL, 4);
      V v_t_2480;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2479 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2480 = v_s_2479;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2480, v_j_241);
    }
    case TAG_IInvalid: {
      heff_take_n(v_it1_2431, 0ULL, 2);
      V v_t_2485;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2484 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2485 = v_s_2484;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2485, v_j_241);
    }
    case TAG_INominal: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2489;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2488 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2489 = v_s_2488;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2489, v_j_241);
    }
    case TAG_ILitEq: {
      heff_take_n(v_it1_2431, 0ULL, 4);
      V v_t_2496;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2495 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2496 = v_s_2495;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2496, v_j_241);
    }
    default: return heff_nomatch(v_it1_2431);
    }
  }
  default: return heff_nomatch(v_it_2430);
  }
}
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2echkHeadOf(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_At: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_sp_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_ArgExplicit: {
      V v_c_245 = heff_field(v_x41_243, 0);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_245)));
      V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_246}));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0, 2, 5, (V[]){v_c_247, heff_dup(v_c_245), v_start_240, heff_dup(v_sp_244), heff_dup(v_s_241)});
    }
    case TAG_ArgProject: {
      V v_x_2414 = heff_field(v_x41_243, 0);
      heff_drop(v_start_240);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2, 2, 3, (V[]){heff_dup(v_sp_244), heff_dup(v_s_241), heff_dup(v_x_2414)});
    }
    case TAG_ArgNamed: {
      V v_x_2418 = heff_field(v_x41_243, 0);
      V v_c_2419 = heff_field(v_x41_243, 1);
      V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
      V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2420}));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3, 2, 5, (V[]){v_c_2421, heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2418)});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = ({ V a_0 = v_c_245; V r_ = (g_heff_2eelab_2etoplevel_2echecksOnly(a_0)); heff_drop(v_c_245); r_; });
  V v_t_2412 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_n(v_sp_244, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2413 = ({ V a_0 = v_t_2411; V a_1 = v_t_2412; V a_2 = v_s_241; V a_3 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); heff_drop(v_s_241); heff_drop(v_x_2410); r_; });
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_s_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1, 1, 5, (V[]){v_c_245, v_start_240, v_sp_244, v_s_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_sp_244 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2415);
  V v_t_2417 = ({ V a_0 = v_sp_244; V a_1 = v_s_241; V a_2 = v_x_2414; V r_ = (g_heff_2eelab_2erules_2erecordElim(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
  V f_ = v_k_2416;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  V v_e_2425 = heff_env(self)[4];
  V v_hd_2428 = heff_env(self)[5];
  V v_k_2429 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_MkPair: {
    V v_ecallee_2431 = heff_field(v_x_2430, 0);
    V v_a0_2432 = heff_field(v_x_2430, 1);
    heff_take_n(v_x_2430, 3ULL, 2);
    V v_t_2433 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_n(v_sp_244, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ({ V a_0 = v_t_2433; V a_1 = v_x_2418; V a_2 = v_x_2424; V a_3 = v_e_2425; V a_4 = v_ecallee_2431; V a_5 = v_a0_2432; V a_6 = v_hd_2428; V a_7 = v_k_2429; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2424); r_; });
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2418 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  V v_e_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7, 1, 7, (V[]){v_start_240, v_sp_244, v_x_2418, v_x_2424, v_e_2425, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args) {
  V v_e_2425 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2418 = heff_env(self)[3];
  V v_x_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2427;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2426 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2427 = heff_tr(heff_apply(v_f_2426, 1, (V[]){heff_dup(v_e_2425)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6, 2, 6, (V[]){v_c_2427, v_start_240, v_sp_244, v_x_2418, v_x_2424, v_e_2425});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5, 1, 5, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2418, v_x_2424})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4, 1, 5, (V[]){v_k_2423, v_s_241, v_start_240, v_sp_244, v_x_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0, 2, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_242, 0);
    V v_rest_246 = heff_field(v_x4_242, 1);
    V v_c_247 = ({ V a_0 = heff_dup(v_start_240); V a_1 = v_s_241; V a_2 = v_a_245; V r_ = (g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1, 2, 3, (V[]){v_c_247, v_start_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_s_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_start_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2, 1, 4, (V[]){v_start_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_it1_241)) {
    case TAG_IVar: {
      V v_x_243 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0, 2, 2, (V[]){v_sp_242, v_x_243});
    }
    case TAG_IInt: {
      V v_i_247 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1, 2, 2, (V[]){v_sp_242, v_i_247});
    }
    case TAG_IFloat: {
      V v_x_2411 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2, 2, 2, (V[]){v_sp_242, v_x_2411});
    }
    case TAG_IString: {
      V v_s_2415 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3, 2, 1, (V[]){v_s_2415});
    }
    case TAG_IRune: {
      V v_c_2424 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6, 2, 1, (V[]){v_c_2424});
    }
    case TAG_IApp: {
      V v_h_2433 = heff_field(v_it1_241, 0);
      V v_args_2434 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2435 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_h_2433)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9, 2, 3, (V[]){v_c_2435, v_h_2433, v_args_2434});
    }
    case TAG_IAnn: {
      V v_n0_2443 = heff_field(v_it1_241, 0);
      V v_n1_2444 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2445 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n0_2443));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11, 2, 2, (V[]){v_c_2445, v_n1_2444});
    }
    case TAG_ISpec: {
      V v_n0_2452 = heff_field(v_it1_241, 0);
      V v_x_2453 = heff_field(v_it1_241, 1);
      V v_v_2455 = heff_field(v_it1_241, 3);
      heff_take_n(v_it1_241, 11ULL, 4);
      heff_drop(v_sp_242);
      V v_c_2456 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_v_2455));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14, 2, 4, (V[]){v_c_2456, v_n0_2452, v_n_240, v_x_2453});
    }
    case TAG_IAnnLam: {
      V v_x_2466 = heff_field(v_it1_241, 0);
      V v_tyN_2468 = heff_field(v_it1_241, 2);
      V v_body_2469 = heff_field(v_it1_241, 3);
      heff_take_n(v_it1_241, 13ULL, 4);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2470 = ({ V a_0 = v_tyN_2468; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2468); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17, 2, 3, (V[]){v_c_2470, v_body_2469, v_x_2466});
    }
    case TAG_IInvalid: {
      V v_code_2477 = heff_field(v_it1_241, 0);
      V v_why_2478 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20, 2, 3, (V[]){v_code_2477, v_why_2478, v_sp_242});
    }
    case TAG_INominal: {
      V v_i_2485 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2486 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_2485));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21, 2, 1, (V[]){v_c_2486});
    }
    case TAG_ILitEq: {
      V v_x_2491 = heff_field(v_it1_241, 0);
      V v_xsp_2492 = heff_field(v_it1_241, 1);
      V v_eq_2493 = heff_field(v_it1_241, 2);
      V v_lit_2494 = heff_field(v_it1_241, 3);
      heff_take_n(v_it1_241, 15ULL, 4);
      heff_drop_tag(v_n_240, 2);
      V v_c_2495 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_lit_2494));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23, 2, 5, (V[]){v_c_2495, v_sp_242, v_x_2491, v_xsp_2492, v_eq_2493});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(a[0]);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V v_t_246 = (g_heff_2eelab_2erules_2efind(v_sp_242, v_x_243));
  V f_ = v_k_245;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_i_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_t_2410 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_n(TAG_IntNum, 1, (V[]){v_i_247})));
  V f_ = v_k_249;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2412);
  V v_t_2414 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_n(TAG_FracNum, 1, (V[]){v_x_2411})));
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args) {
  V v_u_2421 = args[0];
  heff_drop(v_u_2421);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args) {
  V v_e_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2418);
  heff_drop(v_hd_2419);
  V v_t_2422 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_s_2415}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo)});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, NTAG(TAG_VPrimString)});
  V f_ = v_k_2420;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4, 3, 1, (V[]){v_s_2415})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args) {
  V v_u_2430 = args[0];
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args) {
  V v_e_2427 = args[0];
  V v_hd_2428 = args[1];
  V v_k_2429 = args[2];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2427);
  heff_drop(v_hd_2428);
  V v_t_2431 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitRune, 1, (V[]){v_c_2424}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8_clo)});
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, NTAG(TAG_VPrimRune)});
  V f_ = v_k_2429;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7, 3, 1, (V[]){v_c_2424})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args) {
  V v_x_2438 = args[0];
  V v_h_2433 = heff_env(self)[0];
  V v_args_2434 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2441;
  switch (heff_tag_of(v_h_2433)) {
  case TAG_At: {
    V v_s_2440 = heff_field(v_h_2433, 1);
    heff_take_n(v_h_2433, 2ULL, 2);
    v_t_2441 = v_s_2440;
    break;
  }
  default: heff_nomatch(v_h_2433);
  }
  V v_c_2442 = ({ V a_0 = heff_get_n(v_t_2441, 0, 2); V a_1 = v_x_2438; V a_2 = v_args_2434; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_args_2434); r_; });
  return heff_tail(v_c_2442, 2, (V[]){v_hd_2436, v_k_2437});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_h_2433 = heff_env(self)[1];
  V v_args_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10, 1, 4, (V[]){v_h_2433, v_args_2434, v_hd_2436, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = ({ V a_0 = v_x_2450; V a_1 = v_x_2448; V r_ = (g_heff_2eelab_2erules_2eannot(a_0, a_1)); heff_drop(v_x_2450); heff_drop(v_x_2448); r_; });
  V f_ = v_k_2447;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args) {
  V v_x_2448 = args[0];
  V v_n1_2444 = heff_env(self)[0];
  V v_hd_2446 = heff_env(self)[1];
  V v_k_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2449 = ({ V a_0 = v_n1_2444; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n1_2444); r_; });
  return heff_tail(v_c_2449, 2, (V[]){v_hd_2446, heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13, 1, 2, (V[]){v_x_2448, v_k_2447})});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_n1_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2445;
  args[0] = heff_dup(v_hd_2446);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12, 1, 3, (V[]){v_n1_2444, v_hd_2446, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args) {
  V v_x_2461 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2453 = heff_env(self)[1];
  V v_x_2459 = heff_env(self)[2];
  V v_k_2458 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2464;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2463 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2464 = v_s_2463;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2465 = ({ V a_0 = v_t_2464; V a_1 = v_x_2461; V a_2 = v_x_2453; V a_3 = v_x_2459; V r_ = (g_heff_2eelab_2erules_2erecordSpec(a_0, a_1, a_2, a_3)); heff_drop(v_x_2461); heff_drop(v_x_2459); r_; });
  V f_ = v_k_2458;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args) {
  V v_x_2459 = args[0];
  V v_n0_2452 = heff_env(self)[0];
  V v_hd_2457 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2453 = heff_env(self)[3];
  V v_k_2458 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2460 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_2452));
  return heff_tail(v_c_2460, 2, (V[]){v_hd_2457, heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16, 1, 4, (V[]){v_n_240, v_x_2453, v_x_2459, v_k_2458})});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_c_2456 = heff_env(self)[0];
  V v_n0_2452 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2453 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2456;
  args[0] = heff_dup(v_hd_2457);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15, 1, 5, (V[]){v_n0_2452, v_hd_2457, v_n_240, v_x_2453, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args) {
  V v_x_2475 = args[0];
  V v_x_2466 = heff_env(self)[0];
  V v_x_2473 = heff_env(self)[1];
  V v_k_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2476 = ({ V a_0 = v_x_2466; V a_1 = v_x_2473; V a_2 = v_x_2475; V r_ = (g_heff_2eelab_2erules_2efunctionIntroSyn(a_0, a_1, a_2)); heff_drop(v_x_2473); heff_drop(v_x_2475); r_; });
  V f_ = v_k_2472;
  args[0] = v_t_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args) {
  V v_x_2473 = args[0];
  V v_body_2469 = heff_env(self)[0];
  V v_hd_2471 = heff_env(self)[1];
  V v_x_2466 = heff_env(self)[2];
  V v_k_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2474 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_body_2469));
  return heff_tail(v_c_2474, 2, (V[]){v_hd_2471, heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19, 1, 3, (V[]){v_x_2466, v_x_2473, v_k_2472})});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  V v_body_2469 = heff_env(self)[1];
  V v_x_2466 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2470;
  args[0] = heff_dup(v_hd_2471);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18, 1, 4, (V[]){v_body_2469, v_hd_2471, v_x_2466, v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k2_2480 = args[1];
  V v_code_2477 = heff_env(self)[0];
  V v_why_2478 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_2477), NTAG(TAG_SError), v_why_2478, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_apply(heff_take_field(v_hd_2479, 2), 1, (V[]){v_t_2483}));
  V f_ = heff_get_n(v_hd_2479, 1, 3);
  args[0] = v_t_2484;
  args[1] = v_k2_2480;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args) {
  V v_x_2489 = args[0];
  V v_k_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2490 = ({ V a_0 = v_x_2489; V r_ = (g_heff_2eelab_2etoplevel_2enominalSyn(a_0)); heff_drop(v_x_2489); r_; });
  V f_ = v_k_2488;
  args[0] = v_t_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k_2488 = args[1];
  V v_c_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2486;
  args[0] = v_hd_2487;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22, 1, 1, (V[]){v_k_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args) {
  V v_x_2498 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2491 = heff_env(self)[1];
  V v_xsp_2492 = heff_env(self)[2];
  V v_eq_2493 = heff_env(self)[3];
  V v_k_2497 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = ({ V a_0 = v_sp_242; V a_1 = v_x_2491; V a_2 = v_xsp_2492; V a_3 = v_eq_2493; V a_4 = v_x_2498; V r_ = (g_heff_2eelab_2erules_2elitEq(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2498); r_; });
  V f_ = v_k_2497;
  args[0] = v_t_2499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k_2497 = args[1];
  V v_c_2495 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2491 = heff_env(self)[2];
  V v_xsp_2492 = heff_env(self)[3];
  V v_eq_2493 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2495;
  args[0] = v_hd_2496;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24, 1, 5, (V[]){v_sp_242, v_x_2491, v_xsp_2492, v_eq_2493, v_k_2497});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V v_i_240) {
top: ;
  V v_x1_2427;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_i1_241, 0ULL, 2);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 2);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_INominal: {
      V v_i11_2422 = heff_field(v_i1_241, 0);
      heff_take_n(v_i1_241, 1ULL, 1);
      v_x1_2427 = v_i11_2422;
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    default: heff_nomatch(v_i1_241);
    }
    break;
  }
  default: heff_nomatch(v_i_240);
  }
  V v_t_2454;
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_At: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInt: {
      V v_k_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24IInt = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      v_t_2454 = heff_tag_at_n(v_ru_24x11_2428_24IInt, TAG_Just, 1, (V[]){heff_tag_n(TAG_IntNum, 1, (V[]){v_k_2431})});
      break;
    }
    case TAG_IFloat: {
      V v_x_2432 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24IFloat = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      v_t_2454 = heff_tag_at_n(v_ru_24x11_2428_24IFloat, TAG_Just, 1, (V[]){heff_tag_n(TAG_FracNum, 1, (V[]){v_x_2432})});
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2428, 0ULL, 2);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2428, 0ULL, 2);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2428, 0ULL, 4);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2428, 0ULL, 4);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2428, 0ULL, 2);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_INominal: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2428, 0ULL, 4);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2428);
    }
    break;
  }
  default: heff_nomatch(v_x1_2427);
  }
  switch (heff_tag_of(v_t_2454)) {
  case TAG_Nothing: {
    V v_c_2455 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_240)));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0, 2, 2, (V[]){v_c_2455, v_i_240});
  }
  case TAG_Just: {
    V v_lit_2461 = heff_field(v_t_2454, 0);
    heff_take_n(v_t_2454, 1ULL, 1);
    V v_t_2488;
    switch (heff_tag_of(v_i_240)) {
    case TAG_At: {
      V v_x11_2462 = heff_dup(heff_field(v_i_240, 0));
      switch (heff_tag_of(v_x11_2462)) {
      case TAG_IVar: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IFloat: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IString: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_x11_2462, 0ULL, 2);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_x11_2462, 0ULL, 2);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_x11_2462, 0ULL, 4);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_x11_2462, 0ULL, 4);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_x11_2462, 0ULL, 2);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_True);
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_x11_2462, 0ULL, 4);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2462);
      }
      break;
    }
    default: heff_nomatch(v_i_240);
    }
    V v_t_2496;
    switch (heff_tag_of(v_t_2488)) {
    case TAG_True: {
      V v_t_2491;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_2490 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_2491 = v_s_2490;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      V v_t_2492 = (g_heff_2eelab_2erules_2enumLitChk(v_t_2491, v_lit_2461));
      v_t_2496 = ({ V a_0 = v_t_2492; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_t_2492); r_; });
      break;
    }
    case TAG_False: {
      V v_t_2495;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_2494 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_2495 = v_s_2494;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      v_t_2496 = (g_heff_2eelab_2erules_2enumLitChk(v_t_2495, v_lit_2461));
      break;
    }
    default: heff_nomatch(v_t_2488);
    }
    V v_x_2497 = ({ V a_0 = v_t_2496; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2496); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2, 2, 1, (V[]){v_x_2497});
  }
  default: return heff_nomatch(v_t_2454);
  }
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args) {
  V v_x_2458 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = ({ V a_0 = v_i_240; V a_1 = v_x_2458; V r_ = (g_heff_2eelab_2etoplevel_2echkHeadOf(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V v_x_2460 = ({ V a_0 = v_t_2459; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2459); r_; });
  V f_ = v_k_2457;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_i_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1, 1, 2, (V[]){v_i_240, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k_2499 = args[1];
  V v_x_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2498);
  V f_ = v_k_2499;
  args[0] = v_x_2497;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_x_243));
    V v_c_246 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_245}));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1, 2, 2, (V[]){v_c_246, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2410 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(v_xs_244));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3, 1, 2, (V[]){v_k_248, v_x_249})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2, 1, 3, (V[]){v_xs_244, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_str0, 44, (101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 102, 105, 101, 108, 100, 32, 115, 101, 116, 116, 105, 110, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 32, 96, 120, 32, 61, 32, 118, 96));
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_e_245)));
      V v_c_247 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_246}));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0, 2, 4, (V[]){v_c_247, heff_dup(v_e_245), heff_dup(v_x_243), heff_dup(v_xsp_244)});
    }
    case TAG_BadFieldSet: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_xsp_244 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413;
  switch (heff_tag_of(v_e_245)) {
  case TAG_At: {
    V v_s_2412 = heff_field(v_e_245, 1);
    heff_take_n(v_e_245, 2ULL, 2);
    v_t_2413 = v_s_2412;
    break;
  }
  default: heff_nomatch(v_e_245);
  }
  V v_x_2414 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_243, v_x_2410, v_t_2413, v_xsp_244});
  V f_ = v_k_249;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_xsp_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1, 1, 4, (V[]){v_e_245, v_x_243, v_xsp_244, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k2_2417 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(202LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_apply(heff_take_field(v_hd_2416, 2), 1, (V[]){v_t_2420}));
  V f_ = heff_get_n(v_hd_2416, 1, 3);
  args[0] = v_t_2421;
  args[1] = v_k2_2417;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_body_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2edoPat(v_p_243));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0, 2, 2, (V[]){v_c_245, v_body_244});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_xs_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_xs_2410), v_x_2413});
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_body_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x_248, 0);
    V v_xs_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_244));
    V v_c_2412 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2411}));
    return heff_tail(v_c_2412, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2, 1, 3, (V[]){v_xs_2410, v_k_247, v_x_249})});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1, 1, 3, (V[]){v_body_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V v_f_240, V v_eqs_241, V v_sp_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(v_eqs_241));
  V v_t_244;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242});
  }
  case TAG_False: {
    V v_t_2438 = (g_heff_2eelab_2eclauses_2edesugar(v_f_240, NTAG(TAG_Nil), v_eqs_241, v_sp_242));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Left: {
      V v_err_2439 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10, 2, 1, (V[]){v_err_2439});
    }
    case TAG_Right: {
      V v_b_2446 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2446));
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_247, 1, 6), v_m_2416));
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_fsp_2413 = heff_env(self)[1];
  V v_rhs_2415 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2412, v_fsp_2413, v_x_2420, v_rhs_2415}), v_sp_2411});
  V f_ = v_k_2419;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_fsp_2413 = heff_env(self)[2];
  V v_rhs_2415 = heff_env(self)[3];
  V v_sp_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5, 1, 5, (V[]){v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args) {
  V v_m_249 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_249)) {
  case TAG_At: {
    V v_x21_2410 = heff_field(v_m_249, 0);
    V v_sp_2411 = heff_field(v_m_249, 1);
    heff_take_n(v_m_249, 3ULL, 2);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkEquation: {
      V v_f_2412 = heff_field(v_x21_2410, 0);
      V v_fsp_2413 = heff_field(v_x21_2410, 1);
      V v_ps_2414 = heff_field(v_x21_2410, 2);
      V v_rhs_2415 = heff_field(v_x21_2410, 3);
      heff_take_n(v_x21_2410, 15ULL, 4);
      V v_c_2417 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3, 1, 1, (V[]){v_e_247}), v_ps_2414));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4, 2, 5, (V[]){v_c_2417, v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_m_249);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_err_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_2427, 1), heff_get_n(v_err_2427, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_apply(heff_take_field(v_hd_2428, 2), 1, (V[]){v_t_2432}));
  V f_ = heff_get_n(v_hd_2428, 1, 3);
  args[0] = v_t_2433;
  args[1] = v_k2_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkChk: {
    V v_f_2437 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    return heff_tail(v_f_2437, 4, (V[]){v_e_247, v_a_248, v_hd_2423, v_k_2424});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426 = (g_heff_2eelab_2eclauses_2edesugar(v_f_240, NTAG(TAG_Nil), v_x_2425, v_sp_242));
  V v_c_2435;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Left: {
    V v_err_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_c_2435 = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8, 2, 1, (V[]){v_err_2427});
    break;
  }
  case TAG_Right: {
    V v_b_2434 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_c_2435 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2434));
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return heff_tail(v_c_2435, 2, (V[]){heff_dup(v_hd_2423), heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9, 1, 4, (V[]){v_e_247, v_a_248, v_hd_2423, v_k_2424})});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7, 1, 6, (V[]){v_f_240, v_sp_242, v_hd_2423, v_e_247, v_a_248, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args) {
  V v_e_247 = args[0];
  V v_a_248 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2422 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2, 1, 1, (V[]){heff_dup(v_e_247)}), v_eqs_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6, 2, 5, (V[]){v_c_2422, v_f_240, v_sp_242, v_e_247, v_a_248});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_err_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_2439, 1), heff_get_n(v_err_2439, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_apply(heff_take_field(v_hd_2440, 2), 1, (V[]){v_t_2444}));
  V f_ = heff_get_n(v_hd_2440, 1, 3);
  args[0] = v_t_2445;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0, 40, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110));
HEFF_STRA(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1, 40, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110));
HEFF_STRA(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2, 40, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110));
HEFF_STRA(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3, 40, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110));
HEFF_STRA(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4, 40, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 108, 111, 99, 97, 108, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110));
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V v_x2_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_241));
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_240, 0);
    V v_ds_243 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_d_242)) {
    case TAG_At: {
      V v_x_244 = heff_field(v_d_242, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_DeclEquations: {
      V v_name_247 = heff_field(v_t_246, 0);
      V v_tyN_249 = heff_field(v_t_246, 2);
      V v_eqs_2410 = heff_field(v_t_246, 3);
      heff_take_n(v_t_246, 13ULL, 4);
      V v_c_2411 = ({ V a_0 = v_tyN_249; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_249); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0, 2, 6, (V[]){v_c_2411, heff_dup(v_d_242), v_name_247, v_eqs_2410, heff_dup(v_ds_243), v_body_241});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_246, 0ULL, 5);
      heff_drop(v_body_241);
      V v_sp_2430;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2429 = heff_field(v_d_242, 1);
        v_sp_2430 = heff_dup(v_s_2429);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4, 2, 1, (V[]){v_sp_2430});
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_body_241);
      V v_sp_2443;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2442 = heff_field(v_d_242, 1);
        v_sp_2443 = heff_dup(v_s_2442);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5, 2, 1, (V[]){v_sp_2443});
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_body_241);
      V v_sp_2455;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2454 = heff_field(v_d_242, 1);
        v_sp_2455 = heff_dup(v_s_2454);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6, 2, 1, (V[]){v_sp_2455});
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_body_241);
      V v_sp_2466;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_d_242, 1);
        v_sp_2466 = heff_dup(v_s_2465);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7, 2, 1, (V[]){v_sp_2466});
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_body_241);
      V v_sp_2476;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2475 = heff_field(v_d_242, 1);
        v_sp_2476 = heff_dup(v_s_2475);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8, 2, 1, (V[]){v_sp_2476});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = ({ V a_0 = v_name_247; V a_1 = v_x_2414; V a_2 = v_x_2419; V a_3 = v_x_2421; V r_ = (g_heff_2eelab_2erules_2elocalDef(a_0, a_1, a_2, a_3)); heff_drop(v_x_2414); heff_drop(v_x_2419); heff_drop(v_x_2421); r_; });
  V f_ = v_k_2413;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ds_243 = heff_env(self)[0];
  V v_body_241 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_name_247 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2420 = ({ V a_0 = v_ds_243; V a_1 = v_body_241; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_ds_243); r_; });
  return heff_tail(v_c_2420, 2, (V[]){v_hd_2412, heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3, 1, 4, (V[]){v_name_247, v_x_2414, v_x_2419, v_k_2413})});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_name_247 = heff_env(self)[1];
  V v_eqs_2410 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2416 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2417 = v_s_2416;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_c_2418 = (g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(heff_dup(v_name_247), v_eqs_2410, v_t_2417));
  return heff_tail(v_c_2418, 2, (V[]){heff_dup(v_hd_2412), heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2, 1, 6, (V[]){v_ds_243, v_body_241, v_hd_2412, v_name_247, v_x_2414, v_k_2413})});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_name_247 = heff_env(self)[2];
  V v_eqs_2410 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1, 1, 7, (V[]){v_d_242, v_name_247, v_eqs_2410, v_hd_2412, v_ds_243, v_body_241, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k2_2432 = args[1];
  V v_sp_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0), v_sp_2430, NTAG(TAG_Nothing)});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_apply(heff_take_field(v_hd_2431, 2), 1, (V[]){v_t_2435}));
  V f_ = heff_get_n(v_hd_2431, 1, 3);
  args[0] = v_t_2436;
  args[1] = v_k2_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k2_2445 = args[1];
  V v_sp_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1), v_sp_2443, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_apply(heff_take_field(v_hd_2444, 2), 1, (V[]){v_t_2448}));
  V f_ = heff_get_n(v_hd_2444, 1, 3);
  args[0] = v_t_2449;
  args[1] = v_k2_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_sp_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2), v_sp_2455, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_take_field(v_hd_2456, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2456, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_sp_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3), v_sp_2466, NTAG(TAG_Nothing)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_apply(heff_take_field(v_hd_2467, 2), 1, (V[]){v_t_2471}));
  V f_ = heff_get_n(v_hd_2467, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k2_2478 = args[1];
  V v_sp_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4), v_sp_2476, NTAG(TAG_Nothing)});
  V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tr(heff_apply(heff_take_field(v_hd_2477, 2), 1, (V[]){v_t_2481}));
  V f_ = heff_get_n(v_hd_2477, 1, 3);
  args[0] = v_t_2482;
  args[1] = v_k2_2478;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0, 2, (105, 116));
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_it2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_it1_241)) {
    case TAG_CInf: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CType: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CLam: {
      V v_x_245 = heff_field(v_it1_241, 0);
      V v_body_247 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 5ULL, 3);
      heff_drop(v_it2_242);
      V v_t_248 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_247));
      V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_248}));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0, 2, 3, (V[]){v_c_249, v_n_240, v_x_245});
    }
    case TAG_CImplicitLam: {
      V v_x_2417 = heff_field(v_it1_241, 0);
      V v_body_2419 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 5ULL, 3);
      heff_drop(v_it2_242);
      V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2419));
      V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2420}));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2, 2, 3, (V[]){v_c_2421, v_n_240, v_x_2417});
    }
    case TAG_CAnnLam: {
      V v_x_2429 = heff_field(v_it1_241, 0);
      V v_tyN_2431 = heff_field(v_it1_241, 2);
      V v_body_2432 = heff_field(v_it1_241, 3);
      heff_take_n(v_it1_241, 13ULL, 4);
      heff_drop(v_it2_242);
      V v_c_2433 = ({ V a_0 = v_tyN_2431; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2431); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4, 2, 4, (V[]){v_c_2433, v_body_2432, v_n_240, v_x_2429});
    }
    case TAG_CTag: {
      V v_x_2443 = heff_field(v_it1_241, 0);
      V v_tsp_2444 = heff_field(v_it1_241, 1);
      V v_args_2445 = heff_field(v_it1_241, 2);
      heff_take_n(v_it1_241, 7ULL, 3);
      heff_drop(v_it2_242);
      V v_c_2446 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(v_args_2445));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7, 2, 4, (V[]){v_c_2446, v_n_240, v_tsp_2444, v_x_2443});
    }
    case TAG_CStruct: {
      V v_fields_2454 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      V v_c_2455 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(v_fields_2454));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9, 2, 2, (V[]){v_c_2455, v_it2_242});
    }
    case TAG_CMatch: {
      V v_scrutN_2460 = heff_field(v_it1_241, 0);
      V v_casesN_2461 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      V v_x1_2462 = (g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(v_casesN_2461));
      V v_t_2463;
      switch (heff_tag_of(v_x1_2462)) {
      case TAG_True: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2463 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_2462);
      }
      switch (heff_tag_of(v_t_2463)) {
      case TAG_True: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11, 2, 3, (V[]){v_casesN_2461, v_scrutN_2460, v_it2_242});
      }
      case TAG_False: {
        V v_t_2486 = (g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(v_casesN_2461));
        V v_t_2488;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_True: {
          V v_x1_2487 = (g_heff_2eelab_2etoplevel_2eannotatesData(v_scrutN_2460));
          switch (heff_tag_of(v_x1_2487)) {
          case TAG_True: {
            v_t_2488 = NTAG(TAG_False);
            break;
          }
          case TAG_False: {
            v_t_2488 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x1_2487);
          }
          break;
        }
        case TAG_False: {
          v_t_2488 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        switch (heff_tag_of(v_t_2488)) {
        case TAG_True: {
          V v_c_2489 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_2460));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19, 2, 3, (V[]){v_c_2489, v_casesN_2461, v_it2_242});
        }
        case TAG_False: {
          V v_x1_24101 = (g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(v_casesN_2461));
          V v_t_24107;
          switch (heff_tag_of(v_x1_24101)) {
          case TAG_Left: {
            V v_e_24102 = heff_field(v_x1_24101, 0);
            V v_ru_24x1_24101_24Left = heff_take_reuse_n(v_x1_24101, 1ULL, 1);
            heff_drop(v_it2_242);
            v_t_24107 = heff_tag_at_n(v_ru_24x1_24101_24Left, TAG_Left, 1, (V[]){v_e_24102});
            break;
          }
          case TAG_Right: {
            V v_x_24103 = heff_field(v_x1_24101, 0);
            heff_take_n(v_x1_24101, 1ULL, 1);
            V v_t_24104 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1023056612x824831407(v_x_24103));
            V v_t_24105 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1023056612x824831407(v_x_24103));
            V v_t_24106 = ({ V a_0 = v_t_24105; V a_1 = ((V)&g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0); V r_ = (g_heff_2eelab_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_24105); r_; });
            v_t_24107 = (g_heff_2eelab_2eclauses_2ecaseTreeOf(v_it2_242, v_x_24103, v_t_24104, v_t_24106));
            break;
          }
          default: heff_nomatch(v_x1_24101);
          }
          switch (heff_tag_of(v_t_24107)) {
          case TAG_Left: {
            V v_err_24108 = heff_field(v_t_24107, 0);
            heff_take_n(v_t_24107, 1ULL, 1);
            heff_drop(v_scrutN_2460);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22, 2, 1, (V[]){v_err_24108});
          }
          case TAG_Right: {
            V v_r_24115 = heff_field(v_t_24107, 0);
            heff_take_n(v_t_24107, 1ULL, 1);
            V v_c_24116 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_2460));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23, 2, 2, (V[]){v_c_24116, v_r_24115});
          }
          default: return heff_nomatch(v_t_24107);
          }
        }
        default: return heff_nomatch(v_t_2488);
        }
      }
      default: return heff_nomatch(v_t_2463);
      }
    }
    case TAG_CLetIn: {
      V v_rhsN_24123 = heff_field(v_it1_241, 0);
      V v_alt0_24124 = heff_field(v_it1_241, 1);
      V v_ru_24it1_241_24CLetIn = heff_take_reuse_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      switch (heff_tag_of(v_alt0_24124)) {
      case TAG_At: {
        V v_it1_24125 = heff_dup(heff_field(v_alt0_24124, 0));
        switch (heff_tag_of(v_it1_24125)) {
        case TAG_MkAlt: {
          V v_it11_24127 = heff_field(v_it1_24125, 0);
          V v_bodyN_24128 = heff_field(v_it1_24125, 1);
          V v_ru_24it1_24125_24MkAlt = heff_take_reuse_n(v_it1_24125, 3ULL, 2);
          switch (heff_tag_of(v_it11_24127)) {
          case TAG_At: {
            V v_it111_24129 = heff_field(v_it11_24127, 0);
            heff_take_n(v_it11_24127, 1ULL, 2);
            switch (heff_tag_of(v_it111_24129)) {
            case TAG_PatVar: {
              V v_x_24131 = heff_field(v_it111_24129, 0);
              heff_take_n(v_it111_24129, 1ULL, 1);
              heff_drop(v_it2_242);
              heff_drop_tag(v_alt0_24124, 2);
              heff_drop_cell(v_ru_24it1_241_24CLetIn, 2);
              heff_drop_cell(v_ru_24it1_24125_24MkAlt, 2);
              V v_c_24132 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_rhsN_24123));
              return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26, 2, 3, (V[]){v_c_24132, v_bodyN_24128, v_x_24131});
            }
            case TAG_PatTag: {
              heff_take_n(v_it111_24129, 0ULL, 3);
              heff_drop(v_bodyN_24128);
              V v_t_24143 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24144 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24143}), v_it2_242});
              V t_0 = v_t_24144;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatOp: {
              heff_take_n(v_it111_24129, 0ULL, 3);
              heff_drop(v_bodyN_24128);
              V v_t_24148 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24149 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24148}), v_it2_242});
              V t_0 = v_t_24149;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatInt: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24151 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24152 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24151}), v_it2_242});
              V t_0 = v_t_24152;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatFloat: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24154 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24155 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24154}), v_it2_242});
              V t_0 = v_t_24155;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatString: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24157 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24158 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24157}), v_it2_242});
              V t_0 = v_t_24158;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatRune: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24160 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24161 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24160}), v_it2_242});
              V t_0 = v_t_24161;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatRecord: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24163 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24164 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24163}), v_it2_242});
              V t_0 = v_t_24164;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatWord: {
              heff_take_n(v_it111_24129, 0ULL, 1);
              heff_drop(v_bodyN_24128);
              V v_t_24166 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24167 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24166}), v_it2_242});
              V t_0 = v_t_24167;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatAs: {
              heff_take_n(v_it111_24129, 0ULL, 3);
              heff_drop(v_bodyN_24128);
              V v_t_24171 = heff_tag_at_n(v_ru_24it1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24124, NTAG(TAG_Nil)});
              V v_t_24172 = heff_tag_at_n(v_ru_24it1_24125_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24123, v_t_24171}), v_it2_242});
              V t_0 = v_t_24172;
              v_n_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_it111_24129);
            }
          }
          default: return heff_nomatch(v_it11_24127);
          }
        }
        default: return heff_nomatch(v_it1_24125);
        }
      }
      default: return heff_nomatch(v_alt0_24124);
      }
    }
    case TAG_CLocal: {
      V v_bodyN_24173 = heff_field(v_it1_241, 0);
      V v_defs_24174 = heff_field(v_it1_241, 1);
      heff_take_n(v_it1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_it2_242);
      return ({ V a_0 = v_defs_24174; V a_1 = v_bodyN_24173; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_defs_24174); r_; });
    }
    case TAG_CAbandon: {
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29, 2, 1, (V[]){v_it2_242});
    }
    case TAG_CNominal: {
      V v_c_24178 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_it2_242);
      V v_c_24179 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_c_24178));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30, 2, 1, (V[]){v_c_24179});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(a[0]);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2416 = ({ V a_0 = v_t_2415; V a_1 = v_x_245; V a_2 = v_x_2412; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  V f_ = v_k_2411;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1, 1, 3, (V[]){v_n_240, v_x_245, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2428 = ({ V a_0 = v_t_2427; V a_1 = v_x_2417; V a_2 = v_x_2424; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_x_2424); r_; });
  V f_ = v_k_2423;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3, 1, 3, (V[]){v_n_240, v_x_2417, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2436 = heff_env(self)[2];
  V v_k_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2441;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2440 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2441 = v_s_2440;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2442 = ({ V a_0 = v_t_2441; V a_1 = v_x_2429; V a_2 = v_x_2436; V a_3 = v_x_2438; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2436); heff_drop(v_x_2438); r_; });
  V f_ = v_k_2435;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_body_2432 = heff_env(self)[0];
  V v_hd_2434 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2437 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2432));
  return heff_tail(v_c_2437, 2, (V[]){v_hd_2434, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6, 1, 4, (V[]){v_n_240, v_x_2429, v_x_2436, v_k_2435})});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_body_2432 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5, 1, 5, (V[]){v_body_2432, v_hd_2434, v_n_240, v_x_2429, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_tsp_2444 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2451 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2452 = v_s_2451;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2453 = (g_heff_2eelab_2erules_2esumIntro(v_t_2452, v_tsp_2444, v_x_2443, v_x_2449));
  V f_ = v_k_2448;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_tsp_2444 = heff_env(self)[2];
  V v_x_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8, 1, 4, (V[]){v_n_240, v_tsp_2444, v_x_2443, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_it2_242 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = (g_heff_2eelab_2erules_2erecordIntro(v_it2_242, v_x_2458));
  V f_ = v_k_2457;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10, 1, 2, (V[]){v_it2_242, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args) {
  V v_x_2476 = args[0];
  V v_body_2472 = heff_env(self)[0];
  V v_sp_2470 = heff_env(self)[1];
  V v_k_2475 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2476, v_body_2472}), v_sp_2470});
  V f_ = v_k_2475;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_c_2473 = heff_env(self)[0];
  V v_body_2472 = heff_env(self)[1];
  V v_sp_2470 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2473;
  args[0] = v_hd_2474;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15, 1, 3, (V[]){v_body_2472, v_sp_2470, v_k_2475});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args) {
  V v_m_2468 = args[0];
  V v_e_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2468)) {
  case TAG_At: {
    V v_x21_2469 = heff_field(v_m_2468, 0);
    V v_sp_2470 = heff_field(v_m_2468, 1);
    heff_take_n(v_m_2468, 3ULL, 2);
    switch (heff_tag_of(v_x21_2469)) {
    case TAG_MkAlt: {
      V v_p_2471 = heff_field(v_x21_2469, 0);
      V v_body_2472 = heff_field(v_x21_2469, 1);
      heff_take_n(v_x21_2469, 3ULL, 2);
      V v_c_2473 = (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2466, 1, 6), v_p_2471));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14, 2, 3, (V[]){v_c_2473, v_body_2472, v_sp_2470});
    }
    default: return heff_nomatch(v_x21_2469);
    }
  }
  default: return heff_nomatch(v_m_2468);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args) {
  V v_x_2484 = args[0];
  V v_e_2466 = heff_env(self)[0];
  V v_a_2467 = heff_env(self)[1];
  V v_hd_2479 = heff_env(self)[2];
  V v_k_2480 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2484)) {
  case TAG_MkChk: {
    V v_f_2485 = heff_field(v_x_2484, 0);
    heff_take_n(v_x_2484, 1ULL, 1);
    return heff_tail(v_f_2485, 4, (V[]){v_e_2466, v_a_2467, v_hd_2479, v_k_2480});
  }
  default: return heff_nomatch(v_x_2484);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args) {
  V v_x_2481 = args[0];
  V v_scrutN_2460 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  V v_hd_2479 = heff_env(self)[2];
  V v_e_2466 = heff_env(self)[3];
  V v_a_2467 = heff_env(self)[4];
  V v_k_2480 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2482 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_scrutN_2460, v_x_2481}), v_it2_242});
  V v_c_2483 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_2482));
  return heff_tail(v_c_2483, 2, (V[]){heff_dup(v_hd_2479), heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18, 1, 4, (V[]){v_e_2466, v_a_2467, v_hd_2479, v_k_2480})});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_c_2478 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  V v_e_2466 = heff_env(self)[3];
  V v_a_2467 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2478;
  args[0] = heff_dup(v_hd_2479);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17, 1, 6, (V[]){v_scrutN_2460, v_it2_242, v_hd_2479, v_e_2466, v_a_2467, v_k_2480});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args) {
  V v_e_2466 = args[0];
  V v_a_2467 = args[1];
  V v_casesN_2461 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2478 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13, 1, 1, (V[]){heff_dup(v_e_2466)}), v_casesN_2461));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16, 2, 5, (V[]){v_c_2478, v_scrutN_2460, v_it2_242, v_e_2466, v_a_2467});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_casesN_2461 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2464);
  V f_ = v_k_2465;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12, 2, 3, (V[]){v_casesN_2461, v_scrutN_2460, v_it2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args) {
  V v_x_2494 = args[0];
  V v_casesN_2461 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  V v_x_2492 = heff_env(self)[2];
  V v_k_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2495 = (g_heff_2eelab_2etoplevel_2etagSpans(v_casesN_2461));
  V v_t_2496 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_x_2494)));
  V v_t_2497 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2494));
  V v_t_2498 = (g_list_2emap_24s366344330x1145113647(v_x_2494));
  V v_t_2499 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2496), v_t_2497, heff_arrayFromList(v_t_2498)});
  V v_x_24100 = ({ V a_0 = v_it2_242; V a_1 = v_x_2492; V a_2 = v_t_2495; V a_3 = v_t_2499; V r_ = (g_heff_2eelab_2erules_2esumElim(a_0, a_1, a_2, a_3)); heff_drop(v_x_2492); heff_drop(v_t_2495); r_; });
  V f_ = v_k_2491;
  args[0] = v_x_24100;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args) {
  V v_x_2492 = args[0];
  V v_casesN_2461 = heff_env(self)[0];
  V v_hd_2490 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  V v_k_2491 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2493 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(heff_dup(v_casesN_2461)));
  return heff_tail(v_c_2493, 2, (V[]){v_hd_2490, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21, 1, 4, (V[]){v_casesN_2461, v_it2_242, v_x_2492, v_k_2491})});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k_2491 = args[1];
  V v_c_2489 = heff_env(self)[0];
  V v_casesN_2461 = heff_env(self)[1];
  V v_it2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2489;
  args[0] = heff_dup(v_hd_2490);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20, 1, 4, (V[]){v_casesN_2461, v_hd_2490, v_it2_242, v_k_2491});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k2_24110 = args[1];
  V v_err_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), heff_take_field(v_err_24108, 1), heff_get_n(v_err_24108, 0, 2), NTAG(TAG_Nothing)});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tr(heff_apply(heff_take_field(v_hd_24109, 2), 1, (V[]){v_t_24113}));
  V f_ = heff_get_n(v_hd_24109, 1, 3);
  args[0] = v_t_24114;
  args[1] = v_k2_24110;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args) {
  V v_x_24121 = args[0];
  V v_r_24115 = heff_env(self)[0];
  V v_x_24119 = heff_env(self)[1];
  V v_k_24118 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24122 = ({ V a_0 = heff_get_n(v_r_24115, 0, 2); V a_1 = v_x_24119; V a_2 = v_x_24121; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24119); heff_drop(v_x_24121); r_; });
  V f_ = v_k_24118;
  args[0] = v_t_24122;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args) {
  V v_x_24119 = args[0];
  V v_r_24115 = heff_env(self)[0];
  V v_hd_24117 = heff_env(self)[1];
  V v_k_24118 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24120 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(heff_rfield(v_r_24115, 1))));
  return heff_tail(v_c_24120, 2, (V[]){v_hd_24117, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25, 1, 3, (V[]){v_r_24115, v_x_24119, v_k_24118})});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args) {
  V v_hd_24117 = args[0];
  V v_k_24118 = args[1];
  V v_c_24116 = heff_env(self)[0];
  V v_r_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24116;
  args[0] = heff_dup(v_hd_24117);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24, 1, 3, (V[]){v_r_24115, v_hd_24117, v_k_24118});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args) {
  V v_x_24138 = args[0];
  V v_x_24131 = heff_env(self)[0];
  V v_x_24135 = heff_env(self)[1];
  V v_k_24134 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24139 = ({ V a_0 = v_x_24131; V a_1 = v_x_24135; V a_2 = v_x_24138; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24135); heff_drop(v_x_24138); r_; });
  V f_ = v_k_24134;
  args[0] = v_t_24139;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args) {
  V v_x_24135 = args[0];
  V v_bodyN_24128 = heff_env(self)[0];
  V v_hd_24133 = heff_env(self)[1];
  V v_x_24131 = heff_env(self)[2];
  V v_k_24134 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24136 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_bodyN_24128));
  V v_c_24137 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_24136}));
  return heff_tail(v_c_24137, 2, (V[]){v_hd_24133, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28, 1, 3, (V[]){v_x_24131, v_x_24135, v_k_24134})});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args) {
  V v_hd_24133 = args[0];
  V v_k_24134 = args[1];
  V v_c_24132 = heff_env(self)[0];
  V v_bodyN_24128 = heff_env(self)[1];
  V v_x_24131 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24132;
  args[0] = heff_dup(v_hd_24133);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27, 1, 4, (V[]){v_bodyN_24128, v_hd_24133, v_x_24131, v_k_24134});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args) {
  V v_hd_24175 = args[0];
  V v_k_24176 = args[1];
  V v_it2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24175);
  V v_t_24177 = (g_heff_2eelab_2erules_2eabandonChk(v_it2_242));
  V f_ = v_k_24176;
  args[0] = v_t_24177;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args) {
  V v_x_24182 = args[0];
  V v_k_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24183 = ({ V a_0 = v_x_24182; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_x_24182); r_; });
  V f_ = v_k_24181;
  args[0] = v_t_24183;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args) {
  V v_hd_24180 = args[0];
  V v_k_24181 = args[1];
  V v_c_24179 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24179;
  args[0] = v_hd_24180;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31, 1, 1, (V[]){v_k_24181});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam20(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_it2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_it1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_it2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
    }
    case TAG_CType: {
      V v_t_244 = heff_field(v_it1_241, 0);
      heff_take_n(v_it1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      V v_c_245 = ({ V a_0 = v_t_244; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_244); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0, 2, 2, (V[]){v_c_245, v_it2_242});
    }
    case TAG_CLam: {
      heff_take_n(v_it1_241, 0ULL, 3);
      heff_drop(v_it2_242);
      V v_c_2413 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2, 2, 2, (V[]){v_c_2413, v_n_240});
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_it1_241, 0ULL, 3);
      heff_drop(v_it2_242);
      V v_c_2447 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4, 2, 2, (V[]){v_c_2447, v_n_240});
    }
    case TAG_CAnnLam: {
      heff_take_n(v_it1_241, 0ULL, 4);
      heff_drop(v_it2_242);
      V v_c_2482 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6, 2, 2, (V[]){v_c_2482, v_n_240});
    }
    case TAG_CTag: {
      heff_take_n(v_it1_241, 0ULL, 3);
      heff_drop(v_it2_242);
      V v_c_24116 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8, 2, 2, (V[]){v_c_24116, v_n_240});
    }
    case TAG_CStruct: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      V v_c_24148 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10, 2, 2, (V[]){v_c_24148, v_n_240});
    }
    case TAG_CMatch: {
      heff_take_n(v_it1_241, 0ULL, 2);
      heff_drop(v_it2_242);
      V v_c_24181 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12, 2, 2, (V[]){v_c_24181, v_n_240});
    }
    case TAG_CLetIn: {
      heff_take_n(v_it1_241, 0ULL, 2);
      heff_drop(v_it2_242);
      V v_c_24214 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14, 2, 2, (V[]){v_c_24214, v_n_240});
    }
    case TAG_CLocal: {
      heff_take_n(v_it1_241, 0ULL, 2);
      heff_drop(v_it2_242);
      V v_c_24247 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16, 2, 2, (V[]){v_c_24247, v_n_240});
    }
    case TAG_CAbandon: {
      heff_drop(v_it2_242);
      V v_c_24278 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18, 2, 2, (V[]){v_c_24278, v_n_240});
    }
    case TAG_CNominal: {
      heff_take_n(v_it1_241, 0ULL, 1);
      heff_drop(v_it2_242);
      V v_c_24310 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam20, 2, 2, (V[]){v_c_24310, v_n_240});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_it2_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = ({ V a_0 = v_it2_242; V a_1 = v_x_248; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_248); r_; });
  V f_ = v_k_247;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1, 1, 2, (V[]){v_it2_242, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2417 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2417, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2417, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2417, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2417, 0ULL, 3);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2417, 0ULL, 4);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2417, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2417, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2417, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2417, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2417, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2417, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2417);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2443;
  switch (heff_tag_of(v_t_2442)) {
  case TAG_True: {
    v_x_2443 = v_x_2416;
    break;
  }
  case TAG_False: {
    v_x_2443 = ({ V a_0 = v_x_2416; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2416); r_; });
    break;
  }
  default: heff_nomatch(v_t_2442);
  }
  V f_ = v_k_2415;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3, 1, 2, (V[]){v_n_240, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2451 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2451)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2451, 0ULL, 1);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2451, 0ULL, 1);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2451, 0ULL, 3);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2451, 0ULL, 3);
      v_t_2476 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2451, 0ULL, 4);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2451, 0ULL, 3);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2451, 0ULL, 1);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2451, 0ULL, 2);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2451, 0ULL, 2);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2451, 0ULL, 2);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2451, 0ULL, 1);
      v_t_2476 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2451);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2477;
  switch (heff_tag_of(v_t_2476)) {
  case TAG_True: {
    v_x_2477 = v_x_2450;
    break;
  }
  case TAG_False: {
    v_x_2477 = ({ V a_0 = v_x_2450; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2450); r_; });
    break;
  }
  default: heff_nomatch(v_t_2476);
  }
  V f_ = v_k_2449;
  args[0] = v_x_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5, 1, 2, (V[]){v_n_240, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args) {
  V v_x_2485 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2484 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24111;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2486 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2486)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2486, 0ULL, 1);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2486, 0ULL, 1);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2486, 0ULL, 3);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2486, 0ULL, 3);
      v_t_24111 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2486, 0ULL, 4);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2486, 0ULL, 3);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2486, 0ULL, 1);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2486, 0ULL, 2);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2486, 0ULL, 2);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2486, 0ULL, 2);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2486, 0ULL, 1);
      v_t_24111 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2486);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24112;
  switch (heff_tag_of(v_t_24111)) {
  case TAG_True: {
    v_x_24112 = v_x_2485;
    break;
  }
  case TAG_False: {
    v_x_24112 = ({ V a_0 = v_x_2485; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2485); r_; });
    break;
  }
  default: heff_nomatch(v_t_24111);
  }
  V f_ = v_k_2484;
  args[0] = v_x_24112;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k_2484 = args[1];
  V v_c_2482 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2482;
  args[0] = v_hd_2483;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7, 1, 2, (V[]){v_n_240, v_k_2484});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args) {
  V v_x_24119 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24118 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24145;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24120 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24120)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24120, 0ULL, 1);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24120, 0ULL, 1);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24120, 0ULL, 3);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24120, 0ULL, 3);
      v_t_24145 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24120, 0ULL, 4);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24120, 0ULL, 3);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24120, 0ULL, 1);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24120, 0ULL, 2);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24120, 0ULL, 2);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24120, 0ULL, 2);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24120, 0ULL, 1);
      v_t_24145 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24120);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24146;
  switch (heff_tag_of(v_t_24145)) {
  case TAG_True: {
    v_x_24146 = v_x_24119;
    break;
  }
  case TAG_False: {
    v_x_24146 = ({ V a_0 = v_x_24119; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24119); r_; });
    break;
  }
  default: heff_nomatch(v_t_24145);
  }
  V f_ = v_k_24118;
  args[0] = v_x_24146;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args) {
  V v_hd_24117 = args[0];
  V v_k_24118 = args[1];
  V v_c_24116 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24116;
  args[0] = v_hd_24117;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9, 1, 2, (V[]){v_n_240, v_k_24118});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args) {
  V v_x_24151 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24150 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24177;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24152 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24152)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24152, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24152, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24152, 0ULL, 3);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24152, 0ULL, 3);
      v_t_24177 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24152, 0ULL, 4);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24152, 0ULL, 3);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24152, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24152, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24152, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24152, 0ULL, 2);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24152, 0ULL, 1);
      v_t_24177 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24152);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24178;
  switch (heff_tag_of(v_t_24177)) {
  case TAG_True: {
    v_x_24178 = v_x_24151;
    break;
  }
  case TAG_False: {
    v_x_24178 = ({ V a_0 = v_x_24151; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24151); r_; });
    break;
  }
  default: heff_nomatch(v_t_24177);
  }
  V f_ = v_k_24150;
  args[0] = v_x_24178;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args) {
  V v_hd_24149 = args[0];
  V v_k_24150 = args[1];
  V v_c_24148 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24148;
  args[0] = v_hd_24149;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11, 1, 2, (V[]){v_n_240, v_k_24150});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args) {
  V v_x_24184 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24183 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24210;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24185 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24185)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24185, 0ULL, 1);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24185, 0ULL, 1);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24185, 0ULL, 3);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24185, 0ULL, 3);
      v_t_24210 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24185, 0ULL, 4);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24185, 0ULL, 3);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24185, 0ULL, 1);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24185, 0ULL, 2);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24185, 0ULL, 2);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24185, 0ULL, 2);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24185, 0ULL, 1);
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24185);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24211;
  switch (heff_tag_of(v_t_24210)) {
  case TAG_True: {
    v_x_24211 = v_x_24184;
    break;
  }
  case TAG_False: {
    v_x_24211 = ({ V a_0 = v_x_24184; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24184); r_; });
    break;
  }
  default: heff_nomatch(v_t_24210);
  }
  V f_ = v_k_24183;
  args[0] = v_x_24211;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args) {
  V v_hd_24182 = args[0];
  V v_k_24183 = args[1];
  V v_c_24181 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24181;
  args[0] = v_hd_24182;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13, 1, 2, (V[]){v_n_240, v_k_24183});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args) {
  V v_x_24217 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24216 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24243;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24218 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24218)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24218, 0ULL, 1);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24218, 0ULL, 1);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24218, 0ULL, 3);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24218, 0ULL, 3);
      v_t_24243 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24218, 0ULL, 4);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24218, 0ULL, 3);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24218, 0ULL, 1);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24218, 0ULL, 2);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24218, 0ULL, 2);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24218, 0ULL, 2);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24218, 0ULL, 1);
      v_t_24243 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24218);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24244;
  switch (heff_tag_of(v_t_24243)) {
  case TAG_True: {
    v_x_24244 = v_x_24217;
    break;
  }
  case TAG_False: {
    v_x_24244 = ({ V a_0 = v_x_24217; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24217); r_; });
    break;
  }
  default: heff_nomatch(v_t_24243);
  }
  V f_ = v_k_24216;
  args[0] = v_x_24244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args) {
  V v_hd_24215 = args[0];
  V v_k_24216 = args[1];
  V v_c_24214 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24214;
  args[0] = v_hd_24215;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15, 1, 2, (V[]){v_n_240, v_k_24216});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args) {
  V v_x_24250 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24276;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24251 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24251)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24251, 0ULL, 1);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24251, 0ULL, 1);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24251, 0ULL, 3);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24251, 0ULL, 3);
      v_t_24276 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24251, 0ULL, 4);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24251, 0ULL, 3);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24251, 0ULL, 1);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24251, 0ULL, 2);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24251, 0ULL, 2);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24251, 0ULL, 2);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24251, 0ULL, 1);
      v_t_24276 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24251);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24277;
  switch (heff_tag_of(v_t_24276)) {
  case TAG_True: {
    v_x_24277 = v_x_24250;
    break;
  }
  case TAG_False: {
    v_x_24277 = ({ V a_0 = v_x_24250; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24250); r_; });
    break;
  }
  default: heff_nomatch(v_t_24276);
  }
  V f_ = v_k_24249;
  args[0] = v_x_24277;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args) {
  V v_hd_24248 = args[0];
  V v_k_24249 = args[1];
  V v_c_24247 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24247;
  args[0] = v_hd_24248;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17, 1, 2, (V[]){v_n_240, v_k_24249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args) {
  V v_x_24281 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24280 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24307;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24282 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24282)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24282, 0ULL, 1);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24282, 0ULL, 1);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24282, 0ULL, 3);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24282, 0ULL, 3);
      v_t_24307 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24282, 0ULL, 4);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24282, 0ULL, 3);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24282, 0ULL, 1);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24282, 0ULL, 2);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24282, 0ULL, 2);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24282, 0ULL, 2);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24282, 0ULL, 1);
      v_t_24307 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24282);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24308;
  switch (heff_tag_of(v_t_24307)) {
  case TAG_True: {
    v_x_24308 = v_x_24281;
    break;
  }
  case TAG_False: {
    v_x_24308 = ({ V a_0 = v_x_24281; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24281); r_; });
    break;
  }
  default: heff_nomatch(v_t_24307);
  }
  V f_ = v_k_24280;
  args[0] = v_x_24308;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args) {
  V v_hd_24279 = args[0];
  V v_k_24280 = args[1];
  V v_c_24278 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24278;
  args[0] = v_hd_24279;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19, 1, 2, (V[]){v_n_240, v_k_24280});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam21(V self, V *args) {
  V v_x_24313 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24312 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24339;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24314 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24314)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24314, 0ULL, 1);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24314, 0ULL, 1);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24314, 0ULL, 3);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24314, 0ULL, 3);
      v_t_24339 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24314, 0ULL, 4);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24314, 0ULL, 3);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24314, 0ULL, 1);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24314, 0ULL, 2);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24314, 0ULL, 2);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24314, 0ULL, 2);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24314, 0ULL, 1);
      v_t_24339 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24314);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24340;
  switch (heff_tag_of(v_t_24339)) {
  case TAG_True: {
    v_x_24340 = v_x_24313;
    break;
  }
  case TAG_False: {
    v_x_24340 = ({ V a_0 = v_x_24313; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24313); r_; });
    break;
  }
  default: heff_nomatch(v_t_24339);
  }
  V f_ = v_k_24312;
  args[0] = v_x_24340;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam20(V self, V *args) {
  V v_hd_24311 = args[0];
  V v_k_24312 = args[1];
  V v_c_24310 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24310;
  args[0] = v_hd_24311;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam21, 1, 2, (V[]){v_n_240, v_k_24312});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = ({ V a_0 = v_t_243; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    V v_d_2412 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 29ULL, 5);
    V v_c_2413 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2411); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2, 2, 4, (V[]){v_c_2413, v_d_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2431 = heff_field(v_x2_240, 0);
    V v_sp_2433 = heff_field(v_x2_240, 2);
    V v_t_2434 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2435 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2434); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8, 2, 3, (V[]){v_c_2435, v_sp_2433, v_x_2431});
  }
  case TAG_PiAnon: {
    V v_d_2439 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2440 = ({ V a_0 = v_d_2439; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_d_2439); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10, 2, 1, (V[]){v_c_2440});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(a[0]);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_c_2419 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427;
  switch (heff_tag_of(v_c_2419)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_c_2419, 1);
    heff_take_n(v_c_2419, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_c_2419);
  }
  V v_x_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2424, v_t_2427})});
  V f_ = v_k_2423;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6, 1, 2, (V[]){v_c_2419, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_NamedImplicit, 4, (V[]){v_sp_2410, v_x_248, v_x_2416, v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2429;
  switch (heff_tag_of(v_d_2412)) {
  case TAG_Nothing: {
    v_c_2429 = ((V)&g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_d_2412, 0);
    heff_take_n(v_d_2412, 1ULL, 1);
    V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
    V v_c_2421 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2420}));
    v_c_2429 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5, 2, 2, (V[]){v_c_2421, v_c_2419});
    break;
  }
  default: heff_nomatch(v_d_2412);
  }
  return heff_tail(v_c_2429, 2, (V[]){v_hd_2414, heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7, 1, 4, (V[]){v_k_2415, v_sp_2410, v_x_248, v_x_2416})});
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_sp_2410 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3, 1, 5, (V[]){v_d_2412, v_hd_2414, v_k_2415, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2437 = heff_env(self)[0];
  V v_sp_2433 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_NamedInstance, 3, (V[]){v_sp_2433, v_x_2431, v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_sp_2433 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9, 1, 3, (V[]){v_k_2437, v_sp_2433, v_x_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_Anonymous, 1, (V[]){v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2440;
  args[0] = v_hd_2441;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11, 1, 1, (V[]){v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0, 48, (101, 120, 112, 101, 99, 116, 101, 100, 32, 97, 32, 102, 105, 101, 108, 100, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 32, 96, 120, 32, 58, 32, 65, 96));
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2, 2, 0};
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_c_247 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0, 2, 3, (V[]){v_c_247, heff_dup(v_d_246), heff_dup(v_x_243)});
    }
    case TAG_BadFieldDecl: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421;
  switch (heff_tag_of(v_c_2413)) {
  case TAG_At: {
    V v_s_2420 = heff_field(v_c_2413, 1);
    heff_take_n(v_c_2413, 2ULL, 2);
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_c_2413);
  }
  V v_x_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2418, v_t_2421})});
  V f_ = v_k_2417;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4, 1, 2, (V[]){v_c_2413, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_249;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_243, v_x_2410, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2423;
  switch (heff_tag_of(v_d_246)) {
  case TAG_Nothing: {
    v_c_2423 = ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_d_246, 0);
    heff_take_n(v_d_246, 1ULL, 1);
    V v_t_2414 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2413)));
    V v_c_2415 = heff_tr(heff_apply(((V)&g_heff_2eelab_2etoplevel_2erecoveringChk_clo), 1, (V[]){v_t_2414}));
    v_c_2423 = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3, 2, 2, (V[]){v_c_2415, v_c_2413});
    break;
  }
  default: heff_nomatch(v_d_246);
  }
  return heff_tail(v_c_2423, 2, (V[]){v_hd_248, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5, 1, 3, (V[]){v_k_249, v_x_243, v_x_2410})});
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1, 1, 4, (V[]){v_d_246, v_hd_248, v_k_249, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k2_2427 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_apply(heff_take_field(v_hd_2426, 2), 1, (V[]){v_t_2430}));
  V f_ = heff_get_n(v_hd_2426, 1, 3);
  args[0] = v_t_2431;
  args[1] = v_k2_2427;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_x_243));
    V v_c_2413 = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1, 2, 2, (V[]){v_a_245, v_x_243});
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3, 2, 2, (V[]){v_c_2413, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411;
  switch (heff_tag_of(v_x_243)) {
  case TAG_At: {
    V v_a_2410 = heff_field(v_x_243, 1);
    heff_take_n(v_x_243, 2ULL, 2);
    v_t_2411 = v_a_2410;
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_a_2412 = ({ V a_0 = v_t_2411; V a_1 = v_a_248; V r_ = (g_heff_2eelab_2erules_2easSmall(a_0, a_1)); heff_drop(v_a_248); r_; });
  V f_ = v_a_247;
  args[0] = v_a_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_245;
  args[0] = v_a_246;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2, 1, 2, (V[]){v_x_243, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2417 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(v_xs_244));
  return heff_tail(v_c_2417, 2, (V[]){v_hd_2414, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam5, 1, 2, (V[]){v_k_2415, v_x_2416})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam4, 1, 3, (V[]){v_xs_244, v_hd_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0, 45, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 118, 97, 114, 105, 97, 110, 116, 32, 105, 110, 32, 97, 32, 115, 117, 109, 32, 116, 121, 112, 101));
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 5ULL, 3);
      heff_drop(v_x22_242);
      V v_c_246 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(v_args_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0, 2, 2, (V[]){v_c_246, v_x_243});
    }
    case TAG_BadVariant: {
      heff_take_n(v_x21_241, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2, 2, 1, (V[]){v_x22_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(a[0]);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, heff_arrayFromList(v_x_249)});
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1, 1, 2, (V[]){v_x_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8, 3, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_it1_241 = heff_field(v_n_240, 0);
    V v_it2_242 = heff_field(v_n_240, 1);
    switch (heff_tag_of(v_it1_241)) {
    case TAG_TPi: {
      V v_b_243 = heff_field(v_it1_241, 0);
      V v_codN_244 = heff_field(v_it1_241, 1);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(heff_dup(v_b_243)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0, 2, 2, (V[]){v_c_245, heff_dup(v_codN_244)});
    }
    case TAG_TSig: {
      V v_fields_2412 = heff_field(v_it1_241, 0);
      V v_c_2413 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(heff_dup(v_fields_2412)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3, 2, 1, (V[]){v_c_2413});
    }
    case TAG_TSum: {
      V v_variantNs_2418 = heff_field(v_it1_241, 0);
      V v_c_2419 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(heff_dup(v_variantNs_2418)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5, 2, 1, (V[]){v_c_2419});
    }
    case TAG_TType: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7_clo);
    }
    case TAG_TInt: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo);
    }
    case TAG_TFloat: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo);
    }
    case TAG_TString: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo);
    }
    case TAG_TRune: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo);
    }
    case TAG_TArray: {
      V v_a0_2444 = heff_field(v_it1_241, 0);
      V v_c_2445 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_a0_2444));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14, 2, 1, (V[]){v_c_2445});
    }
    case TAG_TFixed: {
      V v_w_2450 = heff_field(v_it1_241, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16, 2, 1, (V[]){heff_dup(v_w_2450)});
    }
    case TAG_TInf: {
      V v_i_2458 = heff_field(v_it1_241, 0);
      V v_c_2459 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_2458)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19, 2, 2, (V[]){v_c_2459, heff_dup(v_it2_242)});
    }
    case TAG_TChk: {
      V v_ch_2464 = heff_field(v_it1_241, 0);
      V v_c_2465 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_ch_2464)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21, 2, 1, (V[]){v_c_2465});
    }
    case TAG_TNominal: {
      V v_t_2477 = heff_field(v_it1_241, 0);
      V v_c_2478 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2477));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26, 2, 1, (V[]){v_c_2478});
    }
    default: return heff_nomatch(v_it1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_x_248; V a_1 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_codN_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = ({ V a_0 = v_codN_244; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_codN_244); r_; });
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2, 1, 2, (V[]){v_x_248, v_k_247})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_codN_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1, 1, 3, (V[]){v_codN_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = (g_heff_2eelab_2erules_2erecordFormation(v_x_2416));
  V f_ = v_k_2415;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = (g_list_2emap_24s1415906091x1371825187(heff_dup(v_x_2422)));
  V v_t_2424 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2422));
  V v_t_2425 = (g_list_2emap_24s366344330x1145113647(v_x_2422));
  V v_t_2426 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2423), v_t_2424, heff_arrayFromList(v_t_2425)});
  V v_x_2427 = (g_heff_2eelab_2erules_2esumFormation(v_t_2426));
  V f_ = v_k_2421;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2419;
  args[0] = v_hd_2420;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6, 1, 1, (V[]){v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args) {
  V v_u2_2434 = args[0];
  heff_drop(v_u2_2434);
  V v_t_2435 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2435});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args) {
  V v_e_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  heff_drop(v_e_2430);
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
  V f_ = v_k_2432;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2433, ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = ({ V a_0 = v_x_2448; V r_ = (g_heff_2eelab_2erules_2eprimArray(a_0)); heff_drop(v_x_2448); r_; });
  V f_ = v_k_2447;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2445;
  args[0] = v_hd_2446;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15, 1, 1, (V[]){v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args) {
  V v_u_2456 = args[0];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2450})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args) {
  V v_e_2453 = args[0];
  V v_hd_2454 = args[1];
  V v_k_2455 = args[2];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2453);
  heff_drop(v_hd_2454);
  V v_t_2457 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){heff_dup(v_w_2450)}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18, 1, 1, (V[]){v_w_2450})});
  V f_ = v_k_2455;
  args[0] = v_t_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_w_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17, 3, 1, (V[]){v_w_2450})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args) {
  V v_x_2462 = args[0];
  V v_it2_242 = heff_env(self)[0];
  V v_k_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = ({ V a_0 = v_it2_242; V a_1 = v_x_2462; V r_ = (g_heff_2eelab_2erules_2euniverseElimSyn(a_0, a_1)); heff_drop(v_x_2462); r_; });
  V f_ = v_k_2461;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_c_2459 = heff_env(self)[0];
  V v_it2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2459;
  args[0] = v_hd_2460;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20, 1, 2, (V[]){v_it2_242, v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args) {
  V v_x_2475 = args[0];
  V v_k_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = (g_heff_2eelab_2ememoed_2edecode(v_x_2475));
  V f_ = v_k_2474;
  args[0] = v_t_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_c_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2472;
  args[0] = v_hd_2473;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25, 1, 1, (V[]){v_k_2474});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args) {
  V v_e_2469 = args[0];
  V v_x_2468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2472;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_MkChk: {
    V v_f_2470 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24MkChk = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    V v_t_2471 = heff_tag_at_n(v_ru_24x_2468_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
    v_c_2472 = heff_tr(heff_apply(v_f_2470, 2, (V[]){v_e_2469, v_t_2471}));
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24, 2, 1, (V[]){v_c_2472});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2467;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23, 1, 1, (V[]){v_x_2468})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2465;
  args[0] = v_hd_2466;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22, 1, 1, (V[]){v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args) {
  V v_x_2481 = args[0];
  V v_k_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2482 = ({ V a_0 = v_x_2481; V r_ = (g_heff_2eelab_2etoplevel_2enominalTyp(a_0)); heff_drop(v_x_2481); r_; });
  V f_ = v_k_2480;
  args[0] = v_t_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_c_2478 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2478;
  args[0] = v_hd_2479;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27, 1, 1, (V[]){v_k_2480});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eargBinding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eargBinding_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eargBinding(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_t_245 = heff_field(v_x11_241, 2);
      V v_n_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_At: {
        V v_n_246 = heff_field(v_t_245, 0);
        V v_sp_247 = heff_field(v_t_245, 1);
        v_n_248 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_247), heff_dup(v_n_246)));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      V v_c_249 = ({ V a_0 = v_n_248; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_248); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam0, 2, 3, (V[]){v_c_249, heff_dup(v_sp_242), heff_dup(v_x_243)});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_t_2416 = heff_field(v_x11_241, 2);
      V v_n_2419;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_At: {
        V v_n_2417 = heff_field(v_t_2416, 0);
        V v_sp_2418 = heff_field(v_t_2416, 1);
        v_n_2419 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2418), heff_dup(v_n_2417)));
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_c_2420 = ({ V a_0 = v_n_2419; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2419); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam2, 2, 3, (V[]){v_c_2420, heff_dup(v_sp_242), heff_dup(v_x_2414)});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eargBinding(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_243, v_x_2412, NTAG(TAG_Expl)});
  V f_ = v_k_2411;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam1, 1, 3, (V[]){v_sp_242, v_x_243, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_2414, v_x_2423, NTAG(TAG_Impl)});
  V f_ = v_k_2422;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam3, 1, 3, (V[]){v_sp_242, v_x_2414, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithOne(V v_ab_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_c_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_take_field(v_ab_240, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Expl: {
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Named, 2, (V[]){heff_dup(heff_rfield(v_ab_240, 1)), heff_dup(heff_rfield(v_ab_240, 2))});
      V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_t_242; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_242); r_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, ({ V a_0 = heff_dup(heff_rfield(v_ab_240, 0)); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_243; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_c_243); r_; })});
    }
    case TAG_Impl: {
      V v_t_247 = heff_tag_n(TAG_NamedImplicit, 4, (V[]){heff_dup(heff_rfield(v_ab_240, 0)), heff_dup(heff_rfield(v_ab_240, 1)), heff_take_field(v_ab_240, 2), NTAG(TAG_Nothing)});
      V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_t_242; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_242); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, ({ V a_0 = heff_dup(heff_rfield(v_ab_240, 0)); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_243; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_243); r_; })});
    }
    case TAG_Inst: {
      V v_t_249 = heff_tag_n(TAG_NamedInstance, 3, (V[]){heff_dup(heff_rfield(v_ab_240, 0)), heff_dup(heff_rfield(v_ab_240, 1)), heff_take_field(v_ab_240, 2)});
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_t_242; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_242); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, ({ V a_0 = heff_dup(heff_rfield(v_ab_240, 0)); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_243; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_243); r_; })});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithOne(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithArgs_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_base_241;
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_rest_243, v_base_241));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2ewithOne(heff_dup(v_ab_242), v_t_244);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2ewithArgs(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2eargBinding(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(v_xs_244));
  return heff_tail(v_c_249, 2, (V[]){v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam3, 1, 2, (V[]){v_k_247, v_x_248})});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etheoryD_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_lam4, 1, 0};
V g_heff_2eelab_2etoplevel_2etheoryD_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etheoryD_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_lam3, 3, 0};
V g_heff_2eelab_2etoplevel_2etheoryD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etheoryD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etheoryD_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etheoryD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etheoryD(V v_name_240, V v_params_241, V v_bodyN_242) {
top: ;
  V v_c_243 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(v_params_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam0, 2, 3, (V[]){v_c_243, heff_dup(v_bodyN_242), v_name_240});
}
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etheoryD(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam4(V self, V *args) {
  V v_u2_2416 = args[0];
  heff_drop(v_u2_2416);
  V v_t_2417 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2417});
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam3(V self, V *args) {
  V v_e_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_e_2412);
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
  V f_ = v_k_2414;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2415, ((V)&g_heff_2eelab_2etoplevel_2etheoryD_lam4_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etheoryD_lam3_clo)}), v_x_2411});
  V v_x2_2419 = ({ V a_0 = v_x_246; V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_ty_2420 = heff_field(v_x2_2419, 0);
    V v_tm_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2420, v_tm_2421, NTAG(TAG_False)});
    V f_ = v_k_245;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_bodyN_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_249;
  switch (heff_tag_of(v_bodyN_242)) {
  case TAG_At: {
    V v_n_247 = heff_field(v_bodyN_242, 0);
    V v_sp_248 = heff_field(v_bodyN_242, 1);
    heff_take_n(v_bodyN_242, 3ULL, 2);
    v_n_249 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_248, v_n_247));
    break;
  }
  default: heff_nomatch(v_bodyN_242);
  }
  V v_c_2410 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_249));
  return heff_tail(v_c_2410, 2, (V[]){v_hd_244, heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam2, 1, 3, (V[]){v_x_246, v_name_240, v_k_245})});
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_bodyN_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam1, 1, 4, (V[]){v_bodyN_242, v_hd_244, v_name_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ab_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_ab_241, 3);
    V v_x1_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Expl: {
      v_x1_244 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_x1_244 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_x1_244 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ab_241, 1, 4), (g_heff_2eelab_2etoplevel_2eexplicitNames(v_rest_242))});
    }
    case TAG_False: {
      heff_drop_rec(v_ab_241, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames(a[0]);
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edefineD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edefineD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2edefineD(V v_name_240, V v_params_241, V v_tyN_242, V v_bodyN_243) {
top: ;
  V v_c_244 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(v_params_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam0, 2, 4, (V[]){v_c_244, heff_dup(v_tyN_242), heff_dup(v_bodyN_243), v_name_240});
}
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2edefineD(a[0], a[1], a[2], a[3]); heff_drop(a[2]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2418 = ({ V a_0 = v_x_247; V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, v_x_2417}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_247); r_; });
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_ty_2419 = heff_field(v_x2_2418, 0);
    V v_tm_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2419, v_tm_2420, NTAG(TAG_False)});
    V f_ = v_k_246;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_bodyN_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2415;
  switch (heff_tag_of(v_bodyN_243)) {
  case TAG_At: {
    V v_n_2413 = heff_field(v_bodyN_243, 0);
    V v_sp_2414 = heff_field(v_bodyN_243, 1);
    heff_take_n(v_bodyN_243, 3ULL, 2);
    v_n_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
    break;
  }
  default: heff_nomatch(v_bodyN_243);
  }
  V v_c_2416 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2415));
  return heff_tail(v_c_2416, 2, (V[]){v_hd_245, heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam3, 1, 4, (V[]){v_x_247, v_x_2412, v_name_240, v_k_246})});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_tyN_242 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2410;
  switch (heff_tag_of(v_tyN_242)) {
  case TAG_At: {
    V v_n_248 = heff_field(v_tyN_242, 0);
    V v_sp_249 = heff_field(v_tyN_242, 1);
    heff_take_n(v_tyN_242, 3ULL, 2);
    v_n_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_249, v_n_248));
    break;
  }
  default: heff_nomatch(v_tyN_242);
  }
  V v_c_2411 = ({ V a_0 = v_n_2410; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2410); r_; });
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam2, 1, 5, (V[]){v_bodyN_243, v_hd_245, v_x_247, v_name_240, v_k_246})});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_tyN_242 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam1, 1, 5, (V[]){v_tyN_242, v_hd_245, v_bodyN_243, v_name_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsBody_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eequationsBody(V v_name_240, V v_args_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2eexplicitNames(v_args_241));
  V v_t_245 = (g_heff_2eelab_2eclauses_2edesugar(v_name_240, v_t_244, v_eqs_242, v_sp_243));
  V v_c_2416;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Left: {
    V v_err_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_c_2416 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam0, 2, 1, (V[]){v_err_246});
    break;
  }
  case TAG_Right: {
    V v_b_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_c_2416 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam1, 2, 1, (V[]){v_b_2413});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam2, 2, 1, (V[]){v_c_2416});
}
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eequationsBody(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_err_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_246, 1), heff_get_n(v_err_246, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_b_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_b_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_2422;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_At: {
    V v_n_2420 = heff_field(v_x_2419, 0);
    V v_sp_2421 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 3ULL, 2);
    v_n_2422 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2421, v_n_2420));
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_t_2423 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2422));
  return heff_tail(v_t_2423, 2, (V[]){v_hd_2417, v_k_2418});
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam3, 1, 2, (V[]){v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eequationsD(V v_name_240, V v_tyN_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(v_eqs_242));
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_c_2430;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_c_2430 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam0, 2, 3, (V[]){v_eqs_242, heff_dup(v_name_240), v_sp_243});
    break;
  }
  case TAG_False: {
    v_c_2430 = (g_heff_2eelab_2etoplevel_2eequationsBody(heff_dup(v_name_240), NTAG(TAG_Nil), v_eqs_242, v_sp_243));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam9, 2, 3, (V[]){v_c_2430, heff_dup(v_tyN_241), v_name_240});
}
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eequationsD(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_248, 1, 6), v_m_2417));
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_2413 = heff_env(self)[0];
  V v_fsp_2414 = heff_env(self)[1];
  V v_rhs_2416 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2413, v_fsp_2414, v_x_2421, v_rhs_2416}), v_sp_2412});
  V f_ = v_k_2420;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_f_2413 = heff_env(self)[1];
  V v_fsp_2414 = heff_env(self)[2];
  V v_rhs_2416 = heff_env(self)[3];
  V v_sp_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam5, 1, 5, (V[]){v_f_2413, v_fsp_2414, v_rhs_2416, v_sp_2412, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args) {
  V v_m_2410 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2410)) {
  case TAG_At: {
    V v_x21_2411 = heff_field(v_m_2410, 0);
    V v_sp_2412 = heff_field(v_m_2410, 1);
    heff_take_n(v_m_2410, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkEquation: {
      V v_f_2413 = heff_field(v_x21_2411, 0);
      V v_fsp_2414 = heff_field(v_x21_2411, 1);
      V v_ps_2415 = heff_field(v_x21_2411, 2);
      V v_rhs_2416 = heff_field(v_x21_2411, 3);
      heff_take_n(v_x21_2411, 15ULL, 4);
      V v_c_2418 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam3, 1, 1, (V[]){v_e_248}), v_ps_2415));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam4, 2, 5, (V[]){v_c_2418, v_f_2413, v_fsp_2414, v_rhs_2416, v_sp_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_m_2410);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_248 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_k_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkChk: {
    V v_f_2429 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    return heff_tail(v_f_2429, 4, (V[]){v_e_248, v_a_249, v_hd_2424, v_k_2425});
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  V v_a_249 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2427 = (g_heff_2eelab_2etoplevel_2eequationsBody(v_name_240, NTAG(TAG_Nil), v_x_2426, v_sp_243));
  return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_hd_2424), heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam8, 1, 4, (V[]){v_e_248, v_a_249, v_hd_2424, v_k_2425})});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  V v_a_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam7, 1, 6, (V[]){v_name_240, v_sp_243, v_hd_2424, v_e_248, v_a_249, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args) {
  V v_e_248 = args[0];
  V v_a_249 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2423 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam2, 1, 1, (V[]){heff_dup(v_e_248)}), v_eqs_242));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam6, 2, 5, (V[]){v_c_2423, v_name_240, v_sp_243, v_e_248, v_a_249});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam1, 2, 3, (V[]){v_eqs_242, v_name_240, v_sp_243})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2439 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2438, v_x_2433}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_ty_2440 = heff_field(v_x2_2439, 0);
    V v_tm_2441 = heff_field(v_x2_2439, 1);
    heff_take_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2440, v_tm_2441, NTAG(TAG_False)});
    V f_ = v_k_2432;
    args[0] = v_t_2442;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args) {
  V v_x_2433 = args[0];
  V v_tyN_241 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_2436;
  switch (heff_tag_of(v_tyN_241)) {
  case TAG_At: {
    V v_n_2434 = heff_field(v_tyN_241, 0);
    V v_sp_2435 = heff_field(v_tyN_241, 1);
    heff_take_n(v_tyN_241, 3ULL, 2);
    v_n_2436 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2435, v_n_2434));
    break;
  }
  default: heff_nomatch(v_tyN_241);
  }
  V v_c_2437 = ({ V a_0 = v_n_2436; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2436); r_; });
  return heff_tail(v_c_2437, 2, (V[]){v_hd_2431, heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam11, 1, 3, (V[]){v_x_2433, v_name_240, v_k_2432})});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_tyN_241 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam10, 1, 4, (V[]){v_tyN_241, v_hd_2431, v_name_240, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2edeclJ_str0, 45, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 116, 111, 112, 45, 108, 101, 118, 101, 108, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110));
HEFF_STRA(g_heff_2eelab_2etoplevel_2edeclJ_str1, 45, (117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 110, 111, 116, 97, 116, 105, 111, 110, 32, 102, 111, 114, 32, 116, 111, 112, 45, 108, 101, 118, 101, 108, 32, 100, 101, 99, 108, 97, 114, 97, 116, 105, 111, 110));
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_lam3, 1, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edeclJ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edeclJ(V v_d_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_d_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_DeclEquations: {
    V v_name_244 = heff_field(v_t_243, 0);
    V v_tyN_246 = heff_field(v_t_243, 2);
    V v_eqs_247 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 13ULL, 4);
    V v_t_2410;
    switch (heff_tag_of(v_tyN_246)) {
    case TAG_At: {
      V v_s_249 = heff_dup(heff_field(v_tyN_246, 1));
      v_t_2410 = v_s_249;
      break;
    }
    default: heff_nomatch(v_tyN_246);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_240)) {
    case TAG_At: {
      V v_s_2412 = heff_field(v_d_240, 1);
      v_t_2413 = heff_dup(v_s_2412);
      break;
    }
    default: heff_nomatch(v_d_240);
    }
    V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_n(v_t_2410, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
    return ({ V a_0 = v_name_244; V a_1 = v_tyN_246; V a_2 = v_eqs_247; V a_3 = v_t_2414; V r_ = (g_heff_2eelab_2etoplevel_2eequationsD(a_0, a_1, a_2, a_3)); heff_drop(v_tyN_246); r_; });
  }
  case TAG_DeclDefine: {
    V v_name_2415 = heff_field(v_t_243, 0);
    V v_params_2417 = heff_field(v_t_243, 2);
    V v_tyN_2418 = heff_field(v_t_243, 3);
    V v_bodyN_2419 = heff_field(v_t_243, 4);
    heff_take_n(v_t_243, 29ULL, 5);
    return ({ V a_0 = v_name_2415; V a_1 = v_params_2417; V a_2 = v_tyN_2418; V a_3 = v_bodyN_2419; V r_ = (g_heff_2eelab_2etoplevel_2edefineD(a_0, a_1, a_2, a_3)); heff_drop(v_tyN_2418); heff_drop(v_bodyN_2419); r_; });
  }
  case TAG_DeclTheory: {
    V v_name_2420 = heff_field(v_t_243, 0);
    V v_params_2422 = heff_field(v_t_243, 2);
    V v_bodyN_2423 = heff_field(v_t_243, 3);
    heff_take_n(v_t_243, 13ULL, 4);
    return ({ V a_0 = v_name_2420; V a_1 = v_params_2422; V a_2 = v_bodyN_2423; V r_ = (g_heff_2eelab_2etoplevel_2etheoryD(a_0, a_1, a_2)); heff_drop(v_bodyN_2423); r_; });
  }
  case TAG_DeclPrimitive: {
    V v_x_2424 = heff_field(v_t_243, 0);
    V v_tyN_2426 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_n_2429;
    switch (heff_tag_of(v_tyN_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_tyN_2426, 0);
      V v_sp_2428 = heff_field(v_tyN_2426, 1);
      heff_take_n(v_tyN_2426, 3ULL, 2);
      v_n_2429 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_tyN_2426);
    }
    V v_c_2430 = ({ V a_0 = v_n_2429; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2429); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam0, 2, 2, (V[]){v_c_2430, v_x_2424});
  }
  case TAG_DeclTest: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_sp_2445;
    switch (heff_tag_of(v_d_240)) {
    case TAG_At: {
      V v_s_2444 = heff_field(v_d_240, 1);
      v_sp_2445 = heff_dup(v_s_2444);
      break;
    }
    default: heff_nomatch(v_d_240);
    }
    return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam4, 2, 1, (V[]){v_sp_2445});
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_243, 0ULL, 1);
    V v_sp_2455;
    switch (heff_tag_of(v_d_240)) {
    case TAG_At: {
      V v_s_2454 = heff_field(v_d_240, 1);
      v_sp_2455 = heff_dup(v_s_2454);
      break;
    }
    default: heff_nomatch(v_d_240);
    }
    return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam5, 2, 1, (V[]){v_sp_2455});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2edeclJ(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args) {
  V v_u_2438 = args[0];
  heff_drop(v_u_2438);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args) {
  V v_e_2434 = args[0];
  V v_a_2435 = args[1];
  V v_hd_2436 = args[2];
  V v_k_2437 = args[3];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2434);
  heff_drop(v_a_2435);
  heff_drop(v_hd_2436);
  V v_t_2439 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_2424}), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo)});
  V f_ = v_k_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){heff_dup(v_x_2424), v_x_2433, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam2, 4, 1, (V[]){v_x_2424})}), NTAG(TAG_True)});
  V f_ = v_k_2432;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam1, 1, 2, (V[]){v_x_2424, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k2_2447 = args[1];
  V v_sp_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str0), v_sp_2445, NTAG(TAG_Nothing)});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_take_field(v_hd_2446, 2), 1, (V[]){v_t_2450}));
  V f_ = heff_get_n(v_hd_2446, 1, 3);
  args[0] = v_t_2451;
  args[1] = v_k2_2447;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_sp_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str1), v_sp_2455, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_take_field(v_hd_2456, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2456, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2erecoveredCheck_str0, 21, (101, 114, 114, 111, 114, 115, 32, 114, 101, 99, 111, 118, 101, 114, 101, 100, 32, 102, 114, 111, 109));
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1, 1, 2, (V[]){v_k_241, v_hd_240})});
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 1, 8);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_apply(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    return heff_tail(heff_get_n(v_hd_240, 1, 3), 2, (V[]){v_t_2412, v_k_241});
  }
}
Clo g_heff_2eelab_2etoplevel_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eanyL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eanyL(a[0], a[1]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2epoisonedLeft_str0, 54, (97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 97, 110, 32, 101, 114, 114, 111, 114, 32, 107, 101, 112, 116, 32, 102, 114, 111, 109, 32, 98, 101, 105, 110, 103, 32, 105, 110, 102, 101, 114, 114, 101, 100));
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2epoisonedLeft(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epoisonedLeft(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 2, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args) {
  V v_m_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = v_x_2411; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2411); r_; });
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_me_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_get_n(v_me_2416, 1, 6);
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      heff_take_n(v_t_2417, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = ({ V a_0 = v_x_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_t_2413 = (g_list_2emap_24s1415906091x1371825187(v_t_2412));
  V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4, 1, 1, (V[]){v_x_2411}); V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2413); r_; });
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_apply(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2422}));
    return heff_tail(heff_get_n(v_hd_240, 1, 3), 2, (V[]){v_t_2423, v_k_241});
  }
  case TAG_False: {
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241})});
}
Clo g_heff_2eelab_2etoplevel_2eappendM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendM(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2etoplevel_2eappendM(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2econcatMapM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapM(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2econcatMapM(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eelab_2etoplevel_2espineVals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2espineVals_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2espineVals(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_e_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_241));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_e_242, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_243, v_t_244));
  }
  case TAG_SpProj: {
    V v_sp_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V t_0 = v_sp_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_247 = heff_field(v_x1_240, 0);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    V v_t_2410 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_247));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2espineVals(a[0]);
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2emetasInV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emetasInV_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2emetasInV(V v_mc_240, V v_v_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_t_242, 0);
    V v_sp_244 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_h_243, 0);
      heff_take_n(v_h_243, 1ULL, 1);
      v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_HError: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_244));
    V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2emetasInV_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2etoplevel_2econcatMapM(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_2411, v_t_2414);
  }
  case TAG_VCode: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VLam: {
    heff_take_n(v_t_242, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_VCons: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2emetasInV(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args) {
  V v_v2_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_mc_240; V a_1 = v_v2_2413; V r_ = (g_heff_2eelab_2etoplevel_2emetasInV(a_0, a_1)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2etoplevel_2enubInt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enubInt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enubInt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2etoplevel_2enubInt_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2eelab_2etoplevel_2enubInt(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt(a[0]);
}
V g_heff_2eelab_2etoplevel_2enubInt_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_intEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eshownV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eshownV_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_243));
  V v_e_245 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_take_field(v_cs_242, 0), v_t_244));
  V v_t_2411 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2etoplevel_2eshownV_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2412 = heff_tr(heff_apply(heff_get_n(v_t_2411, 0, 2), 1, (V[]){v_e_245}));
  HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_242, 1, 2), v_e_2412);
}
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eshownV(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_247 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_246)));
  V v_t_248 = ({ V b_0 = heff_get_n(v_g_240, 2, 6); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_249 = ({ V a_0 = v_t_248; V a_1 = v_x_246; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_248); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nothing: {
    return v_d_247;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    heff_take_n(v_x2_249, 1ULL, 1);
    heff_drop(v_d_247);
    return v_x_2410;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str0, 50, (116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 102, 111, 117, 110, 100, 32, 100, 111, 32, 110, 111, 116, 32, 102, 105, 116, 32, 116, 111, 103, 101, 116, 104, 101, 114, 58, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str1, 5, (32, 97, 110, 100, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str2, 14, (32, 97, 114, 101, 32, 110, 111, 116, 32, 101, 113, 117, 97, 108));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str3, 11, (102, 111, 117, 110, 100, 32, 102, 111, 114, 32, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str4, 17, (96, 44, 32, 105, 116, 32, 119, 111, 117, 108, 100, 32, 110, 101, 101, 100, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str5, 3, (32, 61, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str6, 35, (99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 97, 110, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 58, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str7, 3, (32, 61, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str8, 24, (32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 115));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str9, 36, (99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str10, 14, (96, 58, 32, 103, 105, 118, 101, 32, 105, 116, 44, 32, 96, 40));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str11, 9, (32, 58, 61, 32, 46, 46, 46, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str12, 21, (119, 104, 97, 116, 32, 105, 115, 32, 107, 110, 111, 119, 110, 32, 111, 102, 32, 105, 116, 44, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str13, 3, (32, 61, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2estuckWith_str14, 25, (44, 32, 100, 111, 101, 115, 32, 110, 111, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 105, 116, 32, 105, 115));
Clo g_heff_2eelab_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get_n(v_p_241, 3, 4);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str0), heff_strAppend(heff_dup(v_left_243), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str1), heff_strAppend(heff_dup(v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str2)))));
    V v_t_248;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_248 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_247 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_248 = heff_get_n(v_me_247, 5, 6);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2411;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_249 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str3), heff_strAppend(heff_get_n(v_me_249, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str4), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str5), v_right_244)))));
      v_t_2411 = heff_tag_at_n(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){v_t_2410});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_246, v_t_248, v_t_2411});
  }
  case TAG_False: {
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str6), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str7), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str8)))));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2412, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2413 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str9), heff_strAppend(heff_dup(heff_rfield(v_me_2413, 4)), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str10), heff_strAppend(heff_dup(heff_rfield(v_me_2413, 4)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str11)))));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str12), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str13), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str14)))));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2414, heff_get_n(v_me_2413, 5, 6), heff_tag_n(TAG_Just, 1, (V[]){v_t_2415})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2etoplevel_2estuckAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_245 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 2))));
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245));
  V v_x1_247 = (g_heff_2eelab_2etoplevel_2enubInt(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = (g_map_2elookup_24s567992785x1569911877(v_x_248, v_mc_243));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2411 = (g_heff_2eelab_2etoplevel_2eshownV(heff_dup(v_g_240), v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_2412 = (g_heff_2eelab_2etoplevel_2eshownV(v_g_240, v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 2))));
  return (g_heff_2eelab_2etoplevel_2estuckWith(v_fallback_241, v_p_242, v_t_2410, v_t_2411, v_t_2412));
}
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2estuckAt(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eentryFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eentryFor_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244) {
top: ;
  V v_t_2410;
  switch (heff_tag_of(v_prim_242)) {
  case TAG_True: {
    v_t_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eentryFor_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_243)}), NTAG(TAG_Nothing)));
    break;
  }
  case TAG_False: {
    v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), v_k_241, heff_dup(v_tyStx_243), heff_dup(v_bodyStx_244)));
    break;
  }
  default: heff_nomatch(v_prim_242);
  }
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_244, v_tyStx_243, v_t_2410, v_t_2415});
}
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eentryFor(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_245);
  V v_x1_246 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_tyStx_243, NTAG(TAG_LNil)));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_247;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_246, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_249;
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2eelab_2etoplevel_2eerrEntry_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eerrEntry_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eerrEntry(V v_g_240, V v_k_241, V v_tyStx_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_a_247;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nom: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_a_247 = v_x_244;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_a_247 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_246 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_a_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eerrEntry_lam0, 1, 1, (V[]){v_a_247}), NTAG(TAG_Nothing)));
  V v_x1_2410 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_242, v_t_249, v_t_2414});
}
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eerrEntry(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eerrEntry_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_247;
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2echeckStuck(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_apply(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){v_t_249}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2echeckStuck_lam1, 1, 5, (V[]){v_g_240, v_sp_241, heff_dup(v_p_245), v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2echeckStuck(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2412 = ({ V a_0 = v_g_240; V a_1 = v_sp_241; V a_2 = v_p_245; V a_3 = v_x_2411; V r_ = (g_heff_2eelab_2etoplevel_2estuckAt(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_x_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_apply(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_p_243, 1, 3), 2, (V[]){v_t_2415, v_p_244});
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2echeckUnsolved_str0, 36, (99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2echeckUnsolved_str1, 21, (96, 59, 32, 103, 105, 118, 101, 32, 105, 116, 32, 97, 115, 32, 96, 123, 46, 46, 46, 125, 96));
Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckUnsolved_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2echeckUnsolved(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_240, 0);
    V v_t_245 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str0), heff_strAppend(heff_dup(heff_rfield(v_u_243, 0)), ((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str1)));
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_245, heff_dup(heff_rfield(v_u_243, 1)), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_apply(heff_take_field(v_p_241, 2), 1, (V[]){v_t_248}));
    return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_249, v_p_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2echeckUnsolved(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyEnv_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ebodyEnv(V v_gSelf_240, V v_k_241, V v_name_242, V v_aval_243) {
top: ;
  V v_v_245 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam0, 1, 1, (V[]){heff_dup(v_aval_243)}), NTAG(TAG_Nothing)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_name_242, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_249 = heff_tag_n(TAG_CBind, 3, (V[]){NTAG(TAG_CEmpty), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_aval_243});
  V v_sc_2410 = heff_rec_n(4, shape_len__names__locals__ctx, (V[]){MK_INT(1LL), v_t_246, v_t_248, v_t_249});
  V v_t_2411 = heff_tag_n(TAG_ForDescriptive, 2, (V[]){heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId)});
  return heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2410, v_gSelf_240, v_t_2411, MK_INT(0LL), heff_tag_n(TAG_Just, 1, (V[]){v_k_241}), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyEnv(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_aval_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_aval_243;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_245;
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2ebodyPhase_str0, 36, (99, 97, 110, 110, 111, 116, 32, 105, 110, 102, 101, 114, 32, 116, 104, 101, 32, 105, 109, 112, 108, 105, 99, 105, 116, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ebodyPhase_str1, 21, (96, 59, 32, 103, 105, 118, 101, 32, 105, 116, 32, 97, 115, 32, 96, 123, 46, 46, 46, 125, 96));
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244) {
top: ;
  V v_e_245 = (g_heff_2eelab_2etoplevel_2ebodyEnv(heff_dup(v_gSelf_242), v_k_243, heff_take_field(v_d_241, 0), heff_dup(v_aval_244)));
  V v_t_246 = heff_get_n(v_d_241, 2, 4);
  V v_c_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_c_248 = heff_tr(heff_apply(v_f_247, 2, (V[]){v_e_245, v_aval_244}));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam0, 2, 3, (V[]){v_c_248, v_gSelf_242, v_dsp_240});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyPhase(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V f_ = v_k_2418;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args) {
  V v_unsolved_2416 = args[0];
  V v_hd_2417 = args[1];
  V v_k_2418 = args[2];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_unsolved_2416)) {
  case TAG_Nil: {
    heff_drop_rec(v_hd_2417, 3);
    V f_ = v_k_2418;
    args[0] = v_x_2411;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_u_2419 = heff_field(v_unsolved_2416, 0);
    heff_take_n(v_unsolved_2416, 1ULL, 2);
    V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str0), heff_strAppend(heff_dup(heff_rfield(v_u_2419, 0)), ((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str1)));
    V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_2421, heff_get_n(v_u_2419, 1, 2), NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_apply(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2424}));
    V f_ = heff_get_n(v_hd_2417, 1, 3);
    args[0] = v_t_2425;
    args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam7, 1, 2, (V[]){v_k_2418, v_x_2411});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_unsolved_2416);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  return (g_co_2ebind_24s935789828x1526377372(heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam6, 3, 1, (V[]){v_x_2411}), v_hd_249, v_k_2410));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_dsp_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  return ({ V a_0 = v_gSelf_242; V a_1 = v_dsp_240; V a_2 = v_x_2412; V a_3 = heff_dup(v_hd_249); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam5, 1, 3, (V[]){v_x_2411, v_hd_249, v_k_2410}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2412); r_; });
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2413);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam4, 1, 6, (V[]){v_gSelf_242, v_dsp_240, v_x_2412, v_hd_249, v_x_2411, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam3, 1, 6, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2412, v_x_2411, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_gSelf_242), MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam2, 1, 5, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2411, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam1, 1, 4, (V[]){v_gSelf_242, v_hd_249, v_dsp_240, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabOut_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabOut_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_entry, 6, 0};

V g_heff_2eelab_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_tyStx_243, V v_mc_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Left: {
    V v_failed_246 = heff_field(v_x6_245, 0);
    heff_take_n(v_x6_245, 1ULL, 1);
    V v_t_247 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      v_key_248 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_key_248 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2410;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_key_240);
      v_t_2410 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_t_2410 = heff_tr(heff_apply(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_entry_2411 = ({ V a_0 = v_g_241; V a_1 = v_t_2410; V a_2 = v_tyStx_243; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    V v_x_2412 = heff_rec_n(5, shape_name__key__prim__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_248, heff_get_n(v_d_242, 3, 4), v_entry_2411, heff_tag_n(TAG_Just, 1, (V[]){v_failed_246})});
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_lam0, 2, 1, (V[]){v_x_2412});
  }
  case TAG_Right: {
    V v_t_2415 = heff_field(v_x6_245, 0);
    heff_take_n(v_x6_245, 1ULL, 1);
    V v_t_2416 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2417;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      v_key_2417 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_key_2417 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2418 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2419;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_t_2419 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_t_2420 = heff_dup(heff_rfield(v_d_242, 3));
    V v_k_2421;
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      heff_drop(v_key_240);
      v_k_2421 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_k_2421 = heff_tr(heff_apply(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    V v_t_2422 = (g_heff_2eelab_2eunify_2ezonker(v_mc_244));
    V v_t_2423 = heff_tr(heff_apply(heff_get_n(v_t_2422, 0, 2), 1, (V[]){heff_get_n(v_t_2415, 0, 2)}));
    V v_t_2424 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_2421));
    V v_t_2425 = heff_tr(heff_apply(heff_get_n(v_t_2424, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2423}));
    V v_entry_2426 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_241, v_t_2419, heff_rfield(v_d_242, 3), v_tyStx_243, v_t_2425));
    V v_x_2427 = heff_rec_n(5, shape_name__key__prim__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2417, heff_get_n(v_d_242, 3, 4), v_entry_2426, NTAG(TAG_Nothing)});
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_lam1, 2, 1, (V[]){v_x_2427});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[4]); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabOut_lam1(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}

static V g_heff_2eelab_2etoplevel_2eprimNames_val;
static int g_heff_2eelab_2etoplevel_2eprimNames_st;
static V g_heff_2eelab_2etoplevel_2eprimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2eprims_get())));
}
V g_heff_2eelab_2etoplevel_2eprimNames_get(void) {
  if (g_heff_2eelab_2etoplevel_2eprimNames_st == 2) return g_heff_2eelab_2etoplevel_2eprimNames_val;
  if (g_heff_2eelab_2etoplevel_2eprimNames_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2etoplevel_2eprimNames_st = 1;
  g_heff_2eelab_2etoplevel_2eprimNames_val = heff_tr(g_heff_2eelab_2etoplevel_2eprimNames_init());
  g_heff_2eelab_2etoplevel_2eprimNames_st = 2;
  return g_heff_2eelab_2etoplevel_2eprimNames_val;
}

static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
static int g_heff_2eelab_2etoplevel_2ebasicPrimNames_st;
static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2ebasicPrims_get())));
}
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void) {
  if (g_heff_2eelab_2etoplevel_2ebasicPrimNames_st == 2) return g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
  if (g_heff_2eelab_2etoplevel_2ebasicPrimNames_st == 1) heff_fail("defined by itself");
  g_heff_2eelab_2etoplevel_2ebasicPrimNames_st = 1;
  g_heff_2eelab_2etoplevel_2ebasicPrimNames_val = heff_tr(g_heff_2eelab_2etoplevel_2ebasicPrimNames_init());
  g_heff_2eelab_2etoplevel_2ebasicPrimNames_st = 2;
  return g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2eprimKnown_str0, 0, (0));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eprimKnown_str1, 2, (44, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eprimKnown_str2, 30, (116, 104, 101, 114, 101, 32, 105, 115, 32, 110, 111, 32, 112, 114, 105, 109, 105, 116, 105, 118, 101, 32, 99, 97, 108, 108, 101, 100, 32, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eprimKnown_str3, 20, (96, 32, 40, 116, 104, 101, 32, 114, 117, 110, 116, 105, 109, 101, 32, 104, 97, 115, 58, 32));
HEFF_STRA(g_heff_2eelab_2etoplevel_2eprimKnown_str4, 55, (44, 32, 97, 110, 100, 32, 101, 97, 99, 104, 32, 102, 105, 120, 101, 100, 45, 119, 105, 100, 116, 104, 32, 116, 121, 112, 101, 39, 115, 44, 32, 96, 105, 110, 116, 51, 50, 65, 100, 100, 96, 32, 97, 110, 100, 32, 116, 104, 101, 32, 108, 105, 107, 101, 41));
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_lam1, 2, 0};
Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 3);
  V v_t_246;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_xs_243 = heff_dup(g_heff_2eelab_2etoplevel_2eprimNames_get());
    V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_d_241, 0))}));
    V v_x1_245 = ({ V a_0 = v_t_244; V a_1 = v_xs_243; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_243); r_; });
    switch (heff_tag_of(v_x1_245)) {
    case TAG_True: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    break;
  }
  case TAG_False: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_x2_247 = heff_dup(g_heff_2eelab_2etoplevel_2ebasicPrimNames_get());
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_msg_2411 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str2), heff_strAppend(heff_get_n(v_d_241, 0, 4), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str3), heff_strAppend(v_t_2410, ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str4)))));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eprimKnown_lam0, 2, 2, (V[]){v_msg_2411, v_sp_240});
  }
  case TAG_False: {
    heff_drop(v_sp_240);
    heff_drop_rec(v_d_241, 4);
    return ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eprimKnown(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_msg_2411 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_2411, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_apply(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_246 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_246 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_k_247 = heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
  V v_c_249 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eenvironment_2emodify_clo), 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam0, 1, 1, (V[]){v_k_247})}));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam1, 2, 6, (V[]){v_c_249, heff_dup(v_n_242), v_d_243, v_key_240, v_a_244, v_g_241});
}
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelabBody(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_247; V rr_ = heff_rec_reuse_n(v_c_248, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args) {
  V v_u_2421 = args[0];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  V v_x1_2422 = heff_tr(heff_apply(heff_get_n(v_a_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2423;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    return v_x_2425;
  }
  default: return heff_nomatch(v_x1_2422);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args) {
  V v_c_2444 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_2444, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args) {
  V v_c_2458 = args[0];
  return heff_get_n(v_c_2458, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_a_244 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_d_243 = heff_env(self)[3];
  V v_x_2443 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2463 = (g_heff_2eelab_2eunify_2ezonker(v_x_2462));
  V v_t_2464 = heff_tr(heff_apply(heff_get_n(v_t_2463, 1, 2), 1, (V[]){heff_get_n(v_a_244, 0, 2)}));
  V v_t_2465 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_d_243; V a_3 = v_t_2464; V a_4 = v_x_2462; V a_5 = v_x_2443; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2462); r_; });
  return heff_tail(v_t_2465, 2, (V[]){v_hd_2410, v_k_2411});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_x_2443 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2457);
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo)})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){v_t_2460}));
  return heff_tail(heff_dup(heff_rfield(v_hd_2410, 1)), 2, (V[]){v_t_2461, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam10, 1, 7, (V[]){v_a_244, v_key_240, v_g_241, v_d_243, v_x_2443, v_hd_2410, v_k_2411})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_x_2443 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2452);
  V v_t_2455;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2454 = heff_field(v_n_242, 1);
    heff_take_n(v_n_242, 2ULL, 2);
    v_t_2455 = v_s_2454;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2456 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2455, heff_dup(v_d_243)));
  return heff_tail(v_c_2456, 2, (V[]){heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam8, 1, 7, (V[]){v_hd_2410, v_a_244, v_key_240, v_g_241, v_d_243, v_x_2443, v_k_2411})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_x_2443 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2449 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_2410, 1)), 2, (V[]){v_t_2451, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam7, 1, 8, (V[]){v_n_242, v_d_243, v_hd_2410, v_a_244, v_key_240, v_g_241, v_x_2443, v_k_2411})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo)})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){v_t_2446}));
  return heff_tail(heff_dup(heff_rfield(v_hd_2410, 1)), 2, (V[]){v_t_2447, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam6, 1, 8, (V[]){v_hd_2410, v_n_242, v_d_243, v_a_244, v_key_240, v_g_241, v_x_2443, v_k_2411})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_t_2415;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2414 = heff_dup(heff_field(v_n_242, 1));
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2416 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2417;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    v_t_2417 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_2417 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_t_2418 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    v_t_2419 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_2419 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_h_2420 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2419});
  V v_t_2426 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2420, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam3, 1, 1, (V[]){heff_dup(v_a_244)}), NTAG(TAG_Nothing)));
  V v_x1_2427 = heff_tr(heff_apply(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2431;
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_Nom: {
    V v_x_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    v_t_2431 = v_x_2428;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    v_t_2431 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2430 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x1_2427);
  }
  V v_t_2432 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_244, 0)), v_t_2426, v_t_2431});
  V v_t_2433 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2417, v_t_2432, heff_dup(v_g_241)));
  V v_t_2434 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2435;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_True: {
    v_t_2435 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_2435 = heff_tr(heff_apply(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  V v_x1_2436 = heff_tr(heff_apply(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2440;
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2437;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2436, 0ULL, 1);
    v_t_2440 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2439 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    v_t_2440 = v_x_2439;
    break;
  }
  default: heff_nomatch(v_x1_2436);
  }
  V v_t_2441 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2415, heff_dup(v_d_243), v_t_2433, v_t_2435, v_t_2440));
  V v_c_2442 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2441}));
  return heff_tail(v_c_2442, 2, (V[]){heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam4, 1, 7, (V[]){v_hd_2410, v_n_242, v_d_243, v_a_244, v_key_240, v_g_241, v_k_2411})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam2, 1, 7, (V[]){v_n_242, v_d_243, v_key_240, v_a_244, v_g_241, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str0, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str1, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str2, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str3, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str4, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str5, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str6, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str7, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str8, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str9, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchSyn_str10, 54, (97, 32, 119, 97, 116, 99, 104, 32, 109, 117, 115, 116, 32, 115, 97, 121, 32, 119, 104, 97, 116, 32, 116, 121, 112, 101, 32, 105, 116, 32, 104, 97, 115, 58, 32, 119, 114, 105, 116, 101, 32, 96, 62, 62, 62, 32, 40, 101, 32, 58, 32, 84, 41, 96));
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ewatchSyn(V v_w_240) {
top: ;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_w1_241 = heff_field(v_w_240, 0);
    switch (heff_tag_of(v_w1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_w1_241, 0);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_243));
    }
    case TAG_CType: {
      V v_sp_247;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_246 = heff_field(v_w_240, 1);
        v_sp_247 = heff_dup(v_s_246);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam0, 2, 1, (V[]){v_sp_247});
    }
    case TAG_CLam: {
      V v_sp_2419;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2418 = heff_field(v_w_240, 1);
        v_sp_2419 = heff_dup(v_s_2418);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam1, 2, 1, (V[]){v_sp_2419});
    }
    case TAG_CImplicitLam: {
      V v_sp_2431;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_w_240, 1);
        v_sp_2431 = heff_dup(v_s_2430);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam2, 2, 1, (V[]){v_sp_2431});
    }
    case TAG_CAnnLam: {
      V v_sp_2444;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_w_240, 1);
        v_sp_2444 = heff_dup(v_s_2443);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam3, 2, 1, (V[]){v_sp_2444});
    }
    case TAG_CTag: {
      V v_sp_2456;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2455 = heff_field(v_w_240, 1);
        v_sp_2456 = heff_dup(v_s_2455);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam4, 2, 1, (V[]){v_sp_2456});
    }
    case TAG_CStruct: {
      V v_sp_2466;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_w_240, 1);
        v_sp_2466 = heff_dup(v_s_2465);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam5, 2, 1, (V[]){v_sp_2466});
    }
    case TAG_CMatch: {
      V v_sp_2477;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_w_240, 1);
        v_sp_2477 = heff_dup(v_s_2476);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam6, 2, 1, (V[]){v_sp_2477});
    }
    case TAG_CLetIn: {
      V v_sp_2488;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2487 = heff_field(v_w_240, 1);
        v_sp_2488 = heff_dup(v_s_2487);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam7, 2, 1, (V[]){v_sp_2488});
    }
    case TAG_CLocal: {
      V v_sp_2499;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2498 = heff_field(v_w_240, 1);
        v_sp_2499 = heff_dup(v_s_2498);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam8, 2, 1, (V[]){v_sp_2499});
    }
    case TAG_CAbandon: {
      V v_sp_24108;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_w_240, 1);
        v_sp_24108 = heff_dup(v_s_24107);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam9, 2, 1, (V[]){v_sp_24108});
    }
    case TAG_CNominal: {
      V v_sp_24118;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24117 = heff_field(v_w_240, 1);
        v_sp_24118 = heff_dup(v_s_24117);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam10, 2, 1, (V[]){v_sp_24118});
    }
    default: return heff_nomatch(v_w1_241);
    }
  }
  default: return heff_nomatch(v_w_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2ewatchSyn(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_sp_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str0), v_sp_247, NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2412}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  args[0] = v_t_2413;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_sp_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str1), v_sp_2419, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_apply(heff_take_field(v_hd_2420, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2420, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_sp_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str2), v_sp_2431, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_apply(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k2_2446 = args[1];
  V v_sp_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str3), v_sp_2444, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_apply(heff_take_field(v_hd_2445, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2445, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2446;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_sp_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str4), v_sp_2456, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_apply(heff_take_field(v_hd_2457, 2), 1, (V[]){v_t_2461}));
  V f_ = heff_get_n(v_hd_2457, 1, 3);
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_sp_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str5), v_sp_2466, NTAG(TAG_Nothing)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_apply(heff_take_field(v_hd_2467, 2), 1, (V[]){v_t_2471}));
  V f_ = heff_get_n(v_hd_2467, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_sp_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str6), v_sp_2477, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_apply(heff_take_field(v_hd_2478, 2), 1, (V[]){v_t_2482}));
  V f_ = heff_get_n(v_hd_2478, 1, 3);
  args[0] = v_t_2483;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_sp_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str7), v_sp_2488, NTAG(TAG_Nothing)});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tr(heff_apply(heff_take_field(v_hd_2489, 2), 1, (V[]){v_t_2493}));
  V f_ = heff_get_n(v_hd_2489, 1, 3);
  args[0] = v_t_2494;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k2_24101 = args[1];
  V v_sp_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str8), v_sp_2499, NTAG(TAG_Nothing)});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tr(heff_apply(heff_take_field(v_hd_24100, 2), 1, (V[]){v_t_24104}));
  V f_ = heff_get_n(v_hd_24100, 1, 3);
  args[0] = v_t_24105;
  args[1] = v_k2_24101;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k2_24110 = args[1];
  V v_sp_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str9), v_sp_24108, NTAG(TAG_Nothing)});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tr(heff_apply(heff_take_field(v_hd_24109, 2), 1, (V[]){v_t_24113}));
  V f_ = heff_get_n(v_hd_24109, 1, 3);
  args[0] = v_t_24114;
  args[1] = v_k2_24110;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args) {
  V v_hd_24119 = args[0];
  V v_k2_24120 = args[1];
  V v_sp_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str10), v_sp_24118, NTAG(TAG_Nothing)});
  V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_apply(heff_take_field(v_hd_24119, 2), 1, (V[]){v_t_24123}));
  V f_ = heff_get_n(v_hd_24119, 1, 3);
  args[0] = v_t_24124;
  args[1] = v_k2_24120;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2ewatchEntry_str0, 7, (62, 32, 119, 97, 116, 99, 104));
Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchEntry_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_ty_243));
  V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_244));
  V v_t_246 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_tyStx_247 = heff_tr(heff_apply(heff_get_n(v_t_246, 1, 2), 1, (V[]){v_t_245}));
  V v_t_248 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_bodyStx_249 = heff_tr(heff_apply(heff_get_n(v_t_248, 0, 2), 1, (V[]){heff_get_n(v_t_242, 0, 2)}));
  V v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), ((V)&g_heff_2eelab_2etoplevel_2ewatchEntry_str0), heff_dup(v_tyStx_247), heff_dup(v_bodyStx_249)));
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_247), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_249, v_tyStx_247, v_t_2410, v_t_2415});
}
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2ewatchEntry(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ewatchPhase(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_ty_246 = heff_field(v_x3_242, 1);
    return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_g_240), MK_INT(0LL), heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam0, 1, 6, (V[]){v_p_243, v_g_240, v_sp_241, heff_dup(v_t_245), heff_dup(v_ty_246), v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2ewatchPhase(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args) {
  V v_c_2415 = args[0];
  return heff_get_n(v_c_2415, 3, 8);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2420 = ({ V a_0 = v_g_240; V a_1 = v_x_2419; V a_2 = v_t_245; V a_3 = v_ty_246; V r_ = (g_heff_2eelab_2etoplevel_2ewatchEntry(a_0, a_1, a_2, a_3)); heff_drop(v_x_2419); r_; });
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_245 = heff_env(self)[2];
  V v_ty_246 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_apply(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_2412, 1, 3), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam7, 1, 4, (V[]){v_g_240, v_t_245, v_ty_246, v_k_2413})});
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args) {
  V v_unsolved_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_unsolved_2411; V a_1 = heff_dup(v_hd_2412); V a_2 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam5, 1, 5, (V[]){v_hd_2412, v_g_240, v_t_245, v_ty_246, v_k_2413}); V r_ = (g_heff_2eelab_2etoplevel_2echeckUnsolved(a_0, a_1, a_2)); heff_drop(v_unsolved_2411); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  return (g_co_2ebind_24s935789828x1526377372(heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam4, 3, 3, (V[]){v_g_240, v_t_245, v_ty_246}), v_p_243, v_p_244));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  return ({ V a_0 = heff_dup(v_g_240); V a_1 = v_sp_241; V a_2 = v_x_247; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam3, 1, 5, (V[]){v_g_240, v_t_245, v_ty_246, v_p_243, v_p_244}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_247); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam2, 1, 7, (V[]){v_g_240, v_sp_241, v_x_247, v_p_243, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_ty_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam1, 1, 7, (V[]){v_p_243, v_g_240, v_sp_241, v_x_247, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabWatch_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eelabWatch(V v_g_240, V v_n_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_242));
    v_t_245 = heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_243});
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2ewatchSyn(a_0)); heff_drop(v_t_245); r_; });
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam0, 2, 3, (V[]){v_c_246, v_g_240, v_n_241});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabWatch(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2415 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  return ({ V a_0 = v_g_240; V a_1 = v_t_2416; V a_2 = v_x_2413; V a_3 = v_hd_247; V a_4 = v_k_248; V r_ = (g_heff_2eelab_2etoplevel_2ewatchPhase(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSyn: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2411 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2412 = heff_tr(heff_apply(v_f_2410, 1, (V[]){v_t_2411}));
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  return heff_tail(v_c_2412, 2, (V[]){heff_dup(v_hd_247), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam2, 1, 4, (V[]){v_n_241, v_g_240, v_hd_247, v_k_248})});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam1, 1, 4, (V[]){v_g_240, v_hd_247, v_n_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendT(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2etoplevel_2eappendT(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_241, 0)), MK_INT(-1LL))) {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_244 = NTAG(TAG_Nil);
    } else {
      v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_xs_242));
    return (g_heff_2eelab_2etoplevel_2eappendT(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x_244 = heff_field(v_n_242, 0);
    v_t_246 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2426;
  switch (heff_tag_of(v_t_246)) {
  case TAG_DeclEquations: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 4);
    v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_f_247});
    break;
  }
  case TAG_DeclDefine: {
    V v_x_2411 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 5);
    v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
    break;
  }
  case TAG_DeclTheory: {
    V v_x_2416 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 4);
    v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2416});
    break;
  }
  case TAG_DeclPrimitive: {
    V v_x_2420 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 3);
    v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2420});
    break;
  }
  case TAG_DeclTest: {
    V v_x_2423 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2423});
    break;
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_246, 0ULL, 1);
    v_t_2426 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    return ({ V rv_1 = v_diags_243; V rr_ = heff_rec_reuse_n(v_acc_241, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_k_2428 = heff_tr(heff_apply(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_t_2429 = heff_tr(heff_apply(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_g_2432;
    if (heff_strEq_c(v_t_2429, heff_dup(v_x_2427))) {
      heff_drop(v_kf_240);
      v_g_2432 = heff_dup(heff_rfield(v_acc_241, 0));
    } else {
      V v_t_2431 = heff_tr(heff_apply(v_kf_240, 1, (V[]){heff_dup(v_x_2427)}));
      v_g_2432 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2427), v_t_2431, heff_dup(heff_rfield(v_acc_241, 0))));
    }
    V v_t_2433 = (g_map_2einsert_24s1341440536x470972936(v_k_2428, NTAG(TAG_MkUnit), heff_take_field(v_g_2432, 3)));
    V v_globals_2434 = ({ V rv_3 = v_t_2433; V rr_ = heff_rec_reuse_n(v_g_2432, 55ULL, 6, shape_order__entries__aliases__broken__ambiguous__places); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2437;
    switch (heff_tag_of(v_n_242)) {
    case TAG_At: {
      V v_s_2436 = heff_field(v_n_242, 1);
      v_t_2437 = heff_dup(v_s_2436);
      break;
    }
    default: heff_nomatch(v_n_242);
    }
    V v_broken_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_t_2437}), heff_take_field(v_acc_241, 3)});
    return ({ V rv_0 = v_globals_2434; V rv_1 = v_diags_243; V rv_3 = v_broken_2438; V rr_ = heff_rec_reuse_n(v_acc_241, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etopBroken(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ekeepSt_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_242 = heff_field(v_st_240, 0);
    v_t_245 = heff_dup(v_c_242);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_infos_246 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_245, 0, 8), heff_take_field(v_acc_241, 7)));
  V v_t_2410;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_247 = heff_field(v_st_240, 0);
    v_t_2410 = heff_dup(v_c_247);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_trace_2411 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2410, 6, 8), heff_take_field(v_acc_241, 8)));
  return ({ V rv_7 = v_infos_246; V rv_8 = v_trace_2411; V rr_ = heff_rec_reuse_n(v_acc_241, 127ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2ekeepSt(a[0], a[1]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_Left: {
      V v_d_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_247 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_245, heff_dup(v_acc_241)));
      V v_t_2411;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_248 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2412 = heff_get_n(v_t_2411, 1, 8);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
      V v_t_2414 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2413));
      V v_t_2416;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_246, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        heff_drop_rec(v_d_246, 5);
        v_t_2416 = NTAG(TAG_Nil);
      } else {
        v_t_2416 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_246, NTAG(TAG_Nil)});
      }
      V v_t_2417 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2414, v_t_2416));
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(heff_get_n(v_acc_241, 1, 9), v_t_2417));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken(v_kf_240, v_t_247, v_n_242, v_t_2418);
    }
    case TAG_Right: {
      V v_r_2419 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop(v_kf_240);
      V v_g_2420 = heff_take_field(v_acc_241, 0);
      V v_t_2421 = heff_take_field(v_r_2419, 2);
      V v_t_2424;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        V v_t_2422 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_r_2419, 1)), heff_rfield(v_g_2420, 1)));
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          v_t_2424 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2419, 1)), heff_dup(heff_rfield(v_r_2419, 3)), v_g_2420));
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2422, 0ULL, 1);
          v_t_2424 = v_g_2420;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        break;
      }
      case TAG_False: {
        v_t_2424 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2419, 1)), heff_dup(heff_rfield(v_r_2419, 3)), v_g_2420));
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      V v_globals_2425 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_r_2419, 0)), heff_dup(heff_rfield(v_r_2419, 1)), v_t_2424));
      V v_t_2429;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2426 = heff_dup(heff_field(v_st_245, 0));
        v_t_2429 = v_c_2426;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2430 = heff_get_n(v_t_2429, 1, 8);
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
      V v_t_2432 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2431));
      V v_t_2433 = heff_take_field(v_r_2419, 4);
      V v_t_2436;
      switch (heff_tag_of(v_t_2433)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2434 = heff_field(v_t_2433, 0);
        heff_take_n(v_t_2433, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2434, 0)), MK_INT(-1LL))) {
          heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
          heff_drop_rec(v_d_2434, 5);
          v_t_2436 = NTAG(TAG_Nil);
        } else {
          v_t_2436 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_2434, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2433);
      }
      V v_t_2437 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2432, v_t_2436));
      V v_diags_2438 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_241, 1), v_t_2437));
      V v_t_2441;
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_s_2440 = heff_field(v_n_242, 1);
        v_t_2441 = heff_dup(v_s_2440);
        break;
      }
      default: heff_nomatch(v_n_242);
      }
      V v_t_2442 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_r_2419, 0), v_t_2441});
      V v_spans_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, heff_take_field(v_acc_241, 6)});
      V v_t_2447;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2444 = heff_dup(heff_field(v_st_245, 0));
        v_t_2447 = v_c_2444;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_infos_2448 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2447, 0, 8), heff_take_field(v_acc_241, 7)));
      V v_t_2452;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2449 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2452 = v_c_2449;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_trace_2453 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2452, 6, 8), heff_take_field(v_acc_241, 8)));
      V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_2419, 1, 5), heff_take_field(v_acc_241, 2)});
      return ({ V rv_0 = v_globals_2425; V rv_1 = v_diags_2438; V rv_2 = v_t_2454; V rv_6 = v_spans_2443; V rv_7 = v_infos_2448; V rv_8 = v_trace_2453; V rr_ = heff_rec_reuse_n(v_acc_241, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etopTake(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchTake_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_st_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop(v_sp_241);
      V v_t_249;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_246 = heff_dup(heff_field(v_st_244, 0));
        v_t_249 = v_c_246;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2410 = heff_get_n(v_t_249, 1, 8);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
      V v_t_2412 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2411));
      V v_t_2414;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2415 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2412, v_t_2414));
      V v_diags_2416 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2415));
      V v_t_2420;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2417 = heff_dup(heff_field(v_st_244, 0));
        v_t_2420 = v_c_2417;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2421 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2420, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2425;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2422 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2425 = v_c_2422;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2426 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2425, 6, 8), heff_take_field(v_acc_240, 8)));
      return ({ V rv_1 = v_diags_2416; V rv_7 = v_infos_2421; V rv_8 = v_trace_2426; V rr_ = heff_rec_reuse_n(v_acc_240, 125ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    case TAG_Right: {
      V v_entry_2427 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2428 = heff_dup(heff_field(v_st_244, 0));
        v_t_2431 = v_c_2428;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2432 = heff_get_n(v_t_2431, 1, 8);
      V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2432));
      V v_t_2434 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2433));
      V v_diags_2435 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2434));
      V v_t_2439;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2436 = heff_dup(heff_field(v_st_244, 0));
        v_t_2439 = v_c_2436;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2440 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2439, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2444;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2441 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2444 = v_c_2441;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2445 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2444, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2446 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_span__entry, (V[]){v_sp_241, v_entry_2427}), heff_dup(heff_rfield(v_acc_240, 4))});
      return ({ V rv_1 = v_diags_2435; V rv_4 = v_t_2446; V rv_7 = v_infos_2440; V rv_8 = v_trace_2445; V rr_ = heff_rec_reuse_n(v_acc_240, 109ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewatchTake(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0, 21, (101, 114, 114, 111, 114, 115, 32, 114, 101, 99, 111, 118, 101, 114, 101, 100, 32, 102, 114, 111, 109));
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V v_k_240, V v_st_241) {
top: ;
  V v_c_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_c_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){heff_get_n(v_c_245, 1, 8)});
  V v_x1_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_241});
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_k_240);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2411; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
      if (heff_intEq_c(v_t_2412, MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
        return heff_tail(v_k_240, 2, (V[]){NTAG(TAG_MkUnit), v_st_249});
      } else {
        heff_drop(v_k_240);
        V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2414}), v_st_249});
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V v_key_240, V v_g_241, V v_n_242, V v_st_243) {
top: ;
  V v_c_247;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_c_244 = heff_dup(heff_field(v_st_243, 0));
    v_c_247 = v_c_244;
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  V v_t_248 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_247, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_x1_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_248}), v_st_243});
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2418;
      switch (heff_tag_of(v_st_2411)) {
      case TAG_MkSt: {
        V v_d_2416 = heff_field(v_st_2411, 1);
        V v_w_2417 = heff_field(v_st_2411, 2);
        V v_ru_24st_2411_24MkSt = heff_take_reuse_n(v_st_2411, 6ULL, 3);
        v_t_2418 = heff_tag_at_n(v_ru_24st_2411_24MkSt, TAG_MkSt, 3, (V[]){v_x_2413, v_d_2416, v_w_2417});
        break;
      }
      default: heff_nomatch(v_st_2411);
      }
      V v_x1_2419 = heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x11_2420 = heff_field(v_x1_2419, 0);
        V v_st_2421 = heff_field(v_x1_2419, 1);
        V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
        switch (heff_tag_of(v_x11_2420)) {
        case TAG_Left: {
          V v_e_2422 = heff_field(v_x11_2420, 0);
          heff_take_n(v_x11_2420, 1ULL, 1);
          heff_drop(v_key_240);
          heff_drop(v_g_241);
          return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2419_24MkPair, 2);
          V v_c_2424 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_242));
          return heff_tail(v_c_2424, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0, 1, 3, (V[]){v_g_241, v_key_240, heff_dup(v_n_242)}), v_st_2421});
        }
        default: return heff_nomatch(v_x11_2420);
        }
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args) {
  V v_a_2433 = args[0];
  V v_a_2434 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2433}), v_a_2434});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_t_2432 = ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2425; V a_4 = v_x_2430; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_n_242); r_; });
  return heff_tail(v_t_2432, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo)});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2, 1, 5, (V[]){v_key_240, v_g_241, v_n_242, v_x_2425, v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = heff_dup(heff_rfield(v_x_2425, 1));
  V v_c_2429;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_MkTyp: {
    V v_f_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_t_2428 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_241), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2429 = heff_tr(heff_apply(v_f_2427, 1, (V[]){v_t_2428}));
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1, 1, 4, (V[]){v_key_240, v_g_241, v_n_242, v_x_2425})});
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etopOne_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_lam0, 2, 0};
Clo g_heff_2eelab_2etoplevel_2etopOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_n1_243 = heff_dup(heff_field(v_n_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_n_242, 1));
    switch (heff_tag_of(v_n1_243)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_243, 0ULL, 4);
      heff_drop(v_sp_244);
      V v_t_249 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_249; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_243, 0ULL, 5);
      heff_drop(v_sp_244);
      V v_t_2415 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2415; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_243, 0ULL, 4);
      heff_drop(v_sp_244);
      V v_t_2420 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2420; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_243, 0ULL, 3);
      heff_drop(v_sp_244);
      V v_t_2424 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2424; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTest: {
      V v_x_2425 = heff_field(v_n1_243, 0);
      V v_ru_24n1_243_24DeclTest = heff_take_reuse_n(v_n1_243, 1ULL, 2);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_t_2427 = heff_tag_at_n(v_ru_24n1_243_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2425, v_sp_244}), heff_dup(heff_rfield(v_acc_241, 5))});
      return ({ V rv_5 = v_t_2427; V rr_ = heff_rec_reuse_n(v_acc_241, 479ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_DeclWatch: {
      V v_e_2428 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_m_2429 = (g_heff_2eelab_2etoplevel_2eelabWatch(heff_dup(heff_rfield(v_acc_241, 0)), v_e_2428));
      V v_t_2432 = heff_tr(heff_apply(v_m_2429, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2etopOne_lam0_clo), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())}));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_241, v_sp_244, v_t_2432);
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2431 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2430}), v_st_2431});
}
Clo g_heff_2eelab_2etoplevel_2etopGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopGo(V v_kf_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_kf_240);
    V v_diags_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 1)));
    V v_keys_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 2)));
    V v_broken_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 3)));
    V v_watches_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 4)));
    V v_tests_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 5)));
    V v_spans_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 6)));
    V v_infos_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 7)));
    V v_trace_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 8)));
    return ({ V rv_1 = v_diags_243; V rv_2 = v_keys_244; V rv_3 = v_broken_245; V rv_4 = v_watches_246; V rv_5 = v_tests_247; V rv_6 = v_spans_248; V rv_7 = v_infos_249; V rv_8 = v_trace_2410; V rr_ = heff_rec_reuse_n(v_acc_241, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2411 = heff_field(v_x3_242, 0);
    V v_rest_2412 = heff_field(v_x3_242, 1);
    V v_t_2413 = (g_heff_2eelab_2etoplevel_2etopOne(heff_dup(v_kf_240), v_acc_241, heff_dup(v_n_2411)));
    V t_0 = v_kf_240;
    V t_1 = v_t_2413;
    V t_2 = v_rest_2412;
    v_kf_240 = t_0;
    v_acc_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etopGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V v_acc_240, V v_n_241, V v_diags_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_243 = heff_field(v_n_241, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2425;
  switch (heff_tag_of(v_t_245)) {
  case TAG_DeclEquations: {
    V v_f_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 4);
    v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_f_246});
    break;
  }
  case TAG_DeclDefine: {
    V v_x_2410 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 5);
    v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
    break;
  }
  case TAG_DeclTheory: {
    V v_x_2415 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 4);
    v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2415});
    break;
  }
  case TAG_DeclPrimitive: {
    V v_x_2419 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 3);
    v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
    break;
  }
  case TAG_DeclTest: {
    V v_x_2422 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 2);
    v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
    break;
  }
  case TAG_DeclWatch: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2425 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    return ({ V rv_1 = v_diags_242; V rr_ = heff_rec_reuse_n(v_acc_240, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_g_2428;
    if (heff_strEq_c(heff_dup(v_x_2426), heff_dup(v_x_2426))) {
      v_g_2428 = heff_dup(heff_rfield(v_acc_240, 0));
    } else {
      v_g_2428 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2426), heff_dup(v_x_2426), heff_dup(heff_rfield(v_acc_240, 0))));
    }
    V v_t_2429 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2426), NTAG(TAG_MkUnit), heff_take_field(v_g_2428, 3)));
    V v_globals_2430 = ({ V rv_3 = v_t_2429; V rr_ = heff_rec_reuse_n(v_g_2428, 55ULL, 6, shape_order__entries__aliases__broken__ambiguous__places); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2433;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_2432 = heff_field(v_n_241, 1);
      v_t_2433 = heff_dup(v_s_2432);
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_broken_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_t_2433}), heff_take_field(v_acc_240, 3)});
    return ({ V rv_0 = v_globals_2430; V rv_1 = v_diags_242; V rv_3 = v_broken_2434; V rr_ = heff_rec_reuse_n(v_acc_240, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V v_acc_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_st_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_244, heff_dup(v_acc_240)));
      V v_t_2410;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_247 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2410 = v_c_247;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2411 = heff_get_n(v_t_2410, 1, 8);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
      V v_t_2413 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2412));
      V v_t_2415;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2415 = NTAG(TAG_Nil);
      } else {
        v_t_2415 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2416 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2413, v_t_2415));
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(heff_get_n(v_acc_240, 1, 9), v_t_2416));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(v_t_246, v_n_241, v_t_2417);
    }
    case TAG_Right: {
      V v_r_2418 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_g_2419 = heff_take_field(v_acc_240, 0);
      V v_t_2420 = heff_take_field(v_r_2418, 2);
      V v_t_2423;
      switch (heff_tag_of(v_t_2420)) {
      case TAG_True: {
        V v_t_2421 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_r_2418, 1)), heff_rfield(v_g_2419, 1)));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_Nothing: {
          v_t_2423 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 3)), v_g_2419));
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2421, 0ULL, 1);
          v_t_2423 = v_g_2419;
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
        break;
      }
      case TAG_False: {
        v_t_2423 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 3)), v_g_2419));
        break;
      }
      default: heff_nomatch(v_t_2420);
      }
      V v_globals_2424 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_r_2418, 0)), heff_dup(heff_rfield(v_r_2418, 1)), v_t_2423));
      V v_t_2428;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2425 = heff_dup(heff_field(v_st_244, 0));
        v_t_2428 = v_c_2425;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2429 = heff_get_n(v_t_2428, 1, 8);
      V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
      V v_t_2431 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2430));
      V v_t_2432 = heff_take_field(v_r_2418, 4);
      V v_t_2435;
      switch (heff_tag_of(v_t_2432)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        v_t_2435 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2433 = heff_field(v_t_2432, 0);
        heff_take_n(v_t_2432, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2433, 0)), MK_INT(-1LL))) {
          heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
          heff_drop_rec(v_d_2433, 5);
          v_t_2435 = NTAG(TAG_Nil);
        } else {
          v_t_2435 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_2433, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2432);
      }
      V v_t_2436 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2431, v_t_2435));
      V v_diags_2437 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2436));
      V v_t_2440;
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_s_2439 = heff_field(v_n_241, 1);
        v_t_2440 = heff_dup(v_s_2439);
        break;
      }
      default: heff_nomatch(v_n_241);
      }
      V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_r_2418, 0), v_t_2440});
      V v_spans_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, heff_take_field(v_acc_240, 6)});
      V v_t_2446;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2443 = heff_dup(heff_field(v_st_244, 0));
        v_t_2446 = v_c_2443;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2447 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2446, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2451;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2448 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2451 = v_c_2448;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2452 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2451, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_2418, 1, 5), heff_take_field(v_acc_240, 2)});
      return ({ V rv_0 = v_globals_2424; V rv_1 = v_diags_2437; V rv_2 = v_t_2453; V rv_6 = v_spans_2442; V rv_7 = v_infos_2447; V rv_8 = v_trace_2452; V rr_ = heff_rec_reuse_n(v_acc_240, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575(V v_g_240, V v_d_241, V v_tyStx_242, V v_mc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Left: {
    V v_failed_245 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    V v_t_246 = heff_dup(heff_rfield(v_d_241, 3));
    V v_key_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_key_247 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_key_247 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_t_249 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_t_249 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_entry_2410 = ({ V a_0 = v_g_240; V a_1 = v_t_249; V a_2 = v_tyStx_242; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
    V v_x_2411 = heff_rec_n(5, shape_name__key__prim__entry__failed, (V[]){heff_take_field(v_d_241, 0), v_key_247, heff_get_n(v_d_241, 3, 4), v_entry_2410, heff_tag_n(TAG_Just, 1, (V[]){v_failed_245})});
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_lam0, 2, 1, (V[]){v_x_2411});
  }
  case TAG_Right: {
    V v_t_2414 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    V v_t_2415 = heff_dup(heff_rfield(v_d_241, 3));
    V v_key_2416;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_True: {
      v_key_2416 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_key_2416 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2417 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_t_2418 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_t_2418 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2419 = heff_dup(heff_rfield(v_d_241, 3));
    V v_k_2420;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      v_k_2420 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_k_2420 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_t_2421 = (g_heff_2eelab_2eunify_2ezonker(v_mc_243));
    V v_t_2422 = heff_tr(heff_apply(heff_get_n(v_t_2421, 0, 2), 1, (V[]){heff_get_n(v_t_2414, 0, 2)}));
    V v_t_2423 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_2420));
    V v_t_2424 = heff_tr(heff_apply(heff_get_n(v_t_2423, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2422}));
    V v_entry_2425 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_240, v_t_2418, heff_rfield(v_d_241, 3), v_tyStx_242, v_t_2424));
    V v_x_2426 = heff_rec_n(5, shape_name__key__prim__entry__failed, (V[]){heff_take_field(v_d_241, 0), v_key_2416, heff_get_n(v_d_241, 3, 4), v_entry_2425, NTAG(TAG_Nothing)});
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_lam1, 2, 1, (V[]){v_x_2426});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575_lam1(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_x_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(V v_g_240, V v_n_241, V v_d_242, V v_a_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_245;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_t_245 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_245 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_k_246 = heff_tag_n(TAG_Just, 1, (V[]){v_t_245});
  V v_c_248 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eenvironment_2emodify_clo), 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0, 1, 1, (V[]){v_k_246})}));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1, 2, 5, (V[]){v_c_248, heff_dup(v_n_241), v_d_242, v_a_243, v_g_240});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_246; V rr_ = heff_rec_reuse_n(v_c_247, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  V v_x1_2421 = heff_tr(heff_apply(heff_get_n(v_a_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Nom: {
    V v_x_2422 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    return v_x_2422;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2421, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2424 = heff_field(v_x1_2421, 0);
    heff_take_n(v_x1_2421, 1ULL, 1);
    return v_x_2424;
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5(V self, V *args) {
  V v_c_2443 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_2443, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9(V self, V *args) {
  V v_c_2457 = args[0];
  return heff_get_n(v_c_2457, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10(V self, V *args) {
  V v_x_2461 = args[0];
  V v_a_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_x_2442 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2462 = (g_heff_2eelab_2eunify_2ezonker(v_x_2461));
  V v_t_2463 = heff_tr(heff_apply(heff_get_n(v_t_2462, 1, 2), 1, (V[]){heff_get_n(v_a_243, 0, 2)}));
  V v_t_2464 = ({ V a_0 = v_g_240; V a_1 = v_d_242; V a_2 = v_t_2463; V a_3 = v_x_2461; V a_4 = v_x_2442; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut_24s1044629091x299597575(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2461); r_; });
  return heff_tail(v_t_2464, 2, (V[]){v_hd_249, v_k_2410});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_x_2442 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2456);
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9_clo)})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2459}));
  return heff_tail(heff_dup(heff_rfield(v_hd_249, 1)), 2, (V[]){v_t_2460, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10, 1, 6, (V[]){v_a_243, v_g_240, v_d_242, v_x_2442, v_hd_249, v_k_2410})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_x_2442 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2451);
  V v_t_2454;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2453 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2454 = v_s_2453;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2455 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2454, heff_dup(v_d_242)));
  return heff_tail(v_c_2455, 2, (V[]){heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8, 1, 6, (V[]){v_hd_249, v_a_243, v_g_240, v_d_242, v_x_2442, v_k_2410})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_x_2442 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2448 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2447, NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_249, 1)), 2, (V[]){v_t_2450, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7, 1, 7, (V[]){v_n_241, v_d_242, v_hd_249, v_a_243, v_g_240, v_x_2442, v_k_2410})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5_clo)})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_apply(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2445}));
  return heff_tail(heff_dup(heff_rfield(v_hd_249, 1)), 2, (V[]){v_t_2446, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6, 1, 7, (V[]){v_hd_249, v_n_241, v_d_242, v_a_243, v_g_240, v_x_2442, v_k_2410})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2411);
  V v_t_2414;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2413 = heff_dup(heff_field(v_n_241, 1));
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2415 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2416;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    v_t_2416 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_2416 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_t_2417 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2418;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    v_t_2418 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_2418 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  V v_h_2419 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2418});
  V v_t_2425 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2419, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
  V v_x1_2426 = heff_tr(heff_apply(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2427;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2426, 0ULL, 1);
    v_t_2430 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_t_2430 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_t_2431 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_243, 0)), v_t_2425, v_t_2430});
  V v_t_2432 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2416, v_t_2431, heff_dup(v_g_240)));
  V v_t_2433 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2434;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    v_t_2434 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_2434 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  V v_x1_2435 = heff_tr(heff_apply(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2439;
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Nom: {
    V v_x_2436 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2436;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2435, 0ULL, 1);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2438 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2438;
    break;
  }
  default: heff_nomatch(v_x1_2435);
  }
  V v_t_2440 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2414, heff_dup(v_d_242), v_t_2432, v_t_2434, v_t_2439));
  V v_c_2441 = heff_tr(heff_apply(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2440}));
  return heff_tail(v_c_2441, 2, (V[]){heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4, 1, 6, (V[]){v_hd_249, v_n_241, v_d_242, v_a_243, v_g_240, v_k_2410})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2, 1, 6, (V[]){v_n_241, v_d_242, v_a_243, v_g_240, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V v_g_240, V v_n_241, V v_st_242) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_c_243 = heff_dup(heff_field(v_st_242, 0));
    v_c_246 = v_c_243;
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  V v_t_247 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_246, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_x1_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_247}), v_st_242});
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2417;
      switch (heff_tag_of(v_st_2410)) {
      case TAG_MkSt: {
        V v_d_2415 = heff_field(v_st_2410, 1);
        V v_w_2416 = heff_field(v_st_2410, 2);
        V v_ru_24st_2410_24MkSt = heff_take_reuse_n(v_st_2410, 6ULL, 3);
        v_t_2417 = heff_tag_at_n(v_ru_24st_2410_24MkSt, TAG_MkSt, 3, (V[]){v_x_2412, v_d_2415, v_w_2416});
        break;
      }
      default: heff_nomatch(v_st_2410);
      }
      V v_x1_2418 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_t_2417});
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_g_240);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
          V v_c_2423 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_241));
          return heff_tail(v_c_2423, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0, 1, 2, (V[]){v_g_240, heff_dup(v_n_241)}), v_st_2420});
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args) {
  V v_a_2432 = args[0];
  V v_a_2433 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2432}), v_a_2433});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2430);
  V v_t_2431 = ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2424; V a_3 = v_x_2429; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(a_0, a_1, a_2, a_3)); heff_drop(v_n_241); r_; });
  return heff_tail(v_t_2431, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo)});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2, 1, 4, (V[]){v_g_240, v_n_241, v_x_2424, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_dup(heff_rfield(v_x_2424, 1));
  V v_c_2428;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_MkTyp: {
    V v_f_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_t_2427 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2428 = heff_tr(heff_apply(v_f_2426, 1, (V[]){v_t_2427}));
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  return heff_tail(v_c_2428, 2, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1, 1, 3, (V[]){v_g_240, v_n_241, v_x_2424})});
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0, 2, 0};
Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V v_acc_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_t_248 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_248; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_242, 0ULL, 5);
      heff_drop(v_sp_243);
      V v_t_2414 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2414; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_t_2419 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2419; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_t_2423 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2423; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTest: {
      V v_x_2424 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24DeclTest = heff_take_reuse_n(v_n1_242, 1ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2426 = heff_tag_at_n(v_ru_24n1_242_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2424, v_sp_243}), heff_dup(heff_rfield(v_acc_240, 5))});
      return ({ V rv_5 = v_t_2426; V rr_ = heff_rec_reuse_n(v_acc_240, 479ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_DeclWatch: {
      V v_e_2427 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_m_2428 = (g_heff_2eelab_2etoplevel_2eelabWatch(heff_dup(heff_rfield(v_acc_240, 0)), v_e_2427));
      V v_t_2431 = heff_tr(heff_apply(v_m_2428, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0_clo), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())}));
      return (g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_240, v_sp_243, v_t_2431));
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_2430 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2429}), v_st_2430});
}
Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V v_acc_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_diags_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_keys_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
    V v_broken_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 3)));
    V v_watches_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 4)));
    V v_tests_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 5)));
    V v_spans_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
    V v_infos_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 7)));
    V v_trace_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 8)));
    return ({ V rv_1 = v_diags_242; V rv_2 = v_keys_243; V rv_3 = v_broken_244; V rv_4 = v_watches_245; V rv_5 = v_tests_246; V rv_6 = v_spans_247; V rv_7 = v_infos_248; V rv_8 = v_trace_249; V rr_ = heff_rec_reuse_n(v_acc_240, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2410 = heff_field(v_x3_241, 0);
    V v_rest_2411 = heff_field(v_x3_241, 1);
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(v_acc_240, heff_dup(v_n_2410)));
    V t_0 = v_t_2412;
    V t_1 = v_rest_2411;
    v_acc_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eisPrimB_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eisPrimB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eelab_2etoplevel_2eisPrimB(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eelab_2etoplevel_2ethawOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 4)));
  V v_t_246;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 1, 6);
    V v_t_244 = ({ V a_0 = heff_dup(heff_rfield(v_d_241, 1)); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    break;
  }
  case TAG_False: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_g_247 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_d_241, 0)), heff_dup(heff_rfield(v_d_241, 1)), heff_take_field(v_acc_240, 0)));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 2, 5)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_247; V rv_2 = v_t_248; V rv_6 = v_t_2410; V rr_ = heff_rec_reuse_n(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  case TAG_False: {
    V v_t_2411 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 4)));
    V v_t_2412 = ({ V a_0 = heff_dup(heff_rfield(v_acc_240, 0)); V a_1 = heff_dup(heff_rfield(v_d_241, 1)); V a_2 = v_t_2411; V a_3 = heff_take_field(v_d_241, 3); V a_4 = heff_take_field(v_d_241, 4); V r_ = (g_heff_2eelab_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_d_241, 1)), v_t_2412, heff_take_field(v_acc_240, 0)));
    V v_g_2414 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_d_241, 0)), heff_dup(heff_rfield(v_d_241, 1)), v_t_2413));
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 2, 5)});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_2414; V rv_2 = v_t_2415; V rv_6 = v_t_2417; V rr_ = heff_rec_reuse_n(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawOne(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2ethawDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawDone_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ethawDone(V v_acc_240) {
top: ;
  V v_keys_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
  V v_spans_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
  return ({ V rv_2 = v_keys_241; V rv_6 = v_spans_242; V rr_ = heff_rec_reuse_n(v_acc_240, 443ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawDone(a[0]);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2ebodyDump_str0, 20, (60, 110, 111, 32, 115, 117, 99, 104, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 62));
HEFF_STRA(g_heff_2eelab_2etoplevel_2ebodyDump_str1, 20, (60, 110, 111, 32, 115, 117, 99, 104, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 62));
Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ebodyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_241, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_242, 6);
      return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str0);
    }
    case TAG_Just: {
      V v_k2_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_246 = ({ V a_0 = v_k2_245; V b_1 = heff_get_n(v_g_242, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str1);
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        return ({ V b_0 = heff_get_n(v_e_247, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop_rec(v_g_242, 6);
    return ({ V b_0 = heff_get_n(v_e_248, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyDump(a[0], a[1]);
}
HEFF_STRA(g_heff_2eelab_2etoplevel_2etyDump_str0, 20, (60, 110, 111, 32, 115, 117, 99, 104, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 62));
HEFF_STRA(g_heff_2eelab_2etoplevel_2etyDump_str1, 20, (60, 110, 111, 32, 115, 117, 99, 104, 32, 100, 101, 102, 105, 110, 105, 116, 105, 111, 110, 62));
Clo g_heff_2eelab_2etoplevel_2etyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_241, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_242, 6);
      return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str0);
    }
    case TAG_Just: {
      V v_k2_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_246 = ({ V a_0 = v_k2_245; V b_1 = heff_get_n(v_g_242, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str1);
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        return ({ V b_0 = heff_get_n(v_e_247, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop_rec(v_g_242, 6);
    return ({ V b_0 = heff_get_n(v_e_248, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etyDump(a[0], a[1]);
}