// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Anonymous 24551
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BDelayedBy 11524
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_Catch 6517
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ExplicitParam 63083
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_ImplicitParam 51130
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SetField 47531
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_dflt 9576017
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nameSpan 438211216
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_scope 310622830
#define LBL_scrutinee 73860976
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_sol 323594
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__chk__span__nameSpan[] = {LBL_name, LBL_chk, LBL_span, LBL_nameSpan};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__entry[] = {LBL_span, LBL_entry};
static uint32_t shape_span__name__typ__implicit[] = {LBL_span, LBL_name, LBL_typ, LBL_implicit};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2ebind_24s1601686549x58384075(V, V, V, V);
V g_co_2ebind_24s1601686549x58384075_entry(V self, V *a);
extern Clo g_co_2ebind_24s1601686549x58384075_clo;
V g_co_2ebind_24s935789828x1526377372(V, V, V);
V g_co_2ebind_24s935789828x1526377372_entry(V self, V *a);
extern Clo g_co_2ebind_24s935789828x1526377372_clo;
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void);
V g_heff_2ecompile_2eprims_2eprims_get(void);
V g_heff_2eelab_2eclauses_2ecaseTreeOf(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo;
V g_heff_2eelab_2eclauses_2edesugar(V, V, V, V);
V g_heff_2eelab_2eclauses_2edesugar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edesugar_clo;
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eenvironment_2eemptySt_get(void);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddInstance(V, V, V);
V g_heff_2eelab_2eglobals_2eaddInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddInstance_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2ememoed_2edecode(V);
V g_heff_2eelab_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2edecode_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(V);
V g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2easSmall(V, V);
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2easSmall_clo;
V g_heff_2eelab_2erules_2eautoRec(V, V, V);
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eautoRec_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2eformRecord(V, V);
V g_heff_2eelab_2erules_2eformRecord_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformRecord_clo;
V g_heff_2eelab_2erules_2efunctionElimC(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionElimC_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionElimC_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2efunctionIntroSyn(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2enamedGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2erules_2enumLitSyn(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2eprimRune_get(void);
V g_heff_2eelab_2erules_2eprimString_get(void);
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2erecordTypeIntro(V, V);
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo;
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2esumFormation(V);
V g_heff_2eelab_2erules_2esumFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_clo;
V g_heff_2eelab_2erules_2esumIntro(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntro_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V);
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(V);
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V);
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V);
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eargBinding(V);
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eargBinding_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echeckUnsolved(V, V, V);
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkHeadOf(V, V);
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2edefineD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edefineD_clo;
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2edoPat(V);
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoPat_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eequationsBody(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo;
V g_heff_2eelab_2etoplevel_2eequationsD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_clo;
V g_heff_2eelab_2etoplevel_2eerrEntry(V, V, V);
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2efailedAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efailedAt_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo;
V g_heff_2eelab_2etoplevel_2eflatPat(V);
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eflatPat_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2elamsOf(V, V);
V g_heff_2eelab_2etoplevel_2elamsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elamsOf_clo;
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V, V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2emetasInV(V, V);
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2emetasInV_clo;
V g_heff_2eelab_2etoplevel_2emonomorphicInstance(V, V);
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn(V);
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo;
V g_heff_2eelab_2etoplevel_2enominalTyp(V);
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
V g_heff_2eelab_2etoplevel_2eparamsOf(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsOf_clo;
V g_heff_2eelab_2etoplevel_2epatName(V);
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epatName_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2eshownV(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eshownV_clo;
V g_heff_2eelab_2etoplevel_2espineVals(V);
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2espineVals_clo;
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2etagSynonym(V);
V g_heff_2eelab_2etoplevel_2etagSynonym_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSynonym_clo;
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2eelab_2etoplevel_2etheoryD(V, V, V);
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etheoryD_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etopGo(V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL(V, V);
V g_heff_2eelab_2etoplevel_2etraverseEL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2etoplevel_2ewatchPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo;
V g_heff_2eelab_2etoplevel_2ewatchSyn(V);
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithOne(V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_clo;
V g_heff_2esyntax_2epsurface_2eunIsTy(V);
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTermF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTermF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    if (heff_strEq_c(heff_dup(v_x_245), v_k_241)) {
      heff_drop(v_x_245);
      return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_SLocal, 1, (V[]){v_d_242});
    } else {
      heff_drop(v_d_242);
      return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_SGlobal, 1, (V[]){v_x_245});
    }
  }
  case TAG_SCode: {
    V v_a_247 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_247}));
    return heff_tag_at_n(v_ru_24t_243_24SCode, TAG_SCode, 1, (V[]){v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_t_243, 0);
    V v_a_2410 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SApp = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_f_249}));
    V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_a_2410}));
    return heff_tag_at_n(v_ru_24t_243_24SApp, TAG_SApp, 2, (V[]){v_t_2411, v_t_2412});
  }
  case TAG_SLam: {
    V v_dom_2413 = heff_field(v_t_243, 0);
    V v_t2_2414 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SLam = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    switch (heff_tag_of(v_t2_2414)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_t2_2414, 0);
      V v_b_2416 = heff_field(v_t2_2414, 1);
      heff_take_n(v_t2_2414, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2413}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2417, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2418})});
    }
    case TAG_AbsConst: {
      V v_b_2419 = heff_field(v_t2_2414, 0);
      heff_take_n(v_t2_2414, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2413}));
      V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2419}));
      return heff_tag_at_n(v_ru_24t_243_24SLam, TAG_SLam, 2, (V[]){v_t_2420, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2421})});
    }
    default: return heff_nomatch(v_t2_2414);
    }
  }
  case TAG_SCons: {
    V v_c_2422 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SCons = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_f_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_xs_2424 = heff_take_field(v_c_2422, 2);
    V v_t_2427 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2424)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam0, 1, 2, (V[]){v_xs_2424, v_f_2423}));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_n(v_c_2422, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SCons, TAG_SCons, 1, (V[]){v_t_2428});
  }
  case TAG_SProj: {
    V v_e_2429 = heff_field(v_t_243, 0);
    V v_l_2430 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SProj = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2429}));
    return heff_tag_at_n(v_ru_24t_243_24SProj, TAG_SProj, 2, (V[]){v_t_2431, v_l_2430});
  }
  case TAG_STag: {
    V v_tg_2432 = heff_field(v_t_243, 0);
    V v_as_2433 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24STag = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_f_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_242}));
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_as_2433)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam1, 1, 2, (V[]){v_as_2433, v_f_2434}));
    return heff_tag_at_n(v_ru_24t_243_24STag, TAG_STag, 2, (V[]){v_tg_2432, v_t_2437});
  }
  case TAG_SMatch: {
    V v_e_2438 = heff_field(v_t_243, 0);
    V v_cs_2439 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SMatch = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2438}));
    V v_xs_2441 = heff_take_field(v_cs_2439, 2);
    V v_t_2448 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2441)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTermF_lam2, 1, 3, (V[]){v_xs_2441, v_d_242, v_r_240}));
    V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_n(v_cs_2439, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SMatch, TAG_SMatch, 2, (V[]){v_t_2440, v_t_2449});
  }
  case TAG_SSpecialize: {
    V v_e_2450 = heff_field(v_t_243, 0);
    V v_l_2451 = heff_field(v_t_243, 1);
    V v_v_2452 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SSpecialize = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_k_241);
    V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_d_242), v_e_2450}));
    V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_v_2452}));
    return heff_tag_at_n(v_ru_24t_243_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2453, v_l_2451, v_t_2454});
  }
  case TAG_SIs: {
    V v_e_2455 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIs = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2455}));
    return heff_tag_at_n(v_ru_24t_243_24SIs, TAG_SIs, 1, (V[]){v_t_2456});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SRec: {
    V v_e_2457 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SRec = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2457}));
    return heff_tag_at_n(v_ru_24t_243_24SRec, TAG_SRec, 1, (V[]){v_t_2458});
  }
  case TAG_SFix: {
    V v_dom_2459 = heff_field(v_t_243, 0);
    V v_t2_2460 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SFix = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    switch (heff_tag_of(v_t2_2460)) {
    case TAG_MkAbs: {
      V v_x_2461 = heff_field(v_t2_2460, 0);
      V v_b_2462 = heff_field(v_t2_2460, 1);
      heff_take_n(v_t2_2460, 3ULL, 2);
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2459}));
      V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2462}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2463, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2461, v_t_2464})});
    }
    case TAG_AbsConst: {
      V v_b_2465 = heff_field(v_t2_2460, 0);
      heff_take_n(v_t2_2460, 1ULL, 1);
      V v_t_2466 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){heff_dup(v_d_242), v_dom_2459}));
      V v_t_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_b_2465}));
      return heff_tag_at_n(v_ru_24t_243_24SFix, TAG_SFix, 2, (V[]){v_t_2466, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2467})});
    }
    default: return heff_nomatch(v_t2_2460);
    }
  }
  case TAG_SImplicit: {
    V v_x_2468 = heff_field(v_t_243, 0);
    V v_e_2469 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24SImplicit = heff_take_reuse_n(v_t_243, 3ULL, 2);
    heff_drop(v_k_241);
    V v_t_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_2469}));
    return heff_tag_at_n(v_ru_24t_243_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2468, v_t_2470});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SMetaApp: {
    V v_m_2472 = heff_field(v_t_243, 0);
    V v_ix_2473 = heff_field(v_t_243, 1);
    V v_ty2_2474 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SMetaApp = heff_take_reuse_n(v_t_243, 7ULL, 3);
    heff_drop(v_k_241);
    V v_t_2475 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_ty2_2474}));
    return heff_tag_at_n(v_ru_24t_243_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2472, v_ix_2473, v_t_2475});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_k_241);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eselfTermF(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam0(V self, V *args) {
  V v_i_2425 = args[0];
  V v_xs_2424 = heff_env(self)[0];
  V v_f_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_arrayIndex(v_xs_2424, v_i_2425);
  V f_ = v_f_2423;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam1(V self, V *args) {
  V v_i_2435 = args[0];
  V v_as_2433 = heff_env(self)[0];
  V v_f_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_arrayIndex(v_as_2433, v_i_2435);
  V f_ = v_f_2434;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTermF_lam2(V self, V *args) {
  V v_i_2442 = args[0];
  V v_xs_2441 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_2443 = heff_arrayIndex(v_xs_2441, v_i_2442);
  switch (heff_tag_of(v_p_2443)) {
  case TAG_MkPair: {
    V v_xs_2444 = heff_field(v_p_2443, 0);
    V v_b_2445 = heff_field(v_p_2443, 1);
    V v_ru_24p_2443_24MkPair = heff_take_reuse_n(v_p_2443, 3ULL, 2);
    V v_t_2446 = heff_intAdd(v_d_242, heff_arrayLength(heff_dup(v_xs_2444)));
    V v_t_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_t_2446, v_b_2445}));
    return heff_tag_at_n(v_ru_24p_2443_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2444, v_t_2447});
  }
  default: return heff_nomatch(v_p_2443);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTypeF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTypeF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_f_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2423 = heff_take_field(v_ft_2420, 2);
    V v_t_2426 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2423)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam0, 1, 2, (V[]){v_xs_2423, v_f_2422}));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_n(v_ft_2420, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2427, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2430 = heff_take_field(v_vs_2428, 2);
    V v_t_2435 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2430)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_f_2429}));
    V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_n(v_vs_2428, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2436});
  }
  case TAG_SIsTy: {
    V v_a_2437 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2437}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2438});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    V v_a_2439 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2439}));
    return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2440});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eselfTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_xs_2423 = heff_env(self)[0];
  V v_f_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_arrayIndex(v_xs_2423, v_i_2424);
  V f_ = v_f_2422;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  V f_ = v_f_2429;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2432)), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam2, 1, 2, (V[]){v_xs_2432, v_f_2429}));
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfWalk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eselfWalk(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam1, 2, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eselfWalk(a[0]);
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return (g_heff_2eelab_2etoplevel_2eselfTermF(v_t_243, v_k_240, v_d_241, v_t_242));
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eselfWalk(heff_dup(v_k_240)));
  return ({ V a_0 = v_t_246; V a_1 = v_k_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eselfTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalSyn(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_res_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  V v_x1_2412 = heff_tr(heff_call(heff_get_n(v_res_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2416});
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_res_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    V v_ru_24x_247_24MkPair = heff_take_reuse_n(v_x_247, 3ULL, 2);
    V v_t_2410 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_res_248, 0))});
    V v_t_2417 = heff_tag_at_n(v_ru_24x_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(2, shape_stx__val, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam3, 1, 1, (V[]){v_res_248})}), v_a_249});
    V f_ = v_k_246;
    args[0] = v_t_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalSyn_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkSyn: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_n(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_call(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalSyn_lam1, 2, 1, (V[]){v_c_244});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalChk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalChk(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam0, 2, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalChk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args) {
  V v_u_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2415});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_x_248, 0))});
  V f_ = v_k_247;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam3, 1, 1, (V[]){v_x_248})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam2, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_245;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkChk: {
    V v_f_243 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_244 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_n(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_245 = heff_tr(heff_call(v_f_243, 2, (V[]){v_t_244, v_a_242}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam1, 2, 1, (V[]){v_c_245});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalTyp_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalTyp(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalTyp(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args) {
  V v_u_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  V v_x1_2410 = heff_tr(heff_call(heff_get_n(v_x_247, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2414});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_SIsTy, 1, (V[]){heff_dup(heff_rfield(v_x_247, 0))});
  V f_ = v_k_246;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam3, 1, 1, (V[]){v_x_247})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_n(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_call(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam1, 2, 1, (V[]){v_c_244});
}
Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echecksOnly_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echecksOnly(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_c1_241 = heff_field(v_c_240, 0);
    switch (heff_tag_of(v_c1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_c1_241, 0);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(heff_dup(v_i_243)));
      V v_x1_245 = heff_get_n(v_t_244, 0, 2);
      V v_t_248;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_At: {
        V v_x_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 2);
        v_t_248 = v_x_246;
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      switch (heff_tag_of(v_t_248)) {
      case TAG_IVar: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IInt: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IFloat: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IString: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IRune: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IApp: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_IAnn: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_ISpec: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_False);
      }
      case TAG_IAnnLam: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_True);
      }
      case TAG_IInvalid: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_INominal: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_ILitEq: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_CType: {
      return NTAG(TAG_False);
    }
    case TAG_CLam: {
      return NTAG(TAG_True);
    }
    case TAG_CImplicitLam: {
      return NTAG(TAG_True);
    }
    case TAG_CAnnLam: {
      return NTAG(TAG_True);
    }
    case TAG_CTag: {
      return NTAG(TAG_True);
    }
    case TAG_CStruct: {
      return NTAG(TAG_True);
    }
    case TAG_CMatch: {
      return NTAG(TAG_True);
    }
    case TAG_CLetIn: {
      return NTAG(TAG_True);
    }
    case TAG_CLocal: {
      return NTAG(TAG_True);
    }
    case TAG_CAbandon: {
      return NTAG(TAG_True);
    }
    case TAG_CNominal: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_c1_241);
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2echecksOnly(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveringChk_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2erecoveringChk(V v_m_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tr(heff_call(v_m_240, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam0, 1, 1, (V[]){heff_dup(v_hd_241)})}));
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_244, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam1, 1, 1, (V[]){heff_dup(v_hd_241)})})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_247}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam2, 1, 1, (V[]){v_k_242})});
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveringChk(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_s_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam3(V self, V *args) {
  V v_e_2411 = args[0];
  V v_a_2412 = args[1];
  V v_hd_2413 = args[2];
  V v_k2_2414 = args[3];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2411);
  heff_drop(v_a_2412);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_d_2410})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erecoveringChk_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Left: {
    V v_d_2410 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Left = heff_take_reuse_n(v_x_249, 1ULL, 1);
    V v_t_2418 = ({ V b_0 = heff_tag_at_n(v_ru_24x_249_24Left, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveringChk_lam3, 4, 1, (V[]){v_d_2410})}); V r_ = (g_heff_2eelab_2erules_2erecovering(b_0)); heff_drop(b_0); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_c_2419 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2420 = ({ V a_0 = v_c_2419; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_c_2419); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2etoplevel_2etraverseEL(v_f_240, v_xs_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str0, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str1, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str2, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str3, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str4, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str5, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str6, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str7, 54, "an argument of a `case` pattern is a pattern or a name");
HEFF_LIT(g_heff_2eelab_2etoplevel_2epatName_str8, 54, "an argument of a `case` pattern is a pattern or a name");
V g_heff_2eelab_2etoplevel_2epatName_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2epatName_lam9(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epatName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epatName_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2epatName(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam0, 2, 1, (V[]){heff_dup(v_x_243)});
    }
    case TAG_PatTag: {
      V v_sp_2411;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2410 = heff_field(v_p_240, 1);
        v_sp_2411 = heff_dup(v_s_2410);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam1, 2, 1, (V[]){v_sp_2411});
    }
    case TAG_PatOp: {
      V v_sp_2423;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_p_240, 1);
        v_sp_2423 = heff_dup(v_s_2422);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam2, 2, 1, (V[]){v_sp_2423});
    }
    case TAG_PatInt: {
      V v_sp_2433;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_p_240, 1);
        v_sp_2433 = heff_dup(v_s_2432);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam3, 2, 1, (V[]){v_sp_2433});
    }
    case TAG_PatFloat: {
      V v_sp_2443;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2442 = heff_field(v_p_240, 1);
        v_sp_2443 = heff_dup(v_s_2442);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam4, 2, 1, (V[]){v_sp_2443});
    }
    case TAG_PatString: {
      V v_sp_2453;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2452 = heff_field(v_p_240, 1);
        v_sp_2453 = heff_dup(v_s_2452);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam5, 2, 1, (V[]){v_sp_2453});
    }
    case TAG_PatRune: {
      V v_sp_2463;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_p_240, 1);
        v_sp_2463 = heff_dup(v_s_2462);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam6, 2, 1, (V[]){v_sp_2463});
    }
    case TAG_PatRecord: {
      V v_sp_2473;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2472 = heff_field(v_p_240, 1);
        v_sp_2473 = heff_dup(v_s_2472);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam7, 2, 1, (V[]){v_sp_2473});
    }
    case TAG_PatWord: {
      V v_sp_2483;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2482 = heff_field(v_p_240, 1);
        v_sp_2483 = heff_dup(v_s_2482);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam8, 2, 1, (V[]){v_sp_2483});
    }
    case TAG_PatAs: {
      V v_sp_2495;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2494 = heff_field(v_p_240, 1);
        v_sp_2495 = heff_dup(v_s_2494);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2epatName_lam9, 2, 1, (V[]){v_sp_2495});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2epatName(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2epatName_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_sp_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str0), v_sp_2411, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_sp_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str1), v_sp_2423, NTAG(TAG_Nothing)});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2428}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam3(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k2_2435 = args[1];
  V v_sp_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str2), v_sp_2433, NTAG(TAG_Nothing)});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_2434, 2), 1, (V[]){v_t_2438}));
  V f_ = heff_get_n(v_hd_2434, 1, 3);
  args[0] = v_t_2439;
  args[1] = v_k2_2435;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam4(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k2_2445 = args[1];
  V v_sp_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str3), v_sp_2443, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_2444, 2), 1, (V[]){v_t_2448}));
  V f_ = heff_get_n(v_hd_2444, 1, 3);
  args[0] = v_t_2449;
  args[1] = v_k2_2445;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam5(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_sp_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str4), v_sp_2453, NTAG(TAG_Nothing)});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2458}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2459;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam6(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_sp_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str5), v_sp_2463, NTAG(TAG_Nothing)});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_call(heff_take_field(v_hd_2464, 2), 1, (V[]){v_t_2468}));
  V f_ = heff_get_n(v_hd_2464, 1, 3);
  args[0] = v_t_2469;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam7(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k2_2475 = args[1];
  V v_sp_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str6), v_sp_2473, NTAG(TAG_Nothing)});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_call(heff_take_field(v_hd_2474, 2), 1, (V[]){v_t_2478}));
  V f_ = heff_get_n(v_hd_2474, 1, 3);
  args[0] = v_t_2479;
  args[1] = v_k2_2475;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam8(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k2_2485 = args[1];
  V v_sp_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str7), v_sp_2483, NTAG(TAG_Nothing)});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tr(heff_call(heff_take_field(v_hd_2484, 2), 1, (V[]){v_t_2488}));
  V f_ = heff_get_n(v_hd_2484, 1, 3);
  args[0] = v_t_2489;
  args[1] = v_k2_2485;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2epatName_lam9(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k2_2497 = args[1];
  V v_sp_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epatName_str8), v_sp_2495, NTAG(TAG_Nothing)});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tr(heff_call(heff_take_field(v_hd_2496, 2), 1, (V[]){v_t_24100}));
  V f_ = heff_get_n(v_hd_2496, 1, 3);
  args[0] = v_t_24101;
  args[1] = v_k2_2497;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2epatName(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str2, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str3, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str4, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str5, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str6, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str7, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str8, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str9, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str10, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edoPat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoPat(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_240)));
  V v_it_242 = heff_get_n(v_t_241, 0, 2);
  switch (heff_tag_of(v_it_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_PatVar: {
      V v_it11_245 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      if (heff_strEq_c(v_it11_245, ((V)&g_heff_2eelab_2etoplevel_2edoPat_str0))) {
        heff_drop(v_p_240);
        return ((V)&g_heff_2eelab_2etoplevel_2edoPat_lam0_clo);
      } else {
        V v_sp_2412;
        switch (heff_tag_of(v_p_240)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_p_240, 1);
          heff_take_n(v_p_240, 2ULL, 2);
          v_sp_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_p_240);
        }
        return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam1, 2, 1, (V[]){v_sp_2412});
      }
    }
    case TAG_PatTag: {
      V v_x_2419 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 3);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_240));
      V v_c_2423 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(heff_get_n(v_t_2422, 1, 2)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam2, 2, 2, (V[]){v_c_2423, v_x_2419});
    }
    case TAG_PatOp: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_2432;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam4, 2, 1, (V[]){v_sp_2432});
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2442;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam5, 2, 1, (V[]){v_sp_2442});
    }
    case TAG_PatFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2452;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2451 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam6, 2, 1, (V[]){v_sp_2452});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2462;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2461 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2462 = v_s_2461;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam7, 2, 1, (V[]){v_sp_2462});
    }
    case TAG_PatRune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2472;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2471 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2472 = v_s_2471;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam8, 2, 1, (V[]){v_sp_2472});
    }
    case TAG_PatRecord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2482;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2481 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2482 = v_s_2481;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam9, 2, 1, (V[]){v_sp_2482});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2492;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2491 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam10, 2, 1, (V[]){v_sp_2492});
    }
    case TAG_PatAs: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_24104;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_24103 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_24104 = v_s_24103;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam11, 2, 1, (V[]){v_sp_24104});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoPat(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2edoPat_str1), NTAG(TAG_Nil)});
  V f_ = v_k_248;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_sp_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str2), v_sp_2412, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam3, 1, 2, (V[]){v_k_2425, v_x_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_sp_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str3), v_sp_2432, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2438;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_sp_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str4), v_sp_2442, NTAG(TAG_Nothing)});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_call(heff_take_field(v_hd_2443, 2), 1, (V[]){v_t_2447}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2448;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_sp_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str5), v_sp_2452, NTAG(TAG_Nothing)});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_2453, 2), 1, (V[]){v_t_2457}));
  V f_ = heff_get_n(v_hd_2453, 1, 3);
  args[0] = v_t_2458;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k2_2464 = args[1];
  V v_sp_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str6), v_sp_2462, NTAG(TAG_Nothing)});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_2463, 2), 1, (V[]){v_t_2467}));
  V f_ = heff_get_n(v_hd_2463, 1, 3);
  args[0] = v_t_2468;
  args[1] = v_k2_2464;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k2_2474 = args[1];
  V v_sp_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str7), v_sp_2472, NTAG(TAG_Nothing)});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_2473, 2), 1, (V[]){v_t_2477}));
  V f_ = heff_get_n(v_hd_2473, 1, 3);
  args[0] = v_t_2478;
  args[1] = v_k2_2474;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k2_2484 = args[1];
  V v_sp_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str8), v_sp_2482, NTAG(TAG_Nothing)});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_2483, 2), 1, (V[]){v_t_2487}));
  V f_ = heff_get_n(v_hd_2483, 1, 3);
  args[0] = v_t_2488;
  args[1] = v_k2_2484;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k2_2494 = args[1];
  V v_sp_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str9), v_sp_2492, NTAG(TAG_Nothing)});
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_2493, 2), 1, (V[]){v_t_2497}));
  V f_ = heff_get_n(v_hd_2493, 1, 3);
  args[0] = v_t_2498;
  args[1] = v_k2_2494;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k2_24106 = args[1];
  V v_sp_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str10), v_sp_24104, NTAG(TAG_Nothing)});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tr(heff_call(heff_take_field(v_hd_24105, 2), 1, (V[]){v_t_24109}));
  V f_ = heff_get_n(v_hd_24105, 1, 3);
  args[0] = v_t_24110;
  args[1] = v_k2_24106;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eannotatesData_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eannotatesData(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      return NTAG(TAG_False);
    }
    case TAG_IRune: {
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      V v_c_2410 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_c1_2412 = heff_field(v_c_2410, 0);
        switch (heff_tag_of(v_c1_2412)) {
        case TAG_CInf: {
          return NTAG(TAG_False);
        }
        case TAG_CType: {
          return NTAG(TAG_False);
        }
        case TAG_CLam: {
          return NTAG(TAG_False);
        }
        case TAG_CImplicitLam: {
          return NTAG(TAG_False);
        }
        case TAG_CAnnLam: {
          return NTAG(TAG_False);
        }
        case TAG_CTag: {
          return NTAG(TAG_True);
        }
        case TAG_CStruct: {
          return NTAG(TAG_True);
        }
        case TAG_CMatch: {
          return NTAG(TAG_False);
        }
        case TAG_CLetIn: {
          return NTAG(TAG_False);
        }
        case TAG_CLocal: {
          return NTAG(TAG_False);
        }
        case TAG_CAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_CNominal: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_c1_2412);
        }
      }
      default: return heff_nomatch(v_c_2410);
      }
    }
    case TAG_ISpec: {
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      return NTAG(TAG_False);
    }
    case TAG_IInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      return NTAG(TAG_False);
    }
    case TAG_ILitEq: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eannotatesData(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2421;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        v_t_2421 = NTAG(TAG_True);
        break;
      }
      case TAG_PatTag: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatOp: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatInt: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatFloat: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatString: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatRune: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatRecord: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatWord: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      case TAG_PatAs: {
        v_t_2421 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eflatPat_str0, 1, "_");
Clo g_heff_2eelab_2etoplevel_2eflatPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eflatPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eflatPat(V v_gr_240) {
top: ;
  V v_t_241 = heff_take_field(v_gr_240, 0);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 2);
    v_t_244 = v_x_242;
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_PatVar: {
    V v_x_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    if (heff_strEq_c(v_x_245, ((V)&g_heff_2eelab_2etoplevel_2eflatPat_str0))) {
      V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_gr_240, 1, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_intEq(v_t_247, MK_INT(0LL));
    } else {
      heff_drop_rec(v_gr_240, 2);
      return NTAG(TAG_False);
    }
  }
  case TAG_PatTag: {
    heff_take_n(v_t_244, 0ULL, 3);
    return ({ V b_0 = heff_get_n(v_gr_240, 1, 2); V r_ = (g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(b_0)); heff_drop(b_0); r_; });
  }
  case TAG_PatOp: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRune: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatWord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eflatPat(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2etagSpans_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSpans_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSpans(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      switch (heff_tag_of(v_x111_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x111_243, 0);
        heff_take_n(v_x111_243, 1ULL, 2);
        V v_acc_247 = (g_heff_2eelab_2etoplevel_2etagSpans(v_rest_242));
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_245));
        V v_it_249 = heff_get_n(v_t_248, 0, 2);
        switch (heff_tag_of(v_it_249)) {
        case TAG_At: {
          V v_it1_2410 = heff_field(v_it_249, 0);
          V v_tsp_2411 = heff_field(v_it_249, 1);
          heff_take_n(v_it_249, 3ULL, 2);
          switch (heff_tag_of(v_it1_2410)) {
          case TAG_PatVar: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatTag: {
            V v_x_2413 = heff_field(v_it1_2410, 0);
            heff_take_n(v_it1_2410, 1ULL, 3);
            return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_tsp_2411}), v_acc_247});
          }
          case TAG_PatOp: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatInt: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatFloat: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatString: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRune: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatRecord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatWord: {
            heff_take_n(v_it1_2410, 0ULL, 1);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          case TAG_PatAs: {
            heff_take_n(v_it1_2410, 0ULL, 3);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_tsp_2411);
            return v_acc_247;
          }
          default: return heff_nomatch(v_it1_2410);
          }
        }
        default: return heff_nomatch(v_it_249);
        }
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSpans(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2elamsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elamsOf_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elamsOf(V v_n_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_SLocal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SCode: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLam: {
    V v_b2_248 = heff_field(v_b_241, 1);
    heff_take_n(v_b_241, 2ULL, 2);
    switch (heff_tag_of(v_b2_248)) {
    case TAG_MkAbs: {
      V v_b22_2410 = heff_field(v_b2_248, 1);
      heff_take_n(v_b2_248, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b22_2410;
      v_n_240 = t_0;
      v_b_241 = t_1;
      goto top;
    }
    case TAG_AbsConst: {
      V v_b21_2411 = heff_field(v_b2_248, 0);
      heff_take_n(v_b2_248, 1ULL, 1);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b21_2411;
      v_n_240 = t_0;
      v_b_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_b2_248);
    }
  }
  case TAG_SCons: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_STag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SSpecialize: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SIs: {
    V v_b1_2422 = heff_field(v_b_241, 0);
    heff_take_n(v_b_241, 1ULL, 1);
    V t_0 = v_n_240;
    V t_1 = v_b1_2422;
    v_n_240 = t_0;
    v_b_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SRec: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SImplicit: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SMetaApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitString: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitRune: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  case TAG_SLitFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_n_240, v_b_241});
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2eelab_2etoplevel_2elamsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elamsOf(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eparamsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eparamsOf_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eparamsOf(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SU: {
    V v_ru_24x3_242_24SU = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SU, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SDecode: {
    V v_ru_24x3_242_24SDecode = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SDecode, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SFunction: {
    V v_cod_247 = heff_field(v_x3_242, 2);
    V v_x34_248 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 12ULL, 5);
    switch (heff_tag_of(v_x34_248)) {
    case TAG_Expl: {
      V v_t_2413;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2411 = heff_field(v_cod_247, 1);
        heff_take_n(v_cod_247, 2ULL, 2);
        v_t_2413 = v_t_2411;
        break;
      }
      case TAG_AbsConst: {
        V v_t_2412 = heff_field(v_cod_247, 0);
        heff_take_n(v_cod_247, 1ULL, 1);
        v_t_2413 = v_t_2412;
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V t_0 = v_i_240;
      V t_1 = heff_intAdd(v_e_241, MK_INT(1LL));
      V t_2 = v_t_2413;
      v_i_240 = t_0;
      v_e_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Impl: {
      if (heff_intLt_c(MK_INT(0LL), heff_dup(v_e_241))) {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_cod_247);
        return NTAG(TAG_Nothing);
      } else {
        V v_t_2418;
        switch (heff_tag_of(v_cod_247)) {
        case TAG_MkAbs: {
          V v_t_2416 = heff_field(v_cod_247, 1);
          heff_take_n(v_cod_247, 2ULL, 2);
          v_t_2418 = v_t_2416;
          break;
        }
        case TAG_AbsConst: {
          V v_t_2417 = heff_field(v_cod_247, 0);
          heff_take_n(v_cod_247, 1ULL, 1);
          v_t_2418 = v_t_2417;
          break;
        }
        default: heff_nomatch(v_cod_247);
        }
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_t_2418;
        v_i_240 = t_0;
        v_e_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_Inst: {
      heff_drop(v_i_240);
      heff_drop(v_e_241);
      heff_drop(v_cod_247);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x34_248);
    }
  }
  case TAG_SRecord: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SSum: {
    V v_ru_24x3_242_24SSum = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SSum, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SIsTy: {
    V v_ru_24x3_242_24SIsTy = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SIsTy, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimInt: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimFloat: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimString: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimRune: {
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SPrimArray: {
    V v_ru_24x3_242_24SPrimArray = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SPrimArray, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  case TAG_SFixed: {
    V v_ru_24x3_242_24SFixed = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    return heff_tag_at_n(v_ru_24x3_242_24SFixed, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eparamsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eparamsOf(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eparamsInOrder_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eparamsInOrder(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_intEq(v_i_241, v_k_240);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SLocal: {
      V v_j_245 = heff_field(v_x31_243, 0);
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_k_240), MK_INT(1LL)), heff_dup(v_i_241));
      if (heff_intEq_c(heff_dup(v_j_245), v_t_246)) {
        V t_0 = v_k_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_i_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_k_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eparamsInOrder(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2etagSynonym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etagSynonym_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etagSynonym(V v_ge_240) {
top: ;
  V v_it_241 = (g_heff_2eelab_2etoplevel_2eparamsOf(MK_INT(0LL), MK_INT(0LL), heff_take_field(v_ge_240, 1)));
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ge_240, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_242 = heff_field(v_it_241, 0);
    V v_ru_24it_241_24Just = heff_take_reuse_n(v_it_241, 1ULL, 1);
    switch (heff_tag_of(v_it1_242)) {
    case TAG_MkPair: {
      V v_i_243 = heff_field(v_it1_242, 0);
      V v_k_244 = heff_field(v_it1_242, 1);
      heff_take_n(v_it1_242, 3ULL, 2);
      V v_it_245 = (g_heff_2eelab_2etoplevel_2elamsOf(MK_INT(0LL), heff_get_n(v_ge_240, 0, 4)));
      switch (heff_tag_of(v_it_245)) {
      case TAG_MkPair: {
        V v_n_246 = heff_field(v_it_245, 0);
        V v_it2_247 = heff_field(v_it_245, 1);
        heff_take_n(v_it_245, 3ULL, 2);
        switch (heff_tag_of(v_it2_247)) {
        case TAG_SLocal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          V v_t_2418 = heff_field(v_it2_247, 0);
          V v_args_2419 = heff_field(v_it2_247, 1);
          heff_take_n(v_it2_247, 3ULL, 2);
          if (heff_intEq_c(v_n_246, heff_intAdd(v_i_243, heff_dup(v_k_244)))) {
            V v_t_2421 = ({ V a_0 = heff_dup(v_k_244); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_args_2419); V r_ = (g_heff_2eelab_2etoplevel_2eparamsInOrder(a_0, a_1, b_2)); heff_drop(b_2); r_; });
            switch (heff_tag_of(v_t_2421)) {
            case TAG_True: {
              return heff_tag_at_n(v_ru_24it_241_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_k_244})});
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_241_24Just, 1);
              heff_drop(v_k_244);
              heff_drop(v_t_2418);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_t_2421);
            }
          } else {
            heff_drop_cell(v_ru_24it_241_24Just, 1);
            heff_drop(v_k_244);
            heff_drop(v_t_2418);
            heff_drop(v_args_2419);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_SMatch: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SOpaque: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_it2_247, 0ULL, 3);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_it2_247, 0ULL, 2);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_it2_247, 0ULL, 1);
          heff_drop_cell(v_ru_24it_241_24Just, 1);
          heff_drop(v_i_243);
          heff_drop(v_k_244);
          heff_drop(v_n_246);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it2_247);
        }
      }
      default: return heff_nomatch(v_it_245);
      }
    }
    default: return heff_nomatch(v_it1_242);
    }
  }
  default: return heff_nomatch(v_it_241);
  }
}
V g_heff_2eelab_2etoplevel_2etagSynonym_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etagSynonym(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_x_241));
    switch (heff_tag_of(v_a_243)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      V v_a_245 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_244));
      switch (heff_tag_of(v_a_245)) {
      case TAG_True: {
        v_t_246 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_246 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ehasOpPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ehasOpPat(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_x1_247 = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(v_ps_246));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    case TAG_PatOp: {
      return NTAG(TAG_True);
    }
    case TAG_PatInt: {
      return NTAG(TAG_False);
    }
    case TAG_PatFloat: {
      return NTAG(TAG_False);
    }
    case TAG_PatString: {
      return NTAG(TAG_False);
    }
    case TAG_PatRune: {
      return NTAG(TAG_False);
    }
    case TAG_PatRecord: {
      V v_fs_2415 = heff_field(v_p1_241, 0);
      V v_x1_2416 = (g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(v_fs_2415));
      switch (heff_tag_of(v_x1_2416)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_x1_2416);
      }
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      V v_q_2420 = heff_field(v_p1_241, 2);
      V t_0 = v_q_2420;
      v_p_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ehasOpPat(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str0, 17, "no such operator ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str1, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str2, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str3, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str4, 14, ") x y = C x y`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str5, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str6, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str7, 14, ") x y = C x y`");
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eopPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eopPat_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eopPat(V v_g_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_dup(heff_field(v_p_241, 0));
    V v_p2_243 = heff_dup(heff_field(v_p_241, 1));
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam0, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatTag: {
      V v_t_247 = heff_field(v_p1_242, 0);
      V v_tsp_248 = heff_field(v_p1_242, 1);
      V v_args_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_p2_243);
      V v_c_2411 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam1, 1, 1, (V[]){v_g_240}), v_args_249));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam2, 2, 3, (V[]){v_c_2411, v_t_247, v_tsp_248});
    }
    case TAG_PatOp: {
      V v_x_2422 = heff_field(v_p1_242, 0);
      V v_xsp_2423 = heff_field(v_p1_242, 1);
      V v_args_2424 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_p2_243);
      V v_t_2425 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2422), heff_rfield(v_g_240, 2)));
      V v_it_2431;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nothing: {
        V v_t_2426 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2422), heff_rfield(v_g_240, 1)));
        switch (heff_tag_of(v_t_2426)) {
        case TAG_Nothing: {
          v_it_2431 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_e_2427 = heff_field(v_t_2426, 0);
          V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
          v_it_2431 = heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2422), v_e_2427})});
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        break;
      }
      case TAG_Just: {
        V v_k_2428 = heff_field(v_t_2425, 0);
        V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 1ULL, 1);
        V v_t_2429 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_2428), heff_rfield(v_g_240, 1)));
        switch (heff_tag_of(v_t_2429)) {
        case TAG_Nothing: {
          heff_drop(v_k_2428);
          heff_drop_cell(v_ru_24t_2425_24Just, 1);
          v_it_2431 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_e_2430 = heff_field(v_t_2429, 0);
          heff_take_n(v_t_2429, 1ULL, 1);
          v_it_2431 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2428, v_e_2430})});
          break;
        }
        default: heff_nomatch(v_t_2429);
        }
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      switch (heff_tag_of(v_it_2431)) {
      case TAG_Nothing: {
        heff_drop_rec(v_g_240, 7);
        heff_drop(v_args_2424);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam4, 2, 2, (V[]){v_x_2422, v_xsp_2423});
      }
      case TAG_Just: {
        V v_it1_2439 = heff_field(v_it_2431, 0);
        heff_take_n(v_it_2431, 1ULL, 1);
        switch (heff_tag_of(v_it1_2439)) {
        case TAG_MkPair: {
          V v_ge_2441 = heff_field(v_it1_2439, 1);
          heff_take_n(v_it1_2439, 2ULL, 2);
          V v_it_2442 = (g_heff_2eelab_2etoplevel_2etagSynonym(v_ge_2441));
          switch (heff_tag_of(v_it_2442)) {
          case TAG_Nothing: {
            heff_drop_rec(v_g_240, 7);
            heff_drop(v_args_2424);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam5, 2, 2, (V[]){v_x_2422, v_xsp_2423});
          }
          case TAG_Just: {
            V v_it1_2450 = heff_field(v_it_2442, 0);
            heff_take_n(v_it_2442, 1ULL, 1);
            switch (heff_tag_of(v_it1_2450)) {
            case TAG_MkPair: {
              V v_t_2451 = heff_field(v_it1_2450, 0);
              V v_k_2452 = heff_field(v_it1_2450, 1);
              heff_take_n(v_it1_2450, 3ULL, 2);
              V v_t_2453 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_args_2424));
              if (heff_intEq_c(v_k_2452, v_t_2453)) {
                heff_drop(v_x_2422);
                V v_c_2456 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam6, 1, 1, (V[]){v_g_240}), v_args_2424));
                return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam7, 2, 3, (V[]){v_c_2456, v_t_2451, v_xsp_2423});
              } else {
                heff_drop_rec(v_g_240, 7);
                heff_drop(v_args_2424);
                heff_drop(v_t_2451);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam9, 2, 2, (V[]){v_x_2422, v_xsp_2423});
              }
            }
            default: return heff_nomatch(v_it1_2450);
            }
          }
          default: return heff_nomatch(v_it_2442);
          }
        }
        default: return heff_nomatch(v_it1_2439);
        }
      }
      default: return heff_nomatch(v_it_2431);
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam10, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam11, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam12, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam13, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRecord: {
      V v_fs_2486 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_tag(v_p_241, 2);
      V v_c_2494 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam14, 1, 1, (V[]){v_g_240}), v_fs_2486));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam17, 2, 2, (V[]){v_c_2494, v_p2_243});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 7);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam19, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatAs: {
      V v_x_24102 = heff_field(v_p1_242, 0);
      V v_xsp_24103 = heff_field(v_p1_242, 1);
      V v_q_24104 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      V v_c_24105 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_q_24104));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam20, 2, 4, (V[]){v_c_24105, v_x_24102, v_xsp_24103, v_p2_243});
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eopPat(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2410));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_tsp_248 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_247)}), heff_dup(v_tsp_248)});
  V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2415, v_x_2414));
  V v_b_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_At: {
    V v_s_2418 = heff_field(v_x1_2416, 1);
    heff_take_n(v_x1_2416, 2ULL, 2);
    v_b_2419 = v_s_2418;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_248, 0)); V rr_ = heff_rec_reuse_n(v_b_2419, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_247, v_tsp_248, v_x_2414}), v_t_2420});
  V f_ = v_k_2413;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_tsp_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam3, 1, 3, (V[]){v_t_247, v_tsp_248, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str0), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str1)));
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2434, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2438;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str2), heff_strAppend(heff_dup(v_x_2422), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str3), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str4)))));
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2445, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_2443, 2), 1, (V[]){v_t_2448}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2449;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args) {
  V v_m_2455 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2455));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_t_2451 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  V v_k_2458 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2451)}), heff_dup(v_xsp_2423)});
  V v_x1_2461 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2460, v_x_2459));
  V v_b_2464;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_At: {
    V v_s_2463 = heff_field(v_x1_2461, 1);
    heff_take_n(v_x1_2461, 2ULL, 2);
    v_b_2464 = v_s_2463;
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  V v_t_2465 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_2423, 0)); V rr_ = heff_rec_reuse_n(v_b_2464, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2451, v_xsp_2423, v_x_2459}), v_t_2465});
  V f_ = v_k_2458;
  args[0] = v_x_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_c_2456 = heff_env(self)[0];
  V v_t_2451 = heff_env(self)[1];
  V v_xsp_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2456;
  args[0] = v_hd_2457;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam8, 1, 3, (V[]){v_t_2451, v_xsp_2423, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str5), heff_strAppend(heff_dup(v_x_2422), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str6), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str7)))));
  V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2469, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_call(heff_take_field(v_hd_2467, 2), 1, (V[]){v_t_2472}));
  V f_ = heff_get_n(v_hd_2467, 1, 3);
  args[0] = v_t_2473;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2475);
  V f_ = v_k_2476;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2478);
  V f_ = v_k_2479;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k_2482 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2481);
  V f_ = v_k_2482;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2484);
  V f_ = v_k_2485;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args) {
  V v_x_2493 = args[0];
  V v_k_2492 = heff_env(self)[0];
  V v_x_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2492;
  args[0] = heff_tag_n(TAG_MkFieldPat, 2, (V[]){v_x_2488, v_x_2493});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_c_2490 = heff_env(self)[0];
  V v_x_2488 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2490;
  args[0] = v_hd_2491;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam16, 1, 2, (V[]){v_k_2492, v_x_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args) {
  V v_m_2487 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2487)) {
  case TAG_MkFieldPat: {
    V v_x_2488 = heff_field(v_m_2487, 0);
    V v_p_2489 = heff_field(v_m_2487, 1);
    heff_take_n(v_m_2487, 3ULL, 2);
    V v_c_2490 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_p_2489));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam15, 2, 2, (V[]){v_c_2490, v_x_2488});
  }
  default: return heff_nomatch(v_m_2487);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args) {
  V v_x_2497 = args[0];
  V v_p2_243 = heff_env(self)[0];
  V v_k_2496 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2498 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatRecord, 1, (V[]){v_x_2497}), v_p2_243});
  V f_ = v_k_2496;
  args[0] = v_t_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args) {
  V v_hd_2495 = args[0];
  V v_k_2496 = args[1];
  V v_c_2494 = heff_env(self)[0];
  V v_p2_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2494;
  args[0] = v_hd_2495;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam18, 1, 2, (V[]){v_p2_243, v_k_2496});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24100);
  V f_ = v_k_24101;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_24102 = heff_env(self)[0];
  V v_xsp_24103 = heff_env(self)[1];
  V v_p2_243 = heff_env(self)[2];
  V v_k_24107 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatAs, 3, (V[]){v_x_24102, v_xsp_24103, v_x_24108}), v_p2_243});
  V f_ = v_k_24107;
  args[0] = v_t_24109;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k_24107 = args[1];
  V v_c_24105 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  V v_xsp_24103 = heff_env(self)[2];
  V v_p2_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24105;
  args[0] = v_hd_24106;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam21, 1, 4, (V[]){v_x_24102, v_xsp_24103, v_p2_243, v_k_24107});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(v_a_247));
        switch (heff_tag_of(v_a_249)) {
        case TAG_True: {
          v_a_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_a_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_a_2410)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_a_2410);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_a_247 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_245));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_a_247)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_a_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_245)));
        v_t_248 = (g_heff_2eelab_2etoplevel_2eflatPat(v_t_247));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkHeadOf_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2echkHeadOf(V v_n_240, V v_j_241) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_i1_242 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_i1_242)) {
    case TAG_IVar: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_i1_242, 0ULL, 1);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_242, 0ULL, 2);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    case TAG_INominal: {
      V v_i11_2423 = heff_field(v_i1_242, 0);
      heff_take_n(v_i1_242, 1ULL, 1);
      v_t_2428 = v_i11_2423;
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_242, 0ULL, 4);
      v_t_2428 = heff_dup(v_n_240);
      break;
    }
    default: heff_nomatch(v_i1_242);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(v_t_2428));
  V v_it_2430 = heff_get_n(v_t_2429, 0, 2);
  switch (heff_tag_of(v_it_2430)) {
  case TAG_At: {
    V v_it1_2431 = heff_field(v_it_2430, 0);
    heff_take_n(v_it_2430, 1ULL, 2);
    switch (heff_tag_of(v_it1_2431)) {
    case TAG_IVar: {
      V v_x_2433 = heff_field(v_it1_2431, 0);
      heff_take_n(v_it1_2431, 1ULL, 1);
      V v_t_2436;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2435 = heff_dup(heff_field(v_n_240, 1));
        v_t_2436 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2439;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2440 = (g_heff_2eelab_2erules_2eapply(v_t_2439, v_j_241));
      return (g_heff_2eelab_2erules_2eautoRec(v_t_2436, v_x_2433, v_t_2440));
    }
    case TAG_IInt: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2444;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2444 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2444, v_j_241);
    }
    case TAG_IFloat: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2448;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2448, v_j_241);
    }
    case TAG_IString: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2451 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2452, v_j_241);
    }
    case TAG_IRune: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2456;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2455 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2456, v_j_241);
    }
    case TAG_IApp: {
      heff_take_n(v_it1_2431, 0ULL, 2);
      V v_t_2461;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2460 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2461 = v_s_2460;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2461, v_j_241);
    }
    case TAG_IAnn: {
      heff_take_n(v_it1_2431, 0ULL, 2);
      V v_t_2466;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2466 = v_s_2465;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2466, v_j_241);
    }
    case TAG_ISpec: {
      heff_take_n(v_it1_2431, 0ULL, 4);
      V v_t_2473;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2472 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2473 = v_s_2472;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2473, v_j_241);
    }
    case TAG_IAnnLam: {
      heff_take_n(v_it1_2431, 0ULL, 4);
      V v_t_2480;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2479 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2480 = v_s_2479;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2480, v_j_241);
    }
    case TAG_IInvalid: {
      heff_take_n(v_it1_2431, 0ULL, 2);
      V v_t_2485;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2484 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2485 = v_s_2484;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2485, v_j_241);
    }
    case TAG_INominal: {
      heff_take_n(v_it1_2431, 0ULL, 1);
      V v_t_2489;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2488 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2489 = v_s_2488;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2489, v_j_241);
    }
    case TAG_ILitEq: {
      heff_take_n(v_it1_2431, 0ULL, 4);
      V v_t_2496;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2495 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2496 = v_s_2495;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply(v_t_2496, v_j_241);
    }
    default: return heff_nomatch(v_it1_2431);
    }
  }
  default: return heff_nomatch(v_it_2430);
  }
}
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2echkHeadOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_At: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_sp_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_ArgExplicit: {
      V v_c_245 = heff_field(v_x41_243, 0);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0, 2, 5, (V[]){v_t_246, heff_dup(v_c_245), v_start_240, heff_dup(v_sp_244), heff_dup(v_s_241)});
    }
    case TAG_ArgProject: {
      V v_x_2413 = heff_field(v_x41_243, 0);
      heff_drop(v_start_240);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2, 2, 3, (V[]){heff_dup(v_sp_244), heff_dup(v_s_241), heff_dup(v_x_2413)});
    }
    case TAG_ArgNamed: {
      V v_x_2417 = heff_field(v_x41_243, 0);
      V v_c_2418 = heff_field(v_x41_243, 1);
      V v_t_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2418)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3, 2, 5, (V[]){v_t_2419, heff_dup(v_s_241), v_start_240, heff_dup(v_sp_244), heff_dup(v_x_2417)});
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = ({ V a_0 = v_c_245; V r_ = (g_heff_2eelab_2etoplevel_2echecksOnly(a_0)); heff_drop(v_c_245); r_; });
  V v_t_2411 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_n(v_sp_244, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2412 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V a_2 = v_s_241; V a_3 = v_x_249; V r_ = (g_heff_2eelab_2erules_2efunctionElimC(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); heff_drop(v_s_241); heff_drop(v_x_249); r_; });
  V f_ = v_k_248;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_s_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_246, v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam1, 1, 5, (V[]){v_c_245, v_start_240, v_sp_244, v_s_241, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_sp_244 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2414);
  V v_t_2416 = ({ V a_0 = v_sp_244; V a_1 = v_s_241; V a_2 = v_x_2413; V r_ = (g_heff_2eelab_2erules_2erecordElim(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
  V f_ = v_k_2415;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_x_2422 = heff_env(self)[3];
  V v_e_2423 = heff_env(self)[4];
  V v_hd_2426 = heff_env(self)[5];
  V v_k_2427 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_ecallee_2429 = heff_field(v_x_2428, 0);
    V v_a0_2430 = heff_field(v_x_2428, 1);
    heff_take_n(v_x_2428, 3ULL, 2);
    V v_t_2431 = ({ V rv_0 = v_start_240; V rr_ = heff_rec_reuse_n(v_sp_244, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ({ V a_0 = v_t_2431; V a_1 = v_x_2417; V a_2 = v_x_2422; V a_3 = v_e_2423; V a_4 = v_ecallee_2429; V a_5 = v_a0_2430; V a_6 = v_hd_2426; V a_7 = v_k_2427; V r_ = (g_heff_2eelab_2erules_2enamedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2422); r_; });
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_e_2423 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam7, 1, 7, (V[]){v_start_240, v_sp_244, v_x_2417, v_x_2422, v_e_2423, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5(V self, V *args) {
  V v_e_2423 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2425;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_2424 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_2425 = heff_tr(heff_call(v_f_2424, 1, (V[]){heff_dup(v_e_2423)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam6, 2, 6, (V[]){v_c_2425, v_start_240, v_sp_244, v_x_2417, v_x_2422, v_e_2423});
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam5, 1, 5, (V[]){v_s_241, v_start_240, v_sp_244, v_x_2417, v_x_2422})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_start_240 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_lam4, 1, 5, (V[]){v_k_2421, v_s_241, v_start_240, v_sp_244, v_x_2417})));
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0, 2, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_242, 0);
    V v_rest_246 = heff_field(v_x4_242, 1);
    V v_c_247 = ({ V a_0 = heff_dup(v_start_240); V a_1 = v_s_241; V a_2 = v_a_245; V r_ = (g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1, 2, 3, (V[]){v_c_247, v_start_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_s_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_start_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2, 1, 4, (V[]){v_start_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_27_241 = heff_dup(heff_field(v_n_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_27_241)) {
    case TAG_IVar: {
      V v_x_243 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0, 2, 2, (V[]){v_sp_242, v_x_243});
    }
    case TAG_IInt: {
      V v_i_247 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1, 2, 2, (V[]){v_sp_242, v_i_247});
    }
    case TAG_IFloat: {
      V v_x_2411 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2, 2, 2, (V[]){v_sp_242, v_x_2411});
    }
    case TAG_IString: {
      V v_s_2415 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3, 2, 1, (V[]){v_s_2415});
    }
    case TAG_IRune: {
      V v_c_2424 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6, 2, 1, (V[]){v_c_2424});
    }
    case TAG_IApp: {
      V v_h_2433 = heff_field(v_n1_27_241, 0);
      V v_args_2434 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2435 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_h_2433)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9, 2, 3, (V[]){v_c_2435, v_h_2433, v_args_2434});
    }
    case TAG_IAnn: {
      V v_n0_2443 = heff_field(v_n1_27_241, 0);
      V v_n1_2444 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2445 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n0_2443));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11, 2, 2, (V[]){v_c_2445, v_n1_2444});
    }
    case TAG_ISpec: {
      V v_n0_2452 = heff_field(v_n1_27_241, 0);
      V v_x_2453 = heff_field(v_n1_27_241, 1);
      V v_v_2455 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 11ULL, 4);
      heff_drop(v_sp_242);
      V v_c_2456 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_v_2455));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14, 2, 4, (V[]){v_c_2456, v_n0_2452, v_n_240, v_x_2453});
    }
    case TAG_IAnnLam: {
      V v_x_2466 = heff_field(v_n1_27_241, 0);
      V v_tyN_2468 = heff_field(v_n1_27_241, 2);
      V v_body_2469 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 13ULL, 4);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2470 = ({ V a_0 = v_tyN_2468; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2468); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17, 2, 3, (V[]){v_c_2470, v_body_2469, v_x_2466});
    }
    case TAG_IInvalid: {
      V v_code_2477 = heff_field(v_n1_27_241, 0);
      V v_why_2478 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20, 2, 3, (V[]){v_code_2477, v_why_2478, v_sp_242});
    }
    case TAG_INominal: {
      V v_i_2485 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2486 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_2485));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21, 2, 1, (V[]){v_c_2486});
    }
    case TAG_ILitEq: {
      V v_x_2491 = heff_field(v_n1_27_241, 0);
      V v_xsp_2492 = heff_field(v_n1_27_241, 1);
      V v_eq_2493 = heff_field(v_n1_27_241, 2);
      V v_lit_2494 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 15ULL, 4);
      heff_drop_tag(v_n_240, 2);
      V v_c_2495 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_lit_2494));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23, 2, 5, (V[]){v_c_2495, v_sp_242, v_x_2491, v_xsp_2492, v_eq_2493});
    }
    default: return heff_nomatch(v_n1_27_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(a[0]);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V v_t_246 = (g_heff_2eelab_2erules_2efind(v_sp_242, v_x_243));
  V f_ = v_k_245;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_i_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_t_2410 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_n(TAG_IntNum, 1, (V[]){v_i_247})));
  V f_ = v_k_249;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2412);
  V v_t_2414 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_n(TAG_FracNum, 1, (V[]){v_x_2411})));
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args) {
  V v_u_2421 = args[0];
  heff_drop(v_u_2421);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args) {
  V v_e_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2418);
  heff_drop(v_hd_2419);
  V v_t_2422 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_s_2415}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo)});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, NTAG(TAG_VPrimString)});
  V f_ = v_k_2420;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4, 3, 1, (V[]){v_s_2415})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args) {
  V v_u_2430 = args[0];
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args) {
  V v_e_2427 = args[0];
  V v_hd_2428 = args[1];
  V v_k_2429 = args[2];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2427);
  heff_drop(v_hd_2428);
  V v_t_2431 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitRune, 1, (V[]){v_c_2424}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8_clo)});
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, NTAG(TAG_VPrimRune)});
  V f_ = v_k_2429;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7, 3, 1, (V[]){v_c_2424})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args) {
  V v_x_2438 = args[0];
  V v_h_2433 = heff_env(self)[0];
  V v_args_2434 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2441;
  switch (heff_tag_of(v_h_2433)) {
  case TAG_At: {
    V v_s_2440 = heff_field(v_h_2433, 1);
    heff_take_n(v_h_2433, 2ULL, 2);
    v_t_2441 = v_s_2440;
    break;
  }
  default: heff_nomatch(v_h_2433);
  }
  V v_c_2442 = ({ V a_0 = heff_get_n(v_t_2441, 0, 2); V a_1 = v_x_2438; V a_2 = v_args_2434; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_args_2434); r_; });
  V f_ = v_c_2442;
  heff_room[0] = v_hd_2436;
  heff_room[1] = v_k_2437;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_h_2433 = heff_env(self)[1];
  V v_args_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10, 1, 4, (V[]){v_h_2433, v_args_2434, v_hd_2436, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args) {
  V v_x_2450 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_k_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = ({ V a_0 = v_x_2450; V a_1 = v_x_2448; V r_ = (g_heff_2eelab_2erules_2eannot(a_0, a_1)); heff_drop(v_x_2450); heff_drop(v_x_2448); r_; });
  V f_ = v_k_2447;
  args[0] = v_t_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args) {
  V v_x_2448 = args[0];
  V v_n1_2444 = heff_env(self)[0];
  V v_hd_2446 = heff_env(self)[1];
  V v_k_2447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2449 = ({ V a_0 = v_n1_2444; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n1_2444); r_; });
  V f_ = v_c_2449;
  heff_room[0] = v_hd_2446;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13, 1, 2, (V[]){v_x_2448, v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_c_2445 = heff_env(self)[0];
  V v_n1_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2445;
  args[0] = heff_dup(v_hd_2446);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12, 1, 3, (V[]){v_n1_2444, v_hd_2446, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args) {
  V v_x_2461 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2453 = heff_env(self)[1];
  V v_x_2459 = heff_env(self)[2];
  V v_k_2458 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2464;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2463 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2464 = v_s_2463;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2465 = ({ V a_0 = v_t_2464; V a_1 = v_x_2461; V a_2 = v_x_2453; V a_3 = v_x_2459; V r_ = (g_heff_2eelab_2erules_2erecordSpec(a_0, a_1, a_2, a_3)); heff_drop(v_x_2461); heff_drop(v_x_2459); r_; });
  V f_ = v_k_2458;
  args[0] = v_x_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args) {
  V v_x_2459 = args[0];
  V v_n0_2452 = heff_env(self)[0];
  V v_hd_2457 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2453 = heff_env(self)[3];
  V v_k_2458 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2460 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_2452));
  V f_ = v_c_2460;
  heff_room[0] = v_hd_2457;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16, 1, 4, (V[]){v_n_240, v_x_2453, v_x_2459, v_k_2458});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_c_2456 = heff_env(self)[0];
  V v_n0_2452 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2453 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2456;
  args[0] = heff_dup(v_hd_2457);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15, 1, 5, (V[]){v_n0_2452, v_hd_2457, v_n_240, v_x_2453, v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args) {
  V v_x_2475 = args[0];
  V v_x_2466 = heff_env(self)[0];
  V v_x_2473 = heff_env(self)[1];
  V v_k_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2476 = ({ V a_0 = v_x_2466; V a_1 = v_x_2473; V a_2 = v_x_2475; V r_ = (g_heff_2eelab_2erules_2efunctionIntroSyn(a_0, a_1, a_2)); heff_drop(v_x_2473); heff_drop(v_x_2475); r_; });
  V f_ = v_k_2472;
  args[0] = v_t_2476;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args) {
  V v_x_2473 = args[0];
  V v_body_2469 = heff_env(self)[0];
  V v_hd_2471 = heff_env(self)[1];
  V v_x_2466 = heff_env(self)[2];
  V v_k_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2474 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_body_2469));
  V f_ = v_c_2474;
  heff_room[0] = v_hd_2471;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19, 1, 3, (V[]){v_x_2466, v_x_2473, v_k_2472});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  V v_body_2469 = heff_env(self)[1];
  V v_x_2466 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2470;
  args[0] = heff_dup(v_hd_2471);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18, 1, 4, (V[]){v_body_2469, v_hd_2471, v_x_2466, v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k2_2480 = args[1];
  V v_code_2477 = heff_env(self)[0];
  V v_why_2478 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_2477), NTAG(TAG_SError), v_why_2478, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_2479, 2), 1, (V[]){v_t_2483}));
  V f_ = heff_get_n(v_hd_2479, 1, 3);
  args[0] = v_t_2484;
  args[1] = v_k2_2480;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args) {
  V v_x_2489 = args[0];
  V v_k_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2490 = ({ V a_0 = v_x_2489; V r_ = (g_heff_2eelab_2etoplevel_2enominalSyn(a_0)); heff_drop(v_x_2489); r_; });
  V f_ = v_k_2488;
  args[0] = v_t_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k_2488 = args[1];
  V v_c_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2486;
  args[0] = v_hd_2487;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22, 1, 1, (V[]){v_k_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args) {
  V v_x_2498 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2491 = heff_env(self)[1];
  V v_xsp_2492 = heff_env(self)[2];
  V v_eq_2493 = heff_env(self)[3];
  V v_k_2497 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = ({ V a_0 = v_sp_242; V a_1 = v_x_2491; V a_2 = v_xsp_2492; V a_3 = v_eq_2493; V a_4 = v_x_2498; V r_ = (g_heff_2eelab_2erules_2elitEq(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2498); r_; });
  V f_ = v_k_2497;
  args[0] = v_t_2499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k_2497 = args[1];
  V v_c_2495 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2491 = heff_env(self)[2];
  V v_xsp_2492 = heff_env(self)[3];
  V v_eq_2493 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2495;
  args[0] = v_hd_2496;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24, 1, 5, (V[]){v_sp_242, v_x_2491, v_xsp_2492, v_eq_2493, v_k_2497});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V v_i_240) {
top: ;
  V v_x1_2427;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_i1_241, 0ULL, 2);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 2);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    case TAG_INominal: {
      V v_i11_2422 = heff_field(v_i1_241, 0);
      heff_take_n(v_i1_241, 1ULL, 1);
      v_x1_2427 = v_i11_2422;
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      v_x1_2427 = heff_dup(v_i_240);
      break;
    }
    default: heff_nomatch(v_i1_241);
    }
    break;
  }
  default: heff_nomatch(v_i_240);
  }
  V v_t_2454;
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_At: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInt: {
      V v_k_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24IInt = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      v_t_2454 = heff_tag_at_n(v_ru_24x11_2428_24IInt, TAG_Just, 1, (V[]){heff_tag_n(TAG_IntNum, 1, (V[]){v_k_2431})});
      break;
    }
    case TAG_IFloat: {
      V v_x_2432 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24IFloat = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      v_t_2454 = heff_tag_at_n(v_ru_24x11_2428_24IFloat, TAG_Just, 1, (V[]){heff_tag_n(TAG_FracNum, 1, (V[]){v_x_2432})});
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2428, 0ULL, 2);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2428, 0ULL, 2);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2428, 0ULL, 4);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2428, 0ULL, 4);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2428, 0ULL, 2);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_INominal: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2428, 0ULL, 4);
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2428);
    }
    break;
  }
  default: heff_nomatch(v_x1_2427);
  }
  switch (heff_tag_of(v_t_2454)) {
  case TAG_Nothing: {
    V v_c_2455 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_240)));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0, 2, 2, (V[]){v_c_2455, v_i_240});
  }
  case TAG_Just: {
    V v_lit_2461 = heff_field(v_t_2454, 0);
    heff_take_n(v_t_2454, 1ULL, 1);
    V v_t_2488;
    switch (heff_tag_of(v_i_240)) {
    case TAG_At: {
      V v_x11_2462 = heff_dup(heff_field(v_i_240, 0));
      switch (heff_tag_of(v_x11_2462)) {
      case TAG_IVar: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IFloat: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IString: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_x11_2462, 0ULL, 2);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_x11_2462, 0ULL, 2);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_x11_2462, 0ULL, 4);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_x11_2462, 0ULL, 4);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_x11_2462, 0ULL, 2);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_x11_2462, 0ULL, 1);
        v_t_2488 = NTAG(TAG_True);
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_x11_2462, 0ULL, 4);
        v_t_2488 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2462);
      }
      break;
    }
    default: heff_nomatch(v_i_240);
    }
    V v_t_2496;
    switch (heff_tag_of(v_t_2488)) {
    case TAG_True: {
      V v_t_2491;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_2490 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_2491 = v_s_2490;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      V v_t_2492 = (g_heff_2eelab_2erules_2enumLitChk(v_t_2491, v_lit_2461));
      v_t_2496 = ({ V a_0 = v_t_2492; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_t_2492); r_; });
      break;
    }
    case TAG_False: {
      V v_t_2495;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_2494 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_2495 = v_s_2494;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      v_t_2496 = (g_heff_2eelab_2erules_2enumLitChk(v_t_2495, v_lit_2461));
      break;
    }
    default: heff_nomatch(v_t_2488);
    }
    V v_x_2497 = ({ V a_0 = v_t_2496; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2496); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2, 2, 1, (V[]){v_x_2497});
  }
  default: return heff_nomatch(v_t_2454);
  }
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args) {
  V v_x_2458 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = ({ V a_0 = v_i_240; V a_1 = v_x_2458; V r_ = (g_heff_2eelab_2etoplevel_2echkHeadOf(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V v_x_2460 = ({ V a_0 = v_t_2459; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2459); r_; });
  V f_ = v_k_2457;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_i_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1, 1, 2, (V[]){v_i_240, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k_2499 = args[1];
  V v_x_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2498);
  V f_ = v_k_2499;
  args[0] = v_x_2497;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0, 48, "expected a field declaration of the form `x : A`");
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2, 2, 0};
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_c_247 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0, 2, 3, (V[]){v_c_247, heff_dup(v_d_246), heff_dup(v_x_243)});
    }
    case TAG_BadFieldDecl: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_c_2413)) {
  case TAG_At: {
    V v_s_2419 = heff_field(v_c_2413, 1);
    heff_take_n(v_c_2413, 2ULL, 2);
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_c_2413);
  }
  V v_x_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2417, v_t_2420})});
  V f_ = v_k_2416;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2414, v_hd_2415, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4, 1, 2, (V[]){v_c_2413, v_k_2416})));
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_249;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_243, v_x_2410, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2422;
  switch (heff_tag_of(v_d_246)) {
  case TAG_Nothing: {
    v_c_2422 = ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_d_246, 0);
    heff_take_n(v_d_246, 1ULL, 1);
    V v_t_2414 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2413)));
    v_c_2422 = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3, 2, 2, (V[]){v_t_2414, v_c_2413});
    break;
  }
  default: heff_nomatch(v_d_246);
  }
  V f_ = v_c_2422;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5, 1, 3, (V[]){v_k_249, v_x_243, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1, 1, 4, (V[]){v_d_246, v_hd_248, v_k_249, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_2425, 2), 1, (V[]){v_t_2429}));
  V f_ = heff_get_n(v_hd_2425, 1, 3);
  args[0] = v_t_2430;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V v_sp_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_t1_242 = heff_field(v_t_241, 0);
    switch (heff_tag_of(v_t1_242)) {
    case TAG_TPi: {
      V v_c_246 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0, 2, 2, (V[]){v_c_246, v_sp_240});
    }
    case TAG_TSig: {
      V v_fields_2411 = heff_field(v_t1_242, 0);
      V v_c_2412 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(heff_dup(v_fields_2411)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2, 2, 2, (V[]){v_c_2412, v_sp_240});
    }
    case TAG_TSum: {
      V v_c_2418 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4, 2, 2, (V[]){v_c_2418, v_sp_240});
    }
    case TAG_TType: {
      V v_c_2423 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6, 2, 2, (V[]){v_c_2423, v_sp_240});
    }
    case TAG_TInt: {
      V v_c_2428 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8, 2, 2, (V[]){v_c_2428, v_sp_240});
    }
    case TAG_TFloat: {
      V v_c_2433 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10, 2, 2, (V[]){v_c_2433, v_sp_240});
    }
    case TAG_TString: {
      V v_c_2438 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12, 2, 2, (V[]){v_c_2438, v_sp_240});
    }
    case TAG_TRune: {
      V v_c_2443 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14, 2, 2, (V[]){v_c_2443, v_sp_240});
    }
    case TAG_TArray: {
      V v_c_2449 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16, 2, 2, (V[]){v_c_2449, v_sp_240});
    }
    case TAG_TFixed: {
      V v_c_2455 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18, 2, 2, (V[]){v_c_2455, v_sp_240});
    }
    case TAG_TInf: {
      V v_c_2461 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20, 2, 2, (V[]){v_c_2461, v_sp_240});
    }
    case TAG_TChk: {
      V v_c_2467 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22, 2, 2, (V[]){v_c_2467, v_sp_240});
    }
    case TAG_TNominal: {
      V v_c_2473 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_241));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24, 2, 2, (V[]){v_c_2473, v_sp_240});
    }
    default: return heff_nomatch(v_t1_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V a_0 = v_sp_240; V a_1 = v_x_249; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_249); r_; });
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam1, 1, 2, (V[]){v_sp_240, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = (g_heff_2eelab_2erules_2erecordTypeIntro(v_sp_240, v_x_2415));
  V f_ = v_k_2414;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam3, 1, 2, (V[]){v_sp_240, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = ({ V a_0 = v_sp_240; V a_1 = v_x_2421; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2421); r_; });
  V f_ = v_k_2420;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam5, 1, 2, (V[]){v_sp_240, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = ({ V a_0 = v_sp_240; V a_1 = v_x_2426; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2426); r_; });
  V f_ = v_k_2425;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam7, 1, 2, (V[]){v_sp_240, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9(V self, V *args) {
  V v_x_2431 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = ({ V a_0 = v_sp_240; V a_1 = v_x_2431; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2431); r_; });
  V f_ = v_k_2430;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam8(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam9, 1, 2, (V[]){v_sp_240, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11(V self, V *args) {
  V v_x_2436 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = ({ V a_0 = v_sp_240; V a_1 = v_x_2436; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2436); r_; });
  V f_ = v_k_2435;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam10(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2433;
  args[0] = v_hd_2434;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam11, 1, 2, (V[]){v_sp_240, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13(V self, V *args) {
  V v_x_2441 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = ({ V a_0 = v_sp_240; V a_1 = v_x_2441; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2441); r_; });
  V f_ = v_k_2440;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam12(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam13, 1, 2, (V[]){v_sp_240, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15(V self, V *args) {
  V v_x_2446 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2447 = ({ V a_0 = v_sp_240; V a_1 = v_x_2446; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2446); r_; });
  V f_ = v_k_2445;
  args[0] = v_t_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam14(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2443;
  args[0] = v_hd_2444;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam15, 1, 2, (V[]){v_sp_240, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17(V self, V *args) {
  V v_x_2452 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2453 = ({ V a_0 = v_sp_240; V a_1 = v_x_2452; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2452); r_; });
  V f_ = v_k_2451;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam16(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2449;
  args[0] = v_hd_2450;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam17, 1, 2, (V[]){v_sp_240, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19(V self, V *args) {
  V v_x_2458 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = ({ V a_0 = v_sp_240; V a_1 = v_x_2458; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2458); r_; });
  V f_ = v_k_2457;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam18(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam19, 1, 2, (V[]){v_sp_240, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21(V self, V *args) {
  V v_x_2464 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = ({ V a_0 = v_sp_240; V a_1 = v_x_2464; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2464); r_; });
  V f_ = v_k_2463;
  args[0] = v_t_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam20(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2461;
  args[0] = v_hd_2462;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam21, 1, 2, (V[]){v_sp_240, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23(V self, V *args) {
  V v_x_2470 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2469 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471 = ({ V a_0 = v_sp_240; V a_1 = v_x_2470; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2470); r_; });
  V f_ = v_k_2469;
  args[0] = v_t_2471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam22(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_c_2467 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2467;
  args[0] = v_hd_2468;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam23, 1, 2, (V[]){v_sp_240, v_k_2469});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25(V self, V *args) {
  V v_x_2476 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_k_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2477 = ({ V a_0 = v_sp_240; V a_1 = v_x_2476; V r_ = (g_heff_2eelab_2erules_2euniverseIntro(a_0, a_1)); heff_drop(v_x_2476); r_; });
  V f_ = v_k_2475;
  args[0] = v_t_2477;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam24(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  V v_c_2473 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2473;
  args[0] = v_hd_2474;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_lam25, 1, 2, (V[]){v_sp_240, v_k_2475});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1, 2, 2, (V[]){v_t_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_t_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_245, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247})));
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_str0, 44, "expected a field setting of the form `x = v`");
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_e_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0, 2, 4, (V[]){v_t_246, heff_dup(v_e_245), heff_dup(v_x_243), heff_dup(v_xsp_244)});
    }
    case TAG_BadFieldSet: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_xsp_244 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412;
  switch (heff_tag_of(v_e_245)) {
  case TAG_At: {
    V v_s_2411 = heff_field(v_e_245, 1);
    heff_take_n(v_e_245, 2ULL, 2);
    v_t_2412 = v_s_2411;
    break;
  }
  default: heff_nomatch(v_e_245);
  }
  V v_x_2413 = heff_rec_n(4, shape_name__chk__span__nameSpan, (V[]){v_x_243, v_x_249, v_t_2412, v_xsp_244});
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_246 = heff_env(self)[0];
  V v_e_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_xsp_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_246, v_hd_247, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam1, 1, 4, (V[]){v_e_245, v_x_243, v_xsp_244, v_k_248})));
}
V g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(202LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_2415, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2415, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2efieldSetF_24s1198185905x524196569(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_body_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2edoPat(v_p_243));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0, 2, 2, (V[]){v_c_245, v_body_244});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_xs_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_xs_2410), v_x_2412});
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_body_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x_248, 0);
    V v_xs_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_244));
    return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2411, v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2, 1, 3, (V[]){v_xs_2410, v_k_247, v_x_249})));
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1, 1, 3, (V[]){v_body_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V v_f_240, V v_eqs_241, V v_sp_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(v_eqs_241));
  V v_t_244;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242});
  }
  case TAG_False: {
    V v_t_2438 = (g_heff_2eelab_2eclauses_2edesugar(v_f_240, NTAG(TAG_Nil), v_eqs_241, v_sp_242));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Left: {
      V v_err_2439 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10, 2, 1, (V[]){v_err_2439});
    }
    case TAG_Right: {
      V v_b_2446 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2446));
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_247, 1, 6), v_m_2416));
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_fsp_2413 = heff_env(self)[1];
  V v_rhs_2415 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2412, v_fsp_2413, v_x_2420, v_rhs_2415}), v_sp_2411});
  V f_ = v_k_2419;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_fsp_2413 = heff_env(self)[2];
  V v_rhs_2415 = heff_env(self)[3];
  V v_sp_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5, 1, 5, (V[]){v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args) {
  V v_m_249 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_249)) {
  case TAG_At: {
    V v_x21_2410 = heff_field(v_m_249, 0);
    V v_sp_2411 = heff_field(v_m_249, 1);
    heff_take_n(v_m_249, 3ULL, 2);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkEquation: {
      V v_f_2412 = heff_field(v_x21_2410, 0);
      V v_fsp_2413 = heff_field(v_x21_2410, 1);
      V v_ps_2414 = heff_field(v_x21_2410, 2);
      V v_rhs_2415 = heff_field(v_x21_2410, 3);
      heff_take_n(v_x21_2410, 15ULL, 4);
      V v_c_2417 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3, 1, 1, (V[]){v_e_247}), v_ps_2414));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4, 2, 5, (V[]){v_c_2417, v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_m_249);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k2_2429 = args[1];
  V v_err_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_2427, 1), heff_get_n(v_err_2427, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_2428, 2), 1, (V[]){v_t_2432}));
  V f_ = heff_get_n(v_hd_2428, 1, 3);
  args[0] = v_t_2433;
  args[1] = v_k2_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_e_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkChk: {
    V v_f_2437 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    V f_ = v_f_2437;
    heff_room[0] = v_e_247;
    heff_room[1] = v_a_248;
    heff_room[2] = v_hd_2423;
    heff_room[3] = v_k_2424;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426 = (g_heff_2eelab_2eclauses_2edesugar(v_f_240, NTAG(TAG_Nil), v_x_2425, v_sp_242));
  V v_c_2435;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Left: {
    V v_err_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_c_2435 = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8, 2, 1, (V[]){v_err_2427});
    break;
  }
  case TAG_Right: {
    V v_b_2434 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_c_2435 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2434));
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V f_ = v_c_2435;
  heff_room[0] = heff_dup(v_hd_2423);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9, 1, 4, (V[]){v_e_247, v_a_248, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7, 1, 6, (V[]){v_f_240, v_sp_242, v_hd_2423, v_e_247, v_a_248, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args) {
  V v_e_247 = args[0];
  V v_a_248 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2422 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2, 1, 1, (V[]){heff_dup(v_e_247)}), v_eqs_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6, 2, 5, (V[]){v_c_2422, v_f_240, v_sp_242, v_e_247, v_a_248});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_err_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_2439, 1), heff_get_n(v_err_2439, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_call(heff_take_field(v_hd_2440, 2), 1, (V[]){v_t_2444}));
  V f_ = heff_get_n(v_hd_2440, 1, 3);
  args[0] = v_t_2445;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4, 40, "unexpected notation for local definition");
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V v_x2_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_241));
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_240, 0);
    V v_ds_243 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_d_242)) {
    case TAG_At: {
      V v_x_244 = heff_field(v_d_242, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_DeclEquations: {
      V v_name_247 = heff_field(v_t_246, 0);
      V v_tyN_2410 = heff_field(v_t_246, 3);
      V v_eqs_2411 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 25ULL, 5);
      V v_c_2412 = ({ V a_0 = v_tyN_2410; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2410); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0, 2, 6, (V[]){v_c_2412, heff_dup(v_d_242), v_name_247, v_eqs_2411, heff_dup(v_ds_243), v_body_241});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_246, 0ULL, 5);
      heff_drop(v_body_241);
      V v_sp_2431;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_d_242, 1);
        v_sp_2431 = heff_dup(v_s_2430);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4, 2, 1, (V[]){v_sp_2431});
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_body_241);
      V v_sp_2444;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_d_242, 1);
        v_sp_2444 = heff_dup(v_s_2443);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5, 2, 1, (V[]){v_sp_2444});
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_body_241);
      V v_sp_2456;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2455 = heff_field(v_d_242, 1);
        v_sp_2456 = heff_dup(v_s_2455);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6, 2, 1, (V[]){v_sp_2456});
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_body_241);
      V v_sp_2467;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2466 = heff_field(v_d_242, 1);
        v_sp_2467 = heff_dup(v_s_2466);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7, 2, 1, (V[]){v_sp_2467});
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_body_241);
      V v_sp_2477;
      switch (heff_tag_of(v_d_242)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_d_242, 1);
        v_sp_2477 = heff_dup(v_s_2476);
        break;
      }
      default: heff_nomatch(v_d_242);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8, 2, 1, (V[]){v_sp_2477});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = ({ V a_0 = v_name_247; V a_1 = v_x_2415; V a_2 = v_x_2420; V a_3 = v_x_2422; V r_ = (g_heff_2eelab_2erules_2elocalDef(a_0, a_1, a_2, a_3)); heff_drop(v_x_2415); heff_drop(v_x_2420); heff_drop(v_x_2422); r_; });
  V f_ = v_k_2414;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ds_243 = heff_env(self)[0];
  V v_body_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_name_247 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2421 = ({ V a_0 = v_ds_243; V a_1 = v_body_241; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_ds_243); r_; });
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3, 1, 4, (V[]){v_name_247, v_x_2415, v_x_2420, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_name_247 = heff_env(self)[1];
  V v_eqs_2411 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2417 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_c_2419 = (g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(heff_dup(v_name_247), v_eqs_2411, v_t_2418));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2, 1, 6, (V[]){v_ds_243, v_body_241, v_hd_2413, v_name_247, v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_name_247 = heff_env(self)[2];
  V v_eqs_2411 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1, 1, 7, (V[]){v_d_242, v_name_247, v_eqs_2411, v_hd_2413, v_ds_243, v_body_241, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_sp_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0), v_sp_2431, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k2_2446 = args[1];
  V v_sp_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1), v_sp_2444, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_2445, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2445, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2446;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_sp_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2), v_sp_2456, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_2457, 2), 1, (V[]){v_t_2461}));
  V f_ = heff_get_n(v_hd_2457, 1, 3);
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k2_2469 = args[1];
  V v_sp_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3), v_sp_2467, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_call(heff_take_field(v_hd_2468, 2), 1, (V[]){v_t_2472}));
  V f_ = heff_get_n(v_hd_2468, 1, 3);
  args[0] = v_t_2473;
  args[1] = v_k2_2469;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_sp_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4), v_sp_2477, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_2478, 2), 1, (V[]){v_t_2482}));
  V f_ = heff_get_n(v_hd_2478, 1, 3);
  args[0] = v_t_2483;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0, 2, "it");
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_n2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CType: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CLam: {
      V v_x_245 = heff_field(v_n1_241, 0);
      V v_body_247 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      heff_drop(v_n2_242);
      V v_t_248 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_247));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0, 2, 3, (V[]){v_t_248, v_n_240, v_x_245});
    }
    case TAG_CImplicitLam: {
      V v_x_2416 = heff_field(v_n1_241, 0);
      V v_body_2418 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      heff_drop(v_n2_242);
      V v_t_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2418));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2, 2, 3, (V[]){v_t_2419, v_n_240, v_x_2416});
    }
    case TAG_CAnnLam: {
      V v_x_2427 = heff_field(v_n1_241, 0);
      V v_tyN_2429 = heff_field(v_n1_241, 2);
      V v_body_2430 = heff_field(v_n1_241, 3);
      heff_take_n(v_n1_241, 13ULL, 4);
      heff_drop(v_n2_242);
      V v_c_2431 = ({ V a_0 = v_tyN_2429; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2429); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4, 2, 4, (V[]){v_c_2431, v_body_2430, v_n_240, v_x_2427});
    }
    case TAG_CTag: {
      V v_x_2441 = heff_field(v_n1_241, 0);
      V v_tsp_2442 = heff_field(v_n1_241, 1);
      V v_args_2443 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 7ULL, 3);
      heff_drop(v_n2_242);
      V v_c_2444 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(v_args_2443));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7, 2, 4, (V[]){v_c_2444, v_n_240, v_tsp_2442, v_x_2441});
    }
    case TAG_CStruct: {
      V v_fields_2452 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      V v_c_2453 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(v_fields_2452));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9, 2, 2, (V[]){v_c_2453, v_n2_242});
    }
    case TAG_CMatch: {
      V v_scrutN_2458 = heff_field(v_n1_241, 0);
      V v_casesN_2459 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      V v_x1_2460 = (g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(v_casesN_2459));
      V v_t_2461;
      switch (heff_tag_of(v_x1_2460)) {
      case TAG_True: {
        v_t_2461 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2461 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_2460);
      }
      switch (heff_tag_of(v_t_2461)) {
      case TAG_True: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11, 2, 3, (V[]){v_casesN_2459, v_scrutN_2458, v_n2_242});
      }
      case TAG_False: {
        V v_t_2484 = (g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(v_casesN_2459));
        V v_t_2486;
        switch (heff_tag_of(v_t_2484)) {
        case TAG_True: {
          V v_x1_2485 = (g_heff_2eelab_2etoplevel_2eannotatesData(v_scrutN_2458));
          switch (heff_tag_of(v_x1_2485)) {
          case TAG_True: {
            v_t_2486 = NTAG(TAG_False);
            break;
          }
          case TAG_False: {
            v_t_2486 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x1_2485);
          }
          break;
        }
        case TAG_False: {
          v_t_2486 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2484);
        }
        switch (heff_tag_of(v_t_2486)) {
        case TAG_True: {
          V v_c_2487 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_2458));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19, 2, 3, (V[]){v_c_2487, v_casesN_2459, v_n2_242});
        }
        case TAG_False: {
          V v_x1_2499 = (g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(v_casesN_2459));
          V v_t_24104;
          switch (heff_tag_of(v_x1_2499)) {
          case TAG_Left: {
            V v_e_24100 = heff_field(v_x1_2499, 0);
            V v_ru_24x1_2499_24Left = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
            heff_drop(v_n2_242);
            v_t_24104 = heff_tag_at_n(v_ru_24x1_2499_24Left, TAG_Left, 1, (V[]){v_e_24100});
            break;
          }
          case TAG_Right: {
            V v_x_24101 = heff_field(v_x1_2499, 0);
            heff_take_n(v_x1_2499, 1ULL, 1);
            V v_used_24102 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_24101, NTAG(TAG_Nil)));
            V v_t_24103 = (g_heff_2eelab_2eclauses_2efresh(v_used_24102, ((V)&g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0)));
            v_t_24104 = (g_heff_2eelab_2eclauses_2ecaseTreeOf(v_n2_242, v_x_24101, v_used_24102, v_t_24103));
            break;
          }
          default: heff_nomatch(v_x1_2499);
          }
          switch (heff_tag_of(v_t_24104)) {
          case TAG_Left: {
            V v_err_24105 = heff_field(v_t_24104, 0);
            heff_take_n(v_t_24104, 1ULL, 1);
            heff_drop(v_scrutN_2458);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22, 2, 1, (V[]){v_err_24105});
          }
          case TAG_Right: {
            V v_r_24112 = heff_field(v_t_24104, 0);
            heff_take_n(v_t_24104, 1ULL, 1);
            V v_c_24113 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_2458));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23, 2, 2, (V[]){v_c_24113, v_r_24112});
          }
          default: return heff_nomatch(v_t_24104);
          }
        }
        default: return heff_nomatch(v_t_2486);
        }
      }
      default: return heff_nomatch(v_t_2461);
      }
    }
    case TAG_CLetIn: {
      V v_rhsN_24120 = heff_field(v_n1_241, 0);
      V v_alt0_24121 = heff_field(v_n1_241, 1);
      V v_ru_24n1_241_24CLetIn = heff_take_reuse_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      switch (heff_tag_of(v_alt0_24121)) {
      case TAG_At: {
        V v_it1_24122 = heff_dup(heff_field(v_alt0_24121, 0));
        switch (heff_tag_of(v_it1_24122)) {
        case TAG_MkAlt: {
          V v_it11_24124 = heff_field(v_it1_24122, 0);
          V v_bodyN_24125 = heff_field(v_it1_24122, 1);
          V v_ru_24it1_24122_24MkAlt = heff_take_reuse_n(v_it1_24122, 3ULL, 2);
          switch (heff_tag_of(v_it11_24124)) {
          case TAG_At: {
            V v_it111_24126 = heff_field(v_it11_24124, 0);
            heff_take_n(v_it11_24124, 1ULL, 2);
            switch (heff_tag_of(v_it111_24126)) {
            case TAG_PatVar: {
              V v_x_24128 = heff_field(v_it111_24126, 0);
              heff_take_n(v_it111_24126, 1ULL, 1);
              heff_drop(v_n2_242);
              heff_drop_tag(v_alt0_24121, 2);
              heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
              heff_drop_cell(v_ru_24it1_24122_24MkAlt, 2);
              V v_c_24129 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_rhsN_24120));
              return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26, 2, 3, (V[]){v_c_24129, v_bodyN_24125, v_x_24128});
            }
            case TAG_PatTag: {
              heff_take_n(v_it111_24126, 0ULL, 3);
              heff_drop(v_bodyN_24125);
              V v_t_24139 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24140 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24139}), v_n2_242});
              V t_0 = v_t_24140;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatOp: {
              heff_take_n(v_it111_24126, 0ULL, 3);
              heff_drop(v_bodyN_24125);
              V v_t_24144 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24145 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24144}), v_n2_242});
              V t_0 = v_t_24145;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatInt: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24147 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24148 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24147}), v_n2_242});
              V t_0 = v_t_24148;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatFloat: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24150 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24151 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24150}), v_n2_242});
              V t_0 = v_t_24151;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatString: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24153 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24154 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24153}), v_n2_242});
              V t_0 = v_t_24154;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatRune: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24156 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24157 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24156}), v_n2_242});
              V t_0 = v_t_24157;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatRecord: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24159 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24160 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24159}), v_n2_242});
              V t_0 = v_t_24160;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatWord: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24162 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24163 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24162}), v_n2_242});
              V t_0 = v_t_24163;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatAs: {
              heff_take_n(v_it111_24126, 0ULL, 3);
              heff_drop(v_bodyN_24125);
              V v_t_24167 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24168 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24167}), v_n2_242});
              V t_0 = v_t_24168;
              v_n_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_it111_24126);
            }
          }
          default: return heff_nomatch(v_it11_24124);
          }
        }
        default: return heff_nomatch(v_it1_24122);
        }
      }
      default: return heff_nomatch(v_alt0_24121);
      }
    }
    case TAG_CLocal: {
      V v_bodyN_24169 = heff_field(v_n1_241, 0);
      V v_defs_24170 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      return ({ V a_0 = v_defs_24170; V a_1 = v_bodyN_24169; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_defs_24170); r_; });
    }
    case TAG_CAbandon: {
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29, 2, 1, (V[]){v_n2_242});
    }
    case TAG_CNominal: {
      V v_c_24174 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      V v_c_24175 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_c_24174));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30, 2, 1, (V[]){v_c_24175});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(a[0]);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2413 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = v_x_245; V a_2 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  V f_ = v_k_2410;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_248, v_hd_249, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1, 1, 3, (V[]){v_n_240, v_x_245, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2424 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2425 = v_s_2424;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2416; V a_2 = v_x_2422; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_x_2422); r_; });
  V f_ = v_k_2421;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3, 1, 3, (V[]){v_n_240, v_x_2416, v_k_2421})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_k_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2438 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2439 = v_s_2438;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2440 = ({ V a_0 = v_t_2439; V a_1 = v_x_2427; V a_2 = v_x_2434; V a_3 = v_x_2436; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2434); heff_drop(v_x_2436); r_; });
  V f_ = v_k_2433;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_body_2430 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2435 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2430));
  V f_ = v_c_2435;
  heff_room[0] = v_hd_2432;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6, 1, 4, (V[]){v_n_240, v_x_2427, v_x_2434, v_k_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_body_2430 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5, 1, 5, (V[]){v_body_2430, v_hd_2432, v_n_240, v_x_2427, v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_tsp_2442 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_k_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2450;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2449 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2451 = (g_heff_2eelab_2erules_2esumIntro(v_t_2450, v_tsp_2442, v_x_2441, v_x_2447));
  V f_ = v_k_2446;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_tsp_2442 = heff_env(self)[2];
  V v_x_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2444;
  args[0] = v_hd_2445;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8, 1, 4, (V[]){v_n_240, v_tsp_2442, v_x_2441, v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args) {
  V v_x_2456 = args[0];
  V v_n2_242 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = (g_heff_2eelab_2erules_2erecordIntro(v_n2_242, v_x_2456));
  V f_ = v_k_2455;
  args[0] = v_t_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2453;
  args[0] = v_hd_2454;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10, 1, 2, (V[]){v_n2_242, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args) {
  V v_x_2474 = args[0];
  V v_body_2470 = heff_env(self)[0];
  V v_sp_2468 = heff_env(self)[1];
  V v_k_2473 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2474, v_body_2470}), v_sp_2468});
  V f_ = v_k_2473;
  args[0] = v_t_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_c_2471 = heff_env(self)[0];
  V v_body_2470 = heff_env(self)[1];
  V v_sp_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2471;
  args[0] = v_hd_2472;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15, 1, 3, (V[]){v_body_2470, v_sp_2468, v_k_2473});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args) {
  V v_m_2466 = args[0];
  V v_e_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2466)) {
  case TAG_At: {
    V v_x21_2467 = heff_field(v_m_2466, 0);
    V v_sp_2468 = heff_field(v_m_2466, 1);
    heff_take_n(v_m_2466, 3ULL, 2);
    switch (heff_tag_of(v_x21_2467)) {
    case TAG_MkAlt: {
      V v_p_2469 = heff_field(v_x21_2467, 0);
      V v_body_2470 = heff_field(v_x21_2467, 1);
      heff_take_n(v_x21_2467, 3ULL, 2);
      V v_c_2471 = (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2464, 1, 6), v_p_2469));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14, 2, 3, (V[]){v_c_2471, v_body_2470, v_sp_2468});
    }
    default: return heff_nomatch(v_x21_2467);
    }
  }
  default: return heff_nomatch(v_m_2466);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args) {
  V v_x_2482 = args[0];
  V v_e_2464 = heff_env(self)[0];
  V v_a_2465 = heff_env(self)[1];
  V v_hd_2477 = heff_env(self)[2];
  V v_k_2478 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2482)) {
  case TAG_MkChk: {
    V v_f_2483 = heff_field(v_x_2482, 0);
    heff_take_n(v_x_2482, 1ULL, 1);
    V f_ = v_f_2483;
    heff_room[0] = v_e_2464;
    heff_room[1] = v_a_2465;
    heff_room[2] = v_hd_2477;
    heff_room[3] = v_k_2478;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2482);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args) {
  V v_x_2479 = args[0];
  V v_scrutN_2458 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_2477 = heff_env(self)[2];
  V v_e_2464 = heff_env(self)[3];
  V v_a_2465 = heff_env(self)[4];
  V v_k_2478 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_scrutN_2458, v_x_2479}), v_n2_242});
  V v_c_2481 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_2480));
  V f_ = v_c_2481;
  heff_room[0] = heff_dup(v_hd_2477);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18, 1, 4, (V[]){v_e_2464, v_a_2465, v_hd_2477, v_k_2478});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_c_2476 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_2464 = heff_env(self)[3];
  V v_a_2465 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2476;
  args[0] = heff_dup(v_hd_2477);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17, 1, 6, (V[]){v_scrutN_2458, v_n2_242, v_hd_2477, v_e_2464, v_a_2465, v_k_2478});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args) {
  V v_e_2464 = args[0];
  V v_a_2465 = args[1];
  V v_casesN_2459 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2476 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13, 1, 1, (V[]){heff_dup(v_e_2464)}), v_casesN_2459));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16, 2, 5, (V[]){v_c_2476, v_scrutN_2458, v_n2_242, v_e_2464, v_a_2465});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_casesN_2459 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2462);
  V f_ = v_k_2463;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12, 2, 3, (V[]){v_casesN_2459, v_scrutN_2458, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args) {
  V v_x_2492 = args[0];
  V v_casesN_2459 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_x_2490 = heff_env(self)[2];
  V v_k_2489 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2493 = (g_heff_2eelab_2etoplevel_2etagSpans(v_casesN_2459));
  V v_t_2494 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2492)));
  V v_t_2495 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2492));
  V v_t_2496 = (g_list_2emap_24s1173914895x100384474(v_x_2492));
  V v_t_2497 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2494), v_t_2495, heff_arrayFromList(v_t_2496)});
  V v_x_2498 = ({ V a_0 = v_n2_242; V a_1 = v_x_2490; V a_2 = v_t_2493; V a_3 = v_t_2497; V r_ = (g_heff_2eelab_2erules_2esumElim(a_0, a_1, a_2, a_3)); heff_drop(v_x_2490); heff_drop(v_t_2493); r_; });
  V f_ = v_k_2489;
  args[0] = v_x_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args) {
  V v_x_2490 = args[0];
  V v_casesN_2459 = heff_env(self)[0];
  V v_hd_2488 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_k_2489 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2491 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(heff_dup(v_casesN_2459)));
  V f_ = v_c_2491;
  heff_room[0] = v_hd_2488;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21, 1, 4, (V[]){v_casesN_2459, v_n2_242, v_x_2490, v_k_2489});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_casesN_2459 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2487;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20, 1, 4, (V[]){v_casesN_2459, v_hd_2488, v_n2_242, v_k_2489});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k2_24107 = args[1];
  V v_err_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), heff_take_field(v_err_24105, 1), heff_get_n(v_err_24105, 0, 2), NTAG(TAG_Nothing)});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tr(heff_call(heff_take_field(v_hd_24106, 2), 1, (V[]){v_t_24110}));
  V f_ = heff_get_n(v_hd_24106, 1, 3);
  args[0] = v_t_24111;
  args[1] = v_k2_24107;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args) {
  V v_x_24118 = args[0];
  V v_r_24112 = heff_env(self)[0];
  V v_x_24116 = heff_env(self)[1];
  V v_k_24115 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24119 = ({ V a_0 = heff_get_n(v_r_24112, 0, 2); V a_1 = v_x_24116; V a_2 = v_x_24118; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24116); heff_drop(v_x_24118); r_; });
  V f_ = v_k_24115;
  args[0] = v_t_24119;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args) {
  V v_x_24116 = args[0];
  V v_r_24112 = heff_env(self)[0];
  V v_hd_24114 = heff_env(self)[1];
  V v_k_24115 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24117 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(heff_rfield(v_r_24112, 1))));
  V f_ = v_c_24117;
  heff_room[0] = v_hd_24114;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25, 1, 3, (V[]){v_r_24112, v_x_24116, v_k_24115});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args) {
  V v_hd_24114 = args[0];
  V v_k_24115 = args[1];
  V v_c_24113 = heff_env(self)[0];
  V v_r_24112 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24113;
  args[0] = heff_dup(v_hd_24114);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24, 1, 3, (V[]){v_r_24112, v_hd_24114, v_k_24115});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args) {
  V v_x_24134 = args[0];
  V v_x_24128 = heff_env(self)[0];
  V v_x_24132 = heff_env(self)[1];
  V v_k_24131 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24135 = ({ V a_0 = v_x_24128; V a_1 = v_x_24132; V a_2 = v_x_24134; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24132); heff_drop(v_x_24134); r_; });
  V f_ = v_k_24131;
  args[0] = v_t_24135;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args) {
  V v_x_24132 = args[0];
  V v_bodyN_24125 = heff_env(self)[0];
  V v_hd_24130 = heff_env(self)[1];
  V v_x_24128 = heff_env(self)[2];
  V v_k_24131 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24133 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_bodyN_24125));
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_24133, v_hd_24130, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28, 1, 3, (V[]){v_x_24128, v_x_24132, v_k_24131})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k_24131 = args[1];
  V v_c_24129 = heff_env(self)[0];
  V v_bodyN_24125 = heff_env(self)[1];
  V v_x_24128 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24129;
  args[0] = heff_dup(v_hd_24130);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27, 1, 4, (V[]){v_bodyN_24125, v_hd_24130, v_x_24128, v_k_24131});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args) {
  V v_hd_24171 = args[0];
  V v_k_24172 = args[1];
  V v_n2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24171);
  V v_t_24173 = (g_heff_2eelab_2erules_2eabandonChk(v_n2_242));
  V f_ = v_k_24172;
  args[0] = v_t_24173;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args) {
  V v_x_24178 = args[0];
  V v_k_24177 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24179 = ({ V a_0 = v_x_24178; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_x_24178); r_; });
  V f_ = v_k_24177;
  args[0] = v_t_24179;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args) {
  V v_hd_24176 = args[0];
  V v_k_24177 = args[1];
  V v_c_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24175;
  args[0] = v_hd_24176;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31, 1, 1, (V[]){v_k_24177});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_n2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
    }
    case TAG_CType: {
      V v_t_244 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return ({ V a_0 = v_n2_242; V a_1 = v_t_244; V r_ = (g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
    case TAG_CLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_248 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0, 2, 2, (V[]){v_c_248, v_n_240});
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_2442 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2, 2, 2, (V[]){v_c_2442, v_n_240});
    }
    case TAG_CAnnLam: {
      heff_take_n(v_n1_241, 0ULL, 4);
      heff_drop(v_n2_242);
      V v_c_2477 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4, 2, 2, (V[]){v_c_2477, v_n_240});
    }
    case TAG_CTag: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_24111 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6, 2, 2, (V[]){v_c_24111, v_n_240});
    }
    case TAG_CStruct: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24143 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8, 2, 2, (V[]){v_c_24143, v_n_240});
    }
    case TAG_CMatch: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24176 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10, 2, 2, (V[]){v_c_24176, v_n_240});
    }
    case TAG_CLetIn: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24209 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12, 2, 2, (V[]){v_c_24209, v_n_240});
    }
    case TAG_CLocal: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24242 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14, 2, 2, (V[]){v_c_24242, v_n_240});
    }
    case TAG_CAbandon: {
      heff_drop(v_n2_242);
      V v_c_24273 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16, 2, 2, (V[]){v_c_24273, v_n_240});
    }
    case TAG_CNominal: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24305 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18, 2, 2, (V[]){v_c_24305, v_n_240});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2412 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2412, 0ULL, 4);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2412);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2438;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    v_x_2438 = v_x_2411;
    break;
  }
  case TAG_False: {
    v_x_2438 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V f_ = v_k_2410;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1, 1, 2, (V[]){v_n_240, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args) {
  V v_x_2445 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2446 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2446)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2446, 0ULL, 3);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2446, 0ULL, 3);
      v_t_2471 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2446, 0ULL, 4);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2446, 0ULL, 3);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2446, 0ULL, 2);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2446, 0ULL, 2);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2446, 0ULL, 2);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2446);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2472;
  switch (heff_tag_of(v_t_2471)) {
  case TAG_True: {
    v_x_2472 = v_x_2445;
    break;
  }
  case TAG_False: {
    v_x_2472 = ({ V a_0 = v_x_2445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2445); r_; });
    break;
  }
  default: heff_nomatch(v_t_2471);
  }
  V f_ = v_k_2444;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3, 1, 2, (V[]){v_n_240, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args) {
  V v_x_2480 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24106;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2481 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2481)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2481, 0ULL, 3);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2481, 0ULL, 3);
      v_t_24106 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2481, 0ULL, 4);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2481, 0ULL, 3);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2481, 0ULL, 2);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2481, 0ULL, 2);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2481, 0ULL, 2);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2481);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24107;
  switch (heff_tag_of(v_t_24106)) {
  case TAG_True: {
    v_x_24107 = v_x_2480;
    break;
  }
  case TAG_False: {
    v_x_24107 = ({ V a_0 = v_x_2480; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2480); r_; });
    break;
  }
  default: heff_nomatch(v_t_24106);
  }
  V f_ = v_k_2479;
  args[0] = v_x_24107;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_c_2477 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2477;
  args[0] = v_hd_2478;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5, 1, 2, (V[]){v_n_240, v_k_2479});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args) {
  V v_x_24114 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24113 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24140;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24115 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24115)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24115, 0ULL, 3);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24115, 0ULL, 3);
      v_t_24140 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24115, 0ULL, 4);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24115, 0ULL, 3);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24115, 0ULL, 2);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24115, 0ULL, 2);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24115, 0ULL, 2);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24115);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24141;
  switch (heff_tag_of(v_t_24140)) {
  case TAG_True: {
    v_x_24141 = v_x_24114;
    break;
  }
  case TAG_False: {
    v_x_24141 = ({ V a_0 = v_x_24114; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24114); r_; });
    break;
  }
  default: heff_nomatch(v_t_24140);
  }
  V f_ = v_k_24113;
  args[0] = v_x_24141;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args) {
  V v_hd_24112 = args[0];
  V v_k_24113 = args[1];
  V v_c_24111 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24111;
  args[0] = v_hd_24112;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7, 1, 2, (V[]){v_n_240, v_k_24113});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args) {
  V v_x_24146 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24172;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24147 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24147)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24147, 0ULL, 3);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24147, 0ULL, 3);
      v_t_24172 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24147, 0ULL, 4);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24147, 0ULL, 3);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24147, 0ULL, 2);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24147, 0ULL, 2);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24147, 0ULL, 2);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24147);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24173;
  switch (heff_tag_of(v_t_24172)) {
  case TAG_True: {
    v_x_24173 = v_x_24146;
    break;
  }
  case TAG_False: {
    v_x_24173 = ({ V a_0 = v_x_24146; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24146); r_; });
    break;
  }
  default: heff_nomatch(v_t_24172);
  }
  V f_ = v_k_24145;
  args[0] = v_x_24173;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_c_24143 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24143;
  args[0] = v_hd_24144;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9, 1, 2, (V[]){v_n_240, v_k_24145});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args) {
  V v_x_24179 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24178 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24205;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24180 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24180)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24180, 0ULL, 3);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24180, 0ULL, 3);
      v_t_24205 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24180, 0ULL, 4);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24180, 0ULL, 3);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24180, 0ULL, 2);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24180, 0ULL, 2);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24180, 0ULL, 2);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24180);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24206;
  switch (heff_tag_of(v_t_24205)) {
  case TAG_True: {
    v_x_24206 = v_x_24179;
    break;
  }
  case TAG_False: {
    v_x_24206 = ({ V a_0 = v_x_24179; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24179); r_; });
    break;
  }
  default: heff_nomatch(v_t_24205);
  }
  V f_ = v_k_24178;
  args[0] = v_x_24206;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args) {
  V v_hd_24177 = args[0];
  V v_k_24178 = args[1];
  V v_c_24176 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24176;
  args[0] = v_hd_24177;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11, 1, 2, (V[]){v_n_240, v_k_24178});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args) {
  V v_x_24212 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24211 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24238;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24213 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24213)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24213, 0ULL, 3);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24213, 0ULL, 3);
      v_t_24238 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24213, 0ULL, 4);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24213, 0ULL, 3);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24213, 0ULL, 2);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24213, 0ULL, 2);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24213, 0ULL, 2);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24213);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24239;
  switch (heff_tag_of(v_t_24238)) {
  case TAG_True: {
    v_x_24239 = v_x_24212;
    break;
  }
  case TAG_False: {
    v_x_24239 = ({ V a_0 = v_x_24212; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24212); r_; });
    break;
  }
  default: heff_nomatch(v_t_24238);
  }
  V f_ = v_k_24211;
  args[0] = v_x_24239;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args) {
  V v_hd_24210 = args[0];
  V v_k_24211 = args[1];
  V v_c_24209 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24209;
  args[0] = v_hd_24210;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13, 1, 2, (V[]){v_n_240, v_k_24211});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args) {
  V v_x_24245 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24271;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24246 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24246)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24246, 0ULL, 3);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24246, 0ULL, 3);
      v_t_24271 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24246, 0ULL, 4);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24246, 0ULL, 3);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24246, 0ULL, 2);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24246, 0ULL, 2);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24246, 0ULL, 2);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24246);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24272;
  switch (heff_tag_of(v_t_24271)) {
  case TAG_True: {
    v_x_24272 = v_x_24245;
    break;
  }
  case TAG_False: {
    v_x_24272 = ({ V a_0 = v_x_24245; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24245); r_; });
    break;
  }
  default: heff_nomatch(v_t_24271);
  }
  V f_ = v_k_24244;
  args[0] = v_x_24272;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args) {
  V v_hd_24243 = args[0];
  V v_k_24244 = args[1];
  V v_c_24242 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24242;
  args[0] = v_hd_24243;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15, 1, 2, (V[]){v_n_240, v_k_24244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args) {
  V v_x_24276 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24275 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24302;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24277 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24277)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24277, 0ULL, 3);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24277, 0ULL, 3);
      v_t_24302 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24277, 0ULL, 4);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24277, 0ULL, 3);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24277, 0ULL, 2);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24277, 0ULL, 2);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24277, 0ULL, 2);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24277);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24303;
  switch (heff_tag_of(v_t_24302)) {
  case TAG_True: {
    v_x_24303 = v_x_24276;
    break;
  }
  case TAG_False: {
    v_x_24303 = ({ V a_0 = v_x_24276; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24276); r_; });
    break;
  }
  default: heff_nomatch(v_t_24302);
  }
  V f_ = v_k_24275;
  args[0] = v_x_24303;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args) {
  V v_hd_24274 = args[0];
  V v_k_24275 = args[1];
  V v_c_24273 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24273;
  args[0] = v_hd_24274;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17, 1, 2, (V[]){v_n_240, v_k_24275});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args) {
  V v_x_24308 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24307 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24334;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24309 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24309)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24309, 0ULL, 3);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24309, 0ULL, 3);
      v_t_24334 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24309, 0ULL, 4);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24309, 0ULL, 3);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24309, 0ULL, 2);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24309, 0ULL, 2);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24309, 0ULL, 2);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24309);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24335;
  switch (heff_tag_of(v_t_24334)) {
  case TAG_True: {
    v_x_24335 = v_x_24308;
    break;
  }
  case TAG_False: {
    v_x_24335 = ({ V a_0 = v_x_24308; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24308); r_; });
    break;
  }
  default: heff_nomatch(v_t_24334);
  }
  V f_ = v_k_24307;
  args[0] = v_x_24335;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args) {
  V v_hd_24306 = args[0];
  V v_k_24307 = args[1];
  V v_c_24305 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24305;
  args[0] = v_hd_24306;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19, 1, 2, (V[]){v_n_240, v_k_24307});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = ({ V a_0 = v_t_243; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    V v_d_2412 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 29ULL, 5);
    V v_c_2413 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2411); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2, 2, 4, (V[]){v_c_2413, v_d_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_sp_2432 = heff_field(v_x2_240, 2);
    V v_t_2433 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2434 = ({ V a_0 = v_t_2433; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2433); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8, 2, 3, (V[]){v_c_2434, v_sp_2432, v_x_2430});
  }
  case TAG_PiAnon: {
    V v_d_2438 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2439 = ({ V a_0 = v_d_2438; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_d_2438); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10, 2, 1, (V[]){v_c_2439});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(a[0]);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_c_2419)) {
  case TAG_At: {
    V v_s_2425 = heff_field(v_c_2419, 1);
    heff_take_n(v_c_2419, 2ULL, 2);
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_c_2419);
  }
  V v_x_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2423, v_t_2426})});
  V f_ = v_k_2422;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6, 1, 2, (V[]){v_c_2419, v_k_2422})));
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_NamedImplicit, 4, (V[]){v_sp_2410, v_x_248, v_x_2416, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2428;
  switch (heff_tag_of(v_d_2412)) {
  case TAG_Nothing: {
    v_c_2428 = ((V)&g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_d_2412, 0);
    heff_take_n(v_d_2412, 1ULL, 1);
    V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
    v_c_2428 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5, 2, 2, (V[]){v_t_2420, v_c_2419});
    break;
  }
  default: heff_nomatch(v_d_2412);
  }
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7, 1, 4, (V[]){v_k_2415, v_sp_2410, v_x_248, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_sp_2410 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3, 1, 5, (V[]){v_d_2412, v_hd_2414, v_k_2415, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_NamedInstance, 3, (V[]){v_sp_2432, v_x_2430, v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9, 1, 3, (V[]){v_k_2436, v_sp_2432, v_x_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Anonymous, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2439;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11, 1, 1, (V[]){v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1, 2, 3, (V[]){v_a_245, v_x_243, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_a_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2412, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411;
  switch (heff_tag_of(v_x_243)) {
  case TAG_At: {
    V v_a_2410 = heff_field(v_x_243, 1);
    heff_take_n(v_x_243, 2ULL, 2);
    v_t_2411 = v_a_2410;
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_a_2412 = ({ V a_0 = v_t_2411; V a_1 = v_a_248; V r_ = (g_heff_2eelab_2erules_2easSmall(a_0, a_1)); heff_drop(v_a_248); r_; });
  V v_c_2413 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(v_xs_244));
  V f_ = v_c_2413;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam3, 1, 2, (V[]){v_k_247, v_a_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013_lam2, 1, 4, (V[]){v_x_243, v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0, 45, "unexpected notation for variant in a sum type");
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_args_245 = heff_field(v_x21_241, 2);
      heff_take_n(v_x21_241, 5ULL, 3);
      heff_drop(v_x22_242);
      V v_c_246 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1601365996x1265637013(v_args_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0, 2, 2, (V[]){v_c_246, v_x_243});
    }
    case TAG_BadVariant: {
      heff_take_n(v_x21_241, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2, 2, 1, (V[]){v_x22_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(a[0]);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, heff_arrayFromList(v_x_249)});
  V f_ = v_k_248;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam1, 1, 2, (V[]){v_x_243, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12, 1, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11, 3, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16, 2, 0};
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TPi: {
      V v_b_243 = heff_field(v_x21_241, 0);
      V v_codN_244 = heff_field(v_x21_241, 1);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(heff_dup(v_b_243)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0, 2, 2, (V[]){v_c_245, heff_dup(v_codN_244)});
    }
    case TAG_TSig: {
      V v_fields_2412 = heff_field(v_x21_241, 0);
      V v_c_2413 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s705404546x2093663150(heff_dup(v_fields_2412)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3, 2, 1, (V[]){v_c_2413});
    }
    case TAG_TSum: {
      V v_variantNs_2423 = heff_field(v_x21_241, 0);
      V v_c_2424 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(heff_dup(v_variantNs_2423)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8, 2, 1, (V[]){v_c_2424});
    }
    case TAG_TType: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10_clo);
    }
    case TAG_TInt: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13_clo);
    }
    case TAG_TFloat: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14_clo);
    }
    case TAG_TString: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15_clo);
    }
    case TAG_TRune: {
      return ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16_clo);
    }
    case TAG_TArray: {
      V v_a0_2449 = heff_field(v_x21_241, 0);
      V v_c_2450 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_a0_2449));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17, 2, 1, (V[]){v_c_2450});
    }
    case TAG_TFixed: {
      V v_w_2455 = heff_field(v_x21_241, 0);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19, 2, 1, (V[]){heff_dup(v_w_2455)});
    }
    case TAG_TInf: {
      V v_i_2463 = heff_field(v_x21_241, 0);
      V v_c_2464 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_2463)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22, 2, 2, (V[]){v_c_2464, heff_dup(v_x22_242)});
    }
    case TAG_TChk: {
      V v_ch_2469 = heff_field(v_x21_241, 0);
      V v_c_2470 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_ch_2469)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24, 2, 1, (V[]){v_c_2470});
    }
    case TAG_TNominal: {
      V v_t_2482 = heff_field(v_x21_241, 0);
      V v_c_2483 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2482));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29, 2, 1, (V[]){v_c_2483});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = ({ V a_0 = v_x_248; V a_1 = v_x_2410; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_x_2410); r_; });
  V f_ = v_k_247;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_codN_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = ({ V a_0 = v_codN_244; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_codN_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam2, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_codN_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam1, 1, 3, (V[]){v_codN_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_2417 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = (g_heff_2eelab_2erules_2erecordOf(v_e_2417, v_x_2421));
  V f_ = v_k_2420;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_e_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam7, 1, 2, (V[]){v_e_2417, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5(V self, V *args) {
  V v_e_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2418 = (g_heff_2eelab_2erules_2eformRecord(heff_dup(v_e_2417), v_x_2416));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam6, 2, 2, (V[]){v_c_2418, v_e_2417});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam5, 1, 1, (V[]){v_x_2416})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam3(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam4, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2427)));
  V v_t_2429 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2427));
  V v_t_2430 = (g_list_2emap_24s1173914895x100384474(v_x_2427));
  V v_t_2431 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2428), v_t_2429, heff_arrayFromList(v_t_2430)});
  V v_x_2432 = (g_heff_2eelab_2erules_2esumFormation(v_t_2431));
  V f_ = v_k_2426;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam8(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam9, 1, 1, (V[]){v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12(V self, V *args) {
  V v_u2_2439 = args[0];
  heff_drop(v_u2_2439);
  V v_t_2440 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_SmallU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2440});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11(V self, V *args) {
  V v_e_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k_2437 = args[2];
  heff_drop(v_e_2435);
  heff_drop(v_hd_2436);
  V v_t_2438 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
  V f_ = v_k_2437;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2438, ((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam12_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam10(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam11_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam13(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam14(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam15(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimString_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam16(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = heff_dup(g_heff_2eelab_2erules_2eprimRune_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2454 = ({ V a_0 = v_x_2453; V r_ = (g_heff_2eelab_2erules_2eprimArray(a_0)); heff_drop(v_x_2453); r_; });
  V f_ = v_k_2452;
  args[0] = v_t_2454;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam17(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_c_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2450;
  args[0] = v_hd_2451;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam18, 1, 1, (V[]){v_k_2452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21(V self, V *args) {
  V v_u_2461 = args[0];
  V v_w_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2461);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VFixed, 1, (V[]){v_w_2455})});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20(V self, V *args) {
  V v_e_2458 = args[0];
  V v_hd_2459 = args[1];
  V v_k_2460 = args[2];
  V v_w_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2458);
  heff_drop(v_hd_2459);
  V v_t_2462 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SFixed, 1, (V[]){heff_dup(v_w_2455)}), heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam21, 1, 1, (V[]){v_w_2455})});
  V f_ = v_k_2460;
  args[0] = v_t_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam19(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_w_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam20, 3, 1, (V[]){v_w_2455})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23(V self, V *args) {
  V v_x_2467 = args[0];
  V v_x22_242 = heff_env(self)[0];
  V v_k_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2468 = ({ V a_0 = v_x22_242; V a_1 = v_x_2467; V r_ = (g_heff_2eelab_2erules_2euniverseElimSyn(a_0, a_1)); heff_drop(v_x_2467); r_; });
  V f_ = v_k_2466;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam22(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_c_2464 = heff_env(self)[0];
  V v_x22_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2464;
  args[0] = v_hd_2465;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam23, 1, 2, (V[]){v_x22_242, v_k_2466});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28(V self, V *args) {
  V v_x_2480 = args[0];
  V v_k_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2481 = (g_heff_2eelab_2ememoed_2edecode(v_x_2480));
  V f_ = v_k_2479;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_c_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2477;
  args[0] = v_hd_2478;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam28, 1, 1, (V[]){v_k_2479});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26(V self, V *args) {
  V v_e_2474 = args[0];
  V v_x_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2477;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_MkChk: {
    V v_f_2475 = heff_field(v_x_2473, 0);
    V v_ru_24x_2473_24MkChk = heff_take_reuse_n(v_x_2473, 1ULL, 1);
    V v_t_2476 = heff_tag_at_n(v_ru_24x_2473_24MkChk, TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
    v_c_2477 = heff_tr(heff_call(v_f_2475, 2, (V[]){v_e_2474, v_t_2476}));
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam27, 2, 1, (V[]){v_c_2477});
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25(V self, V *args) {
  V v_x_2473 = args[0];
  V v_k_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2472;
  args[0] = heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam26, 1, 1, (V[]){v_x_2473})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam24(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2470;
  args[0] = v_hd_2471;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam25, 1, 1, (V[]){v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30(V self, V *args) {
  V v_x_2486 = args[0];
  V v_k_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2487 = ({ V a_0 = v_x_2486; V r_ = (g_heff_2eelab_2etoplevel_2enominalTyp(a_0)); heff_drop(v_x_2486); r_; });
  V f_ = v_k_2485;
  args[0] = v_t_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam29(V self, V *args) {
  V v_hd_2484 = args[0];
  V v_k_2485 = args[1];
  V v_c_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2483;
  args[0] = v_hd_2484;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_lam30, 1, 1, (V[]){v_k_2485});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eargBinding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eargBinding_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eargBinding(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_t_245 = heff_field(v_x11_241, 2);
      V v_n_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_At: {
        V v_n_246 = heff_field(v_t_245, 0);
        V v_sp_247 = heff_field(v_t_245, 1);
        v_n_248 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_247), heff_dup(v_n_246)));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      V v_c_249 = ({ V a_0 = v_n_248; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_248); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam0, 2, 3, (V[]){v_c_249, heff_dup(v_sp_242), heff_dup(v_x_243)});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_t_2416 = heff_field(v_x11_241, 2);
      V v_n_2419;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_At: {
        V v_n_2417 = heff_field(v_t_2416, 0);
        V v_sp_2418 = heff_field(v_t_2416, 1);
        v_n_2419 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2418), heff_dup(v_n_2417)));
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_c_2420 = ({ V a_0 = v_n_2419; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2419); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam2, 2, 3, (V[]){v_c_2420, heff_dup(v_sp_242), heff_dup(v_x_2414)});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eargBinding(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_243, v_x_2412, NTAG(TAG_Expl)});
  V f_ = v_k_2411;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam1, 1, 3, (V[]){v_sp_242, v_x_243, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_2414, v_x_2423, NTAG(TAG_Impl)});
  V f_ = v_k_2422;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam3, 1, 3, (V[]){v_sp_242, v_x_2414, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithOne(V v_ab_240, V v_x2_241) {
top: ;
  V v_t_242 = heff_take_field(v_ab_240, 3);
  switch (heff_tag_of(v_t_242)) {
  case TAG_Expl: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_243 = heff_field(v_x2_241, 0);
      V v_c_244 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_Named, 2, (V[]){heff_dup(heff_rfield(v_ab_240, 1)), heff_dup(heff_rfield(v_ab_240, 2))});
      V v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_t_243; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_243); r_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, ({ V a_0 = heff_dup(heff_rfield(v_ab_240, 0)); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_244; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_c_244); r_; })});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Impl: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_247 = heff_field(v_x2_241, 0);
      V v_c_248 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_NamedImplicit, 4, (V[]){heff_dup(heff_rfield(v_ab_240, 0)), heff_dup(heff_rfield(v_ab_240, 1)), heff_take_field(v_ab_240, 2), NTAG(TAG_Nothing)});
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_t_247; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_247); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, ({ V a_0 = heff_dup(heff_rfield(v_ab_240, 0)); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_248; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_248); r_; })});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Inst: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_MkPair: {
      V v_t_2411 = heff_field(v_x2_241, 0);
      V v_c_2412 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_t_2413 = heff_tag_n(TAG_NamedInstance, 3, (V[]){heff_dup(heff_rfield(v_ab_240, 0)), heff_dup(heff_rfield(v_ab_240, 1)), heff_take_field(v_ab_240, 2)});
      V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2411); r_; });
      return heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, ({ V a_0 = heff_dup(heff_rfield(v_ab_240, 0)); V a_1 = heff_get_n(v_ab_240, 1, 4); V a_2 = v_c_2412; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2412); r_; })});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithOne(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithArgs_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_base_241;
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_rest_243, v_base_241));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2ewithOne(heff_dup(v_ab_242), v_t_244);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewithArgs(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = ({ V a_0 = v_x_243; V r_ = (g_heff_2eelab_2etoplevel_2eargBinding(a_0)); heff_drop(v_x_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etheoryD_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_lam4, 1, 0};
V g_heff_2eelab_2etoplevel_2etheoryD_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etheoryD_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_lam3, 3, 0};
V g_heff_2eelab_2etoplevel_2etheoryD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etheoryD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etheoryD_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etheoryD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etheoryD_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etheoryD(V v_name_240, V v_params_241, V v_bodyN_242) {
top: ;
  V v_c_243 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(v_params_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam0, 2, 3, (V[]){v_c_243, heff_dup(v_bodyN_242), v_name_240});
}
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etheoryD(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam4(V self, V *args) {
  V v_u2_2416 = args[0];
  heff_drop(v_u2_2416);
  V v_t_2417 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2417});
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam3(V self, V *args) {
  V v_e_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_e_2412);
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
  V f_ = v_k_2414;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2415, ((V)&g_heff_2eelab_2etoplevel_2etheoryD_lam4_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etheoryD_lam3_clo)}), v_x_2411});
  V v_x2_2419 = ({ V a_0 = v_x_246; V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_246); r_; });
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_ty_2420 = heff_field(v_x2_2419, 0);
    V v_tm_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2420, v_tm_2421, NTAG(TAG_False)});
    V f_ = v_k_245;
    args[0] = v_t_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_bodyN_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_249;
  switch (heff_tag_of(v_bodyN_242)) {
  case TAG_At: {
    V v_n_247 = heff_field(v_bodyN_242, 0);
    V v_sp_248 = heff_field(v_bodyN_242, 1);
    heff_take_n(v_bodyN_242, 3ULL, 2);
    v_n_249 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_248, v_n_247));
    break;
  }
  default: heff_nomatch(v_bodyN_242);
  }
  V v_c_2410 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_249));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam2, 1, 3, (V[]){v_x_246, v_name_240, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etheoryD_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_bodyN_242 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etheoryD_lam1, 1, 4, (V[]){v_bodyN_242, v_hd_244, v_name_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ab_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_ab_241, 3);
    V v_x1_244;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Expl: {
      v_x1_244 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_x1_244 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_x1_244 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ab_241, 1, 4), (g_heff_2eelab_2etoplevel_2eexplicitNames(v_rest_242))});
    }
    case TAG_False: {
      heff_drop_rec(v_ab_241, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames(a[0]);
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edefineD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edefineD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2edefineD(V v_name_240, V v_params_241, V v_tyN_242, V v_bodyN_243) {
top: ;
  V v_c_244 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s968327236x559479476(v_params_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam0, 2, 4, (V[]){v_c_244, heff_dup(v_tyN_242), heff_dup(v_bodyN_243), v_name_240});
}
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2edefineD(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2edefineD_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2418 = ({ V a_0 = v_x_247; V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2412, v_x_2417}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(a_0, a_1)); heff_drop(v_x_247); r_; });
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_ty_2419 = heff_field(v_x2_2418, 0);
    V v_tm_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2419, v_tm_2420, NTAG(TAG_False)});
    V f_ = v_k_246;
    args[0] = v_t_2421;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eelab_2etoplevel_2edefineD_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_bodyN_243 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2415;
  switch (heff_tag_of(v_bodyN_243)) {
  case TAG_At: {
    V v_n_2413 = heff_field(v_bodyN_243, 0);
    V v_sp_2414 = heff_field(v_bodyN_243, 1);
    heff_take_n(v_bodyN_243, 3ULL, 2);
    v_n_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
    break;
  }
  default: heff_nomatch(v_bodyN_243);
  }
  V v_c_2416 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2415));
  V f_ = v_c_2416;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam3, 1, 4, (V[]){v_x_247, v_x_2412, v_name_240, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_tyN_242 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_n_2410;
  switch (heff_tag_of(v_tyN_242)) {
  case TAG_At: {
    V v_n_248 = heff_field(v_tyN_242, 0);
    V v_sp_249 = heff_field(v_tyN_242, 1);
    heff_take_n(v_tyN_242, 3ULL, 2);
    v_n_2410 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_249, v_n_248));
    break;
  }
  default: heff_nomatch(v_tyN_242);
  }
  V v_c_2411 = ({ V a_0 = v_n_2410; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2410); r_; });
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam2, 1, 5, (V[]){v_bodyN_243, v_hd_245, v_x_247, v_name_240, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edefineD_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_tyN_242 = heff_env(self)[1];
  V v_bodyN_243 = heff_env(self)[2];
  V v_name_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edefineD_lam1, 1, 5, (V[]){v_tyN_242, v_hd_245, v_bodyN_243, v_name_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsBody_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eequationsBody(V v_name_240, V v_args_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2eexplicitNames(v_args_241));
  V v_t_245 = (g_heff_2eelab_2eclauses_2edesugar(v_name_240, v_t_244, v_eqs_242, v_sp_243));
  V v_c_2416;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Left: {
    V v_err_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_c_2416 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam0, 2, 1, (V[]){v_err_246});
    break;
  }
  case TAG_Right: {
    V v_b_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_c_2416 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam1, 2, 1, (V[]){v_b_2413});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam2, 2, 1, (V[]){v_c_2416});
}
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eequationsBody(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_err_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_246, 1), heff_get_n(v_err_246, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_b_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_b_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2417 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_2422;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_At: {
    V v_n_2420 = heff_field(v_x_2419, 0);
    V v_sp_2421 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 3ULL, 2);
    v_n_2422 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2421, v_n_2420));
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_t_2423 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2422));
  V f_ = v_t_2423;
  heff_room[0] = v_hd_2417;
  heff_room[1] = v_k_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsBody_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsBody_lam3, 1, 2, (V[]){v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eequationsD(V v_name_240, V v_tyN_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2eelab_2etoplevel_2eallL_24s367987061x1973272616(v_eqs_242));
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  V v_c_2430;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_c_2430 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam0, 2, 3, (V[]){v_eqs_242, heff_dup(v_name_240), v_sp_243});
    break;
  }
  case TAG_False: {
    v_c_2430 = (g_heff_2eelab_2etoplevel_2eequationsBody(heff_dup(v_name_240), NTAG(TAG_Nil), v_eqs_242, v_sp_243));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam9, 2, 3, (V[]){v_c_2430, heff_dup(v_tyN_241), v_name_240});
}
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eequationsD(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_248, 1, 6), v_m_2417));
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_f_2413 = heff_env(self)[0];
  V v_fsp_2414 = heff_env(self)[1];
  V v_rhs_2416 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2413, v_fsp_2414, v_x_2421, v_rhs_2416}), v_sp_2412});
  V f_ = v_k_2420;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_f_2413 = heff_env(self)[1];
  V v_fsp_2414 = heff_env(self)[2];
  V v_rhs_2416 = heff_env(self)[3];
  V v_sp_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam5, 1, 5, (V[]){v_f_2413, v_fsp_2414, v_rhs_2416, v_sp_2412, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args) {
  V v_m_2410 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2410)) {
  case TAG_At: {
    V v_x21_2411 = heff_field(v_m_2410, 0);
    V v_sp_2412 = heff_field(v_m_2410, 1);
    heff_take_n(v_m_2410, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkEquation: {
      V v_f_2413 = heff_field(v_x21_2411, 0);
      V v_fsp_2414 = heff_field(v_x21_2411, 1);
      V v_ps_2415 = heff_field(v_x21_2411, 2);
      V v_rhs_2416 = heff_field(v_x21_2411, 3);
      heff_take_n(v_x21_2411, 15ULL, 4);
      V v_c_2418 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam3, 1, 1, (V[]){v_e_248}), v_ps_2415));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam4, 2, 5, (V[]){v_c_2418, v_f_2413, v_fsp_2414, v_rhs_2416, v_sp_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_m_2410);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_248 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_k_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkChk: {
    V v_f_2429 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    V f_ = v_f_2429;
    heff_room[0] = v_e_248;
    heff_room[1] = v_a_249;
    heff_room[2] = v_hd_2424;
    heff_room[3] = v_k_2425;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_hd_2424 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  V v_a_249 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2427 = (g_heff_2eelab_2etoplevel_2eequationsBody(v_name_240, NTAG(TAG_Nil), v_x_2426, v_sp_243));
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_2424);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam8, 1, 4, (V[]){v_e_248, v_a_249, v_hd_2424, v_k_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  V v_a_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam7, 1, 6, (V[]){v_name_240, v_sp_243, v_hd_2424, v_e_248, v_a_249, v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args) {
  V v_e_248 = args[0];
  V v_a_249 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2423 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam2, 1, 1, (V[]){heff_dup(v_e_248)}), v_eqs_242));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam6, 2, 5, (V[]){v_c_2423, v_name_240, v_sp_243, v_e_248, v_a_249});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam1, 2, 3, (V[]){v_eqs_242, v_name_240, v_sp_243})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2439 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2438, v_x_2433}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_ty_2440 = heff_field(v_x2_2439, 0);
    V v_tm_2441 = heff_field(v_x2_2439, 1);
    heff_take_n(v_x2_2439, 3ULL, 2);
    V v_t_2442 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2440, v_tm_2441, NTAG(TAG_False)});
    V f_ = v_k_2432;
    args[0] = v_t_2442;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args) {
  V v_x_2433 = args[0];
  V v_tyN_241 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_2436;
  switch (heff_tag_of(v_tyN_241)) {
  case TAG_At: {
    V v_n_2434 = heff_field(v_tyN_241, 0);
    V v_sp_2435 = heff_field(v_tyN_241, 1);
    heff_take_n(v_tyN_241, 3ULL, 2);
    v_n_2436 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2435, v_n_2434));
    break;
  }
  default: heff_nomatch(v_tyN_241);
  }
  V v_c_2437 = ({ V a_0 = v_n_2436; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2436); r_; });
  V f_ = v_c_2437;
  heff_room[0] = v_hd_2431;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam11, 1, 3, (V[]){v_x_2433, v_name_240, v_k_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_tyN_241 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam10, 1, 4, (V[]){v_tyN_241, v_hd_2431, v_name_240, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str0, 45, "unexpected notation for top-level declaration");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str1, 45, "unexpected notation for top-level declaration");
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_lam3, 1, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edeclJ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edeclJ(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_241)) {
    case TAG_DeclEquations: {
      V v_name_243 = heff_field(v_d1_241, 0);
      V v_tyN_246 = heff_field(v_d1_241, 3);
      V v_eqs_247 = heff_field(v_d1_241, 4);
      V v_t_2410;
      switch (heff_tag_of(v_tyN_246)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_tyN_246, 1);
        v_t_2410 = heff_dup(v_s_249);
        break;
      }
      default: heff_nomatch(v_tyN_246);
      }
      V v_t_2413;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_d_240, 1);
        v_t_2413 = heff_dup(v_s_2412);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_n(v_t_2410, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
      return (g_heff_2eelab_2etoplevel_2eequationsD(heff_dup(v_name_243), v_tyN_246, heff_dup(v_eqs_247), v_t_2414));
    }
    case TAG_DeclDefine: {
      V v_name_2415 = heff_field(v_d1_241, 0);
      V v_params_2417 = heff_field(v_d1_241, 2);
      V v_tyN_2418 = heff_field(v_d1_241, 3);
      V v_bodyN_2419 = heff_field(v_d1_241, 4);
      return (g_heff_2eelab_2etoplevel_2edefineD(heff_dup(v_name_2415), heff_dup(v_params_2417), v_tyN_2418, v_bodyN_2419));
    }
    case TAG_DeclTheory: {
      V v_name_2420 = heff_field(v_d1_241, 0);
      V v_params_2422 = heff_field(v_d1_241, 2);
      V v_bodyN_2423 = heff_field(v_d1_241, 3);
      return (g_heff_2eelab_2etoplevel_2etheoryD(heff_dup(v_name_2420), heff_dup(v_params_2422), v_bodyN_2423));
    }
    case TAG_DeclPrimitive: {
      V v_x_2424 = heff_field(v_d1_241, 0);
      V v_tyN_2426 = heff_field(v_d1_241, 2);
      V v_n_2429;
      switch (heff_tag_of(v_tyN_2426)) {
      case TAG_At: {
        V v_n_2427 = heff_field(v_tyN_2426, 0);
        V v_sp_2428 = heff_field(v_tyN_2426, 1);
        v_n_2429 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2428), heff_dup(v_n_2427)));
        break;
      }
      default: heff_nomatch(v_tyN_2426);
      }
      V v_c_2430 = ({ V a_0 = v_n_2429; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2429); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam0, 2, 2, (V[]){v_c_2430, heff_dup(v_x_2424)});
    }
    case TAG_DeclTest: {
      V v_sp_2445;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_d_240, 1);
        v_sp_2445 = heff_dup(v_s_2444);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam4, 2, 1, (V[]){v_sp_2445});
    }
    case TAG_DeclWatch: {
      V v_sp_2455;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2454 = heff_field(v_d_240, 1);
        v_sp_2455 = heff_dup(v_s_2454);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam5, 2, 1, (V[]){v_sp_2455});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2edeclJ(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args) {
  V v_u_2438 = args[0];
  heff_drop(v_u_2438);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args) {
  V v_e_2434 = args[0];
  V v_a_2435 = args[1];
  V v_hd_2436 = args[2];
  V v_k_2437 = args[3];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2434);
  heff_drop(v_a_2435);
  heff_drop(v_hd_2436);
  V v_t_2439 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_2424}), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo)});
  V f_ = v_k_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){heff_dup(v_x_2424), v_x_2433, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam2, 4, 1, (V[]){v_x_2424})}), NTAG(TAG_True)});
  V f_ = v_k_2432;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam1, 1, 2, (V[]){v_x_2424, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k2_2447 = args[1];
  V v_sp_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str0), v_sp_2445, NTAG(TAG_Nothing)});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_2446, 2), 1, (V[]){v_t_2450}));
  V f_ = heff_get_n(v_hd_2446, 1, 3);
  args[0] = v_t_2451;
  args[1] = v_k2_2447;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_sp_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str1), v_sp_2455, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_2456, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2456, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erecoveredCheck_str0, 21, "errors recovered from");
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1, 1, 2, (V[]){v_k_241, v_hd_240})});
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 1, 8);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
Clo g_heff_2eelab_2etoplevel_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eanyL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eanyL(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2epoisonedLeft_str0, 54, "an implicit argument an error kept from being inferred");
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2epoisonedLeft_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2epoisonedLeft(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2epoisonedLeft(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 2, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4(V self, V *args) {
  V v_m_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = ({ V a_0 = v_m_2414; V a_1 = v_x_2411; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2411); r_; });
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_me_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_get_n(v_me_2416, 1, 6);
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nothing: {
      return NTAG(TAG_True);
    }
    case TAG_Just: {
      heff_take_n(v_t_2417, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = ({ V a_0 = v_x_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_x_246); r_; });
  V v_t_2413 = (g_list_2emap_24s1415906091x1371825187(v_t_2412));
  V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam4, 1, 1, (V[]){v_x_2411}); V a_1 = v_t_2413; V r_ = (g_heff_2eelab_2etoplevel_2eanyL(a_0, a_1)); heff_drop(v_t_2413); r_; });
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2eelab_2etoplevel_2epoisonedLeft_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2epoisonedLeft_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_249}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2epoisonedLeft_lam3, 1, 3, (V[]){v_x_246, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2eappendM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendM(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2etoplevel_2eappendM(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendM(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2econcatMapM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapM(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2econcatMapM(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2espineVals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2espineVals_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2espineVals(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SpId: {
    return NTAG(TAG_Nil);
  }
  case TAG_SpApp: {
    V v_sp_241 = heff_field(v_x1_240, 0);
    V v_e_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SpApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_241));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24SpApp, TAG_Cons, 2, (V[]){v_e_242, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_243, v_t_244));
  }
  case TAG_SpProj: {
    V v_sp_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    V t_0 = v_sp_245;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_247 = heff_field(v_x1_240, 0);
    V v_e_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    V v_t_2410 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_247));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_249, NTAG(TAG_Nil)});
    return (g_heff_2eelab_2etoplevel_2eappendM(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2espineVals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2espineVals(a[0]);
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2emetasInV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emetasInV_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2emetasInV(V v_mc_240, V v_v_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_t_242, 0);
    V v_sp_244 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 3ULL, 5);
    V v_t_2411;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_243, 0ULL, 1);
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_HMeta: {
      V v_m_2410 = heff_field(v_h_243, 0);
      heff_take_n(v_h_243, 1ULL, 1);
      v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_HError: {
      v_t_2411 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2espineVals(v_sp_244));
    V v_t_2414 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2etoplevel_2emetasInV_lam0, 1, 1, (V[]){heff_dup(v_mc_240)}); V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2etoplevel_2econcatMapM(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_2411, v_t_2414);
  }
  case TAG_VCode: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VLam: {
    heff_take_n(v_t_242, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_VCons: {
    heff_take_n(v_t_242, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2emetasInV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2emetasInV(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2emetasInV_lam0(V self, V *args) {
  V v_v2_2413 = args[0];
  V v_mc_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_mc_240; V a_1 = v_v2_2413; V r_ = (g_heff_2eelab_2etoplevel_2emetasInV(a_0, a_1)); heff_drop(v_mc_240); r_; });
}
V g_heff_2eelab_2etoplevel_2enubInt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enubInt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enubInt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2etoplevel_2enubInt_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2eelab_2etoplevel_2enubInt(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt(a[0]);
}
V g_heff_2eelab_2etoplevel_2enubInt_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_intEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eshownV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eshownV_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eshownV(V v_g_240, V v_mc_241, V v_cs_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_241, v_v_243));
  V v_e_245 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_take_field(v_cs_242, 0), v_t_244));
  V v_t_2411 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2etoplevel_2eshownV_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 0, 2), 1, (V[]){v_e_245}));
  HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_242, 1, 2), v_e_2412);
}
V g_heff_2eelab_2etoplevel_2eshownV_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eshownV(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eshownV_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_247 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_246)));
  V v_t_248 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_249 = ({ V a_0 = v_t_248; V a_1 = v_x_246; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_248); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nothing: {
    return v_d_247;
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    heff_take_n(v_x2_249, 1ULL, 1);
    heff_drop(v_d_247);
    return v_x_2410;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str0, 50, "the implicit arguments found do not fit together: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str2, 14, " are not equal");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str3, 11, "found for `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str4, 17, "`, it would need ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str5, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str6, 35, "cannot infer an implicit argument: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str7, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str8, 24, " does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str9, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str10, 14, "`: give it, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str11, 9, " := ...)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str12, 21, "what is known of it, ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str13, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str14, 25, ", does not say what it is");
Clo g_heff_2eelab_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get_n(v_p_241, 3, 4);
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str0), heff_strAppend(heff_dup(v_left_243), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str1), heff_strAppend(heff_dup(v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str2)))));
    V v_t_248;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_248 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_247 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_248 = heff_get_n(v_me_247, 5, 6);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2411;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_249 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str3), heff_strAppend(heff_get_n(v_me_249, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str4), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str5), v_right_244)))));
      v_t_2411 = heff_tag_at_n(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){v_t_2410});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_246, v_t_248, v_t_2411});
  }
  case TAG_False: {
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2412 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str6), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str7), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str8)))));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2412, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2413 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str9), heff_strAppend(heff_dup(heff_rfield(v_me_2413, 4)), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str10), heff_strAppend(heff_dup(heff_rfield(v_me_2413, 4)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str11)))));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str12), heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str13), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str14)))));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2414, heff_get_n(v_me_2413, 5, 6), heff_tag_n(TAG_Just, 1, (V[]){v_t_2415})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2etoplevel_2estuckAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2estuckAt(V v_g_240, V v_fallback_241, V v_p_242, V v_mc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_245 = (g_heff_2eelab_2etoplevel_2emetasInV(v_mc_243, heff_dup(heff_rfield(v_p_242, 2))));
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245));
  V v_x1_247 = (g_heff_2eelab_2etoplevel_2enubInt(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    v_t_2410 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2410 = (g_map_2elookup_24s567992785x1569911877(v_x_248, v_mc_243));
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2411 = (g_heff_2eelab_2etoplevel_2eshownV(heff_dup(v_g_240), v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 1))));
  V v_t_2412 = (g_heff_2eelab_2etoplevel_2eshownV(v_g_240, v_mc_243, heff_dup(heff_rfield(v_p_242, 0)), heff_dup(heff_rfield(v_p_242, 2))));
  return (g_heff_2eelab_2etoplevel_2estuckWith(v_fallback_241, v_p_242, v_t_2410, v_t_2411, v_t_2412));
}
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2estuckAt(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eentryFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eentryFor_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eentryFor(V v_g_240, V v_k_241, V v_prim_242, V v_tyStx_243, V v_bodyStx_244) {
top: ;
  V v_t_2410;
  switch (heff_tag_of(v_prim_242)) {
  case TAG_True: {
    v_t_2410 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_k_241}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eentryFor_lam0, 1, 2, (V[]){heff_dup(v_g_240), heff_dup(v_tyStx_243)}), NTAG(TAG_Nothing)));
    break;
  }
  case TAG_False: {
    v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), v_k_241, heff_dup(v_tyStx_243), heff_dup(v_bodyStx_244)));
    break;
  }
  default: heff_nomatch(v_prim_242);
  }
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_243), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_244, v_tyStx_243, v_t_2410, v_t_2415});
}
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eentryFor(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eentryFor_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_tyStx_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_245);
  V v_x1_246 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), v_tyStx_243, NTAG(TAG_LNil)));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nom: {
    V v_x_247 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_247;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_246, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_249 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 1);
    return v_x_249;
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2eelab_2etoplevel_2eerrEntry_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eerrEntry_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eerrEntry(V v_g_240, V v_k_241, V v_tyStx_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_a_247;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nom: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_a_247 = v_x_244;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_a_247 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_246 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 1);
    v_a_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eerrEntry_lam0, 1, 1, (V[]){v_a_247}), NTAG(TAG_Nothing)));
  V v_x1_2410 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_242), NTAG(TAG_LNil)));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_242, v_t_249, v_t_2414});
}
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eerrEntry(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eerrEntry_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_247;
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckStuck_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2echeckStuck(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2echeckStuck_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){v_t_249}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2etoplevel_2echeckStuck_lam1, 1, 5, (V[]){v_g_240, v_sp_241, heff_dup(v_p_245), v_p_243, v_p_244})});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2echeckStuck(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2etoplevel_2echeckStuck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2412 = ({ V a_0 = v_g_240; V a_1 = v_sp_241; V a_2 = v_p_245; V a_3 = v_x_2411; V r_ = (g_heff_2eelab_2etoplevel_2estuckAt(a_0, a_1, a_2, a_3)); heff_drop(v_x_2411); r_; });
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_x_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2414}));
  V f_ = heff_get_n(v_p_243, 1, 3);
  heff_room[0] = v_t_2415;
  heff_room[1] = v_p_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2echeckUnsolved_str0, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2echeckUnsolved_str1, 21, "`; give it as `{...}`");
Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckUnsolved_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2echeckUnsolved(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_240, 0);
    V v_t_245 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str0), heff_strAppend(heff_dup(heff_rfield(v_u_243, 0)), ((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str1)));
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_245, heff_dup(heff_rfield(v_u_243, 1)), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_248}));
    return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_249, v_p_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2echeckUnsolved(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyEnv_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ebodyEnv(V v_gSelf_240, V v_k_241, V v_name_242, V v_aval_243) {
top: ;
  V v_v_245 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam0, 1, 1, (V[]){heff_dup(v_aval_243)}), NTAG(TAG_Nothing)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_name_242, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_249 = heff_tag_n(TAG_CBind, 3, (V[]){NTAG(TAG_CEmpty), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_aval_243});
  V v_t_2410 = heff_tag_n(TAG_ForDescriptive, 2, (V[]){heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId)});
  return heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_rec_n(4, shape_len__names__locals__ctx, (V[]){MK_INT(1LL), v_t_246, v_t_248, v_t_249}), v_gSelf_240, v_t_2410, MK_INT(0LL), heff_tag_n(TAG_Just, 1, (V[]){v_k_241}), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyEnv(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_aval_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_aval_243;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_245;
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efailedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efailedAt_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2efailedAt(V v_aval_240, V v_d_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2eelab_2emeta_2eblockedTy(v_aval_240, heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2etoplevel_2efailedAt_lam0, 1, 3, (V[]){v_d_241, v_hd_242, v_k_243})));
}
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2efailedAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2efailedAt_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_d_245;
  switch (heff_tag_of(v_x_244)) {
  case TAG_True: {
    v_d_245 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_n(v_d_241, 30ULL, 5, shape_code__severity__msg__span__note); heff_rfield(rr_, 0) = rv_0; rr_; });
    break;
  }
  case TAG_False: {
    v_d_245 = v_d_241;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_d_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_247}));
  V f_ = heff_get_n(v_hd_242, 1, 3);
  heff_room[0] = v_t_248;
  heff_room[1] = v_k_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str0, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str1, 21, "`; give it as `{...}`");
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244) {
top: ;
  V v_e_245 = (g_heff_2eelab_2etoplevel_2ebodyEnv(heff_dup(v_gSelf_242), v_k_243, heff_take_field(v_d_241, 0), heff_dup(v_aval_244)));
  V v_t_246 = heff_get_n(v_d_241, 2, 4);
  V v_m_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_m_248 = heff_tr(heff_call(v_f_247, 2, (V[]){v_e_245, heff_dup(v_aval_244)}));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam0, 2, 4, (V[]){v_m_248, v_aval_244, v_gSelf_242, v_dsp_240});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyPhase(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_aval_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2efailedAt(v_aval_244, v_s_2412, heff_dup(v_hd_249), heff_get_n(v_hd_249, 0, 3)));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2431);
  V f_ = v_k_2423;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args) {
  V v_unsolved_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_unsolved_2421)) {
  case TAG_Nil: {
    heff_drop_rec(v_hd_2422, 3);
    V f_ = v_k_2423;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_u_2424 = heff_field(v_unsolved_2421, 0);
    heff_take_n(v_unsolved_2421, 1ULL, 2);
    V v_t_2426 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str0), heff_strAppend(heff_dup(heff_rfield(v_u_2424, 0)), ((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str1)));
    V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_2426, heff_get_n(v_u_2424, 1, 2), NTAG(TAG_Nothing)});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_2422, 2), 1, (V[]){v_t_2429}));
    V f_ = heff_get_n(v_hd_2422, 1, 3);
    args[0] = v_t_2430;
    args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam8, 1, 2, (V[]){v_k_2423, v_x_2416});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_unsolved_2421);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  return (g_co_2ebind_24s935789828x1526377372(heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam7, 3, 1, (V[]){v_x_2416}), v_hd_249, v_k_2410));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_dsp_240 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2419);
  return ({ V a_0 = v_gSelf_242; V a_1 = v_dsp_240; V a_2 = v_x_2417; V a_3 = heff_dup(v_hd_249); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam6, 1, 3, (V[]){v_x_2416, v_hd_249, v_k_2410}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2417); r_; });
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2418);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam5, 1, 6, (V[]){v_gSelf_242, v_dsp_240, v_x_2417, v_hd_249, v_x_2416, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam4, 1, 6, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2417, v_x_2416, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_gSelf_242), MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam3, 1, 5, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2416, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_m_248 = heff_env(self)[0];
  V v_aval_244 = heff_env(self)[1];
  V v_gSelf_242 = heff_env(self)[2];
  V v_dsp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tr(heff_call(v_m_248, 2, (V[]){heff_dup(v_hd_249), heff_dup(heff_rfield(v_hd_249, 0))}));
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam1, 1, 2, (V[]){v_aval_244, heff_dup(v_hd_249)})})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_249, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_t_2415;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam2, 1, 4, (V[]){v_gSelf_242, v_hd_249, v_dsp_240, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_entry, 9, 0};

V g_heff_2eelab_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_isInstance_243, V v_tyStx_244, V v_mc_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Left: {
    V v_failed_249 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2410 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      v_key_2411 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_key_2411 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2412 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_key_240);
      v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_t_2413 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_entry_2414 = ({ V a_0 = v_g_241; V a_1 = v_t_2413; V a_2 = v_tyStx_244; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2411, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2414, heff_tag_n(TAG_Just, 1, (V[]){v_failed_249})});
    return heff_tail(v_z_248, 1, (V[]){v_t_2415});
  }
  case TAG_Right: {
    V v_t_2416 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2417 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_key_2418 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_key_2418 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2419 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2420;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      v_t_2420 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_t_2420 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    V v_t_2421 = heff_dup(heff_rfield(v_d_242, 3));
    V v_k_2422;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      heff_drop(v_key_240);
      v_k_2422 = heff_dup(heff_rfield(v_d_242, 0));
      break;
    }
    case TAG_False: {
      v_k_2422 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    V v_t_2423 = (g_heff_2eelab_2eunify_2ezonker(v_mc_245));
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_t_2423, 0, 2), 1, (V[]){heff_get_n(v_t_2416, 0, 2)}));
    V v_t_2425 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_2422));
    V v_t_2426 = heff_tr(heff_call(heff_get_n(v_t_2425, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2424}));
    V v_entry_2427 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_241, v_t_2420, heff_rfield(v_d_242, 3), v_tyStx_244, v_t_2426));
    V v_t_2428 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2418, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2427, NTAG(TAG_Nothing)});
    return heff_tail(v_z_248, 1, (V[]){v_t_2428});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a7 = a[7]; V r = g_heff_2eelab_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a5, a[6], a7, a[8]); heff_drop(a5); heff_drop(a7); return r;
}

static V g_heff_2eelab_2etoplevel_2eprimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2eprimNames_st;
static V g_heff_2eelab_2etoplevel_2eprimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2eprims_get())));
}
V g_heff_2eelab_2etoplevel_2eprimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2eprimNames_st)) return g_heff_2eelab_2etoplevel_2eprimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2eprimNames_val, &g_heff_2eelab_2etoplevel_2eprimNames_st, g_heff_2eelab_2etoplevel_2eprimNames_init);
}

static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2ebasicPrimNames_st;
static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2ebasicPrims_get())));
}
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2ebasicPrimNames_st)) return g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2ebasicPrimNames_val, &g_heff_2eelab_2etoplevel_2ebasicPrimNames_st, g_heff_2eelab_2etoplevel_2ebasicPrimNames_init);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str2, 30, "there is no primitive called `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str3, 20, "` (the runtime has: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str4, 55, ", and each fixed-width type's, `int32Add` and the like)");
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_lam1, 2, 0};
Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 3);
  V v_t_246;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_xs_243 = heff_dup(g_heff_2eelab_2etoplevel_2eprimNames_get());
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_d_241, 0))}));
    V v_x1_245 = ({ V a_0 = v_t_244; V a_1 = v_xs_243; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_243); r_; });
    switch (heff_tag_of(v_x1_245)) {
    case TAG_True: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    break;
  }
  case TAG_False: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_x2_247 = heff_dup(g_heff_2eelab_2etoplevel_2ebasicPrimNames_get());
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_msg_2411 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str2), heff_strAppend(heff_get_n(v_d_241, 0, 4), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str3), heff_strAppend(v_t_2410, ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str4)))));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eprimKnown_lam0, 2, 2, (V[]){v_msg_2411, v_sp_240});
  }
  case TAG_False: {
    heff_drop(v_sp_240);
    heff_drop_rec(v_d_241, 4);
    return ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eprimKnown(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_msg_2411 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_2411, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2emonomorphicInstance_str0, 57, "an instance takes no arguments: its type is no function's");
HEFF_LIT(g_heff_2eelab_2etoplevel_2emonomorphicInstance_str1, 187, "an instance of every type, found by finding others (`{a : Type} -> {{e : Eq a}} -> Eq (List a)`), is not had yet: declare one of each type, or bind it where it is used, `{{x : T}} -> ...`");
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam1(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam1, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam2, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam6, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam8, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam9, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam11(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam11, 2, 0};
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam12(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam12, 2, 0};
Clo g_heff_2eelab_2etoplevel_2emonomorphicInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2emonomorphicInstance_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2emonomorphicInstance(V v_x1_240, V v_ty_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ty_241, 2);
    return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam0_clo);
  }
  case TAG_Just: {
    V v_sp_244 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_245 = (g_heff_2esyntax_2epsurface_2eunIsTy(heff_get_n(v_ty_241, 0, 2)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_SU: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam1_clo);
    }
    case TAG_SDecode: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam2_clo);
    }
    case TAG_SFunction: {
      heff_take_n(v_t_245, 0ULL, 5);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam3, 2, 1, (V[]){v_sp_244});
    }
    case TAG_SRecord: {
      heff_take_n(v_t_245, 0ULL, 3);
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam4_clo);
    }
    case TAG_SSum: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam5_clo);
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam6_clo);
    }
    case TAG_SPrimInt: {
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam7_clo);
    }
    case TAG_SPrimFloat: {
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam8_clo);
    }
    case TAG_SPrimString: {
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam9_clo);
    }
    case TAG_SPrimRune: {
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam10_clo);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam11_clo);
    }
    case TAG_SFixed: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_sp_244);
      return ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam12_clo);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2emonomorphicInstance(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_sp_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(348LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_str0), v_sp_244, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2emonomorphicInstance_str1)})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2421}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2422;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam4(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam6(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam8(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam9(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam11(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V f_ = v_k_2444;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2emonomorphicInstance_lam12(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_entry, 7, 0};

V g_heff_2eelab_2etoplevel_2eelabBody(V v_key_240, V v_g_241, V v_n_242, V v_d_243, V v_a_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_248;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    v_t_248 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_248 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_k_249 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam0, 1, 1, (V[]){v_k_249})})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam1, 1, 7, (V[]){v_z_245, heff_dup(v_n_242), v_d_243, v_key_240, v_a_244, v_g_241, v_z_246})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabBody(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_249; V rr_ = heff_rec_reuse_n(v_c_2410, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam3(V self, V *args) {
  V v_u_2427 = args[0];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2427);
  V v_x1_2428 = heff_tr(heff_call(heff_get_n(v_a_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_Nom: {
    V v_x_2429 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    return v_x_2429;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2431 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    return v_x_2431;
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam5(V self, V *args) {
  V v_c_2452 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_2452, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam9(V self, V *args) {
  V v_c_2466 = args[0];
  return heff_get_n(v_c_2466, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam10(V self, V *args) {
  V v_x_2470 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_d_243 = heff_env(self)[4];
  V v_body_2449 = heff_env(self)[5];
  V v_hd_2450 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2496;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2471 = heff_field(v_n_242, 0);
    heff_take_n(v_n_242, 1ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_DeclEquations: {
      V v_x113_2475 = heff_field(v_x11_2471, 2);
      V v_tyN_2476 = heff_field(v_x11_2471, 3);
      heff_take_n(v_x11_2471, 12ULL, 5);
      switch (heff_tag_of(v_x113_2475)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2476);
        v_t_2496 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2480;
        switch (heff_tag_of(v_tyN_2476)) {
        case TAG_At: {
          V v_s_2479 = heff_field(v_tyN_2476, 1);
          heff_take_n(v_tyN_2476, 2ULL, 2);
          v_t_2480 = v_s_2479;
          break;
        }
        default: heff_nomatch(v_tyN_2476);
        }
        v_t_2496 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2480});
        break;
      }
      default: heff_nomatch(v_x113_2475);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2471, 0ULL, 5);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2471, 0ULL, 4);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2471, 0ULL, 3);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2471, 0ULL, 2);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2471, 0ULL, 1);
      v_t_2496 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2471);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2498;
  switch (heff_tag_of(v_t_2496)) {
  case TAG_Nothing: {
    v_t_2498 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2496, 0ULL, 1);
    v_t_2498 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2496);
  }
  V v_t_2499 = (g_heff_2eelab_2eunify_2ezonker(v_x_2470));
  V v_t_24100 = heff_tr(heff_call(heff_get_n(v_t_2499, 1, 2), 1, (V[]){heff_get_n(v_a_244, 0, 2)}));
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_d_243; V a_3 = v_t_2498; V a_4 = v_t_24100; V a_5 = v_x_2470; V a_6 = v_body_2449; V a_7 = v_hd_2450; V a_8 = v_k_2451; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2470); heff_drop_rec(v_hd_2450, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_d_243 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2465);
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam9_clo)})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){v_t_2468}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  heff_room[0] = v_t_2469;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam10, 1, 8, (V[]){v_n_242, v_a_244, v_key_240, v_g_241, v_d_243, v_body_2449, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam7(V self, V *args) {
  V v_x_2460 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_hd_2450 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2460);
  V v_t_2463;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2462 = heff_dup(heff_field(v_n_242, 1));
    v_t_2463 = v_s_2462;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2464 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2463, heff_dup(v_d_243)));
  V f_ = v_c_2464;
  heff_room[0] = heff_dup(v_hd_2450);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam8, 1, 8, (V[]){v_hd_2450, v_n_242, v_a_244, v_key_240, v_g_241, v_d_243, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_hd_2450 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_key_240 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_body_2449 = heff_env(self)[6];
  V v_k_2451 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2457 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2456, NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  heff_room[0] = v_t_2459;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam7, 1, 8, (V[]){v_n_242, v_d_243, v_hd_2450, v_a_244, v_key_240, v_g_241, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam4(V self, V *args) {
  V v_body_2449 = args[0];
  V v_hd_2450 = args[1];
  V v_k_2451 = args[2];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_a_244 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_lam5_clo)})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2450, 2)), 1, (V[]){v_t_2454}));
  V f_ = heff_dup(heff_rfield(v_hd_2450, 1));
  args[0] = v_t_2455;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam6, 1, 8, (V[]){v_hd_2450, v_n_242, v_d_243, v_a_244, v_key_240, v_g_241, v_body_2449, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_g_241 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2418);
  V v_t_2421;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_s_2420 = heff_dup(heff_field(v_n_242, 1));
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_t_2422 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2423;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_True: {
    v_t_2423 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_2423 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V v_t_2424 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2425;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_True: {
    v_t_2425 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_2425 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_h_2426 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2425});
  V v_t_2432 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2426, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam3, 1, 1, (V[]){heff_dup(v_a_244)}), NTAG(TAG_Nothing)));
  V v_x1_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2437;
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_Nom: {
    V v_x_2434 = heff_field(v_x1_2433, 0);
    heff_take_n(v_x1_2433, 1ULL, 1);
    v_t_2437 = v_x_2434;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2433, 0ULL, 1);
    v_t_2437 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2436 = heff_field(v_x1_2433, 0);
    heff_take_n(v_x1_2433, 1ULL, 1);
    v_t_2437 = v_x_2436;
    break;
  }
  default: heff_nomatch(v_x1_2433);
  }
  V v_t_2438 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_244, 0)), v_t_2432, v_t_2437});
  V v_t_2439 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2423, v_t_2438, heff_dup(v_g_241)));
  V v_t_2440 = heff_dup(heff_rfield(v_d_243, 3));
  V v_t_2441;
  switch (heff_tag_of(v_t_2440)) {
  case TAG_True: {
    v_t_2441 = heff_dup(heff_rfield(v_d_243, 0));
    break;
  }
  case TAG_False: {
    v_t_2441 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_243, 0))}));
    break;
  }
  default: heff_nomatch(v_t_2440);
  }
  V v_x1_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_244, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nom: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2443;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2442, 0ULL, 1);
    v_t_2446 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2445 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_t_2447 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2421, heff_dup(v_d_243), v_t_2439, v_t_2441, v_t_2446));
  V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2447}));
  return (g_co_2ebind_24s1601686549x58384075(v_t_2448, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam4, 3, 5, (V[]){v_n_242, v_d_243, v_a_244, v_key_240, v_g_241}), v_z_245, v_z_246));
}
V g_heff_2eelab_2etoplevel_2eelabBody_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_key_240 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_g_241 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_lam2, 1, 7, (V[]){v_n_242, v_d_243, v_key_240, v_a_244, v_g_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str2, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str3, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str4, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str5, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str6, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str7, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str8, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str9, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str10, 54, "a watch must say what type it has: write `>>> (e : T)`");
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ewatchSyn(V v_w_240) {
top: ;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_w1_241 = heff_field(v_w_240, 0);
    switch (heff_tag_of(v_w1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_w1_241, 0);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_243));
    }
    case TAG_CType: {
      V v_sp_247;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_246 = heff_field(v_w_240, 1);
        v_sp_247 = heff_dup(v_s_246);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam0, 2, 1, (V[]){v_sp_247});
    }
    case TAG_CLam: {
      V v_sp_2419;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2418 = heff_field(v_w_240, 1);
        v_sp_2419 = heff_dup(v_s_2418);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam1, 2, 1, (V[]){v_sp_2419});
    }
    case TAG_CImplicitLam: {
      V v_sp_2431;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_w_240, 1);
        v_sp_2431 = heff_dup(v_s_2430);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam2, 2, 1, (V[]){v_sp_2431});
    }
    case TAG_CAnnLam: {
      V v_sp_2444;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_w_240, 1);
        v_sp_2444 = heff_dup(v_s_2443);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam3, 2, 1, (V[]){v_sp_2444});
    }
    case TAG_CTag: {
      V v_sp_2456;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2455 = heff_field(v_w_240, 1);
        v_sp_2456 = heff_dup(v_s_2455);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam4, 2, 1, (V[]){v_sp_2456});
    }
    case TAG_CStruct: {
      V v_sp_2466;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_w_240, 1);
        v_sp_2466 = heff_dup(v_s_2465);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam5, 2, 1, (V[]){v_sp_2466});
    }
    case TAG_CMatch: {
      V v_sp_2477;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_w_240, 1);
        v_sp_2477 = heff_dup(v_s_2476);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam6, 2, 1, (V[]){v_sp_2477});
    }
    case TAG_CLetIn: {
      V v_sp_2488;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2487 = heff_field(v_w_240, 1);
        v_sp_2488 = heff_dup(v_s_2487);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam7, 2, 1, (V[]){v_sp_2488});
    }
    case TAG_CLocal: {
      V v_sp_2499;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2498 = heff_field(v_w_240, 1);
        v_sp_2499 = heff_dup(v_s_2498);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam8, 2, 1, (V[]){v_sp_2499});
    }
    case TAG_CAbandon: {
      V v_sp_24108;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_w_240, 1);
        v_sp_24108 = heff_dup(v_s_24107);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam9, 2, 1, (V[]){v_sp_24108});
    }
    case TAG_CNominal: {
      V v_sp_24118;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24117 = heff_field(v_w_240, 1);
        v_sp_24118 = heff_dup(v_s_24117);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam10, 2, 1, (V[]){v_sp_24118});
    }
    default: return heff_nomatch(v_w1_241);
    }
  }
  default: return heff_nomatch(v_w_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewatchSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_sp_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str0), v_sp_247, NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2412}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  args[0] = v_t_2413;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_sp_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str1), v_sp_2419, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_2420, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2420, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_sp_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str2), v_sp_2431, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k2_2446 = args[1];
  V v_sp_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str3), v_sp_2444, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_2445, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2445, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2446;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_sp_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str4), v_sp_2456, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_2457, 2), 1, (V[]){v_t_2461}));
  V f_ = heff_get_n(v_hd_2457, 1, 3);
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_sp_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str5), v_sp_2466, NTAG(TAG_Nothing)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_2467, 2), 1, (V[]){v_t_2471}));
  V f_ = heff_get_n(v_hd_2467, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_sp_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str6), v_sp_2477, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_2478, 2), 1, (V[]){v_t_2482}));
  V f_ = heff_get_n(v_hd_2478, 1, 3);
  args[0] = v_t_2483;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_sp_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str7), v_sp_2488, NTAG(TAG_Nothing)});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_2489, 2), 1, (V[]){v_t_2493}));
  V f_ = heff_get_n(v_hd_2489, 1, 3);
  args[0] = v_t_2494;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k2_24101 = args[1];
  V v_sp_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str8), v_sp_2499, NTAG(TAG_Nothing)});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tr(heff_call(heff_take_field(v_hd_24100, 2), 1, (V[]){v_t_24104}));
  V f_ = heff_get_n(v_hd_24100, 1, 3);
  args[0] = v_t_24105;
  args[1] = v_k2_24101;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k2_24110 = args[1];
  V v_sp_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str9), v_sp_24108, NTAG(TAG_Nothing)});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tr(heff_call(heff_take_field(v_hd_24109, 2), 1, (V[]){v_t_24113}));
  V f_ = heff_get_n(v_hd_24109, 1, 3);
  args[0] = v_t_24114;
  args[1] = v_k2_24110;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args) {
  V v_hd_24119 = args[0];
  V v_k2_24120 = args[1];
  V v_sp_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str10), v_sp_24118, NTAG(TAG_Nothing)});
  V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_call(heff_take_field(v_hd_24119, 2), 1, (V[]){v_t_24123}));
  V f_ = heff_get_n(v_hd_24119, 1, 3);
  args[0] = v_t_24124;
  args[1] = v_k2_24120;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchEntry_str0, 7, "> watch");
Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchEntry_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_ty_243));
  V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_244));
  V v_t_246 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_tyStx_247 = heff_tr(heff_call(heff_get_n(v_t_246, 1, 2), 1, (V[]){v_t_245}));
  V v_t_248 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_bodyStx_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 2), 1, (V[]){heff_get_n(v_t_242, 0, 2)}));
  V v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), ((V)&g_heff_2eelab_2etoplevel_2ewatchEntry_str0), heff_dup(v_tyStx_247), heff_dup(v_bodyStx_249)));
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_247), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_249, v_tyStx_247, v_t_2410, v_t_2415});
}
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2ewatchEntry(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ewatchPhase(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_ty_246 = heff_field(v_x3_242, 1);
    return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_g_240), MK_INT(0LL), heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam0, 1, 6, (V[]){v_p_243, v_g_240, v_sp_241, heff_dup(v_t_245), heff_dup(v_ty_246), v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2ewatchPhase(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args) {
  V v_c_2415 = args[0];
  return heff_get_n(v_c_2415, 3, 8);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2420 = ({ V a_0 = v_g_240; V a_1 = v_x_2419; V a_2 = v_t_245; V a_3 = v_ty_246; V r_ = (g_heff_2eelab_2etoplevel_2ewatchEntry(a_0, a_1, a_2, a_3)); heff_drop(v_x_2419); r_; });
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_245 = heff_env(self)[2];
  V v_ty_246 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam7, 1, 4, (V[]){v_g_240, v_t_245, v_ty_246, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args) {
  V v_unsolved_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_unsolved_2411; V a_1 = heff_dup(v_hd_2412); V a_2 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam5, 1, 5, (V[]){v_hd_2412, v_g_240, v_t_245, v_ty_246, v_k_2413}); V r_ = (g_heff_2eelab_2etoplevel_2echeckUnsolved(a_0, a_1, a_2)); heff_drop(v_unsolved_2411); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  return (g_co_2ebind_24s935789828x1526377372(heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam4, 3, 3, (V[]){v_g_240, v_t_245, v_ty_246}), v_p_243, v_p_244));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  return ({ V a_0 = heff_dup(v_g_240); V a_1 = v_sp_241; V a_2 = v_x_247; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam3, 1, 5, (V[]){v_g_240, v_t_245, v_ty_246, v_p_243, v_p_244}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_247); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam2, 1, 7, (V[]){v_g_240, v_sp_241, v_x_247, v_p_243, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_ty_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam1, 1, 7, (V[]){v_p_243, v_g_240, v_sp_241, v_x_247, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabWatch_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eelabWatch(V v_g_240, V v_n_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_242));
    v_t_245 = heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_243});
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2ewatchSyn(a_0)); heff_drop(v_t_245); r_; });
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam0, 2, 3, (V[]){v_c_246, v_g_240, v_n_241});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabWatch(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2415 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  return ({ V a_0 = v_g_240; V a_1 = v_t_2416; V a_2 = v_x_2413; V a_3 = v_hd_247; V a_4 = v_k_248; V r_ = (g_heff_2eelab_2etoplevel_2ewatchPhase(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSyn: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2411 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2412 = heff_tr(heff_call(v_f_2410, 1, (V[]){v_t_2411}));
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam2, 1, 4, (V[]){v_n_241, v_g_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam1, 1, 4, (V[]){v_g_240, v_hd_247, v_n_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendT(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2etoplevel_2eappendT(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_241, 0)), MK_INT(-1LL))) {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_244 = NTAG(TAG_Nil);
    } else {
      v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_xs_242));
    return (g_heff_2eelab_2etoplevel_2eappendT(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopBroken(V v_kf_240, V v_acc_241, V v_n_242, V v_diags_243) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_244 = heff_field(v_n_242, 0);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_DeclEquations: {
      V v_f_246 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_246)});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2411 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2411)});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2416 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2420 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2420)});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2423 = heff_field(v_x11_244, 0);
      v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2423)});
      break;
    }
    case TAG_DeclWatch: {
      v_t_2426 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    return ({ V rv_1 = v_diags_243; V rr_ = heff_rec_reuse_n(v_acc_241, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_k_2428 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_t_2429 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2427)}));
    V v_g_2432;
    if (heff_strEq_c(v_t_2429, heff_dup(v_x_2427))) {
      heff_drop(v_kf_240);
      v_g_2432 = heff_dup(heff_rfield(v_acc_241, 0));
    } else {
      V v_t_2431 = heff_tr(heff_call(v_kf_240, 1, (V[]){heff_dup(v_x_2427)}));
      v_g_2432 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2427), v_t_2431, heff_dup(heff_rfield(v_acc_241, 0))));
    }
    V v_t_2433 = (g_map_2einsert_24s1341440536x470972936(v_k_2428, NTAG(TAG_MkUnit), heff_take_field(v_g_2432, 3)));
    V v_globals_2434 = ({ V rv_3 = v_t_2433; V rr_ = heff_rec_reuse_n(v_g_2432, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2437;
    switch (heff_tag_of(v_n_242)) {
    case TAG_At: {
      V v_s_2436 = heff_field(v_n_242, 1);
      v_t_2437 = heff_dup(v_s_2436);
      break;
    }
    default: heff_nomatch(v_n_242);
    }
    V v_broken_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_t_2437}), heff_take_field(v_acc_241, 3)});
    return ({ V rv_0 = v_globals_2434; V rv_1 = v_diags_243; V rv_3 = v_broken_2438; V rr_ = heff_rec_reuse_n(v_acc_241, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2426);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etopBroken(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ekeepSt_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ekeepSt(V v_st_240, V v_acc_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_242 = heff_field(v_st_240, 0);
    v_t_245 = heff_dup(v_c_242);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_infos_246 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_245, 0, 8), heff_take_field(v_acc_241, 7)));
  V v_t_2410;
  switch (heff_tag_of(v_st_240)) {
  case TAG_MkSt: {
    V v_c_247 = heff_field(v_st_240, 0);
    v_t_2410 = heff_dup(v_c_247);
    break;
  }
  default: heff_nomatch(v_st_240);
  }
  V v_trace_2411 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2410, 6, 8), heff_take_field(v_acc_241, 8)));
  return ({ V rv_7 = v_infos_246; V rv_8 = v_trace_2411; V rr_ = heff_rec_reuse_n(v_acc_241, 127ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ekeepSt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithInstance_str0, 0, "");
V g_heff_2eelab_2etoplevel_2ewithInstance_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewithInstance_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithInstance_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewithInstance(V v_isInstance_240, V v_key_241, V v_name_242, V v_g_243) {
top: ;
  switch (heff_tag_of(v_isInstance_240)) {
  case TAG_True: {
    V v_t_246;
    if (heff_strEq_c(heff_dup(v_key_241), heff_dup(v_name_242))) {
      heff_drop(v_name_242);
      v_t_246 = ((V)&g_heff_2eelab_2etoplevel_2ewithInstance_str0);
    } else {
      V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_key_241)), heff_strLength(v_name_242));
      v_t_246 = heff_strSlice(heff_dup(v_key_241), MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL)));
    }
    return (g_heff_2eelab_2eglobals_2eaddInstance(v_key_241, v_t_246, v_g_243));
  }
  case TAG_False: {
    heff_drop(v_name_242);
    V v_t_248 = (g_list_2eany(heff_clo_n(g_heff_2eelab_2etoplevel_2ewithInstance_lam0, 1, 1, (V[]){heff_dup(v_key_241)}), heff_rfield(v_g_243, 6)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2etoplevel_2ewithInstance_lam1, 1, 1, (V[]){v_key_241}), heff_take_field(v_g_243, 6)));
      return ({ V rv_6 = v_t_2411; V rr_ = heff_rec_reuse_n(v_g_243, 63ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 6) = rv_6; rr_; });
    }
    case TAG_False: {
      heff_drop(v_key_241);
      return v_g_243;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_isInstance_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewithInstance(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ewithInstance_lam0(V self, V *args) {
  V v_i_247 = args[0];
  V v_key_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_247, 0, 2), v_key_241);
}
V g_heff_2eelab_2etoplevel_2ewithInstance_lam1(V self, V *args) {
  V v_i_249 = args[0];
  V v_key_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_i_249, 0, 2), v_key_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
Clo g_heff_2eelab_2etoplevel_2etopTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_Left: {
      V v_d_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      V v_t_247 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_245, heff_dup(v_acc_241)));
      V v_t_2411;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_248 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2412 = heff_get_n(v_t_2411, 1, 8);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
      V v_t_2414 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2413));
      V v_t_2416;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_246, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        heff_drop_rec(v_d_246, 5);
        v_t_2416 = NTAG(TAG_Nil);
      } else {
        v_t_2416 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_246, NTAG(TAG_Nil)});
      }
      V v_t_2417 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2414, v_t_2416));
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(heff_get_n(v_acc_241, 1, 9), v_t_2417));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken(v_kf_240, v_t_247, v_n_242, v_t_2418);
    }
    case TAG_Right: {
      V v_r_2419 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop(v_kf_240);
      V v_g_2420 = heff_take_field(v_acc_241, 0);
      V v_t_2421 = heff_take_field(v_r_2419, 2);
      V v_t_2424;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        V v_t_2422 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_r_2419, 1)), heff_rfield(v_g_2420, 1)));
        switch (heff_tag_of(v_t_2422)) {
        case TAG_Nothing: {
          v_t_2424 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2419, 1)), heff_dup(heff_rfield(v_r_2419, 4)), v_g_2420));
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2422, 0ULL, 1);
          v_t_2424 = v_g_2420;
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        break;
      }
      case TAG_False: {
        v_t_2424 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2419, 1)), heff_dup(heff_rfield(v_r_2419, 4)), v_g_2420));
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      V v_t_2425 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_r_2419, 0)), heff_dup(heff_rfield(v_r_2419, 1)), v_t_2424));
      V v_globals_2426 = (g_heff_2eelab_2etoplevel_2ewithInstance(heff_rfield(v_r_2419, 3), heff_dup(heff_rfield(v_r_2419, 1)), heff_dup(heff_rfield(v_r_2419, 0)), v_t_2425));
      V v_t_2430;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2427 = heff_dup(heff_field(v_st_245, 0));
        v_t_2430 = v_c_2427;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_xs_2431 = heff_get_n(v_t_2430, 1, 8);
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
      V v_t_2433 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2432));
      V v_t_2434 = heff_take_field(v_r_2419, 5);
      V v_t_2437;
      switch (heff_tag_of(v_t_2434)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2435 = heff_field(v_t_2434, 0);
        heff_take_n(v_t_2434, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2435, 0)), MK_INT(-1LL))) {
          heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
          heff_drop_rec(v_d_2435, 5);
          v_t_2437 = NTAG(TAG_Nil);
        } else {
          v_t_2437 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_Cons, 2, (V[]){v_d_2435, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      V v_t_2438 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2433, v_t_2437));
      V v_diags_2439 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_241, 1), v_t_2438));
      V v_t_2442;
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_n_242, 1);
        v_t_2442 = heff_dup(v_s_2441);
        break;
      }
      default: heff_nomatch(v_n_242);
      }
      V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_r_2419, 0), v_t_2442});
      V v_spans_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, heff_take_field(v_acc_241, 6)});
      V v_t_2448;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2445 = heff_dup(heff_field(v_st_245, 0));
        v_t_2448 = v_c_2445;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_infos_2449 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2448, 0, 8), heff_take_field(v_acc_241, 7)));
      V v_t_2453;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2450 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2453 = v_c_2450;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_trace_2454 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2453, 6, 8), heff_take_field(v_acc_241, 8)));
      V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_2419, 1, 6), heff_take_field(v_acc_241, 2)});
      return ({ V rv_0 = v_globals_2426; V rv_1 = v_diags_2439; V rv_2 = v_t_2455; V rv_6 = v_spans_2444; V rv_7 = v_infos_2449; V rv_8 = v_trace_2454; V rr_ = heff_rec_reuse_n(v_acc_241, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etopTake(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchTake_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_st_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop(v_sp_241);
      V v_t_249;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_246 = heff_dup(heff_field(v_st_244, 0));
        v_t_249 = v_c_246;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2410 = heff_get_n(v_t_249, 1, 8);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
      V v_t_2412 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2411));
      V v_t_2414;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2414 = NTAG(TAG_Nil);
      } else {
        v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2415 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2412, v_t_2414));
      V v_diags_2416 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2415));
      V v_t_2420;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2417 = heff_dup(heff_field(v_st_244, 0));
        v_t_2420 = v_c_2417;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2421 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2420, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2425;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2422 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2425 = v_c_2422;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2426 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2425, 6, 8), heff_take_field(v_acc_240, 8)));
      return ({ V rv_1 = v_diags_2416; V rv_7 = v_infos_2421; V rv_8 = v_trace_2426; V rr_ = heff_rec_reuse_n(v_acc_240, 125ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    case TAG_Right: {
      V v_entry_2427 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2428 = heff_dup(heff_field(v_st_244, 0));
        v_t_2431 = v_c_2428;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2432 = heff_get_n(v_t_2431, 1, 8);
      V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2432));
      V v_t_2434 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2433));
      V v_diags_2435 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2434));
      V v_t_2439;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2436 = heff_dup(heff_field(v_st_244, 0));
        v_t_2439 = v_c_2436;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2440 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2439, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2444;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2441 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2444 = v_c_2441;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2445 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2444, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2446 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_span__entry, (V[]){v_sp_241, v_entry_2427}), heff_dup(heff_rfield(v_acc_240, 4))});
      return ({ V rv_1 = v_diags_2435; V rv_4 = v_t_2446; V rv_7 = v_infos_2440; V rv_8 = v_trace_2445; V rr_ = heff_rec_reuse_n(v_acc_240, 109ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewatchTake(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0, 21, "errors recovered from");
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V v_k_240, V v_st_241) {
top: ;
  V v_c_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_c_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){heff_get_n(v_c_245, 1, 8)});
  V v_x1_247 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_241});
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_k_240);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2411; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
      if (heff_intEq_c(v_t_2412, MK_INT(0LL))) {
        heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
        return heff_tail(v_k_240, 2, (V[]){NTAG(TAG_MkUnit), v_st_249});
      } else {
        heff_drop(v_k_240);
        V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2414}), v_st_249});
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V v_key_240, V v_g_241, V v_n_242, V v_st_243) {
top: ;
  V v_c_247;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_c_244 = heff_dup(heff_field(v_st_243, 0));
    v_c_247 = v_c_244;
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  V v_t_248 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_247, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_x1_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_248}), v_st_243});
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_key_240);
      heff_drop(v_g_241);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2418;
      switch (heff_tag_of(v_st_2411)) {
      case TAG_MkSt: {
        V v_d_2416 = heff_field(v_st_2411, 1);
        V v_w_2417 = heff_field(v_st_2411, 2);
        V v_ru_24st_2411_24MkSt = heff_take_reuse_n(v_st_2411, 6ULL, 3);
        v_t_2418 = heff_tag_at_n(v_ru_24st_2411_24MkSt, TAG_MkSt, 3, (V[]){v_x_2413, v_d_2416, v_w_2417});
        break;
      }
      default: heff_nomatch(v_st_2411);
      }
      V v_x1_2419 = heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_t_2418});
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x11_2420 = heff_field(v_x1_2419, 0);
        V v_st_2421 = heff_field(v_x1_2419, 1);
        V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
        switch (heff_tag_of(v_x11_2420)) {
        case TAG_Left: {
          V v_e_2422 = heff_field(v_x11_2420, 0);
          heff_take_n(v_x11_2420, 1ULL, 1);
          heff_drop(v_key_240);
          heff_drop(v_g_241);
          return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2422}), v_st_2421});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2420, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2419_24MkPair, 2);
          V v_c_2424 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_242));
          return heff_tail(v_c_2424, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0, 1, 3, (V[]){v_g_241, heff_dup(v_n_242), v_key_240}), v_st_2421});
        }
        default: return heff_nomatch(v_x11_2420);
        }
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args) {
  V v_a_2461 = args[0];
  V v_a_2462 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2461}), v_a_2462});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args) {
  V v_x_2460 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2460);
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2425; V a_4 = v_x_2430; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4_clo); V r_ = (g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_n_242); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_2432 = args[1];
  V v_n_242 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2431);
  V v_t_2458;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2433 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_x11_2433)) {
    case TAG_DeclEquations: {
      V v_x113_2437 = heff_field(v_x11_2433, 2);
      V v_tyN_2438 = heff_field(v_x11_2433, 3);
      heff_take_n(v_x11_2433, 12ULL, 5);
      switch (heff_tag_of(v_x113_2437)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2438);
        v_t_2458 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2442;
        switch (heff_tag_of(v_tyN_2438)) {
        case TAG_At: {
          V v_s_2441 = heff_field(v_tyN_2438, 1);
          heff_take_n(v_tyN_2438, 2ULL, 2);
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_tyN_2438);
        }
        v_t_2458 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2442});
        break;
      }
      default: heff_nomatch(v_x113_2437);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2433, 0ULL, 5);
      v_t_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2433, 0ULL, 4);
      v_t_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2433, 0ULL, 3);
      v_t_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2433, 0ULL, 2);
      v_t_2458 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_t_2458 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2433);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V v_c_2459 = (g_heff_2eelab_2etoplevel_2emonomorphicInstance(v_t_2458, heff_dup(v_x_2430)));
  V f_ = v_c_2459;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3, 1, 5, (V[]){v_key_240, v_g_241, v_n_242, v_x_2425, v_x_2430});
  heff_room[2] = v_z_2432;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2, 2, 5, (V[]){v_n_242, v_x_2430, v_key_240, v_g_241, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = heff_dup(heff_rfield(v_x_2425, 1));
  V v_c_2429;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_MkTyp: {
    V v_f_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    V v_t_2428 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_241), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2429 = heff_tr(heff_call(v_f_2427, 1, (V[]){v_t_2428}));
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1, 1, 4, (V[]){v_n_242, v_key_240, v_g_241, v_x_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etopOne_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_lam0, 2, 0};
Clo g_heff_2eelab_2etoplevel_2etopOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopOne(V v_kf_240, V v_acc_241, V v_n_242) {
top: ;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_n1_243 = heff_dup(heff_field(v_n_242, 0));
    V v_sp_244 = heff_dup(heff_field(v_n_242, 1));
    switch (heff_tag_of(v_n1_243)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_243, 0ULL, 5);
      heff_drop(v_sp_244);
      V v_t_2410 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2410; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_243, 0ULL, 5);
      heff_drop(v_sp_244);
      V v_t_2416 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2416; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_243, 0ULL, 4);
      heff_drop(v_sp_244);
      V v_t_2421 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2421; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_243, 0ULL, 3);
      heff_drop(v_sp_244);
      V v_t_2425 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(heff_dup(v_kf_240), heff_dup(heff_rfield(v_acc_241, 0)), v_n_242, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_kf_240; V a_1 = v_acc_241; V a_2 = v_n_242; V a_3 = v_t_2425; V r_ = (g_heff_2eelab_2etoplevel_2etopTake(a_0, a_1, a_2, a_3)); heff_drop_tag(v_n_242, 2); r_; });
    }
    case TAG_DeclTest: {
      V v_x_2426 = heff_field(v_n1_243, 0);
      V v_ru_24n1_243_24DeclTest = heff_take_reuse_n(v_n1_243, 1ULL, 2);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_t_2428 = heff_tag_at_n(v_ru_24n1_243_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2426, v_sp_244}), heff_dup(heff_rfield(v_acc_241, 5))});
      return ({ V rv_5 = v_t_2428; V rr_ = heff_rec_reuse_n(v_acc_241, 479ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_DeclWatch: {
      V v_e_2429 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop(v_kf_240);
      heff_drop_tag(v_n_242, 2);
      V v_m_2430 = (g_heff_2eelab_2etoplevel_2eelabWatch(heff_dup(heff_rfield(v_acc_241, 0)), v_e_2429));
      V v_t_2433 = heff_tr(heff_call(v_m_2430, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2etopOne_lam0_clo), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())}));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_241, v_sp_244, v_t_2433);
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopOne_lam0(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_2432 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2431}), v_st_2432});
}
Clo g_heff_2eelab_2etoplevel_2etopGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopGo(V v_kf_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_kf_240);
    V v_diags_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 1)));
    V v_keys_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 2)));
    V v_broken_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 3)));
    V v_watches_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 4)));
    V v_tests_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 5)));
    V v_spans_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 6)));
    V v_infos_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 7)));
    V v_trace_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 8)));
    return ({ V rv_1 = v_diags_243; V rv_2 = v_keys_244; V rv_3 = v_broken_245; V rv_4 = v_watches_246; V rv_5 = v_tests_247; V rv_6 = v_spans_248; V rv_7 = v_infos_249; V rv_8 = v_trace_2410; V rr_ = heff_rec_reuse_n(v_acc_241, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2411 = heff_field(v_x3_242, 0);
    V v_rest_2412 = heff_field(v_x3_242, 1);
    V v_t_2413 = (g_heff_2eelab_2etoplevel_2etopOne(heff_dup(v_kf_240), v_acc_241, heff_dup(v_n_2411)));
    V t_0 = v_kf_240;
    V t_1 = v_t_2413;
    V t_2 = v_rest_2412;
    v_kf_240 = t_0;
    v_acc_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etopGo(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V v_acc_240, V v_n_241, V v_diags_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_243 = heff_field(v_n_241, 0);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_245)});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2410 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2410)});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2415 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2415)});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2419)});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2422 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2422)});
      break;
    }
    case TAG_DeclWatch: {
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    return ({ V rv_1 = v_diags_242; V rr_ = heff_rec_reuse_n(v_acc_240, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_g_2428;
    if (heff_strEq_c(heff_dup(v_x_2426), heff_dup(v_x_2426))) {
      v_g_2428 = heff_dup(heff_rfield(v_acc_240, 0));
    } else {
      v_g_2428 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2426), heff_dup(v_x_2426), heff_dup(heff_rfield(v_acc_240, 0))));
    }
    V v_t_2429 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2426), NTAG(TAG_MkUnit), heff_take_field(v_g_2428, 3)));
    V v_globals_2430 = ({ V rv_3 = v_t_2429; V rr_ = heff_rec_reuse_n(v_g_2428, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2433;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_2432 = heff_field(v_n_241, 1);
      v_t_2433 = heff_dup(v_s_2432);
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_broken_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_t_2433}), heff_take_field(v_acc_240, 3)});
    return ({ V rv_0 = v_globals_2430; V rv_1 = v_diags_242; V rv_3 = v_broken_2434; V rr_ = heff_rec_reuse_n(v_acc_240, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(V v_acc_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_st_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_t_246 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_244, heff_dup(v_acc_240)));
      V v_t_2410;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_247 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2410 = v_c_247;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2411 = heff_get_n(v_t_2410, 1, 8);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2411));
      V v_t_2413 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2412));
      V v_t_2415;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2415 = NTAG(TAG_Nil);
      } else {
        v_t_2415 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_t_2416 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2413, v_t_2415));
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(heff_get_n(v_acc_240, 1, 9), v_t_2416));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(v_t_246, v_n_241, v_t_2417);
    }
    case TAG_Right: {
      V v_r_2418 = heff_field(v_x41_243, 0);
      heff_take_n(v_x41_243, 1ULL, 1);
      V v_g_2419 = heff_take_field(v_acc_240, 0);
      V v_t_2420 = heff_take_field(v_r_2418, 2);
      V v_t_2423;
      switch (heff_tag_of(v_t_2420)) {
      case TAG_True: {
        V v_t_2421 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_r_2418, 1)), heff_rfield(v_g_2419, 1)));
        switch (heff_tag_of(v_t_2421)) {
        case TAG_Nothing: {
          v_t_2423 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 4)), v_g_2419));
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2421, 0ULL, 1);
          v_t_2423 = v_g_2419;
          break;
        }
        default: heff_nomatch(v_t_2421);
        }
        break;
      }
      case TAG_False: {
        v_t_2423 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 4)), v_g_2419));
        break;
      }
      default: heff_nomatch(v_t_2420);
      }
      V v_t_2424 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_r_2418, 0)), heff_dup(heff_rfield(v_r_2418, 1)), v_t_2423));
      V v_globals_2425 = (g_heff_2eelab_2etoplevel_2ewithInstance(heff_rfield(v_r_2418, 3), heff_dup(heff_rfield(v_r_2418, 1)), heff_dup(heff_rfield(v_r_2418, 0)), v_t_2424));
      V v_t_2429;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2426 = heff_dup(heff_field(v_st_244, 0));
        v_t_2429 = v_c_2426;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_xs_2430 = heff_get_n(v_t_2429, 1, 8);
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
      V v_t_2432 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2431));
      V v_t_2433 = heff_take_field(v_r_2418, 5);
      V v_t_2436;
      switch (heff_tag_of(v_t_2433)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2434 = heff_field(v_t_2433, 0);
        heff_take_n(v_t_2433, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2434, 0)), MK_INT(-1LL))) {
          heff_drop_cell(v_ru_24x4_242_24MkPair, 2);
          heff_drop_rec(v_d_2434, 5);
          v_t_2436 = NTAG(TAG_Nil);
        } else {
          v_t_2436 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_Cons, 2, (V[]){v_d_2434, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2433);
      }
      V v_t_2437 = (g_heff_2eelab_2etoplevel_2eappendT(v_t_2432, v_t_2436));
      V v_diags_2438 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2437));
      V v_t_2441;
      switch (heff_tag_of(v_n_241)) {
      case TAG_At: {
        V v_s_2440 = heff_field(v_n_241, 1);
        v_t_2441 = heff_dup(v_s_2440);
        break;
      }
      default: heff_nomatch(v_n_241);
      }
      V v_t_2442 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_r_2418, 0), v_t_2441});
      V v_spans_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, heff_take_field(v_acc_240, 6)});
      V v_t_2447;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2444 = heff_dup(heff_field(v_st_244, 0));
        v_t_2447 = v_c_2444;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2448 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2447, 0, 8), heff_take_field(v_acc_240, 7)));
      V v_t_2452;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2449 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2452 = v_c_2449;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2453 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2452, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_2418, 1, 6), heff_take_field(v_acc_240, 2)});
      return ({ V rv_0 = v_globals_2425; V rv_1 = v_diags_2438; V rv_2 = v_t_2454; V rv_6 = v_spans_2443; V rv_7 = v_infos_2448; V rv_8 = v_trace_2453; V rr_ = heff_rec_reuse_n(v_acc_240, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry, 8, 0};

V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V v_g_240, V v_d_241, V v_isInstance_242, V v_tyStx_243, V v_mc_244, V v_x7_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Left: {
    V v_failed_248 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_t_249 = heff_dup(heff_rfield(v_d_241, 3));
    V v_key_2410;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      v_key_2410 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_key_2410 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2411 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_2412;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      v_t_2412 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_t_2412 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_entry_2413 = ({ V a_0 = v_g_240; V a_1 = v_t_2412; V a_2 = v_tyStx_243; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_241, 0), v_key_2410, heff_get_n(v_d_241, 3, 4), v_isInstance_242, v_entry_2413, heff_tag_n(TAG_Just, 1, (V[]){v_failed_248})});
    return heff_tail(v_z_247, 1, (V[]){v_t_2414});
  }
  case TAG_Right: {
    V v_t_2415 = heff_field(v_x7_245, 0);
    heff_take_n(v_x7_245, 1ULL, 1);
    V v_t_2416 = heff_dup(heff_rfield(v_d_241, 3));
    V v_key_2417;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      v_key_2417 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_key_2417 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2418 = heff_dup(heff_rfield(v_d_241, 3));
    V v_t_2419;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_t_2419 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_t_2420 = heff_dup(heff_rfield(v_d_241, 3));
    V v_k_2421;
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      v_k_2421 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    case TAG_False: {
      v_k_2421 = heff_dup(heff_rfield(v_d_241, 0));
      break;
    }
    default: heff_nomatch(v_t_2420);
    }
    V v_t_2422 = (g_heff_2eelab_2eunify_2ezonker(v_mc_244));
    V v_t_2423 = heff_tr(heff_call(heff_get_n(v_t_2422, 0, 2), 1, (V[]){heff_get_n(v_t_2415, 0, 2)}));
    V v_t_2424 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_2421));
    V v_t_2425 = heff_tr(heff_call(heff_get_n(v_t_2424, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2423}));
    V v_entry_2426 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_240, v_t_2419, heff_rfield(v_d_241, 3), v_tyStx_243, v_t_2425));
    V v_t_2427 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_241, 0), v_key_2417, heff_get_n(v_d_241, 3, 4), v_isInstance_242, v_entry_2426, NTAG(TAG_Nothing)});
    return heff_tail(v_z_247, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V r = g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a[0], a[1], a[2], a[3], a4, a[5], a6, a[7]); heff_drop(a4); heff_drop(a6); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry, 6, 0};

V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(V v_g_240, V v_n_241, V v_d_242, V v_a_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_247 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_247 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_k_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0, 1, 1, (V[]){v_k_248})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(heff_rfield(v_z_244, 1)), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1, 1, 6, (V[]){v_z_244, heff_dup(v_n_241), v_d_242, v_a_243, v_g_240, v_z_245})});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam0(V self, V *args) {
  V v_c_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_7 = v_k_248; V rr_ = heff_rec_reuse_n(v_c_249, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3(V self, V *args) {
  V v_u_2426 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2426);
  V v_x1_2427 = heff_tr(heff_call(heff_get_n(v_a_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_Nom: {
    V v_x_2428 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    return v_x_2428;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2427, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2430 = heff_field(v_x1_2427, 0);
    heff_take_n(v_x1_2427, 1ULL, 1);
    return v_x_2430;
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5(V self, V *args) {
  V v_c_2451 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_2451, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9(V self, V *args) {
  V v_c_2465 = args[0];
  return heff_get_n(v_c_2465, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10(V self, V *args) {
  V v_x_2469 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_body_2448 = heff_env(self)[4];
  V v_hd_2449 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2495;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2470 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_2470)) {
    case TAG_DeclEquations: {
      V v_x113_2474 = heff_field(v_x11_2470, 2);
      V v_tyN_2475 = heff_field(v_x11_2470, 3);
      heff_take_n(v_x11_2470, 12ULL, 5);
      switch (heff_tag_of(v_x113_2474)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2475);
        v_t_2495 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2479;
        switch (heff_tag_of(v_tyN_2475)) {
        case TAG_At: {
          V v_s_2478 = heff_field(v_tyN_2475, 1);
          heff_take_n(v_tyN_2475, 2ULL, 2);
          v_t_2479 = v_s_2478;
          break;
        }
        default: heff_nomatch(v_tyN_2475);
        }
        v_t_2495 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2479});
        break;
      }
      default: heff_nomatch(v_x113_2474);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2470, 0ULL, 5);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2470, 0ULL, 4);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2470, 0ULL, 3);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2470, 0ULL, 2);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2470, 0ULL, 1);
      v_t_2495 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2470);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2497;
  switch (heff_tag_of(v_t_2495)) {
  case TAG_Nothing: {
    v_t_2497 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_2495, 0ULL, 1);
    v_t_2497 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2495);
  }
  V v_t_2498 = (g_heff_2eelab_2eunify_2ezonker(v_x_2469));
  V v_t_2499 = heff_tr(heff_call(heff_get_n(v_t_2498, 1, 2), 1, (V[]){heff_get_n(v_a_243, 0, 2)}));
  return ({ V a_0 = v_g_240; V a_1 = v_d_242; V a_2 = v_t_2497; V a_3 = v_t_2499; V a_4 = v_x_2469; V a_5 = v_body_2448; V a_6 = v_hd_2449; V a_7 = v_k_2450; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2469); heff_drop_rec(v_hd_2449, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8(V self, V *args) {
  V v_x_2464 = args[0];
  V v_hd_2449 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_body_2448 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2464);
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam9_clo)})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){v_t_2467}));
  V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
  heff_room[0] = v_t_2468;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam10, 1, 7, (V[]){v_n_241, v_a_243, v_g_240, v_d_242, v_body_2448, v_hd_2449, v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7(V self, V *args) {
  V v_x_2459 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_2449 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2448 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2459);
  V v_t_2462;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2461 = heff_dup(heff_field(v_n_241, 1));
    v_t_2462 = v_s_2461;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2463 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2462, heff_dup(v_d_242)));
  V f_ = v_c_2463;
  heff_room[0] = heff_dup(v_hd_2449);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam8, 1, 7, (V[]){v_hd_2449, v_n_241, v_a_243, v_g_240, v_d_242, v_body_2448, v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2449 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2448 = heff_env(self)[5];
  V v_k_2450 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2456 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2455, NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})}));
  V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
  heff_room[0] = v_t_2458;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam7, 1, 7, (V[]){v_n_241, v_d_242, v_hd_2449, v_a_243, v_g_240, v_body_2448, v_k_2450});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4(V self, V *args) {
  V v_body_2448 = args[0];
  V v_hd_2449 = args[1];
  V v_k_2450 = args[2];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam5_clo)})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2449, 2)), 1, (V[]){v_t_2453}));
  V f_ = heff_dup(heff_rfield(v_hd_2449, 1));
  args[0] = v_t_2454;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam6, 1, 7, (V[]){v_hd_2449, v_n_241, v_d_242, v_a_243, v_g_240, v_body_2448, v_k_2450});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  V v_t_2420;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2419 = heff_dup(heff_field(v_n_241, 1));
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2421 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2422;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    v_t_2422 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_2422 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2423 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2424;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    v_t_2424 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_2424 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_h_2425 = heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2424});
  V v_t_2431 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_2425, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam3, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
  V v_x1_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2436;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_x_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_t_2436 = v_x_2433;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2432, 0ULL, 1);
    v_t_2436 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_t_2436 = v_x_2435;
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V v_t_2437 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_243, 0)), v_t_2431, v_t_2436});
  V v_t_2438 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2422, v_t_2437, heff_dup(v_g_240)));
  V v_t_2439 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2440;
  switch (heff_tag_of(v_t_2439)) {
  case TAG_True: {
    v_t_2440 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  case TAG_False: {
    v_t_2440 = heff_dup(heff_rfield(v_d_242, 0));
    break;
  }
  default: heff_nomatch(v_t_2439);
  }
  V v_x1_2441 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2445;
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nom: {
    V v_x_2442 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2442;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2441, 0ULL, 1);
    v_t_2445 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2444 = heff_field(v_x1_2441, 0);
    heff_take_n(v_x1_2441, 1ULL, 1);
    v_t_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x1_2441);
  }
  V v_t_2446 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2420, heff_dup(v_d_242), v_t_2438, v_t_2440, v_t_2445));
  V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2446}));
  return (g_co_2ebind_24s1601686549x58384075(v_t_2447, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam4, 3, 4, (V[]){v_n_241, v_d_242, v_a_243, v_g_240}), v_z_244, v_z_245));
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})}));
  V f_ = heff_dup(heff_rfield(v_z_244, 1));
  heff_room[0] = v_t_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_lam2, 1, 6, (V[]){v_n_241, v_d_242, v_a_243, v_g_240, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V v_g_240, V v_n_241, V v_st_242) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_c_243 = heff_dup(heff_field(v_st_242, 0));
    v_c_246 = v_c_243;
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  V v_t_247 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_c_246, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_x1_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_247}), v_st_242});
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2417;
      switch (heff_tag_of(v_st_2410)) {
      case TAG_MkSt: {
        V v_d_2415 = heff_field(v_st_2410, 1);
        V v_w_2416 = heff_field(v_st_2410, 2);
        V v_ru_24st_2410_24MkSt = heff_take_reuse_n(v_st_2410, 6ULL, 3);
        v_t_2417 = heff_tag_at_n(v_ru_24st_2410_24MkSt, TAG_MkSt, 3, (V[]){v_x_2412, v_d_2415, v_w_2416});
        break;
      }
      default: heff_nomatch(v_st_2410);
      }
      V v_x1_2418 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_t_2417});
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_g_240);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
          V v_c_2423 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_241));
          return heff_tail(v_c_2423, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0, 1, 2, (V[]){v_g_240, heff_dup(v_n_241)}), v_st_2420});
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args) {
  V v_a_2460 = args[0];
  V v_a_2461 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2460}), v_a_2461});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args) {
  V v_x_2459 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2459);
  return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2424; V a_3 = v_x_2429; V a_4 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_5 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4_clo); V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_n_241); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_2431 = args[1];
  V v_n_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2430);
  V v_t_2457;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2432 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_DeclEquations: {
      V v_x113_2436 = heff_field(v_x11_2432, 2);
      V v_tyN_2437 = heff_field(v_x11_2432, 3);
      heff_take_n(v_x11_2432, 12ULL, 5);
      switch (heff_tag_of(v_x113_2436)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2437);
        v_t_2457 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2441;
        switch (heff_tag_of(v_tyN_2437)) {
        case TAG_At: {
          V v_s_2440 = heff_field(v_tyN_2437, 1);
          heff_take_n(v_tyN_2437, 2ULL, 2);
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_tyN_2437);
        }
        v_t_2457 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
        break;
      }
      default: heff_nomatch(v_x113_2436);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2432, 0ULL, 5);
      v_t_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2432, 0ULL, 4);
      v_t_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2432, 0ULL, 3);
      v_t_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2432, 0ULL, 2);
      v_t_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2432, 0ULL, 1);
      v_t_2457 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2432);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2458 = (g_heff_2eelab_2etoplevel_2emonomorphicInstance(v_t_2457, heff_dup(v_x_2429)));
  V f_ = v_c_2458;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3, 1, 4, (V[]){v_g_240, v_n_241, v_x_2424, v_x_2429});
  heff_room[2] = v_z_2431;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2, 2, 4, (V[]){v_n_241, v_x_2429, v_g_240, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_dup(heff_rfield(v_x_2424, 1));
  V v_c_2428;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_MkTyp: {
    V v_f_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_t_2427 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2428 = heff_tr(heff_call(v_f_2426, 1, (V[]){v_t_2427}));
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1, 1, 3, (V[]){v_n_241, v_g_240, v_x_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0, 2, 0};
Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V v_acc_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_DeclEquations: {
      heff_take_n(v_n1_242, 0ULL, 5);
      heff_drop(v_sp_243);
      V v_t_249 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_249; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclDefine: {
      heff_take_n(v_n1_242, 0ULL, 5);
      heff_drop(v_sp_243);
      V v_t_2415 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2415; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_n1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_t_2420 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2420; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_n1_242, 0ULL, 3);
      heff_drop(v_sp_243);
      V v_t_2424 = heff_tr(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(heff_dup(heff_rfield(v_acc_240, 0)), v_n_241, heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())));
      return ({ V a_0 = v_acc_240; V a_1 = v_n_241; V a_2 = v_t_2424; V r_ = (g_heff_2eelab_2etoplevel_2etopTake_24s1468412981x2044642763(a_0, a_1, a_2)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTest: {
      V v_x_2425 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24DeclTest = heff_take_reuse_n(v_n1_242, 1ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2427 = heff_tag_at_n(v_ru_24n1_242_24DeclTest, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_2425, v_sp_243}), heff_dup(heff_rfield(v_acc_240, 5))});
      return ({ V rv_5 = v_t_2427; V rr_ = heff_rec_reuse_n(v_acc_240, 479ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 5) = rv_5; rr_; });
    }
    case TAG_DeclWatch: {
      V v_e_2428 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_m_2429 = (g_heff_2eelab_2etoplevel_2eelabWatch(heff_dup(heff_rfield(v_acc_240, 0)), v_e_2428));
      V v_t_2432 = heff_tr(heff_call(v_m_2429, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0_clo), heff_dup(g_heff_2eelab_2eenvironment_2eemptySt_get())}));
      return (g_heff_2eelab_2etoplevel_2ewatchTake(v_acc_240, v_sp_243, v_t_2432));
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_lam0(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2431 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2430}), v_st_2431});
}
Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V v_acc_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_diags_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_keys_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
    V v_broken_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 3)));
    V v_watches_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 4)));
    V v_tests_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 5)));
    V v_spans_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
    V v_infos_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 7)));
    V v_trace_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 8)));
    return ({ V rv_1 = v_diags_242; V rv_2 = v_keys_243; V rv_3 = v_broken_244; V rv_4 = v_watches_245; V rv_5 = v_tests_246; V rv_6 = v_spans_247; V rv_7 = v_infos_248; V rv_8 = v_trace_249; V rr_ = heff_rec_reuse_n(v_acc_240, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2410 = heff_field(v_x3_241, 0);
    V v_rest_2411 = heff_field(v_x3_241, 1);
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(v_acc_240, heff_dup(v_n_2410)));
    V t_0 = v_t_2412;
    V t_1 = v_rest_2411;
    v_acc_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eisPrimB_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eisPrimB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eisPrimB(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawGlobals_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawGlobals(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 5)));
  V v_t_243 = ({ V a_0 = heff_dup(heff_rfield(v_acc_240, 0)); V a_1 = heff_dup(heff_rfield(v_d_241, 1)); V a_2 = v_t_242; V a_3 = heff_take_field(v_d_241, 4); V a_4 = heff_take_field(v_d_241, 5); V r_ = (g_heff_2eelab_2etoplevel_2eentryFor(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_242); r_; });
  V v_t_244 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_d_241, 1)), v_t_243, heff_get_n(v_acc_240, 0, 9)));
  V v_t_245 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_d_241, 0)), heff_dup(heff_rfield(v_d_241, 1)), v_t_244));
  return ({ V b_0 = heff_dup(heff_rfield(v_d_241, 2)); V a_1 = heff_dup(heff_rfield(v_d_241, 1)); V a_2 = heff_get_n(v_d_241, 0, 6); V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2ewithInstance(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawGlobals(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2ethawOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 5)));
  V v_t_246;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 1, 7);
    V v_t_244 = ({ V a_0 = heff_dup(heff_rfield(v_d_241, 1)); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    break;
  }
  case TAG_False: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    V v_g_247 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_d_241, 0)), heff_dup(heff_rfield(v_d_241, 1)), heff_take_field(v_acc_240, 0)));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_247; V rv_2 = v_t_248; V rv_6 = v_t_2410; V rr_ = heff_rec_reuse_n(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  case TAG_False: {
    V v_g_2411 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_240), heff_dup(v_d_241)));
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_2411; V rv_2 = v_t_2412; V rv_6 = v_t_2414; V rr_ = heff_rec_reuse_n(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawOne(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2ethawDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawDone_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ethawDone(V v_acc_240) {
top: ;
  V v_keys_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
  V v_spans_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
  return ({ V rv_2 = v_keys_241; V rv_6 = v_spans_242; V rr_ = heff_rec_reuse_n(v_acc_240, 443ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawDone(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyDump_str0, 20, "<no such definition>");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyDump_str1, 20, "<no such definition>");
Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ebodyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_241, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_242, 7);
      return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str0);
    }
    case TAG_Just: {
      V v_k2_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_246 = ({ V a_0 = v_k2_245; V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2eelab_2etoplevel_2ebodyDump_str1);
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        return ({ V b_0 = heff_get_n(v_e_247, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop_rec(v_g_242, 7);
    return ({ V b_0 = heff_get_n(v_e_248, 0, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTermF_24s9591952x1664582485(b_0)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyDump(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etyDump_str0, 20, "<no such definition>");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etyDump_str1, 20, "<no such definition>");
Clo g_heff_2eelab_2etoplevel_2etyDump_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etyDump_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etyDump(V v_t_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(v_t_240, 0, 9);
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_241, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_242, 7);
      return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str0);
    }
    case TAG_Just: {
      V v_k2_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_246 = ({ V a_0 = v_k2_245; V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2eelab_2etoplevel_2etyDump_str1);
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        return ({ V b_0 = heff_get_n(v_e_247, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_248 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop_rec(v_g_242, 7);
    return ({ V b_0 = heff_get_n(v_e_248, 1, 4); V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(b_0)); heff_drop(b_0); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etyDump(a[0], a[1]);
}