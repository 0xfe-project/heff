// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_prelude_2ejoinWith_2eafter_240_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ejoinWith_2eafter_240_entry, 3, 0};

V g_prelude_2ejoinWith_2eafter_240(V v_sep_240, V v_acc_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_sep_240);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_242, 0);
    V v_ys_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_strAppend(v_acc_241, heff_strAppend(heff_dup(v_sep_240), heff_dup(v_y_243)));
    V t_0 = v_sep_240;
    V t_1 = v_t_245;
    V t_2 = v_ys_244;
    v_sep_240 = t_0;
    v_acc_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2ejoinWith_2eafter_240(a[0], a[1], a2); heff_drop(a2); return r;
}