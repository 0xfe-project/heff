// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo;
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_std_2ecli_2einteractive_2equoted(V);
V g_std_2ecli_2einteractive_2equoted_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2equoted_clo;
Clo g_prelude_2ejoinWith_2eafter_240_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ejoinWith_2eafter_240_entry, 3, 0};

V g_prelude_2ejoinWith_2eafter_240(V v_sep_240, V v_acc_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_sep_240);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_242, 0);
    V v_ys_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_strAppend(v_acc_241, heff_strAppend(heff_dup(v_sep_240), heff_dup(v_y_243)));
    V t_0 = v_sep_240;
    V t_1 = v_t_245;
    V t_2 = v_ys_244;
    v_sep_240 = t_0;
    v_acc_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2ejoinWith_2eafter_240(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry, 4, 0};

V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(V v_sep_240, V v_acc_241, V v_f_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_sep_240);
    heff_drop(v_f_242);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_y_246 = heff_tr(heff_call(heff_dup(v_f_242), 1, (V[]){heff_dup(v_x_244)}));
    V v_t_247 = heff_strAppend(v_acc_241, heff_strAppend(heff_dup(v_sep_240), v_y_246));
    V t_0 = v_sep_240;
    V t_1 = v_t_247;
    V t_2 = v_f_242;
    V t_3 = v_xs_245;
    v_sep_240 = t_0;
    v_acc_241 = t_1;
    v_f_242 = t_2;
    v_x2_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_prelude_2ejoinWith_2eafter_240_24f278239504x1711509818(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry, 4, 0};

V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V v_sep_240, V v_acc_241, V v_x1_242, V v_ys_243) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    return (g_prelude_2ejoinWith_2eafter_240(v_sep_240, v_acc_241, v_ys_243));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_242, 0);
    V v_xs_245 = heff_field(v_x1_242, 1);
    V v_t_246 = heff_strAppend(v_acc_241, heff_strAppend(heff_dup(v_sep_240), heff_dup(v_x_244)));
    V t_0 = v_sep_240;
    V t_1 = v_t_246;
    V t_2 = v_xs_245;
    V t_3 = v_ys_243;
    v_sep_240 = t_0;
    v_acc_241 = t_1;
    v_x1_242 = t_2;
    v_ys_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry, 3, 0};

V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V v_sep_240, V v_acc_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_sep_240);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_y_245 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_x_243));
    V v_t_246 = heff_strAppend(v_acc_241, heff_strAppend(heff_dup(v_sep_240), v_y_245));
    V t_0 = v_sep_240;
    V t_1 = v_t_246;
    V t_2 = v_xs_244;
    v_sep_240 = t_0;
    v_acc_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry, 3, 0};

V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(V v_sep_240, V v_acc_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_sep_240);
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_y_245 = (g_std_2ecli_2einteractive_2equoted(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(v_acc_241, heff_strAppend(heff_dup(v_sep_240), v_y_245));
    V t_0 = v_sep_240;
    V t_1 = v_t_246;
    V t_2 = v_xs_244;
    v_sep_240 = t_0;
    v_acc_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_prelude_2ejoinWith_2eafter_240_24f2111990454x1671124200(a[0], a[1], a2); heff_drop(a2); return r;
}