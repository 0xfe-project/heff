// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Close 2276
#define TAG_Finish 61316
#define TAG_Get 18914
#define TAG_Open 48267
#define TAG_Put 28059
#define TAG_ReadStdin 20528
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Sleep 25229
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_cwd 308458
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_fmap 9641981
#define LBL_heff 9694020
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_shutdown 575795380
#define LBL_style 311138763
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
V g_app_2eheff_2emain_2edispatch_24s1822917622x1005933181(V, V, V, V, V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s1822917622x1005933181_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s1822917622x1005933181_clo;
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(void);
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_get(void);
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(void);
V g_co_2e_3c_2b_3e_24s1424093495x1299667173_get(void);
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(void);
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void);
V g_co_2e_3c_2b_3e_24s33412700x2062750937_get(void);
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void);
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void);
V g_co_2e_3c_2b_3e_24s787064636x102052035_get(void);
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_co_2eop_24s1067007848x1099704198(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1067007848x1099704198_entry(V self, V *a);
extern Clo g_co_2eop_24s1067007848x1099704198_clo;
V g_co_2eop_24s1110804312x932325868(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1110804312x932325868_entry(V self, V *a);
extern Clo g_co_2eop_24s1110804312x932325868_clo;
V g_co_2eop_24s1178127530x1610393171(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1178127530x1610393171_entry(V self, V *a);
extern Clo g_co_2eop_24s1178127530x1610393171_clo;
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s14038175x385665938(V, V, V, V, V, V);
V g_co_2eop_24s14038175x385665938_entry(V self, V *a);
extern Clo g_co_2eop_24s14038175x385665938_clo;
V g_co_2eop_24s1549572115x1242285242(V, V, V, V);
V g_co_2eop_24s1549572115x1242285242_entry(V self, V *a);
extern Clo g_co_2eop_24s1549572115x1242285242_clo;
V g_co_2eop_24s1628839587x1321325607(V, V, V, V);
V g_co_2eop_24s1628839587x1321325607_entry(V self, V *a);
extern Clo g_co_2eop_24s1628839587x1321325607_clo;
V g_co_2eop_24s1703844634x634335703(V, V, V);
V g_co_2eop_24s1703844634x634335703_entry(V self, V *a);
extern Clo g_co_2eop_24s1703844634x634335703_clo;
V g_co_2eop_24s1755542109x365432933(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1755542109x365432933_entry(V self, V *a);
extern Clo g_co_2eop_24s1755542109x365432933_clo;
V g_co_2eop_24s17678202x252484985(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s17678202x252484985_entry(V self, V *a);
extern Clo g_co_2eop_24s17678202x252484985_clo;
V g_co_2eop_24s1932151623x486962575(V, V, V);
V g_co_2eop_24s1932151623x486962575_entry(V self, V *a);
extern Clo g_co_2eop_24s1932151623x486962575_clo;
V g_co_2eop_24s2088512805x623284879(V, V, V, V, V, V);
V g_co_2eop_24s2088512805x623284879_entry(V self, V *a);
extern Clo g_co_2eop_24s2088512805x623284879_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s540628709x1742946060(V, V, V);
V g_co_2eop_24s540628709x1742946060_entry(V self, V *a);
extern Clo g_co_2eop_24s540628709x1742946060_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s760975558x1999937727(V, V, V, V, V, V);
V g_co_2eop_24s760975558x1999937727_entry(V self, V *a);
extern Clo g_co_2eop_24s760975558x1999937727_clo;
V g_co_2eop_24s826344058x1453420202(V, V, V);
V g_co_2eop_24s826344058x1453420202_entry(V self, V *a);
extern Clo g_co_2eop_24s826344058x1453420202_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_co_2eop_24s903307437x182144838(V, V, V, V, V, V);
V g_co_2eop_24s903307437x182144838_entry(V self, V *a);
extern Clo g_co_2eop_24s903307437x182144838_clo;
V g_co_2eop_24s992437918x598211615(V, V, V);
V g_co_2eop_24s992437918x598211615_entry(V self, V *a);
extern Clo g_co_2eop_24s992437918x598211615_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788(V, V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788_clo;
V g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347(V, V);
V g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347_clo;
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_resource_2eheldBy_24s650049234x1642226888(V, V, V, V, V);
V g_resource_2eheldBy_24s650049234x1642226888_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s650049234x1642226888_clo;
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2emap_2eempty_get(void);
V g_std_2enet_2enet_get(void);
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprogress_2eprogress_get(void);
V g_std_2ereactor_2ereactor_get(void);
V g_std_2eterminal_2econsole_get(void);
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args); static Clo g_co_2eop_24s310169282x2049378029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_lam0, 4, 0};
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args);
Clo g_co_2eop_24s310169282x2049378029_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_entry, 4, 0};

V g_co_2eop_24s310169282x2049378029(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s310169282x2049378029_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s310169282x2049378029_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s310169282x2049378029_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, v_k2_243});
}
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s310169282x2049378029(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1549572115x1242285242_lam1(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam0(V self, V *args); static Clo g_co_2eop_24s1549572115x1242285242_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1549572115x1242285242_lam0, 4, 0};
V g_co_2eop_24s1549572115x1242285242_lam3(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam2(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam4(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam5(V self, V *args);
Clo g_co_2eop_24s1549572115x1242285242_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1549572115x1242285242_entry, 4, 0};

V g_co_2eop_24s1549572115x1242285242(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1549572115x1242285242_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam5, 1, 1, (V[]){v_k2_243})});
}
V g_co_2eop_24s1549572115x1242285242_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1549572115x1242285242(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1549572115x1242285242_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1549572115x1242285242_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1549572115x1242285242_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1549572115x1242285242_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1549572115x1242285242_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1549572115x1242285242_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k2_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_243;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s419270740x1449981722_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s419270740x1449981722_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam4(V self, V *args);
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s419270740x1449981722_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s419270740x1449981722_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s419270740x1449981722_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s419270740x1449981722_st;
static V g_co_2e_3c_2b_3e_24s419270740x1449981722_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s419270740x1449981722_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s419270740x1449981722_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s419270740x1449981722_st)) return g_co_2e_3c_2b_3e_24s419270740x1449981722_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s419270740x1449981722_val, &g_co_2e_3c_2b_3e_24s419270740x1449981722_st, g_co_2e_3c_2b_3e_24s419270740x1449981722_init);
}
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam1(V self, V *args) {
  V v_st_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_st_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_h_2414 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tr(heff_call(v_h_2414, 1, (V[]){v_s_2416}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop_rec(v_m_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Get = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Get, TAG_Get, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s419270740x1449981722_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
      break;
    }
    case TAG_Put: {
      V v_st_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_247, v_t_249});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24Throw = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2418 = heff_tag_at_n(v_ru_24y_2411_24Throw, TAG_Throw, 1, (V[]){v_s_2412});
      break;
    }
    case TAG_Catch: {
      V v_c_2413 = heff_field(v_y_2411, 0);
      V v_h_2414 = heff_field(v_y_2411, 1);
      V v_ru_24y_2411_24Catch = heff_take_reuse_n(v_y_2411, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_2413}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_2411_24Catch, TAG_Catch, 2, (V[]){v_t_2415, heff_clo_n(g_co_2e_3c_2b_3e_24s419270740x1449981722_lam2, 1, 3, (V[]){v_h_2414, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_h_2427 = heff_env(self)[0];
  V v_nt_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_call(v_h_2427, 1, (V[]){v_s_2429}));
  V f_ = v_nt_2421;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s419270740x1449981722_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  heff_drop(v_m_2419);
  heff_drop(v_n_2420);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_x_2423});
  }
  case TAG_InR: {
    V v_y_2424 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_y_2424)) {
    case TAG_Throw: {
      V v_s_2425 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Throw = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      heff_drop(v_nt_2421);
      v_t_2431 = heff_tag_at_n(v_ru_24y_2424_24Throw, TAG_Throw, 1, (V[]){v_s_2425});
      break;
    }
    case TAG_Catch: {
      V v_c_2426 = heff_field(v_y_2424, 0);
      V v_h_2427 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24Catch = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      V v_t_2428 = heff_tr(heff_call(heff_dup(v_nt_2421), 1, (V[]){v_c_2426}));
      v_t_2431 = heff_tag_at_n(v_ru_24y_2424_24Catch, TAG_Catch, 2, (V[]){v_t_2428, heff_clo_n(g_co_2e_3c_2b_3e_24s419270740x1449981722_lam4, 1, 2, (V[]){v_h_2427, v_nt_2421})});
      break;
    }
    default: heff_nomatch(v_y_2424);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2ebind_24s1421083649x484987773_lam0(V self, V *args);
Clo g_co_2ebind_24s1421083649x484987773_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1421083649x484987773_entry, 4, 0};

V g_co_2ebind_24s1421083649x484987773(V v_c_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_co_2ebind_24s1421083649x484987773_lam0, 1, 3, (V[]){v_f_241, v_hd_242, v_k_243})});
}
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1421083649x484987773(a[0], a[1], a[2], a[3]);
}
V g_co_2ebind_24s1421083649x484987773_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_241;
  heff_room[0] = v_x_244;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1628839587x1321325607_lam0(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam2(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam1(V self, V *args); static Clo g_co_2eop_24s1628839587x1321325607_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1628839587x1321325607_lam1, 4, 0};
V g_co_2eop_24s1628839587x1321325607_lam4(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam3(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam5(V self, V *args);
Clo g_co_2eop_24s1628839587x1321325607_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1628839587x1321325607_entry, 4, 0};

V g_co_2eop_24s1628839587x1321325607(V v_lit_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_p_241)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InL = heff_take_reuse_n(v_p_241, 1ULL, 1);
    heff_drop_rec(v_lit_240, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Throw: {
      V v_s_245 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Throw = heff_take_reuse_n(v_x_244, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Throw, TAG_Throw, 1, (V[]){v_s_245});
      break;
    }
    case TAG_Catch: {
      V v_c_246 = heff_field(v_x_244, 0);
      V v_h_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24Catch = heff_take_reuse_n(v_x_244, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_dup(heff_rfield(v_hd_242, 0))}));
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Catch, TAG_Catch, 2, (V[]){v_t_248, heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam0, 1, 2, (V[]){v_h_247, heff_dup(v_hd_242)})});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InL, TAG_InL, 1, (V[]){v_t_2411});
    break;
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InR = heff_take_reuse_n(v_p_241, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_lit_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1628839587x1321325607_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam3, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam5, 1, 1, (V[]){heff_dup(v_hd_242)}), v_y_2412}));
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InR, TAG_InR, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_p_241);
  }
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2426, v_k2_243});
}
V g_co_2eop_24s1628839587x1321325607_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1628839587x1321325607(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1628839587x1321325607_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_h_247 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2410 = heff_tr(heff_call(v_h_247, 1, (V[]){v_s_249}));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1628839587x1321325607_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2417}));
  V f_ = v_k_2416;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1628839587x1321325607_lam1(V self, V *args) {
  V v_g_2413 = args[0];
  V v_c_2414 = args[1];
  V v_hd_2415 = args[2];
  V v_k_2416 = args[3];
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam2, 1, 2, (V[]){v_g_2413, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1628839587x1321325607_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2419 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2421}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1628839587x1321325607_lam3(V self, V *args) {
  V v_g_2419 = args[0];
  V v_m_2420 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2420;
  args[1] = heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam4, 1, 2, (V[]){v_g_2419, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1628839587x1321325607_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s1004019096x1485078532_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1004019096x1485078532_st;
static V g_co_2e_3c_2b_3e_24s1004019096x1485078532_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1004019096x1485078532_st)) return g_co_2e_3c_2b_3e_24s1004019096x1485078532_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1004019096x1485078532_val, &g_co_2e_3c_2b_3e_24s1004019096x1485078532_st, g_co_2e_3c_2b_3e_24s1004019096x1485078532_init);
}
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2414;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Write: {
        V v_str_245 = heff_field(v_x_244, 0);
        V v_x_246 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24Write = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_246}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24Write, TAG_Write, 2, (V[]){v_str_245, v_t_247});
        break;
      }
      case TAG_WriteErr: {
        V v_str_248 = heff_field(v_x_244, 0);
        V v_x_249 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24WriteErr = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_249}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_248, v_t_2410});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2411 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam1, 1, 2, (V[]){v_k_2411, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_InR: {
      V v_y_2415 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
      v_t_2417 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2418}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_lam2(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  heff_drop(v_m_2420);
  heff_drop(v_n_2421);
  heff_drop(v_nt_2422);
  return v_p_2423;
}
V g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam1(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam1, 4, 0};

static V g_co_2e_3c_2b_3e_24s1424093495x1299667173_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1424093495x1299667173_st;
static V g_co_2e_3c_2b_3e_24s1424093495x1299667173_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam1_clo)});
}
V g_co_2e_3c_2b_3e_24s1424093495x1299667173_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1424093495x1299667173_st)) return g_co_2e_3c_2b_3e_24s1424093495x1299667173_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1424093495x1299667173_val, &g_co_2e_3c_2b_3e_24s1424093495x1299667173_st, g_co_2e_3c_2b_3e_24s1424093495x1299667173_init);
}
V g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_x_244)) {
      case TAG_InL: {
        V v_x_245 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_245}));
        v_t_249 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_246});
        break;
      }
      case TAG_InR: {
        V v_y_247 = heff_field(v_x_244, 0);
        V v_ru_24x_244_24InR = heff_take_reuse_n(v_x_244, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_247}));
        v_t_249 = heff_tag_at_n(v_ru_24x_244_24InR, TAG_InR, 1, (V[]){v_t_248});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_InL, 1, (V[]){v_t_249});
      break;
    }
    case TAG_InR: {
      V v_y_2410 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2414;
      switch (heff_tag_of(v_y_2410)) {
      case TAG_Sleep: {
        V v_ms_2411 = heff_field(v_y_2410, 0);
        V v_x_2412 = heff_field(v_y_2410, 1);
        V v_ru_24y_2410_24Sleep = heff_take_reuse_n(v_y_2410, 3ULL, 2);
        V v_t_2413 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2412}));
        v_t_2414 = heff_tag_at_n(v_ru_24y_2410_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2411, v_t_2413});
        break;
      }
      default: heff_nomatch(v_y_2410);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2416}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1424093495x1299667173_lam1(V self, V *args) {
  V v_m_2418 = args[0];
  V v_n_2419 = args[1];
  V v_nt_2420 = args[2];
  V v_p_2421 = args[3];
  switch (heff_tag_of(v_p_2421)) {
  case TAG_InL: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InL = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2435;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_InL: {
      V v_x_2423 = heff_field(v_x_2422, 0);
      V v_ru_24x_2422_24InL = heff_take_reuse_n(v_x_2422, 1ULL, 1);
      V v_t_2433;
      switch (heff_tag_of(v_x_2423)) {
      case TAG_InL: {
        V v_x_2424 = heff_field(v_x_2423, 0);
        V v_ru_24x_2423_24InL = heff_take_reuse_n(v_x_2423, 1ULL, 1);
        V v_t_2431;
        switch (heff_tag_of(v_x_2424)) {
        case TAG_InL: {
          V v_x_2425 = heff_field(v_x_2424, 0);
          V v_ru_24x_2424_24InL = heff_take_reuse_n(v_x_2424, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_x_2425)) {
          case TAG_InL: {
            V v_x_2426 = heff_field(v_x_2425, 0);
            heff_take_n(v_x_2425, 1ULL, 1);
            heff_drop(v_m_2418);
            heff_drop(v_n_2419);
            heff_drop(v_nt_2420);
            heff_drop_cell(v_ru_24x_2424_24InL, 1);
            v_t_2429 = heff_tag_at_n(v_ru_24p_2421_24InL, TAG_InL, 1, (V[]){v_x_2426});
            break;
          }
          case TAG_InR: {
            V v_y_2427 = heff_field(v_x_2425, 0);
            heff_take_n(v_x_2425, 1ULL, 1);
            heff_drop_cell(v_ru_24p_2421_24InL, 1);
            V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2418, v_n_2419, v_nt_2420, v_y_2427}));
            v_t_2429 = heff_tag_at_n(v_ru_24x_2424_24InL, TAG_InR, 1, (V[]){v_t_2428});
            break;
          }
          default: heff_nomatch(v_x_2425);
          }
          v_t_2431 = heff_tag_at_n(v_ru_24x_2422_24InL, TAG_InL, 1, (V[]){v_t_2429});
          break;
        }
        case TAG_InR: {
          V v_y_2430 = heff_field(v_x_2424, 0);
          V v_ru_24x_2424_24InR = heff_take_reuse_n(v_x_2424, 1ULL, 1);
          heff_drop(v_m_2418);
          heff_drop(v_n_2419);
          heff_drop(v_nt_2420);
          heff_drop_cell(v_ru_24p_2421_24InL, 1);
          heff_drop_cell(v_ru_24x_2422_24InL, 1);
          v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24InR, TAG_InR, 1, (V[]){v_y_2430});
          break;
        }
        default: heff_nomatch(v_x_2424);
        }
        v_t_2433 = heff_tag_at_n(v_ru_24x_2423_24InL, TAG_InL, 1, (V[]){v_t_2431});
        break;
      }
      case TAG_InR: {
        V v_y_2432 = heff_field(v_x_2423, 0);
        V v_ru_24x_2423_24InR = heff_take_reuse_n(v_x_2423, 1ULL, 1);
        heff_drop(v_m_2418);
        heff_drop(v_n_2419);
        heff_drop(v_nt_2420);
        heff_drop_cell(v_ru_24p_2421_24InL, 1);
        heff_drop_cell(v_ru_24x_2422_24InL, 1);
        v_t_2433 = heff_tag_at_n(v_ru_24x_2423_24InR, TAG_InR, 1, (V[]){v_y_2432});
        break;
      }
      default: heff_nomatch(v_x_2423);
      }
      v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2433});
      break;
    }
    case TAG_InR: {
      V v_y_2434 = heff_field(v_x_2422, 0);
      V v_ru_24x_2422_24InR = heff_take_reuse_n(v_x_2422, 1ULL, 1);
      heff_drop(v_m_2418);
      heff_drop(v_n_2419);
      heff_drop(v_nt_2420);
      heff_drop_cell(v_ru_24p_2421_24InL, 1);
      v_t_2435 = heff_tag_at_n(v_ru_24x_2422_24InR, TAG_InR, 1, (V[]){v_y_2434});
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2435});
  }
  case TAG_InR: {
    V v_y_2436 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InR = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    heff_drop(v_m_2418);
    heff_drop(v_n_2419);
    heff_drop(v_nt_2420);
    return heff_tag_at_n(v_ru_24p_2421_24InR, TAG_InR, 1, (V[]){v_y_2436});
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s787064636x102052035_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s787064636x102052035_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam1(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s787064636x102052035_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s787064636x102052035_lam1, 4, 0};

static V g_co_2e_3c_2b_3e_24s787064636x102052035_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s787064636x102052035_st;
static V g_co_2e_3c_2b_3e_24s787064636x102052035_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s787064636x102052035_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s787064636x102052035_lam1_clo)});
}
V g_co_2e_3c_2b_3e_24s787064636x102052035_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s787064636x102052035_st)) return g_co_2e_3c_2b_3e_24s787064636x102052035_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s787064636x102052035_val, &g_co_2e_3c_2b_3e_24s787064636x102052035_st, g_co_2e_3c_2b_3e_24s787064636x102052035_init);
}
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1424093495x1299667173_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam3(V self, V *args) {
  V v_c_2418 = args[0];
  V v_k_2419 = args[1];
  V v_nt_249 = heff_env(self)[0];
  V v_use_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tr(heff_call(v_nt_249, 1, (V[]){v_c_2418}));
  V f_ = v_use_2417;
  args[0] = v_t_2420;
  args[1] = v_k_2419;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam2(V self, V *args) {
  V v_use_2417 = args[0];
  V v_b_2416 = heff_env(self)[0];
  V v_nt_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2416;
  args[0] = heff_clo_n(g_co_2e_3c_2b_3e_24s787064636x102052035_lam3, 2, 2, (V[]){v_nt_249, v_use_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s787064636x102052035_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1424093495x1299667173_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_x_2411}));
    return heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2412});
  }
  case TAG_InR: {
    V v_y_2413 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    V v_t_2426;
    switch (heff_tag_of(v_y_2413)) {
    case TAG_Open: {
      V v_k_2414 = heff_field(v_y_2413, 0);
      V v_ru_24y_2413_24Open = heff_take_reuse_n(v_y_2413, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2426 = heff_tag_at_n(v_ru_24y_2413_24Open, TAG_Open, 1, (V[]){v_k_2414});
      break;
    }
    case TAG_Start: {
      V v_i_2415 = heff_field(v_y_2413, 0);
      V v_b_2416 = heff_field(v_y_2413, 1);
      V v_ru_24y_2413_24Start = heff_take_reuse_n(v_y_2413, 3ULL, 2);
      v_t_2426 = heff_tag_at_n(v_ru_24y_2413_24Start, TAG_Start, 2, (V[]){v_i_2415, heff_clo_n(g_co_2e_3c_2b_3e_24s787064636x102052035_lam2, 1, 2, (V[]){v_b_2416, v_nt_249})});
      break;
    }
    case TAG_Finish: {
      V v_i_2421 = heff_field(v_y_2413, 0);
      V v_w_2422 = heff_field(v_y_2413, 1);
      V v_f_2423 = heff_field(v_y_2413, 2);
      V v_ru_24y_2413_24Finish = heff_take_reuse_n(v_y_2413, 7ULL, 3);
      heff_drop(v_nt_249);
      v_t_2426 = heff_tag_at_n(v_ru_24y_2413_24Finish, TAG_Finish, 3, (V[]){v_i_2421, v_w_2422, v_f_2423});
      break;
    }
    case TAG_Close: {
      V v_i_2424 = heff_field(v_y_2413, 0);
      V v_x_2425 = heff_field(v_y_2413, 1);
      V v_ru_24y_2413_24Close = heff_take_reuse_n(v_y_2413, 3ULL, 2);
      heff_drop(v_nt_249);
      v_t_2426 = heff_tag_at_n(v_ru_24y_2413_24Close, TAG_Close, 2, (V[]){v_i_2424, v_x_2425});
      break;
    }
    default: heff_nomatch(v_y_2413);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2426});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eop_24s1932151623x486962575_lam1(V self, V *args);
V g_co_2eop_24s1932151623x486962575_lam0(V self, V *args); static Clo g_co_2eop_24s1932151623x486962575_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1932151623x486962575_lam0, 4, 0};
V g_co_2eop_24s1932151623x486962575_lam3(V self, V *args);
V g_co_2eop_24s1932151623x486962575_lam2(V self, V *args);
V g_co_2eop_24s1932151623x486962575_lam4(V self, V *args);
Clo g_co_2eop_24s1932151623x486962575_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1932151623x486962575_entry, 3, 0};

V g_co_2eop_24s1932151623x486962575(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2417;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1932151623x486962575_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1932151623x486962575_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1932151623x486962575_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_243}));
    v_t_2417 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    v_t_2417 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_y_2416});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2418, v_k2_242});
}
V g_co_2eop_24s1932151623x486962575_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1932151623x486962575(a[0], a[1], a[2]);
}
V g_co_2eop_24s1932151623x486962575_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1932151623x486962575_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s1932151623x486962575_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1932151623x486962575_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1932151623x486962575_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1932151623x486962575_lam3, 1, 2, (V[]){v_g_2410, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1932151623x486962575_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s1117694589x1745783676_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1117694589x1745783676_st;
static V g_co_2e_3c_2b_3e_24s1117694589x1745783676_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1117694589x1745783676_st)) return g_co_2e_3c_2b_3e_24s1117694589x1745783676_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1117694589x1745783676_val, &g_co_2e_3c_2b_3e_24s1117694589x1745783676_st, g_co_2e_3c_2b_3e_24s1117694589x1745783676_init);
}
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam1(V self, V *args) {
  V v_r_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_r_2415}));
  V f_ = v_g_241;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2eprogress_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_InL: {
      V v_x_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24InL = heff_take_reuse_n(v_y_245, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_x_246)) {
      case TAG_InL: {
        V v_x_247 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InR, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1424093495x1299667173_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_247}));
        v_t_2411 = heff_tag_at_n(v_ru_24y_245_24InL, TAG_InL, 1, (V[]){v_t_248});
        break;
      }
      case TAG_InR: {
        V v_y_249 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 1);
        heff_drop_cell(v_ru_24y_245_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_249}));
        v_t_2411 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2410});
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2411});
      break;
    }
    case TAG_InR: {
      V v_y_2412 = heff_field(v_y_245, 0);
      heff_take_n(v_y_245, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2417;
      switch (heff_tag_of(v_y_2412)) {
      case TAG_Send: {
        V v_rq_2413 = heff_field(v_y_2412, 0);
        V v_k_2414 = heff_field(v_y_2412, 1);
        V v_ru_24y_2412_24Send = heff_take_reuse_n(v_y_2412, 3ULL, 2);
        v_t_2417 = heff_tag_at_n(v_ru_24y_2412_24Send, TAG_Send, 2, (V[]){v_rq_2413, heff_clo_n(g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam1, 1, 2, (V[]){v_k_2414, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_2412);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_lam2(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_x_2423});
  }
  case TAG_InR: {
    V v_y_2424 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2428;
    switch (heff_tag_of(v_y_2424)) {
    case TAG_InL: {
      V v_x_2425 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24InL = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2422_24InR, 1);
      V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2425}));
      v_t_2428 = heff_tag_at_n(v_ru_24y_2424_24InL, TAG_InL, 1, (V[]){v_t_2426});
      break;
    }
    case TAG_InR: {
      V v_y_2427 = heff_field(v_y_2424, 0);
      heff_take_n(v_y_2424, 1ULL, 1);
      heff_drop(v_m_2419);
      heff_drop(v_n_2420);
      heff_drop(v_nt_2421);
      v_t_2428 = heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_y_2427});
      break;
    }
    default: heff_nomatch(v_y_2424);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2428});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s373441151x488264545_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s373441151x488264545_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s373441151x488264545_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s373441151x488264545_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s373441151x488264545_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s373441151x488264545_st;
static V g_co_2e_3c_2b_3e_24s373441151x488264545_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s373441151x488264545_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s373441151x488264545_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s373441151x488264545_st)) return g_co_2e_3c_2b_3e_24s373441151x488264545_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s373441151x488264545_val, &g_co_2e_3c_2b_3e_24s373441151x488264545_st, g_co_2e_3c_2b_3e_24s373441151x488264545_init);
}
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_245}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2e_3c_2b_3e_24s373441151x488264545_lam1, 1, 3, (V[]){v_h_246, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1117694589x1745783676_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2411}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam3(V self, V *args) {
  V v_s_2422 = args[0];
  V v_h_2420 = heff_env(self)[0];
  V v_nt_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_h_2420, 1, (V[]){v_s_2422}));
  V f_ = v_nt_2415;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s373441151x488264545_lam2(V self, V *args) {
  V v_m_2413 = args[0];
  V v_n_2414 = args[1];
  V v_nt_2415 = args[2];
  V v_p_2416 = args[3];
  switch (heff_tag_of(v_p_2416)) {
  case TAG_InL: {
    V v_x_2417 = heff_field(v_p_2416, 0);
    V v_ru_24p_2416_24InL = heff_take_reuse_n(v_p_2416, 1ULL, 1);
    heff_drop(v_m_2413);
    heff_drop(v_n_2414);
    V v_t_2424;
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Throw: {
      V v_s_2418 = heff_field(v_x_2417, 0);
      V v_ru_24x_2417_24Throw = heff_take_reuse_n(v_x_2417, 1ULL, 1);
      heff_drop(v_nt_2415);
      v_t_2424 = heff_tag_at_n(v_ru_24x_2417_24Throw, TAG_Throw, 1, (V[]){v_s_2418});
      break;
    }
    case TAG_Catch: {
      V v_c_2419 = heff_field(v_x_2417, 0);
      V v_h_2420 = heff_field(v_x_2417, 1);
      V v_ru_24x_2417_24Catch = heff_take_reuse_n(v_x_2417, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_call(heff_dup(v_nt_2415), 1, (V[]){v_c_2419}));
      v_t_2424 = heff_tag_at_n(v_ru_24x_2417_24Catch, TAG_Catch, 2, (V[]){v_t_2421, heff_clo_n(g_co_2e_3c_2b_3e_24s373441151x488264545_lam3, 1, 2, (V[]){v_h_2420, v_nt_2415})});
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    return heff_tag_at_n(v_ru_24p_2416_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2416, 0);
    V v_ru_24p_2416_24InR = heff_take_reuse_n(v_p_2416, 1ULL, 1);
    V v_t_2432;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_InL: {
      V v_x_2426 = heff_field(v_y_2425, 0);
      V v_ru_24y_2425_24InL = heff_take_reuse_n(v_y_2425, 1ULL, 1);
      heff_drop(v_m_2413);
      heff_drop(v_n_2414);
      heff_drop(v_nt_2415);
      heff_drop_cell(v_ru_24p_2416_24InR, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2425_24InL, TAG_InL, 1, (V[]){v_x_2426});
      break;
    }
    case TAG_InR: {
      V v_y_2427 = heff_field(v_y_2425, 0);
      V v_ru_24y_2425_24InR = heff_take_reuse_n(v_y_2425, 1ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_y_2427)) {
      case TAG_InL: {
        V v_x_2428 = heff_field(v_y_2427, 0);
        V v_ru_24y_2427_24InL = heff_take_reuse_n(v_y_2427, 1ULL, 1);
        heff_drop_cell(v_ru_24p_2416_24InR, 1);
        V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){v_m_2413, v_n_2414, v_nt_2415, v_x_2428}));
        v_t_2431 = heff_tag_at_n(v_ru_24y_2427_24InL, TAG_InL, 1, (V[]){v_t_2429});
        break;
      }
      case TAG_InR: {
        V v_y_2430 = heff_field(v_y_2427, 0);
        heff_take_n(v_y_2427, 1ULL, 1);
        heff_drop(v_m_2413);
        heff_drop(v_n_2414);
        heff_drop(v_nt_2415);
        v_t_2431 = heff_tag_at_n(v_ru_24p_2416_24InR, TAG_InR, 1, (V[]){v_y_2430});
        break;
      }
      default: heff_nomatch(v_y_2427);
      }
      v_t_2432 = heff_tag_at_n(v_ru_24y_2425_24InR, TAG_InR, 1, (V[]){v_t_2431});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2432});
  }
  default: return heff_nomatch(v_p_2416);
  }
}
V g_co_2eop_24s615738393x1686646143_lam0(V self, V *args);
V g_co_2eop_24s615738393x1686646143_lam2(V self, V *args);
V g_co_2eop_24s615738393x1686646143_lam1(V self, V *args); static Clo g_co_2eop_24s615738393x1686646143_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s615738393x1686646143_lam1, 4, 0};
V g_co_2eop_24s615738393x1686646143_lam4(V self, V *args);
V g_co_2eop_24s615738393x1686646143_lam3(V self, V *args);
V g_co_2eop_24s615738393x1686646143_lam5(V self, V *args);
Clo g_co_2eop_24s615738393x1686646143_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s615738393x1686646143_entry, 3, 0};

V g_co_2eop_24s615738393x1686646143(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s615738393x1686646143_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s615738393x1686646143_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s615738393x1686646143_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s615738393x1686646143_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, v_k2_242});
}
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s615738393x1686646143(a[0], a[1], a[2]);
}
V g_co_2eop_24s615738393x1686646143_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s615738393x1686646143_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s615738393x1686646143_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s615738393x1686646143_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s615738393x1686646143_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s615738393x1686646143_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s615738393x1686646143_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s615738393x1686646143_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam4(V self, V *args);
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s1733666804x1061788546_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1733666804x1061788546_st;
static V g_co_2e_3c_2b_3e_24s1733666804x1061788546_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1733666804x1061788546_st)) return g_co_2e_3c_2b_3e_24s1733666804x1061788546_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1733666804x1061788546_val, &g_co_2e_3c_2b_3e_24s1733666804x1061788546_st, g_co_2e_3c_2b_3e_24s1733666804x1061788546_init);
}
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_h_2415 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tr(heff_call(v_h_2415, 1, (V[]){v_s_2417}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_245}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam1, 1, 3, (V[]){v_h_246, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24InL = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2412)) {
      case TAG_Throw: {
        V v_s_2413 = heff_field(v_x_2412, 0);
        V v_ru_24x_2412_24Throw = heff_take_reuse_n(v_x_2412, 1ULL, 1);
        heff_drop_rec(v_m_240, 1);
        heff_drop(v_g_241);
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24Throw, TAG_Throw, 1, (V[]){v_s_2413});
        break;
      }
      case TAG_Catch: {
        V v_c_2414 = heff_field(v_x_2412, 0);
        V v_h_2415 = heff_field(v_x_2412, 1);
        V v_ru_24x_2412_24Catch = heff_take_reuse_n(v_x_2412, 3ULL, 2);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_2414}));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24Catch, TAG_Catch, 2, (V[]){v_t_2416, heff_clo_n(g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam2, 1, 3, (V[]){v_h_2415, v_m_240, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      v_t_2422 = heff_tag_at_n(v_ru_24y_2411_24InL, TAG_InL, 1, (V[]){v_t_2419});
      break;
    }
    case TAG_InR: {
      V v_y_2420 = heff_field(v_y_2411, 0);
      heff_take_n(v_y_2411, 1ULL, 1);
      V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1117694589x1745783676_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2420}));
      v_t_2422 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2422});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam4(V self, V *args) {
  V v_s_2432 = args[0];
  V v_h_2430 = heff_env(self)[0];
  V v_nt_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_tr(heff_call(v_h_2430, 1, (V[]){v_s_2432}));
  V f_ = v_nt_2425;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam3(V self, V *args) {
  V v_m_2423 = args[0];
  V v_n_2424 = args[1];
  V v_nt_2425 = args[2];
  V v_p_2426 = args[3];
  switch (heff_tag_of(v_p_2426)) {
  case TAG_InL: {
    V v_x_2427 = heff_field(v_p_2426, 0);
    V v_ru_24p_2426_24InL = heff_take_reuse_n(v_p_2426, 1ULL, 1);
    heff_drop(v_m_2423);
    heff_drop(v_n_2424);
    V v_t_2434;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_Throw: {
      V v_s_2428 = heff_field(v_x_2427, 0);
      V v_ru_24x_2427_24Throw = heff_take_reuse_n(v_x_2427, 1ULL, 1);
      heff_drop(v_nt_2425);
      v_t_2434 = heff_tag_at_n(v_ru_24x_2427_24Throw, TAG_Throw, 1, (V[]){v_s_2428});
      break;
    }
    case TAG_Catch: {
      V v_c_2429 = heff_field(v_x_2427, 0);
      V v_h_2430 = heff_field(v_x_2427, 1);
      V v_ru_24x_2427_24Catch = heff_take_reuse_n(v_x_2427, 3ULL, 2);
      V v_t_2431 = heff_tr(heff_call(heff_dup(v_nt_2425), 1, (V[]){v_c_2429}));
      v_t_2434 = heff_tag_at_n(v_ru_24x_2427_24Catch, TAG_Catch, 2, (V[]){v_t_2431, heff_clo_n(g_co_2e_3c_2b_3e_24s1733666804x1061788546_lam4, 1, 2, (V[]){v_h_2430, v_nt_2425})});
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    return heff_tag_at_n(v_ru_24p_2426_24InL, TAG_InL, 1, (V[]){v_t_2434});
  }
  case TAG_InR: {
    V v_y_2435 = heff_field(v_p_2426, 0);
    V v_ru_24p_2426_24InR = heff_take_reuse_n(v_p_2426, 1ULL, 1);
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){v_m_2423, v_n_2424, v_nt_2425, v_y_2435}));
    return heff_tag_at_n(v_ru_24p_2426_24InR, TAG_InR, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_p_2426);
  }
}
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s33412700x2062750937_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s33412700x2062750937_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam4(V self, V *args);
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s33412700x2062750937_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s33412700x2062750937_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s33412700x2062750937_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s33412700x2062750937_st;
static V g_co_2e_3c_2b_3e_24s33412700x2062750937_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s33412700x2062750937_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s33412700x2062750937_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s33412700x2062750937_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s33412700x2062750937_st)) return g_co_2e_3c_2b_3e_24s33412700x2062750937_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s33412700x2062750937_val, &g_co_2e_3c_2b_3e_24s33412700x2062750937_st, g_co_2e_3c_2b_3e_24s33412700x2062750937_init);
}
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_245}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2e_3c_2b_3e_24s33412700x2062750937_lam1, 1, 3, (V[]){v_h_246, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2411}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam3(V self, V *args) {
  V v_s_2422 = args[0];
  V v_h_2420 = heff_env(self)[0];
  V v_nt_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_h_2420, 1, (V[]){v_s_2422}));
  V f_ = v_nt_2415;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_h_2429 = heff_env(self)[0];
  V v_nt_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_h_2429, 1, (V[]){v_s_2431}));
  V f_ = v_nt_2415;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s33412700x2062750937_lam2(V self, V *args) {
  V v_m_2413 = args[0];
  V v_n_2414 = args[1];
  V v_nt_2415 = args[2];
  V v_p_2416 = args[3];
  switch (heff_tag_of(v_p_2416)) {
  case TAG_InL: {
    V v_x_2417 = heff_field(v_p_2416, 0);
    V v_ru_24p_2416_24InL = heff_take_reuse_n(v_p_2416, 1ULL, 1);
    heff_drop(v_m_2413);
    heff_drop(v_n_2414);
    V v_t_2424;
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Throw: {
      V v_s_2418 = heff_field(v_x_2417, 0);
      V v_ru_24x_2417_24Throw = heff_take_reuse_n(v_x_2417, 1ULL, 1);
      heff_drop(v_nt_2415);
      v_t_2424 = heff_tag_at_n(v_ru_24x_2417_24Throw, TAG_Throw, 1, (V[]){v_s_2418});
      break;
    }
    case TAG_Catch: {
      V v_c_2419 = heff_field(v_x_2417, 0);
      V v_h_2420 = heff_field(v_x_2417, 1);
      V v_ru_24x_2417_24Catch = heff_take_reuse_n(v_x_2417, 3ULL, 2);
      V v_t_2421 = heff_tr(heff_call(heff_dup(v_nt_2415), 1, (V[]){v_c_2419}));
      v_t_2424 = heff_tag_at_n(v_ru_24x_2417_24Catch, TAG_Catch, 2, (V[]){v_t_2421, heff_clo_n(g_co_2e_3c_2b_3e_24s33412700x2062750937_lam3, 1, 2, (V[]){v_h_2420, v_nt_2415})});
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    return heff_tag_at_n(v_ru_24p_2416_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2416, 0);
    V v_ru_24p_2416_24InR = heff_take_reuse_n(v_p_2416, 1ULL, 1);
    V v_t_2436;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_InL: {
      V v_x_2426 = heff_field(v_y_2425, 0);
      V v_ru_24y_2425_24InL = heff_take_reuse_n(v_y_2425, 1ULL, 1);
      heff_drop(v_m_2413);
      heff_drop(v_n_2414);
      heff_drop_cell(v_ru_24p_2416_24InR, 1);
      V v_t_2433;
      switch (heff_tag_of(v_x_2426)) {
      case TAG_Throw: {
        V v_s_2427 = heff_field(v_x_2426, 0);
        V v_ru_24x_2426_24Throw = heff_take_reuse_n(v_x_2426, 1ULL, 1);
        heff_drop(v_nt_2415);
        v_t_2433 = heff_tag_at_n(v_ru_24x_2426_24Throw, TAG_Throw, 1, (V[]){v_s_2427});
        break;
      }
      case TAG_Catch: {
        V v_c_2428 = heff_field(v_x_2426, 0);
        V v_h_2429 = heff_field(v_x_2426, 1);
        V v_ru_24x_2426_24Catch = heff_take_reuse_n(v_x_2426, 3ULL, 2);
        V v_t_2430 = heff_tr(heff_call(heff_dup(v_nt_2415), 1, (V[]){v_c_2428}));
        v_t_2433 = heff_tag_at_n(v_ru_24x_2426_24Catch, TAG_Catch, 2, (V[]){v_t_2430, heff_clo_n(g_co_2e_3c_2b_3e_24s33412700x2062750937_lam4, 1, 2, (V[]){v_h_2429, v_nt_2415})});
        break;
      }
      default: heff_nomatch(v_x_2426);
      }
      v_t_2436 = heff_tag_at_n(v_ru_24y_2425_24InL, TAG_InL, 1, (V[]){v_t_2433});
      break;
    }
    case TAG_InR: {
      V v_y_2434 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){v_m_2413, v_n_2414, v_nt_2415, v_y_2434}));
      v_t_2436 = heff_tag_at_n(v_ru_24p_2416_24InR, TAG_InR, 1, (V[]){v_t_2435});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_p_2416);
  }
}
V g_co_2eop_24s1398690846x1918384825_lam1(V self, V *args);
V g_co_2eop_24s1398690846x1918384825_lam0(V self, V *args); static Clo g_co_2eop_24s1398690846x1918384825_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1398690846x1918384825_lam0, 4, 0};
V g_co_2eop_24s1398690846x1918384825_lam3(V self, V *args);
V g_co_2eop_24s1398690846x1918384825_lam2(V self, V *args);
V g_co_2eop_24s1398690846x1918384825_lam4(V self, V *args);
Clo g_co_2eop_24s1398690846x1918384825_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1398690846x1918384825_entry, 3, 0};

V g_co_2eop_24s1398690846x1918384825(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s33412700x2062750937_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1398690846x1918384825_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1398690846x1918384825_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1398690846x1918384825_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1398690846x1918384825(a[0], a[1], a[2]);
}
V g_co_2eop_24s1398690846x1918384825_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1398690846x1918384825_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1398690846x1918384825_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1398690846x1918384825_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1398690846x1918384825_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1398690846x1918384825_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1398690846x1918384825_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s1178127530x1610393171_str0, 2, ": ");
HEFF_LIT(g_co_2eop_24s1178127530x1610393171_str1, 1, "\012");
V g_co_2eop_24s1178127530x1610393171_lam0(V self, V *args);
V g_co_2eop_24s1178127530x1610393171_lam2(V self, V *args);
V g_co_2eop_24s1178127530x1610393171_lam1(V self, V *args); static Clo g_co_2eop_24s1178127530x1610393171_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1178127530x1610393171_lam1, 4, 0};
V g_co_2eop_24s1178127530x1610393171_lam4(V self, V *args);
V g_co_2eop_24s1178127530x1610393171_lam3(V self, V *args);
V g_co_2eop_24s1178127530x1610393171_lam5(V self, V *args);
V g_co_2eop_24s1178127530x1610393171_lam6(V self, V *args);
Clo g_co_2eop_24s1178127530x1610393171_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1178127530x1610393171_entry, 8, 0};

V g_co_2eop_24s1178127530x1610393171(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2429;
  switch (heff_tag_of(v_p_246)) {
  case TAG_InL: {
    V v_x_248 = heff_field(v_p_246, 0);
    V v_ru_24p_246_24InL = heff_take_reuse_n(v_p_246, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Throw: {
      V v_s_249 = heff_field(v_x_248, 0);
      V v_ru_24x_248_24Throw = heff_take_reuse_n(v_x_248, 1ULL, 1);
      v_t_2415 = heff_tag_at_n(v_ru_24x_248_24Throw, TAG_Throw, 1, (V[]){v_s_249});
      break;
    }
    case TAG_Catch: {
      V v_c_2410 = heff_field(v_x_248, 0);
      V v_h_2411 = heff_field(v_x_248, 1);
      V v_ru_24x_248_24Catch = heff_take_reuse_n(v_x_248, 3ULL, 2);
      V v_t_2412 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(v_hd_247), heff_dup(heff_rfield(v_hd_247, 0))}));
      v_t_2415 = heff_tag_at_n(v_ru_24x_248_24Catch, TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_co_2eop_24s1178127530x1610393171_lam0, 1, 2, (V[]){v_h_2411, heff_dup(v_hd_247)})});
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    v_t_2429 = heff_tag_at_n(v_ru_24p_246_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_246, 0);
    V v_ru_24p_246_24InR = heff_take_reuse_n(v_p_246, 1ULL, 1);
    V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1178127530x1610393171_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1178127530x1610393171_lam3, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s1178127530x1610393171_lam5, 1, 1, (V[]){heff_dup(v_hd_247)}), v_y_2416}));
    v_t_2429 = heff_tag_at_n(v_ru_24p_246_24InR, TAG_InR, 1, (V[]){v_t_2428});
    break;
  }
  default: heff_nomatch(v_p_246);
  }
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2429}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2430, heff_clo_n(g_co_2eop_24s1178127530x1610393171_lam6, 1, 6, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s1178127530x1610393171_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1178127530x1610393171(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_co_2eop_24s1178127530x1610393171_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_h_2411 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2414 = heff_tr(heff_call(v_h_2411, 1, (V[]){v_s_2413}));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1178127530x1610393171_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2417 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = heff_tr(heff_call(v_g_2417, 1, (V[]){v_x_2421}));
  V f_ = v_k_2420;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1178127530x1610393171_lam1(V self, V *args) {
  V v_g_2417 = args[0];
  V v_c_2418 = args[1];
  V v_hd_2419 = args[2];
  V v_k_2420 = args[3];
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_co_2eop_24s1178127530x1610393171_lam2, 1, 2, (V[]){v_g_2417, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1178127530x1610393171_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_2423 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tr(heff_call(v_g_2423, 1, (V[]){v_x_2425}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1178127530x1610393171_lam3(V self, V *args) {
  V v_g_2423 = args[0];
  V v_m_2424 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_2424;
  args[1] = heff_clo_n(g_co_2eop_24s1178127530x1610393171_lam4, 1, 2, (V[]){v_g_2423, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1178127530x1610393171_lam5(V self, V *args) {
  V v_c_2427 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1178127530x1610393171_lam6(V self, V *args) {
  V v_a_2431 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2431);
  V v_m_2432 = v_lit_240;
  V v_x2_2433 = v_lit_241;
  V v_n_2434 = heff_intAdd(v_lit_242, v_lit_243);
  V v_p_2435 = v_lit_244;
  V v_p_2436 = v_lit_245;
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_Nil: {
    heff_drop(v_m_2432);
    heff_drop(v_p_2435);
    V f_ = v_p_2436;
    args[0] = v_n_2434;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2437 = heff_field(v_x2_2433, 0);
    V v_rest_2438 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24Cons = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_t_2439 = heff_strAppend(heff_dup(v_m_2432), heff_strAppend(((V)&g_co_2eop_24s1178127530x1610393171_str0), v_l_2437));
    V v_t_2440 = heff_tag_at_n(v_ru_24x2_2433_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2439, ((V)&g_co_2eop_24s1178127530x1610393171_str1)), NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
    return (g_co_2eop_24s1178127530x1610393171(v_m_2432, v_rest_2438, v_n_2434, MK_INT(1LL), heff_dup(v_p_2435), v_p_2436, heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_p_2435));
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_co_2eop_24s847889387x1388281137_lam0(V self, V *args);
V g_co_2eop_24s847889387x1388281137_lam2(V self, V *args);
V g_co_2eop_24s847889387x1388281137_lam1(V self, V *args); static Clo g_co_2eop_24s847889387x1388281137_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s847889387x1388281137_lam1, 4, 0};
V g_co_2eop_24s847889387x1388281137_lam4(V self, V *args);
V g_co_2eop_24s847889387x1388281137_lam3(V self, V *args);
V g_co_2eop_24s847889387x1388281137_lam5(V self, V *args);
Clo g_co_2eop_24s847889387x1388281137_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s847889387x1388281137_entry, 3, 0};

V g_co_2eop_24s847889387x1388281137(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s847889387x1388281137_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s847889387x1388281137_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s847889387x1388281137_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s847889387x1388281137_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, v_k2_242});
}
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s847889387x1388281137(a[0], a[1], a[2]);
}
V g_co_2eop_24s847889387x1388281137_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s847889387x1388281137_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s847889387x1388281137_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s847889387x1388281137_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s847889387x1388281137_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s847889387x1388281137_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s847889387x1388281137_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s847889387x1388281137_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1067007848x1099704198_lam0(V self, V *args);
V g_co_2eop_24s1067007848x1099704198_lam2(V self, V *args);
V g_co_2eop_24s1067007848x1099704198_lam1(V self, V *args); static Clo g_co_2eop_24s1067007848x1099704198_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1067007848x1099704198_lam1, 4, 0};
V g_co_2eop_24s1067007848x1099704198_lam4(V self, V *args);
V g_co_2eop_24s1067007848x1099704198_lam3(V self, V *args);
V g_co_2eop_24s1067007848x1099704198_lam5(V self, V *args);
V g_co_2eop_24s1067007848x1099704198_lam6(V self, V *args);
Clo g_co_2eop_24s1067007848x1099704198_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1067007848x1099704198_entry, 8, 0};

V g_co_2eop_24s1067007848x1099704198(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2429;
  switch (heff_tag_of(v_p_246)) {
  case TAG_InL: {
    V v_x_248 = heff_field(v_p_246, 0);
    V v_ru_24p_246_24InL = heff_take_reuse_n(v_p_246, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Throw: {
      V v_s_249 = heff_field(v_x_248, 0);
      V v_ru_24x_248_24Throw = heff_take_reuse_n(v_x_248, 1ULL, 1);
      v_t_2415 = heff_tag_at_n(v_ru_24x_248_24Throw, TAG_Throw, 1, (V[]){v_s_249});
      break;
    }
    case TAG_Catch: {
      V v_c_2410 = heff_field(v_x_248, 0);
      V v_h_2411 = heff_field(v_x_248, 1);
      V v_ru_24x_248_24Catch = heff_take_reuse_n(v_x_248, 3ULL, 2);
      V v_t_2412 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(v_hd_247), heff_dup(heff_rfield(v_hd_247, 0))}));
      v_t_2415 = heff_tag_at_n(v_ru_24x_248_24Catch, TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_co_2eop_24s1067007848x1099704198_lam0, 1, 2, (V[]){v_h_2411, heff_dup(v_hd_247)})});
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    v_t_2429 = heff_tag_at_n(v_ru_24p_246_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_246, 0);
    V v_ru_24p_246_24InR = heff_take_reuse_n(v_p_246, 1ULL, 1);
    V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1067007848x1099704198_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1067007848x1099704198_lam3, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s1067007848x1099704198_lam5, 1, 1, (V[]){heff_dup(v_hd_247)}), v_y_2416}));
    v_t_2429 = heff_tag_at_n(v_ru_24p_246_24InR, TAG_InR, 1, (V[]){v_t_2428});
    break;
  }
  default: heff_nomatch(v_p_246);
  }
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2429}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2430, heff_clo_n(g_co_2eop_24s1067007848x1099704198_lam6, 1, 6, (V[]){heff_dup(v_lit_240), v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s1067007848x1099704198_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_co_2eop_24s1067007848x1099704198(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_co_2eop_24s1067007848x1099704198_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_h_2411 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2414 = heff_tr(heff_call(v_h_2411, 1, (V[]){v_s_2413}));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1067007848x1099704198_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2417 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2422 = heff_tr(heff_call(v_g_2417, 1, (V[]){v_x_2421}));
  V f_ = v_k_2420;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1067007848x1099704198_lam1(V self, V *args) {
  V v_g_2417 = args[0];
  V v_c_2418 = args[1];
  V v_hd_2419 = args[2];
  V v_k_2420 = args[3];
  V f_ = v_c_2418;
  args[0] = v_hd_2419;
  args[1] = heff_clo_n(g_co_2eop_24s1067007848x1099704198_lam2, 1, 2, (V[]){v_g_2417, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1067007848x1099704198_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_2423 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tr(heff_call(v_g_2423, 1, (V[]){v_x_2425}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1067007848x1099704198_lam3(V self, V *args) {
  V v_g_2423 = args[0];
  V v_m_2424 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_2424;
  args[1] = heff_clo_n(g_co_2eop_24s1067007848x1099704198_lam4, 1, 2, (V[]){v_g_2423, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1067007848x1099704198_lam5(V self, V *args) {
  V v_c_2427 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1067007848x1099704198_lam6(V self, V *args) {
  V v_a_2431 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2431);
  V v_t_2432 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V r_ = (g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); r_; });
  V f_ = v_t_2432;
  heff_room[0] = v_lit_244;
  heff_room[1] = v_lit_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1755542109x365432933_lam0(V self, V *args);
V g_co_2eop_24s1755542109x365432933_lam2(V self, V *args);
V g_co_2eop_24s1755542109x365432933_lam1(V self, V *args); static Clo g_co_2eop_24s1755542109x365432933_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1755542109x365432933_lam1, 4, 0};
V g_co_2eop_24s1755542109x365432933_lam4(V self, V *args);
V g_co_2eop_24s1755542109x365432933_lam3(V self, V *args);
V g_co_2eop_24s1755542109x365432933_lam5(V self, V *args);
V g_co_2eop_24s1755542109x365432933_lam6(V self, V *args);
Clo g_co_2eop_24s1755542109x365432933_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1755542109x365432933_entry, 10, 0};

V g_co_2eop_24s1755542109x365432933(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2431;
  switch (heff_tag_of(v_p_248)) {
  case TAG_InL: {
    V v_x_2410 = heff_field(v_p_248, 0);
    V v_ru_24p_248_24InL = heff_take_reuse_n(v_p_248, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Throw: {
      V v_s_2411 = heff_field(v_x_2410, 0);
      V v_ru_24x_2410_24Throw = heff_take_reuse_n(v_x_2410, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24x_2410_24Throw, TAG_Throw, 1, (V[]){v_s_2411});
      break;
    }
    case TAG_Catch: {
      V v_c_2412 = heff_field(v_x_2410, 0);
      V v_h_2413 = heff_field(v_x_2410, 1);
      V v_ru_24x_2410_24Catch = heff_take_reuse_n(v_x_2410, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(v_c_2412, 2, (V[]){heff_dup(v_hd_249), heff_dup(heff_rfield(v_hd_249, 0))}));
      v_t_2417 = heff_tag_at_n(v_ru_24x_2410_24Catch, TAG_Catch, 2, (V[]){v_t_2414, heff_clo_n(g_co_2eop_24s1755542109x365432933_lam0, 1, 2, (V[]){v_h_2413, heff_dup(v_hd_249)})});
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    v_t_2431 = heff_tag_at_n(v_ru_24p_248_24InL, TAG_InL, 1, (V[]){v_t_2417});
    break;
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_248, 0);
    V v_ru_24p_248_24InR = heff_take_reuse_n(v_p_248, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1755542109x365432933_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1755542109x365432933_lam3, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s1755542109x365432933_lam5, 1, 1, (V[]){heff_dup(v_hd_249)}), v_y_2418}));
    v_t_2431 = heff_tag_at_n(v_ru_24p_248_24InR, TAG_InR, 1, (V[]){v_t_2430});
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2432 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2431}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2432, heff_clo_n(g_co_2eop_24s1755542109x365432933_lam6, 1, 8, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s1755542109x365432933_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1755542109x365432933(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_co_2eop_24s1755542109x365432933_lam0(V self, V *args) {
  V v_s_2415 = args[0];
  V v_h_2413 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2416 = heff_tr(heff_call(v_h_2413, 1, (V[]){v_s_2415}));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1755542109x365432933_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2423}));
  V f_ = v_k_2422;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1755542109x365432933_lam1(V self, V *args) {
  V v_g_2419 = args[0];
  V v_c_2420 = args[1];
  V v_hd_2421 = args[2];
  V v_k_2422 = args[3];
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_co_2eop_24s1755542109x365432933_lam2, 1, 2, (V[]){v_g_2419, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1755542109x365432933_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tr(heff_call(v_g_2425, 1, (V[]){v_x_2427}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1755542109x365432933_lam3(V self, V *args) {
  V v_g_2425 = args[0];
  V v_m_2426 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2426;
  args[1] = heff_clo_n(g_co_2eop_24s1755542109x365432933_lam4, 1, 2, (V[]){v_g_2425, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1755542109x365432933_lam5(V self, V *args) {
  V v_c_2429 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1755542109x365432933_lam6(V self, V *args) {
  V v_a_2433 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2etestCmd_24s787793850x1983323623(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_a_2433, v_lit_244, v_lit_245, heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()), NTAG(TAG_Nil), v_lit_246, v_lit_247));
}
V g_co_2eop_24s17678202x252484985_lam0(V self, V *args);
V g_co_2eop_24s17678202x252484985_lam2(V self, V *args);
V g_co_2eop_24s17678202x252484985_lam1(V self, V *args); static Clo g_co_2eop_24s17678202x252484985_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s17678202x252484985_lam1, 4, 0};
V g_co_2eop_24s17678202x252484985_lam4(V self, V *args);
V g_co_2eop_24s17678202x252484985_lam3(V self, V *args);
V g_co_2eop_24s17678202x252484985_lam5(V self, V *args);
V g_co_2eop_24s17678202x252484985_lam6(V self, V *args);
Clo g_co_2eop_24s17678202x252484985_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s17678202x252484985_entry, 10, 0};

V g_co_2eop_24s17678202x252484985(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2431;
  switch (heff_tag_of(v_p_248)) {
  case TAG_InL: {
    V v_x_2410 = heff_field(v_p_248, 0);
    V v_ru_24p_248_24InL = heff_take_reuse_n(v_p_248, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Throw: {
      V v_s_2411 = heff_field(v_x_2410, 0);
      V v_ru_24x_2410_24Throw = heff_take_reuse_n(v_x_2410, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24x_2410_24Throw, TAG_Throw, 1, (V[]){v_s_2411});
      break;
    }
    case TAG_Catch: {
      V v_c_2412 = heff_field(v_x_2410, 0);
      V v_h_2413 = heff_field(v_x_2410, 1);
      V v_ru_24x_2410_24Catch = heff_take_reuse_n(v_x_2410, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(v_c_2412, 2, (V[]){heff_dup(v_hd_249), heff_dup(heff_rfield(v_hd_249, 0))}));
      v_t_2417 = heff_tag_at_n(v_ru_24x_2410_24Catch, TAG_Catch, 2, (V[]){v_t_2414, heff_clo_n(g_co_2eop_24s17678202x252484985_lam0, 1, 2, (V[]){v_h_2413, heff_dup(v_hd_249)})});
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    v_t_2431 = heff_tag_at_n(v_ru_24p_248_24InL, TAG_InL, 1, (V[]){v_t_2417});
    break;
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_248, 0);
    V v_ru_24p_248_24InR = heff_take_reuse_n(v_p_248, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s17678202x252484985_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s17678202x252484985_lam3, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s17678202x252484985_lam5, 1, 1, (V[]){heff_dup(v_hd_249)}), v_y_2418}));
    v_t_2431 = heff_tag_at_n(v_ru_24p_248_24InR, TAG_InR, 1, (V[]){v_t_2430});
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2432 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2431}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2432, heff_clo_n(g_co_2eop_24s17678202x252484985_lam6, 1, 8, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s17678202x252484985_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s17678202x252484985(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a1); return r;
}
V g_co_2eop_24s17678202x252484985_lam0(V self, V *args) {
  V v_s_2415 = args[0];
  V v_h_2413 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2416 = heff_tr(heff_call(v_h_2413, 1, (V[]){v_s_2415}));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s17678202x252484985_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2423}));
  V f_ = v_k_2422;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s17678202x252484985_lam1(V self, V *args) {
  V v_g_2419 = args[0];
  V v_c_2420 = args[1];
  V v_hd_2421 = args[2];
  V v_k_2422 = args[3];
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_co_2eop_24s17678202x252484985_lam2, 1, 2, (V[]){v_g_2419, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s17678202x252484985_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tr(heff_call(v_g_2425, 1, (V[]){v_x_2427}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s17678202x252484985_lam3(V self, V *args) {
  V v_g_2425 = args[0];
  V v_m_2426 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2426;
  args[1] = heff_clo_n(g_co_2eop_24s17678202x252484985_lam4, 1, 2, (V[]){v_g_2425, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s17678202x252484985_lam5(V self, V *args) {
  V v_c_2429 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s17678202x252484985_lam6(V self, V *args) {
  V v_a_2433 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_a_2433);
  V v_t_2434 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s830846973x857418910(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2434;
  heff_room[0] = v_lit_246;
  heff_room[1] = v_lit_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s2088512805x623284879_lam0(V self, V *args);
V g_co_2eop_24s2088512805x623284879_lam2(V self, V *args);
V g_co_2eop_24s2088512805x623284879_lam1(V self, V *args); static Clo g_co_2eop_24s2088512805x623284879_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2088512805x623284879_lam1, 4, 0};
V g_co_2eop_24s2088512805x623284879_lam4(V self, V *args);
V g_co_2eop_24s2088512805x623284879_lam3(V self, V *args);
V g_co_2eop_24s2088512805x623284879_lam5(V self, V *args);
V g_co_2eop_24s2088512805x623284879_lam6(V self, V *args);
Clo g_co_2eop_24s2088512805x623284879_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2088512805x623284879_entry, 6, 0};

V g_co_2eop_24s2088512805x623284879(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2427;
  switch (heff_tag_of(v_p_244)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InL = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Throw: {
      V v_s_247 = heff_field(v_x_246, 0);
      V v_ru_24x_246_24Throw = heff_take_reuse_n(v_x_246, 1ULL, 1);
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Throw, TAG_Throw, 1, (V[]){v_s_247});
      break;
    }
    case TAG_Catch: {
      V v_c_248 = heff_field(v_x_246, 0);
      V v_h_249 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24Catch = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(v_hd_245), heff_dup(heff_rfield(v_hd_245, 0))}));
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Catch, TAG_Catch, 2, (V[]){v_t_2410, heff_clo_n(g_co_2eop_24s2088512805x623284879_lam0, 1, 2, (V[]){v_h_249, heff_dup(v_hd_245)})});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    v_t_2427 = heff_tag_at_n(v_ru_24p_244_24InL, TAG_InL, 1, (V[]){v_t_2413});
    break;
  }
  case TAG_InR: {
    V v_y_2414 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InR = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s2088512805x623284879_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s2088512805x623284879_lam3, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s2088512805x623284879_lam5, 1, 1, (V[]){heff_dup(v_hd_245)}), v_y_2414}));
    v_t_2427 = heff_tag_at_n(v_ru_24p_244_24InR, TAG_InR, 1, (V[]){v_t_2426});
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2427}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2428, heff_clo_n(g_co_2eop_24s2088512805x623284879_lam6, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s2088512805x623284879_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s2088512805x623284879(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s2088512805x623284879_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_h_249 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2412 = heff_tr(heff_call(v_h_249, 1, (V[]){v_s_2411}));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s2088512805x623284879_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420 = heff_tr(heff_call(v_g_2415, 1, (V[]){v_x_2419}));
  V f_ = v_k_2418;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2088512805x623284879_lam1(V self, V *args) {
  V v_g_2415 = args[0];
  V v_c_2416 = args[1];
  V v_hd_2417 = args[2];
  V v_k_2418 = args[3];
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_co_2eop_24s2088512805x623284879_lam2, 1, 2, (V[]){v_g_2415, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2088512805x623284879_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_2421 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_g_2421, 1, (V[]){v_x_2423}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2088512805x623284879_lam3(V self, V *args) {
  V v_g_2421 = args[0];
  V v_m_2422 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2422;
  args[1] = heff_clo_n(g_co_2eop_24s2088512805x623284879_lam4, 1, 2, (V[]){v_g_2421, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2088512805x623284879_lam5(V self, V *args) {
  V v_c_2425 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s2088512805x623284879_lam6(V self, V *args) {
  V v_a_2429 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2429);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1852531261x2076651554(v_lit_240, v_lit_241, v_lit_242, v_lit_243));
}
V g_co_2eop_24s760975558x1999937727_lam0(V self, V *args);
V g_co_2eop_24s760975558x1999937727_lam2(V self, V *args);
V g_co_2eop_24s760975558x1999937727_lam1(V self, V *args); static Clo g_co_2eop_24s760975558x1999937727_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s760975558x1999937727_lam1, 4, 0};
V g_co_2eop_24s760975558x1999937727_lam4(V self, V *args);
V g_co_2eop_24s760975558x1999937727_lam3(V self, V *args);
V g_co_2eop_24s760975558x1999937727_lam5(V self, V *args);
V g_co_2eop_24s760975558x1999937727_lam6(V self, V *args);
Clo g_co_2eop_24s760975558x1999937727_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s760975558x1999937727_entry, 6, 0};

V g_co_2eop_24s760975558x1999937727(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2427;
  switch (heff_tag_of(v_p_244)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InL = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Throw: {
      V v_s_247 = heff_field(v_x_246, 0);
      V v_ru_24x_246_24Throw = heff_take_reuse_n(v_x_246, 1ULL, 1);
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Throw, TAG_Throw, 1, (V[]){v_s_247});
      break;
    }
    case TAG_Catch: {
      V v_c_248 = heff_field(v_x_246, 0);
      V v_h_249 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24Catch = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(v_hd_245), heff_dup(heff_rfield(v_hd_245, 0))}));
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Catch, TAG_Catch, 2, (V[]){v_t_2410, heff_clo_n(g_co_2eop_24s760975558x1999937727_lam0, 1, 2, (V[]){v_h_249, heff_dup(v_hd_245)})});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    v_t_2427 = heff_tag_at_n(v_ru_24p_244_24InL, TAG_InL, 1, (V[]){v_t_2413});
    break;
  }
  case TAG_InR: {
    V v_y_2414 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InR = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s760975558x1999937727_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s760975558x1999937727_lam3, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s760975558x1999937727_lam5, 1, 1, (V[]){heff_dup(v_hd_245)}), v_y_2414}));
    v_t_2427 = heff_tag_at_n(v_ru_24p_244_24InR, TAG_InR, 1, (V[]){v_t_2426});
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2427}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2428, heff_clo_n(g_co_2eop_24s760975558x1999937727_lam6, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s760975558x1999937727_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s760975558x1999937727(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s760975558x1999937727_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_h_249 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2412 = heff_tr(heff_call(v_h_249, 1, (V[]){v_s_2411}));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s760975558x1999937727_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420 = heff_tr(heff_call(v_g_2415, 1, (V[]){v_x_2419}));
  V f_ = v_k_2418;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s760975558x1999937727_lam1(V self, V *args) {
  V v_g_2415 = args[0];
  V v_c_2416 = args[1];
  V v_hd_2417 = args[2];
  V v_k_2418 = args[3];
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_co_2eop_24s760975558x1999937727_lam2, 1, 2, (V[]){v_g_2415, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s760975558x1999937727_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_2421 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_g_2421, 1, (V[]){v_x_2423}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s760975558x1999937727_lam3(V self, V *args) {
  V v_g_2421 = args[0];
  V v_m_2422 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2422;
  args[1] = heff_clo_n(g_co_2eop_24s760975558x1999937727_lam4, 1, 2, (V[]){v_g_2421, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s760975558x1999937727_lam5(V self, V *args) {
  V v_c_2425 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s760975558x1999937727_lam6(V self, V *args) {
  V v_a_2429 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_resource_2eheldBy_24s650049234x1642226888(v_lit_240, v_lit_241, v_a_2429, v_lit_242, v_lit_243));
}
V g_co_2eop_24s14038175x385665938_lam0(V self, V *args);
V g_co_2eop_24s14038175x385665938_lam2(V self, V *args);
V g_co_2eop_24s14038175x385665938_lam1(V self, V *args); static Clo g_co_2eop_24s14038175x385665938_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s14038175x385665938_lam1, 4, 0};
V g_co_2eop_24s14038175x385665938_lam4(V self, V *args);
V g_co_2eop_24s14038175x385665938_lam3(V self, V *args);
V g_co_2eop_24s14038175x385665938_lam5(V self, V *args);
V g_co_2eop_24s14038175x385665938_lam6(V self, V *args);
Clo g_co_2eop_24s14038175x385665938_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s14038175x385665938_entry, 6, 0};

V g_co_2eop_24s14038175x385665938(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2427;
  switch (heff_tag_of(v_p_244)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InL = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Throw: {
      V v_s_247 = heff_field(v_x_246, 0);
      V v_ru_24x_246_24Throw = heff_take_reuse_n(v_x_246, 1ULL, 1);
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Throw, TAG_Throw, 1, (V[]){v_s_247});
      break;
    }
    case TAG_Catch: {
      V v_c_248 = heff_field(v_x_246, 0);
      V v_h_249 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24Catch = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(v_hd_245), heff_dup(heff_rfield(v_hd_245, 0))}));
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Catch, TAG_Catch, 2, (V[]){v_t_2410, heff_clo_n(g_co_2eop_24s14038175x385665938_lam0, 1, 2, (V[]){v_h_249, heff_dup(v_hd_245)})});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    v_t_2427 = heff_tag_at_n(v_ru_24p_244_24InL, TAG_InL, 1, (V[]){v_t_2413});
    break;
  }
  case TAG_InR: {
    V v_y_2414 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InR = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s14038175x385665938_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s14038175x385665938_lam3, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s14038175x385665938_lam5, 1, 1, (V[]){heff_dup(v_hd_245)}), v_y_2414}));
    v_t_2427 = heff_tag_at_n(v_ru_24p_244_24InR, TAG_InR, 1, (V[]){v_t_2426});
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2427}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2428, heff_clo_n(g_co_2eop_24s14038175x385665938_lam6, 1, 4, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243})});
}
V g_co_2eop_24s14038175x385665938_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s14038175x385665938(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_co_2eop_24s14038175x385665938_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_h_249 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2412 = heff_tr(heff_call(v_h_249, 1, (V[]){v_s_2411}));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s14038175x385665938_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_k_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420 = heff_tr(heff_call(v_g_2415, 1, (V[]){v_x_2419}));
  V f_ = v_k_2418;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s14038175x385665938_lam1(V self, V *args) {
  V v_g_2415 = args[0];
  V v_c_2416 = args[1];
  V v_hd_2417 = args[2];
  V v_k_2418 = args[3];
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_co_2eop_24s14038175x385665938_lam2, 1, 2, (V[]){v_g_2415, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s14038175x385665938_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_2421 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_g_2421, 1, (V[]){v_x_2423}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s14038175x385665938_lam3(V self, V *args) {
  V v_g_2421 = args[0];
  V v_m_2422 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2422;
  args[1] = heff_clo_n(g_co_2eop_24s14038175x385665938_lam4, 1, 2, (V[]){v_g_2421, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s14038175x385665938_lam5(V self, V *args) {
  V v_c_2425 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s14038175x385665938_lam6(V self, V *args) {
  V v_a_2429 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2429);
  V v_t_2430 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V r_ = (g_heff_2elsp_2erpc_2eawait_24s1843298536x423386347(a_0, a_1)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2430;
  heff_room[0] = v_lit_242;
  heff_room[1] = v_lit_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s903307437x182144838_lam0(V self, V *args);
V g_co_2eop_24s903307437x182144838_lam2(V self, V *args);
V g_co_2eop_24s903307437x182144838_lam1(V self, V *args); static Clo g_co_2eop_24s903307437x182144838_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s903307437x182144838_lam1, 4, 0};
V g_co_2eop_24s903307437x182144838_lam4(V self, V *args);
V g_co_2eop_24s903307437x182144838_lam3(V self, V *args);
V g_co_2eop_24s903307437x182144838_lam5(V self, V *args);
V g_co_2eop_24s903307437x182144838_lam6(V self, V *args);
Clo g_co_2eop_24s903307437x182144838_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s903307437x182144838_entry, 6, 0};

V g_co_2eop_24s903307437x182144838(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_mod_246 = heff_take_field(v_lit_241, 1);
  V v_cwd_247 = heff_take_field(v_lit_241, 2);
  V v_style_248 = heff_take_field(v_lit_241, 3);
  V v_heff_249 = heff_get_n(v_lit_241, 4, 5);
  V v_t_2431;
  switch (heff_tag_of(v_p_244)) {
  case TAG_InL: {
    V v_x_2410 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InL = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_Throw: {
      V v_s_2411 = heff_field(v_x_2410, 0);
      V v_ru_24x_2410_24Throw = heff_take_reuse_n(v_x_2410, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24x_2410_24Throw, TAG_Throw, 1, (V[]){v_s_2411});
      break;
    }
    case TAG_Catch: {
      V v_c_2412 = heff_field(v_x_2410, 0);
      V v_h_2413 = heff_field(v_x_2410, 1);
      V v_ru_24x_2410_24Catch = heff_take_reuse_n(v_x_2410, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(v_c_2412, 2, (V[]){heff_dup(v_hd_245), heff_dup(heff_rfield(v_hd_245, 0))}));
      v_t_2417 = heff_tag_at_n(v_ru_24x_2410_24Catch, TAG_Catch, 2, (V[]){v_t_2414, heff_clo_n(g_co_2eop_24s903307437x182144838_lam0, 1, 2, (V[]){v_h_2413, heff_dup(v_hd_245)})});
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    v_t_2431 = heff_tag_at_n(v_ru_24p_244_24InL, TAG_InL, 1, (V[]){v_t_2417});
    break;
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InR = heff_take_reuse_n(v_p_244, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s903307437x182144838_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s903307437x182144838_lam3, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s903307437x182144838_lam5, 1, 1, (V[]){heff_dup(v_hd_245)}), v_y_2418}));
    v_t_2431 = heff_tag_at_n(v_ru_24p_244_24InR, TAG_InR, 1, (V[]){v_t_2430});
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_t_2432 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2431}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2432, heff_clo_n(g_co_2eop_24s903307437x182144838_lam6, 1, 7, (V[]){v_mod_246, v_cwd_247, v_style_248, v_heff_249, v_lit_240, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s903307437x182144838_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s903307437x182144838(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s903307437x182144838_lam0(V self, V *args) {
  V v_s_2415 = args[0];
  V v_h_2413 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2416 = heff_tr(heff_call(v_h_2413, 1, (V[]){v_s_2415}));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s903307437x182144838_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2423}));
  V f_ = v_k_2422;
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s903307437x182144838_lam1(V self, V *args) {
  V v_g_2419 = args[0];
  V v_c_2420 = args[1];
  V v_hd_2421 = args[2];
  V v_k_2422 = args[3];
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_co_2eop_24s903307437x182144838_lam2, 1, 2, (V[]){v_g_2419, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s903307437x182144838_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2425 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tr(heff_call(v_g_2425, 1, (V[]){v_x_2427}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s903307437x182144838_lam3(V self, V *args) {
  V v_g_2425 = args[0];
  V v_m_2426 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2426;
  args[1] = heff_clo_n(g_co_2eop_24s903307437x182144838_lam4, 1, 2, (V[]){v_g_2425, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s903307437x182144838_lam5(V self, V *args) {
  V v_c_2429 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s903307437x182144838_lam6(V self, V *args) {
  V v_a_2433 = args[0];
  V v_mod_246 = heff_env(self)[0];
  V v_cwd_247 = heff_env(self)[1];
  V v_style_248 = heff_env(self)[2];
  V v_heff_249 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2434 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_False), heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_a_2433, v_mod_246, v_cwd_247, v_style_248, v_heff_249})});
  return (g_heff_2elsp_2elsp_2eserveFrom_24s729186111x1003741788(v_lit_240, v_t_2434, v_lit_242, v_lit_243));
}
V g_co_2eop_24s992437918x598211615_lam0(V self, V *args);
V g_co_2eop_24s992437918x598211615_lam2(V self, V *args);
V g_co_2eop_24s992437918x598211615_lam1(V self, V *args); static Clo g_co_2eop_24s992437918x598211615_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s992437918x598211615_lam1, 4, 0};
V g_co_2eop_24s992437918x598211615_lam4(V self, V *args);
V g_co_2eop_24s992437918x598211615_lam3(V self, V *args);
V g_co_2eop_24s992437918x598211615_lam5(V self, V *args);
Clo g_co_2eop_24s992437918x598211615_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s992437918x598211615_entry, 3, 0};

V g_co_2eop_24s992437918x598211615(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s992437918x598211615_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s992437918x598211615_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s992437918x598211615_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s992437918x598211615_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, v_k2_242});
}
V g_co_2eop_24s992437918x598211615_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s992437918x598211615(a[0], a[1], a[2]);
}
V g_co_2eop_24s992437918x598211615_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s992437918x598211615_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s992437918x598211615_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s992437918x598211615_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s992437918x598211615_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s992437918x598211615_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s992437918x598211615_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s992437918x598211615_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1703844634x634335703_lam1(V self, V *args);
V g_co_2eop_24s1703844634x634335703_lam0(V self, V *args); static Clo g_co_2eop_24s1703844634x634335703_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1703844634x634335703_lam0, 4, 0};
V g_co_2eop_24s1703844634x634335703_lam3(V self, V *args);
V g_co_2eop_24s1703844634x634335703_lam2(V self, V *args);
V g_co_2eop_24s1703844634x634335703_lam4(V self, V *args);
V g_co_2eop_24s1703844634x634335703_lam5(V self, V *args);
Clo g_co_2eop_24s1703844634x634335703_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1703844634x634335703_entry, 3, 0};

V g_co_2eop_24s1703844634x634335703(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1703844634x634335703_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1703844634x634335703_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1703844634x634335703_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, heff_clo_n(g_co_2eop_24s1703844634x634335703_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s1703844634x634335703_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1703844634x634335703(a[0], a[1], a[2]);
}
V g_co_2eop_24s1703844634x634335703_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1703844634x634335703_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1703844634x634335703_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1703844634x634335703_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1703844634x634335703_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1703844634x634335703_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1703844634x634335703_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1703844634x634335703_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1110804312x932325868_lam0(V self, V *args);
V g_co_2eop_24s1110804312x932325868_lam2(V self, V *args);
V g_co_2eop_24s1110804312x932325868_lam1(V self, V *args); static Clo g_co_2eop_24s1110804312x932325868_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1110804312x932325868_lam1, 4, 0};
V g_co_2eop_24s1110804312x932325868_lam4(V self, V *args);
V g_co_2eop_24s1110804312x932325868_lam3(V self, V *args);
V g_co_2eop_24s1110804312x932325868_lam5(V self, V *args);
V g_co_2eop_24s1110804312x932325868_lam6(V self, V *args);
Clo g_co_2eop_24s1110804312x932325868_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1110804312x932325868_entry, 14, 0};

V g_co_2eop_24s1110804312x932325868(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_p_2412, V v_hd_2413) {
top: ;
  V v_t_2435;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_InL: {
    V v_x_2414 = heff_field(v_p_2412, 0);
    V v_ru_24p_2412_24InL = heff_take_reuse_n(v_p_2412, 1ULL, 1);
    V v_t_2421;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_Throw: {
      V v_s_2415 = heff_field(v_x_2414, 0);
      V v_ru_24x_2414_24Throw = heff_take_reuse_n(v_x_2414, 1ULL, 1);
      v_t_2421 = heff_tag_at_n(v_ru_24x_2414_24Throw, TAG_Throw, 1, (V[]){v_s_2415});
      break;
    }
    case TAG_Catch: {
      V v_c_2416 = heff_field(v_x_2414, 0);
      V v_h_2417 = heff_field(v_x_2414, 1);
      V v_ru_24x_2414_24Catch = heff_take_reuse_n(v_x_2414, 3ULL, 2);
      V v_t_2418 = heff_tr(heff_call(v_c_2416, 2, (V[]){heff_dup(v_hd_2413), heff_dup(heff_rfield(v_hd_2413, 0))}));
      v_t_2421 = heff_tag_at_n(v_ru_24x_2414_24Catch, TAG_Catch, 2, (V[]){v_t_2418, heff_clo_n(g_co_2eop_24s1110804312x932325868_lam0, 1, 2, (V[]){v_h_2417, heff_dup(v_hd_2413)})});
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    v_t_2435 = heff_tag_at_n(v_ru_24p_2412_24InL, TAG_InL, 1, (V[]){v_t_2421});
    break;
  }
  case TAG_InR: {
    V v_y_2422 = heff_field(v_p_2412, 0);
    V v_ru_24p_2412_24InR = heff_take_reuse_n(v_p_2412, 1ULL, 1);
    V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1110804312x932325868_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1110804312x932325868_lam3, 2, 1, (V[]){heff_dup(v_hd_2413)})}), heff_clo_n(g_co_2eop_24s1110804312x932325868_lam5, 1, 1, (V[]){heff_dup(v_hd_2413)}), v_y_2422}));
    v_t_2435 = heff_tag_at_n(v_ru_24p_2412_24InR, TAG_InR, 1, (V[]){v_t_2434});
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2435}));
  return heff_tail(heff_get_n(v_hd_2413, 1, 3), 2, (V[]){v_t_2436, heff_clo_n(g_co_2eop_24s1110804312x932325868_lam6, 1, 12, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_lit_2410, v_lit_2411})});
}
V g_co_2eop_24s1110804312x932325868_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1110804312x932325868(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13]);
}
V g_co_2eop_24s1110804312x932325868_lam0(V self, V *args) {
  V v_s_2419 = args[0];
  V v_h_2417 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2420 = heff_tr(heff_call(v_h_2417, 1, (V[]){v_s_2419}));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_get_n(v_hd_2413, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1110804312x932325868_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_2423 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2428 = heff_tr(heff_call(v_g_2423, 1, (V[]){v_x_2427}));
  V f_ = v_k_2426;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1110804312x932325868_lam1(V self, V *args) {
  V v_g_2423 = args[0];
  V v_c_2424 = args[1];
  V v_hd_2425 = args[2];
  V v_k_2426 = args[3];
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_co_2eop_24s1110804312x932325868_lam2, 1, 2, (V[]){v_g_2423, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1110804312x932325868_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_g_2429 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_g_2429, 1, (V[]){v_x_2431}));
  V f_ = heff_get_n(v_hd_2413, 0, 3);
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1110804312x932325868_lam3(V self, V *args) {
  V v_g_2429 = args[0];
  V v_m_2430 = args[1];
  V v_hd_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2413, 1));
  args[0] = v_m_2430;
  args[1] = heff_clo_n(g_co_2eop_24s1110804312x932325868_lam4, 1, 2, (V[]){v_g_2429, v_hd_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1110804312x932325868_lam5(V self, V *args) {
  V v_c_2433 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_get_n(v_hd_2413, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1110804312x932325868_lam6(V self, V *args) {
  V v_a_2437 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  V v_lit_248 = heff_env(self)[8];
  V v_lit_249 = heff_env(self)[9];
  V v_lit_2410 = heff_env(self)[10];
  V v_lit_2411 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_a_2437);
  return (g_app_2eheff_2emain_2edispatch_24s1822917622x1005933181(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_lit_2410, v_lit_2411));
}
V g_co_2eop_24s826344058x1453420202_lam1(V self, V *args);
V g_co_2eop_24s826344058x1453420202_lam0(V self, V *args); static Clo g_co_2eop_24s826344058x1453420202_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s826344058x1453420202_lam0, 4, 0};
V g_co_2eop_24s826344058x1453420202_lam3(V self, V *args);
V g_co_2eop_24s826344058x1453420202_lam2(V self, V *args);
V g_co_2eop_24s826344058x1453420202_lam4(V self, V *args);
V g_co_2eop_24s826344058x1453420202_lam5(V self, V *args);
Clo g_co_2eop_24s826344058x1453420202_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s826344058x1453420202_entry, 3, 0};

V g_co_2eop_24s826344058x1453420202(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_x_243});
    break;
  }
  case TAG_InR: {
    V v_y_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_y_244)) {
    case TAG_InL: {
      V v_x_245 = heff_field(v_y_244, 0);
      V v_ru_24y_244_24InL = heff_take_reuse_n(v_y_244, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s826344058x1453420202_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s826344058x1453420202_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s826344058x1453420202_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_245}));
      v_t_2419 = heff_tag_at_n(v_ru_24y_244_24InL, TAG_InL, 1, (V[]){v_t_2417});
      break;
    }
    case TAG_InR: {
      V v_y_2418 = heff_field(v_y_244, 0);
      heff_take_n(v_y_244, 1ULL, 1);
      v_t_2419 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_y_2418});
      break;
    }
    default: heff_nomatch(v_y_244);
    }
    v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2421, heff_clo_n(g_co_2eop_24s826344058x1453420202_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s826344058x1453420202_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s826344058x1453420202(a[0], a[1], a[2]);
}
V g_co_2eop_24s826344058x1453420202_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s826344058x1453420202_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s826344058x1453420202_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s826344058x1453420202_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s826344058x1453420202_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s826344058x1453420202_lam3, 1, 2, (V[]){v_g_2412, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s826344058x1453420202_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s826344058x1453420202_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s540628709x1742946060_lam1(V self, V *args);
V g_co_2eop_24s540628709x1742946060_lam0(V self, V *args); static Clo g_co_2eop_24s540628709x1742946060_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s540628709x1742946060_lam0, 4, 0};
V g_co_2eop_24s540628709x1742946060_lam3(V self, V *args);
V g_co_2eop_24s540628709x1742946060_lam2(V self, V *args);
V g_co_2eop_24s540628709x1742946060_lam4(V self, V *args);
Clo g_co_2eop_24s540628709x1742946060_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s540628709x1742946060_entry, 3, 0};

V g_co_2eop_24s540628709x1742946060(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_x_243});
    break;
  }
  case TAG_InR: {
    V v_y_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_y_244)) {
    case TAG_InL: {
      V v_x_245 = heff_field(v_y_244, 0);
      V v_ru_24y_244_24InL = heff_take_reuse_n(v_y_244, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s540628709x1742946060_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s540628709x1742946060_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s540628709x1742946060_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_245}));
      v_t_2419 = heff_tag_at_n(v_ru_24y_244_24InL, TAG_InL, 1, (V[]){v_t_2417});
      break;
    }
    case TAG_InR: {
      V v_y_2418 = heff_field(v_y_244, 0);
      heff_take_n(v_y_244, 1ULL, 1);
      v_t_2419 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_y_2418});
      break;
    }
    default: heff_nomatch(v_y_244);
    }
    v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2421, v_k2_242});
}
V g_co_2eop_24s540628709x1742946060_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s540628709x1742946060(a[0], a[1], a[2]);
}
V g_co_2eop_24s540628709x1742946060_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s540628709x1742946060_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s540628709x1742946060_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s540628709x1742946060_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s540628709x1742946060_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s540628709x1742946060_lam3, 1, 2, (V[]){v_g_2412, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s540628709x1742946060_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s615738393x1686646143_24tok2_lam0(V self, V *args);
V g_co_2eop_24s615738393x1686646143_24tok2_lam2(V self, V *args);
V g_co_2eop_24s615738393x1686646143_24tok2_lam1(V self, V *args); static Clo g_co_2eop_24s615738393x1686646143_24tok2_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s615738393x1686646143_24tok2_lam1, 4, 0};
V g_co_2eop_24s615738393x1686646143_24tok2_lam4(V self, V *args);
V g_co_2eop_24s615738393x1686646143_24tok2_lam3(V self, V *args);
V g_co_2eop_24s615738393x1686646143_24tok2_lam5(V self, V *args);
Clo g_co_2eop_24s615738393x1686646143_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s615738393x1686646143_24tok2_entry, 4, 0};

V g_co_2eop_24s615738393x1686646143_24tok2(V v_tok_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_p_241)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InL = heff_take_reuse_n(v_p_241, 1ULL, 1);
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Throw: {
      V v_s_245 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Throw = heff_take_reuse_n(v_x_244, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Throw, TAG_Throw, 1, (V[]){v_s_245});
      break;
    }
    case TAG_Catch: {
      V v_c_246 = heff_field(v_x_244, 0);
      V v_h_247 = heff_field(v_x_244, 1);
      heff_take_n(v_x_244, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_dup(heff_rfield(v_hd_242, 0))}));
      v_t_2411 = heff_tag_at_n(v_tok_240, TAG_Catch, 2, (V[]){v_t_248, heff_clo_n(g_co_2eop_24s615738393x1686646143_24tok2_lam0, 1, 2, (V[]){v_h_247, heff_dup(v_hd_242)})});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InL, TAG_InL, 1, (V[]){v_t_2411});
    break;
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InR = heff_take_reuse_n(v_p_241, 1ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s615738393x1686646143_24tok2_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s615738393x1686646143_24tok2_lam3, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s615738393x1686646143_24tok2_lam5, 1, 1, (V[]){heff_dup(v_hd_242)}), v_y_2412}));
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InR, TAG_InR, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_p_241);
  }
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2426, v_k2_243});
}
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s615738393x1686646143_24tok2(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s615738393x1686646143_24tok2_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_h_247 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2410 = heff_tr(heff_call(v_h_247, 1, (V[]){v_s_249}));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s615738393x1686646143_24tok2_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2417}));
  V f_ = v_k_2416;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s615738393x1686646143_24tok2_lam1(V self, V *args) {
  V v_g_2413 = args[0];
  V v_c_2414 = args[1];
  V v_hd_2415 = args[2];
  V v_k_2416 = args[3];
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_co_2eop_24s615738393x1686646143_24tok2_lam2, 1, 2, (V[]){v_g_2413, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s615738393x1686646143_24tok2_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2419 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2421}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s615738393x1686646143_24tok2_lam3(V self, V *args) {
  V v_g_2419 = args[0];
  V v_m_2420 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2420;
  args[1] = heff_clo_n(g_co_2eop_24s615738393x1686646143_24tok2_lam4, 1, 2, (V[]){v_g_2419, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s615738393x1686646143_24tok2_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}