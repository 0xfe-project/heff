// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Await 41810
#define TAG_Begin 41697
#define TAG_Close 2276
#define TAG_Draw 50003
#define TAG_Finish 61316
#define TAG_Interactive 42932
#define TAG_IsTerminal 53507
#define TAG_Log 24016
#define TAG_Measure 52418
#define TAG_NewChan 9424
#define TAG_Open 48267
#define TAG_RDone 16778
#define TAG_ReadInput 54226
#define TAG_ReadStdin 20528
#define TAG_Recv 61489
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Sleep 25229
#define TAG_Spawn 10053
#define TAG_Start 63542
#define TAG_Terminate 62553
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_child 295989558
#define LBL_cwd 308458
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_fmap 9641981
#define LBL_heff 9694020
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_shutdown 575795380
#define LBL_style 311138763
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_app_2eheff_2emain_2edispatch_24s900934017x379470200(V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s900934017x379470200_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s900934017x379470200_clo;
V g_co_2ebind_24s441514442x2097556756(V, V, V, V);
V g_co_2ebind_24s441514442x2097556756_entry(V self, V *a);
extern Clo g_co_2ebind_24s441514442x2097556756_clo;
V g_co_2eop_24s1218157541x529269095(V, V, V);
V g_co_2eop_24s1218157541x529269095_entry(V self, V *a);
extern Clo g_co_2eop_24s1218157541x529269095_clo;
V g_co_2eop_24s1225551513x67222245(V, V, V, V, V);
V g_co_2eop_24s1225551513x67222245_entry(V self, V *a);
extern Clo g_co_2eop_24s1225551513x67222245_clo;
V g_co_2eop_24s1432398912x140120706(V, V, V, V, V, V);
V g_co_2eop_24s1432398912x140120706_entry(V self, V *a);
extern Clo g_co_2eop_24s1432398912x140120706_clo;
V g_co_2eop_24s1503604731x11983968(V, V, V, V, V);
V g_co_2eop_24s1503604731x11983968_entry(V self, V *a);
extern Clo g_co_2eop_24s1503604731x11983968_clo;
V g_co_2eop_24s158212438x2079511520(V, V, V, V, V, V, V);
V g_co_2eop_24s158212438x2079511520_entry(V self, V *a);
extern Clo g_co_2eop_24s158212438x2079511520_clo;
V g_co_2eop_24s162716155x1210144019(V, V, V);
V g_co_2eop_24s162716155x1210144019_entry(V self, V *a);
extern Clo g_co_2eop_24s162716155x1210144019_clo;
V g_co_2eop_24s1769951398x1534613602(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1769951398x1534613602_entry(V self, V *a);
extern Clo g_co_2eop_24s1769951398x1534613602_clo;
V g_co_2eop_24s2004353512x124285792(V, V, V, V, V);
V g_co_2eop_24s2004353512x124285792_entry(V self, V *a);
extern Clo g_co_2eop_24s2004353512x124285792_clo;
V g_co_2eop_24s237119878x1482184422(V, V, V, V, V);
V g_co_2eop_24s237119878x1482184422_entry(V self, V *a);
extern Clo g_co_2eop_24s237119878x1482184422_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s403979097x1380140111(V, V, V, V, V);
V g_co_2eop_24s403979097x1380140111_entry(V self, V *a);
extern Clo g_co_2eop_24s403979097x1380140111_clo;
V g_co_2eop_24s459815859x1387532636(V, V, V);
V g_co_2eop_24s459815859x1387532636_entry(V self, V *a);
extern Clo g_co_2eop_24s459815859x1387532636_clo;
V g_co_2eop_24s47784662x736955004(V, V);
V g_co_2eop_24s47784662x736955004_entry(V self, V *a);
extern Clo g_co_2eop_24s47784662x736955004_clo;
V g_co_2eop_24s707390346x636263434(V, V, V, V);
V g_co_2eop_24s707390346x636263434_entry(V self, V *a);
extern Clo g_co_2eop_24s707390346x636263434_clo;
V g_co_2eop_24s741235981x220947674(V, V, V, V, V, V, V);
V g_co_2eop_24s741235981x220947674_entry(V self, V *a);
extern Clo g_co_2eop_24s741235981x220947674_clo;
V g_co_2eop_24s792193458x1346260978(V, V, V);
V g_co_2eop_24s792193458x1346260978_entry(V self, V *a);
extern Clo g_co_2eop_24s792193458x1346260978_clo;
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_co_2eplus_24s115190544x963602094_get(void);
V g_co_2eplus_24s1226459126x1628219458_get(void);
V g_co_2eplus_24s1389063241x527387549_get(void);
V g_co_2eplus_24s169777576x280800149_get(void);
V g_co_2eplus_24s1854017309x1005292301_get(void);
V g_co_2eplus_24s2124540091x1079095538_get(void);
V g_co_2eplus_24s984570155x1252140766_get(void);
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826_clo;
V g_heff_2ebuild_2ecommands_2etestCmd_24s832044165x1092763255(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestCmd_24s832044165x1092763255_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestCmd_24s832044165x1092763255_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510(V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510_clo;
HeffT2 g_heff_2elsp_2erpc_2eeventOf_24cpr(V);
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2emap_2eempty_get(void);
V g_std_2enet_2enet_get(void);
V g_std_2eprocess_2eprocess_get(void);
V g_std_2ereactor_2ereactor_get(void);
V g_std_2eterminal_2econsole_get(void);
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args); static Clo g_co_2eop_24s310169282x2049378029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_lam0, 4, 0};
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args);
Clo g_co_2eop_24s310169282x2049378029_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_entry, 4, 0};

V g_co_2eop_24s310169282x2049378029(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s310169282x2049378029_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s310169282x2049378029_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s310169282x2049378029_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, v_k2_243});
}
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s310169282x2049378029(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2ebind_24s441514442x2097556756_lam0(V self, V *args);
Clo g_co_2ebind_24s441514442x2097556756_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s441514442x2097556756_entry, 4, 0};

V g_co_2ebind_24s441514442x2097556756(V v_c_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_co_2ebind_24s441514442x2097556756_lam0, 1, 3, (V[]){v_f_241, v_hd_242, v_k_243})});
}
V g_co_2ebind_24s441514442x2097556756_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s441514442x2097556756(a[0], a[1], a[2], a[3]);
}
V g_co_2ebind_24s441514442x2097556756_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_241;
  heff_room[0] = v_x_244;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eplus_24s169777576x280800149_lam1(V self, V *args);
V g_co_2eplus_24s169777576x280800149_lam0(V self, V *args); static Clo g_co_2eplus_24s169777576x280800149_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s169777576x280800149_lam0, 3, 0};
V g_co_2eplus_24s169777576x280800149_lam2(V self, V *args); static Clo g_co_2eplus_24s169777576x280800149_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s169777576x280800149_lam2, 4, 0};

static V g_co_2eplus_24s169777576x280800149_val;
static HEFF_ONCE g_co_2eplus_24s169777576x280800149_st;
static V g_co_2eplus_24s169777576x280800149_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s169777576x280800149_lam0_clo), ((V)&g_co_2eplus_24s169777576x280800149_lam2_clo)});
}
V g_co_2eplus_24s169777576x280800149_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s169777576x280800149_st)) return g_co_2eplus_24s169777576x280800149_val;
  return heff_global(&g_co_2eplus_24s169777576x280800149_val, &g_co_2eplus_24s169777576x280800149_st, g_co_2eplus_24s169777576x280800149_init);
}
V g_co_2eplus_24s169777576x280800149_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s169777576x280800149_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2414;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Write: {
        V v_str_245 = heff_field(v_x_244, 0);
        V v_x_246 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24Write = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_246}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24Write, TAG_Write, 2, (V[]){v_str_245, v_t_247});
        break;
      }
      case TAG_WriteErr: {
        V v_str_248 = heff_field(v_x_244, 0);
        V v_x_249 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24WriteErr = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_249}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_248, v_t_2410});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2411 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2eplus_24s169777576x280800149_lam1, 1, 2, (V[]){v_k_2411, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_InR: {
      V v_y_2415 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
      v_t_2417 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2418}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s169777576x280800149_lam2(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  switch (heff_tag_of(v_p_2423)) {
  case TAG_InL: {
    V v_x_2424 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InL = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_InL: {
      V v_x_2425 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InL = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      heff_drop(v_m_2420);
      heff_drop(v_n_2421);
      heff_drop(v_nt_2422);
      V v_t_2431;
      switch (heff_tag_of(v_x_2425)) {
      case TAG_Write: {
        V v_str_2426 = heff_field(v_x_2425, 0);
        V v_x_2427 = heff_field(v_x_2425, 1);
        V v_ru_24x_2425_24Write = heff_take_reuse_n(v_x_2425, 3ULL, 2);
        heff_drop_cell(v_ru_24x_2424_24InL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2425_24Write, TAG_Write, 2, (V[]){v_str_2426, v_x_2427});
        break;
      }
      case TAG_WriteErr: {
        V v_str_2428 = heff_field(v_x_2425, 0);
        V v_x_2429 = heff_field(v_x_2425, 1);
        V v_ru_24x_2425_24WriteErr = heff_take_reuse_n(v_x_2425, 3ULL, 2);
        heff_drop_cell(v_ru_24x_2424_24InL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2425_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_2428, v_x_2429});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2430 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24InL, TAG_ReadStdin, 1, (V[]){v_k_2430});
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      v_t_2434 = heff_tag_at_n(v_ru_24p_2423_24InL, TAG_InL, 1, (V[]){v_t_2431});
      break;
    }
    case TAG_InR: {
      V v_y_2432 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InR = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2423_24InL, 1);
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2432}));
      v_t_2434 = heff_tag_at_n(v_ru_24x_2424_24InR, TAG_InR, 1, (V[]){v_t_2433});
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2434});
  }
  case TAG_InR: {
    V v_y_2435 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InR = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2435}));
    return heff_tag_at_n(v_ru_24p_2423_24InR, TAG_InR, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_p_2423);
  }
}
V g_co_2eplus_24s115190544x963602094_lam1(V self, V *args);
V g_co_2eplus_24s115190544x963602094_lam2(V self, V *args);
V g_co_2eplus_24s115190544x963602094_lam0(V self, V *args); static Clo g_co_2eplus_24s115190544x963602094_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s115190544x963602094_lam0, 3, 0};
V g_co_2eplus_24s115190544x963602094_lam3(V self, V *args); static Clo g_co_2eplus_24s115190544x963602094_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s115190544x963602094_lam3, 4, 0};

static V g_co_2eplus_24s115190544x963602094_val;
static HEFF_ONCE g_co_2eplus_24s115190544x963602094_st;
static V g_co_2eplus_24s115190544x963602094_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s115190544x963602094_lam0_clo), ((V)&g_co_2eplus_24s115190544x963602094_lam3_clo)});
}
V g_co_2eplus_24s115190544x963602094_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s115190544x963602094_st)) return g_co_2eplus_24s115190544x963602094_val;
  return heff_global(&g_co_2eplus_24s115190544x963602094_val, &g_co_2eplus_24s115190544x963602094_st, g_co_2eplus_24s115190544x963602094_init);
}
V g_co_2eplus_24s115190544x963602094_lam1(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s115190544x963602094_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s115190544x963602094_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s984570155x1252140766_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_IsTerminal: {
      V v_k_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24IsTerminal = heff_take_reuse_n(v_y_245, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24IsTerminal, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2eplus_24s115190544x963602094_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_249 = heff_field(v_y_245, 0);
      V v_x_2410 = heff_field(v_y_245, 1);
      V v_ru_24y_245_24ShowLines = heff_take_reuse_n(v_y_245, 3ULL, 2);
      V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_249, v_t_2411});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2412 = heff_field(v_y_245, 0);
      V v_as_2413 = heff_field(v_y_245, 1);
      V v_lines_2414 = heff_field(v_y_245, 2);
      V v_k_2415 = heff_field(v_y_245, 3);
      V v_ru_24y_245_24ShowRun = heff_take_reuse_n(v_y_245, 15ULL, 4);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2412, v_as_2413, v_lines_2414, heff_clo_n(g_co_2eplus_24s115190544x963602094_lam2, 1, 2, (V[]){v_k_2415, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s115190544x963602094_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s984570155x1252140766_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2423}));
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    V v_t_2433;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_IsTerminal: {
      V v_k_2426 = heff_field(v_y_2425, 0);
      V v_ru_24y_2425_24IsTerminal = heff_take_reuse_n(v_y_2425, 1ULL, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24IsTerminal, TAG_IsTerminal, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2427 = heff_field(v_y_2425, 0);
      V v_x_2428 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24ShowLines = heff_take_reuse_n(v_y_2425, 3ULL, 2);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2427, v_x_2428});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2429 = heff_field(v_y_2425, 0);
      V v_as_2430 = heff_field(v_y_2425, 1);
      V v_lines_2431 = heff_field(v_y_2425, 2);
      V v_k_2432 = heff_field(v_y_2425, 3);
      V v_ru_24y_2425_24ShowRun = heff_take_reuse_n(v_y_2425, 15ULL, 4);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2429, v_as_2430, v_lines_2431, v_k_2432});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2433});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2eplus_24s1389063241x527387549_lam0(V self, V *args); static Clo g_co_2eplus_24s1389063241x527387549_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1389063241x527387549_lam0, 3, 0};
V g_co_2eplus_24s1389063241x527387549_lam1(V self, V *args); static Clo g_co_2eplus_24s1389063241x527387549_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1389063241x527387549_lam1, 4, 0};

static V g_co_2eplus_24s1389063241x527387549_val;
static HEFF_ONCE g_co_2eplus_24s1389063241x527387549_st;
static V g_co_2eplus_24s1389063241x527387549_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1389063241x527387549_lam0_clo), ((V)&g_co_2eplus_24s1389063241x527387549_lam1_clo)});
}
V g_co_2eplus_24s1389063241x527387549_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1389063241x527387549_st)) return g_co_2eplus_24s1389063241x527387549_val;
  return heff_global(&g_co_2eplus_24s1389063241x527387549_val, &g_co_2eplus_24s1389063241x527387549_st, g_co_2eplus_24s1389063241x527387549_init);
}
V g_co_2eplus_24s1389063241x527387549_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s115190544x963602094_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1389063241x527387549_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s984570155x1252140766_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_x_2412}));
      v_t_2423 = heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_InR: {
      V v_y_2414 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InR = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_m_247);
      heff_drop(v_n_248);
      heff_drop(v_nt_249);
      heff_drop_cell(v_ru_24p_2410_24InL, 1);
      V v_t_2422;
      switch (heff_tag_of(v_y_2414)) {
      case TAG_IsTerminal: {
        V v_k_2415 = heff_field(v_y_2414, 0);
        V v_ru_24y_2414_24IsTerminal = heff_take_reuse_n(v_y_2414, 1ULL, 1);
        v_t_2422 = heff_tag_at_n(v_ru_24y_2414_24IsTerminal, TAG_IsTerminal, 1, (V[]){v_k_2415});
        break;
      }
      case TAG_ShowLines: {
        V v_ls_2416 = heff_field(v_y_2414, 0);
        V v_x_2417 = heff_field(v_y_2414, 1);
        V v_ru_24y_2414_24ShowLines = heff_take_reuse_n(v_y_2414, 3ULL, 2);
        v_t_2422 = heff_tag_at_n(v_ru_24y_2414_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2416, v_x_2417});
        break;
      }
      case TAG_ShowRun: {
        V v_cmd_2418 = heff_field(v_y_2414, 0);
        V v_as_2419 = heff_field(v_y_2414, 1);
        V v_lines_2420 = heff_field(v_y_2414, 2);
        V v_k_2421 = heff_field(v_y_2414, 3);
        V v_ru_24y_2414_24ShowRun = heff_take_reuse_n(v_y_2414, 15ULL, 4);
        v_t_2422 = heff_tag_at_n(v_ru_24y_2414_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2418, v_as_2419, v_lines_2420, v_k_2421});
        break;
      }
      default: heff_nomatch(v_y_2414);
      }
      v_t_2423 = heff_tag_at_n(v_ru_24x_2411_24InR, TAG_InR, 1, (V[]){v_t_2422});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2423});
  }
  case TAG_InR: {
    V v_y_2424 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    heff_drop(v_nt_249);
    V v_t_2432;
    switch (heff_tag_of(v_y_2424)) {
    case TAG_Interactive: {
      V v_k_2425 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Interactive = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Interactive, TAG_Interactive, 1, (V[]){v_k_2425});
      break;
    }
    case TAG_Begin: {
      V v_k_2426 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Begin = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Begin, TAG_Begin, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_Finish: {
      V v_x_2427 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Finish = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Finish, TAG_Finish, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_Measure: {
      V v_k_2428 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Measure = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Measure, TAG_Measure, 1, (V[]){v_k_2428});
      break;
    }
    case TAG_ReadInput: {
      V v_k_2429 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24ReadInput = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24ReadInput, TAG_ReadInput, 1, (V[]){v_k_2429});
      break;
    }
    case TAG_Draw: {
      V v_s_2430 = heff_field(v_y_2424, 0);
      V v_x_2431 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24Draw = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Draw, TAG_Draw, 2, (V[]){v_s_2430, v_x_2431});
      break;
    }
    default: heff_nomatch(v_y_2424);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2432});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eplus_24s1226459126x1628219458_lam0(V self, V *args); static Clo g_co_2eplus_24s1226459126x1628219458_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1226459126x1628219458_lam0, 3, 0};
V g_co_2eplus_24s1226459126x1628219458_lam1(V self, V *args); static Clo g_co_2eplus_24s1226459126x1628219458_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1226459126x1628219458_lam1, 4, 0};

static V g_co_2eplus_24s1226459126x1628219458_val;
static HEFF_ONCE g_co_2eplus_24s1226459126x1628219458_st;
static V g_co_2eplus_24s1226459126x1628219458_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1226459126x1628219458_lam0_clo), ((V)&g_co_2eplus_24s1226459126x1628219458_lam1_clo)});
}
V g_co_2eplus_24s1226459126x1628219458_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1226459126x1628219458_st)) return g_co_2eplus_24s1226459126x1628219458_val;
  return heff_global(&g_co_2eplus_24s1226459126x1628219458_val, &g_co_2eplus_24s1226459126x1628219458_st, g_co_2eplus_24s1226459126x1628219458_init);
}
V g_co_2eplus_24s1226459126x1628219458_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_x_244)) {
      case TAG_InL: {
        V v_x_245 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s115190544x963602094_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_245}));
        v_t_249 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_246});
        break;
      }
      case TAG_InR: {
        V v_y_247 = heff_field(v_x_244, 0);
        V v_ru_24x_244_24InR = heff_take_reuse_n(v_x_244, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_247}));
        v_t_249 = heff_tag_at_n(v_ru_24x_244_24InR, TAG_InR, 1, (V[]){v_t_248});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_InL, 1, (V[]){v_t_249});
      break;
    }
    case TAG_InR: {
      V v_y_2410 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2414;
      switch (heff_tag_of(v_y_2410)) {
      case TAG_Sleep: {
        V v_ms_2411 = heff_field(v_y_2410, 0);
        V v_x_2412 = heff_field(v_y_2410, 1);
        V v_ru_24y_2410_24Sleep = heff_take_reuse_n(v_y_2410, 3ULL, 2);
        V v_t_2413 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2412}));
        v_t_2414 = heff_tag_at_n(v_ru_24y_2410_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2411, v_t_2413});
        break;
      }
      default: heff_nomatch(v_y_2410);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2416}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1226459126x1628219458_lam1(V self, V *args) {
  V v_m_2418 = args[0];
  V v_n_2419 = args[1];
  V v_nt_2420 = args[2];
  V v_p_2421 = args[3];
  switch (heff_tag_of(v_p_2421)) {
  case TAG_InL: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InL = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_InL: {
      V v_x_2423 = heff_field(v_x_2422, 0);
      heff_take_n(v_x_2422, 1ULL, 1);
      V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1389063241x527387549_get(), 1)), 4, (V[]){v_m_2418, v_n_2419, v_nt_2420, v_x_2423}));
      v_t_2429 = heff_tag_at_n(v_ru_24p_2421_24InL, TAG_InL, 1, (V[]){v_t_2424});
      break;
    }
    case TAG_InR: {
      V v_y_2425 = heff_field(v_x_2422, 0);
      V v_ru_24x_2422_24InR = heff_take_reuse_n(v_x_2422, 1ULL, 1);
      heff_drop(v_m_2418);
      heff_drop(v_n_2419);
      heff_drop(v_nt_2420);
      heff_drop_cell(v_ru_24p_2421_24InL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_y_2425)) {
      case TAG_Sleep: {
        V v_ms_2426 = heff_field(v_y_2425, 0);
        V v_x_2427 = heff_field(v_y_2425, 1);
        V v_ru_24y_2425_24Sleep = heff_take_reuse_n(v_y_2425, 3ULL, 2);
        v_t_2428 = heff_tag_at_n(v_ru_24y_2425_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2426, v_x_2427});
        break;
      }
      default: heff_nomatch(v_y_2425);
      }
      v_t_2429 = heff_tag_at_n(v_ru_24x_2422_24InR, TAG_InR, 1, (V[]){v_t_2428});
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2429});
  }
  case TAG_InR: {
    V v_y_2430 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InR = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 1)), 4, (V[]){v_m_2418, v_n_2419, v_nt_2420, v_y_2430}));
    return heff_tag_at_n(v_ru_24p_2421_24InR, TAG_InR, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_co_2eplus_24s2124540091x1079095538_lam0(V self, V *args); static Clo g_co_2eplus_24s2124540091x1079095538_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s2124540091x1079095538_lam0, 3, 0};
V g_co_2eplus_24s2124540091x1079095538_lam3(V self, V *args);
V g_co_2eplus_24s2124540091x1079095538_lam2(V self, V *args);
V g_co_2eplus_24s2124540091x1079095538_lam1(V self, V *args); static Clo g_co_2eplus_24s2124540091x1079095538_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s2124540091x1079095538_lam1, 4, 0};

static V g_co_2eplus_24s2124540091x1079095538_val;
static HEFF_ONCE g_co_2eplus_24s2124540091x1079095538_st;
static V g_co_2eplus_24s2124540091x1079095538_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s2124540091x1079095538_lam0_clo), ((V)&g_co_2eplus_24s2124540091x1079095538_lam1_clo)});
}
V g_co_2eplus_24s2124540091x1079095538_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s2124540091x1079095538_st)) return g_co_2eplus_24s2124540091x1079095538_val;
  return heff_global(&g_co_2eplus_24s2124540091x1079095538_val, &g_co_2eplus_24s2124540091x1079095538_st, g_co_2eplus_24s2124540091x1079095538_init);
}
V g_co_2eplus_24s2124540091x1079095538_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1226459126x1628219458_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s2124540091x1079095538_lam3(V self, V *args) {
  V v_c_2428 = args[0];
  V v_k_2429 = args[1];
  V v_nt_249 = heff_env(self)[0];
  V v_use_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_call(v_nt_249, 1, (V[]){v_c_2428}));
  V f_ = v_use_2427;
  args[0] = v_t_2430;
  args[1] = v_k_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eplus_24s2124540091x1079095538_lam2(V self, V *args) {
  V v_use_2427 = args[0];
  V v_b_2426 = heff_env(self)[0];
  V v_nt_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2426;
  args[0] = heff_clo_n(g_co_2eplus_24s2124540091x1079095538_lam3, 2, 2, (V[]){v_nt_249, v_use_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s2124540091x1079095538_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InL = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2412)) {
      case TAG_InL: {
        V v_x_2413 = heff_field(v_x_2412, 0);
        heff_take_n(v_x_2412, 1ULL, 1);
        V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1389063241x527387549_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_x_2413}));
        v_t_2419 = heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2414});
        break;
      }
      case TAG_InR: {
        V v_y_2415 = heff_field(v_x_2412, 0);
        V v_ru_24x_2412_24InR = heff_take_reuse_n(v_x_2412, 1ULL, 1);
        heff_drop(v_m_247);
        heff_drop(v_n_248);
        heff_drop(v_nt_249);
        heff_drop_cell(v_ru_24p_2410_24InL, 1);
        V v_t_2418;
        switch (heff_tag_of(v_y_2415)) {
        case TAG_Sleep: {
          V v_ms_2416 = heff_field(v_y_2415, 0);
          V v_x_2417 = heff_field(v_y_2415, 1);
          V v_ru_24y_2415_24Sleep = heff_take_reuse_n(v_y_2415, 3ULL, 2);
          v_t_2418 = heff_tag_at_n(v_ru_24y_2415_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2416, v_x_2417});
          break;
        }
        default: heff_nomatch(v_y_2415);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24InR, TAG_InR, 1, (V[]){v_t_2418});
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24InL, TAG_InL, 1, (V[]){v_t_2419});
      break;
    }
    case TAG_InR: {
      V v_y_2420 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InR = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2410_24InL, 1);
      V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_y_2420}));
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24InR, TAG_InR, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    V v_t_2436;
    switch (heff_tag_of(v_y_2423)) {
    case TAG_Open: {
      V v_k_2424 = heff_field(v_y_2423, 0);
      V v_ru_24y_2423_24Open = heff_take_reuse_n(v_y_2423, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Open, TAG_Open, 1, (V[]){v_k_2424});
      break;
    }
    case TAG_Start: {
      V v_i_2425 = heff_field(v_y_2423, 0);
      V v_b_2426 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24Start = heff_take_reuse_n(v_y_2423, 3ULL, 2);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Start, TAG_Start, 2, (V[]){v_i_2425, heff_clo_n(g_co_2eplus_24s2124540091x1079095538_lam2, 1, 2, (V[]){v_b_2426, v_nt_249})});
      break;
    }
    case TAG_Finish: {
      V v_i_2431 = heff_field(v_y_2423, 0);
      V v_w_2432 = heff_field(v_y_2423, 1);
      V v_f_2433 = heff_field(v_y_2423, 2);
      V v_ru_24y_2423_24Finish = heff_take_reuse_n(v_y_2423, 7ULL, 3);
      heff_drop(v_nt_249);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Finish, TAG_Finish, 3, (V[]){v_i_2431, v_w_2432, v_f_2433});
      break;
    }
    case TAG_Close: {
      V v_i_2434 = heff_field(v_y_2423, 0);
      V v_x_2435 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24Close = heff_take_reuse_n(v_y_2423, 3ULL, 2);
      heff_drop(v_nt_249);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Close, TAG_Close, 2, (V[]){v_i_2434, v_x_2435});
      break;
    }
    default: heff_nomatch(v_y_2423);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eop_24s707390346x636263434_lam1(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam0(V self, V *args); static Clo g_co_2eop_24s707390346x636263434_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s707390346x636263434_lam0, 4, 0};
V g_co_2eop_24s707390346x636263434_lam3(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam2(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam4(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam5(V self, V *args);
Clo g_co_2eop_24s707390346x636263434_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s707390346x636263434_entry, 4, 0};

V g_co_2eop_24s707390346x636263434(V v_p_240, V v_k_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s707390346x636263434_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s707390346x636263434_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s707390346x636263434_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_x_244}));
    v_t_2421 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2416});
    break;
  }
  case TAG_InR: {
    V v_y_2417 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Send: {
      V v_rq_2418 = heff_field(v_y_2417, 0);
      V v_k_2419 = heff_field(v_y_2417, 1);
      V v_ru_24y_2417_24Send = heff_take_reuse_n(v_y_2417, 3ULL, 2);
      v_t_2420 = heff_tag_at_n(v_ru_24y_2417_24Send, TAG_Send, 2, (V[]){v_rq_2418, v_k_2419});
      break;
    }
    default: heff_nomatch(v_y_2417);
    }
    v_t_2421 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2420});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2421}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s707390346x636263434_lam5, 1, 3, (V[]){v_k_241, v_hd_242, v_k2_243})});
}
V g_co_2eop_24s707390346x636263434_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s707390346x636263434(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s707390346x636263434_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s707390346x636263434_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s707390346x636263434_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s707390346x636263434_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s707390346x636263434_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s707390346x636263434_lam3, 1, 2, (V[]){v_g_2411, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s707390346x636263434_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s707390346x636263434_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k2_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  heff_room[0] = v_x_2423;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k2_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1218157541x529269095_lam1(V self, V *args);
V g_co_2eop_24s1218157541x529269095_lam0(V self, V *args); static Clo g_co_2eop_24s1218157541x529269095_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1218157541x529269095_lam0, 4, 0};
V g_co_2eop_24s1218157541x529269095_lam3(V self, V *args);
V g_co_2eop_24s1218157541x529269095_lam2(V self, V *args);
V g_co_2eop_24s1218157541x529269095_lam4(V self, V *args);
Clo g_co_2eop_24s1218157541x529269095_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1218157541x529269095_entry, 3, 0};

V g_co_2eop_24s1218157541x529269095(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1218157541x529269095_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1218157541x529269095_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1218157541x529269095_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_243}));
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Send: {
      V v_rq_2417 = heff_field(v_y_2416, 0);
      V v_k_2418 = heff_field(v_y_2416, 1);
      V v_ru_24y_2416_24Send = heff_take_reuse_n(v_y_2416, 3ULL, 2);
      v_t_2419 = heff_tag_at_n(v_ru_24y_2416_24Send, TAG_Send, 2, (V[]){v_rq_2417, v_k_2418});
      break;
    }
    default: heff_nomatch(v_y_2416);
    }
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2421, v_k2_242});
}
V g_co_2eop_24s1218157541x529269095_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1218157541x529269095(a[0], a[1], a[2]);
}
V g_co_2eop_24s1218157541x529269095_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1218157541x529269095_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s1218157541x529269095_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1218157541x529269095_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1218157541x529269095_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1218157541x529269095_lam3, 1, 2, (V[]){v_g_2410, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1218157541x529269095_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s94900133x232571340_lam1(V self, V *args);
V g_co_2eop_24s94900133x232571340_lam0(V self, V *args); static Clo g_co_2eop_24s94900133x232571340_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s94900133x232571340_lam0, 4, 0};
V g_co_2eop_24s94900133x232571340_lam3(V self, V *args);
V g_co_2eop_24s94900133x232571340_lam2(V self, V *args);
V g_co_2eop_24s94900133x232571340_lam4(V self, V *args);
Clo g_co_2eop_24s94900133x232571340_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s94900133x232571340_entry, 3, 0};

V g_co_2eop_24s94900133x232571340(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s94900133x232571340_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s94900133x232571340_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s94900133x232571340_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s94900133x232571340_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s94900133x232571340(a[0], a[1], a[2]);
}
V g_co_2eop_24s94900133x232571340_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s94900133x232571340_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s94900133x232571340_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s94900133x232571340_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s94900133x232571340_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s94900133x232571340_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s94900133x232571340_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s903439140x919002362_lam1(V self, V *args);
V g_co_2eop_24s903439140x919002362_lam0(V self, V *args); static Clo g_co_2eop_24s903439140x919002362_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s903439140x919002362_lam0, 4, 0};
V g_co_2eop_24s903439140x919002362_lam3(V self, V *args);
V g_co_2eop_24s903439140x919002362_lam2(V self, V *args);
V g_co_2eop_24s903439140x919002362_lam4(V self, V *args);
Clo g_co_2eop_24s903439140x919002362_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s903439140x919002362_entry, 3, 0};

V g_co_2eop_24s903439140x919002362(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s903439140x919002362_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s903439140x919002362_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s903439140x919002362_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s903439140x919002362_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s903439140x919002362(a[0], a[1], a[2]);
}
V g_co_2eop_24s903439140x919002362_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s903439140x919002362_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s903439140x919002362_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s903439140x919002362_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s903439140x919002362_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s903439140x919002362_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s903439140x919002362_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s1503604731x11983968_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_co_2eop_24s1503604731x11983968_str1, 1, "\012");
V g_co_2eop_24s1503604731x11983968_lam1(V self, V *args);
V g_co_2eop_24s1503604731x11983968_lam0(V self, V *args); static Clo g_co_2eop_24s1503604731x11983968_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1503604731x11983968_lam0, 4, 0};
V g_co_2eop_24s1503604731x11983968_lam3(V self, V *args);
V g_co_2eop_24s1503604731x11983968_lam2(V self, V *args);
V g_co_2eop_24s1503604731x11983968_lam4(V self, V *args);
V g_co_2eop_24s1503604731x11983968_lam5(V self, V *args);
Clo g_co_2eop_24s1503604731x11983968_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1503604731x11983968_entry, 5, 0};

V g_co_2eop_24s1503604731x11983968(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1503604731x11983968_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1503604731x11983968_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s1503604731x11983968_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s1503604731x11983968_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s1503604731x11983968_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1503604731x11983968(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s1503604731x11983968_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1503604731x11983968_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s1503604731x11983968_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1503604731x11983968_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1503604731x11983968_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1503604731x11983968_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1503604731x11983968_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1503604731x11983968_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_x1_2419 = v_lit_240;
  V v_p_2420 = v_lit_241;
  V v_p_2421 = v_lit_242;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    heff_drop(v_p_2420);
    V f_ = v_p_2421;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_e_2422 = heff_field(v_x1_2419, 0);
    V v_rest_2423 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_co_2eop_24s1503604731x11983968_str0), v_e_2422), ((V)&g_co_2eop_24s1503604731x11983968_str1));
    V v_t_2425 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_WriteErr, 2, (V[]){v_t_2424, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s1503604731x11983968(v_rest_2423, heff_dup(v_p_2420), v_p_2421, heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_p_2420));
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_co_2eop_24s158212438x2079511520_lam1(V self, V *args);
V g_co_2eop_24s158212438x2079511520_lam0(V self, V *args); static Clo g_co_2eop_24s158212438x2079511520_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s158212438x2079511520_lam0, 4, 0};
V g_co_2eop_24s158212438x2079511520_lam3(V self, V *args);
V g_co_2eop_24s158212438x2079511520_lam2(V self, V *args);
V g_co_2eop_24s158212438x2079511520_lam4(V self, V *args);
V g_co_2eop_24s158212438x2079511520_lam5(V self, V *args);
Clo g_co_2eop_24s158212438x2079511520_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s158212438x2079511520_entry, 7, 0};

V g_co_2eop_24s158212438x2079511520(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_p_245, V v_hd_246) {
top: ;
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s158212438x2079511520_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s158212438x2079511520_lam2, 2, 1, (V[]){heff_dup(v_hd_246)})}), heff_clo_n(g_co_2eop_24s158212438x2079511520_lam4, 1, 1, (V[]){heff_dup(v_hd_246)}), v_p_245}));
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2419, heff_clo_n(g_co_2eop_24s158212438x2079511520_lam5, 1, 5, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244})});
}
V g_co_2eop_24s158212438x2079511520_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s158212438x2079511520(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_co_2eop_24s158212438x2079511520_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2412 = heff_tr(heff_call(v_g_247, 1, (V[]){v_x_2411}));
  V f_ = v_k_2410;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s158212438x2079511520_lam0(V self, V *args) {
  V v_g_247 = args[0];
  V v_c_248 = args[1];
  V v_hd_249 = args[2];
  V v_k_2410 = args[3];
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_co_2eop_24s158212438x2079511520_lam1, 1, 2, (V[]){v_g_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s158212438x2079511520_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2415}));
  V f_ = heff_get_n(v_hd_246, 0, 3);
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s158212438x2079511520_lam2(V self, V *args) {
  V v_g_2413 = args[0];
  V v_m_2414 = args[1];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_m_2414;
  args[1] = heff_clo_n(g_co_2eop_24s158212438x2079511520_lam3, 1, 2, (V[]){v_g_2413, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s158212438x2079511520_lam4(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_get_n(v_hd_246, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s158212438x2079511520_lam5(V self, V *args) {
  V v_a_2420 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_a_2420);
  V v_t_2421 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V r_ = (g_heff_2ebuild_2ecommands_2eprintFails_24s315854x412985826(a_0, a_1, a_2)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2421;
  heff_room[0] = v_lit_243;
  heff_room[1] = v_lit_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s2004353512x124285792_str0, 1, "\012");
V g_co_2eop_24s2004353512x124285792_lam1(V self, V *args);
V g_co_2eop_24s2004353512x124285792_lam0(V self, V *args); static Clo g_co_2eop_24s2004353512x124285792_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2004353512x124285792_lam0, 4, 0};
V g_co_2eop_24s2004353512x124285792_lam3(V self, V *args);
V g_co_2eop_24s2004353512x124285792_lam2(V self, V *args);
V g_co_2eop_24s2004353512x124285792_lam4(V self, V *args);
V g_co_2eop_24s2004353512x124285792_lam5(V self, V *args);
Clo g_co_2eop_24s2004353512x124285792_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2004353512x124285792_entry, 5, 0};

V g_co_2eop_24s2004353512x124285792(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s2004353512x124285792_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s2004353512x124285792_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s2004353512x124285792_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s2004353512x124285792_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s2004353512x124285792_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s2004353512x124285792(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s2004353512x124285792_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2004353512x124285792_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s2004353512x124285792_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2004353512x124285792_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2004353512x124285792_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s2004353512x124285792_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2004353512x124285792_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s2004353512x124285792_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_x1_2419 = v_lit_240;
  V v_p_2420 = v_lit_241;
  V v_p_2421 = v_lit_242;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    heff_drop(v_p_2420);
    V f_ = v_p_2421;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2422 = heff_field(v_x1_2419, 0);
    V v_rest_2423 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    V v_t_2424 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_2422, ((V)&g_co_2eop_24s2004353512x124285792_str0)), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s2004353512x124285792(v_rest_2423, heff_dup(v_p_2420), v_p_2421, heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_p_2420));
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_co_2eop_24s741235981x220947674_lam1(V self, V *args);
V g_co_2eop_24s741235981x220947674_lam0(V self, V *args); static Clo g_co_2eop_24s741235981x220947674_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s741235981x220947674_lam0, 4, 0};
V g_co_2eop_24s741235981x220947674_lam3(V self, V *args);
V g_co_2eop_24s741235981x220947674_lam2(V self, V *args);
V g_co_2eop_24s741235981x220947674_lam4(V self, V *args);
V g_co_2eop_24s741235981x220947674_lam5(V self, V *args);
Clo g_co_2eop_24s741235981x220947674_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s741235981x220947674_entry, 7, 0};

V g_co_2eop_24s741235981x220947674(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_p_245, V v_hd_246) {
top: ;
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s741235981x220947674_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s741235981x220947674_lam2, 2, 1, (V[]){heff_dup(v_hd_246)})}), heff_clo_n(g_co_2eop_24s741235981x220947674_lam4, 1, 1, (V[]){heff_dup(v_hd_246)}), v_p_245}));
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2419, heff_clo_n(g_co_2eop_24s741235981x220947674_lam5, 1, 5, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244})});
}
V g_co_2eop_24s741235981x220947674_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s741235981x220947674(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_co_2eop_24s741235981x220947674_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2412 = heff_tr(heff_call(v_g_247, 1, (V[]){v_x_2411}));
  V f_ = v_k_2410;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s741235981x220947674_lam0(V self, V *args) {
  V v_g_247 = args[0];
  V v_c_248 = args[1];
  V v_hd_249 = args[2];
  V v_k_2410 = args[3];
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_co_2eop_24s741235981x220947674_lam1, 1, 2, (V[]){v_g_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s741235981x220947674_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2415}));
  V f_ = heff_get_n(v_hd_246, 0, 3);
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s741235981x220947674_lam2(V self, V *args) {
  V v_g_2413 = args[0];
  V v_m_2414 = args[1];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_m_2414;
  args[1] = heff_clo_n(g_co_2eop_24s741235981x220947674_lam3, 1, 2, (V[]){v_g_2413, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s741235981x220947674_lam4(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_get_n(v_hd_246, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s741235981x220947674_lam5(V self, V *args) {
  V v_a_2420 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2etestCmd_24s832044165x1092763255(v_lit_240, v_a_2420, v_lit_241, v_lit_242, heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()), NTAG(TAG_Nil), v_lit_243, v_lit_244));
}
V g_co_2eop_24s237119878x1482184422_lam1(V self, V *args);
V g_co_2eop_24s237119878x1482184422_lam0(V self, V *args); static Clo g_co_2eop_24s237119878x1482184422_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s237119878x1482184422_lam0, 4, 0};
V g_co_2eop_24s237119878x1482184422_lam3(V self, V *args);
V g_co_2eop_24s237119878x1482184422_lam2(V self, V *args);
V g_co_2eop_24s237119878x1482184422_lam4(V self, V *args);
V g_co_2eop_24s237119878x1482184422_lam6(V self, V *args); static Clo g_co_2eop_24s237119878x1482184422_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s237119878x1482184422_lam6, 1, 0};
V g_co_2eop_24s237119878x1482184422_lam5(V self, V *args);
Clo g_co_2eop_24s237119878x1482184422_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s237119878x1482184422_entry, 5, 0};

V g_co_2eop_24s237119878x1482184422(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s237119878x1482184422_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s237119878x1482184422_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s237119878x1482184422_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s237119878x1482184422_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s237119878x1482184422_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s237119878x1482184422(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s237119878x1482184422_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s237119878x1482184422_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s237119878x1482184422_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s237119878x1482184422_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s237119878x1482184422_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s237119878x1482184422_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s237119878x1482184422_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s237119878x1482184422_lam6(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_co_2eop_24s237119878x1482184422_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_x1_2419 = v_lit_240;
  V v_p_2420 = v_lit_241;
  V v_p_2421 = v_lit_242;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    heff_drop(v_p_2420);
    V f_ = v_p_2421;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_r_2422 = heff_field(v_x1_2419, 0);
    V v_rest_2423 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    V v_t_2425 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_Terminate, 2, (V[]){heff_get_n(v_r_2422, 1, 2), ((V)&g_co_2eop_24s237119878x1482184422_lam6_clo)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s237119878x1482184422(v_rest_2423, heff_dup(v_p_2420), v_p_2421, heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_p_2420));
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_co_2eop_24s1432398912x140120706_lam1(V self, V *args);
V g_co_2eop_24s1432398912x140120706_lam0(V self, V *args); static Clo g_co_2eop_24s1432398912x140120706_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1432398912x140120706_lam0, 4, 0};
V g_co_2eop_24s1432398912x140120706_lam3(V self, V *args);
V g_co_2eop_24s1432398912x140120706_lam2(V self, V *args);
V g_co_2eop_24s1432398912x140120706_lam4(V self, V *args);
V g_co_2eop_24s1432398912x140120706_lam5(V self, V *args);
Clo g_co_2eop_24s1432398912x140120706_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1432398912x140120706_entry, 6, 0};

V g_co_2eop_24s1432398912x140120706(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1432398912x140120706_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1432398912x140120706_lam2, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s1432398912x140120706_lam4, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2418, heff_clo_n(g_co_2eop_24s1432398912x140120706_lam5, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s1432398912x140120706_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1432398912x140120706(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s1432398912x140120706_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1432398912x140120706_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s1432398912x140120706_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1432398912x140120706_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1432398912x140120706_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s1432398912x140120706_lam3, 1, 2, (V[]){v_g_2412, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1432398912x140120706_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1432398912x140120706_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2419);
  return (g_heff_2ebuild_2edev_2estillRunning_24s396378740x1456780069(v_lit_240, v_lit_241, v_lit_242, v_lit_243));
}
HEFF_LIT(g_co_2eop_24s403979097x1380140111_str0, 10, "not JSON, ");
V g_co_2eop_24s403979097x1380140111_lam1(V self, V *args);
V g_co_2eop_24s403979097x1380140111_lam0(V self, V *args); static Clo g_co_2eop_24s403979097x1380140111_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s403979097x1380140111_lam0, 4, 0};
V g_co_2eop_24s403979097x1380140111_lam3(V self, V *args);
V g_co_2eop_24s403979097x1380140111_lam2(V self, V *args);
V g_co_2eop_24s403979097x1380140111_lam4(V self, V *args);
V g_co_2eop_24s403979097x1380140111_lam6(V self, V *args); static Clo g_co_2eop_24s403979097x1380140111_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s403979097x1380140111_lam6, 1, 0};
V g_co_2eop_24s403979097x1380140111_lam7(V self, V *args);
V g_co_2eop_24s403979097x1380140111_lam5(V self, V *args);
Clo g_co_2eop_24s403979097x1380140111_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s403979097x1380140111_entry, 5, 0};

V g_co_2eop_24s403979097x1380140111(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s403979097x1380140111_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s403979097x1380140111_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s403979097x1380140111_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s403979097x1380140111_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s403979097x1380140111_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s403979097x1380140111(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s403979097x1380140111_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s403979097x1380140111_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s403979097x1380140111_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s403979097x1380140111_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s403979097x1380140111_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s403979097x1380140111_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s403979097x1380140111_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s403979097x1380140111_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  return v_x_2424;
}
V g_co_2eop_24s403979097x1380140111_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_ms_2419 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2430 = (g_heff_2elsp_2erpc_2eeventOf_24cpr(v_x_2429));
  {
    V v_field_2432 = v_t_2430.f[1];
    int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
    if ((v_tag_2431 == ((int64_t)0ULL))) {
      V v_x_2434 = v_field_2432;
      V v_t_2435 = heff_tag_n(TAG_Log, 2, (V[]){heff_strAppend(((V)&g_co_2eop_24s403979097x1380140111_str0), v_x_2434), NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s403979097x1380140111(v_ms_2419, heff_dup(v_hd_2420), v_k_2421, v_t_2439, v_hd_2420));
    } else {
      heff_drop(v_ms_2419);
      heff_drop(v_hd_2420);
      V v_y_2440 = v_field_2432;
      V f_ = v_k_2421;
      args[0] = v_y_2440;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_co_2eop_24s403979097x1380140111_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_ms_2419 = v_lit_240;
  V v_hd_2420 = v_lit_241;
  V v_k_2421 = v_lit_242;
  V v_t_2423;
  switch (heff_tag_of(v_ms_2419)) {
  case TAG_Nothing: {
    v_t_2423 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_dup(heff_field(v_ms_2419, 0));
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_ms_2419);
  }
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Await, 2, (V[]){v_t_2423, ((V)&g_co_2eop_24s403979097x1380140111_lam6_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_2420), heff_clo_n(g_co_2eop_24s403979097x1380140111_lam7, 1, 3, (V[]){v_ms_2419, v_hd_2420, v_k_2421})));
}
V g_co_2eop_24s1225551513x67222245_lam1(V self, V *args);
V g_co_2eop_24s1225551513x67222245_lam0(V self, V *args); static Clo g_co_2eop_24s1225551513x67222245_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1225551513x67222245_lam0, 4, 0};
V g_co_2eop_24s1225551513x67222245_lam3(V self, V *args);
V g_co_2eop_24s1225551513x67222245_lam2(V self, V *args);
V g_co_2eop_24s1225551513x67222245_lam4(V self, V *args);
V g_co_2eop_24s1225551513x67222245_lam5(V self, V *args);
Clo g_co_2eop_24s1225551513x67222245_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1225551513x67222245_entry, 5, 0};

V g_co_2eop_24s1225551513x67222245(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1225551513x67222245_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1225551513x67222245_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s1225551513x67222245_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s1225551513x67222245_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s1225551513x67222245_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1225551513x67222245(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s1225551513x67222245_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1225551513x67222245_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s1225551513x67222245_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1225551513x67222245_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1225551513x67222245_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1225551513x67222245_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1225551513x67222245_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1225551513x67222245_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = ({ V rv_0 = v_a_2418; V rr_ = heff_rec_reuse_nf(v_lit_240, 30ULL, 5, shape_lib__mod__cwd__style__heff, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2420 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_False), v_t_2419});
  return (g_heff_2elsp_2elsp_2eserveFrom_24s71991633x413400510(v_t_2420, v_lit_241, v_lit_242));
}
V g_co_2eop_24s162716155x1210144019_lam1(V self, V *args);
V g_co_2eop_24s162716155x1210144019_lam0(V self, V *args); static Clo g_co_2eop_24s162716155x1210144019_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s162716155x1210144019_lam0, 4, 0};
V g_co_2eop_24s162716155x1210144019_lam3(V self, V *args);
V g_co_2eop_24s162716155x1210144019_lam2(V self, V *args);
V g_co_2eop_24s162716155x1210144019_lam4(V self, V *args);
Clo g_co_2eop_24s162716155x1210144019_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s162716155x1210144019_entry, 3, 0};

V g_co_2eop_24s162716155x1210144019(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Spawn: {
      V v_c_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Spawn = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Spawn, TAG_Spawn, 2, (V[]){v_t_246, v_x_245});
      break;
    }
    case TAG_Yield: {
      V v_x_247 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Yield = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Yield, TAG_Yield, 1, (V[]){v_x_247});
      break;
    }
    case TAG_NewChan: {
      V v_k_248 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24NewChan = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24NewChan, TAG_NewChan, 1, (V[]){v_k_248});
      break;
    }
    case TAG_Send: {
      V v_ch_249 = heff_field(v_x_243, 0);
      V v_v_2410 = heff_field(v_x_243, 1);
      V v_x_2411 = heff_field(v_x_243, 2);
      V v_ru_24x_243_24Send = heff_take_reuse_n(v_x_243, 7ULL, 3);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Send, TAG_Send, 3, (V[]){v_ch_249, v_v_2410, v_x_2411});
      break;
    }
    case TAG_Recv: {
      V v_ch_2412 = heff_field(v_x_243, 0);
      V v_k_2413 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Recv = heff_take_reuse_n(v_x_243, 3ULL, 2);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Recv, TAG_Recv, 2, (V[]){v_ch_2412, v_k_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2414});
    break;
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s162716155x1210144019_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s162716155x1210144019_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s162716155x1210144019_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2415}));
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2427});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2428}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2429, v_k2_242});
}
V g_co_2eop_24s162716155x1210144019_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s162716155x1210144019(a[0], a[1], a[2]);
}
V g_co_2eop_24s162716155x1210144019_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2420}));
  V f_ = v_k_2419;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s162716155x1210144019_lam0(V self, V *args) {
  V v_g_2416 = args[0];
  V v_c_2417 = args[1];
  V v_hd_2418 = args[2];
  V v_k_2419 = args[3];
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_co_2eop_24s162716155x1210144019_lam1, 1, 2, (V[]){v_g_2416, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s162716155x1210144019_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_x_2424}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s162716155x1210144019_lam2(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2423;
  args[1] = heff_clo_n(g_co_2eop_24s162716155x1210144019_lam3, 1, 2, (V[]){v_g_2422, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s162716155x1210144019_lam4(V self, V *args) {
  V v_c_2426 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s459815859x1387532636_lam1(V self, V *args);
V g_co_2eop_24s459815859x1387532636_lam0(V self, V *args); static Clo g_co_2eop_24s459815859x1387532636_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s459815859x1387532636_lam0, 4, 0};
V g_co_2eop_24s459815859x1387532636_lam3(V self, V *args);
V g_co_2eop_24s459815859x1387532636_lam2(V self, V *args);
V g_co_2eop_24s459815859x1387532636_lam4(V self, V *args);
Clo g_co_2eop_24s459815859x1387532636_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s459815859x1387532636_entry, 3, 0};

V g_co_2eop_24s459815859x1387532636(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Spawn: {
      V v_c_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Spawn = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Spawn, TAG_Spawn, 2, (V[]){v_t_246, v_x_245});
      break;
    }
    case TAG_Yield: {
      V v_x_247 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Yield = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Yield, TAG_Yield, 1, (V[]){v_x_247});
      break;
    }
    case TAG_NewChan: {
      V v_k_248 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24NewChan = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24NewChan, TAG_NewChan, 1, (V[]){v_k_248});
      break;
    }
    case TAG_Send: {
      V v_ch_249 = heff_field(v_x_243, 0);
      V v_v_2410 = heff_field(v_x_243, 1);
      V v_x_2411 = heff_field(v_x_243, 2);
      V v_ru_24x_243_24Send = heff_take_reuse_n(v_x_243, 7ULL, 3);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Send, TAG_Send, 3, (V[]){v_ch_249, v_v_2410, v_x_2411});
      break;
    }
    case TAG_Recv: {
      V v_ch_2412 = heff_field(v_x_243, 0);
      V v_k_2413 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Recv = heff_take_reuse_n(v_x_243, 3ULL, 2);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Recv, TAG_Recv, 2, (V[]){v_ch_2412, v_k_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2414});
    break;
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s459815859x1387532636_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s459815859x1387532636_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s459815859x1387532636_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2415}));
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2427});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2428}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2429, v_k2_242});
}
V g_co_2eop_24s459815859x1387532636_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s459815859x1387532636(a[0], a[1], a[2]);
}
V g_co_2eop_24s459815859x1387532636_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2420}));
  V f_ = v_k_2419;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s459815859x1387532636_lam0(V self, V *args) {
  V v_g_2416 = args[0];
  V v_c_2417 = args[1];
  V v_hd_2418 = args[2];
  V v_k_2419 = args[3];
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_co_2eop_24s459815859x1387532636_lam1, 1, 2, (V[]){v_g_2416, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s459815859x1387532636_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_x_2424}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s459815859x1387532636_lam2(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2423;
  args[1] = heff_clo_n(g_co_2eop_24s459815859x1387532636_lam3, 1, 2, (V[]){v_g_2422, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s459815859x1387532636_lam4(V self, V *args) {
  V v_c_2426 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s792193458x1346260978_lam1(V self, V *args);
V g_co_2eop_24s792193458x1346260978_lam0(V self, V *args); static Clo g_co_2eop_24s792193458x1346260978_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s792193458x1346260978_lam0, 4, 0};
V g_co_2eop_24s792193458x1346260978_lam3(V self, V *args);
V g_co_2eop_24s792193458x1346260978_lam2(V self, V *args);
V g_co_2eop_24s792193458x1346260978_lam4(V self, V *args);
V g_co_2eop_24s792193458x1346260978_lam5(V self, V *args);
Clo g_co_2eop_24s792193458x1346260978_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s792193458x1346260978_entry, 3, 0};

V g_co_2eop_24s792193458x1346260978(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s792193458x1346260978_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s792193458x1346260978_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s792193458x1346260978_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, heff_clo_n(g_co_2eop_24s792193458x1346260978_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s792193458x1346260978_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s792193458x1346260978(a[0], a[1], a[2]);
}
V g_co_2eop_24s792193458x1346260978_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s792193458x1346260978_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s792193458x1346260978_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s792193458x1346260978_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s792193458x1346260978_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s792193458x1346260978_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s792193458x1346260978_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s792193458x1346260978_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_RDone, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1769951398x1534613602_lam1(V self, V *args);
V g_co_2eop_24s1769951398x1534613602_lam0(V self, V *args); static Clo g_co_2eop_24s1769951398x1534613602_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1769951398x1534613602_lam0, 4, 0};
V g_co_2eop_24s1769951398x1534613602_lam3(V self, V *args);
V g_co_2eop_24s1769951398x1534613602_lam2(V self, V *args);
V g_co_2eop_24s1769951398x1534613602_lam4(V self, V *args);
V g_co_2eop_24s1769951398x1534613602_lam5(V self, V *args);
Clo g_co_2eop_24s1769951398x1534613602_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1769951398x1534613602_entry, 10, 0};

V g_co_2eop_24s1769951398x1534613602(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1769951398x1534613602_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1769951398x1534613602_lam2, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s1769951398x1534613602_lam4, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2421}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s1769951398x1534613602_lam5, 1, 8, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s1769951398x1534613602_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1769951398x1534613602(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_co_2eop_24s1769951398x1534613602_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1769951398x1534613602_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1769951398x1534613602_lam1, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1769951398x1534613602_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1769951398x1534613602_lam2(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_co_2eop_24s1769951398x1534613602_lam3, 1, 2, (V[]){v_g_2416, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1769951398x1534613602_lam4(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1769951398x1534613602_lam5(V self, V *args) {
  V v_a_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_a_2423);
  return (g_app_2eheff_2emain_2edispatch_24s900934017x379470200(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247));
}
V g_co_2eop_24s47784662x736955004_lam1(V self, V *args);
V g_co_2eop_24s47784662x736955004_lam0(V self, V *args); static Clo g_co_2eop_24s47784662x736955004_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_lam0, 4, 0};
V g_co_2eop_24s47784662x736955004_lam3(V self, V *args);
V g_co_2eop_24s47784662x736955004_lam2(V self, V *args); static Clo g_co_2eop_24s47784662x736955004_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_lam2, 3, 0};
V g_co_2eop_24s47784662x736955004_lam5(V self, V *args); static Clo g_co_2eop_24s47784662x736955004_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_lam5, 2, 0};
V g_co_2eop_24s47784662x736955004_lam7(V self, V *args);
V g_co_2eop_24s47784662x736955004_lam6(V self, V *args); static Clo g_co_2eop_24s47784662x736955004_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_lam6, 3, 0};
V g_co_2eop_24s47784662x736955004_lam8(V self, V *args); static Clo g_co_2eop_24s47784662x736955004_lam8_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_lam8, 2, 0};
V g_co_2eop_24s47784662x736955004_lam9(V self, V *args); static Clo g_co_2eop_24s47784662x736955004_lam9_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_lam9, 2, 0};
V g_co_2eop_24s47784662x736955004_lam4(V self, V *args); static Clo g_co_2eop_24s47784662x736955004_lam4_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_lam4, 1, 0};
V g_co_2eop_24s47784662x736955004_lam11(V self, V *args);
V g_co_2eop_24s47784662x736955004_lam10(V self, V *args);
Clo g_co_2eop_24s47784662x736955004_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s47784662x736955004_entry, 2, 0};

V g_co_2eop_24s47784662x736955004(V v_p_240, V v_k2_241) {
top: ;
  V v_a_2430;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s47784662x736955004_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s47784662x736955004_lam2_clo)}), ((V)&g_co_2eop_24s47784662x736955004_lam4_clo), v_x_242}));
    v_a_2430 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2425});
    break;
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_y_2426)) {
    case TAG_Send: {
      V v_rq_2427 = heff_field(v_y_2426, 0);
      V v_k_2428 = heff_field(v_y_2426, 1);
      V v_ru_24y_2426_24Send = heff_take_reuse_n(v_y_2426, 3ULL, 2);
      v_t_2429 = heff_tag_at_n(v_ru_24y_2426_24Send, TAG_Send, 2, (V[]){v_rq_2427, v_k_2428});
      break;
    }
    default: heff_nomatch(v_y_2426);
    }
    v_a_2430 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2429});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  return heff_clo_n(g_co_2eop_24s47784662x736955004_lam10, 1, 2, (V[]){v_a_2430, v_k2_241});
}
V g_co_2eop_24s47784662x736955004_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s47784662x736955004(a[0], a[1]);
}
V g_co_2eop_24s47784662x736955004_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s47784662x736955004_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s47784662x736955004_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s47784662x736955004_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2413 = heff_tr(heff_call(v_g_249, 1, (V[]){v_a_2412}));
  V f_ = v_a_2411;
  args[0] = v_a_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s47784662x736955004_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_a_2411 = args[2];
  V f_ = v_m_2410;
  args[0] = heff_clo_n(g_co_2eop_24s47784662x736955004_lam3, 1, 2, (V[]){v_g_249, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s47784662x736955004_lam5(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2416 = args[1];
  V f_ = v_a_2416;
  args[0] = v_a_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s47784662x736955004_lam7(V self, V *args) {
  V v_a_2420 = args[0];
  V v_a_2418 = heff_env(self)[0];
  V v_a_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2418;
  heff_room[0] = v_a_2420;
  heff_room[1] = v_a_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s47784662x736955004_lam6(V self, V *args) {
  V v_a_2417 = args[0];
  V v_a_2418 = args[1];
  V v_a_2419 = args[2];
  V f_ = v_a_2417;
  args[0] = heff_clo_n(g_co_2eop_24s47784662x736955004_lam7, 1, 2, (V[]){v_a_2418, v_a_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s47784662x736955004_lam8(V self, V *args) {
  V v_a_2421 = args[0];
  V v_a_2422 = args[1];
  return heff_perform(v_a_2421, v_a_2422);
}
V g_co_2eop_24s47784662x736955004_lam9(V self, V *args) {
  V v_a_2423 = args[0];
  V v_a_2424 = args[1];
  V f_ = v_a_2424;
  args[0] = v_a_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s47784662x736955004_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V f_ = v_c_2414;
  heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_co_2eop_24s47784662x736955004_lam5_clo), ((V)&g_co_2eop_24s47784662x736955004_lam6_clo), ((V)&g_co_2eop_24s47784662x736955004_lam8_clo)});
  heff_room[1] = ((V)&g_co_2eop_24s47784662x736955004_lam9_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s47784662x736955004_lam11(V self, V *args) {
  V v_a_2432 = args[0];
  V v_k2_241 = heff_env(self)[0];
  V v_a_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k2_241;
  heff_room[0] = v_a_2432;
  heff_room[1] = v_a_2431;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s47784662x736955004_lam10(V self, V *args) {
  V v_a_2431 = args[0];
  V v_a_2430 = heff_env(self)[0];
  V v_k2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_perform(v_a_2430, heff_clo_n(g_co_2eop_24s47784662x736955004_lam11, 1, 2, (V[]){v_k2_241, v_a_2431}));
}