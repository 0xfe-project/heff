// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Await 41810
#define TAG_Begin 41697
#define TAG_Catch 6517
#define TAG_Close 2276
#define TAG_Complete 48856
#define TAG_Draw 50003
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Finish 61316
#define TAG_Interactive 42932
#define TAG_IsTerminal 53507
#define TAG_Log 24016
#define TAG_Measure 52418
#define TAG_NewChan 9424
#define TAG_Now 25954
#define TAG_Open 48267
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_ReadInput 54226
#define TAG_ReadStdin 20528
#define TAG_Recv 61489
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Sleep 25229
#define TAG_Spawn 10053
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_cwd 308458
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_fmap 9641981
#define LBL_heff 9694020
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_shutdown 575795380
#define LBL_style 311138763
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579(V, V, V, V, V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2edispatch_24s975174480x1139976579_clo;
V g_co_2ebind_24s441514442x2097556756(V, V, V, V);
V g_co_2ebind_24s441514442x2097556756_entry(V self, V *a);
extern Clo g_co_2ebind_24s441514442x2097556756_clo;
V g_co_2eop_24s1050926098x962532285(V, V, V);
V g_co_2eop_24s1050926098x962532285_entry(V self, V *a);
extern Clo g_co_2eop_24s1050926098x962532285_clo;
V g_co_2eop_24s1070734279x1181903788(V, V, V);
V g_co_2eop_24s1070734279x1181903788_entry(V self, V *a);
extern Clo g_co_2eop_24s1070734279x1181903788_clo;
V g_co_2eop_24s1218157541x529269095(V, V, V);
V g_co_2eop_24s1218157541x529269095_entry(V self, V *a);
extern Clo g_co_2eop_24s1218157541x529269095_clo;
V g_co_2eop_24s1238283193x1160440465(V, V, V, V, V, V);
V g_co_2eop_24s1238283193x1160440465_entry(V self, V *a);
extern Clo g_co_2eop_24s1238283193x1160440465_clo;
V g_co_2eop_24s1278336259x450164198(V, V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1278336259x450164198_entry(V self, V *a);
extern Clo g_co_2eop_24s1278336259x450164198_clo;
V g_co_2eop_24s1549572115x1242285242(V, V, V, V);
V g_co_2eop_24s1549572115x1242285242_entry(V self, V *a);
extern Clo g_co_2eop_24s1549572115x1242285242_clo;
V g_co_2eop_24s1594985323x520615696(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1594985323x520615696_entry(V self, V *a);
extern Clo g_co_2eop_24s1594985323x520615696_clo;
V g_co_2eop_24s173284549x1274703393(V, V, V, V, V, V);
V g_co_2eop_24s173284549x1274703393_entry(V self, V *a);
extern Clo g_co_2eop_24s173284549x1274703393_clo;
V g_co_2eop_24s1825131239x2082086395(V, V, V, V, V);
V g_co_2eop_24s1825131239x2082086395_entry(V self, V *a);
extern Clo g_co_2eop_24s1825131239x2082086395_clo;
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s310418905x1614124229(V, V, V);
V g_co_2eop_24s310418905x1614124229_entry(V self, V *a);
extern Clo g_co_2eop_24s310418905x1614124229_clo;
V g_co_2eop_24s707390346x636263434(V, V, V, V);
V g_co_2eop_24s707390346x636263434_entry(V self, V *a);
extern Clo g_co_2eop_24s707390346x636263434_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_co_2eplus_24s115190544x963602094_get(void);
V g_co_2eplus_24s1226459126x1628219458_get(void);
V g_co_2eplus_24s1389063241x527387549_get(void);
V g_co_2eplus_24s1493898788x821937431_get(void);
V g_co_2eplus_24s1679086809x1857696200(V);
V g_co_2eplus_24s1679086809x1857696200_entry(V self, V *a);
extern Clo g_co_2eplus_24s1679086809x1857696200_clo;
V g_co_2eplus_24s169777576x280800149_get(void);
V g_co_2eplus_24s1854017309x1005292301_get(void);
V g_co_2eplus_24s1914620224x1667922359_get(void);
V g_co_2eplus_24s1926030886x1813643643_get(void);
V g_co_2eplus_24s2124540091x1079095538_get(void);
V g_co_2eplus_24s568834074x347645904_get(void);
V g_co_2eplus_24s58116330x1448227934(V);
V g_co_2eplus_24s58116330x1448227934_entry(V self, V *a);
extern Clo g_co_2eplus_24s58116330x1448227934_clo;
V g_co_2eplus_24s781597930x1570803347_get(void);
V g_co_2eplus_24s984570155x1252140766_get(void);
V g_green_2egreen_get(void);
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242(V, V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_clo;
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_resource_2eheldBy_24s2140945292x1227416445(V, V, V, V, V);
V g_resource_2eheldBy_24s2140945292x1227416445_entry(V self, V *a);
extern Clo g_resource_2eheldBy_24s2140945292x1227416445_clo;
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2emap_2eempty_get(void);
V g_std_2enet_2enet_get(void);
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprogress_2eprogress_get(void);
V g_std_2ereactor_2ereactor_get(void);
V g_std_2eterminal_2econsole_get(void);
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args); static Clo g_co_2eop_24s310169282x2049378029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_lam0, 4, 0};
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args);
Clo g_co_2eop_24s310169282x2049378029_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_entry, 4, 0};

V g_co_2eop_24s310169282x2049378029(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s310169282x2049378029_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s310169282x2049378029_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s310169282x2049378029_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, v_k2_243});
}
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s310169282x2049378029(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1549572115x1242285242_lam1(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam0(V self, V *args); static Clo g_co_2eop_24s1549572115x1242285242_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1549572115x1242285242_lam0, 4, 0};
V g_co_2eop_24s1549572115x1242285242_lam3(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam2(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam4(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam5(V self, V *args);
Clo g_co_2eop_24s1549572115x1242285242_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1549572115x1242285242_entry, 4, 0};

V g_co_2eop_24s1549572115x1242285242(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1549572115x1242285242_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam5, 1, 1, (V[]){v_k2_243})});
}
V g_co_2eop_24s1549572115x1242285242_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1549572115x1242285242(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1549572115x1242285242_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1549572115x1242285242_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1549572115x1242285242_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1549572115x1242285242_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1549572115x1242285242_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1549572115x1242285242_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k2_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_243;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2ebind_24s441514442x2097556756_lam0(V self, V *args);
Clo g_co_2ebind_24s441514442x2097556756_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s441514442x2097556756_entry, 4, 0};

V g_co_2ebind_24s441514442x2097556756(V v_c_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_co_2ebind_24s441514442x2097556756_lam0, 1, 3, (V[]){v_f_241, v_hd_242, v_k_243})});
}
V g_co_2ebind_24s441514442x2097556756_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s441514442x2097556756(a[0], a[1], a[2], a[3]);
}
V g_co_2ebind_24s441514442x2097556756_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_241;
  heff_room[0] = v_x_244;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eplus_24s1679086809x1857696200_lam1(V self, V *args);
V g_co_2eplus_24s1679086809x1857696200_lam0(V self, V *args);
V g_co_2eplus_24s1679086809x1857696200_lam2(V self, V *args);
Clo g_co_2eplus_24s1679086809x1857696200_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1679086809x1857696200_entry, 1, 0};

V g_co_2eplus_24s1679086809x1857696200(V v_h_240) {
top: ;
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2eplus_24s1679086809x1857696200_lam0, 3, 1, (V[]){heff_dup(v_h_240)}), heff_clo_n(g_co_2eplus_24s1679086809x1857696200_lam2, 4, 1, (V[]){v_h_240})});
}
V g_co_2eplus_24s1679086809x1857696200_entry(V self, V *a) {
  (void)self;
  return g_co_2eplus_24s1679086809x1857696200(a[0]);
}
V g_co_2eplus_24s1679086809x1857696200_lam1(V self, V *args) {
  V v_r_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_g_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tr(heff_call(v_k_248, 1, (V[]){v_r_249}));
  V f_ = v_g_242;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1679086809x1857696200_lam0(V self, V *args) {
  V v_m_241 = args[0];
  V v_g_242 = args[1];
  V v_p_243 = args[2];
  V v_h_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InL = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_h_240, 0, 2), 3, (V[]){v_m_241, v_g_242, v_x_244}));
    return heff_tag_at_n(v_ru_24p_243_24InL, TAG_InL, 1, (V[]){v_t_245});
  }
  case TAG_InR: {
    V v_y_246 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InR = heff_take_reuse_n(v_p_243, 1ULL, 1);
    heff_drop(v_m_241);
    heff_drop_rec(v_h_240, 2);
    V v_t_2411;
    switch (heff_tag_of(v_y_246)) {
    case TAG_Send: {
      V v_rq_247 = heff_field(v_y_246, 0);
      V v_k_248 = heff_field(v_y_246, 1);
      V v_ru_24y_246_24Send = heff_take_reuse_n(v_y_246, 3ULL, 2);
      v_t_2411 = heff_tag_at_n(v_ru_24y_246_24Send, TAG_Send, 2, (V[]){v_rq_247, heff_clo_n(g_co_2eplus_24s1679086809x1857696200_lam1, 1, 2, (V[]){v_k_248, v_g_242})});
      break;
    }
    default: heff_nomatch(v_y_246);
    }
    return heff_tag_at_n(v_ru_24p_243_24InR, TAG_InR, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_co_2eplus_24s1679086809x1857696200_lam2(V self, V *args) {
  V v_m_2412 = args[0];
  V v_n_2413 = args[1];
  V v_nt_2414 = args[2];
  V v_p_2415 = args[3];
  V v_h_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2415)) {
  case TAG_InL: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    V v_ru_24p_2415_24InL = heff_take_reuse_n(v_p_2415, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){v_m_2412, v_n_2413, v_nt_2414, v_x_2416}));
    return heff_tag_at_n(v_ru_24p_2415_24InL, TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_2415, 0);
    V v_ru_24p_2415_24InR = heff_take_reuse_n(v_p_2415, 1ULL, 1);
    heff_drop(v_m_2412);
    heff_drop(v_n_2413);
    heff_drop(v_nt_2414);
    heff_drop_rec(v_h_240, 2);
    V v_t_2421;
    switch (heff_tag_of(v_y_2418)) {
    case TAG_Send: {
      V v_rq_2419 = heff_field(v_y_2418, 0);
      V v_k_2420 = heff_field(v_y_2418, 1);
      V v_ru_24y_2418_24Send = heff_take_reuse_n(v_y_2418, 3ULL, 2);
      v_t_2421 = heff_tag_at_n(v_ru_24y_2418_24Send, TAG_Send, 2, (V[]){v_rq_2419, v_k_2420});
      break;
    }
    default: heff_nomatch(v_y_2418);
    }
    return heff_tag_at_n(v_ru_24p_2415_24InR, TAG_InR, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_p_2415);
  }
}
V g_co_2eplus_24s568834074x347645904_lam1(V self, V *args);
V g_co_2eplus_24s568834074x347645904_lam2(V self, V *args);
V g_co_2eplus_24s568834074x347645904_lam0(V self, V *args); static Clo g_co_2eplus_24s568834074x347645904_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s568834074x347645904_lam0, 3, 0};
V g_co_2eplus_24s568834074x347645904_lam3(V self, V *args); static Clo g_co_2eplus_24s568834074x347645904_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s568834074x347645904_lam3, 4, 0};

static V g_co_2eplus_24s568834074x347645904_val;
static HEFF_ONCE g_co_2eplus_24s568834074x347645904_st;
static V g_co_2eplus_24s568834074x347645904_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s568834074x347645904_lam0_clo), ((V)&g_co_2eplus_24s568834074x347645904_lam3_clo)});
}
V g_co_2eplus_24s568834074x347645904_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s568834074x347645904_st)) return g_co_2eplus_24s568834074x347645904_val;
  return heff_global(&g_co_2eplus_24s568834074x347645904_val, &g_co_2eplus_24s568834074x347645904_st, g_co_2eplus_24s568834074x347645904_init);
}
V g_co_2eplus_24s568834074x347645904_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s568834074x347645904_lam2(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s568834074x347645904_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1493898788x821937431_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_2414 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24UseColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s568834074x347645904_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2410 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24ErrColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s568834074x347645904_lam2, 1, 2, (V[]){v_k_2410, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s568834074x347645904_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2428;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_InL: {
      V v_x_2422 = heff_field(v_x_2421, 0);
      heff_take_n(v_x_2421, 1ULL, 1);
      V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1493898788x821937431_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_x_2422}));
      v_t_2428 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2423});
      break;
    }
    case TAG_InR: {
      V v_y_2424 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24InR = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      heff_drop(v_m_2417);
      heff_drop(v_n_2418);
      heff_drop(v_nt_2419);
      heff_drop_cell(v_ru_24p_2420_24InL, 1);
      V v_t_2427;
      switch (heff_tag_of(v_y_2424)) {
      case TAG_UseColor: {
        V v_k_2425 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24UseColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24UseColor, TAG_UseColor, 1, (V[]){v_k_2425});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2426 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24ErrColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24ErrColor, TAG_ErrColor, 1, (V[]){v_k_2426});
        break;
      }
      default: heff_nomatch(v_y_2424);
      }
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24InR, TAG_InR, 1, (V[]){v_t_2427});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2428});
  }
  case TAG_InR: {
    V v_y_2429 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_m_2417);
    heff_drop(v_n_2418);
    heff_drop(v_nt_2419);
    V v_t_2446;
    switch (heff_tag_of(v_y_2429)) {
    case TAG_Await: {
      V v_t_2430 = heff_field(v_y_2429, 0);
      V v_k_2431 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24Await = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Await, TAG_Await, 2, (V[]){v_t_2430, v_k_2431});
      break;
    }
    case TAG_Send: {
      V v_s_2432 = heff_field(v_y_2429, 0);
      V v_x_2433 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24Send = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Send, TAG_Send, 2, (V[]){v_s_2432, v_x_2433});
      break;
    }
    case TAG_Log: {
      V v_s_2434 = heff_field(v_y_2429, 0);
      V v_x_2435 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24Log = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Log, TAG_Log, 2, (V[]){v_s_2434, v_x_2435});
      break;
    }
    case TAG_Now: {
      V v_k_2436 = heff_field(v_y_2429, 0);
      V v_ru_24y_2429_24Now = heff_take_reuse_n(v_y_2429, 1ULL, 1);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Now, TAG_Now, 1, (V[]){v_k_2436});
      break;
    }
    case TAG_ProjectFiles: {
      V v_r_2437 = heff_field(v_y_2429, 0);
      V v_k_2438 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24ProjectFiles = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2437, v_k_2438});
      break;
    }
    case TAG_UriPath: {
      V v_u_2439 = heff_field(v_y_2429, 0);
      V v_k_2440 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24UriPath = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24UriPath, TAG_UriPath, 2, (V[]){v_u_2439, v_k_2440});
      break;
    }
    case TAG_PathUri: {
      V v_p_2441 = heff_field(v_y_2429, 0);
      V v_k_2442 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24PathUri = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24PathUri, TAG_PathUri, 2, (V[]){v_p_2441, v_k_2442});
      break;
    }
    case TAG_AbsPath: {
      V v_p_2443 = heff_field(v_y_2429, 0);
      V v_k_2444 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24AbsPath = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2443, v_k_2444});
      break;
    }
    case TAG_Quit: {
      V v_c_2445 = heff_field(v_y_2429, 0);
      V v_ru_24y_2429_24Quit = heff_take_reuse_n(v_y_2429, 1ULL, 1);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Quit, TAG_Quit, 1, (V[]){v_c_2445});
      break;
    }
    default: heff_nomatch(v_y_2429);
    }
    return heff_tag_at_n(v_ru_24p_2420_24InR, TAG_InR, 1, (V[]){v_t_2446});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2eplus_24s1926030886x1813643643_lam1(V self, V *args);
V g_co_2eplus_24s1926030886x1813643643_lam2(V self, V *args);
V g_co_2eplus_24s1926030886x1813643643_lam0(V self, V *args); static Clo g_co_2eplus_24s1926030886x1813643643_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1926030886x1813643643_lam0, 3, 0};
V g_co_2eplus_24s1926030886x1813643643_lam3(V self, V *args); static Clo g_co_2eplus_24s1926030886x1813643643_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1926030886x1813643643_lam3, 4, 0};

static V g_co_2eplus_24s1926030886x1813643643_val;
static HEFF_ONCE g_co_2eplus_24s1926030886x1813643643_st;
static V g_co_2eplus_24s1926030886x1813643643_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1926030886x1813643643_lam0_clo), ((V)&g_co_2eplus_24s1926030886x1813643643_lam3_clo)});
}
V g_co_2eplus_24s1926030886x1813643643_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1926030886x1813643643_st)) return g_co_2eplus_24s1926030886x1813643643_val;
  return heff_global(&g_co_2eplus_24s1926030886x1813643643_val, &g_co_2eplus_24s1926030886x1813643643_st, g_co_2eplus_24s1926030886x1813643643_init);
}
V g_co_2eplus_24s1926030886x1813643643_lam1(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1926030886x1813643643_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1926030886x1813643643_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s568834074x347645904_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_IsTerminal: {
      V v_k_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24IsTerminal = heff_take_reuse_n(v_y_245, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24IsTerminal, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2eplus_24s1926030886x1813643643_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_249 = heff_field(v_y_245, 0);
      V v_x_2410 = heff_field(v_y_245, 1);
      V v_ru_24y_245_24ShowLines = heff_take_reuse_n(v_y_245, 3ULL, 2);
      V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_249, v_t_2411});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2412 = heff_field(v_y_245, 0);
      V v_argv_2413 = heff_field(v_y_245, 1);
      V v_lines_2414 = heff_field(v_y_245, 2);
      V v_k_2415 = heff_field(v_y_245, 3);
      V v_ru_24y_245_24ShowRun = heff_take_reuse_n(v_y_245, 15ULL, 4);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2412, v_argv_2413, v_lines_2414, heff_clo_n(g_co_2eplus_24s1926030886x1813643643_lam2, 1, 2, (V[]){v_k_2415, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1926030886x1813643643_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s568834074x347645904_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2423}));
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    V v_t_2433;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_IsTerminal: {
      V v_k_2426 = heff_field(v_y_2425, 0);
      V v_ru_24y_2425_24IsTerminal = heff_take_reuse_n(v_y_2425, 1ULL, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24IsTerminal, TAG_IsTerminal, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2427 = heff_field(v_y_2425, 0);
      V v_x_2428 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24ShowLines = heff_take_reuse_n(v_y_2425, 3ULL, 2);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2427, v_x_2428});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2429 = heff_field(v_y_2425, 0);
      V v_argv_2430 = heff_field(v_y_2425, 1);
      V v_lines_2431 = heff_field(v_y_2425, 2);
      V v_k_2432 = heff_field(v_y_2425, 3);
      V v_ru_24y_2425_24ShowRun = heff_take_reuse_n(v_y_2425, 15ULL, 4);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2429, v_argv_2430, v_lines_2431, v_k_2432});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2433});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2eplus_24s169777576x280800149_lam1(V self, V *args);
V g_co_2eplus_24s169777576x280800149_lam0(V self, V *args); static Clo g_co_2eplus_24s169777576x280800149_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s169777576x280800149_lam0, 3, 0};
V g_co_2eplus_24s169777576x280800149_lam2(V self, V *args); static Clo g_co_2eplus_24s169777576x280800149_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s169777576x280800149_lam2, 4, 0};

static V g_co_2eplus_24s169777576x280800149_val;
static HEFF_ONCE g_co_2eplus_24s169777576x280800149_st;
static V g_co_2eplus_24s169777576x280800149_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s169777576x280800149_lam0_clo), ((V)&g_co_2eplus_24s169777576x280800149_lam2_clo)});
}
V g_co_2eplus_24s169777576x280800149_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s169777576x280800149_st)) return g_co_2eplus_24s169777576x280800149_val;
  return heff_global(&g_co_2eplus_24s169777576x280800149_val, &g_co_2eplus_24s169777576x280800149_st, g_co_2eplus_24s169777576x280800149_init);
}
V g_co_2eplus_24s169777576x280800149_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s169777576x280800149_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2414;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Write: {
        V v_str_245 = heff_field(v_x_244, 0);
        V v_x_246 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24Write = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_246}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24Write, TAG_Write, 2, (V[]){v_str_245, v_t_247});
        break;
      }
      case TAG_WriteErr: {
        V v_str_248 = heff_field(v_x_244, 0);
        V v_x_249 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24WriteErr = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_249}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_248, v_t_2410});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2411 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2eplus_24s169777576x280800149_lam1, 1, 2, (V[]){v_k_2411, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_InR: {
      V v_y_2415 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
      v_t_2417 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2418}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s169777576x280800149_lam2(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  switch (heff_tag_of(v_p_2423)) {
  case TAG_InL: {
    V v_x_2424 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InL = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_InL: {
      V v_x_2425 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InL = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      heff_drop(v_m_2420);
      heff_drop(v_n_2421);
      heff_drop(v_nt_2422);
      V v_t_2431;
      switch (heff_tag_of(v_x_2425)) {
      case TAG_Write: {
        V v_str_2426 = heff_field(v_x_2425, 0);
        V v_x_2427 = heff_field(v_x_2425, 1);
        V v_ru_24x_2425_24Write = heff_take_reuse_n(v_x_2425, 3ULL, 2);
        heff_drop_cell(v_ru_24x_2424_24InL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2425_24Write, TAG_Write, 2, (V[]){v_str_2426, v_x_2427});
        break;
      }
      case TAG_WriteErr: {
        V v_str_2428 = heff_field(v_x_2425, 0);
        V v_x_2429 = heff_field(v_x_2425, 1);
        V v_ru_24x_2425_24WriteErr = heff_take_reuse_n(v_x_2425, 3ULL, 2);
        heff_drop_cell(v_ru_24x_2424_24InL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2425_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_2428, v_x_2429});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2430 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24InL, TAG_ReadStdin, 1, (V[]){v_k_2430});
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      v_t_2434 = heff_tag_at_n(v_ru_24p_2423_24InL, TAG_InL, 1, (V[]){v_t_2431});
      break;
    }
    case TAG_InR: {
      V v_y_2432 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InR = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2423_24InL, 1);
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2432}));
      v_t_2434 = heff_tag_at_n(v_ru_24x_2424_24InR, TAG_InR, 1, (V[]){v_t_2433});
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2434});
  }
  case TAG_InR: {
    V v_y_2435 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InR = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2435}));
    return heff_tag_at_n(v_ru_24p_2423_24InR, TAG_InR, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_p_2423);
  }
}
V g_co_2eplus_24s115190544x963602094_lam1(V self, V *args);
V g_co_2eplus_24s115190544x963602094_lam2(V self, V *args);
V g_co_2eplus_24s115190544x963602094_lam0(V self, V *args); static Clo g_co_2eplus_24s115190544x963602094_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s115190544x963602094_lam0, 3, 0};
V g_co_2eplus_24s115190544x963602094_lam3(V self, V *args); static Clo g_co_2eplus_24s115190544x963602094_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s115190544x963602094_lam3, 4, 0};

static V g_co_2eplus_24s115190544x963602094_val;
static HEFF_ONCE g_co_2eplus_24s115190544x963602094_st;
static V g_co_2eplus_24s115190544x963602094_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s115190544x963602094_lam0_clo), ((V)&g_co_2eplus_24s115190544x963602094_lam3_clo)});
}
V g_co_2eplus_24s115190544x963602094_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s115190544x963602094_st)) return g_co_2eplus_24s115190544x963602094_val;
  return heff_global(&g_co_2eplus_24s115190544x963602094_val, &g_co_2eplus_24s115190544x963602094_st, g_co_2eplus_24s115190544x963602094_init);
}
V g_co_2eplus_24s115190544x963602094_lam1(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s115190544x963602094_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s115190544x963602094_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s984570155x1252140766_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_IsTerminal: {
      V v_k_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24IsTerminal = heff_take_reuse_n(v_y_245, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24IsTerminal, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2eplus_24s115190544x963602094_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_249 = heff_field(v_y_245, 0);
      V v_x_2410 = heff_field(v_y_245, 1);
      V v_ru_24y_245_24ShowLines = heff_take_reuse_n(v_y_245, 3ULL, 2);
      V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_249, v_t_2411});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2412 = heff_field(v_y_245, 0);
      V v_argv_2413 = heff_field(v_y_245, 1);
      V v_lines_2414 = heff_field(v_y_245, 2);
      V v_k_2415 = heff_field(v_y_245, 3);
      V v_ru_24y_245_24ShowRun = heff_take_reuse_n(v_y_245, 15ULL, 4);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2412, v_argv_2413, v_lines_2414, heff_clo_n(g_co_2eplus_24s115190544x963602094_lam2, 1, 2, (V[]){v_k_2415, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s115190544x963602094_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s984570155x1252140766_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2423}));
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    V v_t_2433;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_IsTerminal: {
      V v_k_2426 = heff_field(v_y_2425, 0);
      V v_ru_24y_2425_24IsTerminal = heff_take_reuse_n(v_y_2425, 1ULL, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24IsTerminal, TAG_IsTerminal, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2427 = heff_field(v_y_2425, 0);
      V v_x_2428 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24ShowLines = heff_take_reuse_n(v_y_2425, 3ULL, 2);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2427, v_x_2428});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2429 = heff_field(v_y_2425, 0);
      V v_argv_2430 = heff_field(v_y_2425, 1);
      V v_lines_2431 = heff_field(v_y_2425, 2);
      V v_k_2432 = heff_field(v_y_2425, 3);
      V v_ru_24y_2425_24ShowRun = heff_take_reuse_n(v_y_2425, 15ULL, 4);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2429, v_argv_2430, v_lines_2431, v_k_2432});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2433});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2eplus_24s1389063241x527387549_lam0(V self, V *args); static Clo g_co_2eplus_24s1389063241x527387549_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1389063241x527387549_lam0, 3, 0};
V g_co_2eplus_24s1389063241x527387549_lam1(V self, V *args); static Clo g_co_2eplus_24s1389063241x527387549_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1389063241x527387549_lam1, 4, 0};

static V g_co_2eplus_24s1389063241x527387549_val;
static HEFF_ONCE g_co_2eplus_24s1389063241x527387549_st;
static V g_co_2eplus_24s1389063241x527387549_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1389063241x527387549_lam0_clo), ((V)&g_co_2eplus_24s1389063241x527387549_lam1_clo)});
}
V g_co_2eplus_24s1389063241x527387549_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1389063241x527387549_st)) return g_co_2eplus_24s1389063241x527387549_val;
  return heff_global(&g_co_2eplus_24s1389063241x527387549_val, &g_co_2eplus_24s1389063241x527387549_st, g_co_2eplus_24s1389063241x527387549_init);
}
V g_co_2eplus_24s1389063241x527387549_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s115190544x963602094_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1389063241x527387549_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s984570155x1252140766_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_x_2412}));
      v_t_2423 = heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_InR: {
      V v_y_2414 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InR = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_m_247);
      heff_drop(v_n_248);
      heff_drop(v_nt_249);
      heff_drop_cell(v_ru_24p_2410_24InL, 1);
      V v_t_2422;
      switch (heff_tag_of(v_y_2414)) {
      case TAG_IsTerminal: {
        V v_k_2415 = heff_field(v_y_2414, 0);
        V v_ru_24y_2414_24IsTerminal = heff_take_reuse_n(v_y_2414, 1ULL, 1);
        v_t_2422 = heff_tag_at_n(v_ru_24y_2414_24IsTerminal, TAG_IsTerminal, 1, (V[]){v_k_2415});
        break;
      }
      case TAG_ShowLines: {
        V v_ls_2416 = heff_field(v_y_2414, 0);
        V v_x_2417 = heff_field(v_y_2414, 1);
        V v_ru_24y_2414_24ShowLines = heff_take_reuse_n(v_y_2414, 3ULL, 2);
        v_t_2422 = heff_tag_at_n(v_ru_24y_2414_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2416, v_x_2417});
        break;
      }
      case TAG_ShowRun: {
        V v_cmd_2418 = heff_field(v_y_2414, 0);
        V v_argv_2419 = heff_field(v_y_2414, 1);
        V v_lines_2420 = heff_field(v_y_2414, 2);
        V v_k_2421 = heff_field(v_y_2414, 3);
        V v_ru_24y_2414_24ShowRun = heff_take_reuse_n(v_y_2414, 15ULL, 4);
        v_t_2422 = heff_tag_at_n(v_ru_24y_2414_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2418, v_argv_2419, v_lines_2420, v_k_2421});
        break;
      }
      default: heff_nomatch(v_y_2414);
      }
      v_t_2423 = heff_tag_at_n(v_ru_24x_2411_24InR, TAG_InR, 1, (V[]){v_t_2422});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2423});
  }
  case TAG_InR: {
    V v_y_2424 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    heff_drop(v_nt_249);
    V v_t_2432;
    switch (heff_tag_of(v_y_2424)) {
    case TAG_Interactive: {
      V v_k_2425 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Interactive = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Interactive, TAG_Interactive, 1, (V[]){v_k_2425});
      break;
    }
    case TAG_Begin: {
      V v_k_2426 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Begin = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Begin, TAG_Begin, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_Finish: {
      V v_x_2427 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Finish = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Finish, TAG_Finish, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_Measure: {
      V v_k_2428 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Measure = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Measure, TAG_Measure, 1, (V[]){v_k_2428});
      break;
    }
    case TAG_ReadInput: {
      V v_k_2429 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24ReadInput = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24ReadInput, TAG_ReadInput, 1, (V[]){v_k_2429});
      break;
    }
    case TAG_Draw: {
      V v_s_2430 = heff_field(v_y_2424, 0);
      V v_x_2431 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24Draw = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      v_t_2432 = heff_tag_at_n(v_ru_24y_2424_24Draw, TAG_Draw, 2, (V[]){v_s_2430, v_x_2431});
      break;
    }
    default: heff_nomatch(v_y_2424);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2432});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eplus_24s1226459126x1628219458_lam0(V self, V *args); static Clo g_co_2eplus_24s1226459126x1628219458_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1226459126x1628219458_lam0, 3, 0};
V g_co_2eplus_24s1226459126x1628219458_lam1(V self, V *args); static Clo g_co_2eplus_24s1226459126x1628219458_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1226459126x1628219458_lam1, 4, 0};

static V g_co_2eplus_24s1226459126x1628219458_val;
static HEFF_ONCE g_co_2eplus_24s1226459126x1628219458_st;
static V g_co_2eplus_24s1226459126x1628219458_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1226459126x1628219458_lam0_clo), ((V)&g_co_2eplus_24s1226459126x1628219458_lam1_clo)});
}
V g_co_2eplus_24s1226459126x1628219458_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1226459126x1628219458_st)) return g_co_2eplus_24s1226459126x1628219458_val;
  return heff_global(&g_co_2eplus_24s1226459126x1628219458_val, &g_co_2eplus_24s1226459126x1628219458_st, g_co_2eplus_24s1226459126x1628219458_init);
}
V g_co_2eplus_24s1226459126x1628219458_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_x_244)) {
      case TAG_InL: {
        V v_x_245 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s115190544x963602094_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_245}));
        v_t_249 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_246});
        break;
      }
      case TAG_InR: {
        V v_y_247 = heff_field(v_x_244, 0);
        V v_ru_24x_244_24InR = heff_take_reuse_n(v_x_244, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_247}));
        v_t_249 = heff_tag_at_n(v_ru_24x_244_24InR, TAG_InR, 1, (V[]){v_t_248});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_InL, 1, (V[]){v_t_249});
      break;
    }
    case TAG_InR: {
      V v_y_2410 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2414;
      switch (heff_tag_of(v_y_2410)) {
      case TAG_Sleep: {
        V v_ms_2411 = heff_field(v_y_2410, 0);
        V v_x_2412 = heff_field(v_y_2410, 1);
        V v_ru_24y_2410_24Sleep = heff_take_reuse_n(v_y_2410, 3ULL, 2);
        V v_t_2413 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2412}));
        v_t_2414 = heff_tag_at_n(v_ru_24y_2410_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2411, v_t_2413});
        break;
      }
      default: heff_nomatch(v_y_2410);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2416}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1226459126x1628219458_lam1(V self, V *args) {
  V v_m_2418 = args[0];
  V v_n_2419 = args[1];
  V v_nt_2420 = args[2];
  V v_p_2421 = args[3];
  switch (heff_tag_of(v_p_2421)) {
  case TAG_InL: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InL = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_InL: {
      V v_x_2423 = heff_field(v_x_2422, 0);
      heff_take_n(v_x_2422, 1ULL, 1);
      V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1389063241x527387549_get(), 1)), 4, (V[]){v_m_2418, v_n_2419, v_nt_2420, v_x_2423}));
      v_t_2429 = heff_tag_at_n(v_ru_24p_2421_24InL, TAG_InL, 1, (V[]){v_t_2424});
      break;
    }
    case TAG_InR: {
      V v_y_2425 = heff_field(v_x_2422, 0);
      V v_ru_24x_2422_24InR = heff_take_reuse_n(v_x_2422, 1ULL, 1);
      heff_drop(v_m_2418);
      heff_drop(v_n_2419);
      heff_drop(v_nt_2420);
      heff_drop_cell(v_ru_24p_2421_24InL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_y_2425)) {
      case TAG_Sleep: {
        V v_ms_2426 = heff_field(v_y_2425, 0);
        V v_x_2427 = heff_field(v_y_2425, 1);
        V v_ru_24y_2425_24Sleep = heff_take_reuse_n(v_y_2425, 3ULL, 2);
        v_t_2428 = heff_tag_at_n(v_ru_24y_2425_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2426, v_x_2427});
        break;
      }
      default: heff_nomatch(v_y_2425);
      }
      v_t_2429 = heff_tag_at_n(v_ru_24x_2422_24InR, TAG_InR, 1, (V[]){v_t_2428});
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2429});
  }
  case TAG_InR: {
    V v_y_2430 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InR = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 1)), 4, (V[]){v_m_2418, v_n_2419, v_nt_2420, v_y_2430}));
    return heff_tag_at_n(v_ru_24p_2421_24InR, TAG_InR, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_co_2eplus_24s2124540091x1079095538_lam0(V self, V *args); static Clo g_co_2eplus_24s2124540091x1079095538_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s2124540091x1079095538_lam0, 3, 0};
V g_co_2eplus_24s2124540091x1079095538_lam3(V self, V *args);
V g_co_2eplus_24s2124540091x1079095538_lam2(V self, V *args);
V g_co_2eplus_24s2124540091x1079095538_lam1(V self, V *args); static Clo g_co_2eplus_24s2124540091x1079095538_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s2124540091x1079095538_lam1, 4, 0};

static V g_co_2eplus_24s2124540091x1079095538_val;
static HEFF_ONCE g_co_2eplus_24s2124540091x1079095538_st;
static V g_co_2eplus_24s2124540091x1079095538_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s2124540091x1079095538_lam0_clo), ((V)&g_co_2eplus_24s2124540091x1079095538_lam1_clo)});
}
V g_co_2eplus_24s2124540091x1079095538_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s2124540091x1079095538_st)) return g_co_2eplus_24s2124540091x1079095538_val;
  return heff_global(&g_co_2eplus_24s2124540091x1079095538_val, &g_co_2eplus_24s2124540091x1079095538_st, g_co_2eplus_24s2124540091x1079095538_init);
}
V g_co_2eplus_24s2124540091x1079095538_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1226459126x1628219458_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s2124540091x1079095538_lam3(V self, V *args) {
  V v_c_2428 = args[0];
  V v_k_2429 = args[1];
  V v_nt_249 = heff_env(self)[0];
  V v_use_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_call(v_nt_249, 1, (V[]){v_c_2428}));
  V f_ = v_use_2427;
  args[0] = v_t_2430;
  args[1] = v_k_2429;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eplus_24s2124540091x1079095538_lam2(V self, V *args) {
  V v_use_2427 = args[0];
  V v_b_2426 = heff_env(self)[0];
  V v_nt_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2426;
  args[0] = heff_clo_n(g_co_2eplus_24s2124540091x1079095538_lam3, 2, 2, (V[]){v_nt_249, v_use_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s2124540091x1079095538_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InL = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2412)) {
      case TAG_InL: {
        V v_x_2413 = heff_field(v_x_2412, 0);
        heff_take_n(v_x_2412, 1ULL, 1);
        V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1389063241x527387549_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_x_2413}));
        v_t_2419 = heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2414});
        break;
      }
      case TAG_InR: {
        V v_y_2415 = heff_field(v_x_2412, 0);
        V v_ru_24x_2412_24InR = heff_take_reuse_n(v_x_2412, 1ULL, 1);
        heff_drop(v_m_247);
        heff_drop(v_n_248);
        heff_drop(v_nt_249);
        heff_drop_cell(v_ru_24p_2410_24InL, 1);
        V v_t_2418;
        switch (heff_tag_of(v_y_2415)) {
        case TAG_Sleep: {
          V v_ms_2416 = heff_field(v_y_2415, 0);
          V v_x_2417 = heff_field(v_y_2415, 1);
          V v_ru_24y_2415_24Sleep = heff_take_reuse_n(v_y_2415, 3ULL, 2);
          v_t_2418 = heff_tag_at_n(v_ru_24y_2415_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2416, v_x_2417});
          break;
        }
        default: heff_nomatch(v_y_2415);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24InR, TAG_InR, 1, (V[]){v_t_2418});
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24InL, TAG_InL, 1, (V[]){v_t_2419});
      break;
    }
    case TAG_InR: {
      V v_y_2420 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InR = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2410_24InL, 1);
      V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_y_2420}));
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24InR, TAG_InR, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    V v_t_2436;
    switch (heff_tag_of(v_y_2423)) {
    case TAG_Open: {
      V v_k_2424 = heff_field(v_y_2423, 0);
      V v_ru_24y_2423_24Open = heff_take_reuse_n(v_y_2423, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Open, TAG_Open, 1, (V[]){v_k_2424});
      break;
    }
    case TAG_Start: {
      V v_i_2425 = heff_field(v_y_2423, 0);
      V v_b_2426 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24Start = heff_take_reuse_n(v_y_2423, 3ULL, 2);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Start, TAG_Start, 2, (V[]){v_i_2425, heff_clo_n(g_co_2eplus_24s2124540091x1079095538_lam2, 1, 2, (V[]){v_b_2426, v_nt_249})});
      break;
    }
    case TAG_Finish: {
      V v_i_2431 = heff_field(v_y_2423, 0);
      V v_w_2432 = heff_field(v_y_2423, 1);
      V v_f_2433 = heff_field(v_y_2423, 2);
      V v_ru_24y_2423_24Finish = heff_take_reuse_n(v_y_2423, 7ULL, 3);
      heff_drop(v_nt_249);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Finish, TAG_Finish, 3, (V[]){v_i_2431, v_w_2432, v_f_2433});
      break;
    }
    case TAG_Close: {
      V v_i_2434 = heff_field(v_y_2423, 0);
      V v_x_2435 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24Close = heff_take_reuse_n(v_y_2423, 3ULL, 2);
      heff_drop(v_nt_249);
      v_t_2436 = heff_tag_at_n(v_ru_24y_2423_24Close, TAG_Close, 2, (V[]){v_i_2434, v_x_2435});
      break;
    }
    default: heff_nomatch(v_y_2423);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eop_24s707390346x636263434_lam1(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam0(V self, V *args); static Clo g_co_2eop_24s707390346x636263434_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s707390346x636263434_lam0, 4, 0};
V g_co_2eop_24s707390346x636263434_lam3(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam2(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam4(V self, V *args);
V g_co_2eop_24s707390346x636263434_lam5(V self, V *args);
Clo g_co_2eop_24s707390346x636263434_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s707390346x636263434_entry, 4, 0};

V g_co_2eop_24s707390346x636263434(V v_p_240, V v_k_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s707390346x636263434_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s707390346x636263434_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s707390346x636263434_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_x_244}));
    v_t_2421 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2416});
    break;
  }
  case TAG_InR: {
    V v_y_2417 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Send: {
      V v_rq_2418 = heff_field(v_y_2417, 0);
      V v_k_2419 = heff_field(v_y_2417, 1);
      V v_ru_24y_2417_24Send = heff_take_reuse_n(v_y_2417, 3ULL, 2);
      v_t_2420 = heff_tag_at_n(v_ru_24y_2417_24Send, TAG_Send, 2, (V[]){v_rq_2418, v_k_2419});
      break;
    }
    default: heff_nomatch(v_y_2417);
    }
    v_t_2421 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2420});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2421}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s707390346x636263434_lam5, 1, 3, (V[]){v_k_241, v_hd_242, v_k2_243})});
}
V g_co_2eop_24s707390346x636263434_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s707390346x636263434(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s707390346x636263434_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s707390346x636263434_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s707390346x636263434_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s707390346x636263434_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s707390346x636263434_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s707390346x636263434_lam3, 1, 2, (V[]){v_g_2411, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s707390346x636263434_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s707390346x636263434_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k2_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  heff_room[0] = v_x_2423;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k2_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1218157541x529269095_lam1(V self, V *args);
V g_co_2eop_24s1218157541x529269095_lam0(V self, V *args); static Clo g_co_2eop_24s1218157541x529269095_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1218157541x529269095_lam0, 4, 0};
V g_co_2eop_24s1218157541x529269095_lam3(V self, V *args);
V g_co_2eop_24s1218157541x529269095_lam2(V self, V *args);
V g_co_2eop_24s1218157541x529269095_lam4(V self, V *args);
Clo g_co_2eop_24s1218157541x529269095_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1218157541x529269095_entry, 3, 0};

V g_co_2eop_24s1218157541x529269095(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1218157541x529269095_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1218157541x529269095_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1218157541x529269095_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_243}));
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Send: {
      V v_rq_2417 = heff_field(v_y_2416, 0);
      V v_k_2418 = heff_field(v_y_2416, 1);
      V v_ru_24y_2416_24Send = heff_take_reuse_n(v_y_2416, 3ULL, 2);
      v_t_2419 = heff_tag_at_n(v_ru_24y_2416_24Send, TAG_Send, 2, (V[]){v_rq_2417, v_k_2418});
      break;
    }
    default: heff_nomatch(v_y_2416);
    }
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2421, v_k2_242});
}
V g_co_2eop_24s1218157541x529269095_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1218157541x529269095(a[0], a[1], a[2]);
}
V g_co_2eop_24s1218157541x529269095_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1218157541x529269095_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s1218157541x529269095_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1218157541x529269095_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1218157541x529269095_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1218157541x529269095_lam3, 1, 2, (V[]){v_g_2410, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1218157541x529269095_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s58116330x1448227934_lam0(V self, V *args);
V g_co_2eplus_24s58116330x1448227934_lam1(V self, V *args);
Clo g_co_2eplus_24s58116330x1448227934_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s58116330x1448227934_entry, 1, 0};

V g_co_2eplus_24s58116330x1448227934(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2eplus_24s58116330x1448227934_lam0, 3, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_co_2eplus_24s58116330x1448227934_lam1, 4, 1, (V[]){v_k_240})});
}
V g_co_2eplus_24s58116330x1448227934_entry(V self, V *a) {
  (void)self;
  return g_co_2eplus_24s58116330x1448227934(a[0]);
}
V g_co_2eplus_24s58116330x1448227934_lam0(V self, V *args) {
  V v_m_241 = args[0];
  V v_g_242 = args[1];
  V v_p_243 = args[2];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InL = heff_take_reuse_n(v_p_243, 1ULL, 1);
    heff_drop_rec(v_k_240, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2eprogress_get(), 0)), 3, (V[]){v_m_241, v_g_242, v_x_244}));
    return heff_tag_at_n(v_ru_24p_243_24InL, TAG_InL, 1, (V[]){v_t_245});
  }
  case TAG_InR: {
    V v_y_246 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InR = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 3, (V[]){v_m_241, v_g_242, v_y_246}));
    return heff_tag_at_n(v_ru_24p_243_24InR, TAG_InR, 1, (V[]){v_t_247});
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_co_2eplus_24s58116330x1448227934_lam1(V self, V *args) {
  V v_m_248 = args[0];
  V v_n_249 = args[1];
  V v_nt_2410 = args[2];
  V v_p_2411 = args[3];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2411)) {
  case TAG_InL: {
    V v_x_2412 = heff_field(v_p_2411, 0);
    V v_ru_24p_2411_24InL = heff_take_reuse_n(v_p_2411, 1ULL, 1);
    heff_drop(v_m_248);
    heff_drop(v_n_249);
    heff_drop(v_nt_2410);
    heff_drop_rec(v_k_240, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_Start: {
      V v_parent_2413 = heff_field(v_x_2412, 0);
      V v_name_2414 = heff_field(v_x_2412, 1);
      V v_total_2415 = heff_field(v_x_2412, 2);
      V v_k_2416 = heff_field(v_x_2412, 3);
      V v_ru_24x_2412_24Start = heff_take_reuse_n(v_x_2412, 15ULL, 4);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2412_24Start, TAG_Start, 4, (V[]){v_parent_2413, v_name_2414, v_total_2415, v_k_2416});
      break;
    }
    case TAG_Complete: {
      V v_t_2417 = heff_field(v_x_2412, 0);
      V v_x_2418 = heff_field(v_x_2412, 1);
      V v_ru_24x_2412_24Complete = heff_take_reuse_n(v_x_2412, 3ULL, 2);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2412_24Complete, TAG_Complete, 2, (V[]){v_t_2417, v_x_2418});
      break;
    }
    case TAG_End: {
      V v_t_2419 = heff_field(v_x_2412, 0);
      V v_x_2420 = heff_field(v_x_2412, 1);
      V v_ru_24x_2412_24End = heff_take_reuse_n(v_x_2412, 3ULL, 2);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2412_24End, TAG_End, 2, (V[]){v_t_2419, v_x_2420});
      break;
    }
    case TAG_RunUnder: {
      V v_t_2421 = heff_field(v_x_2412, 0);
      V v_cmd_2422 = heff_field(v_x_2412, 1);
      V v_argv_2423 = heff_field(v_x_2412, 2);
      V v_k_2424 = heff_field(v_x_2412, 3);
      V v_ru_24x_2412_24RunUnder = heff_take_reuse_n(v_x_2412, 15ULL, 4);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2412_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2421, v_cmd_2422, v_argv_2423, v_k_2424});
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    return heff_tag_at_n(v_ru_24p_2411_24InL, TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2411, 0);
    V v_ru_24p_2411_24InR = heff_take_reuse_n(v_p_2411, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 4, (V[]){v_m_248, v_n_249, v_nt_2410, v_y_2426}));
    return heff_tag_at_n(v_ru_24p_2411_24InR, TAG_InR, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_p_2411);
  }
}
V g_co_2eop_24s22628809x1035315751_lam1(V self, V *args);
V g_co_2eop_24s22628809x1035315751_lam0(V self, V *args); static Clo g_co_2eop_24s22628809x1035315751_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s22628809x1035315751_lam0, 4, 0};
V g_co_2eop_24s22628809x1035315751_lam3(V self, V *args);
V g_co_2eop_24s22628809x1035315751_lam2(V self, V *args);
V g_co_2eop_24s22628809x1035315751_lam4(V self, V *args);
Clo g_co_2eop_24s22628809x1035315751_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s22628809x1035315751_entry, 3, 0};

V g_co_2eop_24s22628809x1035315751(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s22628809x1035315751_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s22628809x1035315751_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s22628809x1035315751_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s22628809x1035315751(a[0], a[1], a[2]);
}
V g_co_2eop_24s22628809x1035315751_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s22628809x1035315751_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s22628809x1035315751_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s22628809x1035315751_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s22628809x1035315751_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s22628809x1035315751_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s22628809x1035315751_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s1825131239x2082086395_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_co_2eop_24s1825131239x2082086395_str1, 1, "\012");
V g_co_2eop_24s1825131239x2082086395_lam1(V self, V *args);
V g_co_2eop_24s1825131239x2082086395_lam0(V self, V *args); static Clo g_co_2eop_24s1825131239x2082086395_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1825131239x2082086395_lam0, 4, 0};
V g_co_2eop_24s1825131239x2082086395_lam3(V self, V *args);
V g_co_2eop_24s1825131239x2082086395_lam2(V self, V *args);
V g_co_2eop_24s1825131239x2082086395_lam4(V self, V *args);
V g_co_2eop_24s1825131239x2082086395_lam5(V self, V *args);
Clo g_co_2eop_24s1825131239x2082086395_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1825131239x2082086395_entry, 5, 0};

V g_co_2eop_24s1825131239x2082086395(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1825131239x2082086395_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1825131239x2082086395_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s1825131239x2082086395_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s1825131239x2082086395_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s1825131239x2082086395_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1825131239x2082086395(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s1825131239x2082086395_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1825131239x2082086395_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s1825131239x2082086395_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1825131239x2082086395_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1825131239x2082086395_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1825131239x2082086395_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1825131239x2082086395_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1825131239x2082086395_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_x1_2419 = v_lit_240;
  V v_p_2420 = v_lit_241;
  V v_p_2421 = v_lit_242;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    heff_drop(v_p_2420);
    V f_ = v_p_2421;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_e_2422 = heff_field(v_x1_2419, 0);
    V v_rest_2423 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_co_2eop_24s1825131239x2082086395_str0), v_e_2422), ((V)&g_co_2eop_24s1825131239x2082086395_str1));
    V v_t_2425 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_WriteErr, 2, (V[]){v_t_2424, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s1825131239x2082086395(v_rest_2423, heff_dup(v_p_2420), v_p_2421, heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_p_2420));
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_co_2eop_24s1594985323x520615696_lam1(V self, V *args);
V g_co_2eop_24s1594985323x520615696_lam0(V self, V *args); static Clo g_co_2eop_24s1594985323x520615696_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1594985323x520615696_lam0, 4, 0};
V g_co_2eop_24s1594985323x520615696_lam3(V self, V *args);
V g_co_2eop_24s1594985323x520615696_lam2(V self, V *args);
V g_co_2eop_24s1594985323x520615696_lam4(V self, V *args);
V g_co_2eop_24s1594985323x520615696_lam5(V self, V *args);
Clo g_co_2eop_24s1594985323x520615696_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1594985323x520615696_entry, 10, 0};

V g_co_2eop_24s1594985323x520615696(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1594985323x520615696_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1594985323x520615696_lam2, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s1594985323x520615696_lam4, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2421}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s1594985323x520615696_lam5, 1, 8, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s1594985323x520615696_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1594985323x520615696(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_co_2eop_24s1594985323x520615696_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1594985323x520615696_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1594985323x520615696_lam1, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1594985323x520615696_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1594985323x520615696_lam2(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_co_2eop_24s1594985323x520615696_lam3, 1, 2, (V[]){v_g_2416, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1594985323x520615696_lam4(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1594985323x520615696_lam5(V self, V *args) {
  V v_a_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2etestCmd_24s1796223040x1264767957(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_a_2423, v_lit_244, v_lit_245, heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()), NTAG(TAG_Nil), v_lit_246, v_lit_247));
}
V g_co_2eop_24s1238283193x1160440465_lam1(V self, V *args);
V g_co_2eop_24s1238283193x1160440465_lam0(V self, V *args); static Clo g_co_2eop_24s1238283193x1160440465_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1238283193x1160440465_lam0, 4, 0};
V g_co_2eop_24s1238283193x1160440465_lam3(V self, V *args);
V g_co_2eop_24s1238283193x1160440465_lam2(V self, V *args);
V g_co_2eop_24s1238283193x1160440465_lam4(V self, V *args);
V g_co_2eop_24s1238283193x1160440465_lam5(V self, V *args);
Clo g_co_2eop_24s1238283193x1160440465_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1238283193x1160440465_entry, 6, 0};

V g_co_2eop_24s1238283193x1160440465(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1238283193x1160440465_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1238283193x1160440465_lam2, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s1238283193x1160440465_lam4, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2418, heff_clo_n(g_co_2eop_24s1238283193x1160440465_lam5, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s1238283193x1160440465_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1238283193x1160440465(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s1238283193x1160440465_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1238283193x1160440465_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s1238283193x1160440465_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1238283193x1160440465_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1238283193x1160440465_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s1238283193x1160440465_lam3, 1, 2, (V[]){v_g_2412, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1238283193x1160440465_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1238283193x1160440465_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_resource_2eheldBy_24s2140945292x1227416445(v_lit_240, v_lit_241, v_a_2419, v_lit_242, v_lit_243));
}
V g_co_2eop_24s173284549x1274703393_lam1(V self, V *args);
V g_co_2eop_24s173284549x1274703393_lam0(V self, V *args); static Clo g_co_2eop_24s173284549x1274703393_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s173284549x1274703393_lam0, 4, 0};
V g_co_2eop_24s173284549x1274703393_lam3(V self, V *args);
V g_co_2eop_24s173284549x1274703393_lam2(V self, V *args);
V g_co_2eop_24s173284549x1274703393_lam4(V self, V *args);
V g_co_2eop_24s173284549x1274703393_lam5(V self, V *args);
Clo g_co_2eop_24s173284549x1274703393_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s173284549x1274703393_entry, 6, 0};

V g_co_2eop_24s173284549x1274703393(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s173284549x1274703393_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s173284549x1274703393_lam2, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s173284549x1274703393_lam4, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2418, heff_clo_n(g_co_2eop_24s173284549x1274703393_lam5, 1, 4, (V[]){v_lit_241, v_lit_240, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s173284549x1274703393_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s173284549x1274703393(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s173284549x1274703393_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s173284549x1274703393_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s173284549x1274703393_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s173284549x1274703393_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s173284549x1274703393_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s173284549x1274703393_lam3, 1, 2, (V[]){v_g_2412, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s173284549x1274703393_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s173284549x1274703393_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_lit_241 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2420 = ({ V rv_0 = v_a_2419; V rr_ = heff_rec_reuse_nf(v_lit_241, 30ULL, 5, shape_lib__mod__cwd__style__heff, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2421 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_False), NTAG(TAG_False), v_t_2420});
  return (g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242(v_lit_240, v_t_2421, v_lit_242, v_lit_243));
}
V g_co_2eplus_24s1914620224x1667922359_lam1(V self, V *args);
V g_co_2eplus_24s1914620224x1667922359_lam0(V self, V *args); static Clo g_co_2eplus_24s1914620224x1667922359_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1914620224x1667922359_lam0, 3, 0};
V g_co_2eplus_24s1914620224x1667922359_lam3(V self, V *args);
V g_co_2eplus_24s1914620224x1667922359_lam2(V self, V *args); static Clo g_co_2eplus_24s1914620224x1667922359_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1914620224x1667922359_lam2, 4, 0};

static V g_co_2eplus_24s1914620224x1667922359_val;
static HEFF_ONCE g_co_2eplus_24s1914620224x1667922359_st;
static V g_co_2eplus_24s1914620224x1667922359_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1914620224x1667922359_lam0_clo), ((V)&g_co_2eplus_24s1914620224x1667922359_lam2_clo)});
}
V g_co_2eplus_24s1914620224x1667922359_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1914620224x1667922359_st)) return g_co_2eplus_24s1914620224x1667922359_val;
  return heff_global(&g_co_2eplus_24s1914620224x1667922359_val, &g_co_2eplus_24s1914620224x1667922359_st, g_co_2eplus_24s1914620224x1667922359_init);
}
V g_co_2eplus_24s1914620224x1667922359_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s1914620224x1667922359_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_245}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eplus_24s1914620224x1667922359_lam1, 1, 3, (V[]){v_h_246, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24InL = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_green_2egreen_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_2412}));
      v_t_2416 = heff_tag_at_n(v_ru_24y_2411_24InL, TAG_InL, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_InR: {
      V v_y_2414 = heff_field(v_y_2411, 0);
      heff_take_n(v_y_2411, 1ULL, 1);
      V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2414}));
      v_t_2416 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2415});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1914620224x1667922359_lam3(V self, V *args) {
  V v_s_2426 = args[0];
  V v_h_2424 = heff_env(self)[0];
  V v_nt_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_h_2424, 1, (V[]){v_s_2426}));
  V f_ = v_nt_2419;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1914620224x1667922359_lam2(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_m_2417);
    heff_drop(v_n_2418);
    V v_t_2428;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_Throw: {
      V v_s_2422 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24Throw = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      heff_drop(v_nt_2419);
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24Throw, TAG_Throw, 1, (V[]){v_s_2422});
      break;
    }
    case TAG_Catch: {
      V v_c_2423 = heff_field(v_x_2421, 0);
      V v_h_2424 = heff_field(v_x_2421, 1);
      V v_ru_24x_2421_24Catch = heff_take_reuse_n(v_x_2421, 3ULL, 2);
      V v_t_2425 = heff_tr(heff_call(heff_dup(v_nt_2419), 1, (V[]){v_c_2423}));
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24Catch, TAG_Catch, 2, (V[]){v_t_2425, heff_clo_n(g_co_2eplus_24s1914620224x1667922359_lam3, 1, 2, (V[]){v_h_2424, v_nt_2419})});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2428});
  }
  case TAG_InR: {
    V v_y_2429 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_y_2429)) {
    case TAG_InL: {
      V v_x_2430 = heff_field(v_y_2429, 0);
      V v_ru_24y_2429_24InL = heff_take_reuse_n(v_y_2429, 1ULL, 1);
      heff_drop(v_m_2417);
      heff_drop(v_n_2418);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      V v_t_2441;
      switch (heff_tag_of(v_x_2430)) {
      case TAG_Spawn: {
        V v_c_2431 = heff_field(v_x_2430, 0);
        V v_x_2432 = heff_field(v_x_2430, 1);
        V v_ru_24x_2430_24Spawn = heff_take_reuse_n(v_x_2430, 3ULL, 2);
        V v_t_2433 = heff_tr(heff_call(v_nt_2419, 1, (V[]){v_c_2431}));
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Spawn, TAG_Spawn, 2, (V[]){v_t_2433, v_x_2432});
        break;
      }
      case TAG_Yield: {
        V v_x_2434 = heff_field(v_x_2430, 0);
        V v_ru_24x_2430_24Yield = heff_take_reuse_n(v_x_2430, 1ULL, 1);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Yield, TAG_Yield, 1, (V[]){v_x_2434});
        break;
      }
      case TAG_NewChan: {
        V v_k_2435 = heff_field(v_x_2430, 0);
        V v_ru_24x_2430_24NewChan = heff_take_reuse_n(v_x_2430, 1ULL, 1);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24NewChan, TAG_NewChan, 1, (V[]){v_k_2435});
        break;
      }
      case TAG_Send: {
        V v_ch_2436 = heff_field(v_x_2430, 0);
        V v_v_2437 = heff_field(v_x_2430, 1);
        V v_x_2438 = heff_field(v_x_2430, 2);
        V v_ru_24x_2430_24Send = heff_take_reuse_n(v_x_2430, 7ULL, 3);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Send, TAG_Send, 3, (V[]){v_ch_2436, v_v_2437, v_x_2438});
        break;
      }
      case TAG_Recv: {
        V v_ch_2439 = heff_field(v_x_2430, 0);
        V v_k_2440 = heff_field(v_x_2430, 1);
        V v_ru_24x_2430_24Recv = heff_take_reuse_n(v_x_2430, 3ULL, 2);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Recv, TAG_Recv, 2, (V[]){v_ch_2439, v_k_2440});
        break;
      }
      default: heff_nomatch(v_x_2430);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24y_2429_24InL, TAG_InL, 1, (V[]){v_t_2441});
      break;
    }
    case TAG_InR: {
      V v_y_2442 = heff_field(v_y_2429, 0);
      heff_take_n(v_y_2429, 1ULL, 1);
      V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_y_2442}));
      v_t_2444 = heff_tag_at_n(v_ru_24p_2420_24InR, TAG_InR, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_y_2429);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2eop_24s1070734279x1181903788_lam1(V self, V *args);
V g_co_2eop_24s1070734279x1181903788_lam0(V self, V *args); static Clo g_co_2eop_24s1070734279x1181903788_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1070734279x1181903788_lam0, 4, 0};
V g_co_2eop_24s1070734279x1181903788_lam3(V self, V *args);
V g_co_2eop_24s1070734279x1181903788_lam2(V self, V *args);
V g_co_2eop_24s1070734279x1181903788_lam4(V self, V *args);
Clo g_co_2eop_24s1070734279x1181903788_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1070734279x1181903788_entry, 3, 0};

V g_co_2eop_24s1070734279x1181903788(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1914620224x1667922359_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1070734279x1181903788_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1070734279x1181903788_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1070734279x1181903788_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s1070734279x1181903788_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1070734279x1181903788(a[0], a[1], a[2]);
}
V g_co_2eop_24s1070734279x1181903788_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1070734279x1181903788_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1070734279x1181903788_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1070734279x1181903788_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1070734279x1181903788_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1070734279x1181903788_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1070734279x1181903788_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1050926098x962532285_lam1(V self, V *args);
V g_co_2eop_24s1050926098x962532285_lam0(V self, V *args); static Clo g_co_2eop_24s1050926098x962532285_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1050926098x962532285_lam0, 4, 0};
V g_co_2eop_24s1050926098x962532285_lam3(V self, V *args);
V g_co_2eop_24s1050926098x962532285_lam2(V self, V *args);
V g_co_2eop_24s1050926098x962532285_lam4(V self, V *args);
V g_co_2eop_24s1050926098x962532285_lam5(V self, V *args);
Clo g_co_2eop_24s1050926098x962532285_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1050926098x962532285_entry, 3, 0};

V g_co_2eop_24s1050926098x962532285(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Spawn: {
      V v_c_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Spawn = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Spawn, TAG_Spawn, 2, (V[]){v_t_246, v_x_245});
      break;
    }
    case TAG_Yield: {
      V v_x_247 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Yield = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Yield, TAG_Yield, 1, (V[]){v_x_247});
      break;
    }
    case TAG_NewChan: {
      V v_k_248 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24NewChan = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24NewChan, TAG_NewChan, 1, (V[]){v_k_248});
      break;
    }
    case TAG_Send: {
      V v_ch_249 = heff_field(v_x_243, 0);
      V v_v_2410 = heff_field(v_x_243, 1);
      V v_x_2411 = heff_field(v_x_243, 2);
      V v_ru_24x_243_24Send = heff_take_reuse_n(v_x_243, 7ULL, 3);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Send, TAG_Send, 3, (V[]){v_ch_249, v_v_2410, v_x_2411});
      break;
    }
    case TAG_Recv: {
      V v_ch_2412 = heff_field(v_x_243, 0);
      V v_k_2413 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Recv = heff_take_reuse_n(v_x_243, 3ULL, 2);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Recv, TAG_Recv, 2, (V[]){v_ch_2412, v_k_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2414});
    break;
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1050926098x962532285_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1050926098x962532285_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1050926098x962532285_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2415}));
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2427});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2428}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2429, heff_clo_n(g_co_2eop_24s1050926098x962532285_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s1050926098x962532285_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1050926098x962532285(a[0], a[1], a[2]);
}
V g_co_2eop_24s1050926098x962532285_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2420}));
  V f_ = v_k_2419;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1050926098x962532285_lam0(V self, V *args) {
  V v_g_2416 = args[0];
  V v_c_2417 = args[1];
  V v_hd_2418 = args[2];
  V v_k_2419 = args[3];
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_co_2eop_24s1050926098x962532285_lam1, 1, 2, (V[]){v_g_2416, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1050926098x962532285_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_x_2424}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1050926098x962532285_lam2(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2423;
  args[1] = heff_clo_n(g_co_2eop_24s1050926098x962532285_lam3, 1, 2, (V[]){v_g_2422, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1050926098x962532285_lam4(V self, V *args) {
  V v_c_2426 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1050926098x962532285_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310418905x1614124229_lam1(V self, V *args);
V g_co_2eop_24s310418905x1614124229_lam0(V self, V *args); static Clo g_co_2eop_24s310418905x1614124229_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310418905x1614124229_lam0, 4, 0};
V g_co_2eop_24s310418905x1614124229_lam3(V self, V *args);
V g_co_2eop_24s310418905x1614124229_lam2(V self, V *args);
V g_co_2eop_24s310418905x1614124229_lam4(V self, V *args);
Clo g_co_2eop_24s310418905x1614124229_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310418905x1614124229_entry, 3, 0};

V g_co_2eop_24s310418905x1614124229(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Spawn: {
      V v_c_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Spawn = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Spawn, TAG_Spawn, 2, (V[]){v_t_246, v_x_245});
      break;
    }
    case TAG_Yield: {
      V v_x_247 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Yield = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Yield, TAG_Yield, 1, (V[]){v_x_247});
      break;
    }
    case TAG_NewChan: {
      V v_k_248 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24NewChan = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24NewChan, TAG_NewChan, 1, (V[]){v_k_248});
      break;
    }
    case TAG_Send: {
      V v_ch_249 = heff_field(v_x_243, 0);
      V v_v_2410 = heff_field(v_x_243, 1);
      V v_x_2411 = heff_field(v_x_243, 2);
      V v_ru_24x_243_24Send = heff_take_reuse_n(v_x_243, 7ULL, 3);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Send, TAG_Send, 3, (V[]){v_ch_249, v_v_2410, v_x_2411});
      break;
    }
    case TAG_Recv: {
      V v_ch_2412 = heff_field(v_x_243, 0);
      V v_k_2413 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Recv = heff_take_reuse_n(v_x_243, 3ULL, 2);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Recv, TAG_Recv, 2, (V[]){v_ch_2412, v_k_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2414});
    break;
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s310418905x1614124229_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s310418905x1614124229_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s310418905x1614124229_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2415}));
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2427});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2428}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2429, v_k2_242});
}
V g_co_2eop_24s310418905x1614124229_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s310418905x1614124229(a[0], a[1], a[2]);
}
V g_co_2eop_24s310418905x1614124229_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2420}));
  V f_ = v_k_2419;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310418905x1614124229_lam0(V self, V *args) {
  V v_g_2416 = args[0];
  V v_c_2417 = args[1];
  V v_hd_2418 = args[2];
  V v_k_2419 = args[3];
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_co_2eop_24s310418905x1614124229_lam1, 1, 2, (V[]){v_g_2416, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310418905x1614124229_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_x_2424}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310418905x1614124229_lam2(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2423;
  args[1] = heff_clo_n(g_co_2eop_24s310418905x1614124229_lam3, 1, 2, (V[]){v_g_2422, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310418905x1614124229_lam4(V self, V *args) {
  V v_c_2426 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1278336259x450164198_lam1(V self, V *args);
V g_co_2eop_24s1278336259x450164198_lam0(V self, V *args); static Clo g_co_2eop_24s1278336259x450164198_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1278336259x450164198_lam0, 4, 0};
V g_co_2eop_24s1278336259x450164198_lam3(V self, V *args);
V g_co_2eop_24s1278336259x450164198_lam2(V self, V *args);
V g_co_2eop_24s1278336259x450164198_lam4(V self, V *args);
V g_co_2eop_24s1278336259x450164198_lam5(V self, V *args);
Clo g_co_2eop_24s1278336259x450164198_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1278336259x450164198_entry, 14, 0};

V g_co_2eop_24s1278336259x450164198(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_lit_2410, V v_lit_2411, V v_p_2412, V v_hd_2413) {
top: ;
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1278336259x450164198_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1278336259x450164198_lam2, 2, 1, (V[]){heff_dup(v_hd_2413)})}), heff_clo_n(g_co_2eop_24s1278336259x450164198_lam4, 1, 1, (V[]){heff_dup(v_hd_2413)}), v_p_2412}));
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_2413, 1, 3), 2, (V[]){v_t_2426, heff_clo_n(g_co_2eop_24s1278336259x450164198_lam5, 1, 12, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_lit_2410, v_lit_2411})});
}
V g_co_2eop_24s1278336259x450164198_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1278336259x450164198(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13]);
}
V g_co_2eop_24s1278336259x450164198_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2419 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2418}));
  V f_ = v_k_2417;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1278336259x450164198_lam0(V self, V *args) {
  V v_g_2414 = args[0];
  V v_c_2415 = args[1];
  V v_hd_2416 = args[2];
  V v_k_2417 = args[3];
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_co_2eop_24s1278336259x450164198_lam1, 1, 2, (V[]){v_g_2414, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1278336259x450164198_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_2420 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_g_2420, 1, (V[]){v_x_2422}));
  V f_ = heff_get_n(v_hd_2413, 0, 3);
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1278336259x450164198_lam2(V self, V *args) {
  V v_g_2420 = args[0];
  V v_m_2421 = args[1];
  V v_hd_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2413, 1));
  args[0] = v_m_2421;
  args[1] = heff_clo_n(g_co_2eop_24s1278336259x450164198_lam3, 1, 2, (V[]){v_g_2420, v_hd_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1278336259x450164198_lam4(V self, V *args) {
  V v_c_2424 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_get_n(v_hd_2413, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1278336259x450164198_lam5(V self, V *args) {
  V v_a_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  V v_lit_248 = heff_env(self)[8];
  V v_lit_249 = heff_env(self)[9];
  V v_lit_2410 = heff_env(self)[10];
  V v_lit_2411 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_a_2427);
  return (g_app_2eheff_2emain_2edispatch_24s975174480x1139976579(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_lit_248, v_lit_249, v_lit_2410, v_lit_2411));
}
V g_co_2eop_24s94900133x232571340_lam1(V self, V *args);
V g_co_2eop_24s94900133x232571340_lam0(V self, V *args); static Clo g_co_2eop_24s94900133x232571340_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s94900133x232571340_lam0, 4, 0};
V g_co_2eop_24s94900133x232571340_lam3(V self, V *args);
V g_co_2eop_24s94900133x232571340_lam2(V self, V *args);
V g_co_2eop_24s94900133x232571340_lam4(V self, V *args);
Clo g_co_2eop_24s94900133x232571340_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s94900133x232571340_entry, 3, 0};

V g_co_2eop_24s94900133x232571340(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s94900133x232571340_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s94900133x232571340_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s94900133x232571340_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s94900133x232571340_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s94900133x232571340(a[0], a[1], a[2]);
}
V g_co_2eop_24s94900133x232571340_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s94900133x232571340_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s94900133x232571340_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s94900133x232571340_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s94900133x232571340_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s94900133x232571340_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s94900133x232571340_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}