// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StringWord 15530
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_claim 296100950
#define LBL_cmt 308164
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_err 310239
#define LBL_exposes 1070285678
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_listed 844633320
#define LBL_name 9869138
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__decls__diags[] = {LBL_imports, LBL_decls, LBL_diags};
V g_heff_2esyntax_2efmt_2eimports_2ereadImports(V);
V g_heff_2esyntax_2efmt_2eimports_2ereadImports_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2eimports_2ereadImports_clo;
HeffT2 g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eformat_2ealtKey(V, V);
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ealtKey_clo;
V g_heff_2esyntax_2eformat_2ecatchKey(V, V);
V g_heff_2esyntax_2eformat_2ecatchKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ecatchKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_heff_2esyntax_2eformat_2eformatIn(V, V);
V g_heff_2esyntax_2eformat_2eformatIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eformatIn_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2elamKey(V, V);
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2elamKey_clo;
V g_heff_2esyntax_2eformat_2emeaning(V);
V g_heff_2esyntax_2eformat_2emeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaning_clo;
V g_heff_2esyntax_2eformat_2emeaningOf(V, V);
V g_heff_2esyntax_2eformat_2emeaningOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningOf_clo;
V g_heff_2esyntax_2eformat_2eparamKey(V, V);
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eparamKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2epiKey(V, V);
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epiKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2esameMeaning_24cpr(V, V, V, V);
V g_heff_2esyntax_2eformat_2esegmentKey(V, V);
V g_heff_2esyntax_2eformat_2esegmentKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esegmentKey_clo;
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eformat_2eupdateSetKey(V, V);
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo;
V g_heff_2esyntax_2eformat_2evariantKey(V, V);
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2evariantKey_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1055307687x247454614(V, V);
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_clo;
V g_list_2emap_24s1099021180x1702355548(V, V);
V g_list_2emap_24s1099021180x1702355548_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_clo;
V g_list_2emap_24s1152414072x2935301(V, V);
V g_list_2emap_24s1152414072x2935301_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_clo;
V g_list_2emap_24s135291903x1031656159(V, V);
V g_list_2emap_24s135291903x1031656159_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_clo;
V g_list_2emap_24s179832492x431904054(V);
V g_list_2emap_24s179832492x431904054_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_clo;
V g_list_2emap_24s1816200867x1876638332(V);
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s228910449x1110031924(V, V);
V g_list_2emap_24s228910449x1110031924_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s354283597x484250159(V, V);
V g_list_2emap_24s354283597x484250159_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_clo;
V g_list_2emap_24s510830240x893896831(V, V);
V g_list_2emap_24s510830240x893896831_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_clo;
V g_list_2emap_24s900318151x1569363206(V, V, V);
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str1, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str2, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str3, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str4, 3, "utf");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str5, 7, "default");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str6, 1, "*");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str7, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str8, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str9, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str10, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str14, 7, "segment");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_str16, 1, "(");
Clo g_heff_2esyntax_2eformat_2esegmentKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2esegmentKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2esegmentKey(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkSegment: {
      V v_v_244 = heff_field(v_x21_242, 0);
      V v_ty_245 = heff_field(v_x21_242, 1);
      V v_size_246 = heff_field(v_x21_242, 2);
      V v_little_247 = heff_field(v_x21_242, 3);
      V v_signed_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 31ULL, 5);
      V v_t_249 = heff_tr(heff_call(v_f_240, 1, (V[]){v_v_244}));
      V v_t_2411;
      switch (heff_tag_of(v_ty_245)) {
      case TAG_SegmentInteger: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str0);
        break;
      }
      case TAG_SegmentBinary: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str1);
        break;
      }
      case TAG_SegmentBits: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str2);
        break;
      }
      case TAG_SegmentFloat: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str3);
        break;
      }
      case TAG_SegmentUtf: {
        V v_n_2410 = heff_field(v_ty_245, 0);
        heff_take_n(v_ty_245, 1ULL, 1);
        v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_str4), heff_intShow(v_n_2410));
        break;
      }
      default: heff_nomatch(v_ty_245);
      }
      V v_t_2417;
      switch (heff_tag_of(v_size_246)) {
      case TAG_SizeDefault: {
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str5);
        break;
      }
      case TAG_SizeNumber: {
        V v_n_2412 = heff_field(v_size_246, 0);
        heff_take_n(v_size_246, 1ULL, 1);
        v_t_2417 = heff_intShow(v_n_2412);
        break;
      }
      case TAG_SizeName: {
        V v_x_2413 = heff_field(v_size_246, 0);
        V v_unit_2415 = heff_field(v_size_246, 2);
        heff_take_n(v_size_246, 5ULL, 3);
        V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_str6), heff_intShow(v_unit_2415));
        v_t_2417 = heff_strAppend(v_x_2413, v_t_2416);
        break;
      }
      default: heff_nomatch(v_size_246);
      }
      V v_t_2418;
      if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
        heff_drop(v_little_247);
        v_t_2418 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str7);
      } else {
        heff_drop(v_little_247);
        v_t_2418 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str8);
      }
      V v_t_2419;
      if ((heff_dup(v_signed_248) == NTAG(TAG_True))) {
        heff_drop(v_signed_248);
        v_t_2419 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str9);
      } else {
        heff_drop(v_signed_248);
        v_t_2419 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str10);
      }
      V v_t_2420 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
      V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2420})});
      V v_parts_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2421})});
      V v_x2_2423 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2esegmentKey_str11), v_parts_2422));
      V v_t_2426;
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_Nil: {
        v_t_2426 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2424 = heff_field(v_x2_2423, 0);
        V v_xs_2425 = heff_field(v_x2_2423, 1);
        heff_take_n(v_x2_2423, 3ULL, 2);
        v_t_2426 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str13); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2423);
      }
      V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_str14), heff_strAppend(v_t_2426, ((V)&g_heff_2esyntax_2eformat_2esegmentKey_str15)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_str16), v_t_2427);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2esegmentKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2esegmentKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str3, 8, "explicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str11, 1, "(");
Clo g_heff_2esyntax_2eformat_2eparamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eparamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eparamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2eparamKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str5), v_t_2414);
    }
    case TAG_ImplicitParam: {
      V v_x_2415 = heff_field(v_x21_242, 0);
      V v_t_2417 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2417}));
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_parts_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_t_2419});
      V v_x2_2421 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2eparamKey_str6), v_parts_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str11), v_t_2425);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eparamKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str3, 5, "named");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str15, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str21, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str22, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str27, 4, "anon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str29, 1, "(");
Clo g_heff_2esyntax_2eformat_2epiKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epiKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2epiKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_244)}));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_parts_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_t_246});
    V v_x2_248 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str0), v_parts_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str3), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2epiKey_str4)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str5), v_t_2412);
  }
  case TAG_PiImplicit: {
    V v_x_2413 = heff_field(v_x2_241, 0);
    V v_t_2416 = heff_field(v_x2_241, 3);
    V v_x25_2417 = heff_field(v_x2_241, 4);
    switch (heff_tag_of(v_x25_2417)) {
    case TAG_Nothing: {
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2416)}));
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_parts_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2413), v_t_2419});
      V v_x2_2421 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str6), v_parts_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2epiKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str11), v_t_2425);
    }
    case TAG_Just: {
      V v_d_2426 = heff_field(v_x25_2417, 0);
      V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2416)}));
      V v_t_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_d_2426)}));
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      V v_parts_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2413), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2429})});
      V v_x2_2431 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str12), v_parts_2430));
      V v_t_2434;
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_Nil: {
        v_t_2434 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2432 = heff_field(v_x2_2431, 0);
        V v_xs_2433 = heff_field(v_x2_2431, 1);
        heff_take_n(v_x2_2431, 3ULL, 2);
        v_t_2434 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str14); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2431);
      }
      V v_t_2435 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str15), heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2eformat_2epiKey_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str17), v_t_2435);
    }
    default: return heff_nomatch(v_x25_2417);
    }
  }
  case TAG_PiInstance: {
    V v_x_2436 = heff_field(v_x2_241, 0);
    V v_t_2439 = heff_field(v_x2_241, 3);
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2439)}));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
    V v_parts_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2436), v_t_2441});
    V v_x2_2443 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str18), v_parts_2442));
    V v_t_2446;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      v_t_2446 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      v_t_2446 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str20); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    V v_t_2447 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str21), heff_strAppend(v_t_2446, ((V)&g_heff_2esyntax_2eformat_2epiKey_str22)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str23), v_t_2447);
  }
  case TAG_PiAnon: {
    V v_t_2448 = heff_field(v_x2_241, 0);
    V v_t_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2448)}));
    V v_parts_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    V v_x2_2451 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str24), v_parts_2450));
    V v_t_2454;
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str26); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    V v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str27), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2eformat_2epiKey_str28)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str29), v_t_2455);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2epiKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str7, 7, "variant");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str13, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str15, 1, "(");
Clo g_heff_2esyntax_2eformat_2evariantKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2evariantKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2evariantKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_args_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_x2_247 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_246));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str3)));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_parts_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2412});
      V v_x2_2414 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2evariantKey_str4), v_parts_2413));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str7), heff_strAppend(v_t_2417, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str8)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str9), v_t_2418);
    }
    case TAG_BadVariant: {
      V v_e_2419 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
      V v_parts_2421 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      V v_x2_2422 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2evariantKey_str10), v_parts_2421));
      V v_t_2425;
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_xs_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        v_t_2425 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str12); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2422);
      }
      V v_t_2426 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str13), heff_strAppend(v_t_2425, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str14)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str15), v_t_2426);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2evariantKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str7, 4, "path");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str9, 1, "(");
Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eupdateSetKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eupdateSetKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x2_246 = (g_list_2emap_24s1816200867x1876638332(v_path_244));
      V v_t_249;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_xs_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str1); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str2), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str3)));
      V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_parts_2413 = heff_tag_at_n(v_ru_24x21_242_24SetPath, TAG_Cons, 2, (V[]){v_t_2410, v_t_2412});
      V v_x2_2414 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str4), v_parts_2413));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str7), heff_strAppend(v_t_2417, ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str8)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str9), v_t_2418);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eupdateSetKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str3, 3, "alt");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str5, 1, "(");
Clo g_heff_2esyntax_2eformat_2ealtKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ealtKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ealtKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2eformat_2epatKey(v_p_244));
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_Cons, 2, (V[]){v_t_246, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ealtKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2ealtKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ealtKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ealtKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2ealtKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ealtKey_str5), v_t_2414);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ealtKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str15, 3, "tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str21, 3, "int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str22, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str27, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str29, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str31, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str32, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str33, 6, "string");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str34, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str35, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str36, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str37, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str38, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str39, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str41, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str42, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str43, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str44, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str45, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str46, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str47, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str48, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str49, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str50, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str51, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str52, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str53, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str54, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str55, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str56, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str57, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str58, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str59, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str60, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str61, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str62, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str63, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str64, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str65, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str66, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str67, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str69, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str70, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str71, 4, "word");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str72, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str73, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str74, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str75, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str76, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str77, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str78, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str79, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str80, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str81, 3, "app");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str82, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str83, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str84, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str85, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str86, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str87, 7, "project");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str88, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str89, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str90, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str91, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str92, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str93, 5, "named");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str94, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str95, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str96, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str97, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str98, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str99, 2, "pi");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str100, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str101, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str103, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str104, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str105, 3, "lam");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str106, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str107, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str108, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str109, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str110, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str111, 3, "ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str112, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str113, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str115, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str116, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str117, 4, "spec");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str118, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str119, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str120, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str121, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str122, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str123, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str125, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str126, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str127, 3, "sig");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str128, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str129, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str130, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str131, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str132, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str133, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str135, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str136, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str137, 3, "sum");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str138, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str139, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str140, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str141, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str142, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str143, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str144, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str145, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str146, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str147, 6, "struct");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str148, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str149, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str150, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str151, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str152, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str153, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str154, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str155, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str156, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str157, 6, "update");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str158, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str159, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str160, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str161, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str162, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str163, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str164, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str165, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str166, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str167, 5, "match");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str168, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str169, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str170, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str171, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str172, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str173, 3, "let");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str174, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str175, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str176, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str177, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str178, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str179, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str180, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str181, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str182, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str183, 2, "do");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str184, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str185, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str186, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str187, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str188, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str189, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str190, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str191, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str192, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str193, 5, "local");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str194, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str195, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str196, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str197, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str198, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str199, 7, "invalid");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str200, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str201, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str202, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str203, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str204, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str205, 6, "assign");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str206, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str207, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str208, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str209, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str210, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str211, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str212, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str213, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str214, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str215, 5, "while");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str216, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str217, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str218, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str219, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str220, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str221, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str222, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str223, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str224, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str225, 3, "for");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str226, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str227, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str228, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str229, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str230, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str231, 6, "ifthen");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str232, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str233, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str234, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str235, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str236, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str237, 5, "break");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str238, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str239, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str240, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str241, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str242, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str243, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str244, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str245, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str246, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str247, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str248, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str249, 6, "return");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str250, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str251, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str252, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str253, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str254, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str255, 4, "nest");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str256, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str257, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str258, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str259, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str260, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str261, 4, "lazy");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str262, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str263, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str264, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str265, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str266, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str267, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str268, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str269, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str270, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str271, 5, "tuple");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str272, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str273, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str274, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str275, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str276, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str277, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str278, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str279, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str280, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str281, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str282, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str283, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str284, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str285, 3, "try");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str286, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str287, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str288, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str289, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str290, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str291, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str292, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str293, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str294, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str295, 4, "with");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str296, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str297, 1, "(");
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args);
Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      V v_x2_246 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str0), v_t_245));
      V v_t_249;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_xs_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str3), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str5), v_t_2410);
    }
    case TAG_EImplicitVar: {
      V v_x_2411 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
      V v_x2_2413 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str6), v_t_2412));
      V v_t_2416;
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nil: {
        v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_xs_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str8); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2413);
      }
      V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str9), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str11), v_t_2417);
    }
    case TAG_ETag: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
      V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str12), v_t_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str14); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str15), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str17), v_t_2424);
    }
    case TAG_EInt: {
      V v_i_2425 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2425), NTAG(TAG_Nil)});
      V v_x2_2427 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str18), v_t_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str19);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_xs_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str20); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2427);
      }
      V v_t_2431 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str21), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str22)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str23), v_t_2431);
    }
    case TAG_EFloat: {
      V v_x_2432 = heff_tget_v(v_x21_242, 0);
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2433 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_floatShow(v_x_2432), NTAG(TAG_Nil)});
      V v_x2_2434 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str24), v_t_2433));
      V v_t_2437;
      switch (heff_tag_of(v_x2_2434)) {
      case TAG_Nil: {
        v_t_2437 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_2435 = heff_field(v_x2_2434, 0);
        V v_xs_2436 = heff_field(v_x2_2434, 1);
        heff_take_n(v_x2_2434, 3ULL, 2);
        v_t_2437 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str26); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2434);
      }
      V v_t_2438 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str27), heff_strAppend(v_t_2437, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str28)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str29), v_t_2438);
    }
    case TAG_EString: {
      V v_x_2439 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2440 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
      V v_x2_2441 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str30), v_t_2440));
      V v_t_2444;
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_Nil: {
        v_t_2444 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str31);
        break;
      }
      case TAG_Cons: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_xs_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        v_t_2444 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str32); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2441);
      }
      V v_t_2445 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str33), heff_strAppend(v_t_2444, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str34)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str35), v_t_2445);
    }
    case TAG_EBinary: {
      V v_segs_2446 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_2448 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam0, 1, 1, (V[]){v_r_240}), v_segs_2446));
      V v_t_2451;
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_Nil: {
        v_t_2451 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str36);
        break;
      }
      case TAG_Cons: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        V v_xs_2450 = heff_field(v_x2_2448, 1);
        heff_take_n(v_x2_2448, 3ULL, 2);
        v_t_2451 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str37); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2448);
      }
      V v_t_2452 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str38), heff_strAppend(v_t_2451, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str39)));
      V v_parts_2453 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
      V v_x2_2454 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str40), v_parts_2453));
      V v_t_2457;
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_Nil: {
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str41);
        break;
      }
      case TAG_Cons: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_xs_2456 = heff_field(v_x2_2454, 1);
        heff_take_n(v_x2_2454, 3ULL, 2);
        v_t_2457 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str42); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2454);
      }
      V v_t_2458 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str43), heff_strAppend(v_t_2457, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str44)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str45), v_t_2458);
    }
    case TAG_ERune: {
      V v_c_2459 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2460 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2459), NTAG(TAG_Nil)});
      V v_x2_2461 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str46), v_t_2460));
      V v_t_2464;
      switch (heff_tag_of(v_x2_2461)) {
      case TAG_Nil: {
        v_t_2464 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str47);
        break;
      }
      case TAG_Cons: {
        V v_x_2462 = heff_field(v_x2_2461, 0);
        V v_xs_2463 = heff_field(v_x2_2461, 1);
        heff_take_n(v_x2_2461, 3ULL, 2);
        v_t_2464 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str48); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2461);
      }
      V v_t_2465 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str49), heff_strAppend(v_t_2464, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str50)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str51), v_t_2465);
    }
    case TAG_EWord: {
      V v_w_2466 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2468;
      switch (heff_tag_of(v_w_2466)) {
      case TAG_TypeWord: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str52);
        break;
      }
      case TAG_IntWord: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str53);
        break;
      }
      case TAG_FloatWord: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str54);
        break;
      }
      case TAG_StringWord: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str55);
        break;
      }
      case TAG_RuneWord: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str56);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str57);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str58);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2467 = heff_field(v_w_2466, 0);
        heff_take_n(v_w_2466, 1ULL, 1);
        switch (heff_tag_of(v_w_2467)) {
        case TAG_I8: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str59);
          break;
        }
        case TAG_I16: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str60);
          break;
        }
        case TAG_I32: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str61);
          break;
        }
        case TAG_I64: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str62);
          break;
        }
        case TAG_U8: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str63);
          break;
        }
        case TAG_U16: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str64);
          break;
        }
        case TAG_U32: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str65);
          break;
        }
        case TAG_U64: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str66);
          break;
        }
        case TAG_F32: {
          v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str67);
          break;
        }
        default: heff_nomatch(v_w_2467);
        }
        break;
      }
      default: heff_nomatch(v_w_2466);
      }
      V v_t_2469 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
      V v_x2_2470 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str68), v_t_2469));
      V v_t_2473;
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_Nil: {
        v_t_2473 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str69);
        break;
      }
      case TAG_Cons: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_xs_2472 = heff_field(v_x2_2470, 1);
        heff_take_n(v_x2_2470, 3ULL, 2);
        v_t_2473 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str70); V a_1 = v_x_2471; V a_2 = v_xs_2472; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2472); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2470);
      }
      V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str71), heff_strAppend(v_t_2473, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str72)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str73), v_t_2474);
    }
    case TAG_EApp: {
      V v_h_2475 = heff_field(v_x21_242, 0);
      V v_args_2476 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_2475}));
      V v_x2_2478 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_2476));
      V v_t_2481;
      switch (heff_tag_of(v_x2_2478)) {
      case TAG_Nil: {
        v_t_2481 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str74);
        break;
      }
      case TAG_Cons: {
        V v_x_2479 = heff_field(v_x2_2478, 0);
        V v_xs_2480 = heff_field(v_x2_2478, 1);
        heff_take_n(v_x2_2478, 3ULL, 2);
        v_t_2481 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str75); V a_1 = v_x_2479; V a_2 = v_xs_2480; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2480); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2478);
      }
      V v_t_2482 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str76), heff_strAppend(v_t_2481, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str77)));
      V v_t_2483 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2482, NTAG(TAG_Nil)});
      V v_parts_2484 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_Cons, 2, (V[]){v_t_2477, v_t_2483});
      V v_x2_2485 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str78), v_parts_2484));
      V v_t_2488;
      switch (heff_tag_of(v_x2_2485)) {
      case TAG_Nil: {
        v_t_2488 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str79);
        break;
      }
      case TAG_Cons: {
        V v_x_2486 = heff_field(v_x2_2485, 0);
        V v_xs_2487 = heff_field(v_x2_2485, 1);
        heff_take_n(v_x2_2485, 3ULL, 2);
        v_t_2488 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str80); V a_1 = v_x_2486; V a_2 = v_xs_2487; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2487); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2485);
      }
      V v_t_2489 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str81), heff_strAppend(v_t_2488, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str82)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str83), v_t_2489);
    }
    case TAG_EProject: {
      V v_x_2490 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2491 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2490, NTAG(TAG_Nil)});
      V v_x2_2492 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str84), v_t_2491));
      V v_t_2495;
      switch (heff_tag_of(v_x2_2492)) {
      case TAG_Nil: {
        v_t_2495 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str85);
        break;
      }
      case TAG_Cons: {
        V v_x_2493 = heff_field(v_x2_2492, 0);
        V v_xs_2494 = heff_field(v_x2_2492, 1);
        heff_take_n(v_x2_2492, 3ULL, 2);
        v_t_2495 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str86); V a_1 = v_x_2493; V a_2 = v_xs_2494; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2494); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2492);
      }
      V v_t_2496 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str87), heff_strAppend(v_t_2495, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str88)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str89), v_t_2496);
    }
    case TAG_ENamed: {
      V v_x_2497 = heff_field(v_x21_242, 0);
      V v_e_2498 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2498}));
      V v_t_24100 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2499, NTAG(TAG_Nil)});
      V v_parts_24101 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_Cons, 2, (V[]){v_x_2497, v_t_24100});
      V v_x2_24102 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str90), v_parts_24101));
      V v_t_24105;
      switch (heff_tag_of(v_x2_24102)) {
      case TAG_Nil: {
        v_t_24105 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str91);
        break;
      }
      case TAG_Cons: {
        V v_x_24103 = heff_field(v_x2_24102, 0);
        V v_xs_24104 = heff_field(v_x2_24102, 1);
        heff_take_n(v_x2_24102, 3ULL, 2);
        v_t_24105 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str92); V a_1 = v_x_24103; V a_2 = v_xs_24104; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24104); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24102);
      }
      V v_t_24106 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str93), heff_strAppend(v_t_24105, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str94)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str95), v_t_24106);
    }
    case TAG_EPi: {
      V v_b_24107 = heff_field(v_x21_242, 0);
      V v_cod_24108 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24109 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_b_24107; V r_ = (g_heff_2esyntax_2eformat_2epiKey(a_0, a_1)); heff_drop(v_b_24107); r_; });
      V v_t_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_24108}));
      V v_t_24111 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24110, NTAG(TAG_Nil)});
      V v_parts_24112 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_Cons, 2, (V[]){v_t_24109, v_t_24111});
      V v_x2_24113 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str96), v_parts_24112));
      V v_t_24116;
      switch (heff_tag_of(v_x2_24113)) {
      case TAG_Nil: {
        v_t_24116 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str97);
        break;
      }
      case TAG_Cons: {
        V v_x_24114 = heff_field(v_x2_24113, 0);
        V v_xs_24115 = heff_field(v_x2_24113, 1);
        heff_take_n(v_x2_24113, 3ULL, 2);
        v_t_24116 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str98); V a_1 = v_x_24114; V a_2 = v_xs_24115; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24115); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24113);
      }
      V v_t_24117 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str99), heff_strAppend(v_t_24116, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str100)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str101), v_t_24117);
    }
    case TAG_ELam: {
      V v_b_24118 = heff_field(v_x21_242, 0);
      V v_body_24119 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24120 = (g_heff_2esyntax_2eformat_2elamKey(heff_dup(v_r_240), v_b_24118));
      V v_t_24121 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_24119}));
      V v_t_24122 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
      V v_parts_24123 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_Cons, 2, (V[]){v_t_24120, v_t_24122});
      V v_x2_24124 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str102), v_parts_24123));
      V v_t_24127;
      switch (heff_tag_of(v_x2_24124)) {
      case TAG_Nil: {
        v_t_24127 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str103);
        break;
      }
      case TAG_Cons: {
        V v_x_24125 = heff_field(v_x2_24124, 0);
        V v_xs_24126 = heff_field(v_x2_24124, 1);
        heff_take_n(v_x2_24124, 3ULL, 2);
        v_t_24127 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str104); V a_1 = v_x_24125; V a_2 = v_xs_24126; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24126); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24124);
      }
      V v_t_24128 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str105), heff_strAppend(v_t_24127, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str106)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str107), v_t_24128);
    }
    case TAG_EAnn: {
      V v_e_24129 = heff_field(v_x21_242, 0);
      V v_t_24130 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24131 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24129}));
      V v_t_24132 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24130}));
      V v_t_24133 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
      V v_parts_24134 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_Cons, 2, (V[]){v_t_24131, v_t_24133});
      V v_x2_24135 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str108), v_parts_24134));
      V v_t_24138;
      switch (heff_tag_of(v_x2_24135)) {
      case TAG_Nil: {
        v_t_24138 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str109);
        break;
      }
      case TAG_Cons: {
        V v_x_24136 = heff_field(v_x2_24135, 0);
        V v_xs_24137 = heff_field(v_x2_24135, 1);
        heff_take_n(v_x2_24135, 3ULL, 2);
        v_t_24138 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str110); V a_1 = v_x_24136; V a_2 = v_xs_24137; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24137); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24135);
      }
      V v_t_24139 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str111), heff_strAppend(v_t_24138, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str112)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str113), v_t_24139);
    }
    case TAG_ESpec: {
      V v_acc_24140 = heff_field(v_x21_242, 0);
      V v_x_24141 = heff_field(v_x21_242, 1);
      V v_v_24143 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24144 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_acc_24140}));
      V v_t_24145 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24143}));
      V v_t_24146 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24145, NTAG(TAG_Nil)});
      V v_parts_24147 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24144, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24141, v_t_24146})});
      V v_x2_24148 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str114), v_parts_24147));
      V v_t_24151;
      switch (heff_tag_of(v_x2_24148)) {
      case TAG_Nil: {
        v_t_24151 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str115);
        break;
      }
      case TAG_Cons: {
        V v_x_24149 = heff_field(v_x2_24148, 0);
        V v_xs_24150 = heff_field(v_x2_24148, 1);
        heff_take_n(v_x2_24148, 3ULL, 2);
        v_t_24151 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str116); V a_1 = v_x_24149; V a_2 = v_xs_24150; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24150); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24148);
      }
      V v_t_24152 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str117), heff_strAppend(v_t_24151, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str118)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str119), v_t_24152);
    }
    case TAG_ESig: {
      V v_fs_24153 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24154 = (g_list_2emap_24s135291903x1031656159(v_r_240, v_fs_24153));
      V v_t_24157;
      switch (heff_tag_of(v_x2_24154)) {
      case TAG_Nil: {
        v_t_24157 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str120);
        break;
      }
      case TAG_Cons: {
        V v_x_24155 = heff_field(v_x2_24154, 0);
        V v_xs_24156 = heff_field(v_x2_24154, 1);
        heff_take_n(v_x2_24154, 3ULL, 2);
        v_t_24157 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str121); V a_1 = v_x_24155; V a_2 = v_xs_24156; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24156); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24154);
      }
      V v_t_24158 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str122), heff_strAppend(v_t_24157, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str123)));
      V v_parts_24159 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24158, NTAG(TAG_Nil)});
      V v_x2_24160 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str124), v_parts_24159));
      V v_t_24163;
      switch (heff_tag_of(v_x2_24160)) {
      case TAG_Nil: {
        v_t_24163 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str125);
        break;
      }
      case TAG_Cons: {
        V v_x_24161 = heff_field(v_x2_24160, 0);
        V v_xs_24162 = heff_field(v_x2_24160, 1);
        heff_take_n(v_x2_24160, 3ULL, 2);
        v_t_24163 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str126); V a_1 = v_x_24161; V a_2 = v_xs_24162; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24162); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24160);
      }
      V v_t_24164 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str127), heff_strAppend(v_t_24163, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str128)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str129), v_t_24164);
    }
    case TAG_ESum: {
      V v_vs_24165 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24166 = (g_list_2emap_24s354283597x484250159(v_r_240, v_vs_24165));
      V v_t_24169;
      switch (heff_tag_of(v_x2_24166)) {
      case TAG_Nil: {
        v_t_24169 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str130);
        break;
      }
      case TAG_Cons: {
        V v_x_24167 = heff_field(v_x2_24166, 0);
        V v_xs_24168 = heff_field(v_x2_24166, 1);
        heff_take_n(v_x2_24166, 3ULL, 2);
        v_t_24169 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str131); V a_1 = v_x_24167; V a_2 = v_xs_24168; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24168); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24166);
      }
      V v_t_24170 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str132), heff_strAppend(v_t_24169, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str133)));
      V v_parts_24171 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24170, NTAG(TAG_Nil)});
      V v_x2_24172 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str134), v_parts_24171));
      V v_t_24175;
      switch (heff_tag_of(v_x2_24172)) {
      case TAG_Nil: {
        v_t_24175 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str135);
        break;
      }
      case TAG_Cons: {
        V v_x_24173 = heff_field(v_x2_24172, 0);
        V v_xs_24174 = heff_field(v_x2_24172, 1);
        heff_take_n(v_x2_24172, 3ULL, 2);
        v_t_24175 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str136); V a_1 = v_x_24173; V a_2 = v_xs_24174; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24174); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24172);
      }
      V v_t_24176 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str137), heff_strAppend(v_t_24175, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str138)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str139), v_t_24176);
    }
    case TAG_EStruct: {
      V v_fs_24177 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24178 = (g_list_2emap_24s1099021180x1702355548(v_r_240, v_fs_24177));
      V v_t_24181;
      switch (heff_tag_of(v_x2_24178)) {
      case TAG_Nil: {
        v_t_24181 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str140);
        break;
      }
      case TAG_Cons: {
        V v_x_24179 = heff_field(v_x2_24178, 0);
        V v_xs_24180 = heff_field(v_x2_24178, 1);
        heff_take_n(v_x2_24178, 3ULL, 2);
        v_t_24181 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str141); V a_1 = v_x_24179; V a_2 = v_xs_24180; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24180); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24178);
      }
      V v_t_24182 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str142), heff_strAppend(v_t_24181, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str143)));
      V v_parts_24183 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24182, NTAG(TAG_Nil)});
      V v_x2_24184 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str144), v_parts_24183));
      V v_t_24187;
      switch (heff_tag_of(v_x2_24184)) {
      case TAG_Nil: {
        v_t_24187 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str145);
        break;
      }
      case TAG_Cons: {
        V v_x_24185 = heff_field(v_x2_24184, 0);
        V v_xs_24186 = heff_field(v_x2_24184, 1);
        heff_take_n(v_x2_24184, 3ULL, 2);
        v_t_24187 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str146); V a_1 = v_x_24185; V a_2 = v_xs_24186; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24186); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24184);
      }
      V v_t_24188 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str147), heff_strAppend(v_t_24187, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str148)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str149), v_t_24188);
    }
    case TAG_EUpdate: {
      V v_a_24189 = heff_field(v_x21_242, 0);
      V v_fs_24190 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24191 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24189}));
      V v_x2_24192 = (g_list_2emap_24s510830240x893896831(v_r_240, v_fs_24190));
      V v_t_24195;
      switch (heff_tag_of(v_x2_24192)) {
      case TAG_Nil: {
        v_t_24195 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str150);
        break;
      }
      case TAG_Cons: {
        V v_x_24193 = heff_field(v_x2_24192, 0);
        V v_xs_24194 = heff_field(v_x2_24192, 1);
        heff_take_n(v_x2_24192, 3ULL, 2);
        v_t_24195 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str151); V a_1 = v_x_24193; V a_2 = v_xs_24194; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24194); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24192);
      }
      V v_t_24196 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str152), heff_strAppend(v_t_24195, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str153)));
      V v_t_24197 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24196, NTAG(TAG_Nil)});
      V v_parts_24198 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_Cons, 2, (V[]){v_t_24191, v_t_24197});
      V v_x2_24199 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str154), v_parts_24198));
      V v_t_24202;
      switch (heff_tag_of(v_x2_24199)) {
      case TAG_Nil: {
        v_t_24202 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str155);
        break;
      }
      case TAG_Cons: {
        V v_x_24200 = heff_field(v_x2_24199, 0);
        V v_xs_24201 = heff_field(v_x2_24199, 1);
        heff_take_n(v_x2_24199, 3ULL, 2);
        v_t_24202 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str156); V a_1 = v_x_24200; V a_2 = v_xs_24201; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24201); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24199);
      }
      V v_t_24203 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str157), heff_strAppend(v_t_24202, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str158)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str159), v_t_24203);
    }
    case TAG_EMatch: {
      V v_s_24204 = heff_field(v_x21_242, 0);
      V v_alts_24205 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24206 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24204}));
      V v_x2_24207 = (g_list_2emap_24s1152414072x2935301(v_r_240, v_alts_24205));
      V v_t_24210;
      switch (heff_tag_of(v_x2_24207)) {
      case TAG_Nil: {
        v_t_24210 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str160);
        break;
      }
      case TAG_Cons: {
        V v_x_24208 = heff_field(v_x2_24207, 0);
        V v_xs_24209 = heff_field(v_x2_24207, 1);
        heff_take_n(v_x2_24207, 3ULL, 2);
        v_t_24210 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str161); V a_1 = v_x_24208; V a_2 = v_xs_24209; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24209); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24207);
      }
      V v_t_24211 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str162), heff_strAppend(v_t_24210, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str163)));
      V v_t_24212 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24211, NTAG(TAG_Nil)});
      V v_parts_24213 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_Cons, 2, (V[]){v_t_24206, v_t_24212});
      V v_x2_24214 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str164), v_parts_24213));
      V v_t_24217;
      switch (heff_tag_of(v_x2_24214)) {
      case TAG_Nil: {
        v_t_24217 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str165);
        break;
      }
      case TAG_Cons: {
        V v_x_24215 = heff_field(v_x2_24214, 0);
        V v_xs_24216 = heff_field(v_x2_24214, 1);
        heff_take_n(v_x2_24214, 3ULL, 2);
        v_t_24217 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str166); V a_1 = v_x_24215; V a_2 = v_xs_24216; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24216); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24214);
      }
      V v_t_24218 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str167), heff_strAppend(v_t_24217, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str168)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str169), v_t_24218);
    }
    case TAG_ELetIn: {
      V v_rhs_24219 = heff_field(v_x21_242, 0);
      V v_x212_24220 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x212_24220)) {
      case TAG_At: {
        V v_x2121_24221 = heff_field(v_x212_24220, 0);
        heff_take_n(v_x212_24220, 1ULL, 2);
        switch (heff_tag_of(v_x2121_24221)) {
        case TAG_MkAlt: {
          V v_p_24223 = heff_field(v_x2121_24221, 0);
          V v_e_24224 = heff_field(v_x2121_24221, 1);
          heff_take_n(v_x2121_24221, 3ULL, 2);
          V v_t_24225 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24219}));
          V v_t_24226 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24223));
          V v_t_24227 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24224}));
          V v_t_24228 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24227, NTAG(TAG_Nil)});
          V v_parts_24229 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_Cons, 2, (V[]){v_t_24225, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24226, v_t_24228})});
          V v_x2_24230 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str170), v_parts_24229));
          V v_t_24233;
          switch (heff_tag_of(v_x2_24230)) {
          case TAG_Nil: {
            v_t_24233 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str171);
            break;
          }
          case TAG_Cons: {
            V v_x_24231 = heff_field(v_x2_24230, 0);
            V v_xs_24232 = heff_field(v_x2_24230, 1);
            heff_take_n(v_x2_24230, 3ULL, 2);
            v_t_24233 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str172); V a_1 = v_x_24231; V a_2 = v_xs_24232; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24232); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24230);
          }
          V v_t_24234 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str173), heff_strAppend(v_t_24233, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str174)));
          return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str175), v_t_24234);
        }
        default: return heff_nomatch(v_x2121_24221);
        }
      }
      default: return heff_nomatch(v_x212_24220);
      }
    }
    case TAG_EDo: {
      V v_stmts_24235 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24236 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24237 = (g_list_2emap(v_t_24236, v_stmts_24235));
      V v_t_24240;
      switch (heff_tag_of(v_x2_24237)) {
      case TAG_Nil: {
        v_t_24240 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str176);
        break;
      }
      case TAG_Cons: {
        V v_x_24238 = heff_field(v_x2_24237, 0);
        V v_xs_24239 = heff_field(v_x2_24237, 1);
        heff_take_n(v_x2_24237, 3ULL, 2);
        v_t_24240 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str177); V a_1 = v_x_24238; V a_2 = v_xs_24239; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24239); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24237);
      }
      V v_t_24241 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str178), heff_strAppend(v_t_24240, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str179)));
      V v_parts_24242 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24241, NTAG(TAG_Nil)});
      V v_x2_24243 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str180), v_parts_24242));
      V v_t_24246;
      switch (heff_tag_of(v_x2_24243)) {
      case TAG_Nil: {
        v_t_24246 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str181);
        break;
      }
      case TAG_Cons: {
        V v_x_24244 = heff_field(v_x2_24243, 0);
        V v_xs_24245 = heff_field(v_x2_24243, 1);
        heff_take_n(v_x2_24243, 3ULL, 2);
        v_t_24246 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str182); V a_1 = v_x_24244; V a_2 = v_xs_24245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24245); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24243);
      }
      V v_t_24247 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str183), heff_strAppend(v_t_24246, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str184)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str185), v_t_24247);
    }
    case TAG_ELocal: {
      V v_body_24248 = heff_field(v_x21_242, 0);
      V v_ds_24249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24250 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24248}));
      V v_x2_24251 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24249));
      V v_t_24254;
      switch (heff_tag_of(v_x2_24251)) {
      case TAG_Nil: {
        v_t_24254 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str186);
        break;
      }
      case TAG_Cons: {
        V v_x_24252 = heff_field(v_x2_24251, 0);
        V v_xs_24253 = heff_field(v_x2_24251, 1);
        heff_take_n(v_x2_24251, 3ULL, 2);
        v_t_24254 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str187); V a_1 = v_x_24252; V a_2 = v_xs_24253; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24253); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24251);
      }
      V v_t_24255 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str188), heff_strAppend(v_t_24254, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str189)));
      V v_t_24256 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24255, NTAG(TAG_Nil)});
      V v_parts_24257 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_Cons, 2, (V[]){v_t_24250, v_t_24256});
      V v_x2_24258 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str190), v_parts_24257));
      V v_t_24261;
      switch (heff_tag_of(v_x2_24258)) {
      case TAG_Nil: {
        v_t_24261 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str191);
        break;
      }
      case TAG_Cons: {
        V v_x_24259 = heff_field(v_x2_24258, 0);
        V v_xs_24260 = heff_field(v_x2_24258, 1);
        heff_take_n(v_x2_24258, 3ULL, 2);
        v_t_24261 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str192); V a_1 = v_x_24259; V a_2 = v_xs_24260; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24260); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24258);
      }
      V v_t_24262 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str193), heff_strAppend(v_t_24261, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str194)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str195), v_t_24262);
    }
    case TAG_EInvalid: {
      V v_why_24263 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24264 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_why_24263, NTAG(TAG_Nil)});
      V v_x2_24265 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str196), v_t_24264));
      V v_t_24268;
      switch (heff_tag_of(v_x2_24265)) {
      case TAG_Nil: {
        v_t_24268 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str197);
        break;
      }
      case TAG_Cons: {
        V v_x_24266 = heff_field(v_x2_24265, 0);
        V v_xs_24267 = heff_field(v_x2_24265, 1);
        heff_take_n(v_x2_24265, 3ULL, 2);
        v_t_24268 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str198); V a_1 = v_x_24266; V a_2 = v_xs_24267; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24267); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24265);
      }
      V v_t_24269 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str199), heff_strAppend(v_t_24268, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str200)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str201), v_t_24269);
    }
    case TAG_EAssign: {
      V v_x_24270 = heff_field(v_x21_242, 0);
      V v_e_24272 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_24273 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24272}));
      V v_t_24274 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24273, NTAG(TAG_Nil)});
      V v_parts_24275 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24270, v_t_24274});
      V v_x2_24276 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str202), v_parts_24275));
      V v_t_24279;
      switch (heff_tag_of(v_x2_24276)) {
      case TAG_Nil: {
        v_t_24279 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str203);
        break;
      }
      case TAG_Cons: {
        V v_x_24277 = heff_field(v_x2_24276, 0);
        V v_xs_24278 = heff_field(v_x2_24276, 1);
        heff_take_n(v_x2_24276, 3ULL, 2);
        v_t_24279 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str204); V a_1 = v_x_24277; V a_2 = v_xs_24278; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24278); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24276);
      }
      V v_t_24280 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str205), heff_strAppend(v_t_24279, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str206)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str207), v_t_24280);
    }
    case TAG_EWhile: {
      V v_c_24281 = heff_field(v_x21_242, 0);
      V v_body_24282 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EWhile = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24283 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24281}));
      V v_t_24284 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24285 = (g_list_2emap(v_t_24284, v_body_24282));
      V v_t_24288;
      switch (heff_tag_of(v_x2_24285)) {
      case TAG_Nil: {
        v_t_24288 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str208);
        break;
      }
      case TAG_Cons: {
        V v_x_24286 = heff_field(v_x2_24285, 0);
        V v_xs_24287 = heff_field(v_x2_24285, 1);
        heff_take_n(v_x2_24285, 3ULL, 2);
        v_t_24288 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str209); V a_1 = v_x_24286; V a_2 = v_xs_24287; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24287); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24285);
      }
      V v_t_24289 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str210), heff_strAppend(v_t_24288, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str211)));
      V v_t_24290 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24289, NTAG(TAG_Nil)});
      V v_parts_24291 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_Cons, 2, (V[]){v_t_24283, v_t_24290});
      V v_x2_24292 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str212), v_parts_24291));
      V v_t_24295;
      switch (heff_tag_of(v_x2_24292)) {
      case TAG_Nil: {
        v_t_24295 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str213);
        break;
      }
      case TAG_Cons: {
        V v_x_24293 = heff_field(v_x2_24292, 0);
        V v_xs_24294 = heff_field(v_x2_24292, 1);
        heff_take_n(v_x2_24292, 3ULL, 2);
        v_t_24295 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str214); V a_1 = v_x_24293; V a_2 = v_xs_24294; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24294); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24292);
      }
      V v_t_24296 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str215), heff_strAppend(v_t_24295, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str216)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str217), v_t_24296);
    }
    case TAG_EFor: {
      V v_p_24297 = heff_field(v_x21_242, 0);
      V v_c_24298 = heff_field(v_x21_242, 1);
      V v_body_24299 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_24300 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24297));
      V v_t_24301 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24298}));
      V v_t_24302 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24303 = (g_list_2emap(v_t_24302, v_body_24299));
      V v_t_24306;
      switch (heff_tag_of(v_x2_24303)) {
      case TAG_Nil: {
        v_t_24306 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str218);
        break;
      }
      case TAG_Cons: {
        V v_x_24304 = heff_field(v_x2_24303, 0);
        V v_xs_24305 = heff_field(v_x2_24303, 1);
        heff_take_n(v_x2_24303, 3ULL, 2);
        v_t_24306 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str219); V a_1 = v_x_24304; V a_2 = v_xs_24305; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24305); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24303);
      }
      V v_t_24307 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str220), heff_strAppend(v_t_24306, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str221)));
      V v_t_24308 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24307, NTAG(TAG_Nil)});
      V v_parts_24309 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24300, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24301, v_t_24308})});
      V v_x2_24310 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str222), v_parts_24309));
      V v_t_24313;
      switch (heff_tag_of(v_x2_24310)) {
      case TAG_Nil: {
        v_t_24313 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str223);
        break;
      }
      case TAG_Cons: {
        V v_x_24311 = heff_field(v_x2_24310, 0);
        V v_xs_24312 = heff_field(v_x2_24310, 1);
        heff_take_n(v_x2_24310, 3ULL, 2);
        v_t_24313 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str224); V a_1 = v_x_24311; V a_2 = v_xs_24312; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24312); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24310);
      }
      V v_t_24314 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str225), heff_strAppend(v_t_24313, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str226)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str227), v_t_24314);
    }
    case TAG_EIfThen: {
      V v_c_24315 = heff_field(v_x21_242, 0);
      V v_a_24316 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EIfThen = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24317 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24315}));
      V v_t_24318 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_24316}));
      V v_t_24319 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24318, NTAG(TAG_Nil)});
      V v_parts_24320 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_Cons, 2, (V[]){v_t_24317, v_t_24319});
      V v_x2_24321 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str228), v_parts_24320));
      V v_t_24324;
      switch (heff_tag_of(v_x2_24321)) {
      case TAG_Nil: {
        v_t_24324 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str229);
        break;
      }
      case TAG_Cons: {
        V v_x_24322 = heff_field(v_x2_24321, 0);
        V v_xs_24323 = heff_field(v_x2_24321, 1);
        heff_take_n(v_x2_24321, 3ULL, 2);
        v_t_24324 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str230); V a_1 = v_x_24322; V a_2 = v_xs_24323; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24323); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24321);
      }
      V v_t_24325 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str231), heff_strAppend(v_t_24324, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str232)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str233), v_t_24325);
    }
    case TAG_EBreak: {
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_x2_24326 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str234), NTAG(TAG_Nil)));
      V v_t_24329;
      switch (heff_tag_of(v_x2_24326)) {
      case TAG_Nil: {
        v_t_24329 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str235);
        break;
      }
      case TAG_Cons: {
        V v_x_24327 = heff_field(v_x2_24326, 0);
        V v_xs_24328 = heff_field(v_x2_24326, 1);
        heff_take_n(v_x2_24326, 3ULL, 2);
        v_t_24329 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str236); V a_1 = v_x_24327; V a_2 = v_xs_24328; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24328); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24326);
      }
      V v_t_24330 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str237), heff_strAppend(v_t_24329, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str238)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str239), v_t_24330);
    }
    case TAG_EContinue: {
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_x2_24331 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str240), NTAG(TAG_Nil)));
      V v_t_24334;
      switch (heff_tag_of(v_x2_24331)) {
      case TAG_Nil: {
        v_t_24334 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str241);
        break;
      }
      case TAG_Cons: {
        V v_x_24332 = heff_field(v_x2_24331, 0);
        V v_xs_24333 = heff_field(v_x2_24331, 1);
        heff_take_n(v_x2_24331, 3ULL, 2);
        v_t_24334 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str242); V a_1 = v_x_24332; V a_2 = v_xs_24333; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24333); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24331);
      }
      V v_t_24335 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str243), heff_strAppend(v_t_24334, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str244)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str245), v_t_24335);
    }
    case TAG_EReturn: {
      V v_e_24336 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24337 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24336}));
      V v_parts_24338 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24337, NTAG(TAG_Nil)});
      V v_x2_24339 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str246), v_parts_24338));
      V v_t_24342;
      switch (heff_tag_of(v_x2_24339)) {
      case TAG_Nil: {
        v_t_24342 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str247);
        break;
      }
      case TAG_Cons: {
        V v_x_24340 = heff_field(v_x2_24339, 0);
        V v_xs_24341 = heff_field(v_x2_24339, 1);
        heff_take_n(v_x2_24339, 3ULL, 2);
        v_t_24342 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str248); V a_1 = v_x_24340; V a_2 = v_xs_24341; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24341); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24339);
      }
      V v_t_24343 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str249), heff_strAppend(v_t_24342, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str250)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str251), v_t_24343);
    }
    case TAG_ENest: {
      V v_e_24344 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24345 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24344}));
      V v_parts_24346 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24345, NTAG(TAG_Nil)});
      V v_x2_24347 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str252), v_parts_24346));
      V v_t_24350;
      switch (heff_tag_of(v_x2_24347)) {
      case TAG_Nil: {
        v_t_24350 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str253);
        break;
      }
      case TAG_Cons: {
        V v_x_24348 = heff_field(v_x2_24347, 0);
        V v_xs_24349 = heff_field(v_x2_24347, 1);
        heff_take_n(v_x2_24347, 3ULL, 2);
        v_t_24350 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str254); V a_1 = v_x_24348; V a_2 = v_xs_24349; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24349); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24347);
      }
      V v_t_24351 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str255), heff_strAppend(v_t_24350, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str256)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str257), v_t_24351);
    }
    case TAG_ELazy: {
      V v_e_24352 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24353 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24352}));
      V v_parts_24354 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24353, NTAG(TAG_Nil)});
      V v_x2_24355 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str258), v_parts_24354));
      V v_t_24358;
      switch (heff_tag_of(v_x2_24355)) {
      case TAG_Nil: {
        v_t_24358 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str259);
        break;
      }
      case TAG_Cons: {
        V v_x_24356 = heff_field(v_x2_24355, 0);
        V v_xs_24357 = heff_field(v_x2_24355, 1);
        heff_take_n(v_x2_24355, 3ULL, 2);
        v_t_24358 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str260); V a_1 = v_x_24356; V a_2 = v_xs_24357; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24357); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24355);
      }
      V v_t_24359 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str261), heff_strAppend(v_t_24358, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str262)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str263), v_t_24359);
    }
    case TAG_ETuple: {
      V v_es_24360 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24361 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_es_24360));
      V v_t_24364;
      switch (heff_tag_of(v_x2_24361)) {
      case TAG_Nil: {
        v_t_24364 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str264);
        break;
      }
      case TAG_Cons: {
        V v_x_24362 = heff_field(v_x2_24361, 0);
        V v_xs_24363 = heff_field(v_x2_24361, 1);
        heff_take_n(v_x2_24361, 3ULL, 2);
        v_t_24364 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str265); V a_1 = v_x_24362; V a_2 = v_xs_24363; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24363); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24361);
      }
      V v_t_24365 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str266), heff_strAppend(v_t_24364, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str267)));
      V v_parts_24366 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24365, NTAG(TAG_Nil)});
      V v_x2_24367 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str268), v_parts_24366));
      V v_t_24370;
      switch (heff_tag_of(v_x2_24367)) {
      case TAG_Nil: {
        v_t_24370 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str269);
        break;
      }
      case TAG_Cons: {
        V v_x_24368 = heff_field(v_x2_24367, 0);
        V v_xs_24369 = heff_field(v_x2_24367, 1);
        heff_take_n(v_x2_24367, 3ULL, 2);
        v_t_24370 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str270); V a_1 = v_x_24368; V a_2 = v_xs_24369; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24369); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24367);
      }
      V v_t_24371 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str271), heff_strAppend(v_t_24370, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str272)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str273), v_t_24371);
    }
    case TAG_ETry: {
      V v_x211_24372 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_24372)) {
      case TAG_MkTry: {
        V v_ty_24373 = heff_field(v_x211_24372, 0);
        V v_body_24374 = heff_field(v_x211_24372, 1);
        V v_c_24375 = heff_field(v_x211_24372, 2);
        heff_take_n(v_x211_24372, 7ULL, 3);
        V v_t_24377;
        switch (heff_tag_of(v_ty_24373)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_24377 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_24376 = heff_field(v_ty_24373, 0);
          heff_take_n(v_ty_24373, 1ULL, 1);
          v_t_24377 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_24376, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_ty_24373);
        }
        V v_x2_24378 = (g_list_2emap(heff_dup(heff_rfield(v_r_240, 0)), v_t_24377));
        V v_t_24381;
        switch (heff_tag_of(v_x2_24378)) {
        case TAG_Nil: {
          v_t_24381 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str274);
          break;
        }
        case TAG_Cons: {
          V v_x_24379 = heff_field(v_x2_24378, 0);
          V v_xs_24380 = heff_field(v_x2_24378, 1);
          heff_take_n(v_x2_24378, 3ULL, 2);
          v_t_24381 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str275); V a_1 = v_x_24379; V a_2 = v_xs_24380; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24380); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24378);
        }
        V v_t_24382 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str276), heff_strAppend(v_t_24381, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str277)));
        V v_t_24383 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){heff_dup(v_r_240)}));
        V v_x2_24384 = (g_list_2emap(v_t_24383, v_body_24374));
        V v_t_24387;
        switch (heff_tag_of(v_x2_24384)) {
        case TAG_Nil: {
          v_t_24387 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str278);
          break;
        }
        case TAG_Cons: {
          V v_x_24385 = heff_field(v_x2_24384, 0);
          V v_xs_24386 = heff_field(v_x2_24384, 1);
          heff_take_n(v_x2_24384, 3ULL, 2);
          v_t_24387 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str279); V a_1 = v_x_24385; V a_2 = v_xs_24386; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24386); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24384);
        }
        V v_t_24388 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str280), heff_strAppend(v_t_24387, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str281)));
        V v_t_24389 = (g_heff_2esyntax_2eformat_2ecatchKey(v_r_240, v_c_24375));
        V v_t_24390 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24389, NTAG(TAG_Nil)});
        V v_parts_24391 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24382, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24388, v_t_24390})});
        V v_x2_24392 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str282), v_parts_24391));
        V v_t_24395;
        switch (heff_tag_of(v_x2_24392)) {
        case TAG_Nil: {
          v_t_24395 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str283);
          break;
        }
        case TAG_Cons: {
          V v_x_24393 = heff_field(v_x2_24392, 0);
          V v_xs_24394 = heff_field(v_x2_24392, 1);
          heff_take_n(v_x2_24392, 3ULL, 2);
          v_t_24395 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str284); V a_1 = v_x_24393; V a_2 = v_xs_24394; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24394); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24392);
        }
        V v_t_24396 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str285), heff_strAppend(v_t_24395, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str286)));
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str287), v_t_24396);
      }
      default: return heff_nomatch(v_x211_24372);
      }
    }
    case TAG_EWith: {
      V v_w_24397 = heff_field(v_x21_242, 0);
      V v_x_24398 = heff_field(v_x21_242, 1);
      V v_body_24400 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24401 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_w_24397}));
      V v_t_24402 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24403 = (g_list_2emap(v_t_24402, v_body_24400));
      V v_t_24406;
      switch (heff_tag_of(v_x2_24403)) {
      case TAG_Nil: {
        v_t_24406 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str288);
        break;
      }
      case TAG_Cons: {
        V v_x_24404 = heff_field(v_x2_24403, 0);
        V v_xs_24405 = heff_field(v_x2_24403, 1);
        heff_take_n(v_x2_24403, 3ULL, 2);
        v_t_24406 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str289); V a_1 = v_x_24404; V a_2 = v_xs_24405; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24405); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24403);
      }
      V v_t_24407 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str290), heff_strAppend(v_t_24406, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str291)));
      V v_t_24408 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24407, NTAG(TAG_Nil)});
      V v_parts_24409 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24401, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24398, v_t_24408})});
      V v_x2_24410 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str292), v_parts_24409));
      V v_t_24413;
      switch (heff_tag_of(v_x2_24410)) {
      case TAG_Nil: {
        v_t_24413 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str293);
        break;
      }
      case TAG_Cons: {
        V v_x_24411 = heff_field(v_x2_24410, 0);
        V v_xs_24412 = heff_field(v_x2_24410, 1);
        heff_take_n(v_x2_24410, 3ULL, 2);
        v_t_24413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str294); V a_1 = v_x_24411; V a_2 = v_xs_24412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24410);
      }
      V v_t_24414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str295), heff_strAppend(v_t_24413, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str296)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str297), v_t_24414);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyTermF(a[0], a[1]);
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args) {
  V v_m_2447 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2eformat_2esegmentKey(heff_get_n(v_r_240, 0, 2), v_m_2447));
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str0, 10, "definition");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str4, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str5, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str9, 9, "equations");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str19, 6, "define");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str21, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str23, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str24, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str25, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str29, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str34, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str35, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str37, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str41, 4, "test");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str42, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str43, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str45, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str46, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str47, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str48, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str49, 1, "(");
Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_t_249;
      switch (heff_tag_of(v_declared_246)) {
      case TAG_AsDefinition: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_AsInstance: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str1);
        break;
      }
      default: heff_nomatch(v_declared_246);
      }
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_x2_2411 = (g_list_2emap_24s1055307687x247454614(v_r_240, v_eqs_248));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_xs_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str4), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str5)));
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2416})});
      V v_parts_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_244, v_t_2417});
      V v_x2_2419 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str6), v_parts_2418));
      V v_t_2422;
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nil: {
        v_t_2422 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_xs_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        v_t_2422 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str8); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2419);
      }
      V v_t_2423 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str9), heff_strAppend(v_t_2422, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str11), v_t_2423);
    }
    case TAG_DeclDefine: {
      V v_x_2424 = heff_field(v_x21_242, 0);
      V v_ps_2426 = heff_field(v_x21_242, 2);
      V v_u_2427 = heff_field(v_x21_242, 3);
      V v_body_2428 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_x2_2429 = (g_list_2emap_24s228910449x1110031924(heff_dup(v_r_240), v_ps_2426));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str13); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str14), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str15)));
      V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2427}));
      V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2428}));
      V v_t_2436 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
      V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, v_t_2436})});
      V v_parts_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, v_t_2437});
      V v_x2_2439 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str16), v_parts_2438));
      V v_t_2442;
      switch (heff_tag_of(v_x2_2439)) {
      case TAG_Nil: {
        v_t_2442 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str17);
        break;
      }
      case TAG_Cons: {
        V v_x_2440 = heff_field(v_x2_2439, 0);
        V v_xs_2441 = heff_field(v_x2_2439, 1);
        heff_take_n(v_x2_2439, 3ULL, 2);
        v_t_2442 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str18); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2439);
      }
      V v_t_2443 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str19), heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str20)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str21), v_t_2443);
    }
    case TAG_DeclTheory: {
      V v_x_2444 = heff_field(v_x21_242, 0);
      V v_ps_2446 = heff_field(v_x21_242, 2);
      V v_body_2447 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_x2_2448 = (g_list_2emap_24s228910449x1110031924(heff_dup(v_r_240), v_ps_2446));
      V v_t_2451;
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_Nil: {
        v_t_2451 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str22);
        break;
      }
      case TAG_Cons: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        V v_xs_2450 = heff_field(v_x2_2448, 1);
        heff_take_n(v_x2_2448, 3ULL, 2);
        v_t_2451 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str23); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2448);
      }
      V v_t_2452 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str24), heff_strAppend(v_t_2451, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str25)));
      V v_t_2453 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2447}));
      V v_t_2454 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
      V v_parts_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2444, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, v_t_2454})});
      V v_x2_2456 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str26), v_parts_2455));
      V v_t_2459;
      switch (heff_tag_of(v_x2_2456)) {
      case TAG_Nil: {
        v_t_2459 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_2457 = heff_field(v_x2_2456, 0);
        V v_xs_2458 = heff_field(v_x2_2456, 1);
        heff_take_n(v_x2_2456, 3ULL, 2);
        v_t_2459 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str28); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2456);
      }
      V v_t_2460 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str29), heff_strAppend(v_t_2459, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str30)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str31), v_t_2460);
    }
    case TAG_DeclPrimitive: {
      V v_x_2461 = heff_field(v_x21_242, 0);
      V v_t_2463 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2463}));
      V v_t_2465 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
      V v_parts_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2461, v_t_2465});
      V v_x2_2467 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str32), v_parts_2466));
      V v_t_2470;
      switch (heff_tag_of(v_x2_2467)) {
      case TAG_Nil: {
        v_t_2470 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str33);
        break;
      }
      case TAG_Cons: {
        V v_x_2468 = heff_field(v_x2_2467, 0);
        V v_xs_2469 = heff_field(v_x2_2467, 1);
        heff_take_n(v_x2_2467, 3ULL, 2);
        v_t_2470 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str34); V a_1 = v_x_2468; V a_2 = v_xs_2469; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2469); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2467);
      }
      V v_t_2471 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str35), heff_strAppend(v_t_2470, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str36)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str37), v_t_2471);
    }
    case TAG_DeclTest: {
      V v_x_2472 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2474 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2472, NTAG(TAG_Nil)});
      V v_x2_2475 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str38), v_t_2474));
      V v_t_2478;
      switch (heff_tag_of(v_x2_2475)) {
      case TAG_Nil: {
        v_t_2478 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2476 = heff_field(v_x2_2475, 0);
        V v_xs_2477 = heff_field(v_x2_2475, 1);
        heff_take_n(v_x2_2475, 3ULL, 2);
        v_t_2478 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str40); V a_1 = v_x_2476; V a_2 = v_xs_2477; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2477); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2475);
      }
      V v_t_2479 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str41), heff_strAppend(v_t_2478, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str42)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str43), v_t_2479);
    }
    case TAG_DeclWatch: {
      V v_e_2480 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2481 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2480}));
      V v_parts_2482 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
      V v_x2_2483 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str44), v_parts_2482));
      V v_t_2486;
      switch (heff_tag_of(v_x2_2483)) {
      case TAG_Nil: {
        v_t_2486 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str45);
        break;
      }
      case TAG_Cons: {
        V v_x_2484 = heff_field(v_x2_2483, 0);
        V v_xs_2485 = heff_field(v_x2_2483, 1);
        heff_take_n(v_x2_2483, 3ULL, 2);
        v_t_2486 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str46); V a_1 = v_x_2484; V a_2 = v_xs_2485; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2485); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2483);
      }
      V v_t_2487 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str47), heff_strAppend(v_t_2486, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str48)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str49), v_t_2487);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningOf_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningOf_str1, 2, " (");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningOf_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningOf_str3, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningOf_str4, 4, "(..)");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningOf_str5, 0, "");
Clo g_heff_2esyntax_2eformat_2emeaningOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2emeaningOf_entry, 2, 0};

V g_heff_2esyntax_2eformat_2emeaningOf(V v_h_240, V v_r_241) {
top: ;
  V v_t_242 = heff_take_field(v_h_240, 2);
  V v_t_2411;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_h_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_244 = heff_take_field(v_h_243, 0);
    V v_t_246;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_246 = ((V)&g_heff_2esyntax_2eformat_2emeaningOf_str0);
      break;
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      v_t_246 = v_x_245;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_247 = heff_take_field(v_h_243, 1);
    V v_t_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = ((V)&g_heff_2esyntax_2eformat_2emeaningOf_str1);
    } else {
      heff_drop(v_t_247);
      v_t_248 = ((V)&g_heff_2esyntax_2eformat_2emeaningOf_str2);
    }
    V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2emeaningOf_str3), heff_strAppend(v_t_246, v_t_248));
    V v_t_2410 = (g_list_2emap_24s900318151x1569363206(((V)&g_heff_2esyntax_2eformat_2emeaningOf_str4), ((V)&g_heff_2esyntax_2eformat_2emeaningOf_str5), heff_get_n(v_h_243, 2, 5)));
    v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2410});
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_2412 = (g_list_2emap_24s1817208647x1282894070(heff_get_n(v_h_240, 0, 4)));
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
  V v_t_2414 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2eformat_2ekeys_get(), 1)), heff_take_field(v_r_241, 0)));
  V v_t_2415 = (g_list_2emap_24s179832492x431904054(heff_get_n(v_r_241, 1, 4)));
  return heff_rec_n(3, shape_imports__decls__diags, (V[]){v_t_2413, v_t_2414, v_t_2415});
}
V g_heff_2esyntax_2eformat_2emeaningOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2emeaningOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str1, 0, "");
Clo g_heff_2esyntax_2eformat_2emeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2emeaning_entry, 1, 0};

V g_heff_2esyntax_2eformat_2emeaning(V v_s_240) {
top: ;
  V v_h_241 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_s_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_text_242 = heff_dup(heff_rfield(v_h_241, 3));
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_text_242, v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_245 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str0); V a_1 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str1); V a_2 = v_text_242; V a_3 = v_t_244; V r_ = (g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(a_0, a_1, a_2, a_3)); heff_drop(v_text_242); r_; });
  return (g_heff_2esyntax_2eformat_2emeaningOf(v_h_241, v_t_245));
}
V g_heff_2esyntax_2eformat_2emeaning_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2emeaning(a[0]);
}

HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V v_f_240, V v_src_241) {
top: ;
  V v_claim_242 = (g_heff_2esyntax_2efmt_2eimports_2ereadImports(heff_dup(v_src_241)));
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_rfield(v_claim_242, 2), v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  HeffT2 v_t_245 = (g_heff_2esyntax_2efmt_2elayout_2efmtLexed_24cpr(v_f_240, heff_dup(v_src_241), v_claim_242, v_t_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_src_241);
      V v_why_249 = v_field_247;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_249}});
    } else {
      V v_out_2410 = v_field_247;
      V v_t_2411 = (g_heff_2esyntax_2eformat_2emeaning(heff_dup(v_src_241)));
      V v_t_2412 = (g_heff_2esyntax_2eformat_2emeaning(heff_dup(v_out_2410)));
      return (g_heff_2esyntax_2eformat_2esameMeaning_24cpr(v_src_241, v_out_2410, v_t_2411, v_t_2412));
    }
  }
}
Clo g_heff_2esyntax_2eformat_2eformatIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eformatIn_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eformatIn(V v_f_240, V v_src_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_f_240, v_src_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_244});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_244});
    }
  }
}
V g_heff_2esyntax_2eformat_2eformatIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eformatIn(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eformat_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_src_242 = heff_get_n(v_t_241, 3, 4);
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = ({ V a_0 = v_src_242; V a_1 = v_t_243; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_242); r_; });
  V v_ts_245 = heff_arrayFromList(heff_get_n(v_t_244, 0, 3));
  V v_t_246 = ({ V a_0 = v_ts_245; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ts_245); r_; });
  V v_t_247 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(((V)&g_heff_2esyntax_2eformat_2eformat_24cpr_str0), v_t_246));
  return (g_heff_2esyntax_2eformat_2eformatIn_24cpr(heff_get_n(v_t_247, 0, 2), v_src_240));
}