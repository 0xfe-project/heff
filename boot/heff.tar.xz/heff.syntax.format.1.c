// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntWord 51777
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Right 62770
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_blank 295177582
#define LBL_claim 296100950
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_digits 615232529
#define LBL_e 319
#define LBL_end 310101
#define LBL_env 310119
#define LBL_err 310239
#define LBL_error 298143266
#define LBL_exponent 966452320
#define LBL_exposes 1070285678
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_inline 763144644
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lead 9813027
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_listed 844633320
#define LBL_name 9869138
#define LBL_negative 1666250321
#define LBL_noLead 906256360
#define LBL_noTrail 184435464
#define LBL_offset 927361982
#define LBL_out 319944
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_raw 322210
#define LBL_span 10032145
#define LBL_src 323678
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_trail 311979552
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__decls__diags[] = {LBL_imports, LBL_decls, LBL_diags};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_kind__text__start__end__line__col__first[] = {LBL_kind, LBL_text, LBL_start, LBL_end, LBL_line, LBL_col, LBL_first};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_line__offset__out[] = {LBL_line, LBL_offset, LBL_out};
static uint32_t shape_src__lead__inline__trail__noLead__noTrail__fix[] = {LBL_src, LBL_lead, LBL_inline, LBL_trail, LBL_noLead, LBL_noTrail, LBL_fix};
static uint32_t shape_toks__env[] = {LBL_toks, LBL_env};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019(V, V, V, V, V);
V g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_entry(V self, V *a);
extern Clo g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019_clo;
HeffT2 g_heff_2esyntax_2ecst_2eprogramGo_24cpr(V, V);
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines(V);
V g_heff_2esyntax_2efmt_2elayout_2ekeptLines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ekeptLines_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etopLevelGo_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get(void);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2elamKey(V, V);
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2elamKey_clo;
V g_heff_2esyntax_2eformat_2emeaning(V);
V g_heff_2esyntax_2eformat_2emeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaning_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2epiKey(V, V);
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epiKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2esameMeaning_24cpr(V, V, V, V);
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2ereadRun(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadRun_clo;
V g_list_2eascending_24s1547370222x166817322(V, V, V);
V g_list_2eascending_24s1547370222x166817322_entry(V self, V *a);
extern Clo g_list_2eascending_24s1547370222x166817322_clo;
V g_list_2eascending_24s946492440x1788863194(V, V, V);
V g_list_2eascending_24s946492440x1788863194_entry(V self, V *a);
extern Clo g_list_2eascending_24s946492440x1788863194_clo;
V g_list_2edescending_24s1432586697x321478004(V, V, V);
V g_list_2edescending_24s1432586697x321478004_entry(V self, V *a);
extern Clo g_list_2edescending_24s1432586697x321478004_clo;
V g_list_2edescending_24s1706700342x2062518382(V, V, V);
V g_list_2edescending_24s1706700342x2062518382_entry(V self, V *a);
extern Clo g_list_2edescending_24s1706700342x2062518382_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1872971975x1696014049(V, V, V);
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1872971975x1696014049_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1055307687x247454614(V, V);
V g_list_2emap_24s1055307687x247454614_entry(V self, V *a);
extern Clo g_list_2emap_24s1055307687x247454614_clo;
V g_list_2emap_24s1099021180x1702355548(V, V);
V g_list_2emap_24s1099021180x1702355548_entry(V self, V *a);
extern Clo g_list_2emap_24s1099021180x1702355548_clo;
V g_list_2emap_24s1152414072x2935301(V, V);
V g_list_2emap_24s1152414072x2935301_entry(V self, V *a);
extern Clo g_list_2emap_24s1152414072x2935301_clo;
V g_list_2emap_24s135291903x1031656159(V, V);
V g_list_2emap_24s135291903x1031656159_entry(V self, V *a);
extern Clo g_list_2emap_24s135291903x1031656159_clo;
V g_list_2emap_24s1409451498x400757684(V);
V g_list_2emap_24s1409451498x400757684_entry(V self, V *a);
extern Clo g_list_2emap_24s1409451498x400757684_clo;
V g_list_2emap_24s179832492x431904054(V);
V g_list_2emap_24s179832492x431904054_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1845612977x612508518(V);
V g_list_2emap_24s1845612977x612508518_entry(V self, V *a);
extern Clo g_list_2emap_24s1845612977x612508518_clo;
V g_list_2emap_24s1975257801x764827799(V);
V g_list_2emap_24s1975257801x764827799_entry(V self, V *a);
extern Clo g_list_2emap_24s1975257801x764827799_clo;
V g_list_2emap_24s228910449x1110031924(V, V);
V g_list_2emap_24s228910449x1110031924_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s32026788x2029987799(V);
V g_list_2emap_24s32026788x2029987799_entry(V self, V *a);
extern Clo g_list_2emap_24s32026788x2029987799_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s354283597x484250159(V, V);
V g_list_2emap_24s354283597x484250159_entry(V self, V *a);
extern Clo g_list_2emap_24s354283597x484250159_clo;
V g_list_2emap_24s510830240x893896831(V, V);
V g_list_2emap_24s510830240x893896831_entry(V self, V *a);
extern Clo g_list_2emap_24s510830240x893896831_clo;
V g_list_2emap_24s725725455x1186198702(V);
V g_list_2emap_24s725725455x1186198702_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_clo;
V g_list_2emap_24s900318151x1569363206(V, V, V);
V g_list_2emap_24s900318151x1569363206_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s1839386886x1884977030(V, V);
V g_list_2emergeRuns_24s1839386886x1884977030_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1839386886x1884977030_clo;
V g_list_2emergeRuns_24s2052062657x972894659(V, V);
V g_list_2emergeRuns_24s2052062657x972894659_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s2052062657x972894659_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2edisplay_2edisplayInto_240(V, V);
V g_std_2edoc_2edisplay_2edisplayInto_240_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplay_2edisplayInto_240_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str3, 6, "(named");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str8, 9, "(implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str13, 9, "(implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str18, 9, "(instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str23, 5, "(anon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str24, 1, ")");
Clo g_heff_2esyntax_2eformat_2epiKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epiKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2epiKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_244)}));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_parts_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_t_246});
    V v_x2_248 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str0), v_parts_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str3), v_t_2411), ((V)&g_heff_2esyntax_2eformat_2epiKey_str4));
  }
  case TAG_PiImplicit: {
    V v_x_2412 = heff_field(v_x2_241, 0);
    V v_t_2415 = heff_field(v_x2_241, 3);
    V v_x25_2416 = heff_field(v_x2_241, 4);
    switch (heff_tag_of(v_x25_2416)) {
    case TAG_Nothing: {
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2415)}));
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str5), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str7); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str8), v_t_2423), ((V)&g_heff_2esyntax_2eformat_2epiKey_str9));
    }
    case TAG_Just: {
      V v_d_2424 = heff_field(v_x25_2416, 0);
      V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2415)}));
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_d_2424)}));
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
      V v_parts_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})});
      V v_x2_2429 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str10), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str12); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str13), v_t_2432), ((V)&g_heff_2esyntax_2eformat_2epiKey_str14));
    }
    default: return heff_nomatch(v_x25_2416);
    }
  }
  case TAG_PiInstance: {
    V v_x_2433 = heff_field(v_x2_241, 0);
    V v_t_2436 = heff_field(v_x2_241, 3);
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2436)}));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
    V v_parts_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2433), v_t_2438});
    V v_x2_2440 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str15), v_parts_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str17); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str18), v_t_2443), ((V)&g_heff_2esyntax_2eformat_2epiKey_str19));
  }
  case TAG_PiAnon: {
    V v_t_2444 = heff_field(v_x2_241, 0);
    V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2444)}));
    V v_parts_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    V v_x2_2447 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epiKey_str20), v_parts_2446));
    V v_t_2450;
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_Nil: {
      v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_xs_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      v_t_2450 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str22); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2447);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str23), v_t_2450), ((V)&g_heff_2esyntax_2eformat_2epiKey_str24));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2epiKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str0, 4, "(var");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str2, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str3, 9, "(implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str6, 9, "(notation");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str7, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str9, 4, "(tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str15, 4, "(int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str17, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str20, 6, "(float");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str22, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str23, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str25, 7, "(string");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str26, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str27, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str28, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str29, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str30, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str31, 3, "utf");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str32, 7, "default");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str33, 1, "*");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str34, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str35, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str36, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str37, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str41, 8, "(segment");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str42, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str43, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str44, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str45, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str46, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str47, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str48, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str49, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str50, 7, "(binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str51, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str53, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str54, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str55, 5, "(rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str56, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str57, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str58, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str59, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str60, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str61, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str62, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str63, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str64, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str65, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str66, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str67, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str68, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str69, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str70, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str71, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str72, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str73, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str74, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str75, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str76, 5, "(word");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str77, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str78, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str79, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str80, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str81, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str83, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str84, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str85, 4, "(app");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str86, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str87, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str88, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str89, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str90, 8, "(project");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str91, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str93, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str94, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str95, 6, "(named");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str96, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str97, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str98, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str99, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str100, 3, "(pi");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str101, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str102, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str103, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str104, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str105, 4, "(lam");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str106, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str107, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str108, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str109, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str110, 4, "(ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str111, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str112, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str113, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str114, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str115, 5, "(spec");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str116, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str117, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str118, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str119, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str120, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str121, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str122, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str123, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str124, 4, "(sig");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str125, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str126, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str127, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str128, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str129, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str131, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str132, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str133, 4, "(sum");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str134, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str135, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str136, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str137, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str138, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str139, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str140, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str141, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str142, 7, "(struct");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str143, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str144, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str145, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str146, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str147, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str148, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str149, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str150, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str151, 7, "(update");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str152, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str153, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str154, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str155, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str156, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str157, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str158, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str159, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str160, 6, "(match");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str161, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str162, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str163, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str164, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str165, 4, "(let");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str166, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str167, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str168, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str169, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str170, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str171, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str172, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str173, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str174, 3, "(do");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str175, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str176, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str177, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str178, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str179, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str180, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str181, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str182, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str183, 6, "(local");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str184, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str185, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str186, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str187, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str188, 8, "(invalid");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str189, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str190, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str191, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str192, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str193, 7, "(assign");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str194, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str195, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str196, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str197, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str198, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str199, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str200, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str201, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str202, 6, "(while");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str203, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str204, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str205, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str206, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str207, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str208, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str209, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str210, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str211, 4, "(for");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str212, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str213, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str214, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str215, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str216, 7, "(ifthen");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str217, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str218, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str219, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str220, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str221, 6, "(break");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str222, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str223, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str224, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str225, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str226, 9, "(continue");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str227, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str228, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str229, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str230, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str231, 7, "(return");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str232, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str233, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str234, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str235, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str236, 5, "(nest");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str237, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str238, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str239, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str240, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str241, 5, "(lazy");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str242, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str243, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str244, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str245, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str246, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str247, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str248, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str249, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str250, 6, "(tuple");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str251, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str252, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str253, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str254, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str255, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str256, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str257, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str258, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str259, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str260, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str261, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str262, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str263, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str264, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str265, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str266, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str267, 6, "(catch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str268, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str269, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str270, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str271, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str272, 4, "(try");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str273, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str274, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str275, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str276, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str277, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str278, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str279, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str280, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str281, 5, "(with");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str282, 1, ")");
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args);
Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str0), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str1), v_x_244));
      return heff_strAppend(v_t_245, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str2));
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str4), v_x_246));
      return heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str5));
    }
    case TAG_ENotationVar: {
      V v_x_248 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 3);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str6), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str7), v_x_248));
      return heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str8));
    }
    case TAG_ETag: {
      V v_x_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str10), v_x_2412));
      return heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str11));
    }
    case TAG_EInt: {
      V v_i_2414 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2414), NTAG(TAG_Nil)});
      V v_x2_2416 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str12), v_t_2415));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str14); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str15), v_t_2419), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str16));
    }
    case TAG_EFloat: {
      V v_x_2420 = heff_tget_v(v_x21_242, 0);
      heff_take_nf(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_negative_2421 = heff_take_field(v_x_2420, 0);
      V v_digits_2422 = heff_take_field(v_x_2420, 1);
      V v_exponent_2423 = heff_get_n(v_x_2420, 2, 3);
      double v_t_2425;
      if ((heff_dup(v_negative_2421) == NTAG(TAG_True))) {
        heff_drop(v_negative_2421);
        double v_x_2424 = (g_std_2emath_2efromDecimal_w(v_digits_2422, v_exponent_2423));
        v_t_2425 = ((-1.0) * v_x_2424);
      } else {
        heff_drop(v_negative_2421);
        v_t_2425 = (g_std_2emath_2efromDecimal_w(v_digits_2422, v_exponent_2423));
      }
      V v_parts_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_floatShow(heff_box_f64(v_t_2425)), NTAG(TAG_Nil)});
      V v_x2_2427 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str17), v_parts_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str18);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_xs_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str19); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2427);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str20), v_t_2430), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str21));
    }
    case TAG_EString: {
      V v_x_2431 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2432 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2431, NTAG(TAG_Nil)});
      V v_x2_2433 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str22), v_t_2432));
      V v_t_2436;
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Nil: {
        v_t_2436 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str23);
        break;
      }
      case TAG_Cons: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_xs_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        v_t_2436 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str24); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2433);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str25), v_t_2436), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str26));
    }
    case TAG_EBinary: {
      V v_segs_2437 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_2465 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam0, 1, 1, (V[]){v_r_240}), v_segs_2437));
      V v_t_2468;
      switch (heff_tag_of(v_x2_2465)) {
      case TAG_Nil: {
        v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str43);
        break;
      }
      case TAG_Cons: {
        V v_x_2466 = heff_field(v_x2_2465, 0);
        V v_xs_2467 = heff_field(v_x2_2465, 1);
        heff_take_n(v_x2_2465, 3ULL, 2);
        v_t_2468 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str44); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2465);
      }
      V v_t_2469 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str45), v_t_2468), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str46));
      V v_parts_2470 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
      V v_x2_2471 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str47), v_parts_2470));
      V v_t_2474;
      switch (heff_tag_of(v_x2_2471)) {
      case TAG_Nil: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str48);
        break;
      }
      case TAG_Cons: {
        V v_x_2472 = heff_field(v_x2_2471, 0);
        V v_xs_2473 = heff_field(v_x2_2471, 1);
        heff_take_n(v_x2_2471, 3ULL, 2);
        v_t_2474 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str49); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2471);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str50), v_t_2474), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str51));
    }
    case TAG_ERune: {
      V v_c_2475 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2476 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2475), NTAG(TAG_Nil)});
      V v_x2_2477 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str52), v_t_2476));
      V v_t_2480;
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_Nil: {
        v_t_2480 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str53);
        break;
      }
      case TAG_Cons: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_xs_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        v_t_2480 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str54); V a_1 = v_x_2478; V a_2 = v_xs_2479; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2479); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2477);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str55), v_t_2480), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str56));
    }
    case TAG_EWord: {
      V v_w_2481 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2483;
      switch (heff_tag_of(v_w_2481)) {
      case TAG_TypeWord: {
        v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str57);
        break;
      }
      case TAG_IntWord: {
        v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str58);
        break;
      }
      case TAG_FloatWord: {
        v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str59);
        break;
      }
      case TAG_StringWord: {
        v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str60);
        break;
      }
      case TAG_RuneWord: {
        v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str61);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str62);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str63);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2482 = heff_field(v_w_2481, 0);
        heff_take_n(v_w_2481, 1ULL, 1);
        switch (heff_tag_of(v_w_2482)) {
        case TAG_I8: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str64);
          break;
        }
        case TAG_I16: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str65);
          break;
        }
        case TAG_I32: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str66);
          break;
        }
        case TAG_I64: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str67);
          break;
        }
        case TAG_U8: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str68);
          break;
        }
        case TAG_U16: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str69);
          break;
        }
        case TAG_U32: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str70);
          break;
        }
        case TAG_U64: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str71);
          break;
        }
        case TAG_F32: {
          v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str72);
          break;
        }
        default: heff_nomatch(v_w_2482);
        }
        break;
      }
      default: heff_nomatch(v_w_2481);
      }
      V v_t_2484 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
      V v_x2_2485 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str73), v_t_2484));
      V v_t_2488;
      switch (heff_tag_of(v_x2_2485)) {
      case TAG_Nil: {
        v_t_2488 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str74);
        break;
      }
      case TAG_Cons: {
        V v_x_2486 = heff_field(v_x2_2485, 0);
        V v_xs_2487 = heff_field(v_x2_2485, 1);
        heff_take_n(v_x2_2485, 3ULL, 2);
        v_t_2488 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str75); V a_1 = v_x_2486; V a_2 = v_xs_2487; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2487); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2485);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str76), v_t_2488), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str77));
    }
    case TAG_EApp: {
      V v_h_2489 = heff_field(v_x21_242, 0);
      V v_args_2490 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_2489}));
      V v_x2_2492 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_2490));
      V v_t_2495;
      switch (heff_tag_of(v_x2_2492)) {
      case TAG_Nil: {
        v_t_2495 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str78);
        break;
      }
      case TAG_Cons: {
        V v_x_2493 = heff_field(v_x2_2492, 0);
        V v_xs_2494 = heff_field(v_x2_2492, 1);
        heff_take_n(v_x2_2492, 3ULL, 2);
        v_t_2495 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str79); V a_1 = v_x_2493; V a_2 = v_xs_2494; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2494); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2492);
      }
      V v_t_2496 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str80), v_t_2495), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str81));
      V v_t_2497 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2496, NTAG(TAG_Nil)});
      V v_parts_2498 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_Cons, 2, (V[]){v_t_2491, v_t_2497});
      V v_x2_2499 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str82), v_parts_2498));
      V v_t_24102;
      switch (heff_tag_of(v_x2_2499)) {
      case TAG_Nil: {
        v_t_24102 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str83);
        break;
      }
      case TAG_Cons: {
        V v_x_24100 = heff_field(v_x2_2499, 0);
        V v_xs_24101 = heff_field(v_x2_2499, 1);
        heff_take_n(v_x2_2499, 3ULL, 2);
        v_t_24102 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str84); V a_1 = v_x_24100; V a_2 = v_xs_24101; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24101); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2499);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str85), v_t_24102), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str86));
    }
    case TAG_EProject: {
      V v_x_24103 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24104 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_24103, NTAG(TAG_Nil)});
      V v_x2_24105 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str87), v_t_24104));
      V v_t_24108;
      switch (heff_tag_of(v_x2_24105)) {
      case TAG_Nil: {
        v_t_24108 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str88);
        break;
      }
      case TAG_Cons: {
        V v_x_24106 = heff_field(v_x2_24105, 0);
        V v_xs_24107 = heff_field(v_x2_24105, 1);
        heff_take_n(v_x2_24105, 3ULL, 2);
        v_t_24108 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str89); V a_1 = v_x_24106; V a_2 = v_xs_24107; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24107); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24105);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str90), v_t_24108), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str91));
    }
    case TAG_ENamed: {
      V v_x_24109 = heff_field(v_x21_242, 0);
      V v_e_24110 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24111 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24110}));
      V v_t_24112 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24111, NTAG(TAG_Nil)});
      V v_parts_24113 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_Cons, 2, (V[]){v_x_24109, v_t_24112});
      V v_x2_24114 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str92), v_parts_24113));
      V v_t_24117;
      switch (heff_tag_of(v_x2_24114)) {
      case TAG_Nil: {
        v_t_24117 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str93);
        break;
      }
      case TAG_Cons: {
        V v_x_24115 = heff_field(v_x2_24114, 0);
        V v_xs_24116 = heff_field(v_x2_24114, 1);
        heff_take_n(v_x2_24114, 3ULL, 2);
        v_t_24117 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str94); V a_1 = v_x_24115; V a_2 = v_xs_24116; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24116); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24114);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str95), v_t_24117), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str96));
    }
    case TAG_EPi: {
      V v_b_24118 = heff_field(v_x21_242, 0);
      V v_cod_24119 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24120 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_b_24118; V r_ = (g_heff_2esyntax_2eformat_2epiKey(a_0, a_1)); heff_drop(v_b_24118); r_; });
      V v_t_24121 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_24119}));
      V v_t_24122 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
      V v_parts_24123 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_Cons, 2, (V[]){v_t_24120, v_t_24122});
      V v_x2_24124 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str97), v_parts_24123));
      V v_t_24127;
      switch (heff_tag_of(v_x2_24124)) {
      case TAG_Nil: {
        v_t_24127 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str98);
        break;
      }
      case TAG_Cons: {
        V v_x_24125 = heff_field(v_x2_24124, 0);
        V v_xs_24126 = heff_field(v_x2_24124, 1);
        heff_take_n(v_x2_24124, 3ULL, 2);
        v_t_24127 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str99); V a_1 = v_x_24125; V a_2 = v_xs_24126; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24126); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24124);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str100), v_t_24127), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str101));
    }
    case TAG_ELam: {
      V v_b_24128 = heff_field(v_x21_242, 0);
      V v_body_24129 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24130 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_b_24128; V r_ = (g_heff_2esyntax_2eformat_2elamKey(a_0, a_1)); heff_drop(v_b_24128); r_; });
      V v_t_24131 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_24129}));
      V v_t_24132 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
      V v_parts_24133 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_Cons, 2, (V[]){v_t_24130, v_t_24132});
      V v_x2_24134 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str102), v_parts_24133));
      V v_t_24137;
      switch (heff_tag_of(v_x2_24134)) {
      case TAG_Nil: {
        v_t_24137 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str103);
        break;
      }
      case TAG_Cons: {
        V v_x_24135 = heff_field(v_x2_24134, 0);
        V v_xs_24136 = heff_field(v_x2_24134, 1);
        heff_take_n(v_x2_24134, 3ULL, 2);
        v_t_24137 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str104); V a_1 = v_x_24135; V a_2 = v_xs_24136; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24136); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24134);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str105), v_t_24137), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str106));
    }
    case TAG_EAnn: {
      V v_e_24138 = heff_field(v_x21_242, 0);
      V v_t_24139 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24140 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24138}));
      V v_t_24141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24139}));
      V v_t_24142 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24141, NTAG(TAG_Nil)});
      V v_parts_24143 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_Cons, 2, (V[]){v_t_24140, v_t_24142});
      V v_x2_24144 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str107), v_parts_24143));
      V v_t_24147;
      switch (heff_tag_of(v_x2_24144)) {
      case TAG_Nil: {
        v_t_24147 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str108);
        break;
      }
      case TAG_Cons: {
        V v_x_24145 = heff_field(v_x2_24144, 0);
        V v_xs_24146 = heff_field(v_x2_24144, 1);
        heff_take_n(v_x2_24144, 3ULL, 2);
        v_t_24147 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str109); V a_1 = v_x_24145; V a_2 = v_xs_24146; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24146); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24144);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str110), v_t_24147), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str111));
    }
    case TAG_ESpec: {
      V v_acc_24148 = heff_field(v_x21_242, 0);
      V v_x_24149 = heff_field(v_x21_242, 1);
      V v_v_24151 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24152 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_acc_24148}));
      V v_t_24153 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24151}));
      V v_t_24154 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24153, NTAG(TAG_Nil)});
      V v_parts_24155 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24152, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24149, v_t_24154})});
      V v_x2_24156 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str112), v_parts_24155));
      V v_t_24159;
      switch (heff_tag_of(v_x2_24156)) {
      case TAG_Nil: {
        v_t_24159 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str113);
        break;
      }
      case TAG_Cons: {
        V v_x_24157 = heff_field(v_x2_24156, 0);
        V v_xs_24158 = heff_field(v_x2_24156, 1);
        heff_take_n(v_x2_24156, 3ULL, 2);
        v_t_24159 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str114); V a_1 = v_x_24157; V a_2 = v_xs_24158; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24158); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24156);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str115), v_t_24159), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str116));
    }
    case TAG_ESig: {
      V v_fs_24160 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24161 = (g_list_2emap_24s135291903x1031656159(v_r_240, v_fs_24160));
      V v_t_24164;
      switch (heff_tag_of(v_x2_24161)) {
      case TAG_Nil: {
        v_t_24164 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str117);
        break;
      }
      case TAG_Cons: {
        V v_x_24162 = heff_field(v_x2_24161, 0);
        V v_xs_24163 = heff_field(v_x2_24161, 1);
        heff_take_n(v_x2_24161, 3ULL, 2);
        v_t_24164 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str118); V a_1 = v_x_24162; V a_2 = v_xs_24163; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24163); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24161);
      }
      V v_t_24165 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str119), v_t_24164), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str120));
      V v_parts_24166 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
      V v_x2_24167 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str121), v_parts_24166));
      V v_t_24170;
      switch (heff_tag_of(v_x2_24167)) {
      case TAG_Nil: {
        v_t_24170 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str122);
        break;
      }
      case TAG_Cons: {
        V v_x_24168 = heff_field(v_x2_24167, 0);
        V v_xs_24169 = heff_field(v_x2_24167, 1);
        heff_take_n(v_x2_24167, 3ULL, 2);
        v_t_24170 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str123); V a_1 = v_x_24168; V a_2 = v_xs_24169; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24169); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24167);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str124), v_t_24170), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str125));
    }
    case TAG_ESum: {
      V v_vs_24171 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24172 = (g_list_2emap_24s354283597x484250159(v_r_240, v_vs_24171));
      V v_t_24175;
      switch (heff_tag_of(v_x2_24172)) {
      case TAG_Nil: {
        v_t_24175 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str126);
        break;
      }
      case TAG_Cons: {
        V v_x_24173 = heff_field(v_x2_24172, 0);
        V v_xs_24174 = heff_field(v_x2_24172, 1);
        heff_take_n(v_x2_24172, 3ULL, 2);
        v_t_24175 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str127); V a_1 = v_x_24173; V a_2 = v_xs_24174; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24174); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24172);
      }
      V v_t_24176 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str128), v_t_24175), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str129));
      V v_parts_24177 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24176, NTAG(TAG_Nil)});
      V v_x2_24178 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str130), v_parts_24177));
      V v_t_24181;
      switch (heff_tag_of(v_x2_24178)) {
      case TAG_Nil: {
        v_t_24181 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str131);
        break;
      }
      case TAG_Cons: {
        V v_x_24179 = heff_field(v_x2_24178, 0);
        V v_xs_24180 = heff_field(v_x2_24178, 1);
        heff_take_n(v_x2_24178, 3ULL, 2);
        v_t_24181 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str132); V a_1 = v_x_24179; V a_2 = v_xs_24180; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24180); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24178);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str133), v_t_24181), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str134));
    }
    case TAG_EStruct: {
      V v_fs_24182 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24183 = (g_list_2emap_24s1099021180x1702355548(v_r_240, v_fs_24182));
      V v_t_24186;
      switch (heff_tag_of(v_x2_24183)) {
      case TAG_Nil: {
        v_t_24186 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str135);
        break;
      }
      case TAG_Cons: {
        V v_x_24184 = heff_field(v_x2_24183, 0);
        V v_xs_24185 = heff_field(v_x2_24183, 1);
        heff_take_n(v_x2_24183, 3ULL, 2);
        v_t_24186 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str136); V a_1 = v_x_24184; V a_2 = v_xs_24185; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24185); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24183);
      }
      V v_t_24187 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str137), v_t_24186), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str138));
      V v_parts_24188 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24187, NTAG(TAG_Nil)});
      V v_x2_24189 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str139), v_parts_24188));
      V v_t_24192;
      switch (heff_tag_of(v_x2_24189)) {
      case TAG_Nil: {
        v_t_24192 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str140);
        break;
      }
      case TAG_Cons: {
        V v_x_24190 = heff_field(v_x2_24189, 0);
        V v_xs_24191 = heff_field(v_x2_24189, 1);
        heff_take_n(v_x2_24189, 3ULL, 2);
        v_t_24192 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str141); V a_1 = v_x_24190; V a_2 = v_xs_24191; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24191); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24189);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str142), v_t_24192), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str143));
    }
    case TAG_EUpdate: {
      V v_a_24193 = heff_field(v_x21_242, 0);
      V v_fs_24194 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24195 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24193}));
      V v_x2_24196 = (g_list_2emap_24s510830240x893896831(v_r_240, v_fs_24194));
      V v_t_24199;
      switch (heff_tag_of(v_x2_24196)) {
      case TAG_Nil: {
        v_t_24199 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str144);
        break;
      }
      case TAG_Cons: {
        V v_x_24197 = heff_field(v_x2_24196, 0);
        V v_xs_24198 = heff_field(v_x2_24196, 1);
        heff_take_n(v_x2_24196, 3ULL, 2);
        v_t_24199 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str145); V a_1 = v_x_24197; V a_2 = v_xs_24198; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24198); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24196);
      }
      V v_t_24200 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str146), v_t_24199), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str147));
      V v_t_24201 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24200, NTAG(TAG_Nil)});
      V v_parts_24202 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_Cons, 2, (V[]){v_t_24195, v_t_24201});
      V v_x2_24203 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str148), v_parts_24202));
      V v_t_24206;
      switch (heff_tag_of(v_x2_24203)) {
      case TAG_Nil: {
        v_t_24206 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str149);
        break;
      }
      case TAG_Cons: {
        V v_x_24204 = heff_field(v_x2_24203, 0);
        V v_xs_24205 = heff_field(v_x2_24203, 1);
        heff_take_n(v_x2_24203, 3ULL, 2);
        v_t_24206 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str150); V a_1 = v_x_24204; V a_2 = v_xs_24205; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24205); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24203);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str151), v_t_24206), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str152));
    }
    case TAG_EMatch: {
      V v_s_24207 = heff_field(v_x21_242, 0);
      V v_alts_24208 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24209 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24207}));
      V v_x2_24210 = (g_list_2emap_24s1152414072x2935301(v_r_240, v_alts_24208));
      V v_t_24213;
      switch (heff_tag_of(v_x2_24210)) {
      case TAG_Nil: {
        v_t_24213 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str153);
        break;
      }
      case TAG_Cons: {
        V v_x_24211 = heff_field(v_x2_24210, 0);
        V v_xs_24212 = heff_field(v_x2_24210, 1);
        heff_take_n(v_x2_24210, 3ULL, 2);
        v_t_24213 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str154); V a_1 = v_x_24211; V a_2 = v_xs_24212; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24212); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24210);
      }
      V v_t_24214 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str155), v_t_24213), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str156));
      V v_t_24215 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24214, NTAG(TAG_Nil)});
      V v_parts_24216 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_Cons, 2, (V[]){v_t_24209, v_t_24215});
      V v_x2_24217 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str157), v_parts_24216));
      V v_t_24220;
      switch (heff_tag_of(v_x2_24217)) {
      case TAG_Nil: {
        v_t_24220 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str158);
        break;
      }
      case TAG_Cons: {
        V v_x_24218 = heff_field(v_x2_24217, 0);
        V v_xs_24219 = heff_field(v_x2_24217, 1);
        heff_take_n(v_x2_24217, 3ULL, 2);
        v_t_24220 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str159); V a_1 = v_x_24218; V a_2 = v_xs_24219; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24219); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24217);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str160), v_t_24220), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str161));
    }
    case TAG_ELetIn: {
      V v_rhs_24221 = heff_field(v_x21_242, 0);
      V v_x212_24222 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x212_24222)) {
      case TAG_At: {
        V v_x2121_24223 = heff_field(v_x212_24222, 0);
        V v_ru_24x212_24222_24At = heff_take_reuse_n(v_x212_24222, 1ULL, 2);
        switch (heff_tag_of(v_x2121_24223)) {
        case TAG_MkAlt: {
          V v_p_24225 = heff_field(v_x2121_24223, 0);
          V v_e_24226 = heff_field(v_x2121_24223, 1);
          heff_take_n(v_x2121_24223, 3ULL, 2);
          V v_t_24227 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24221}));
          V v_t_24228 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24225));
          V v_t_24229 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24226}));
          V v_t_24230 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24229, NTAG(TAG_Nil)});
          V v_parts_24231 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_Cons, 2, (V[]){v_t_24227, heff_tag_at_n(v_ru_24x212_24222_24At, TAG_Cons, 2, (V[]){v_t_24228, v_t_24230})});
          V v_x2_24232 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str162), v_parts_24231));
          V v_t_24235;
          switch (heff_tag_of(v_x2_24232)) {
          case TAG_Nil: {
            v_t_24235 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str163);
            break;
          }
          case TAG_Cons: {
            V v_x_24233 = heff_field(v_x2_24232, 0);
            V v_xs_24234 = heff_field(v_x2_24232, 1);
            heff_take_n(v_x2_24232, 3ULL, 2);
            v_t_24235 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str164); V a_1 = v_x_24233; V a_2 = v_xs_24234; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24234); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24232);
          }
          return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str165), v_t_24235), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str166));
        }
        default: return heff_nomatch(v_x2121_24223);
        }
      }
      default: return heff_nomatch(v_x212_24222);
      }
    }
    case TAG_EDo: {
      V v_stmts_24236 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24237 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24238 = (g_list_2emap(v_t_24237, v_stmts_24236));
      V v_t_24241;
      switch (heff_tag_of(v_x2_24238)) {
      case TAG_Nil: {
        v_t_24241 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str167);
        break;
      }
      case TAG_Cons: {
        V v_x_24239 = heff_field(v_x2_24238, 0);
        V v_xs_24240 = heff_field(v_x2_24238, 1);
        heff_take_n(v_x2_24238, 3ULL, 2);
        v_t_24241 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str168); V a_1 = v_x_24239; V a_2 = v_xs_24240; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24240); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24238);
      }
      V v_t_24242 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str169), v_t_24241), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str170));
      V v_parts_24243 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24242, NTAG(TAG_Nil)});
      V v_x2_24244 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str171), v_parts_24243));
      V v_t_24247;
      switch (heff_tag_of(v_x2_24244)) {
      case TAG_Nil: {
        v_t_24247 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str172);
        break;
      }
      case TAG_Cons: {
        V v_x_24245 = heff_field(v_x2_24244, 0);
        V v_xs_24246 = heff_field(v_x2_24244, 1);
        heff_take_n(v_x2_24244, 3ULL, 2);
        v_t_24247 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str173); V a_1 = v_x_24245; V a_2 = v_xs_24246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24246); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24244);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str174), v_t_24247), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str175));
    }
    case TAG_ELocal: {
      V v_body_24248 = heff_field(v_x21_242, 0);
      V v_ds_24249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24250 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24248}));
      V v_x2_24251 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24249));
      V v_t_24254;
      switch (heff_tag_of(v_x2_24251)) {
      case TAG_Nil: {
        v_t_24254 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str176);
        break;
      }
      case TAG_Cons: {
        V v_x_24252 = heff_field(v_x2_24251, 0);
        V v_xs_24253 = heff_field(v_x2_24251, 1);
        heff_take_n(v_x2_24251, 3ULL, 2);
        v_t_24254 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str177); V a_1 = v_x_24252; V a_2 = v_xs_24253; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24253); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24251);
      }
      V v_t_24255 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str178), v_t_24254), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str179));
      V v_t_24256 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24255, NTAG(TAG_Nil)});
      V v_parts_24257 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_Cons, 2, (V[]){v_t_24250, v_t_24256});
      V v_x2_24258 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str180), v_parts_24257));
      V v_t_24261;
      switch (heff_tag_of(v_x2_24258)) {
      case TAG_Nil: {
        v_t_24261 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str181);
        break;
      }
      case TAG_Cons: {
        V v_x_24259 = heff_field(v_x2_24258, 0);
        V v_xs_24260 = heff_field(v_x2_24258, 1);
        heff_take_n(v_x2_24258, 3ULL, 2);
        v_t_24261 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str182); V a_1 = v_x_24259; V a_2 = v_xs_24260; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24260); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24258);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str183), v_t_24261), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str184));
    }
    case TAG_EInvalid: {
      V v_why_24262 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24263 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_why_24262, NTAG(TAG_Nil)});
      V v_x2_24264 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str185), v_t_24263));
      V v_t_24267;
      switch (heff_tag_of(v_x2_24264)) {
      case TAG_Nil: {
        v_t_24267 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str186);
        break;
      }
      case TAG_Cons: {
        V v_x_24265 = heff_field(v_x2_24264, 0);
        V v_xs_24266 = heff_field(v_x2_24264, 1);
        heff_take_n(v_x2_24264, 3ULL, 2);
        v_t_24267 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str187); V a_1 = v_x_24265; V a_2 = v_xs_24266; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24266); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24264);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str188), v_t_24267), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str189));
    }
    case TAG_EAssign: {
      V v_x_24268 = heff_field(v_x21_242, 0);
      V v_e_24270 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_24271 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24270}));
      V v_t_24272 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24271, NTAG(TAG_Nil)});
      V v_parts_24273 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24268, v_t_24272});
      V v_x2_24274 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str190), v_parts_24273));
      V v_t_24277;
      switch (heff_tag_of(v_x2_24274)) {
      case TAG_Nil: {
        v_t_24277 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str191);
        break;
      }
      case TAG_Cons: {
        V v_x_24275 = heff_field(v_x2_24274, 0);
        V v_xs_24276 = heff_field(v_x2_24274, 1);
        heff_take_n(v_x2_24274, 3ULL, 2);
        v_t_24277 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str192); V a_1 = v_x_24275; V a_2 = v_xs_24276; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24276); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24274);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str193), v_t_24277), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str194));
    }
    case TAG_EWhile: {
      V v_c_24278 = heff_field(v_x21_242, 0);
      V v_body_24279 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EWhile = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24280 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24278}));
      V v_t_24281 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24282 = (g_list_2emap(v_t_24281, v_body_24279));
      V v_t_24285;
      switch (heff_tag_of(v_x2_24282)) {
      case TAG_Nil: {
        v_t_24285 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str195);
        break;
      }
      case TAG_Cons: {
        V v_x_24283 = heff_field(v_x2_24282, 0);
        V v_xs_24284 = heff_field(v_x2_24282, 1);
        heff_take_n(v_x2_24282, 3ULL, 2);
        v_t_24285 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str196); V a_1 = v_x_24283; V a_2 = v_xs_24284; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24284); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24282);
      }
      V v_t_24286 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str197), v_t_24285), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str198));
      V v_t_24287 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24286, NTAG(TAG_Nil)});
      V v_parts_24288 = heff_tag_at_n(v_ru_24x21_242_24EWhile, TAG_Cons, 2, (V[]){v_t_24280, v_t_24287});
      V v_x2_24289 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str199), v_parts_24288));
      V v_t_24292;
      switch (heff_tag_of(v_x2_24289)) {
      case TAG_Nil: {
        v_t_24292 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str200);
        break;
      }
      case TAG_Cons: {
        V v_x_24290 = heff_field(v_x2_24289, 0);
        V v_xs_24291 = heff_field(v_x2_24289, 1);
        heff_take_n(v_x2_24289, 3ULL, 2);
        v_t_24292 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str201); V a_1 = v_x_24290; V a_2 = v_xs_24291; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24291); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24289);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str202), v_t_24292), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str203));
    }
    case TAG_EFor: {
      V v_p_24293 = heff_field(v_x21_242, 0);
      V v_c_24294 = heff_field(v_x21_242, 1);
      V v_body_24295 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 7ULL, 3);
      V v_t_24296 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24293));
      V v_t_24297 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24294}));
      V v_t_24298 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24299 = (g_list_2emap(v_t_24298, v_body_24295));
      V v_t_24302;
      switch (heff_tag_of(v_x2_24299)) {
      case TAG_Nil: {
        v_t_24302 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str204);
        break;
      }
      case TAG_Cons: {
        V v_x_24300 = heff_field(v_x2_24299, 0);
        V v_xs_24301 = heff_field(v_x2_24299, 1);
        heff_take_n(v_x2_24299, 3ULL, 2);
        v_t_24302 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str205); V a_1 = v_x_24300; V a_2 = v_xs_24301; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24301); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24299);
      }
      V v_t_24303 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str206), v_t_24302), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str207));
      V v_t_24304 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24303, NTAG(TAG_Nil)});
      V v_parts_24305 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24296, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24297, v_t_24304})});
      V v_x2_24306 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str208), v_parts_24305));
      V v_t_24309;
      switch (heff_tag_of(v_x2_24306)) {
      case TAG_Nil: {
        v_t_24309 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str209);
        break;
      }
      case TAG_Cons: {
        V v_x_24307 = heff_field(v_x2_24306, 0);
        V v_xs_24308 = heff_field(v_x2_24306, 1);
        heff_take_n(v_x2_24306, 3ULL, 2);
        v_t_24309 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str210); V a_1 = v_x_24307; V a_2 = v_xs_24308; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24308); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24306);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str211), v_t_24309), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str212));
    }
    case TAG_EIfThen: {
      V v_c_24310 = heff_field(v_x21_242, 0);
      V v_a_24311 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EIfThen = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24312 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24310}));
      V v_t_24313 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_24311}));
      V v_t_24314 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24313, NTAG(TAG_Nil)});
      V v_parts_24315 = heff_tag_at_n(v_ru_24x21_242_24EIfThen, TAG_Cons, 2, (V[]){v_t_24312, v_t_24314});
      V v_x2_24316 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str213), v_parts_24315));
      V v_t_24319;
      switch (heff_tag_of(v_x2_24316)) {
      case TAG_Nil: {
        v_t_24319 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str214);
        break;
      }
      case TAG_Cons: {
        V v_x_24317 = heff_field(v_x2_24316, 0);
        V v_xs_24318 = heff_field(v_x2_24316, 1);
        heff_take_n(v_x2_24316, 3ULL, 2);
        v_t_24319 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str215); V a_1 = v_x_24317; V a_2 = v_xs_24318; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24318); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24316);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str216), v_t_24319), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str217));
    }
    case TAG_EBreak: {
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_x2_24320 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str218), NTAG(TAG_Nil)));
      V v_t_24323;
      switch (heff_tag_of(v_x2_24320)) {
      case TAG_Nil: {
        v_t_24323 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str219);
        break;
      }
      case TAG_Cons: {
        V v_x_24321 = heff_field(v_x2_24320, 0);
        V v_xs_24322 = heff_field(v_x2_24320, 1);
        heff_take_n(v_x2_24320, 3ULL, 2);
        v_t_24323 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str220); V a_1 = v_x_24321; V a_2 = v_xs_24322; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24322); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24320);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str221), v_t_24323), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str222));
    }
    case TAG_EContinue: {
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_x2_24324 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str223), NTAG(TAG_Nil)));
      V v_t_24327;
      switch (heff_tag_of(v_x2_24324)) {
      case TAG_Nil: {
        v_t_24327 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str224);
        break;
      }
      case TAG_Cons: {
        V v_x_24325 = heff_field(v_x2_24324, 0);
        V v_xs_24326 = heff_field(v_x2_24324, 1);
        heff_take_n(v_x2_24324, 3ULL, 2);
        v_t_24327 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str225); V a_1 = v_x_24325; V a_2 = v_xs_24326; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24326); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24324);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str226), v_t_24327), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str227));
    }
    case TAG_EReturn: {
      V v_e_24328 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24328}));
      V v_parts_24330 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24329, NTAG(TAG_Nil)});
      V v_x2_24331 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str228), v_parts_24330));
      V v_t_24334;
      switch (heff_tag_of(v_x2_24331)) {
      case TAG_Nil: {
        v_t_24334 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str229);
        break;
      }
      case TAG_Cons: {
        V v_x_24332 = heff_field(v_x2_24331, 0);
        V v_xs_24333 = heff_field(v_x2_24331, 1);
        heff_take_n(v_x2_24331, 3ULL, 2);
        v_t_24334 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str230); V a_1 = v_x_24332; V a_2 = v_xs_24333; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24333); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24331);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str231), v_t_24334), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str232));
    }
    case TAG_ENest: {
      V v_e_24335 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24336 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24335}));
      V v_parts_24337 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24336, NTAG(TAG_Nil)});
      V v_x2_24338 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str233), v_parts_24337));
      V v_t_24341;
      switch (heff_tag_of(v_x2_24338)) {
      case TAG_Nil: {
        v_t_24341 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str234);
        break;
      }
      case TAG_Cons: {
        V v_x_24339 = heff_field(v_x2_24338, 0);
        V v_xs_24340 = heff_field(v_x2_24338, 1);
        heff_take_n(v_x2_24338, 3ULL, 2);
        v_t_24341 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str235); V a_1 = v_x_24339; V a_2 = v_xs_24340; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24340); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24338);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str236), v_t_24341), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str237));
    }
    case TAG_ELazy: {
      V v_e_24342 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24343 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24342}));
      V v_parts_24344 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24343, NTAG(TAG_Nil)});
      V v_x2_24345 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str238), v_parts_24344));
      V v_t_24348;
      switch (heff_tag_of(v_x2_24345)) {
      case TAG_Nil: {
        v_t_24348 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str239);
        break;
      }
      case TAG_Cons: {
        V v_x_24346 = heff_field(v_x2_24345, 0);
        V v_xs_24347 = heff_field(v_x2_24345, 1);
        heff_take_n(v_x2_24345, 3ULL, 2);
        v_t_24348 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str240); V a_1 = v_x_24346; V a_2 = v_xs_24347; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24347); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24345);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str241), v_t_24348), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str242));
    }
    case TAG_ETuple: {
      V v_es_24349 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_x2_24350 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_es_24349));
      V v_t_24353;
      switch (heff_tag_of(v_x2_24350)) {
      case TAG_Nil: {
        v_t_24353 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str243);
        break;
      }
      case TAG_Cons: {
        V v_x_24351 = heff_field(v_x2_24350, 0);
        V v_xs_24352 = heff_field(v_x2_24350, 1);
        heff_take_n(v_x2_24350, 3ULL, 2);
        v_t_24353 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str244); V a_1 = v_x_24351; V a_2 = v_xs_24352; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24352); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24350);
      }
      V v_t_24354 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str245), v_t_24353), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str246));
      V v_parts_24355 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24354, NTAG(TAG_Nil)});
      V v_x2_24356 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str247), v_parts_24355));
      V v_t_24359;
      switch (heff_tag_of(v_x2_24356)) {
      case TAG_Nil: {
        v_t_24359 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str248);
        break;
      }
      case TAG_Cons: {
        V v_x_24357 = heff_field(v_x2_24356, 0);
        V v_xs_24358 = heff_field(v_x2_24356, 1);
        heff_take_n(v_x2_24356, 3ULL, 2);
        v_t_24359 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str249); V a_1 = v_x_24357; V a_2 = v_xs_24358; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24358); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24356);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str250), v_t_24359), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str251));
    }
    case TAG_ETry: {
      V v_x211_24360 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      switch (heff_tag_of(v_x211_24360)) {
      case TAG_MkTry: {
        V v_ty_24361 = heff_field(v_x211_24360, 0);
        V v_body_24362 = heff_field(v_x211_24360, 1);
        V v_c_24363 = heff_field(v_x211_24360, 2);
        heff_take_n(v_x211_24360, 7ULL, 3);
        V v_t_24365;
        switch (heff_tag_of(v_ty_24361)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_24365 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_24364 = heff_field(v_ty_24361, 0);
          heff_take_n(v_ty_24361, 1ULL, 1);
          v_t_24365 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_24364, NTAG(TAG_Nil)});
          break;
        }
        default: heff_nomatch(v_ty_24361);
        }
        V v_x2_24366 = (g_list_2emap(heff_dup(heff_rfield(v_r_240, 0)), v_t_24365));
        V v_t_24369;
        switch (heff_tag_of(v_x2_24366)) {
        case TAG_Nil: {
          v_t_24369 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str252);
          break;
        }
        case TAG_Cons: {
          V v_x_24367 = heff_field(v_x2_24366, 0);
          V v_xs_24368 = heff_field(v_x2_24366, 1);
          heff_take_n(v_x2_24366, 3ULL, 2);
          v_t_24369 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str253); V a_1 = v_x_24367; V a_2 = v_xs_24368; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24368); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24366);
        }
        V v_t_24370 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str254), v_t_24369), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str255));
        V v_t_24371 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){heff_dup(v_r_240)}));
        V v_x2_24372 = (g_list_2emap(v_t_24371, v_body_24362));
        V v_t_24375;
        switch (heff_tag_of(v_x2_24372)) {
        case TAG_Nil: {
          v_t_24375 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str256);
          break;
        }
        case TAG_Cons: {
          V v_x_24373 = heff_field(v_x2_24372, 0);
          V v_xs_24374 = heff_field(v_x2_24372, 1);
          heff_take_n(v_x2_24372, 3ULL, 2);
          v_t_24375 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str257); V a_1 = v_x_24373; V a_2 = v_xs_24374; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24374); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24372);
        }
        V v_t_24376 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str258), v_t_24375), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str259));
        V v_r_24377 = v_r_240;
        V v_x2_24378 = v_c_24363;
        V v_t_24394;
        switch (heff_tag_of(v_x2_24378)) {
        case TAG_MkCatchArm: {
          V v_b_24379 = heff_field(v_x2_24378, 0);
          V v_ss_24380 = heff_field(v_x2_24378, 1);
          V v_ru_24x2_24378_24MkCatchArm = heff_take_reuse_n(v_x2_24378, 3ULL, 2);
          V v_t_24381 = ({ V a_0 = heff_dup(v_r_24377); V a_1 = v_b_24379; V r_ = (g_heff_2esyntax_2eformat_2elamKey(a_0, a_1)); heff_drop(v_b_24379); r_; });
          V v_t_24382 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_24377}));
          V v_x2_24383 = (g_list_2emap(v_t_24382, v_ss_24380));
          V v_t_24386;
          switch (heff_tag_of(v_x2_24383)) {
          case TAG_Nil: {
            v_t_24386 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str260);
            break;
          }
          case TAG_Cons: {
            V v_x_24384 = heff_field(v_x2_24383, 0);
            V v_xs_24385 = heff_field(v_x2_24383, 1);
            heff_take_n(v_x2_24383, 3ULL, 2);
            v_t_24386 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str261); V a_1 = v_x_24384; V a_2 = v_xs_24385; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24385); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24383);
          }
          V v_t_24387 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str262), v_t_24386), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str263));
          V v_t_24388 = heff_tag_at_n(v_ru_24x2_24378_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_24387, NTAG(TAG_Nil)});
          V v_parts_24389 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24381, v_t_24388});
          V v_x2_24390 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str264), v_parts_24389));
          V v_t_24393;
          switch (heff_tag_of(v_x2_24390)) {
          case TAG_Nil: {
            v_t_24393 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str265);
            break;
          }
          case TAG_Cons: {
            V v_x_24391 = heff_field(v_x2_24390, 0);
            V v_xs_24392 = heff_field(v_x2_24390, 1);
            heff_take_n(v_x2_24390, 3ULL, 2);
            v_t_24393 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str266); V a_1 = v_x_24391; V a_2 = v_xs_24392; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24392); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24390);
          }
          v_t_24394 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str267), v_t_24393), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str268));
          break;
        }
        default: heff_nomatch(v_x2_24378);
        }
        V v_t_24395 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24394, NTAG(TAG_Nil)});
        V v_parts_24396 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24370, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24376, v_t_24395})});
        V v_x2_24397 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str269), v_parts_24396));
        V v_t_24400;
        switch (heff_tag_of(v_x2_24397)) {
        case TAG_Nil: {
          v_t_24400 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str270);
          break;
        }
        case TAG_Cons: {
          V v_x_24398 = heff_field(v_x2_24397, 0);
          V v_xs_24399 = heff_field(v_x2_24397, 1);
          heff_take_n(v_x2_24397, 3ULL, 2);
          v_t_24400 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str271); V a_1 = v_x_24398; V a_2 = v_xs_24399; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24399); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24397);
        }
        return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str272), v_t_24400), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str273));
      }
      default: return heff_nomatch(v_x211_24360);
      }
    }
    case TAG_EWith: {
      V v_w_24401 = heff_field(v_x21_242, 0);
      V v_x_24402 = heff_field(v_x21_242, 1);
      V v_body_24404 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24405 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_w_24401}));
      V v_t_24406 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24407 = (g_list_2emap(v_t_24406, v_body_24404));
      V v_t_24410;
      switch (heff_tag_of(v_x2_24407)) {
      case TAG_Nil: {
        v_t_24410 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str274);
        break;
      }
      case TAG_Cons: {
        V v_x_24408 = heff_field(v_x2_24407, 0);
        V v_xs_24409 = heff_field(v_x2_24407, 1);
        heff_take_n(v_x2_24407, 3ULL, 2);
        v_t_24410 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str275); V a_1 = v_x_24408; V a_2 = v_xs_24409; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24409); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24407);
      }
      V v_t_24411 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str276), v_t_24410), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str277));
      V v_t_24412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24411, NTAG(TAG_Nil)});
      V v_parts_24413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24405, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24402, v_t_24412})});
      V v_x2_24414 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str278), v_parts_24413));
      V v_t_24417;
      switch (heff_tag_of(v_x2_24414)) {
      case TAG_Nil: {
        v_t_24417 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str279);
        break;
      }
      case TAG_Cons: {
        V v_x_24415 = heff_field(v_x2_24414, 0);
        V v_xs_24416 = heff_field(v_x2_24414, 1);
        heff_take_n(v_x2_24414, 3ULL, 2);
        v_t_24417 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str280); V a_1 = v_x_24415; V a_2 = v_xs_24416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24414);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str281), v_t_24417), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str282));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyTermF(a[0], a[1]);
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args) {
  V v_m_2438 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_f_2439 = heff_get_n(v_r_240, 0, 2);
  V v_x2_2440 = v_m_2438;
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_At: {
    V v_x21_2441 = heff_field(v_x2_2440, 0);
    V v_ru_24x2_2440_24At = heff_take_reuse_n(v_x2_2440, 1ULL, 2);
    switch (heff_tag_of(v_x21_2441)) {
    case TAG_MkSegment: {
      V v_v_2443 = heff_field(v_x21_2441, 0);
      V v_ty_2444 = heff_field(v_x21_2441, 1);
      V v_size_2445 = heff_field(v_x21_2441, 2);
      V v_little_2446 = heff_field(v_x21_2441, 3);
      V v_signed_2447 = heff_field(v_x21_2441, 4);
      heff_take_n(v_x21_2441, 31ULL, 5);
      V v_t_2448 = heff_tr(heff_call(v_f_2439, 1, (V[]){v_v_2443}));
      V v_t_2450;
      switch (heff_tag_of(v_ty_2444)) {
      case TAG_SegmentInteger: {
        v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str27);
        break;
      }
      case TAG_SegmentBinary: {
        v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str28);
        break;
      }
      case TAG_SegmentBits: {
        v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str29);
        break;
      }
      case TAG_SegmentFloat: {
        v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str30);
        break;
      }
      case TAG_SegmentUtf: {
        V v_n_2449 = heff_field(v_ty_2444, 0);
        heff_take_n(v_ty_2444, 1ULL, 1);
        v_t_2450 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str31), heff_intShow(v_n_2449));
        break;
      }
      default: heff_nomatch(v_ty_2444);
      }
      V v_t_2455;
      switch (heff_tag_of(v_size_2445)) {
      case TAG_SizeDefault: {
        v_t_2455 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str32);
        break;
      }
      case TAG_SizeNumber: {
        V v_n_2451 = heff_field(v_size_2445, 0);
        heff_take_n(v_size_2445, 1ULL, 1);
        v_t_2455 = heff_intShow(v_n_2451);
        break;
      }
      case TAG_SizeName: {
        V v_x_2452 = heff_field(v_size_2445, 0);
        V v_unit_2454 = heff_field(v_size_2445, 2);
        heff_take_n(v_size_2445, 5ULL, 3);
        v_t_2455 = heff_strAppend(heff_strAppend(v_x_2452, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str33)), heff_intShow(v_unit_2454));
        break;
      }
      default: heff_nomatch(v_size_2445);
      }
      V v_t_2456;
      if ((heff_dup(v_little_2446) == NTAG(TAG_True))) {
        heff_drop(v_little_2446);
        v_t_2456 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str34);
      } else {
        heff_drop(v_little_2446);
        v_t_2456 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str35);
      }
      V v_t_2457;
      if ((heff_dup(v_signed_2447) == NTAG(TAG_True))) {
        heff_drop(v_signed_2447);
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str36);
      } else {
        heff_drop(v_signed_2447);
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str37);
      }
      V v_t_2458 = heff_tag_at_n(v_ru_24x2_2440_24At, TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
      V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, v_t_2458})});
      V v_parts_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2459})});
      V v_x2_2461 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str38), v_parts_2460));
      V v_t_2464;
      switch (heff_tag_of(v_x2_2461)) {
      case TAG_Nil: {
        v_t_2464 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2462 = heff_field(v_x2_2461, 0);
        V v_xs_2463 = heff_field(v_x2_2461, 1);
        heff_take_n(v_x2_2461, 3ULL, 2);
        v_t_2464 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str40); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2461);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str41), v_t_2464), ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str42));
    }
    default: return heff_nomatch(v_x21_2441);
    }
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str0, 10, "definition");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str4, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str5, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str9, 10, "(equations");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str12, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str13, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str14, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str15, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str18, 7, "(define");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str21, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str22, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str23, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str27, 7, "(theory");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str29, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str30, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str31, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str32, 10, "(primitive");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str33, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str34, 5, "(test");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str35, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str37, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str40, 6, "(watch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str41, 1, ")");
Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_t_249;
      switch (heff_tag_of(v_declared_246)) {
      case TAG_AsDefinition: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_AsInstance: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str1);
        break;
      }
      default: heff_nomatch(v_declared_246);
      }
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_x2_2411 = (g_list_2emap_24s1055307687x247454614(v_r_240, v_eqs_248));
      V v_t_2414;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        V v_xs_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str4), v_t_2414), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str5));
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2416})});
      V v_parts_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_244, v_t_2417});
      V v_x2_2419 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str6), v_parts_2418));
      V v_t_2422;
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nil: {
        v_t_2422 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_xs_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        v_t_2422 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str8); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2419);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str9), v_t_2422), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str10));
    }
    case TAG_DeclDefine: {
      V v_x_2423 = heff_field(v_x21_242, 0);
      V v_ps_2425 = heff_field(v_x21_242, 2);
      V v_u_2426 = heff_field(v_x21_242, 3);
      V v_body_2427 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_x2_2428 = (g_list_2emap_24s228910449x1110031924(heff_dup(v_r_240), v_ps_2425));
      V v_t_2431;
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_Nil: {
        v_t_2431 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2429 = heff_field(v_x2_2428, 0);
        V v_xs_2430 = heff_field(v_x2_2428, 1);
        heff_take_n(v_x2_2428, 3ULL, 2);
        v_t_2431 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str12); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2428);
      }
      V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str13), v_t_2431), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str14));
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2426}));
      V v_t_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2427}));
      V v_t_2435 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2435})});
      V v_parts_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2423, v_t_2436});
      V v_x2_2438 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str15), v_parts_2437));
      V v_t_2441;
      switch (heff_tag_of(v_x2_2438)) {
      case TAG_Nil: {
        v_t_2441 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x2_2438, 0);
        V v_xs_2440 = heff_field(v_x2_2438, 1);
        heff_take_n(v_x2_2438, 3ULL, 2);
        v_t_2441 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str17); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2438);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str18), v_t_2441), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str19));
    }
    case TAG_DeclTheory: {
      V v_x_2442 = heff_field(v_x21_242, 0);
      V v_ps_2444 = heff_field(v_x21_242, 2);
      V v_body_2445 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_x2_2446 = (g_list_2emap_24s228910449x1110031924(heff_dup(v_r_240), v_ps_2444));
      V v_t_2449;
      switch (heff_tag_of(v_x2_2446)) {
      case TAG_Nil: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_2447 = heff_field(v_x2_2446, 0);
        V v_xs_2448 = heff_field(v_x2_2446, 1);
        heff_take_n(v_x2_2446, 3ULL, 2);
        v_t_2449 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str21); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2446);
      }
      V v_t_2450 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str22), v_t_2449), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str23));
      V v_t_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2445}));
      V v_t_2452 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
      V v_parts_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2442, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, v_t_2452})});
      V v_x2_2454 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str24), v_parts_2453));
      V v_t_2457;
      switch (heff_tag_of(v_x2_2454)) {
      case TAG_Nil: {
        v_t_2457 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_2455 = heff_field(v_x2_2454, 0);
        V v_xs_2456 = heff_field(v_x2_2454, 1);
        heff_take_n(v_x2_2454, 3ULL, 2);
        v_t_2457 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str26); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2454);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str27), v_t_2457), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str28));
    }
    case TAG_DeclPrimitive: {
      V v_x_2458 = heff_field(v_x21_242, 0);
      V v_t_2460 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
      V v_t_2462 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
      V v_parts_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2458, v_t_2462});
      V v_x2_2464 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str29), v_parts_2463));
      V v_t_2467;
      switch (heff_tag_of(v_x2_2464)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str30);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x2_2464, 0);
        V v_xs_2466 = heff_field(v_x2_2464, 1);
        heff_take_n(v_x2_2464, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str31); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2464);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str32), v_t_2467), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str33));
    }
    case TAG_DeclTest: {
      V v_x_2468 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2470 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str34), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str35), v_x_2468));
      return heff_strAppend(v_t_2470, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str36));
    }
    case TAG_DeclWatch: {
      V v_e_2471 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2471}));
      V v_parts_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
      V v_x2_2474 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str37), v_parts_2473));
      V v_t_2477;
      switch (heff_tag_of(v_x2_2474)) {
      case TAG_Nil: {
        v_t_2477 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str38);
        break;
      }
      case TAG_Cons: {
        V v_x_2475 = heff_field(v_x2_2474, 0);
        V v_xs_2476 = heff_field(v_x2_2474, 1);
        heff_take_n(v_x2_2474, 3ULL, 2);
        v_t_2477 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str39); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2474);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str40), v_t_2477), ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str41));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyDeclF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str3, 2, " (");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str5, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str6, 4, "(..)");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaning_str7, 0, "");
Clo g_heff_2esyntax_2eformat_2emeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2emeaning_entry, 1, 0};

V g_heff_2esyntax_2eformat_2emeaning(V v_s_240) {
top: ;
  V v_h_241 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_s_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_h_242 = heff_dup(v_h_241);
  V v_claim_243 = heff_take_field(v_h_242, 2);
  V v_imports_244 = heff_get_n(v_h_242, 0, 4);
  V v_text_245 = heff_get_n(v_h_241, 3, 4);
  V v_lit_246 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str0);
  V v_lit_247 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str1);
  V v_src_248 = heff_dup(v_text_245);
  V v_t_249 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_2410 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_text_245, v_t_249, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_r_2422;
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[2]);
    V v_ltoks_2414 = heff_arrayFromList(heff_dup(v_field_2411));
    V v_t_2415 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), v_field_2411));
    V v_toks_2416 = heff_arrayFromList(v_t_2415);
    V v_lexDiags_2417 = (g_list_2emap_24s338694954x1326523169(v_field_2412));
    V v_t_2418 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){((V)&g_heff_2esyntax_2esurface_2enoKnown_clo), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_True), heff_dup(v_lit_246), v_lit_247});
    V v_t_2419 = (g_heff_2esyntax_2esurface_2eprescanGo(v_ltoks_2414, MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nil)));
    V v_t_2420 = (g_heff_2esyntax_2esurface_2efixDecls(v_ltoks_2414, MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2421 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(v_lit_246, v_t_2420));
    v_r_2422 = (g_heff_2esyntax_2esurface_2ereadRun(v_src_248, v_t_2418, v_toks_2416, v_lexDiags_2417, v_t_2419, v_t_2421));
  }
  V v_decls_2423 = heff_take_field(v_r_2422, 0);
  V v_diags_2424 = heff_get_n(v_r_2422, 1, 5);
  V v_t_2434;
  switch (heff_tag_of(v_claim_243)) {
  case TAG_Nothing: {
    v_t_2434 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_h_2425 = heff_field(v_claim_243, 0);
    heff_take_n(v_claim_243, 1ULL, 1);
    V v_name_2426 = heff_take_field(v_h_2425, 0);
    V v_listed_2427 = heff_take_field(v_h_2425, 1);
    V v_exposes_2428 = heff_get_n(v_h_2425, 2, 5);
    V v_t_2430;
    switch (heff_tag_of(v_name_2426)) {
    case TAG_Nothing: {
      v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str2);
      break;
    }
    case TAG_Just: {
      V v_x_2429 = heff_field(v_name_2426, 0);
      heff_take_n(v_name_2426, 1ULL, 1);
      v_t_2430 = v_x_2429;
      break;
    }
    default: heff_nomatch(v_name_2426);
    }
    V v_t_2431;
    if ((heff_dup(v_listed_2427) == NTAG(TAG_True))) {
      heff_drop(v_listed_2427);
      v_t_2431 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str3);
    } else {
      heff_drop(v_listed_2427);
      v_t_2431 = ((V)&g_heff_2esyntax_2eformat_2emeaning_str4);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2eformat_2emeaning_str5), v_t_2430), v_t_2431);
    V v_t_2433 = (g_list_2emap_24s900318151x1569363206(((V)&g_heff_2esyntax_2eformat_2emeaning_str6), ((V)&g_heff_2esyntax_2eformat_2emeaning_str7), v_exposes_2428));
    v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_t_2433});
    break;
  }
  default: heff_nomatch(v_claim_243);
  }
  V v_t_2435 = (g_list_2emap_24s1817208647x1282894070(v_imports_244));
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2434, v_t_2435));
  V v_t_2437 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2eformat_2ekeys_get(), 1)), v_decls_2423));
  V v_t_2438 = (g_list_2emap_24s179832492x431904054(v_diags_2424));
  return heff_rec_n(3, shape_imports__decls__diags, (V[]){v_t_2436, v_t_2437, v_t_2438});
}
V g_heff_2esyntax_2eformat_2emeaning_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2emeaning(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str0, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str1, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str4, 2, " (");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str6, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str7, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str9, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str10, 2, " (");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str12, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str13, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str15, 5, "\012  , ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str16, 5, "\012  ( ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str17, 4, "\012  )");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str18, 6, "module");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str19, 7, "module ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str21, 6, "import");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str22, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str23, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str26, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str27, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str29, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str30, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str32, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2eformat_2eformatIn_24cpr_str33, 21, "the file does not lex");

HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V v_f_240, V v_src_241) {
top: ;
  V v_claim_242 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_241), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_f_243 = v_f_240;
  V v_src_244 = heff_dup(v_src_241);
  V v_claim_245 = heff_dup(v_claim_242);
  V v_claim_246 = heff_take_field(v_claim_245, 2);
  V v_imports_247 = heff_get_n(v_claim_245, 0, 4);
  V v_t_248 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_249 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_get_n(v_claim_242, 3, 4), v_t_248, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_24118;
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    switch (heff_tag_of(v_field_2411)) {
    case TAG_Nil: {
      V v_src_2413 = v_src_244;
      V v_x1_2414 = v_claim_246;
      V v_t_2447;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nothing: {
        v_t_2447 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_h_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        V v_error_2416 = heff_take_field(v_h_2415, 4);
        V v_name_2417 = heff_take_field(v_h_2415, 0);
        V v_listed_2418 = heff_take_field(v_h_2415, 1);
        V v_exposes_2419 = heff_take_field(v_h_2415, 2);
        V v_span_2420 = heff_get_n(v_h_2415, 3, 5);
        V v_t_2445;
        switch (heff_tag_of(v_error_2416)) {
        case TAG_Nothing: {
          V v_name_2421 = v_name_2417;
          V v_x2_2422 = v_listed_2418;
          V v_es_2423 = (g_list_2emap_24s1975257801x764827799(v_exposes_2419));
          if ((heff_dup(v_x2_2422) == NTAG(TAG_True))) {
            heff_drop(v_x2_2422);
            V v_t_2425;
            switch (heff_tag_of(v_name_2421)) {
            case TAG_Nothing: {
              v_t_2425 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str0);
              break;
            }
            case TAG_Just: {
              V v_name_2424 = heff_dup(heff_field(v_name_2421, 0));
              v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str1), v_name_2424);
              break;
            }
            default: heff_nomatch(v_name_2421);
            }
            V v_t_2428;
            switch (heff_tag_of(v_es_2423)) {
            case TAG_Nil: {
              v_t_2428 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str2);
              break;
            }
            case TAG_Cons: {
              V v_x_2426 = heff_dup(heff_field(v_es_2423, 0));
              V v_xs_2427 = heff_dup(heff_field(v_es_2423, 1));
              v_t_2428 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str3); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
              break;
            }
            default: heff_nomatch(v_es_2423);
            }
            V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str4)), v_t_2428);
            V v_t_2430 = heff_strLength(heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str5)));
            if ((heff_unbox_word(v_t_2430) <= ((int64_t)80ULL))) {
              V v_t_2432;
              switch (heff_tag_of(v_name_2421)) {
              case TAG_Nothing: {
                v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str6);
                break;
              }
              case TAG_Just: {
                V v_name_2431 = heff_field(v_name_2421, 0);
                heff_take_n(v_name_2421, 1ULL, 1);
                v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str7), v_name_2431);
                break;
              }
              default: heff_nomatch(v_name_2421);
              }
              V v_t_2435;
              switch (heff_tag_of(v_es_2423)) {
              case TAG_Nil: {
                v_t_2435 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str8);
                break;
              }
              case TAG_Cons: {
                V v_x_2433 = heff_field(v_es_2423, 0);
                V v_xs_2434 = heff_field(v_es_2423, 1);
                heff_take_n(v_es_2423, 3ULL, 2);
                v_t_2435 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str9); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
                break;
              }
              default: heff_nomatch(v_es_2423);
              }
              V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str10)), v_t_2435);
              v_t_2445 = heff_strAppend(v_t_2436, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str11));
            } else {
              V v_t_2438;
              switch (heff_tag_of(v_name_2421)) {
              case TAG_Nothing: {
                v_t_2438 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str12);
                break;
              }
              case TAG_Just: {
                V v_name_2437 = heff_field(v_name_2421, 0);
                heff_take_n(v_name_2421, 1ULL, 1);
                v_t_2438 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str13), v_name_2437);
                break;
              }
              default: heff_nomatch(v_name_2421);
              }
              V v_t_2441;
              switch (heff_tag_of(v_es_2423)) {
              case TAG_Nil: {
                v_t_2441 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str14);
                break;
              }
              case TAG_Cons: {
                V v_x_2439 = heff_field(v_es_2423, 0);
                V v_xs_2440 = heff_field(v_es_2423, 1);
                heff_take_n(v_es_2423, 3ULL, 2);
                v_t_2441 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str15); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
                break;
              }
              default: heff_nomatch(v_es_2423);
              }
              V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str16)), v_t_2441);
              v_t_2445 = heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str17));
            }
          } else {
            heff_drop(v_x2_2422);
            heff_drop(v_es_2423);
            switch (heff_tag_of(v_name_2421)) {
            case TAG_Nothing: {
              v_t_2445 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str18);
              break;
            }
            case TAG_Just: {
              V v_name_2443 = heff_field(v_name_2421, 0);
              heff_take_n(v_name_2421, 1ULL, 1);
              v_t_2445 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str19), v_name_2443);
              break;
            }
            default: heff_nomatch(v_name_2421);
            }
          }
          break;
        }
        case TAG_Just: {
          heff_take_n(v_error_2416, 0ULL, 1);
          heff_drop(v_name_2417);
          heff_drop(v_listed_2418);
          heff_drop(v_exposes_2419);
          v_t_2445 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str20);
          break;
        }
        default: heff_nomatch(v_error_2416);
        }
        V v_t_2446 = heff_rec_n(7, shape_kind__text__start__end__line__col__first, (V[]){((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str21), v_t_2445, heff_take_field(v_span_2420, 0), heff_get_n(v_span_2420, 1, 2), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True)});
        v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2448 = (g_list_2emap_24s1845612977x612508518(v_imports_247));
      V v_x2_2449 = (g_prelude_2e_2b_2b_24f489629841x1061860251(v_field_2410, v_t_2447, v_t_2448));
      V v_toks_2458;
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_Nil: {
        v_toks_2458 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_xs_2451 = heff_field(v_x2_2449, 1);
        V v_ru_24x2_2449_24Cons = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
        V v_t_2457;
        switch (heff_tag_of(v_xs_2451)) {
        case TAG_Nil: {
          V v_t_2452 = heff_tag_at_n(v_ru_24x2_2449_24Cons, TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
          v_t_2457 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          V v_y_2453 = heff_field(v_xs_2451, 0);
          V v_ys_2454 = heff_field(v_xs_2451, 1);
          V v_ru_24xs_2451_24Cons = heff_take_reuse_n(v_xs_2451, 3ULL, 2);
          if (heff_intLe_c(heff_dup(heff_rfield(v_x_2450, 2)), heff_dup(heff_rfield(v_y_2453, 2)))) {
            V v_t_2455 = heff_tag_at_n(v_ru_24x2_2449_24Cons, TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
            v_t_2457 = (g_list_2eascending_24s946492440x1788863194(heff_dup(v_y_2453), heff_tag_at_n(v_ru_24xs_2451_24Cons, TAG_Cons, 2, (V[]){v_y_2453, v_t_2455}), v_ys_2454));
          } else {
            V v_t_2456 = heff_tag_at_n(v_ru_24x2_2449_24Cons, TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
            v_t_2457 = (g_list_2edescending_24s1432586697x321478004(heff_dup(v_y_2453), heff_tag_at_n(v_ru_24xs_2451_24Cons, TAG_Cons, 2, (V[]){v_y_2453, v_t_2456}), v_ys_2454));
          }
          break;
        }
        default: heff_nomatch(v_xs_2451);
        }
        v_toks_2458 = (g_list_2emergeRuns_24s2052062657x972894659(NTAG(TAG_Nil), v_t_2457));
        break;
      }
      default: heff_nomatch(v_x2_2449);
      }
      V v_comments_2459 = v_field_2412;
      V v_t_2460 = (g_list_2emap_24s1409451498x400757684(v_toks_2458));
      V v_t_2461 = (g_list_2emap_24s32026788x2029987799(v_comments_2459));
      V v_x2_2462 = (g_prelude_2e_2b_2b(v_t_2460, v_t_2461));
      V v_es_2471;
      switch (heff_tag_of(v_x2_2462)) {
      case TAG_Nil: {
        v_es_2471 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_field(v_x2_2462, 0);
        V v_xs_2464 = heff_field(v_x2_2462, 1);
        V v_ru_24x2_2462_24Cons = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
        V v_t_2470;
        switch (heff_tag_of(v_xs_2464)) {
        case TAG_Nil: {
          V v_t_2465 = heff_tag_at_n(v_ru_24x2_2462_24Cons, TAG_Cons, 2, (V[]){v_x_2463, NTAG(TAG_Nil)});
          v_t_2470 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          V v_y_2466 = heff_field(v_xs_2464, 0);
          V v_ys_2467 = heff_field(v_xs_2464, 1);
          V v_ru_24xs_2464_24Cons = heff_take_reuse_n(v_xs_2464, 3ULL, 2);
          if (heff_intLe_c(heff_dup(heff_rfield(v_x_2463, 0)), heff_dup(heff_rfield(v_y_2466, 0)))) {
            V v_t_2468 = heff_tag_at_n(v_ru_24x2_2462_24Cons, TAG_Cons, 2, (V[]){v_x_2463, NTAG(TAG_Nil)});
            v_t_2470 = (g_list_2eascending_24s1547370222x166817322(heff_dup(v_y_2466), heff_tag_at_n(v_ru_24xs_2464_24Cons, TAG_Cons, 2, (V[]){v_y_2466, v_t_2468}), v_ys_2467));
          } else {
            V v_t_2469 = heff_tag_at_n(v_ru_24x2_2462_24Cons, TAG_Cons, 2, (V[]){v_x_2463, NTAG(TAG_Nil)});
            v_t_2470 = (g_list_2edescending_24s1706700342x2062518382(heff_dup(v_y_2466), heff_tag_at_n(v_ru_24xs_2464_24Cons, TAG_Cons, 2, (V[]){v_y_2466, v_t_2469}), v_ys_2467));
          }
          break;
        }
        default: heff_nomatch(v_xs_2464);
        }
        v_es_2471 = (g_list_2emergeRuns_24s1839386886x1884977030(NTAG(TAG_Nil), v_t_2470));
        break;
      }
      default: heff_nomatch(v_x2_2462);
      }
      V v_t_2472 = heff_rec_n(3, shape_line__offset__out, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)});
      V v_l_2473 = (g_list_2efoldl_24s1872971975x1696014049(heff_dup(v_src_2413), v_t_2472, v_es_2471));
      V v_t_2474 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_l_2473, 2, 3)));
      V v_elems_2475 = heff_arrayFromList(v_t_2474);
      V v_r_2476 = ({ V a_0 = heff_dup(v_src_2413); V a_1 = heff_dup(v_elems_2475); V a_2 = v_elems_2475; V a_3 = MK_INT(0LL); V a_4 = heff_dup(g_heff_2esyntax_2efmt_2etokens_2eemptyStA_get()); V r_ = (g_array_2efoldl_2efoldlFrom_240_24s1198473325x96359019(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_elems_2475); r_; });
      V v_toks_2477 = heff_take_field(v_r_2476, 2);
      V v_lead_2478 = heff_take_field(v_r_2476, 5);
      V v_inline_2479 = heff_take_field(v_r_2476, 6);
      V v_trail_2480 = heff_get_n(v_r_2476, 7, 10);
      V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_toks_2477));
      V v_at_2482 = heff_rec_n(2, shape_toks__env, (V[]){heff_arrayFromList(v_t_2481), heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_src_2413, v_lead_2478, v_inline_2479, v_trail_2480, MK_INT(-1LL), MK_INT(-1LL), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get())})});
      V v_t_2483 = heff_get_n(heff_dup(heff_rfield(v_at_2482, 1)), 0, 7);
      V v_t_2484 = heff_get_n(heff_dup(heff_rfield(v_at_2482, 1)), 1, 7);
      V v_t_2485 = heff_get_n(heff_dup(heff_rfield(v_at_2482, 1)), 2, 7);
      V v_t_2486 = heff_get_n(heff_dup(heff_rfield(v_at_2482, 1)), 3, 7);
      V v_t_2487 = heff_get_n(heff_dup(heff_rfield(v_at_2482, 1)), 4, 7);
      V v_t_2488 = heff_get_n(heff_dup(heff_rfield(v_at_2482, 1)), 5, 7);
      V v_at_2489 = ({ V rv_1 = heff_rec_n(7, shape_src__lead__inline__trail__noLead__noTrail__fix, (V[]){v_t_2483, v_t_2484, v_t_2485, v_t_2486, v_t_2487, v_t_2488, v_f_243}); V rr_ = heff_rec_reuse_nf(v_at_2482, 1ULL, 2, shape_toks__env, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_toks_2490 = heff_take_field(v_at_2489, 0);
      V v_env_2491 = heff_get_n(v_at_2489, 1, 2);
      V v_t_2492 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2493 = (g_heff_2esyntax_2ecst_2eprogramGo_24cpr(heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(v_toks_2490), MK_INT(0LL), MK_INT(0LL), v_t_2492, MK_INT(0LL)}), NTAG(TAG_Nil)));
      {
        V v_field_2495 = v_t_2493.f[1];
        int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
        if ((v_tag_2494 == ((int64_t)0ULL))) {
          heff_drop(v_toks_2490);
          heff_drop(v_env_2491);
          V v_e_2496 = v_field_2495;
          v_t_24118 = heff_tag_n(TAG_Left, 1, (V[]){v_e_2496});
        } else {
          V v_ds_2497 = v_field_2495;
          V v_ts_2498 = v_toks_2490;
          int64_t v_i_2499 = (heff_unbox_word(heff_arrayLength_lent(v_ts_2498, 0)) - ((int64_t)1ULL));
          V v_eof_24101;
          if (((((int64_t)0ULL) <= v_i_2499) && (v_i_2499 < heff_unbox_word(heff_arrayLength_lent(v_ts_2498, 0))))) {
            V v_t_24100 = heff_arrayIndexIn(v_ts_2498, heff_box_word(v_i_2499));
            v_eof_24101 = v_t_24100;
          } else {
            heff_drop(v_ts_2498);
            v_eof_24101 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str22), ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str23), ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str24), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          }
          V v_d_24102 = (g_heff_2esyntax_2efmt_2elayout_2etopLevelGo(v_env_2491, MK_INT(0LL), NTAG(TAG_False), v_eof_24101, v_ds_2497));
          V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){MK_INT(0LL), v_d_24102}), NTAG(TAG_Nil)});
          V v_s_24104 = (g_std_2edoc_2ebest(MK_INT(80LL), MK_INT(0LL), MK_INT(0LL), v_t_24103));
          V v_s_24105 = (g_std_2edoc_2edisplay_2edisplayInto_240(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str25), v_s_24104));
          V v_t_24106 = ({ V a_0 = v_s_24105; V b_1 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str26); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str27), v_s_24105, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_24105); heff_drop(b_1); r_; });
          V v_t_24107 = (g_list_2emap_24s725725455x1186198702(v_t_24106));
          V v_x2_24108 = (g_heff_2esyntax_2efmt_2elayout_2ekeptLines(v_t_24107));
          V v_s_24111;
          switch (heff_tag_of(v_x2_24108)) {
          case TAG_Nil: {
            v_s_24111 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str28);
            break;
          }
          case TAG_Cons: {
            V v_x_24109 = heff_field(v_x2_24108, 0);
            V v_xs_24110 = heff_field(v_x2_24108, 1);
            heff_take_n(v_x2_24108, 3ULL, 2);
            v_s_24111 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str29); V a_1 = v_x_24109; V a_2 = v_xs_24110; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24110); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24108);
          }
          V v_t_24115;
          if ((heff_unbox_word(heff_strLength(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()))) == ((int64_t)0ULL))) {
            v_t_24115 = v_s_24111;
          } else {
            V v_x2_24112 = ({ V a_0 = v_s_24111; V b_1 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_2 = MK_INT(0LL); V a_3 = heff_strFind(heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()), heff_dup(v_s_24111), MK_INT(0LL)); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_24111); heff_drop(b_1); r_; });
            switch (heff_tag_of(v_x2_24112)) {
            case TAG_Nil: {
              v_t_24115 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str30);
              break;
            }
            case TAG_Cons: {
              V v_x_24113 = heff_field(v_x2_24112, 0);
              V v_xs_24114 = heff_field(v_x2_24112, 1);
              heff_take_n(v_x2_24112, 3ULL, 2);
              v_t_24115 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str31); V a_1 = v_x_24113; V a_2 = v_xs_24114; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24114); r_; });
              break;
            }
            default: heff_nomatch(v_x2_24112);
            }
          }
          v_t_24118 = heff_tag_n(TAG_Right, 1, (V[]){heff_strAppend(v_t_24115, ((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str32))});
        }
      }
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_field_2411, 0ULL, 2);
      heff_drop(v_f_243);
      heff_drop(v_src_244);
      heff_drop(v_claim_246);
      heff_drop(v_imports_247);
      heff_drop(v_field_2410);
      heff_drop(v_field_2412);
      v_t_24118 = heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2eformatIn_24cpr_str33)});
      break;
    }
    default: heff_nomatch(v_field_2411);
    }
  }
  switch (heff_tag_of(v_t_24118)) {
  case TAG_Left: {
    V v_why_24119 = heff_field(v_t_24118, 0);
    heff_take_n(v_t_24118, 1ULL, 1);
    heff_drop(v_src_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_24119}});
  }
  case TAG_Right: {
    V v_out_24120 = heff_field(v_t_24118, 0);
    heff_take_n(v_t_24118, 1ULL, 1);
    V v_t_24121 = (g_heff_2esyntax_2eformat_2emeaning(heff_dup(v_src_241)));
    V v_t_24122 = (g_heff_2esyntax_2eformat_2emeaning(heff_dup(v_out_24120)));
    return (g_heff_2esyntax_2eformat_2esameMeaning_24cpr(v_src_241, v_out_24120, v_t_24121, v_t_24122));
  }
  default: return ((HeffT2){{heff_nomatch(v_t_24118)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eformat_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
  V v_src_242 = heff_get_n(v_t_241, 3, 4);
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_242, v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_245 = heff_arrayFromList(heff_get_n(v_t_244, 0, 3));
  V v_t_246 = (g_heff_2esyntax_2esurface_2efixDecls(v_ts_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(((V)&g_heff_2esyntax_2eformat_2eformat_24cpr_str0), v_t_246));
  return (g_heff_2esyntax_2eformat_2eformatIn_24cpr(heff_get_n(v_t_247, 0, 2), v_src_240));
}