// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_PathStatus 29154
#define TAG_Right 62770
#define TAG_WriteFile 62589
#define LBL_bytes 295582853
#define LBL_changed 970801394
#define LBL_decls 296817955
#define LBL_glob 9671231
#define LBL_home 9703846
#define LBL_keys 9783995
#define LBL_lbls 9810500
#define LBL_memo 9843201
#define LBL_memos 305139347
#define LBL_modified 129625309
#define LBL_name 9869138
#define LBL_size 10026184
#define LBL_sizes 310811820
#define LBL_tags 10047712
#define LBL_vers 10111479
static uint32_t shape_changed__memos[] = {LBL_changed, LBL_memos};
static uint32_t shape_name__home__keys__vers__sizes__tags__lbls__decls__glob__bytes__modified[] = {LBL_name, LBL_home, LBL_keys, LBL_vers, LBL_sizes, LBL_tags, LBL_lbls, LBL_decls, LBL_glob, LBL_bytes, LBL_modified};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam7(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0(V v_path_240, V v_text_241, V v_hd_242, V v_k_243, V v_p_244, V v_w_245, V v_x_246) {
top: ;
  V v_c_2443;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Left: {
    heff_take_n(v_x_246, 0ULL, 1);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_240)));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_249, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam0_clo)});
    v_c_2443 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam1, 2, 1, (V[]){v_a_2411});
    break;
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_2424, v_text_241, 1)) {
      heff_drop(v_text_241);
      v_c_2443 = ((V)&g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam3_clo);
    } else {
      V v_path_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_240)));
      V v_t_2428 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2427; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2427); r_; });
      V v_a_2430 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2428, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam4_clo)});
      v_c_2443 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam5, 2, 1, (V[]){v_a_2430});
    }
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  return heff_tail(v_c_2443, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam7, 1, 5, (V[]){v_path_240, v_hd_242, v_p_244, v_w_245, v_k_243})});
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2413 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2421 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    switch (heff_tag_of(v_y_2421)) {
    case TAG_Left: {
      heff_take_n(v_y_2421, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2413;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2421, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2413;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2421);
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2418, v_hd_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam2, 1, 1, (V[]){v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam4(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2432 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2432;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2438, 0);
    heff_take_n(v_x_2438, 1ULL, 1);
    switch (heff_tag_of(v_y_2440)) {
    case TAG_Left: {
      heff_take_n(v_y_2440, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2432;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2440, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2432;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2440);
    }
  }
  default: return heff_nomatch(v_x_2438);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_a_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2430})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2437, v_hd_2431, heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam6, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam8(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_w_245 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Left: {
    V v_ru_24x_2454_24Left = heff_take_reuse_n(v_x_2454, 0ULL, 1);
    V v_t_2459;
    heff_clo_take(self, 4);
    if ((heff_dup(v_x_2444) == NTAG(TAG_True))) {
      heff_drop(v_x_2444);
      V v_t_2456 = heff_get_n(v_p_244, 1, 3);
      V v_t_2458;
      switch (heff_tag_of(v_t_2456)) {
      case TAG_Nothing: {
        v_t_2458 = v_w_245;
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2456, 0ULL, 1);
        v_t_2458 = ({ V rv_0 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_w_245, 2ULL, 2, shape_changed__memos, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        break;
      }
      default: heff_nomatch(v_t_2456);
      }
      v_t_2459 = heff_tag_at_n(v_ru_24x_2454_24Left, TAG_Just, 1, (V[]){v_t_2458});
    } else {
      heff_drop(v_x_2444);
      heff_drop_rec(v_p_244, 3);
      heff_drop_rec(v_w_245, 2);
      heff_drop_cell(v_ru_24x_2454_24Left, 1);
      v_t_2459 = NTAG(TAG_Nothing);
    }
    V f_ = v_k_243;
    args[0] = v_t_2459;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2460 = heff_field(v_x_2454, 0);
    V v_ru_24x_2454_24Right = heff_take_reuse_n(v_x_2454, 1ULL, 1);
    switch (heff_tag_of(v_y_2460)) {
    case TAG_Left: {
      heff_take_n(v_y_2460, 0ULL, 1);
      V v_t_2465;
      heff_clo_take(self, 4);
      if ((heff_dup(v_x_2444) == NTAG(TAG_True))) {
        heff_drop(v_x_2444);
        V v_t_2462 = heff_get_n(v_p_244, 1, 3);
        V v_t_2464;
        switch (heff_tag_of(v_t_2462)) {
        case TAG_Nothing: {
          v_t_2464 = v_w_245;
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2462, 0ULL, 1);
          v_t_2464 = ({ V rv_0 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_w_245, 2ULL, 2, shape_changed__memos, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          break;
        }
        default: heff_nomatch(v_t_2462);
        }
        v_t_2465 = heff_tag_at_n(v_ru_24x_2454_24Right, TAG_Just, 1, (V[]){v_t_2464});
      } else {
        heff_drop(v_x_2444);
        heff_drop_rec(v_p_244, 3);
        heff_drop_rec(v_w_245, 2);
        heff_drop_cell(v_ru_24x_2454_24Right, 1);
        v_t_2465 = NTAG(TAG_Nothing);
      }
      V f_ = v_k_243;
      args[0] = v_t_2465;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2466 = heff_field(v_y_2460, 0);
      heff_take_n(v_y_2460, 1ULL, 1);
      V v_x_2476;
      heff_clo_take(self, 4);
      if ((heff_dup(v_x_2444) == NTAG(TAG_True))) {
        heff_drop(v_x_2444);
        V v_lit_2467 = v_x_2466;
        V v_size_2468 = heff_take_field(v_lit_2467, 1);
        V v_modified_2469 = heff_get_n(v_lit_2467, 2, 4);
        V v_x1_2470 = heff_get_n(v_p_244, 1, 3);
        V v_w_2471 = v_w_245;
        V v_t_2475;
        switch (heff_tag_of(v_x1_2470)) {
        case TAG_Nothing: {
          heff_drop(v_size_2468);
          heff_drop(v_modified_2469);
          v_t_2475 = v_w_2471;
          break;
        }
        case TAG_Just: {
          V v_m_2472 = heff_field(v_x1_2470, 0);
          heff_take_n(v_x1_2470, 1ULL, 1);
          V v_t_2473 = ({ V rv_9 = v_size_2468; V rv_10 = v_modified_2469; V rr_ = heff_rec_reuse_nf(v_m_2472, 511ULL, 11, shape_name__home__keys__vers__sizes__tags__lbls__decls__glob__bytes__modified, 262143u, 0u); heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 10) = rv_10; rr_; });
          V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, heff_take_field(v_w_2471, 1)});
          v_t_2475 = ({ V rv_0 = NTAG(TAG_True); V rv_1 = v_t_2474; V rr_ = heff_rec_reuse_nf(v_w_2471, 0ULL, 2, shape_changed__memos, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        default: heff_nomatch(v_x1_2470);
        }
        v_x_2476 = heff_tag_at_n(v_ru_24x_2454_24Right, TAG_Just, 1, (V[]){v_t_2475});
      } else {
        heff_drop(v_x_2444);
        heff_drop_rec(v_p_244, 3);
        heff_drop_rec(v_w_245, 2);
        heff_drop_cell(v_ru_24x_2454_24Right, 1);
        heff_drop(v_x_2466);
        v_x_2476 = NTAG(TAG_Nothing);
      }
      V f_ = v_k_243;
      args[0] = v_x_2476;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2460);
    }
  }
  default: return heff_nomatch(v_x_2454);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam7(V self, V *args) {
  V v_x_2444 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_w_245 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2445 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
  V v_t_2446 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2445; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2445); r_; });
  V v_a_2448 = heff_tag_n(TAG_PathStatus, 3, (V[]){v_t_2446, NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam8_clo)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2453, v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePart_24s1747401419x1365718330_2ek_24l0_lam9, 1, 4, (V[]){v_x_2444, v_p_244, v_w_245, v_k_243})));
}