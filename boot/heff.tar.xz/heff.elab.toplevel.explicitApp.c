// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
V g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240(V);
V g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240_clo;
Clo g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_ArgExplicit: {
      return NTAG(TAG_True);
    }
    case TAG_ArgProject: {
      return NTAG(TAG_False);
    }
    case TAG_ArgNamed: {
      return NTAG(TAG_False);
    }
    case TAG_ArgEvidence: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eexplicitApp_2eisExplicitArg_240(a0); heff_drop(a0); return r;
}