// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_fix 310927
#define LBL_head 9693863
#define LBL_held 9694204
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_sigs 10025609
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__span__ty__eqns__whole[] = {LBL_name, LBL_span, LBL_ty, LBL_eqns, LBL_whole};
static uint32_t shape_sigs__held__rest[] = {LBL_sigs, LBL_held, LBL_rest};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2ebothLoosest(V, V, V);
V g_heff_2esyntax_2efixity_2ebothLoosest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2ebothLoosest_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2earrowNames(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V, V, V);
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V, V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
double g_heff_2esyntax_2esurface_2efloatSplit_w(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatSplit_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2egroupFrom(V, V);
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupFrom_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eipow10(V);
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eipow10_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V, V);
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2epickSig_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2erevOnto(V, V);
V g_heff_2esyntax_2esurface_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erevOnto_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_clo;
V g_heff_2esyntax_2esurface_2eunitIn(V, V);
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitIn_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_prelude_2etraverse_24s956608878x365908798(V);
V g_prelude_2etraverse_24s956608878x365908798_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s956608878x365908798_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eintOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintOfText_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eintOfText(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str0))) {
    V v_t_242 = (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    return heff_intSub(MK_INT(0LL), v_t_242);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str1))) {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    } else {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(0LL)));
    }
  }
}
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintOfText(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2efloatSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatSplit_entry, 2, 0};

double g_heff_2esyntax_2esurface_2efloatSplit_w(V v_s_240, V v_eAt_241) {
top: ;
  V v_m_242 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2);
  V v_d_243 = ({ V b_0 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_247;
  if (heff_intLe_c(heff_strLength_lent(v_m_242, 0), heff_dup(v_d_243))) {
    heff_drop(v_d_243);
    v_m_247 = ({ V a_0 = v_m_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_m_242); r_; });
  } else {
    V v_t_245 = heff_strSlice(heff_dup(v_m_242), heff_intAdd(heff_dup(v_d_243), MK_INT(1LL)), heff_strLength_lent(v_m_242, 0));
    V v_t_246 = heff_strAppend(heff_strSlice(v_m_242, MK_INT(0LL), v_d_243), v_t_245);
    v_m_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_246); r_; });
  }
  V v_t_2410;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_eAt_241))) {
    v_t_2410 = MK_INT(0LL);
  } else {
    V v_t_249 = heff_strSlice(heff_dup(v_s_240), heff_intAdd(heff_dup(v_eAt_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0));
    v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2esyntax_2esurface_2eexpOf(a_0)); heff_drop(v_t_249); r_; });
  }
  V v_m_2411 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2);
  V v_d_2412 = ({ V b_0 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 6); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2415;
  if (heff_intLe_c(heff_strLength_lent(v_m_2411, 0), heff_dup(v_d_2412))) {
    heff_drop(v_m_2411);
    heff_drop(v_d_2412);
    v_t_2415 = MK_INT(0LL);
  } else {
    V v_t_2414 = heff_intSub(heff_strLength(v_m_2411), v_d_2412);
    v_t_2415 = heff_intSub(v_t_2414, MK_INT(1LL));
  }
  V v_p_2416 = heff_intSub(v_t_2410, v_t_2415);
  if (heff_intLe_c_lent(MK_INT(0LL), v_p_2416, 1)) {
    V v_t_2418 = (g_heff_2esyntax_2esurface_2eipow10(v_p_2416));
    return heff_from_int_f64(heff_intMul(v_m_247, v_t_2418));
  } else {
    V v_t_2419 = (g_heff_2esyntax_2esurface_2eipow10(heff_intSub(MK_INT(0LL), v_p_2416)));
    return (heff_from_int_f64(v_m_247) / heff_from_int_f64(v_t_2419));
  }
}
V g_heff_2esyntax_2esurface_2efloatSplit(V v_s_240, V v_eAt_241) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_eAt_241)));
}
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efloatSplit(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatOfDigits_entry, 1, 0};

double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_244 = ({ V a_0 = v_t_243; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_243); r_; });
    double v_t_245 = ({ V a_0 = v_t_242; V a_1 = v_t_244; double r_ = (g_heff_2esyntax_2esurface_2efloatSplit_w(a_0, a_1)); heff_drop(v_t_242); r_; });
    return ((0.0) - v_t_245);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str1))) {
      V v_t_247 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_248 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_249 = ({ V a_0 = v_t_248; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_248); r_; });
      return ({ V a_0 = v_t_247; V a_1 = v_t_249; double r_ = (g_heff_2esyntax_2esurface_2efloatSplit_w(a_0, a_1)); heff_drop(v_t_247); r_; });
    } else {
      V v_t_2410 = (g_heff_2esyntax_2esurface_2esplitExp(v_s_240, MK_INT(0LL)));
      return (g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_t_2410));
    }
  }
}
V g_heff_2esyntax_2esurface_2efloatOfDigits(V v_s_240) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_s_240)));
}
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efloatOfDigits(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2earrowNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowNames_entry, 6, 0};

V g_heff_2esyntax_2esurface_2earrowNames(V v_rhs_240, V v_g_241, V v_ty_242, V v_braces_243, V v_dflt_244, V v_orig_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_get_n(v_t_247, 1, 2)});
  V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a_0)); heff_drop_tag(v_t_248, 2); r_; });
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_orig_245);
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_241));
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2410, 0, 2), heff_get_n(v_t_2411, 1, 2)});
    return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2earrowNames_lam0, 2, 3, (V[]){v_braces_243, v_ty_242, v_dflt_244}); V a_1 = v_rhs_240; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop_tag(v_t_2412, 2); r_; });
  } else {
    heff_drop(v_g_241);
    heff_drop(v_ty_242);
    heff_drop(v_dflt_244);
    heff_drop(v_t_249);
    switch (heff_tag_of(v_braces_243)) {
    case TAG_Nothing: {
      V v_t_2484 = (g_heff_2esyntax_2esurface_2eplainBinder(heff_dup(v_orig_245)));
      V v_t_2487;
      switch (heff_tag_of(v_orig_245)) {
      case TAG_At: {
        V v_s_2486 = heff_field(v_orig_245, 1);
        heff_take_n(v_orig_245, 2ULL, 2);
        v_t_2487 = v_s_2486;
        break;
      }
      default: heff_nomatch(v_orig_245);
      }
      V v_t_2490;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2489 = heff_dup(heff_field(v_rhs_240, 1));
        v_t_2490 = v_s_2489;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2491 = ({ V rv_1 = heff_get_n(v_t_2490, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2487, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EPi, 2, (V[]){v_t_2484, v_rhs_240}), v_t_2491});
    }
    case TAG_Just: {
      V v_bsp_2492 = heff_field(v_braces_243, 0);
      V v_ru_24braces_243_24Just = heff_take_reuse_n(v_braces_243, 1ULL, 1);
      heff_drop(v_orig_245);
      V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24braces_243_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_str0)}), heff_dup(v_bsp_2492)});
      V v_t_2494 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2493}), heff_dup(v_rhs_240)});
      V v_t_2497;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2496 = heff_field(v_rhs_240, 1);
        heff_take_n(v_rhs_240, 2ULL, 2);
        v_t_2497 = v_s_2496;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2498 = ({ V rv_1 = heff_get_n(v_t_2497, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2492, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2494, v_t_2498});
    }
    default: return heff_nomatch(v_braces_243);
    }
  }
}
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowNames(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_b_2414 = args[1];
  V v_braces_243 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_dflt_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_At: {
    V v_it1_2415 = heff_field(v_x_2413, 0);
    V v_ysp_2416 = heff_field(v_x_2413, 1);
    V v_ru_24x_2413_24At = heff_take_reuse_n(v_x_2413, 3ULL, 2);
    switch (heff_tag_of(v_it1_2415)) {
    case TAG_EVar: {
      V v_y_2417 = heff_field(v_it1_2415, 0);
      heff_take_n(v_it1_2415, 1ULL, 1);
      switch (heff_tag_of(v_braces_243)) {
      case TAG_Nothing: {
        heff_drop(v_dflt_244);
        V v_t_2418 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiNamed, 3, (V[]){v_y_2417, heff_dup(v_ysp_2416), v_ty_242}), heff_dup(v_b_2414)});
        V v_t_2421;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_ysp_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2413_24At, TAG_At, 2, (V[]){v_t_2418, v_t_2422});
      }
      case TAG_Just: {
        V v_bsp_2423 = heff_field(v_braces_243, 0);
        heff_take_n(v_braces_243, 1ULL, 1);
        V v_t_2424 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiImplicit, 5, (V[]){v_y_2417, v_ysp_2416, heff_dup(v_bsp_2423), v_ty_242, v_dflt_244}), heff_dup(v_b_2414)});
        V v_t_2427;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2413_24At, TAG_At, 2, (V[]){v_t_2424, v_t_2428});
      }
      default: return heff_nomatch(v_braces_243);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETag: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInt: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EString: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EBinary: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ERune: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWord: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EApp: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EProject: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EPi: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELam: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_2415, 0ULL, 4);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESig: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESum: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EDo: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EAssign: {
      heff_take_n(v_it1_2415, 0ULL, 3);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWhile: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EFor: {
      heff_take_n(v_it1_2415, 0ULL, 3);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EIfThen: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EBreak: {
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EContinue: {
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EReturn: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ENest: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELazy: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETuple: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETry: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWith: {
      heff_take_n(v_it1_2415, 0ULL, 4);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    default: return heff_nomatch(v_it1_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str1, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str2, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str3, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str4, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str5, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str6, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str7, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str8, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str9, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str10, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str11, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str12, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str13, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str14, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str15, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str16, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str17, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str18, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str19, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str20, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str21, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str22, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str23, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str24, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str25, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str26, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str27, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str28, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str29, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str30, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str31, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str32, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str33, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str34, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str35, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str36, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str37, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str38, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str39, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str40, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str41, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str42, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str43, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str44, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str45, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str46, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str47, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str48, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str49, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str50, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str51, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str52, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str53, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str54, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str55, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str56, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str57, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str58, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str59, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str60, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str61, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str62, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str63, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str64, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str65, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str66, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str67, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str68, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str69, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str70, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str71, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str72, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str73, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str74, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str75, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str76, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str77, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str78, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str79, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str80, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str81, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str82, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str83, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str84, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str85, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str86, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str87, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str88, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str89, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str90, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str91, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str92, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str93, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str94, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str95, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str96, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str97, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str98, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str99, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str100, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str101, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str102, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str103, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str104, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str105, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str106, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str107, 49, "an instance argument is named: `{{x : T}} -> ...`");
Clo g_heff_2esyntax_2esurface_2earrowBinop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowBinop_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowBinop(V v_x1_240, V v_rhs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Plain: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Plain = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_243 = heff_dup(heff_field(v_x11_242, 0));
      V v_sp_244 = heff_dup(heff_field(v_x11_242, 1));
      switch (heff_tag_of(v_x111_243)) {
      case TAG_EVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_246 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_249;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_248 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2412;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2413});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2415 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2418;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2417 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2418 = v_s_2417;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2421;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2422});
      }
      case TAG_ETag: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2424 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2427;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2430;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2429 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2431 = ({ V rv_1 = heff_get_n(v_t_2430, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2427, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2431});
      }
      case TAG_EInt: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2433 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2436;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2439;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2438 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2440 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2436, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2433, v_t_2440});
      }
      case TAG_EFloat: {
        heff_take_na(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2442 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2445;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2444 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2448;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2447 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2448 = v_s_2447;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2449 = ({ V rv_1 = heff_get_n(v_t_2448, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2445, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2449});
      }
      case TAG_EString: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2451 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2454;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2453 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2457;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2456 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2457 = v_s_2456;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2458 = ({ V rv_1 = heff_get_n(v_t_2457, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2454, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_t_2458});
      }
      case TAG_EBinary: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2460 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2463;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2462 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2466;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2465 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2466 = v_s_2465;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2467 = ({ V rv_1 = heff_get_n(v_t_2466, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2463, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2460, v_t_2467});
      }
      case TAG_ERune: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2469 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2472;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2471 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2475;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2474 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2476 = ({ V rv_1 = heff_get_n(v_t_2475, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2472, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_t_2476});
      }
      case TAG_EWord: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2478 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2481;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2480 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2481 = v_s_2480;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2484;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2483 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2485 = ({ V rv_1 = heff_get_n(v_t_2484, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2481, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2478, v_t_2485});
      }
      case TAG_EApp: {
        V v_ru_24x111_243_24EApp = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_2488 = heff_tag_at_n(v_ru_24x111_243_24EApp, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2491;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2490 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2491 = v_s_2490;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2494;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2493 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2495 = ({ V rv_1 = heff_get_n(v_t_2494, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2491, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2488, v_t_2495});
      }
      case TAG_EProject: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2497 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24100;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2499 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24100 = v_s_2499;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24103;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24102 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24104 = ({ V rv_1 = heff_get_n(v_t_24103, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24100, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2497, v_t_24104});
      }
      case TAG_ENamed: {
        V v_ru_24x111_243_24ENamed = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24107 = heff_tag_at_n(v_ru_24x111_243_24ENamed, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24110;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24109 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24110 = v_s_24109;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24113;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24112 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24114 = ({ V rv_1 = heff_get_n(v_t_24113, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24110, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24107, v_t_24114});
      }
      case TAG_EPi: {
        V v_ru_24x111_243_24EPi = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24117 = heff_tag_at_n(v_ru_24x111_243_24EPi, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24120;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24119 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24120 = v_s_24119;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24123;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24122 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24124 = ({ V rv_1 = heff_get_n(v_t_24123, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24120, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24117, v_t_24124});
      }
      case TAG_ELam: {
        V v_ru_24x111_243_24ELam = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24127 = heff_tag_at_n(v_ru_24x111_243_24ELam, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24130;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24129 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24130 = v_s_24129;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24133;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24132 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24133 = v_s_24132;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24134 = ({ V rv_1 = heff_get_n(v_t_24133, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24130, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24127, v_t_24134});
      }
      case TAG_EAnn: {
        V v_g_24135 = heff_field(v_x111_243, 0);
        V v_ty_24136 = heff_field(v_x111_243, 1);
        V v_ru_24x111_243_24EAnn = heff_take_reuse_n(v_x111_243, 3ULL, 2);
        heff_drop_tag(v_x11_242, 2);
        heff_drop_cell(v_ru_24x1_240_24Plain, 1);
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x111_243_24EAnn, TAG_EAnn, 2, (V[]){heff_dup(v_g_24135), heff_dup(v_ty_24136)}), v_sp_244});
        return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_24135, v_ty_24136, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_t_24137));
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_243, 0ULL, 4);
        heff_drop(v_sp_244);
        V v_t_24142 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24145;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24144 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24148;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24147 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24148 = v_s_24147;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24149 = ({ V rv_1 = heff_get_n(v_t_24148, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24145, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24142, v_t_24149});
      }
      case TAG_ESig: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24151 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24154;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24153 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24154 = v_s_24153;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24157;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24156 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24157 = v_s_24156;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24158 = ({ V rv_1 = heff_get_n(v_t_24157, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24154, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24151, v_t_24158});
      }
      case TAG_ESum: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24160 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24163;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24162 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24163 = v_s_24162;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24166;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24165 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24166 = v_s_24165;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24167 = ({ V rv_1 = heff_get_n(v_t_24166, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24163, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24160, v_t_24167});
      }
      case TAG_EStruct: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24169 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24172;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24171 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24172 = v_s_24171;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24175;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24174 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24175 = v_s_24174;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24176 = ({ V rv_1 = heff_get_n(v_t_24175, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24172, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24169, v_t_24176});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_243_24EUpdate = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24179 = heff_tag_at_n(v_ru_24x111_243_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24182;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24181 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24182 = v_s_24181;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24185;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24184 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24185 = v_s_24184;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24186 = ({ V rv_1 = heff_get_n(v_t_24185, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24182, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24179, v_t_24186});
      }
      case TAG_EMatch: {
        V v_ru_24x111_243_24EMatch = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24189 = heff_tag_at_n(v_ru_24x111_243_24EMatch, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24192;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24191 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24192 = v_s_24191;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24195;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24194 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24195 = v_s_24194;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24196 = ({ V rv_1 = heff_get_n(v_t_24195, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24192, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24189, v_t_24196});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_243_24ELetIn = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24199 = heff_tag_at_n(v_ru_24x111_243_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24202;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24201 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24202 = v_s_24201;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24205;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24204 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24205 = v_s_24204;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24206 = ({ V rv_1 = heff_get_n(v_t_24205, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24202, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24199, v_t_24206});
      }
      case TAG_EDo: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24208 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24211;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24210 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24214;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24213 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24214 = v_s_24213;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24215 = ({ V rv_1 = heff_get_n(v_t_24214, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24211, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24208, v_t_24215});
      }
      case TAG_ELocal: {
        V v_ru_24x111_243_24ELocal = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24218 = heff_tag_at_n(v_ru_24x111_243_24ELocal, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24221;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24220 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24221 = v_s_24220;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24224;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24223 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24224 = v_s_24223;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24225 = ({ V rv_1 = heff_get_n(v_t_24224, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24221, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24218, v_t_24225});
      }
      case TAG_EInvalid: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24227 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24230;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24229 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24233;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24232 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24233 = v_s_24232;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24234 = ({ V rv_1 = heff_get_n(v_t_24233, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24230, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24227, v_t_24234});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop(v_sp_244);
        V v_t_24238 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24241;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24240 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24241 = v_s_24240;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24244;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24243 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24244 = v_s_24243;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24245 = ({ V rv_1 = heff_get_n(v_t_24244, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24241, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24238, v_t_24245});
      }
      case TAG_EWhile: {
        V v_ru_24x111_243_24EWhile = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24248 = heff_tag_at_n(v_ru_24x111_243_24EWhile, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24251;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24250 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24251 = v_s_24250;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24254;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24253 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24254 = v_s_24253;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24255 = ({ V rv_1 = heff_get_n(v_t_24254, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24251, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24248, v_t_24255});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop(v_sp_244);
        V v_t_24259 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24262;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24261 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24262 = v_s_24261;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24265;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24264 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24265 = v_s_24264;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24266 = ({ V rv_1 = heff_get_n(v_t_24265, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24262, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24259, v_t_24266});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_243_24EIfThen = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24269 = heff_tag_at_n(v_ru_24x111_243_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24272;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24271 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24272 = v_s_24271;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24275;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24274 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24275 = v_s_24274;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24276 = ({ V rv_1 = heff_get_n(v_t_24275, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24272, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24269, v_t_24276});
      }
      case TAG_EBreak: {
        heff_drop(v_sp_244);
        V v_t_24277 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24280;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24279 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24280 = v_s_24279;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24283;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24282 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24283 = v_s_24282;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24284 = ({ V rv_1 = heff_get_n(v_t_24283, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24280, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24277, v_t_24284});
      }
      case TAG_EContinue: {
        heff_drop(v_sp_244);
        V v_t_24285 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24288;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24287 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24288 = v_s_24287;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24291;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24290 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24292 = ({ V rv_1 = heff_get_n(v_t_24291, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24288, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24285, v_t_24292});
      }
      case TAG_EReturn: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24294 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24297;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24296 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24297 = v_s_24296;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24300;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24299 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24300 = v_s_24299;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24301 = ({ V rv_1 = heff_get_n(v_t_24300, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24297, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24294, v_t_24301});
      }
      case TAG_ENest: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24303 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24306;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24305 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24306 = v_s_24305;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24309;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24308 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24309 = v_s_24308;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24310 = ({ V rv_1 = heff_get_n(v_t_24309, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24306, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24303, v_t_24310});
      }
      case TAG_ELazy: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24312 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24315;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24314 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24315 = v_s_24314;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24318;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24317 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24318 = v_s_24317;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24319 = ({ V rv_1 = heff_get_n(v_t_24318, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24315, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24312, v_t_24319});
      }
      case TAG_ETuple: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24321 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24324;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24323 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24324 = v_s_24323;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24327;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24326 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24327 = v_s_24326;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24328 = ({ V rv_1 = heff_get_n(v_t_24327, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24324, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24321, v_t_24328});
      }
      case TAG_ETry: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24330 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24333;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24332 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24333 = v_s_24332;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24336;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24335 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24336 = v_s_24335;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24337 = ({ V rv_1 = heff_get_n(v_t_24336, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24333, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24330, v_t_24337});
      }
      case TAG_EWith: {
        heff_take_n(v_x111_243, 0ULL, 4);
        heff_drop(v_sp_244);
        V v_t_24342 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24345;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24344 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24345 = v_s_24344;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24348;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24347 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24348 = v_s_24347;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24349 = ({ V rv_1 = heff_get_n(v_t_24348, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24345, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24342, v_t_24349});
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_Braced: {
    V v_x11_24350 = heff_field(v_x1_240, 0);
    V v_dflt_24351 = heff_field(v_x1_240, 1);
    V v_bsp_24352 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x11_24350)) {
    case TAG_At: {
      V v_x111_24353 = heff_field(v_x11_24350, 0);
      V v_sp_24354 = heff_field(v_x11_24350, 1);
      V v_ru_24x11_24350_24At = heff_take_reuse_n(v_x11_24350, 3ULL, 2);
      switch (heff_tag_of(v_x111_24353)) {
      case TAG_EVar: {
        V v_ru_24x111_24353_24EVar = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24356 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str0)}), heff_dup(v_bsp_24352)});
        V v_t_24357 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EVar, TAG_PiAnon, 1, (V[]){v_t_24356}), heff_dup(v_rhs_241)});
        V v_t_24360;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24359 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24360 = v_s_24359;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24361 = ({ V rv_1 = heff_get_n(v_t_24360, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24357, v_t_24361});
      }
      case TAG_EImplicitVar: {
        V v_ru_24x111_24353_24EImplicitVar = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24363 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str1)}), heff_dup(v_bsp_24352)});
        V v_t_24364 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_t_24363}), heff_dup(v_rhs_241)});
        V v_t_24367;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24366 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24367 = v_s_24366;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24368 = ({ V rv_1 = heff_get_n(v_t_24367, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24364, v_t_24368});
      }
      case TAG_ETag: {
        V v_ru_24x111_24353_24ETag = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24370 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str2)}), heff_dup(v_bsp_24352)});
        V v_t_24371 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ETag, TAG_PiAnon, 1, (V[]){v_t_24370}), heff_dup(v_rhs_241)});
        V v_t_24374;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24373 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24374 = v_s_24373;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24375 = ({ V rv_1 = heff_get_n(v_t_24374, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24371, v_t_24375});
      }
      case TAG_EInt: {
        V v_ru_24x111_24353_24EInt = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24377 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str3)}), heff_dup(v_bsp_24352)});
        V v_t_24378 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EInt, TAG_PiAnon, 1, (V[]){v_t_24377}), heff_dup(v_rhs_241)});
        V v_t_24381;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24380 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24381 = v_s_24380;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24382 = ({ V rv_1 = heff_get_n(v_t_24381, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24378, v_t_24382});
      }
      case TAG_EFloat: {
        V v_ru_24x111_24353_24EFloat = heff_take_reuse_na(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24384 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str4)}), heff_dup(v_bsp_24352)});
        V v_t_24385 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EFloat, TAG_PiAnon, 1, (V[]){v_t_24384}), heff_dup(v_rhs_241)});
        V v_t_24388;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24387 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24388 = v_s_24387;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24389 = ({ V rv_1 = heff_get_n(v_t_24388, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24385, v_t_24389});
      }
      case TAG_EString: {
        V v_ru_24x111_24353_24EString = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24391 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str5)}), heff_dup(v_bsp_24352)});
        V v_t_24392 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EString, TAG_PiAnon, 1, (V[]){v_t_24391}), heff_dup(v_rhs_241)});
        V v_t_24395;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24394 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24395 = v_s_24394;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24396 = ({ V rv_1 = heff_get_n(v_t_24395, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24392, v_t_24396});
      }
      case TAG_EBinary: {
        V v_ru_24x111_24353_24EBinary = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24398 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str6)}), heff_dup(v_bsp_24352)});
        V v_t_24399 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EBinary, TAG_PiAnon, 1, (V[]){v_t_24398}), heff_dup(v_rhs_241)});
        V v_t_24402;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24401 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24402 = v_s_24401;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24403 = ({ V rv_1 = heff_get_n(v_t_24402, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24399, v_t_24403});
      }
      case TAG_ERune: {
        V v_ru_24x111_24353_24ERune = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24405 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str7)}), heff_dup(v_bsp_24352)});
        V v_t_24406 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ERune, TAG_PiAnon, 1, (V[]){v_t_24405}), heff_dup(v_rhs_241)});
        V v_t_24409;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24408 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24409 = v_s_24408;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24410 = ({ V rv_1 = heff_get_n(v_t_24409, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24406, v_t_24410});
      }
      case TAG_EWord: {
        V v_ru_24x111_24353_24EWord = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24412 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str8)}), heff_dup(v_bsp_24352)});
        V v_t_24413 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EWord, TAG_PiAnon, 1, (V[]){v_t_24412}), heff_dup(v_rhs_241)});
        V v_t_24416;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24415 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24416 = v_s_24415;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24417 = ({ V rv_1 = heff_get_n(v_t_24416, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24413, v_t_24417});
      }
      case TAG_EApp: {
        V v_ru_24x111_24353_24EApp = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24420 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str9)}), heff_dup(v_bsp_24352)});
        V v_t_24421 = heff_tag_at_n(v_ru_24x111_24353_24EApp, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24420}), heff_dup(v_rhs_241)});
        V v_t_24424;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24423 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24424 = v_s_24423;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24425 = ({ V rv_1 = heff_get_n(v_t_24424, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24421, v_t_24425});
      }
      case TAG_EProject: {
        V v_ru_24x111_24353_24EProject = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24427 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str10)}), heff_dup(v_bsp_24352)});
        V v_t_24428 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EProject, TAG_PiAnon, 1, (V[]){v_t_24427}), heff_dup(v_rhs_241)});
        V v_t_24431;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24430 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24431 = v_s_24430;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24432 = ({ V rv_1 = heff_get_n(v_t_24431, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24428, v_t_24432});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24353_24ENamed = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24435 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str11)}), heff_dup(v_bsp_24352)});
        V v_t_24436 = heff_tag_at_n(v_ru_24x111_24353_24ENamed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24435}), heff_dup(v_rhs_241)});
        V v_t_24439;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24438 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24439 = v_s_24438;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24440 = ({ V rv_1 = heff_get_n(v_t_24439, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24436, v_t_24440});
      }
      case TAG_EPi: {
        V v_ru_24x111_24353_24EPi = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24443 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str12)}), heff_dup(v_bsp_24352)});
        V v_t_24444 = heff_tag_at_n(v_ru_24x111_24353_24EPi, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24443}), heff_dup(v_rhs_241)});
        V v_t_24447;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24446 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24447 = v_s_24446;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24448 = ({ V rv_1 = heff_get_n(v_t_24447, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24444, v_t_24448});
      }
      case TAG_ELam: {
        V v_ru_24x111_24353_24ELam = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24451 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str13)}), heff_dup(v_bsp_24352)});
        V v_t_24452 = heff_tag_at_n(v_ru_24x111_24353_24ELam, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24451}), heff_dup(v_rhs_241)});
        V v_t_24455;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24454 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24455 = v_s_24454;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24456 = ({ V rv_1 = heff_get_n(v_t_24455, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24452, v_t_24456});
      }
      case TAG_EAnn: {
        V v_g_24457 = heff_field(v_x111_24353, 0);
        V v_ty_24458 = heff_field(v_x111_24353, 1);
        heff_take_n(v_x111_24353, 3ULL, 2);
        V v_t_24459 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){heff_dup(v_g_24457), heff_dup(v_ty_24458)}), v_sp_24354});
        return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_24457, v_ty_24458, heff_tag_n(TAG_Just, 1, (V[]){v_bsp_24352}), v_dflt_24351, v_t_24459));
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24353, 0ULL, 4);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24464 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str14)}), heff_dup(v_bsp_24352)});
        V v_t_24465 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24464}), heff_dup(v_rhs_241)});
        V v_t_24468;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24467 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24468 = v_s_24467;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24469 = ({ V rv_1 = heff_get_n(v_t_24468, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24465, v_t_24469});
      }
      case TAG_ESig: {
        V v_ru_24x111_24353_24ESig = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24471 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str15)}), heff_dup(v_bsp_24352)});
        V v_t_24472 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ESig, TAG_PiAnon, 1, (V[]){v_t_24471}), heff_dup(v_rhs_241)});
        V v_t_24475;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24474 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24475 = v_s_24474;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24476 = ({ V rv_1 = heff_get_n(v_t_24475, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24472, v_t_24476});
      }
      case TAG_ESum: {
        V v_ru_24x111_24353_24ESum = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24478 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str16)}), heff_dup(v_bsp_24352)});
        V v_t_24479 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ESum, TAG_PiAnon, 1, (V[]){v_t_24478}), heff_dup(v_rhs_241)});
        V v_t_24482;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24481 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24482 = v_s_24481;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24483 = ({ V rv_1 = heff_get_n(v_t_24482, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24479, v_t_24483});
      }
      case TAG_EStruct: {
        V v_ru_24x111_24353_24EStruct = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24485 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str17)}), heff_dup(v_bsp_24352)});
        V v_t_24486 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EStruct, TAG_PiAnon, 1, (V[]){v_t_24485}), heff_dup(v_rhs_241)});
        V v_t_24489;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24488 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24489 = v_s_24488;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24490 = ({ V rv_1 = heff_get_n(v_t_24489, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24486, v_t_24490});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24353_24EUpdate = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24493 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str18)}), heff_dup(v_bsp_24352)});
        V v_t_24494 = heff_tag_at_n(v_ru_24x111_24353_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24493}), heff_dup(v_rhs_241)});
        V v_t_24497;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24496 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24497 = v_s_24496;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24498 = ({ V rv_1 = heff_get_n(v_t_24497, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24494, v_t_24498});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24353_24EMatch = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24501 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str19)}), heff_dup(v_bsp_24352)});
        V v_t_24502 = heff_tag_at_n(v_ru_24x111_24353_24EMatch, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24501}), heff_dup(v_rhs_241)});
        V v_t_24505;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24504 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24505 = v_s_24504;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24506 = ({ V rv_1 = heff_get_n(v_t_24505, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24502, v_t_24506});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24353_24ELetIn = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24509 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str20)}), heff_dup(v_bsp_24352)});
        V v_t_24510 = heff_tag_at_n(v_ru_24x111_24353_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24509}), heff_dup(v_rhs_241)});
        V v_t_24513;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24512 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24513 = v_s_24512;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24514 = ({ V rv_1 = heff_get_n(v_t_24513, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24510, v_t_24514});
      }
      case TAG_EDo: {
        V v_ru_24x111_24353_24EDo = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24516 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str21)}), heff_dup(v_bsp_24352)});
        V v_t_24517 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EDo, TAG_PiAnon, 1, (V[]){v_t_24516}), heff_dup(v_rhs_241)});
        V v_t_24520;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24519 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24520 = v_s_24519;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24521 = ({ V rv_1 = heff_get_n(v_t_24520, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24517, v_t_24521});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24353_24ELocal = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24524 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str22)}), heff_dup(v_bsp_24352)});
        V v_t_24525 = heff_tag_at_n(v_ru_24x111_24353_24ELocal, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24524}), heff_dup(v_rhs_241)});
        V v_t_24528;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24527 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24528 = v_s_24527;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24529 = ({ V rv_1 = heff_get_n(v_t_24528, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24525, v_t_24529});
      }
      case TAG_EInvalid: {
        V v_ru_24x111_24353_24EInvalid = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24531 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str23)}), heff_dup(v_bsp_24352)});
        V v_t_24532 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EInvalid, TAG_PiAnon, 1, (V[]){v_t_24531}), heff_dup(v_rhs_241)});
        V v_t_24535;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24534 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24535 = v_s_24534;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24536 = ({ V rv_1 = heff_get_n(v_t_24535, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24532, v_t_24536});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_24353, 0ULL, 3);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24540 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str24)}), heff_dup(v_bsp_24352)});
        V v_t_24541 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24540}), heff_dup(v_rhs_241)});
        V v_t_24544;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24543 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24544 = v_s_24543;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24545 = ({ V rv_1 = heff_get_n(v_t_24544, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24541, v_t_24545});
      }
      case TAG_EWhile: {
        V v_ru_24x111_24353_24EWhile = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24548 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str25)}), heff_dup(v_bsp_24352)});
        V v_t_24549 = heff_tag_at_n(v_ru_24x111_24353_24EWhile, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24548}), heff_dup(v_rhs_241)});
        V v_t_24552;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24551 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24552 = v_s_24551;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24553 = ({ V rv_1 = heff_get_n(v_t_24552, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24549, v_t_24553});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_24353, 0ULL, 3);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24557 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str26)}), heff_dup(v_bsp_24352)});
        V v_t_24558 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24557}), heff_dup(v_rhs_241)});
        V v_t_24561;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24560 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24561 = v_s_24560;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24562 = ({ V rv_1 = heff_get_n(v_t_24561, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24558, v_t_24562});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_24353_24EIfThen = heff_take_reuse_n(v_x111_24353, 0ULL, 2);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24565 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str27)}), heff_dup(v_bsp_24352)});
        V v_t_24566 = heff_tag_at_n(v_ru_24x111_24353_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24565}), heff_dup(v_rhs_241)});
        V v_t_24569;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24568 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24569 = v_s_24568;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24570 = ({ V rv_1 = heff_get_n(v_t_24569, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24566, v_t_24570});
      }
      case TAG_EBreak: {
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24571 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str28)}), heff_dup(v_bsp_24352)});
        V v_t_24572 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24571}), heff_dup(v_rhs_241)});
        V v_t_24575;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24574 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24575 = v_s_24574;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24576 = ({ V rv_1 = heff_get_n(v_t_24575, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24572, v_t_24576});
      }
      case TAG_EContinue: {
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24577 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str29)}), heff_dup(v_bsp_24352)});
        V v_t_24578 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24577}), heff_dup(v_rhs_241)});
        V v_t_24581;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24580 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24581 = v_s_24580;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24582 = ({ V rv_1 = heff_get_n(v_t_24581, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24578, v_t_24582});
      }
      case TAG_EReturn: {
        V v_ru_24x111_24353_24EReturn = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24584 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str30)}), heff_dup(v_bsp_24352)});
        V v_t_24585 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24EReturn, TAG_PiAnon, 1, (V[]){v_t_24584}), heff_dup(v_rhs_241)});
        V v_t_24588;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24587 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24588 = v_s_24587;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24589 = ({ V rv_1 = heff_get_n(v_t_24588, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24585, v_t_24589});
      }
      case TAG_ENest: {
        V v_ru_24x111_24353_24ENest = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24591 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str31)}), heff_dup(v_bsp_24352)});
        V v_t_24592 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ENest, TAG_PiAnon, 1, (V[]){v_t_24591}), heff_dup(v_rhs_241)});
        V v_t_24595;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24594 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24595 = v_s_24594;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24596 = ({ V rv_1 = heff_get_n(v_t_24595, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24592, v_t_24596});
      }
      case TAG_ELazy: {
        V v_ru_24x111_24353_24ELazy = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24598 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str32)}), heff_dup(v_bsp_24352)});
        V v_t_24599 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ELazy, TAG_PiAnon, 1, (V[]){v_t_24598}), heff_dup(v_rhs_241)});
        V v_t_24602;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24601 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24602 = v_s_24601;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24603 = ({ V rv_1 = heff_get_n(v_t_24602, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24599, v_t_24603});
      }
      case TAG_ETuple: {
        V v_ru_24x111_24353_24ETuple = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24605 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str33)}), heff_dup(v_bsp_24352)});
        V v_t_24606 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ETuple, TAG_PiAnon, 1, (V[]){v_t_24605}), heff_dup(v_rhs_241)});
        V v_t_24609;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24608 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24609 = v_s_24608;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24610 = ({ V rv_1 = heff_get_n(v_t_24609, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24606, v_t_24610});
      }
      case TAG_ETry: {
        V v_ru_24x111_24353_24ETry = heff_take_reuse_n(v_x111_24353, 0ULL, 1);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24612 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str34)}), heff_dup(v_bsp_24352)});
        V v_t_24613 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24353_24ETry, TAG_PiAnon, 1, (V[]){v_t_24612}), heff_dup(v_rhs_241)});
        V v_t_24616;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24615 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24616 = v_s_24615;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24617 = ({ V rv_1 = heff_get_n(v_t_24616, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24613, v_t_24617});
      }
      case TAG_EWith: {
        heff_take_n(v_x111_24353, 0ULL, 4);
        heff_drop(v_dflt_24351);
        heff_drop(v_sp_24354);
        V v_t_24622 = heff_tag_at_n(v_ru_24x11_24350_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str35)}), heff_dup(v_bsp_24352)});
        V v_t_24623 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24622}), heff_dup(v_rhs_241)});
        V v_t_24626;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24625 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24626 = v_s_24625;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24627 = ({ V rv_1 = heff_get_n(v_t_24626, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24352, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24623, v_t_24627});
      }
      default: return heff_nomatch(v_x111_24353);
      }
    }
    default: return heff_nomatch(v_x11_24350);
    }
  }
  case TAG_Bracketed: {
    V v_x11_24628 = heff_field(v_x1_240, 0);
    V v_bsp_24629 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Bracketed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24628)) {
    case TAG_At: {
      V v_x111_24630 = heff_field(v_x11_24628, 0);
      V v_ru_24x11_24628_24At = heff_take_reuse_n(v_x11_24628, 1ULL, 2);
      switch (heff_tag_of(v_x111_24630)) {
      case TAG_EVar: {
        V v_ru_24x111_24630_24EVar = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24633 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str36)}), heff_dup(v_bsp_24629)});
        V v_t_24634 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EVar, TAG_PiAnon, 1, (V[]){v_t_24633}), heff_dup(v_rhs_241)});
        V v_t_24637;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24636 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24637 = v_s_24636;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24638 = ({ V rv_1 = heff_get_n(v_t_24637, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24634, v_t_24638});
      }
      case TAG_EImplicitVar: {
        V v_ru_24x111_24630_24EImplicitVar = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24640 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str37)}), heff_dup(v_bsp_24629)});
        V v_t_24641 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_t_24640}), heff_dup(v_rhs_241)});
        V v_t_24644;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24643 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24644 = v_s_24643;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24645 = ({ V rv_1 = heff_get_n(v_t_24644, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24641, v_t_24645});
      }
      case TAG_ETag: {
        V v_ru_24x111_24630_24ETag = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24647 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str38)}), heff_dup(v_bsp_24629)});
        V v_t_24648 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ETag, TAG_PiAnon, 1, (V[]){v_t_24647}), heff_dup(v_rhs_241)});
        V v_t_24651;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24650 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24651 = v_s_24650;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24652 = ({ V rv_1 = heff_get_n(v_t_24651, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24648, v_t_24652});
      }
      case TAG_EInt: {
        V v_ru_24x111_24630_24EInt = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24654 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str39)}), heff_dup(v_bsp_24629)});
        V v_t_24655 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EInt, TAG_PiAnon, 1, (V[]){v_t_24654}), heff_dup(v_rhs_241)});
        V v_t_24658;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24657 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24658 = v_s_24657;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24659 = ({ V rv_1 = heff_get_n(v_t_24658, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24655, v_t_24659});
      }
      case TAG_EFloat: {
        V v_ru_24x111_24630_24EFloat = heff_take_reuse_na(v_x111_24630, 0ULL, 1);
        V v_t_24661 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str40)}), heff_dup(v_bsp_24629)});
        V v_t_24662 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EFloat, TAG_PiAnon, 1, (V[]){v_t_24661}), heff_dup(v_rhs_241)});
        V v_t_24665;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24664 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24665 = v_s_24664;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24666 = ({ V rv_1 = heff_get_n(v_t_24665, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24662, v_t_24666});
      }
      case TAG_EString: {
        V v_ru_24x111_24630_24EString = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24668 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str41)}), heff_dup(v_bsp_24629)});
        V v_t_24669 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EString, TAG_PiAnon, 1, (V[]){v_t_24668}), heff_dup(v_rhs_241)});
        V v_t_24672;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24671 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24672 = v_s_24671;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24673 = ({ V rv_1 = heff_get_n(v_t_24672, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24669, v_t_24673});
      }
      case TAG_EBinary: {
        V v_ru_24x111_24630_24EBinary = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24675 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str42)}), heff_dup(v_bsp_24629)});
        V v_t_24676 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EBinary, TAG_PiAnon, 1, (V[]){v_t_24675}), heff_dup(v_rhs_241)});
        V v_t_24679;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24678 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24679 = v_s_24678;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24680 = ({ V rv_1 = heff_get_n(v_t_24679, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24676, v_t_24680});
      }
      case TAG_ERune: {
        V v_ru_24x111_24630_24ERune = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24682 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str43)}), heff_dup(v_bsp_24629)});
        V v_t_24683 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ERune, TAG_PiAnon, 1, (V[]){v_t_24682}), heff_dup(v_rhs_241)});
        V v_t_24686;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24685 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24686 = v_s_24685;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24687 = ({ V rv_1 = heff_get_n(v_t_24686, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24683, v_t_24687});
      }
      case TAG_EWord: {
        V v_ru_24x111_24630_24EWord = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24689 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str44)}), heff_dup(v_bsp_24629)});
        V v_t_24690 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EWord, TAG_PiAnon, 1, (V[]){v_t_24689}), heff_dup(v_rhs_241)});
        V v_t_24693;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24692 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24693 = v_s_24692;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24694 = ({ V rv_1 = heff_get_n(v_t_24693, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24690, v_t_24694});
      }
      case TAG_EApp: {
        V v_ru_24x111_24630_24EApp = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_24697 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str45)}), heff_dup(v_bsp_24629)});
        V v_t_24698 = heff_tag_at_n(v_ru_24x111_24630_24EApp, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24697}), heff_dup(v_rhs_241)});
        V v_t_24701;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24700 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24701 = v_s_24700;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24702 = ({ V rv_1 = heff_get_n(v_t_24701, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24698, v_t_24702});
      }
      case TAG_EProject: {
        V v_ru_24x111_24630_24EProject = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_24704 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str46)}), heff_dup(v_bsp_24629)});
        V v_t_24705 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EProject, TAG_PiAnon, 1, (V[]){v_t_24704}), heff_dup(v_rhs_241)});
        V v_t_24708;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24707 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24708 = v_s_24707;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24709 = ({ V rv_1 = heff_get_n(v_t_24708, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24705, v_t_24709});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24630_24ENamed = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_24712 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str47)}), heff_dup(v_bsp_24629)});
        V v_t_24713 = heff_tag_at_n(v_ru_24x111_24630_24ENamed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24712}), heff_dup(v_rhs_241)});
        V v_t_24716;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24715 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24716 = v_s_24715;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24717 = ({ V rv_1 = heff_get_n(v_t_24716, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24713, v_t_24717});
      }
      case TAG_EPi: {
        V v_ru_24x111_24630_24EPi = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_24720 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str48)}), heff_dup(v_bsp_24629)});
        V v_t_24721 = heff_tag_at_n(v_ru_24x111_24630_24EPi, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24720}), heff_dup(v_rhs_241)});
        V v_t_24724;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24723 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24724 = v_s_24723;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24725 = ({ V rv_1 = heff_get_n(v_t_24724, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24721, v_t_24725});
      }
      case TAG_ELam: {
        V v_ru_24x111_24630_24ELam = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_24728 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str49)}), heff_dup(v_bsp_24629)});
        V v_t_24729 = heff_tag_at_n(v_ru_24x111_24630_24ELam, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24728}), heff_dup(v_rhs_241)});
        V v_t_24732;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24731 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24732 = v_s_24731;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24733 = ({ V rv_1 = heff_get_n(v_t_24732, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24729, v_t_24733});
      }
      case TAG_EAnn: {
        V v_x1111_24734 = heff_field(v_x111_24630, 0);
        V v_t_24735 = heff_field(v_x111_24630, 1);
        V v_ru_24x111_24630_24EAnn = heff_take_reuse_n(v_x111_24630, 3ULL, 2);
        switch (heff_tag_of(v_x1111_24734)) {
        case TAG_At: {
          V v_x11111_24736 = heff_field(v_x1111_24734, 0);
          V v_xsp_24737 = heff_field(v_x1111_24734, 1);
          heff_take_n(v_x1111_24734, 3ULL, 2);
          switch (heff_tag_of(v_x11111_24736)) {
          case TAG_EVar: {
            V v_x_24738 = heff_field(v_x11111_24736, 0);
            heff_take_n(v_x11111_24736, 1ULL, 1);
            heff_drop_cell(v_ru_24x111_24630_24EAnn, 2);
            V v_t_24739 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiInstance, 4, (V[]){v_x_24738, v_xsp_24737, heff_dup(v_bsp_24629), v_t_24735}), heff_dup(v_rhs_241)});
            V v_t_24742;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24741 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24742 = v_s_24741;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24743 = ({ V rv_1 = heff_get_n(v_t_24742, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24739, v_t_24743});
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24745 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str50)}), heff_dup(v_bsp_24629)});
            V v_t_24746 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24745}), heff_dup(v_rhs_241)});
            V v_t_24749;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24748 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24749 = v_s_24748;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24750 = ({ V rv_1 = heff_get_n(v_t_24749, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24746, v_t_24750});
          }
          case TAG_ETag: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24752 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str51)}), heff_dup(v_bsp_24629)});
            V v_t_24753 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24752}), heff_dup(v_rhs_241)});
            V v_t_24756;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24755 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24756 = v_s_24755;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24757 = ({ V rv_1 = heff_get_n(v_t_24756, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24753, v_t_24757});
          }
          case TAG_EInt: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24759 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str52)}), heff_dup(v_bsp_24629)});
            V v_t_24760 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24759}), heff_dup(v_rhs_241)});
            V v_t_24763;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24762 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24763 = v_s_24762;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24764 = ({ V rv_1 = heff_get_n(v_t_24763, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24760, v_t_24764});
          }
          case TAG_EFloat: {
            heff_take_na(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24766 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str53)}), heff_dup(v_bsp_24629)});
            V v_t_24767 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24766}), heff_dup(v_rhs_241)});
            V v_t_24770;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24769 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24770 = v_s_24769;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24771 = ({ V rv_1 = heff_get_n(v_t_24770, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24767, v_t_24771});
          }
          case TAG_EString: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24773 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str54)}), heff_dup(v_bsp_24629)});
            V v_t_24774 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24773}), heff_dup(v_rhs_241)});
            V v_t_24777;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24776 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24777 = v_s_24776;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24778 = ({ V rv_1 = heff_get_n(v_t_24777, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24774, v_t_24778});
          }
          case TAG_EBinary: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24780 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str55)}), heff_dup(v_bsp_24629)});
            V v_t_24781 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24780}), heff_dup(v_rhs_241)});
            V v_t_24784;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24783 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24784 = v_s_24783;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24785 = ({ V rv_1 = heff_get_n(v_t_24784, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24781, v_t_24785});
          }
          case TAG_ERune: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24787 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str56)}), heff_dup(v_bsp_24629)});
            V v_t_24788 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24787}), heff_dup(v_rhs_241)});
            V v_t_24791;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24790 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24791 = v_s_24790;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24792 = ({ V rv_1 = heff_get_n(v_t_24791, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24788, v_t_24792});
          }
          case TAG_EWord: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24794 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str57)}), heff_dup(v_bsp_24629)});
            V v_t_24795 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24794}), heff_dup(v_rhs_241)});
            V v_t_24798;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24797 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24798 = v_s_24797;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24799 = ({ V rv_1 = heff_get_n(v_t_24798, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24795, v_t_24799});
          }
          case TAG_EApp: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24802 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str58)}), heff_dup(v_bsp_24629)});
            V v_t_24803 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24802}), heff_dup(v_rhs_241)});
            V v_t_24806;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24805 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24806 = v_s_24805;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24807 = ({ V rv_1 = heff_get_n(v_t_24806, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24803, v_t_24807});
          }
          case TAG_EProject: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24809 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str59)}), heff_dup(v_bsp_24629)});
            V v_t_24810 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24809}), heff_dup(v_rhs_241)});
            V v_t_24813;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24812 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24813 = v_s_24812;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24814 = ({ V rv_1 = heff_get_n(v_t_24813, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24810, v_t_24814});
          }
          case TAG_ENamed: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24817 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str60)}), heff_dup(v_bsp_24629)});
            V v_t_24818 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24817}), heff_dup(v_rhs_241)});
            V v_t_24821;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24820 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24821 = v_s_24820;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24822 = ({ V rv_1 = heff_get_n(v_t_24821, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24818, v_t_24822});
          }
          case TAG_EPi: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24825 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str61)}), heff_dup(v_bsp_24629)});
            V v_t_24826 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24825}), heff_dup(v_rhs_241)});
            V v_t_24829;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24828 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24829 = v_s_24828;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24830 = ({ V rv_1 = heff_get_n(v_t_24829, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24826, v_t_24830});
          }
          case TAG_ELam: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24833 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str62)}), heff_dup(v_bsp_24629)});
            V v_t_24834 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24833}), heff_dup(v_rhs_241)});
            V v_t_24837;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24836 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24837 = v_s_24836;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24838 = ({ V rv_1 = heff_get_n(v_t_24837, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24834, v_t_24838});
          }
          case TAG_EAnn: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24841 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str63)}), heff_dup(v_bsp_24629)});
            V v_t_24842 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24841}), heff_dup(v_rhs_241)});
            V v_t_24845;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24844 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24845 = v_s_24844;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24846 = ({ V rv_1 = heff_get_n(v_t_24845, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24842, v_t_24846});
          }
          case TAG_ESpec: {
            heff_take_n(v_x11111_24736, 0ULL, 4);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24851 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str64)}), heff_dup(v_bsp_24629)});
            V v_t_24852 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24851}), heff_dup(v_rhs_241)});
            V v_t_24855;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24854 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24855 = v_s_24854;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24856 = ({ V rv_1 = heff_get_n(v_t_24855, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24852, v_t_24856});
          }
          case TAG_ESig: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24858 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str65)}), heff_dup(v_bsp_24629)});
            V v_t_24859 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24858}), heff_dup(v_rhs_241)});
            V v_t_24862;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24861 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24862 = v_s_24861;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24863 = ({ V rv_1 = heff_get_n(v_t_24862, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24859, v_t_24863});
          }
          case TAG_ESum: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24865 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str66)}), heff_dup(v_bsp_24629)});
            V v_t_24866 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24865}), heff_dup(v_rhs_241)});
            V v_t_24869;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24868 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24869 = v_s_24868;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24870 = ({ V rv_1 = heff_get_n(v_t_24869, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24866, v_t_24870});
          }
          case TAG_EStruct: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24872 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str67)}), heff_dup(v_bsp_24629)});
            V v_t_24873 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24872}), heff_dup(v_rhs_241)});
            V v_t_24876;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24875 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24876 = v_s_24875;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24877 = ({ V rv_1 = heff_get_n(v_t_24876, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24873, v_t_24877});
          }
          case TAG_EUpdate: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24880 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str68)}), heff_dup(v_bsp_24629)});
            V v_t_24881 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24880}), heff_dup(v_rhs_241)});
            V v_t_24884;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24883 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24884 = v_s_24883;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24885 = ({ V rv_1 = heff_get_n(v_t_24884, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24881, v_t_24885});
          }
          case TAG_EMatch: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24888 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str69)}), heff_dup(v_bsp_24629)});
            V v_t_24889 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24888}), heff_dup(v_rhs_241)});
            V v_t_24892;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24891 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24892 = v_s_24891;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24893 = ({ V rv_1 = heff_get_n(v_t_24892, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24889, v_t_24893});
          }
          case TAG_ELetIn: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24896 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str70)}), heff_dup(v_bsp_24629)});
            V v_t_24897 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24896}), heff_dup(v_rhs_241)});
            V v_t_24900;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24899 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24900 = v_s_24899;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24901 = ({ V rv_1 = heff_get_n(v_t_24900, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24897, v_t_24901});
          }
          case TAG_EDo: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24903 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str71)}), heff_dup(v_bsp_24629)});
            V v_t_24904 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24903}), heff_dup(v_rhs_241)});
            V v_t_24907;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24906 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24907 = v_s_24906;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24908 = ({ V rv_1 = heff_get_n(v_t_24907, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24904, v_t_24908});
          }
          case TAG_ELocal: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24911 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str72)}), heff_dup(v_bsp_24629)});
            V v_t_24912 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24911}), heff_dup(v_rhs_241)});
            V v_t_24915;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24914 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24915 = v_s_24914;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24916 = ({ V rv_1 = heff_get_n(v_t_24915, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24912, v_t_24916});
          }
          case TAG_EInvalid: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24918 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str73)}), heff_dup(v_bsp_24629)});
            V v_t_24919 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24918}), heff_dup(v_rhs_241)});
            V v_t_24922;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24921 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24922 = v_s_24921;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24923 = ({ V rv_1 = heff_get_n(v_t_24922, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24919, v_t_24923});
          }
          case TAG_EAssign: {
            heff_take_n(v_x11111_24736, 0ULL, 3);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24927 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str74)}), heff_dup(v_bsp_24629)});
            V v_t_24928 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24927}), heff_dup(v_rhs_241)});
            V v_t_24931;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24930 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24931 = v_s_24930;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24932 = ({ V rv_1 = heff_get_n(v_t_24931, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24928, v_t_24932});
          }
          case TAG_EWhile: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24935 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str75)}), heff_dup(v_bsp_24629)});
            V v_t_24936 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24935}), heff_dup(v_rhs_241)});
            V v_t_24939;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24938 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24939 = v_s_24938;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24940 = ({ V rv_1 = heff_get_n(v_t_24939, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24936, v_t_24940});
          }
          case TAG_EFor: {
            heff_take_n(v_x11111_24736, 0ULL, 3);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24944 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str76)}), heff_dup(v_bsp_24629)});
            V v_t_24945 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24944}), heff_dup(v_rhs_241)});
            V v_t_24948;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24947 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24948 = v_s_24947;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24949 = ({ V rv_1 = heff_get_n(v_t_24948, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24945, v_t_24949});
          }
          case TAG_EIfThen: {
            heff_take_n(v_x11111_24736, 0ULL, 2);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24952 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str77)}), heff_dup(v_bsp_24629)});
            V v_t_24953 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24952}), heff_dup(v_rhs_241)});
            V v_t_24956;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24955 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24956 = v_s_24955;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24957 = ({ V rv_1 = heff_get_n(v_t_24956, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24953, v_t_24957});
          }
          case TAG_EBreak: {
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24958 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str78)}), heff_dup(v_bsp_24629)});
            V v_t_24959 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24958}), heff_dup(v_rhs_241)});
            V v_t_24962;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24961 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24962 = v_s_24961;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24963 = ({ V rv_1 = heff_get_n(v_t_24962, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24959, v_t_24963});
          }
          case TAG_EContinue: {
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24964 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str79)}), heff_dup(v_bsp_24629)});
            V v_t_24965 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24964}), heff_dup(v_rhs_241)});
            V v_t_24968;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24967 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24968 = v_s_24967;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24969 = ({ V rv_1 = heff_get_n(v_t_24968, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24965, v_t_24969});
          }
          case TAG_EReturn: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24971 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str80)}), heff_dup(v_bsp_24629)});
            V v_t_24972 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24971}), heff_dup(v_rhs_241)});
            V v_t_24975;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24974 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24975 = v_s_24974;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24976 = ({ V rv_1 = heff_get_n(v_t_24975, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24972, v_t_24976});
          }
          case TAG_ENest: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24978 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str81)}), heff_dup(v_bsp_24629)});
            V v_t_24979 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24978}), heff_dup(v_rhs_241)});
            V v_t_24982;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24981 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24982 = v_s_24981;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24983 = ({ V rv_1 = heff_get_n(v_t_24982, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24979, v_t_24983});
          }
          case TAG_ELazy: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24985 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str82)}), heff_dup(v_bsp_24629)});
            V v_t_24986 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24985}), heff_dup(v_rhs_241)});
            V v_t_24989;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24988 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24989 = v_s_24988;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24990 = ({ V rv_1 = heff_get_n(v_t_24989, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24986, v_t_24990});
          }
          case TAG_ETuple: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24992 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str83)}), heff_dup(v_bsp_24629)});
            V v_t_24993 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24992}), heff_dup(v_rhs_241)});
            V v_t_24996;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24995 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24996 = v_s_24995;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24997 = ({ V rv_1 = heff_get_n(v_t_24996, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_24993, v_t_24997});
          }
          case TAG_ETry: {
            heff_take_n(v_x11111_24736, 0ULL, 1);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_24999 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str84)}), heff_dup(v_bsp_24629)});
            V v_t_241000 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24999}), heff_dup(v_rhs_241)});
            V v_t_241003;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_241002 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_241003 = v_s_241002;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_241004 = ({ V rv_1 = heff_get_n(v_t_241003, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241000, v_t_241004});
          }
          case TAG_EWith: {
            heff_take_n(v_x11111_24736, 0ULL, 4);
            heff_drop(v_t_24735);
            heff_drop(v_xsp_24737);
            V v_t_241009 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str85)}), heff_dup(v_bsp_24629)});
            V v_t_241010 = heff_tag_at_n(v_ru_24x111_24630_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241009}), heff_dup(v_rhs_241)});
            V v_t_241013;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_241012 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_241013 = v_s_241012;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_241014 = ({ V rv_1 = heff_get_n(v_t_241013, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241010, v_t_241014});
          }
          default: return heff_nomatch(v_x11111_24736);
          }
        }
        default: return heff_nomatch(v_x1111_24734);
        }
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24630, 0ULL, 4);
        V v_t_241019 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str86)}), heff_dup(v_bsp_24629)});
        V v_t_241020 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241019}), heff_dup(v_rhs_241)});
        V v_t_241023;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241022 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241023 = v_s_241022;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241024 = ({ V rv_1 = heff_get_n(v_t_241023, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241020, v_t_241024});
      }
      case TAG_ESig: {
        V v_ru_24x111_24630_24ESig = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241026 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str87)}), heff_dup(v_bsp_24629)});
        V v_t_241027 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ESig, TAG_PiAnon, 1, (V[]){v_t_241026}), heff_dup(v_rhs_241)});
        V v_t_241030;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241029 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241030 = v_s_241029;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241031 = ({ V rv_1 = heff_get_n(v_t_241030, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241027, v_t_241031});
      }
      case TAG_ESum: {
        V v_ru_24x111_24630_24ESum = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241033 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str88)}), heff_dup(v_bsp_24629)});
        V v_t_241034 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ESum, TAG_PiAnon, 1, (V[]){v_t_241033}), heff_dup(v_rhs_241)});
        V v_t_241037;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241036 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241037 = v_s_241036;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241038 = ({ V rv_1 = heff_get_n(v_t_241037, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241034, v_t_241038});
      }
      case TAG_EStruct: {
        V v_ru_24x111_24630_24EStruct = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241040 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str89)}), heff_dup(v_bsp_24629)});
        V v_t_241041 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EStruct, TAG_PiAnon, 1, (V[]){v_t_241040}), heff_dup(v_rhs_241)});
        V v_t_241044;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241043 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241044 = v_s_241043;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241045 = ({ V rv_1 = heff_get_n(v_t_241044, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241041, v_t_241045});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24630_24EUpdate = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_241048 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str90)}), heff_dup(v_bsp_24629)});
        V v_t_241049 = heff_tag_at_n(v_ru_24x111_24630_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241048}), heff_dup(v_rhs_241)});
        V v_t_241052;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241051 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241052 = v_s_241051;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241053 = ({ V rv_1 = heff_get_n(v_t_241052, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241049, v_t_241053});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24630_24EMatch = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_241056 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str91)}), heff_dup(v_bsp_24629)});
        V v_t_241057 = heff_tag_at_n(v_ru_24x111_24630_24EMatch, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241056}), heff_dup(v_rhs_241)});
        V v_t_241060;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241059 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241060 = v_s_241059;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241061 = ({ V rv_1 = heff_get_n(v_t_241060, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241057, v_t_241061});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24630_24ELetIn = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_241064 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str92)}), heff_dup(v_bsp_24629)});
        V v_t_241065 = heff_tag_at_n(v_ru_24x111_24630_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241064}), heff_dup(v_rhs_241)});
        V v_t_241068;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241067 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241068 = v_s_241067;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241069 = ({ V rv_1 = heff_get_n(v_t_241068, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241065, v_t_241069});
      }
      case TAG_EDo: {
        V v_ru_24x111_24630_24EDo = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241071 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str93)}), heff_dup(v_bsp_24629)});
        V v_t_241072 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EDo, TAG_PiAnon, 1, (V[]){v_t_241071}), heff_dup(v_rhs_241)});
        V v_t_241075;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241074 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241075 = v_s_241074;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241076 = ({ V rv_1 = heff_get_n(v_t_241075, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241072, v_t_241076});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24630_24ELocal = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_241079 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str94)}), heff_dup(v_bsp_24629)});
        V v_t_241080 = heff_tag_at_n(v_ru_24x111_24630_24ELocal, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241079}), heff_dup(v_rhs_241)});
        V v_t_241083;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241082 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241083 = v_s_241082;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241084 = ({ V rv_1 = heff_get_n(v_t_241083, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241080, v_t_241084});
      }
      case TAG_EInvalid: {
        V v_ru_24x111_24630_24EInvalid = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241086 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str95)}), heff_dup(v_bsp_24629)});
        V v_t_241087 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EInvalid, TAG_PiAnon, 1, (V[]){v_t_241086}), heff_dup(v_rhs_241)});
        V v_t_241090;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241089 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241090 = v_s_241089;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241091 = ({ V rv_1 = heff_get_n(v_t_241090, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241087, v_t_241091});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_24630, 0ULL, 3);
        V v_t_241095 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str96)}), heff_dup(v_bsp_24629)});
        V v_t_241096 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241095}), heff_dup(v_rhs_241)});
        V v_t_241099;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241098 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241099 = v_s_241098;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241100 = ({ V rv_1 = heff_get_n(v_t_241099, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241096, v_t_241100});
      }
      case TAG_EWhile: {
        V v_ru_24x111_24630_24EWhile = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_241103 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str97)}), heff_dup(v_bsp_24629)});
        V v_t_241104 = heff_tag_at_n(v_ru_24x111_24630_24EWhile, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241103}), heff_dup(v_rhs_241)});
        V v_t_241107;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241106 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241107 = v_s_241106;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241108 = ({ V rv_1 = heff_get_n(v_t_241107, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241104, v_t_241108});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_24630, 0ULL, 3);
        V v_t_241112 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str98)}), heff_dup(v_bsp_24629)});
        V v_t_241113 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241112}), heff_dup(v_rhs_241)});
        V v_t_241116;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241115 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241116 = v_s_241115;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241117 = ({ V rv_1 = heff_get_n(v_t_241116, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241113, v_t_241117});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_24630_24EIfThen = heff_take_reuse_n(v_x111_24630, 0ULL, 2);
        V v_t_241120 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str99)}), heff_dup(v_bsp_24629)});
        V v_t_241121 = heff_tag_at_n(v_ru_24x111_24630_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241120}), heff_dup(v_rhs_241)});
        V v_t_241124;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241123 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241124 = v_s_241123;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241125 = ({ V rv_1 = heff_get_n(v_t_241124, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241121, v_t_241125});
      }
      case TAG_EBreak: {
        V v_t_241126 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str100)}), heff_dup(v_bsp_24629)});
        V v_t_241127 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241126}), heff_dup(v_rhs_241)});
        V v_t_241130;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241129 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241130 = v_s_241129;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241131 = ({ V rv_1 = heff_get_n(v_t_241130, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241127, v_t_241131});
      }
      case TAG_EContinue: {
        V v_t_241132 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str101)}), heff_dup(v_bsp_24629)});
        V v_t_241133 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241132}), heff_dup(v_rhs_241)});
        V v_t_241136;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241135 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241136 = v_s_241135;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241137 = ({ V rv_1 = heff_get_n(v_t_241136, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241133, v_t_241137});
      }
      case TAG_EReturn: {
        V v_ru_24x111_24630_24EReturn = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241139 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str102)}), heff_dup(v_bsp_24629)});
        V v_t_241140 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24EReturn, TAG_PiAnon, 1, (V[]){v_t_241139}), heff_dup(v_rhs_241)});
        V v_t_241143;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241142 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241143 = v_s_241142;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241144 = ({ V rv_1 = heff_get_n(v_t_241143, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241140, v_t_241144});
      }
      case TAG_ENest: {
        V v_ru_24x111_24630_24ENest = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241146 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str103)}), heff_dup(v_bsp_24629)});
        V v_t_241147 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ENest, TAG_PiAnon, 1, (V[]){v_t_241146}), heff_dup(v_rhs_241)});
        V v_t_241150;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241149 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241150 = v_s_241149;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241151 = ({ V rv_1 = heff_get_n(v_t_241150, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241147, v_t_241151});
      }
      case TAG_ELazy: {
        V v_ru_24x111_24630_24ELazy = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241153 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str104)}), heff_dup(v_bsp_24629)});
        V v_t_241154 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ELazy, TAG_PiAnon, 1, (V[]){v_t_241153}), heff_dup(v_rhs_241)});
        V v_t_241157;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241156 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241157 = v_s_241156;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241158 = ({ V rv_1 = heff_get_n(v_t_241157, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241154, v_t_241158});
      }
      case TAG_ETuple: {
        V v_ru_24x111_24630_24ETuple = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241160 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str105)}), heff_dup(v_bsp_24629)});
        V v_t_241161 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ETuple, TAG_PiAnon, 1, (V[]){v_t_241160}), heff_dup(v_rhs_241)});
        V v_t_241164;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241163 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241164 = v_s_241163;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241165 = ({ V rv_1 = heff_get_n(v_t_241164, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241161, v_t_241165});
      }
      case TAG_ETry: {
        V v_ru_24x111_24630_24ETry = heff_take_reuse_n(v_x111_24630, 0ULL, 1);
        V v_t_241167 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str106)}), heff_dup(v_bsp_24629)});
        V v_t_241168 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24630_24ETry, TAG_PiAnon, 1, (V[]){v_t_241167}), heff_dup(v_rhs_241)});
        V v_t_241171;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241170 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241171 = v_s_241170;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241172 = ({ V rv_1 = heff_get_n(v_t_241171, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241168, v_t_241172});
      }
      case TAG_EWith: {
        heff_take_n(v_x111_24630, 0ULL, 4);
        V v_t_241177 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str107)}), heff_dup(v_bsp_24629)});
        V v_t_241178 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241177}), heff_dup(v_rhs_241)});
        V v_t_241181;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241180 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241181 = v_s_241180;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241182 = ({ V rv_1 = heff_get_n(v_t_241181, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24629, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24628_24At, TAG_At, 2, (V[]){v_t_241178, v_t_241182});
      }
      default: return heff_nomatch(v_x111_24630);
      }
    }
    default: return heff_nomatch(v_x11_24628);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowBinop(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str0, 37, "` does not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str2, 35, "` do not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str3, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str5, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str6, 39, "` are both the loosest: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str8, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str9, 85, "` are not related: add parentheses, or declare which binds tighter (`above`, `below`)");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str11, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str12, 34, "`), or import the module that does");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str13, 1, "`");
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam2, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam5, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam7, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efirstS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efirstS(V v_fix_240, V v_lenient_241, V v_before_242, V v_op_243) {
top: ;
  V v_it_244 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_fix_240), heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1))));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Tighter: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam0_clo);
  }
  case TAG_Looser: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam1_clo);
  }
  case TAG_Same: {
    V v_it1_249 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_AssocLeft: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam2_clo);
    }
    case TAG_AssocRight: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam3_clo);
    }
    case TAG_AssocNone: {
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam4, 1, 2, (V[]){v_before_242, v_op_243});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Unrelated: {
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop(v_fix_240);
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam5_clo);
    } else {
      V v_a_2424 = heff_get_n(v_before_242, 1, 9);
      V v_b_2425 = heff_dup(heff_rfield(v_op_243, 1));
      V v_t_2426 = (g_heff_2esyntax_2efixity_2ebothLoosest(v_fix_240, heff_dup(v_a_2424), heff_dup(v_b_2425)));
      V v_msg_2429;
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str5), heff_strAppend(v_b_2425, ((V)&g_heff_2esyntax_2esurface_2efirstS_str6)));
        v_msg_2429 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str7), heff_strAppend(v_a_2424, v_t_2427));
      } else {
        heff_drop(v_t_2426);
        V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str8), heff_strAppend(v_b_2425, ((V)&g_heff_2esyntax_2esurface_2efirstS_str9)));
        v_msg_2429 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str10), heff_strAppend(v_a_2424, v_t_2428));
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam6, 1, 2, (V[]){v_op_243, v_msg_2429});
    }
  }
  case TAG_Undeclared: {
    V v_x_2433 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      heff_drop(v_x_2433);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam7_clo);
    } else {
      V v_t_2437;
      if (heff_strEq_c(heff_dup(v_x_2433), heff_dup(heff_rfield(v_op_243, 1)))) {
        heff_drop_rec(v_before_242, 9);
        v_t_2437 = v_op_243;
      } else {
        heff_drop_rec(v_op_243, 9);
        v_t_2437 = v_before_242;
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam8, 1, 2, (V[]){v_x_2433, v_t_2437});
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efirstS(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_245});
}
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_247});
}
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args) {
  V v_st_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_st_2410});
}
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args) {
  V v_st_2412 = args[0];
  V v_t_2413 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_st_2412});
}
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args) {
  V v_st_2414 = args[0];
  V v_before_242 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419;
  if (heff_strEq_c(heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1)))) {
    heff_drop_rec(v_before_242, 9);
    V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str0));
    v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str1), v_t_2416);
  } else {
    V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str2));
    V v_t_2418 = heff_strAppend(heff_get_n(v_before_242, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str3), v_t_2417));
    v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str4), v_t_2418);
  }
  V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2419, v_t_2420, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args) {
  V v_st_2422 = args[0];
  V v_t_2423 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_st_2422});
}
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args) {
  V v_st_2430 = args[0];
  V v_op_243 = heff_env(self)[0];
  V v_msg_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2429, v_t_2431, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_st_2430});
}
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args) {
  V v_st_2434 = args[0];
  V v_t_2435 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_st_2434});
}
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args) {
  V v_st_2438 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_t_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str11), heff_strAppend(heff_dup(v_x_2433), ((V)&g_heff_2esyntax_2esurface_2efirstS_str12)));
  V v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str13), heff_strAppend(v_x_2433, v_t_2439));
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2437, 3), heff_get_n(v_t_2437, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2440, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2438});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str11, 0, "");
Clo g_heff_2esyntax_2esurface_2espreadGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2espreadGo_entry, 5, 0};

V g_heff_2esyntax_2esurface_2espreadGo(V v_waiting_240, V v_held_241, V v_open_242, V v_x4_243, V v_acc_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_open_242);
    V v_t_245 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
    V v_xs_246 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_245));
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  }
  case TAG_Cons: {
    V v_it_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_waiting_240)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_held_241)) {
      case TAG_Nil: {
        heff_drop(v_open_242);
        V v_g_2419;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          V v_sp_2413 = heff_dup(heff_field(v_it_247, 4));
          v_g_2419 = (g_heff_2esyntax_2esurface_2egroupFrom(v_sp_2413, heff_dup(v_rest_248)));
          break;
        }
        case TAG_Eqn: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        case TAG_Whole: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        case TAG_Doc: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        V v_t_2420 = heff_dup(heff_rfield(v_g_2419, 0));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nil: {
          heff_drop_rec(v_g_2419, 3);
          V t_0 = NTAG(TAG_Nil);
          V t_1 = NTAG(TAG_Nil);
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_rest_248;
          V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2420, 0ULL, 2);
          heff_drop(v_rest_248);
          V v_t_2423 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, heff_dup(heff_rfield(v_g_2419, 0))});
          V t_0 = v_t_2423;
          V t_1 = heff_dup(heff_rfield(v_g_2419, 1));
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_get_n(v_g_2419, 2, 3);
          V t_4 = v_acc_244;
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      case TAG_Cons: {
        V v_t_2448;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          v_t_2448 = NTAG(TAG_False);
          break;
        }
        case TAG_Eqn: {
          switch (heff_tag_of(v_open_242)) {
          case TAG_Nothing: {
            v_t_2448 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_f_2434 = heff_dup(heff_field(v_open_242, 0));
            V v_t_2445;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              V v_f_2436 = heff_dup(heff_field(v_it_247, 1));
              v_t_2445 = v_f_2436;
              break;
            }
            case TAG_Eqn: {
              V v_f_2440 = heff_dup(heff_field(v_it_247, 0));
              v_t_2445 = v_f_2440;
              break;
            }
            case TAG_Whole: {
              v_t_2445 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str0);
              break;
            }
            case TAG_Doc: {
              v_t_2445 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str1);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            v_t_2448 = heff_strEq(v_f_2434, v_t_2445);
            break;
          }
          default: heff_nomatch(v_open_242);
          }
          break;
        }
        case TAG_Whole: {
          v_t_2448 = NTAG(TAG_False);
          break;
        }
        case TAG_Doc: {
          v_t_2448 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
          heff_drop(v_t_2448);
          V t_0 = v_waiting_240;
          V t_1 = v_held_241;
          V t_2 = v_open_242;
          V t_3 = v_rest_248;
          V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2448);
          V v_t_2459;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_Eqn: {
            v_t_2459 = NTAG(TAG_True);
            break;
          }
          case TAG_Whole: {
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          case TAG_Doc: {
            v_t_2459 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
            heff_drop(v_open_242);
            heff_drop(v_t_2459);
            V v_t_2470;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              V v_f_2461 = heff_dup(heff_field(v_it_247, 1));
              v_t_2470 = v_f_2461;
              break;
            }
            case TAG_Eqn: {
              V v_f_2465 = heff_dup(heff_field(v_it_247, 0));
              v_t_2470 = v_f_2465;
              break;
            }
            case TAG_Whole: {
              v_t_2470 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str2);
              break;
            }
            case TAG_Doc: {
              v_t_2470 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str3);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            HeffT2 v_t_2471 = ({ V a_0 = v_t_2470; V a_1 = heff_dup(v_waiting_240); HeffT2 r_ = (g_heff_2esyntax_2esurface_2epickSig_24cpr(a_0, a_1)); heff_drop(v_t_2470); r_; });
            {
              V v_field_2473 = v_t_2471.f[1];
              int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
              if ((v_tag_2472 == ((int64_t)0ULL))) {
                V v_it_271_2475 = v_field_2473;
                switch (heff_tag_of(v_it_271_2475)) {
                case TAG_MkPair: {
                  V v_s_2476 = heff_field(v_it_271_2475, 0);
                  V v_more_2477 = heff_field(v_it_271_2475, 1);
                  heff_take_n(v_it_271_2475, 3ULL, 2);
                  V v_t_2488;
                  switch (heff_tag_of(v_it_247)) {
                  case TAG_Sig: {
                    V v_f_2479 = heff_dup(heff_field(v_it_247, 1));
                    v_t_2488 = v_f_2479;
                    break;
                  }
                  case TAG_Eqn: {
                    V v_f_2483 = heff_dup(heff_field(v_it_247, 0));
                    v_t_2488 = v_f_2483;
                    break;
                  }
                  case TAG_Whole: {
                    v_t_2488 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str4);
                    break;
                  }
                  case TAG_Doc: {
                    v_t_2488 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str5);
                    break;
                  }
                  default: heff_nomatch(v_it_247);
                  }
                  V v_t_2489 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, heff_tag_n(TAG_Cons, 2, (V[]){v_s_2476, v_acc_244})});
                  V t_0 = v_more_2477;
                  V t_1 = v_held_241;
                  V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2488});
                  V t_3 = v_rest_248;
                  V t_4 = v_t_2489;
                  v_waiting_240 = t_0;
                  v_held_241 = t_1;
                  v_open_242 = t_2;
                  v_x4_243 = t_3;
                  v_acc_244 = t_4;
                  goto top;
                }
                default: return heff_nomatch(v_it_271_2475);
                }
              } else {
                heff_drop(v_field_2473);
                V v_t_2490 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
                V v_t_2491 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_2490));
                V t_0 = NTAG(TAG_Nil);
                V t_1 = NTAG(TAG_Nil);
                V t_2 = NTAG(TAG_Nothing);
                V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
                V t_4 = v_t_2491;
                v_waiting_240 = t_0;
                v_held_241 = t_1;
                v_open_242 = t_2;
                v_x4_243 = t_3;
                v_acc_244 = t_4;
                goto top;
              }
            }
          } else {
            heff_drop(v_t_2459);
            V v_t_24124;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              v_t_24124 = NTAG(TAG_False);
              break;
            }
            case TAG_Eqn: {
              v_t_24124 = NTAG(TAG_False);
              break;
            }
            case TAG_Whole: {
              V v_d_24100 = heff_dup(heff_field(v_it_247, 0));
              switch (heff_tag_of(v_d_24100)) {
              case TAG_At: {
                V v_x11_24101 = heff_field(v_d_24100, 0);
                heff_take_n(v_d_24100, 1ULL, 2);
                switch (heff_tag_of(v_x11_24101)) {
                case TAG_DeclEquations: {
                  heff_take_n(v_x11_24101, 0ULL, 5);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclDefine: {
                  heff_take_n(v_x11_24101, 0ULL, 5);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclTheory: {
                  heff_take_n(v_x11_24101, 0ULL, 4);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclPrimitive: {
                  heff_take_n(v_x11_24101, 0ULL, 3);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclTest: {
                  heff_take_n(v_x11_24101, 0ULL, 2);
                  v_t_24124 = NTAG(TAG_True);
                  break;
                }
                case TAG_DeclWatch: {
                  heff_take_n(v_x11_24101, 0ULL, 1);
                  v_t_24124 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_x11_24101);
                }
                break;
              }
              default: heff_nomatch(v_d_24100);
              }
              break;
            }
            case TAG_Doc: {
              v_t_24124 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
              heff_drop(v_t_24124);
              V t_0 = v_waiting_240;
              V t_1 = v_held_241;
              V t_2 = v_open_242;
              V t_3 = v_rest_248;
              V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            } else {
              heff_drop(v_open_242);
              heff_drop(v_t_24124);
              V v_t_24125 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
              V v_t_24126 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24125));
              V t_0 = NTAG(TAG_Nil);
              V t_1 = NTAG(TAG_Nil);
              V t_2 = NTAG(TAG_Nothing);
              V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
              V t_4 = v_t_24126;
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            }
          }
        }
      }
      default: return heff_nomatch(v_held_241);
      }
    }
    case TAG_Cons: {
      V v_t_24151;
      switch (heff_tag_of(v_it_247)) {
      case TAG_Sig: {
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      case TAG_Eqn: {
        switch (heff_tag_of(v_open_242)) {
        case TAG_Nothing: {
          v_t_24151 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_f_24137 = heff_dup(heff_field(v_open_242, 0));
          V v_t_24148;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            V v_f_24139 = heff_dup(heff_field(v_it_247, 1));
            v_t_24148 = v_f_24139;
            break;
          }
          case TAG_Eqn: {
            V v_f_24143 = heff_dup(heff_field(v_it_247, 0));
            v_t_24148 = v_f_24143;
            break;
          }
          case TAG_Whole: {
            v_t_24148 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str6);
            break;
          }
          case TAG_Doc: {
            v_t_24148 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str7);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          v_t_24151 = heff_strEq(v_f_24137, v_t_24148);
          break;
        }
        default: heff_nomatch(v_open_242);
        }
        break;
      }
      case TAG_Whole: {
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      case TAG_Doc: {
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it_247);
      }
      if ((heff_dup(v_t_24151) == NTAG(TAG_True))) {
        heff_drop(v_t_24151);
        V t_0 = v_waiting_240;
        V t_1 = v_held_241;
        V t_2 = v_open_242;
        V t_3 = v_rest_248;
        V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
        v_waiting_240 = t_0;
        v_held_241 = t_1;
        v_open_242 = t_2;
        v_x4_243 = t_3;
        v_acc_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_24151);
        V v_t_24162;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          v_t_24162 = NTAG(TAG_False);
          break;
        }
        case TAG_Eqn: {
          v_t_24162 = NTAG(TAG_True);
          break;
        }
        case TAG_Whole: {
          v_t_24162 = NTAG(TAG_False);
          break;
        }
        case TAG_Doc: {
          v_t_24162 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        if ((heff_dup(v_t_24162) == NTAG(TAG_True))) {
          heff_drop(v_open_242);
          heff_drop(v_t_24162);
          V v_t_24173;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            V v_f_24164 = heff_dup(heff_field(v_it_247, 1));
            v_t_24173 = v_f_24164;
            break;
          }
          case TAG_Eqn: {
            V v_f_24168 = heff_dup(heff_field(v_it_247, 0));
            v_t_24173 = v_f_24168;
            break;
          }
          case TAG_Whole: {
            v_t_24173 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str8);
            break;
          }
          case TAG_Doc: {
            v_t_24173 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str9);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          HeffT2 v_t_24174 = ({ V a_0 = v_t_24173; V a_1 = heff_dup(v_waiting_240); HeffT2 r_ = (g_heff_2esyntax_2esurface_2epickSig_24cpr(a_0, a_1)); heff_drop(v_t_24173); r_; });
          {
            V v_field_24176 = v_t_24174.f[1];
            int64_t v_tag_24175 = ((int64_t)v_t_24174.f[0]);
            if ((v_tag_24175 == ((int64_t)0ULL))) {
              heff_drop_tag(v_waiting_240, 2);
              V v_it_271_24178 = v_field_24176;
              switch (heff_tag_of(v_it_271_24178)) {
              case TAG_MkPair: {
                V v_s_24179 = heff_field(v_it_271_24178, 0);
                V v_more_24180 = heff_field(v_it_271_24178, 1);
                heff_take_n(v_it_271_24178, 3ULL, 2);
                V v_t_24191;
                switch (heff_tag_of(v_it_247)) {
                case TAG_Sig: {
                  V v_f_24182 = heff_dup(heff_field(v_it_247, 1));
                  v_t_24191 = v_f_24182;
                  break;
                }
                case TAG_Eqn: {
                  V v_f_24186 = heff_dup(heff_field(v_it_247, 0));
                  v_t_24191 = v_f_24186;
                  break;
                }
                case TAG_Whole: {
                  v_t_24191 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str10);
                  break;
                }
                case TAG_Doc: {
                  v_t_24191 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str11);
                  break;
                }
                default: heff_nomatch(v_it_247);
                }
                V v_t_24192 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, heff_tag_n(TAG_Cons, 2, (V[]){v_s_24179, v_acc_244})});
                V t_0 = v_more_24180;
                V t_1 = v_held_241;
                V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24191});
                V t_3 = v_rest_248;
                V t_4 = v_t_24192;
                v_waiting_240 = t_0;
                v_held_241 = t_1;
                v_open_242 = t_2;
                v_x4_243 = t_3;
                v_acc_244 = t_4;
                goto top;
              }
              default: return heff_nomatch(v_it_271_24178);
              }
            } else {
              heff_drop(v_field_24176);
              V v_t_24193 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
              V v_t_24194 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24193));
              V t_0 = NTAG(TAG_Nil);
              V t_1 = NTAG(TAG_Nil);
              V t_2 = NTAG(TAG_Nothing);
              V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
              V t_4 = v_t_24194;
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            }
          }
        } else {
          heff_drop(v_t_24162);
          V v_t_24227;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            v_t_24227 = NTAG(TAG_False);
            break;
          }
          case TAG_Eqn: {
            v_t_24227 = NTAG(TAG_False);
            break;
          }
          case TAG_Whole: {
            V v_d_24203 = heff_dup(heff_field(v_it_247, 0));
            switch (heff_tag_of(v_d_24203)) {
            case TAG_At: {
              V v_x11_24204 = heff_field(v_d_24203, 0);
              heff_take_n(v_d_24203, 1ULL, 2);
              switch (heff_tag_of(v_x11_24204)) {
              case TAG_DeclEquations: {
                heff_take_n(v_x11_24204, 0ULL, 5);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclDefine: {
                heff_take_n(v_x11_24204, 0ULL, 5);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclTheory: {
                heff_take_n(v_x11_24204, 0ULL, 4);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclPrimitive: {
                heff_take_n(v_x11_24204, 0ULL, 3);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclTest: {
                heff_take_n(v_x11_24204, 0ULL, 2);
                v_t_24227 = NTAG(TAG_True);
                break;
              }
              case TAG_DeclWatch: {
                heff_take_n(v_x11_24204, 0ULL, 1);
                v_t_24227 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_x11_24204);
              }
              break;
            }
            default: heff_nomatch(v_d_24203);
            }
            break;
          }
          case TAG_Doc: {
            v_t_24227 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          if ((heff_dup(v_t_24227) == NTAG(TAG_True))) {
            heff_drop(v_t_24227);
            V t_0 = v_waiting_240;
            V t_1 = v_held_241;
            V t_2 = v_open_242;
            V t_3 = v_rest_248;
            V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
            v_waiting_240 = t_0;
            v_held_241 = t_1;
            v_open_242 = t_2;
            v_x4_243 = t_3;
            v_acc_244 = t_4;
            goto top;
          } else {
            heff_drop(v_open_242);
            heff_drop(v_t_24227);
            V v_t_24228 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
            V v_t_24229 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24228));
            V t_0 = NTAG(TAG_Nil);
            V t_1 = NTAG(TAG_Nil);
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
            V t_4 = v_t_24229;
            v_waiting_240 = t_0;
            v_held_241 = t_1;
            v_open_242 = t_2;
            v_x4_243 = t_3;
            v_acc_244 = t_4;
            goto top;
          }
        }
      }
    }
    default: return heff_nomatch(v_waiting_240);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2espreadGo(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_f_242 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_242, v_x1_240}});
  }
  case TAG_EParen: {
    V v_f_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_246, v_x1_240}});
  }
  case TAG_Named: {
    V v_f_2412 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2412, v_x1_240}});
  }
  case TAG_Tup: {
    V v_f_2417 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2417, v_x1_240}});
  }
  case TAG_Seg: {
    V v_f_2421 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2421, v_x1_240}});
  }
  case TAG_Braces: {
    V v_f_2426 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2426, v_x1_240}});
  }
  case TAG_Update: {
    V v_f_2433 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2433, v_x1_240}});
  }
  case TAG_EUSet: {
    V v_f_2437 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2437, v_x1_240}});
  }
  case TAG_InstB: {
    V v_f_2443 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2443, v_x1_240}});
  }
  case TAG_EFSet: {
    V v_f_2447 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2447, v_x1_240}});
  }
  case TAG_EFDefault: {
    V v_f_2451 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2451, v_x1_240}});
  }
  case TAG_Sum: {
    V v_f_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2457, v_x1_240}});
  }
  case TAG_ECon: {
    V v_f_2460 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2460, v_x1_240}});
  }
  case TAG_EField: {
    V v_f_2463 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2463, v_x1_240}});
  }
  case TAG_ENeg: {
    V v_f_2466 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2466, v_x1_240}});
  }
  case TAG_ETilde: {
    V v_f_2469 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2469, v_x1_240}});
  }
  case TAG_App: {
    V v_f_2472 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2472, v_x1_240}});
  }
  case TAG_Op: {
    V v_f_2476 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2476, v_x1_240}});
  }
  case TAG_Ops: {
    V v_f_2479 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2479, v_x1_240}});
  }
  case TAG_OpRhs: {
    V v_op_2480 = heff_field(v_x1_240, 0);
    V v_e_2481 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return ((HeffT2){{v_op_2480, v_e_2481}});
  }
  case TAG_Ann: {
    V v_f_2485 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2485, v_x1_240}});
  }
  case TAG_BVar: {
    V v_f_2487 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2487, v_x1_240}});
  }
  case TAG_BImp: {
    V v_f_2491 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2491, v_x1_240}});
  }
  case TAG_BAnn: {
    V v_f_2497 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2497, v_x1_240}});
  }
  case TAG_BPat: {
    V v_f_2499 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2499, v_x1_240}});
  }
  case TAG_Lam: {
    V v_f_24104 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24104, v_x1_240}});
  }
  case TAG_Case: {
    V v_f_24109 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24109, v_x1_240}});
  }
  case TAG_EAlt: {
    V v_f_24113 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24113, v_x1_240}});
  }
  case TAG_If: {
    V v_f_24120 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24120, v_x1_240}});
  }
  case TAG_Do: {
    V v_f_24123 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24123, v_x1_240}});
  }
  case TAG_ESBind: {
    V v_f_24127 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24127, v_x1_240}});
  }
  case TAG_ELet: {
    V v_f_24134 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24134, v_x1_240}});
  }
  case TAG_ELetElse: {
    V v_f_24142 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24142, v_x1_240}});
  }
  case TAG_ELetMut: {
    V v_f_24149 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24149, v_x1_240}});
  }
  case TAG_EAssign: {
    V v_f_24153 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24153, v_x1_240}});
  }
  case TAG_EWhile: {
    V v_f_24158 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24158, v_x1_240}});
  }
  case TAG_EFor: {
    V v_f_24165 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24165, v_x1_240}});
  }
  case TAG_EJump: {
    V v_f_24167 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24167, v_x1_240}});
  }
  case TAG_EReturn: {
    V v_f_24170 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24170, v_x1_240}});
  }
  case TAG_ENest: {
    V v_f_24175 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24175, v_x1_240}});
  }
  case TAG_EArrow: {
    V v_f_24178 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24178, v_x1_240}});
  }
  case TAG_IfThen: {
    V v_f_24183 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24183, v_x1_240}});
  }
  case TAG_ETry: {
    V v_f_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24188, v_x1_240}});
  }
  case TAG_ECatch: {
    V v_f_24193 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24193, v_x1_240}});
  }
  case TAG_EWith: {
    V v_f_24200 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24200, v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0, 2, ":=");

HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 4);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_f_2421 = heff_field(v_x12_2418, 0);
      V v_x122_2422 = heff_field(v_x12_2418, 1);
      heff_take_n(v_x12_2418, 3ULL, 2);
      switch (heff_tag_of(v_x122_2422)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_f_2421)) {
        case TAG_Atom: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EParen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Named: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Tup: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Seg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Braces: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Update: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EUSet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_InstB: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EFSet: {
          heff_take_n(v_f_2421, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFDefault: {
          V v_eq_2461 = heff_dup(heff_field(v_f_2421, 1));
          if (heff_strEq_c(heff_get_n(v_eq_2461, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
          } else {
            heff_drop_tag(v_f_2421, 3);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Sum: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ECon: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EField: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ENeg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ETilde: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_App: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Op: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Ops: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_OpRhs: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Ann: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BVar: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BImp: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BAnn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BPat: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Lam: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Case: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EAlt: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_If: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Do: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ESBind: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELetElse: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELetMut: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EAssign: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EWhile: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EFor: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EJump: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EReturn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ENest: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EArrow: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_IfThen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ETry: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ECatch: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EWith: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        default: return ((HeffT2){{heff_nomatch(v_f_2421)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_x122_2422, 0ULL, 2);
        heff_drop(v_f_2421);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_2422)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 4);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      V v_x121_2421 = heff_dup(heff_field(v_x12_2418, 0));
      switch (heff_tag_of(v_x121_2421)) {
      case TAG_Atom: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EParen: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Named: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Tup: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Seg: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Braces: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Update: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EUSet: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_InstB: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFSet: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x12_2418}});
      }
      case TAG_EFDefault: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Sum: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ECon: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EField: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENeg: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETilde: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_App: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Op: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Ops: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_OpRhs: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Ann: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_BVar: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_BImp: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_BAnn: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_BPat: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Lam: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Case: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAlt: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_If: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Do: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESBind: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELet: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetElse: {
        heff_take_n(v_x121_2421, 0ULL, 7);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetMut: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAssign: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWhile: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFor: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EJump: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EReturn: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENest: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EArrow: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_IfThen: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETry: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ECatch: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWith: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x121_2421)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0, 64, "a unit is what a size counts: say the size, `x::size(4)-unit(8)`");

HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_s_244, 0));
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_v_243)) {
    case TAG_StrValue: {
      v_t_249 = NTAG(TAG_SegmentBinary);
      break;
    }
    case TAG_IntValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    case TAG_FloatValue: {
      v_t_249 = NTAG(TAG_SegmentFloat);
      break;
    }
    case TAG_RuneValue: {
      v_t_249 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_OtherValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    break;
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_249 = v_t_248;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_249, v_st_245));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_x11_2413 = v_field_2411;
    V v_st_2414 = v_field_2412;
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      V v_e_2415 = heff_field(v_x11_2413, 0);
      V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      heff_drop_rec(v_s_244, 5);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
    }
    case TAG_Right: {
      V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 0ULL, 1);
      V v_t_2417 = heff_dup(heff_rfield(v_s_244, 1));
      V v_t_2428;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_SizeDefault: {
        V v_t_2418 = heff_dup(heff_rfield(v_s_244, 2));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_st_2414});
          break;
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2413_24Right, 1);
          V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0), heff_dup(v_sp_241), NTAG(TAG_Nothing)});
          v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2421}), v_st_2414});
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      case TAG_SizeNumber: {
        heff_take_n(v_t_2417, 0ULL, 1);
        V v_t_2423 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_st_2414});
        break;
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2417, 0ULL, 3);
        V v_t_2427 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_st_2414});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      switch (heff_tag_of(v_t_2428)) {
      case TAG_MkPair: {
        V v_x11_2429 = heff_field(v_t_2428, 0);
        V v_st_2430 = heff_field(v_t_2428, 1);
        V v_ru_24t_2428_24MkPair = heff_take_reuse_n(v_t_2428, 3ULL, 2);
        switch (heff_tag_of(v_x11_2429)) {
        case TAG_Left: {
          V v_e_2431 = heff_field(v_x11_2429, 0);
          V v_ru_24x11_2429_24Left = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_rec(v_s_244, 5);
          heff_drop_cell(v_ru_24t_2428_24MkPair, 2);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2429_24Left, TAG_Left, 1, (V[]){v_e_2431}), v_st_2430}});
        }
        case TAG_Right: {
          V v_ru_24x11_2429_24Right = heff_take_reuse_n(v_x11_2429, 0ULL, 1);
          V v_t_2433 = heff_dup(heff_rfield(v_s_244, 0));
          V v_t_2436;
          switch (heff_tag_of(v_t_2433)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_v_243)) {
            case TAG_StrValue: {
              v_t_2436 = NTAG(TAG_SegmentBinary);
              break;
            }
            case TAG_IntValue: {
              v_t_2436 = NTAG(TAG_SegmentInteger);
              break;
            }
            case TAG_FloatValue: {
              v_t_2436 = NTAG(TAG_SegmentFloat);
              break;
            }
            case TAG_RuneValue: {
              v_t_2436 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
              break;
            }
            case TAG_OtherValue: {
              v_t_2436 = NTAG(TAG_SegmentInteger);
              break;
            }
            default: heff_nomatch(v_v_243);
            }
            break;
          }
          case TAG_Just: {
            V v_t_2435 = heff_field(v_t_2433, 0);
            heff_take_n(v_t_2433, 1ULL, 1);
            v_t_2436 = v_t_2435;
            break;
          }
          default: heff_nomatch(v_t_2433);
          }
          V v_t_2437 = heff_dup(heff_rfield(v_s_244, 0));
          V v_t_2440;
          switch (heff_tag_of(v_t_2437)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_v_243)) {
            case TAG_StrValue: {
              v_t_2440 = NTAG(TAG_SegmentBinary);
              break;
            }
            case TAG_IntValue: {
              v_t_2440 = NTAG(TAG_SegmentInteger);
              break;
            }
            case TAG_FloatValue: {
              v_t_2440 = NTAG(TAG_SegmentFloat);
              break;
            }
            case TAG_RuneValue: {
              v_t_2440 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
              break;
            }
            case TAG_OtherValue: {
              v_t_2440 = NTAG(TAG_SegmentInteger);
              break;
            }
            default: heff_nomatch(v_v_243);
            }
            break;
          }
          case TAG_Just: {
            V v_t_2439 = heff_field(v_t_2437, 0);
            heff_take_n(v_t_2437, 1ULL, 1);
            v_t_2440 = v_t_2439;
            break;
          }
          default: heff_nomatch(v_t_2437);
          }
          V v_unit_2441 = ({ V a_0 = v_t_2440; V a_1 = heff_rfield(v_s_244, 2); V r_ = (g_heff_2esyntax_2esurface_2eunitIn(a_0, a_1)); heff_drop(v_t_2440); r_; });
          V v_t_2442 = heff_dup(heff_rfield(v_s_244, 1));
          V v_t_2447;
          switch (heff_tag_of(v_t_2442)) {
          case TAG_SizeDefault: {
            heff_drop(v_unit_2441);
            v_t_2447 = NTAG(TAG_SizeDefault);
            break;
          }
          case TAG_SizeNumber: {
            V v_n_2443 = heff_field(v_t_2442, 0);
            V v_ru_24t_2442_24SizeNumber = heff_take_reuse_n(v_t_2442, 1ULL, 1);
            v_t_2447 = heff_tag_at_n(v_ru_24t_2442_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2443, v_unit_2441)});
            break;
          }
          case TAG_SizeName: {
            V v_x_2444 = heff_field(v_t_2442, 0);
            V v_xsp_2445 = heff_field(v_t_2442, 1);
            V v_ru_24t_2442_24SizeName = heff_take_reuse_n(v_t_2442, 3ULL, 3);
            v_t_2447 = heff_tag_at_n(v_ru_24t_2442_24SizeName, TAG_SizeName, 3, (V[]){v_x_2444, v_xsp_2445, v_unit_2441});
            break;
          }
          default: heff_nomatch(v_t_2442);
          }
          V v_m_2448 = (g_heff_2esyntax_2esurface_2etypeChecks(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), heff_dup(v_s_244), v_t_2436, v_t_2447));
          V v_x1_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_st_2430}));
          switch (heff_tag_of(v_x1_2449)) {
          case TAG_MkPair: {
            V v_x11_2450 = heff_field(v_x1_2449, 0);
            V v_st_2451 = heff_field(v_x1_2449, 1);
            heff_take_n(v_x1_2449, 3ULL, 2);
            switch (heff_tag_of(v_x11_2450)) {
            case TAG_Left: {
              V v_e_2452 = heff_field(v_x11_2450, 0);
              V v_ru_24x11_2450_24Left = heff_take_reuse_n(v_x11_2450, 1ULL, 1);
              heff_drop(v_sp_241);
              heff_drop(v_e_242);
              heff_drop(v_v_243);
              heff_drop_rec(v_s_244, 5);
              heff_drop_cell(v_ru_24t_2428_24MkPair, 2);
              heff_drop_cell(v_ru_24x11_2429_24Right, 1);
              return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2450_24Left, TAG_Left, 1, (V[]){v_e_2452}), v_st_2451}});
            }
            case TAG_Right: {
              V v_ru_24x11_2450_24Right = heff_take_reuse_n(v_x11_2450, 0ULL, 1);
              V v_t_2454 = heff_dup(heff_rfield(v_s_244, 0));
              V v_t_2457;
              switch (heff_tag_of(v_t_2454)) {
              case TAG_Nothing: {
                switch (heff_tag_of(v_v_243)) {
                case TAG_StrValue: {
                  heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                  v_t_2457 = NTAG(TAG_SegmentBinary);
                  break;
                }
                case TAG_IntValue: {
                  heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                  v_t_2457 = NTAG(TAG_SegmentInteger);
                  break;
                }
                case TAG_FloatValue: {
                  heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                  v_t_2457 = NTAG(TAG_SegmentFloat);
                  break;
                }
                case TAG_RuneValue: {
                  v_t_2457 = heff_tag_at_n(v_ru_24x11_2450_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                  break;
                }
                case TAG_OtherValue: {
                  heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                  v_t_2457 = NTAG(TAG_SegmentInteger);
                  break;
                }
                default: heff_nomatch(v_v_243);
                }
                break;
              }
              case TAG_Just: {
                V v_t_2456 = heff_field(v_t_2454, 0);
                heff_take_n(v_t_2454, 1ULL, 1);
                heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                v_t_2457 = v_t_2456;
                break;
              }
              default: heff_nomatch(v_t_2454);
              }
              V v_t_2458 = heff_take_field(v_s_244, 0);
              V v_t_2461;
              switch (heff_tag_of(v_t_2458)) {
              case TAG_Nothing: {
                switch (heff_tag_of(v_v_243)) {
                case TAG_StrValue: {
                  v_t_2461 = NTAG(TAG_SegmentBinary);
                  break;
                }
                case TAG_IntValue: {
                  heff_take_n(v_v_243, 0ULL, 1);
                  v_t_2461 = NTAG(TAG_SegmentInteger);
                  break;
                }
                case TAG_FloatValue: {
                  v_t_2461 = NTAG(TAG_SegmentFloat);
                  break;
                }
                case TAG_RuneValue: {
                  v_t_2461 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                  break;
                }
                case TAG_OtherValue: {
                  v_t_2461 = NTAG(TAG_SegmentInteger);
                  break;
                }
                default: heff_nomatch(v_v_243);
                }
                break;
              }
              case TAG_Just: {
                V v_t_2460 = heff_field(v_t_2458, 0);
                heff_take_n(v_t_2458, 1ULL, 1);
                heff_drop(v_v_243);
                v_t_2461 = v_t_2460;
                break;
              }
              default: heff_nomatch(v_t_2458);
              }
              V v_unit_2462 = ({ V a_0 = v_t_2461; V a_1 = heff_rfield(v_s_244, 2); V r_ = (g_heff_2esyntax_2esurface_2eunitIn(a_0, a_1)); heff_drop(v_t_2461); r_; });
              V v_t_2463 = heff_take_field(v_s_244, 1);
              V v_t_2468;
              switch (heff_tag_of(v_t_2463)) {
              case TAG_SizeDefault: {
                heff_drop(v_unit_2462);
                v_t_2468 = NTAG(TAG_SizeDefault);
                break;
              }
              case TAG_SizeNumber: {
                V v_n_2464 = heff_field(v_t_2463, 0);
                V v_ru_24t_2463_24SizeNumber = heff_take_reuse_n(v_t_2463, 1ULL, 1);
                v_t_2468 = heff_tag_at_n(v_ru_24t_2463_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2464, v_unit_2462)});
                break;
              }
              case TAG_SizeName: {
                V v_x_2465 = heff_field(v_t_2463, 0);
                V v_xsp_2466 = heff_field(v_t_2463, 1);
                V v_ru_24t_2463_24SizeName = heff_take_reuse_n(v_t_2463, 3ULL, 3);
                v_t_2468 = heff_tag_at_n(v_ru_24t_2463_24SizeName, TAG_SizeName, 3, (V[]){v_x_2465, v_xsp_2466, v_unit_2462});
                break;
              }
              default: heff_nomatch(v_t_2463);
              }
              V v_t_2469 = heff_take_field(v_s_244, 3);
              V v_t_2471;
              switch (heff_tag_of(v_t_2469)) {
              case TAG_Nothing: {
                v_t_2471 = NTAG(TAG_False);
                break;
              }
              case TAG_Just: {
                V v_b_2470 = heff_field(v_t_2469, 0);
                heff_take_n(v_t_2469, 1ULL, 1);
                v_t_2471 = v_b_2470;
                break;
              }
              default: heff_nomatch(v_t_2469);
              }
              V v_t_2472 = heff_get_n(v_s_244, 4, 5);
              V v_t_2474;
              switch (heff_tag_of(v_t_2472)) {
              case TAG_Nothing: {
                v_t_2474 = NTAG(TAG_False);
                break;
              }
              case TAG_Just: {
                V v_b_2473 = heff_field(v_t_2472, 0);
                heff_take_n(v_t_2472, 1ULL, 1);
                v_t_2474 = v_b_2473;
                break;
              }
              default: heff_nomatch(v_t_2472);
              }
              V v_t_2475 = heff_tag_at_n(v_ru_24t_2428_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2457, v_t_2468, v_t_2471, v_t_2474}), v_sp_241});
              V v_f_2476 = heff_tag_at_n(v_ru_24x11_2429_24Right, TAG_Right, 1, (V[]){v_t_2475});
              return ((HeffT2){{v_f_2476, v_st_2451}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x11_2450)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2449)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2429)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2428)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str0, 33, "` is named twice in one signature");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str1, 1, "`");

HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_n_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_n_242, 0))}));
    V v_t_245 = (g_list_2eany(v_t_244, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_seen_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V v_t_246 = heff_strAppend(heff_take_field(v_n_242, 0), ((V)&g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str0));
      V v_f_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str1), v_t_246), heff_get_n(v_n_242, 1, 2), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_247}});
    } else {
      heff_drop(v_t_245);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_n_242, 0, 2), v_seen_240});
      V t_0 = v_t_248;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2emutualDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualDefs_entry, 1, 0};

V g_heff_2esyntax_2esurface_2emutualDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V v_f_244 = heff_field(v_x11_241, 1);
      V v_fsp_245 = heff_field(v_x11_241, 2);
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_sp_247 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 30ULL, 5);
      HeffT2 v_t_248 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_244, heff_dup(v_rest_242)));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_es_2412 = v_field_2410;
          V v_a_2413 = heff_take_field(v_sp_247, 1);
          V v_b_2414 = heff_take_field(v_es_2412, 1);
          V v_t_2416;
          if (heff_intLt_c_lent(v_a_2413, v_b_2414, 0)) {
            heff_drop(v_a_2413);
            v_t_2416 = v_b_2414;
          } else {
            heff_drop(v_b_2414);
            v_t_2416 = v_a_2413;
          }
          V v_t_2417 = ({ V rv_1 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_sp_247, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          V v_t_2418 = heff_rec_n(5, shape_name__span__ty__eqns__whole, (V[]){v_f_244, v_fsp_245, v_ty_246, heff_get_n(v_es_2412, 0, 2), v_t_2417});
          V v_cell_2419 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2418}), heff_hole()});
          V v_u_2420 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, heff_dup(v_cell_2419)));
          heff_drop(v_u_2420);
          return v_cell_2419;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_f_244);
          heff_drop(v_fsp_245);
          heff_drop(v_ty_246);
          heff_drop_rec(v_sp_247, 2);
          heff_drop(v_field_2410);
          V t_0 = v_rest_242;
          v_x1_240 = t_0;
          goto top;
        }
      }
    }
    case TAG_Eqn: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Whole: {
      V v_cell_2425 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_241}), heff_hole()});
      V v_u_2426 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, heff_dup(v_cell_2425)));
      heff_drop(v_u_2426);
      return v_cell_2425;
    }
    case TAG_Doc: {
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_241}), heff_hole()});
      V v_u_2429 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, heff_dup(v_cell_2428)));
      heff_drop(v_u_2429);
      return v_cell_2428;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualDefs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0, 5, "`: it");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1, 31, "nothing can be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3, 4, "`: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4, 28, "` cannot be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8, 2, " (");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10, 83, " is the loosest operator, below every other, declared `below` with nothing after it");
Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V v_d_240, V v_u_241, V v_g_242) {
top: ;
  V v_t_243 = heff_get_n(v_d_240, 1, 8);
  V v_t_2410;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0));
    v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1), v_t_244);
    break;
  }
  case TAG_Cons: {
    V v_op_245 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2));
    V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3), v_t_247));
    V v_t_249 = heff_strAppend(heff_get_n(v_op_245, 1, 7), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4), v_t_248));
    v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5), v_t_249);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_at_2411 = heff_get_n(v_g_242, 4, 5);
  V v_t_2413;
  if (heff_strEq_c_lent(v_at_2411, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6), 2)) {
    heff_drop(v_at_2411);
    v_t_2413 = ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7);
  } else {
    v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8), heff_strAppend(v_at_2411, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9)));
  }
  V v_msg_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10), v_t_2413));
  V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_u_241, 2), heff_get_n(v_u_241, 3, 7)});
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2414, v_t_2415, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebelowLoosestDiag(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V v_names_240, V v_pats_241, V v_rhs_242, V v_w_243, V v_st_244) {
top: ;
  V v_t_245 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_f_246 = heff_get_n(v_t_245, 0, 2);
  HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_st_244, 3); V a_1 = v_f_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_f_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_t_2412;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_249;
      v_t_2412 = v_x_2411;
    } else {
      heff_drop(v_field_249);
      v_t_2412 = NTAG(TAG_Nil);
    }
    V v_pv_2413 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2412));
    V v_m_2414 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 1)), heff_dup(v_pats_241)));
    V v_t_2415 = ({ V rv_4 = v_pv_2413; V rr_ = heff_rec_reuse_nf(v_st_244, 495ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_t_2415}));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_MkPair: {
      V v_x11_2417 = heff_field(v_x1_2416, 0);
      V v_st_2418 = heff_field(v_x1_2416, 1);
      heff_take_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x11_2417)) {
      case TAG_Left: {
        V v_e_2419 = heff_field(v_x11_2417, 0);
        V v_ru_24x11_2417_24Left = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
        heff_drop(v_names_240);
        heff_drop(v_pats_241);
        heff_drop(v_rhs_242);
        heff_drop(v_t_2412);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2417_24Left, TAG_Left, 1, (V[]){v_e_2419}), v_st_2418}});
      }
      case TAG_Right: {
        V v_x_2420 = heff_field(v_x11_2417, 0);
        heff_take_n(v_x11_2417, 1ULL, 1);
        V v_t_2421 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2412));
        V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2421}));
        V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_pats_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_241); r_; });
        V v_t_2424 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2412); r_; });
        V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2423, v_t_2424));
        V v_t_2426 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2418, 495ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2425, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0, 1, 4, (V[]){v_rhs_242, heff_dup(v_w_243), v_names_240, v_x_2420}), v_t_2426));
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2417)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2416)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1(V self, V *args) {
  V v_st_2433 = args[0];
  V v_x_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2432}), v_st_2433});
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2(V self, V *args) {
  V v_rhs_27_2438 = args[0];
  V v_z_2439 = args[1];
  V v_names_240 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_t_2441 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_t_2442 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_t_2443 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2441, 0, 2), heff_get_n(v_t_2442, 1, 2), v_x_2420, heff_dup(v_rhs_27_2438)});
  V v_t_2446;
  switch (heff_tag_of(v_names_240)) {
  case TAG_Nil: {
    v_t_2446 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2444 = heff_dup(heff_field(v_names_240, 0));
    v_t_2446 = heff_get_n(v_t_2444, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_240);
  }
  V v_t_2449;
  switch (heff_tag_of(v_rhs_27_2438)) {
  case TAG_At: {
    V v_s_2448 = heff_dup(heff_field(v_rhs_27_2438, 1));
    v_t_2449 = v_s_2448;
    break;
  }
  default: heff_nomatch(v_rhs_27_2438);
  }
  V v_t_2450 = ({ V rv_0 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_t_2449, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2453;
  switch (heff_tag_of(v_names_240)) {
  case TAG_Nil: {
    v_t_2453 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2451 = heff_field(v_names_240, 0);
    heff_take_n(v_names_240, 1ULL, 2);
    v_t_2453 = heff_get_n(v_t_2451, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_240);
  }
  V v_t_2456;
  switch (heff_tag_of(v_rhs_27_2438)) {
  case TAG_At: {
    V v_s_2455 = heff_field(v_rhs_27_2438, 1);
    heff_take_n(v_rhs_27_2438, 2ULL, 2);
    v_t_2456 = v_s_2455;
    break;
  }
  default: heff_nomatch(v_rhs_27_2438);
  }
  V v_t_2457 = ({ V rv_0 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_t_2456, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2458 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2440, 0, 2), heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_t_2450}), v_t_2457});
  V v_x_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2459}), v_z_2439});
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args) {
  V v_st_2427 = args[0];
  V v_rhs_242 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_names_240 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2428 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_rhs_242, v_st_2427));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_MkPair: {
    V v_x11_2429 = heff_field(v_x1_2428, 0);
    V v_st_2430 = heff_field(v_x1_2428, 1);
    V v_ru_24x1_2428_24MkPair = heff_take_reuse_n(v_x1_2428, 3ULL, 2);
    switch (heff_tag_of(v_x11_2429)) {
    case TAG_Left: {
      V v_e_2431 = heff_field(v_x11_2429, 0);
      heff_take_n(v_x11_2429, 1ULL, 1);
      heff_drop(v_w_243);
      heff_drop(v_names_240);
      heff_drop(v_x_2420);
      return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2431}), v_st_2430});
    }
    case TAG_Right: {
      V v_x_2432 = heff_field(v_x11_2429, 0);
      heff_take_n(v_x11_2429, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_2428_24MkPair, 2);
      V v_t_2437;
      switch (heff_tag_of(v_w_243)) {
      case TAG_Nothing: {
        v_t_2437 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1, 1, 1, (V[]){v_x_2432});
        break;
      }
      case TAG_Just: {
        V v_it1_2434 = heff_field(v_w_243, 0);
        heff_take_n(v_w_243, 1ULL, 1);
        switch (heff_tag_of(v_it1_2434)) {
        case TAG_MkPair: {
          V v_kw_2435 = heff_field(v_it1_2434, 0);
          V v_ds_2436 = heff_field(v_it1_2434, 1);
          heff_take_n(v_it1_2434, 3ULL, 2);
          v_t_2437 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo), 3, (V[]){v_kw_2435, v_ds_2436, v_x_2432}));
          break;
        }
        default: heff_nomatch(v_it1_2434);
        }
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      return (g_heff_2esyntax_2esurface_2ebind(v_t_2437, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2, 2, 2, (V[]){v_names_240, v_x_2420}), v_st_2430));
    }
    default: return heff_nomatch(v_x11_2429);
    }
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1, 1, "(");
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(heff_dup(v_e_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_f_245 = v_field_243;
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0, 1, 2, (V[]){v_f_245, v_e_240});
    } else {
      heff_drop(v_field_243);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1, 1, 1, (V[]){v_e_240});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_f_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(v_f_245, v_st_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      HeffT2 v_t_2414 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(heff_dup(v_x_2413)));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop(v_x_2413);
          V v_q_2418 = v_field_2416;
          V v_t_2419 = heff_tag_n(TAG_ImplicitParam, 3, (V[]){heff_take_field(v_q_2418, 0), heff_take_field(v_q_2418, 1), heff_get_n(v_q_2418, 2, 3)});
          V v_a_2420 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
          V v_b_2421 = (g_heff_2esyntax_2ecst_2elastE(v_e_240));
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2420, 3, 9), heff_get_n(v_b_2421, 4, 9)});
          V v_x_2423 = heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_t_2422});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){v_x_2423}), v_st_2411});
        } else {
          heff_drop(v_e_240);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          heff_drop(v_field_2416);
          V v_t_2426;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_At: {
            V v_s_2425 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2426 = v_s_2425;
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0), v_t_2426, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2427}), v_st_2411});
        }
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args) {
  V v_st_2437 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2433}), v_st_2437});
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args) {
  V v_st_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_240), v_st_2428));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_t_2434 = ({ V a_0 = v_e_240; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_240); r_; });
      V v_m_2438;
      if (heff_strEq_c(heff_get_n(v_t_2434, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1))) {
        V v_t_2436 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2433));
        v_m_2438 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2436}));
      } else {
        v_m_2438 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2, 1, 1, (V[]){v_x_2433});
      }
      V v_x1_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_st_2431}));
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_MkPair: {
        V v_x11_2440 = heff_field(v_x1_2439, 0);
        V v_st_2441 = heff_field(v_x1_2439, 1);
        heff_take_n(v_x1_2439, 3ULL, 2);
        switch (heff_tag_of(v_x11_2440)) {
        case TAG_Left: {
          V v_e_2442 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
        }
        case TAG_Right: {
          V v_x_2443 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_2429_24MkPair, 2);
          return (g_heff_2esyntax_2esurface_2eparamOf(v_x_2443, v_st_2441));
        }
        default: return heff_nomatch(v_x11_2440);
        }
      }
      default: return heff_nomatch(v_x1_2439);
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(heff_dup(v_e_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      heff_drop(v_e_240);
      V v_x_245 = v_field_243;
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0, 1, 1, (V[]){v_x_245});
    } else {
      heff_drop(v_field_243);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(v_e_240);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_245, 3)), heff_dup(heff_rfield(v_x_245, 4))});
  V v_t_248 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_245, 3)), heff_dup(heff_rfield(v_x_245, 4))});
  V v_t_2410 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_x_245, 1), v_t_247, heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_t_249})});
  V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
  V v_t_2412 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2411})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_st_246});
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam44(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Atom: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EParen: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Named: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Tup: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Seg: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Braces: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Update: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EUSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7, 1, 1, (V[]){v_x2_240});
  }
  case TAG_InstB: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFDefault: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Sum: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ECon: {
    V v_c_24130 = heff_field(v_x2_240, 0);
    V v_args_24131 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24132 = (g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(v_c_24130, v_args_24131));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12, 1, 1, (V[]){v_m_24132});
  }
  case TAG_EField: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ENeg: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ETilde: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_App: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Op: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Ops: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_OpRhs: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Ann: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BVar: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BImp: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BAnn: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BPat: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Lam: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Case: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAlt: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27, 1, 1, (V[]){v_x2_240});
  }
  case TAG_If: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Do: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ESBind: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELetElse: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELetMut: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAssign: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EWhile: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFor: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EJump: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EReturn: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam38, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ENest: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam39, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EArrow: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam40, 1, 1, (V[]){v_x2_240});
  }
  case TAG_IfThen: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam41, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ETry: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam42, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ECatch: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam43, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EWith: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam44, 1, 1, (V[]){v_x2_240});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(a[0]);
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      V v_x_248 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_247));
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_248}), v_st_245});
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      V v_x_2418 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2417));
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2418}), v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args) {
  V v_st_2424 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2424));
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_MkPair: {
    V v_x11_2426 = heff_field(v_x1_2425, 0);
    V v_st_2427 = heff_field(v_x1_2425, 1);
    V v_ru_24x1_2425_24MkPair = heff_take_reuse_n(v_x1_2425, 3ULL, 2);
    switch (heff_tag_of(v_x11_2426)) {
    case TAG_Left: {
      V v_e_2428 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2428}), v_st_2427});
    }
    case TAG_Right: {
      V v_x_2429 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      V v_x_2430 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2429));
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2430}), v_st_2427});
    }
    default: return heff_nomatch(v_x11_2426);
    }
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args) {
  V v_st_2435 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2436 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2435));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_MkPair: {
    V v_x11_2437 = heff_field(v_x1_2436, 0);
    V v_st_2438 = heff_field(v_x1_2436, 1);
    V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_Left: {
      V v_e_2439 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      V v_x_2441 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2440));
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2441}), v_st_2438});
    }
    default: return heff_nomatch(v_x11_2437);
    }
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args) {
  V v_st_2445 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2446 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2445));
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_MkPair: {
    V v_x11_2447 = heff_field(v_x1_2446, 0);
    V v_st_2448 = heff_field(v_x1_2446, 1);
    V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
    switch (heff_tag_of(v_x11_2447)) {
    case TAG_Left: {
      V v_e_2449 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
    }
    case TAG_Right: {
      V v_x_2450 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      V v_x_2451 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2450));
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2451}), v_st_2448});
    }
    default: return heff_nomatch(v_x11_2447);
    }
  }
  default: return heff_nomatch(v_x1_2446);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args) {
  V v_st_2456 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2457 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2456));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_MkPair: {
    V v_x11_2458 = heff_field(v_x1_2457, 0);
    V v_st_2459 = heff_field(v_x1_2457, 1);
    V v_ru_24x1_2457_24MkPair = heff_take_reuse_n(v_x1_2457, 3ULL, 2);
    switch (heff_tag_of(v_x11_2458)) {
    case TAG_Left: {
      V v_e_2460 = heff_field(v_x11_2458, 0);
      heff_take_n(v_x11_2458, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2460}), v_st_2459});
    }
    case TAG_Right: {
      V v_x_2461 = heff_field(v_x11_2458, 0);
      heff_take_n(v_x11_2458, 1ULL, 1);
      V v_x_2462 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2461));
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2462}), v_st_2459});
    }
    default: return heff_nomatch(v_x11_2458);
    }
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args) {
  V v_st_2469 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2470 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2469));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_MkPair: {
    V v_x11_2471 = heff_field(v_x1_2470, 0);
    V v_st_2472 = heff_field(v_x1_2470, 1);
    V v_ru_24x1_2470_24MkPair = heff_take_reuse_n(v_x1_2470, 3ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_Left: {
      V v_e_2473 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2473}), v_st_2472});
    }
    case TAG_Right: {
      V v_x_2474 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      V v_x_2475 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2474));
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2475}), v_st_2472});
    }
    default: return heff_nomatch(v_x11_2471);
    }
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args) {
  V v_st_2479 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2480 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2479));
  switch (heff_tag_of(v_x1_2480)) {
  case TAG_MkPair: {
    V v_x11_2481 = heff_field(v_x1_2480, 0);
    V v_st_2482 = heff_field(v_x1_2480, 1);
    V v_ru_24x1_2480_24MkPair = heff_take_reuse_n(v_x1_2480, 3ULL, 2);
    switch (heff_tag_of(v_x11_2481)) {
    case TAG_Left: {
      V v_e_2483 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2483}), v_st_2482});
    }
    case TAG_Right: {
      V v_x_2484 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      V v_x_2485 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2484));
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2485}), v_st_2482});
    }
    default: return heff_nomatch(v_x11_2481);
    }
  }
  default: return heff_nomatch(v_x1_2480);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args) {
  V v_st_2491 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2492 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2491));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      V v_x_2497 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2496));
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2497}), v_st_2494});
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args) {
  V v_st_24101 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24101));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24106));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args) {
  V v_st_24111 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24112 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24111));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_MkPair: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_st_24114 = heff_field(v_x1_24112, 1);
    V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_Left: {
      V v_e_24115 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
    }
    case TAG_Right: {
      V v_x_24116 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      V v_x_24117 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24116));
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24117}), v_st_24114});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args) {
  V v_st_24123 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24124 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24123));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      V v_x_24129 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24128));
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24129}), v_st_24126});
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args) {
  V v_st_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_st_24133}));
  switch (heff_tag_of(v_x1_24134)) {
  case TAG_MkPair: {
    V v_x11_24135 = heff_field(v_x1_24134, 0);
    V v_st_24136 = heff_field(v_x1_24134, 1);
    V v_ru_24x1_24134_24MkPair = heff_take_reuse_n(v_x1_24134, 3ULL, 2);
    switch (heff_tag_of(v_x11_24135)) {
    case TAG_Left: {
      V v_e_24137 = heff_field(v_x11_24135, 0);
      heff_take_n(v_x11_24135, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24137}), v_st_24136});
    }
    case TAG_Right: {
      V v_x_24138 = heff_field(v_x11_24135, 0);
      heff_take_n(v_x11_24135, 1ULL, 1);
      V v_x_24139 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24138));
      return heff_tag_at_n(v_ru_24x1_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24139}), v_st_24136});
    }
    default: return heff_nomatch(v_x11_24135);
    }
  }
  default: return heff_nomatch(v_x1_24134);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args) {
  V v_st_24142 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24143 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24142));
  switch (heff_tag_of(v_x1_24143)) {
  case TAG_MkPair: {
    V v_x11_24144 = heff_field(v_x1_24143, 0);
    V v_st_24145 = heff_field(v_x1_24143, 1);
    V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
    switch (heff_tag_of(v_x11_24144)) {
    case TAG_Left: {
      V v_e_24146 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
    }
    case TAG_Right: {
      V v_x_24147 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      V v_x_24148 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24147));
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24148}), v_st_24145});
    }
    default: return heff_nomatch(v_x11_24144);
    }
  }
  default: return heff_nomatch(v_x1_24143);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args) {
  V v_st_24151 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24152 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24151));
  switch (heff_tag_of(v_x1_24152)) {
  case TAG_MkPair: {
    V v_x11_24153 = heff_field(v_x1_24152, 0);
    V v_st_24154 = heff_field(v_x1_24152, 1);
    V v_ru_24x1_24152_24MkPair = heff_take_reuse_n(v_x1_24152, 3ULL, 2);
    switch (heff_tag_of(v_x11_24153)) {
    case TAG_Left: {
      V v_e_24155 = heff_field(v_x11_24153, 0);
      heff_take_n(v_x11_24153, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24155}), v_st_24154});
    }
    case TAG_Right: {
      V v_x_24156 = heff_field(v_x11_24153, 0);
      heff_take_n(v_x11_24153, 1ULL, 1);
      V v_x_24157 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24156));
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24157}), v_st_24154});
    }
    default: return heff_nomatch(v_x11_24153);
    }
  }
  default: return heff_nomatch(v_x1_24152);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args) {
  V v_st_24160 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24161 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24160));
  switch (heff_tag_of(v_x1_24161)) {
  case TAG_MkPair: {
    V v_x11_24162 = heff_field(v_x1_24161, 0);
    V v_st_24163 = heff_field(v_x1_24161, 1);
    V v_ru_24x1_24161_24MkPair = heff_take_reuse_n(v_x1_24161, 3ULL, 2);
    switch (heff_tag_of(v_x11_24162)) {
    case TAG_Left: {
      V v_e_24164 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24164}), v_st_24163});
    }
    case TAG_Right: {
      V v_x_24165 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      V v_x_24166 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24165));
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24163});
    }
    default: return heff_nomatch(v_x11_24162);
    }
  }
  default: return heff_nomatch(v_x1_24161);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args) {
  V v_st_24169 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24169));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      V v_x_24175 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24174));
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24175}), v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args) {
  V v_st_24179 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24180 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24179));
  switch (heff_tag_of(v_x1_24180)) {
  case TAG_MkPair: {
    V v_x11_24181 = heff_field(v_x1_24180, 0);
    V v_st_24182 = heff_field(v_x1_24180, 1);
    V v_ru_24x1_24180_24MkPair = heff_take_reuse_n(v_x1_24180, 3ULL, 2);
    switch (heff_tag_of(v_x11_24181)) {
    case TAG_Left: {
      V v_e_24183 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24183}), v_st_24182});
    }
    case TAG_Right: {
      V v_x_24184 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      V v_x_24185 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24184));
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24185}), v_st_24182});
    }
    default: return heff_nomatch(v_x11_24181);
    }
  }
  default: return heff_nomatch(v_x1_24180);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args) {
  V v_st_24188 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24189 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24188));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_MkPair: {
    V v_x11_24190 = heff_field(v_x1_24189, 0);
    V v_st_24191 = heff_field(v_x1_24189, 1);
    V v_ru_24x1_24189_24MkPair = heff_take_reuse_n(v_x1_24189, 3ULL, 2);
    switch (heff_tag_of(v_x11_24190)) {
    case TAG_Left: {
      V v_e_24192 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24192}), v_st_24191});
    }
    case TAG_Right: {
      V v_x_24193 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      V v_x_24194 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24193));
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24194}), v_st_24191});
    }
    default: return heff_nomatch(v_x11_24190);
    }
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args) {
  V v_st_24197 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24198 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24197));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_x11_24199 = heff_field(v_x1_24198, 0);
    V v_st_24200 = heff_field(v_x1_24198, 1);
    V v_ru_24x1_24198_24MkPair = heff_take_reuse_n(v_x1_24198, 3ULL, 2);
    switch (heff_tag_of(v_x11_24199)) {
    case TAG_Left: {
      V v_e_24201 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
    }
    case TAG_Right: {
      V v_x_24202 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      V v_x_24203 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24202));
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24203}), v_st_24200});
    }
    default: return heff_nomatch(v_x11_24199);
    }
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args) {
  V v_st_24207 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24208 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24207));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_MkPair: {
    V v_x11_24209 = heff_field(v_x1_24208, 0);
    V v_st_24210 = heff_field(v_x1_24208, 1);
    V v_ru_24x1_24208_24MkPair = heff_take_reuse_n(v_x1_24208, 3ULL, 2);
    switch (heff_tag_of(v_x11_24209)) {
    case TAG_Left: {
      V v_e_24211 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24211}), v_st_24210});
    }
    case TAG_Right: {
      V v_x_24212 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      V v_x_24213 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24212));
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24210});
    }
    default: return heff_nomatch(v_x11_24209);
    }
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args) {
  V v_st_24215 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24216 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24215));
  switch (heff_tag_of(v_x1_24216)) {
  case TAG_MkPair: {
    V v_x11_24217 = heff_field(v_x1_24216, 0);
    V v_st_24218 = heff_field(v_x1_24216, 1);
    V v_ru_24x1_24216_24MkPair = heff_take_reuse_n(v_x1_24216, 3ULL, 2);
    switch (heff_tag_of(v_x11_24217)) {
    case TAG_Left: {
      V v_e_24219 = heff_field(v_x11_24217, 0);
      heff_take_n(v_x11_24217, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24216_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24219}), v_st_24218});
    }
    case TAG_Right: {
      V v_x_24220 = heff_field(v_x11_24217, 0);
      heff_take_n(v_x11_24217, 1ULL, 1);
      V v_x_24221 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24220));
      return heff_tag_at_n(v_ru_24x1_24216_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24221}), v_st_24218});
    }
    default: return heff_nomatch(v_x11_24217);
    }
  }
  default: return heff_nomatch(v_x1_24216);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args) {
  V v_st_24225 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24226 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24225));
  switch (heff_tag_of(v_x1_24226)) {
  case TAG_MkPair: {
    V v_x11_24227 = heff_field(v_x1_24226, 0);
    V v_st_24228 = heff_field(v_x1_24226, 1);
    V v_ru_24x1_24226_24MkPair = heff_take_reuse_n(v_x1_24226, 3ULL, 2);
    switch (heff_tag_of(v_x11_24227)) {
    case TAG_Left: {
      V v_e_24229 = heff_field(v_x11_24227, 0);
      heff_take_n(v_x11_24227, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24229}), v_st_24228});
    }
    case TAG_Right: {
      V v_x_24230 = heff_field(v_x11_24227, 0);
      heff_take_n(v_x11_24227, 1ULL, 1);
      V v_x_24231 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24230));
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24231}), v_st_24228});
    }
    default: return heff_nomatch(v_x11_24227);
    }
  }
  default: return heff_nomatch(v_x1_24226);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args) {
  V v_st_24237 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24237));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_MkPair: {
    V v_x11_24239 = heff_field(v_x1_24238, 0);
    V v_st_24240 = heff_field(v_x1_24238, 1);
    V v_ru_24x1_24238_24MkPair = heff_take_reuse_n(v_x1_24238, 3ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_Left: {
      V v_e_24241 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24241}), v_st_24240});
    }
    case TAG_Right: {
      V v_x_24242 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      V v_x_24243 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24242));
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24243}), v_st_24240});
    }
    default: return heff_nomatch(v_x11_24239);
    }
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args) {
  V v_st_24245 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24246 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24245));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_MkPair: {
    V v_x11_24247 = heff_field(v_x1_24246, 0);
    V v_st_24248 = heff_field(v_x1_24246, 1);
    V v_ru_24x1_24246_24MkPair = heff_take_reuse_n(v_x1_24246, 3ULL, 2);
    switch (heff_tag_of(v_x11_24247)) {
    case TAG_Left: {
      V v_e_24249 = heff_field(v_x11_24247, 0);
      heff_take_n(v_x11_24247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24249}), v_st_24248});
    }
    case TAG_Right: {
      V v_x_24250 = heff_field(v_x11_24247, 0);
      heff_take_n(v_x11_24247, 1ULL, 1);
      V v_x_24251 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24250));
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24251}), v_st_24248});
    }
    default: return heff_nomatch(v_x11_24247);
    }
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args) {
  V v_st_24256 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24257 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24256));
  switch (heff_tag_of(v_x1_24257)) {
  case TAG_MkPair: {
    V v_x11_24258 = heff_field(v_x1_24257, 0);
    V v_st_24259 = heff_field(v_x1_24257, 1);
    V v_ru_24x1_24257_24MkPair = heff_take_reuse_n(v_x1_24257, 3ULL, 2);
    switch (heff_tag_of(v_x11_24258)) {
    case TAG_Left: {
      V v_e_24260 = heff_field(v_x11_24258, 0);
      heff_take_n(v_x11_24258, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24260}), v_st_24259});
    }
    case TAG_Right: {
      V v_x_24261 = heff_field(v_x11_24258, 0);
      heff_take_n(v_x11_24258, 1ULL, 1);
      V v_x_24262 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24261));
      return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24262}), v_st_24259});
    }
    default: return heff_nomatch(v_x11_24258);
    }
  }
  default: return heff_nomatch(v_x1_24257);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args) {
  V v_st_24267 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24268 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24267));
  switch (heff_tag_of(v_x1_24268)) {
  case TAG_MkPair: {
    V v_x11_24269 = heff_field(v_x1_24268, 0);
    V v_st_24270 = heff_field(v_x1_24268, 1);
    V v_ru_24x1_24268_24MkPair = heff_take_reuse_n(v_x1_24268, 3ULL, 2);
    switch (heff_tag_of(v_x11_24269)) {
    case TAG_Left: {
      V v_e_24271 = heff_field(v_x11_24269, 0);
      heff_take_n(v_x11_24269, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24271}), v_st_24270});
    }
    case TAG_Right: {
      V v_x_24272 = heff_field(v_x11_24269, 0);
      heff_take_n(v_x11_24269, 1ULL, 1);
      V v_x_24273 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24272));
      return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24273}), v_st_24270});
    }
    default: return heff_nomatch(v_x11_24269);
    }
  }
  default: return heff_nomatch(v_x1_24268);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args) {
  V v_st_24277 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24278 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24277));
  switch (heff_tag_of(v_x1_24278)) {
  case TAG_MkPair: {
    V v_x11_24279 = heff_field(v_x1_24278, 0);
    V v_st_24280 = heff_field(v_x1_24278, 1);
    V v_ru_24x1_24278_24MkPair = heff_take_reuse_n(v_x1_24278, 3ULL, 2);
    switch (heff_tag_of(v_x11_24279)) {
    case TAG_Left: {
      V v_e_24281 = heff_field(v_x11_24279, 0);
      heff_take_n(v_x11_24279, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24278_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24281}), v_st_24280});
    }
    case TAG_Right: {
      V v_x_24282 = heff_field(v_x11_24279, 0);
      heff_take_n(v_x11_24279, 1ULL, 1);
      V v_x_24283 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24282));
      return heff_tag_at_n(v_ru_24x1_24278_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24283}), v_st_24280});
    }
    default: return heff_nomatch(v_x11_24279);
    }
  }
  default: return heff_nomatch(v_x1_24278);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args) {
  V v_st_24290 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24291 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24290));
  switch (heff_tag_of(v_x1_24291)) {
  case TAG_MkPair: {
    V v_x11_24292 = heff_field(v_x1_24291, 0);
    V v_st_24293 = heff_field(v_x1_24291, 1);
    V v_ru_24x1_24291_24MkPair = heff_take_reuse_n(v_x1_24291, 3ULL, 2);
    switch (heff_tag_of(v_x11_24292)) {
    case TAG_Left: {
      V v_e_24294 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24294}), v_st_24293});
    }
    case TAG_Right: {
      V v_x_24295 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      V v_x_24296 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24295));
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24296}), v_st_24293});
    }
    default: return heff_nomatch(v_x11_24292);
    }
  }
  default: return heff_nomatch(v_x1_24291);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29(V self, V *args) {
  V v_st_24299 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24300 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24299));
  switch (heff_tag_of(v_x1_24300)) {
  case TAG_MkPair: {
    V v_x11_24301 = heff_field(v_x1_24300, 0);
    V v_st_24302 = heff_field(v_x1_24300, 1);
    V v_ru_24x1_24300_24MkPair = heff_take_reuse_n(v_x1_24300, 3ULL, 2);
    switch (heff_tag_of(v_x11_24301)) {
    case TAG_Left: {
      V v_e_24303 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24303}), v_st_24302});
    }
    case TAG_Right: {
      V v_x_24304 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      V v_x_24305 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24304));
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24305}), v_st_24302});
    }
    default: return heff_nomatch(v_x11_24301);
    }
  }
  default: return heff_nomatch(v_x1_24300);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30(V self, V *args) {
  V v_st_24309 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24310 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24309));
  switch (heff_tag_of(v_x1_24310)) {
  case TAG_MkPair: {
    V v_x11_24311 = heff_field(v_x1_24310, 0);
    V v_st_24312 = heff_field(v_x1_24310, 1);
    V v_ru_24x1_24310_24MkPair = heff_take_reuse_n(v_x1_24310, 3ULL, 2);
    switch (heff_tag_of(v_x11_24311)) {
    case TAG_Left: {
      V v_e_24313 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24313}), v_st_24312});
    }
    case TAG_Right: {
      V v_x_24314 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      V v_x_24315 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24314));
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24315}), v_st_24312});
    }
    default: return heff_nomatch(v_x11_24311);
    }
  }
  default: return heff_nomatch(v_x1_24310);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31(V self, V *args) {
  V v_st_24322 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24323 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24322));
  switch (heff_tag_of(v_x1_24323)) {
  case TAG_MkPair: {
    V v_x11_24324 = heff_field(v_x1_24323, 0);
    V v_st_24325 = heff_field(v_x1_24323, 1);
    V v_ru_24x1_24323_24MkPair = heff_take_reuse_n(v_x1_24323, 3ULL, 2);
    switch (heff_tag_of(v_x11_24324)) {
    case TAG_Left: {
      V v_e_24326 = heff_field(v_x11_24324, 0);
      heff_take_n(v_x11_24324, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24323_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24326}), v_st_24325});
    }
    case TAG_Right: {
      V v_x_24327 = heff_field(v_x11_24324, 0);
      heff_take_n(v_x11_24324, 1ULL, 1);
      V v_x_24328 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24327));
      return heff_tag_at_n(v_ru_24x1_24323_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24328}), v_st_24325});
    }
    default: return heff_nomatch(v_x11_24324);
    }
  }
  default: return heff_nomatch(v_x1_24323);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32(V self, V *args) {
  V v_st_24336 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24337 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24336));
  switch (heff_tag_of(v_x1_24337)) {
  case TAG_MkPair: {
    V v_x11_24338 = heff_field(v_x1_24337, 0);
    V v_st_24339 = heff_field(v_x1_24337, 1);
    V v_ru_24x1_24337_24MkPair = heff_take_reuse_n(v_x1_24337, 3ULL, 2);
    switch (heff_tag_of(v_x11_24338)) {
    case TAG_Left: {
      V v_e_24340 = heff_field(v_x11_24338, 0);
      heff_take_n(v_x11_24338, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24340}), v_st_24339});
    }
    case TAG_Right: {
      V v_x_24341 = heff_field(v_x11_24338, 0);
      heff_take_n(v_x11_24338, 1ULL, 1);
      V v_x_24342 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24341));
      return heff_tag_at_n(v_ru_24x1_24337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24342}), v_st_24339});
    }
    default: return heff_nomatch(v_x11_24338);
    }
  }
  default: return heff_nomatch(v_x1_24337);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33(V self, V *args) {
  V v_st_24349 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24350 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24349));
  switch (heff_tag_of(v_x1_24350)) {
  case TAG_MkPair: {
    V v_x11_24351 = heff_field(v_x1_24350, 0);
    V v_st_24352 = heff_field(v_x1_24350, 1);
    V v_ru_24x1_24350_24MkPair = heff_take_reuse_n(v_x1_24350, 3ULL, 2);
    switch (heff_tag_of(v_x11_24351)) {
    case TAG_Left: {
      V v_e_24353 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24353}), v_st_24352});
    }
    case TAG_Right: {
      V v_x_24354 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      V v_x_24355 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24354));
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24355}), v_st_24352});
    }
    default: return heff_nomatch(v_x11_24351);
    }
  }
  default: return heff_nomatch(v_x1_24350);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34(V self, V *args) {
  V v_st_24359 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24360 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24359));
  switch (heff_tag_of(v_x1_24360)) {
  case TAG_MkPair: {
    V v_x11_24361 = heff_field(v_x1_24360, 0);
    V v_st_24362 = heff_field(v_x1_24360, 1);
    V v_ru_24x1_24360_24MkPair = heff_take_reuse_n(v_x1_24360, 3ULL, 2);
    switch (heff_tag_of(v_x11_24361)) {
    case TAG_Left: {
      V v_e_24363 = heff_field(v_x11_24361, 0);
      heff_take_n(v_x11_24361, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24360_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24363}), v_st_24362});
    }
    case TAG_Right: {
      V v_x_24364 = heff_field(v_x11_24361, 0);
      heff_take_n(v_x11_24361, 1ULL, 1);
      V v_x_24365 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24364));
      return heff_tag_at_n(v_ru_24x1_24360_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24365}), v_st_24362});
    }
    default: return heff_nomatch(v_x11_24361);
    }
  }
  default: return heff_nomatch(v_x1_24360);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35(V self, V *args) {
  V v_st_24370 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24371 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24370));
  switch (heff_tag_of(v_x1_24371)) {
  case TAG_MkPair: {
    V v_x11_24372 = heff_field(v_x1_24371, 0);
    V v_st_24373 = heff_field(v_x1_24371, 1);
    V v_ru_24x1_24371_24MkPair = heff_take_reuse_n(v_x1_24371, 3ULL, 2);
    switch (heff_tag_of(v_x11_24372)) {
    case TAG_Left: {
      V v_e_24374 = heff_field(v_x11_24372, 0);
      heff_take_n(v_x11_24372, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24371_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24374}), v_st_24373});
    }
    case TAG_Right: {
      V v_x_24375 = heff_field(v_x11_24372, 0);
      heff_take_n(v_x11_24372, 1ULL, 1);
      V v_x_24376 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24375));
      return heff_tag_at_n(v_ru_24x1_24371_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24376}), v_st_24373});
    }
    default: return heff_nomatch(v_x11_24372);
    }
  }
  default: return heff_nomatch(v_x1_24371);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36(V self, V *args) {
  V v_st_24383 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24384 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24383));
  switch (heff_tag_of(v_x1_24384)) {
  case TAG_MkPair: {
    V v_x11_24385 = heff_field(v_x1_24384, 0);
    V v_st_24386 = heff_field(v_x1_24384, 1);
    V v_ru_24x1_24384_24MkPair = heff_take_reuse_n(v_x1_24384, 3ULL, 2);
    switch (heff_tag_of(v_x11_24385)) {
    case TAG_Left: {
      V v_e_24387 = heff_field(v_x11_24385, 0);
      heff_take_n(v_x11_24385, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24384_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24387}), v_st_24386});
    }
    case TAG_Right: {
      V v_x_24388 = heff_field(v_x11_24385, 0);
      heff_take_n(v_x11_24385, 1ULL, 1);
      V v_x_24389 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24388));
      return heff_tag_at_n(v_ru_24x1_24384_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24389}), v_st_24386});
    }
    default: return heff_nomatch(v_x11_24385);
    }
  }
  default: return heff_nomatch(v_x1_24384);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37(V self, V *args) {
  V v_st_24391 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24392 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24391));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_MkPair: {
    V v_x11_24393 = heff_field(v_x1_24392, 0);
    V v_st_24394 = heff_field(v_x1_24392, 1);
    V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
    switch (heff_tag_of(v_x11_24393)) {
    case TAG_Left: {
      V v_e_24395 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
    }
    case TAG_Right: {
      V v_x_24396 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      V v_x_24397 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24396));
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24397}), v_st_24394});
    }
    default: return heff_nomatch(v_x11_24393);
    }
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam38(V self, V *args) {
  V v_st_24400 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24401 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24400));
  switch (heff_tag_of(v_x1_24401)) {
  case TAG_MkPair: {
    V v_x11_24402 = heff_field(v_x1_24401, 0);
    V v_st_24403 = heff_field(v_x1_24401, 1);
    V v_ru_24x1_24401_24MkPair = heff_take_reuse_n(v_x1_24401, 3ULL, 2);
    switch (heff_tag_of(v_x11_24402)) {
    case TAG_Left: {
      V v_e_24404 = heff_field(v_x11_24402, 0);
      heff_take_n(v_x11_24402, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24401_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24404}), v_st_24403});
    }
    case TAG_Right: {
      V v_x_24405 = heff_field(v_x11_24402, 0);
      heff_take_n(v_x11_24402, 1ULL, 1);
      V v_x_24406 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24405));
      return heff_tag_at_n(v_ru_24x1_24401_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24406}), v_st_24403});
    }
    default: return heff_nomatch(v_x11_24402);
    }
  }
  default: return heff_nomatch(v_x1_24401);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam39(V self, V *args) {
  V v_st_24411 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24412 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24411));
  switch (heff_tag_of(v_x1_24412)) {
  case TAG_MkPair: {
    V v_x11_24413 = heff_field(v_x1_24412, 0);
    V v_st_24414 = heff_field(v_x1_24412, 1);
    V v_ru_24x1_24412_24MkPair = heff_take_reuse_n(v_x1_24412, 3ULL, 2);
    switch (heff_tag_of(v_x11_24413)) {
    case TAG_Left: {
      V v_e_24415 = heff_field(v_x11_24413, 0);
      heff_take_n(v_x11_24413, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24415}), v_st_24414});
    }
    case TAG_Right: {
      V v_x_24416 = heff_field(v_x11_24413, 0);
      heff_take_n(v_x11_24413, 1ULL, 1);
      V v_x_24417 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24416));
      return heff_tag_at_n(v_ru_24x1_24412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24417}), v_st_24414});
    }
    default: return heff_nomatch(v_x11_24413);
    }
  }
  default: return heff_nomatch(v_x1_24412);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam40(V self, V *args) {
  V v_st_24420 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24421 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24420));
  switch (heff_tag_of(v_x1_24421)) {
  case TAG_MkPair: {
    V v_x11_24422 = heff_field(v_x1_24421, 0);
    V v_st_24423 = heff_field(v_x1_24421, 1);
    V v_ru_24x1_24421_24MkPair = heff_take_reuse_n(v_x1_24421, 3ULL, 2);
    switch (heff_tag_of(v_x11_24422)) {
    case TAG_Left: {
      V v_e_24424 = heff_field(v_x11_24422, 0);
      heff_take_n(v_x11_24422, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24424}), v_st_24423});
    }
    case TAG_Right: {
      V v_x_24425 = heff_field(v_x11_24422, 0);
      heff_take_n(v_x11_24422, 1ULL, 1);
      V v_x_24426 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24425));
      return heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24426}), v_st_24423});
    }
    default: return heff_nomatch(v_x11_24422);
    }
  }
  default: return heff_nomatch(v_x1_24421);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam41(V self, V *args) {
  V v_st_24431 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24432 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24431));
  switch (heff_tag_of(v_x1_24432)) {
  case TAG_MkPair: {
    V v_x11_24433 = heff_field(v_x1_24432, 0);
    V v_st_24434 = heff_field(v_x1_24432, 1);
    V v_ru_24x1_24432_24MkPair = heff_take_reuse_n(v_x1_24432, 3ULL, 2);
    switch (heff_tag_of(v_x11_24433)) {
    case TAG_Left: {
      V v_e_24435 = heff_field(v_x11_24433, 0);
      heff_take_n(v_x11_24433, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24435}), v_st_24434});
    }
    case TAG_Right: {
      V v_x_24436 = heff_field(v_x11_24433, 0);
      heff_take_n(v_x11_24433, 1ULL, 1);
      V v_x_24437 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24436));
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24437}), v_st_24434});
    }
    default: return heff_nomatch(v_x11_24433);
    }
  }
  default: return heff_nomatch(v_x1_24432);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam42(V self, V *args) {
  V v_st_24442 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24443 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24442));
  switch (heff_tag_of(v_x1_24443)) {
  case TAG_MkPair: {
    V v_x11_24444 = heff_field(v_x1_24443, 0);
    V v_st_24445 = heff_field(v_x1_24443, 1);
    V v_ru_24x1_24443_24MkPair = heff_take_reuse_n(v_x1_24443, 3ULL, 2);
    switch (heff_tag_of(v_x11_24444)) {
    case TAG_Left: {
      V v_e_24446 = heff_field(v_x11_24444, 0);
      heff_take_n(v_x11_24444, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24446}), v_st_24445});
    }
    case TAG_Right: {
      V v_x_24447 = heff_field(v_x11_24444, 0);
      heff_take_n(v_x11_24444, 1ULL, 1);
      V v_x_24448 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24447));
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24448}), v_st_24445});
    }
    default: return heff_nomatch(v_x11_24444);
    }
  }
  default: return heff_nomatch(v_x1_24443);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam43(V self, V *args) {
  V v_st_24453 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24454 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24453));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_MkPair: {
    V v_x11_24455 = heff_field(v_x1_24454, 0);
    V v_st_24456 = heff_field(v_x1_24454, 1);
    V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
    switch (heff_tag_of(v_x11_24455)) {
    case TAG_Left: {
      V v_e_24457 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
    }
    case TAG_Right: {
      V v_x_24458 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      V v_x_24459 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24458));
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24459}), v_st_24456});
    }
    default: return heff_nomatch(v_x11_24455);
    }
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam44(V self, V *args) {
  V v_st_24466 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24467 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24466));
  switch (heff_tag_of(v_x1_24467)) {
  case TAG_MkPair: {
    V v_x11_24468 = heff_field(v_x1_24467, 0);
    V v_st_24469 = heff_field(v_x1_24467, 1);
    V v_ru_24x1_24467_24MkPair = heff_take_reuse_n(v_x1_24467, 3ULL, 2);
    switch (heff_tag_of(v_x11_24468)) {
    case TAG_Left: {
      V v_e_24470 = heff_field(v_x11_24468, 0);
      heff_take_n(v_x11_24468, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24470}), v_st_24469});
    }
    case TAG_Right: {
      V v_x_24471 = heff_field(v_x11_24468, 0);
      heff_take_n(v_x11_24468, 1ULL, 1);
      V v_x_24472 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24471));
      return heff_tag_at_n(v_ru_24x1_24467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24472}), v_st_24469});
    }
    default: return heff_nomatch(v_x11_24468);
    }
  }
  default: return heff_nomatch(v_x1_24467);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_fields_244, V v_z_245) {
top: ;
  V v_m_246 = (g_prelude_2etraverse_24s518454301x170091462(v_params_243));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    heff_take_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_fields_244);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Left, TAG_Left, 1, (V[]){v_e_2410}), v_st_249}});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2411)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2412, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0, 1, 5, (V[]){v_fields_244, v_name_242, v_d_240, v_kw_241, v_x_2411}), v_st_249));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args) {
  V v_st_2413 = args[0];
  V v_fields_244 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_d_240 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_m_2414 = (g_prelude_2etraverse_24s956608878x365908798(v_fields_244));
  V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){heff_dup(v_st_2413)}));
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_MkPair: {
    V v_x11_2416 = heff_field(v_x1_2415, 0);
    V v_st_2417 = heff_field(v_x1_2415, 1);
    V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
    switch (heff_tag_of(v_x11_2416)) {
    case TAG_Left: {
      V v_e_2418 = heff_field(v_x11_2416, 0);
      heff_take_n(v_x11_2416, 1ULL, 1);
      heff_drop_rec(v_st_2413, 9);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_x_2411);
      return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_x11_2416, 0);
      V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 1ULL, 1);
      V v_t_2420 = ({ V rv_1 = heff_get_n(v_st_2413, 1, 9); V rr_ = heff_rec_reuse_nf(v_st_2417, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
      V v_t_2422 = ({ V a_0 = v_x_2419; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2419); r_; });
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2424});
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_ESig, 1, (V[]){v_t_2422}), v_t_2425});
      V v_t_2427 = heff_tag_n(TAG_DeclTheory, 4, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2421, v_x_2411, v_t_2426});
      V v_t_2428 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
      V v_e_2429 = heff_get_n(v_t_2428, 4, 9);
      V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2429});
      V v_t_2431 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_t_2430})});
      V v_x_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2432}), v_t_2420});
    }
    default: return heff_nomatch(v_x11_2416);
    }
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V v_ys_240, V v_pv_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_245 = heff_field(v_x2_242, 1);
    V v_t_247 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_245));
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(v_t_247, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_248);
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 1)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2))) {
          V v_t_2413 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_249, 1))}));
          V v_t_2414 = (g_list_2eany(v_t_2413, v_pv_241));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            V v_x_2415 = heff_dup(heff_rfield(v_t_249, 1));
            V v_t_2416 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
            return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_t_2416}));
          } else {
            heff_drop(v_t_2414);
            return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
          }
        } else {
          return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
        }
      } else {
        V v_x_2417 = heff_dup(heff_rfield(v_t_249, 1));
        V v_t_2418 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
        return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_t_2418}));
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str3))) {
        V v_t_2420 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_249, 1))}));
        V v_t_2421 = (g_list_2eany(v_t_2420, v_pv_241));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          V v_x_2422 = heff_dup(heff_rfield(v_t_249, 1));
          V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, v_t_2423}));
        } else {
          heff_drop(v_t_2421);
          return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
        }
      } else {
        return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2425 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2425;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2428 = heff_field(v_x2_242, 1);
    V v_t_2432 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2428));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2432, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2433);
  }
  case TAG_POp: {
    V v_l_2434 = heff_field(v_x2_242, 0);
    V v_q_2436 = heff_field(v_x2_242, 2);
    V v_t_2437 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2434));
    V v_t_2438 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2436));
    V v_t_2439 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2437, v_t_2438));
    V v_t_2440 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2439, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2440);
  }
  case TAG_PRec: {
    V v_fs_2442 = heff_field(v_x2_242, 1);
    V v_t_2446 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2442));
    V v_t_2447 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2446, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2447);
  }
  case TAG_PField: {
    V v_q_2450 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2450;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2451 = heff_field(v_x2_242, 0);
    V v_q_2453 = heff_field(v_x2_242, 2);
    V v_x_2454 = heff_dup(heff_rfield(v_x_2451, 1));
    V v_cell_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2454, heff_hole()});
    V v_u_2456 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2455));
    heff_drop(v_u_2456);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2453;
    V t_3 = v_cell_2455;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2457 = heff_field(v_x2_242, 0);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2457;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args) {
  V v_q_246 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_246; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_246); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args) {
  V v_q_2431 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2431; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2431); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args) {
  V v_q_2445 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2445; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2445); r_; });
}