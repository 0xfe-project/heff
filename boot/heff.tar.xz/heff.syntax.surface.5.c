// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_If 9134
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkFields 41650
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Same 22203
#define TAG_Sum 30935
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_head 9693863
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2ebothLoosest(V, V, V);
V g_heff_2esyntax_2efixity_2ebothLoosest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2ebothLoosest_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2earrowNames(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2eatomOf(V);
V g_heff_2esyntax_2esurface_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomOf_clo;
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V, V, V);
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracedOne(V);
V g_heff_2esyntax_2esurface_2ebracedOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedOne_clo;
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V, V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo;
V g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_clo;
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldsOf(V, V);
V g_heff_2esyntax_2esurface_2efieldsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldsOf_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
double g_heff_2esyntax_2esurface_2efloatSplit_w(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatSplit_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eipow10(V);
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eipow10_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2enameAnn(V);
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameAnn_clo;
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldL(V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldL_clo;
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eintOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintOfText_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eintOfText(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str0))) {
    V v_t_242 = (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    return heff_intSub(MK_INT(0LL), v_t_242);
  } else {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str1))) {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    } else {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(0LL)));
    }
  }
}
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eintOfText(a[0]);
}
Clo g_heff_2esyntax_2esurface_2efloatSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatSplit_entry, 2, 0};

double g_heff_2esyntax_2esurface_2efloatSplit_w(V v_s_240, V v_eAt_241) {
top: ;
  V v_m_242 = heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), heff_dup(v_eAt_241));
  V v_d_243 = (g_heff_2esyntax_2esurface_2edotAt(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), heff_dup(v_eAt_241)), MK_INT(0LL)));
  V v_m_247;
  if (heff_intLe_c(heff_strLength(heff_dup(v_m_242)), heff_dup(v_d_243))) {
    heff_drop(v_d_243);
    v_m_247 = (g_heff_2esyntax_2esurface_2eintOfText(v_m_242));
  } else {
    V v_t_245 = heff_strSlice(heff_dup(v_m_242), heff_intAdd(heff_dup(v_d_243), MK_INT(1LL)), heff_strLength(heff_dup(v_m_242)));
    V v_t_246 = heff_strAppend(heff_strSlice(v_m_242, MK_INT(0LL), v_d_243), v_t_245);
    v_m_247 = (g_heff_2esyntax_2esurface_2eintOfText(v_t_246));
  }
  V v_t_2410;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_eAt_241))) {
    v_t_2410 = MK_INT(0LL);
  } else {
    V v_t_249 = heff_strSlice(heff_dup(v_s_240), heff_intAdd(heff_dup(v_eAt_241), MK_INT(1LL)), heff_strLength(heff_dup(v_s_240)));
    v_t_2410 = (g_heff_2esyntax_2esurface_2eexpOf(v_t_249));
  }
  V v_m_2411 = heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), heff_dup(v_eAt_241));
  V v_d_2412 = (g_heff_2esyntax_2esurface_2edotAt(heff_strSlice(v_s_240, MK_INT(0LL), v_eAt_241), MK_INT(0LL)));
  V v_t_2415;
  if (heff_intLe_c(heff_strLength(heff_dup(v_m_2411)), heff_dup(v_d_2412))) {
    heff_drop(v_m_2411);
    heff_drop(v_d_2412);
    v_t_2415 = MK_INT(0LL);
  } else {
    V v_t_2414 = heff_intSub(heff_strLength(v_m_2411), v_d_2412);
    v_t_2415 = heff_intSub(v_t_2414, MK_INT(1LL));
  }
  V v_p_2416 = heff_intSub(v_t_2410, v_t_2415);
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_p_2416))) {
    V v_t_2418 = (g_heff_2esyntax_2esurface_2eipow10(v_p_2416));
    return heff_from_int_f64(heff_intMul(v_m_247, v_t_2418));
  } else {
    V v_t_2419 = (g_heff_2esyntax_2esurface_2eipow10(heff_intSub(MK_INT(0LL), v_p_2416)));
    return (heff_from_int_f64(v_m_247) / heff_from_int_f64(v_t_2419));
  }
}
V g_heff_2esyntax_2esurface_2efloatSplit(V v_s_240, V v_eAt_241) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_eAt_241)));
}
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efloatSplit(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatOfDigits_entry, 1, 0};

double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(heff_dup(v_s_240)));
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
    V v_t_244 = (g_heff_2esyntax_2esurface_2esplitExp(v_t_243, MK_INT(0LL)));
    double v_t_245 = (g_heff_2esyntax_2esurface_2efloatSplit_w(v_t_242, v_t_244));
    return ((0.0) - v_t_245);
  } else {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str1))) {
      V v_t_247 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(heff_dup(v_s_240)));
      V v_t_248 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
      V v_t_249 = (g_heff_2esyntax_2esurface_2esplitExp(v_t_248, MK_INT(0LL)));
      return (g_heff_2esyntax_2esurface_2efloatSplit_w(v_t_247, v_t_249));
    } else {
      V v_t_2410 = (g_heff_2esyntax_2esurface_2esplitExp(heff_dup(v_s_240), MK_INT(0LL)));
      return (g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_t_2410));
    }
  }
}
V g_heff_2esyntax_2esurface_2efloatOfDigits(V v_s_240) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_s_240)));
}
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efloatOfDigits(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2earrowNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowNames_entry, 6, 0};

V g_heff_2esyntax_2esurface_2earrowNames(V v_rhs_240, V v_g_241, V v_ty_242, V v_braces_243, V v_dflt_244, V v_orig_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_get_n(v_t_247, 1, 2)});
  V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a_0)); heff_drop_tag(v_t_248, 2); r_; });
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_orig_245);
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_241));
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2410, 0, 2), heff_get_n(v_t_2411, 1, 2)});
    return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2earrowNames_lam0, 2, 3, (V[]){v_braces_243, v_ty_242, v_dflt_244}); V a_1 = v_rhs_240; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop_tag(v_t_2412, 2); r_; });
  } else {
    heff_drop(v_g_241);
    heff_drop(v_ty_242);
    heff_drop(v_dflt_244);
    heff_drop(v_t_249);
    switch (heff_tag_of(v_braces_243)) {
    case TAG_Nothing: {
      V v_d_2468 = (g_heff_2esyntax_2esurface_2eplainBinder(heff_dup(v_orig_245)));
      V v_dsp_2471;
      switch (heff_tag_of(v_orig_245)) {
      case TAG_At: {
        V v_s_2470 = heff_field(v_orig_245, 1);
        heff_take_n(v_orig_245, 2ULL, 2);
        v_dsp_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_orig_245);
      }
      V v_b_2474;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2473 = heff_dup(heff_field(v_rhs_240, 1));
        v_b_2474 = v_s_2473;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2475 = ({ V rv_1 = heff_get_n(v_b_2474, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2471, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EPi, 2, (V[]){v_d_2468, v_rhs_240}), v_t_2475});
    }
    case TAG_Just: {
      V v_bsp_2476 = heff_field(v_braces_243, 0);
      V v_ru_24braces_243_24Just = heff_take_reuse_n(v_braces_243, 1ULL, 1);
      heff_drop(v_orig_245);
      V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24braces_243_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_str0)}), heff_dup(v_bsp_2476)});
      V v_t_2478 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2477}), heff_dup(v_rhs_240)});
      V v_b_2481;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2480 = heff_field(v_rhs_240, 1);
        heff_take_n(v_rhs_240, 2ULL, 2);
        v_b_2481 = v_s_2480;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2482 = ({ V rv_1 = heff_get_n(v_b_2481, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2476, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2478, v_t_2482});
    }
    default: return heff_nomatch(v_braces_243);
    }
  }
}
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowNames(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_b_2414 = args[1];
  V v_braces_243 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_dflt_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_At: {
    V v_it1_2415 = heff_field(v_x_2413, 0);
    V v_ysp_2416 = heff_field(v_x_2413, 1);
    V v_ru_24x_2413_24At = heff_take_reuse_n(v_x_2413, 3ULL, 2);
    switch (heff_tag_of(v_it1_2415)) {
    case TAG_EVar: {
      V v_y_2417 = heff_field(v_it1_2415, 0);
      heff_take_n(v_it1_2415, 1ULL, 1);
      switch (heff_tag_of(v_braces_243)) {
      case TAG_Nothing: {
        heff_drop(v_dflt_244);
        V v_b_2420;
        switch (heff_tag_of(v_ty_242)) {
        case TAG_At: {
          V v_s_2419 = heff_dup(heff_field(v_ty_242, 1));
          v_b_2420 = v_s_2419;
          break;
        }
        default: heff_nomatch(v_ty_242);
        }
        heff_drop(v_b_2420);
        V v_t_2421 = heff_tag_at_n(v_ru_24x_2413_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiNamed, 3, (V[]){v_y_2417, heff_dup(v_ysp_2416), v_ty_242}), heff_dup(v_b_2414)});
        V v_b_2424;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2423 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_b_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2425 = ({ V rv_1 = heff_get_n(v_b_2424, 1, 2); V rr_ = heff_rec_reuse_nf(v_ysp_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_t_2425});
      }
      case TAG_Just: {
        V v_bsp_2426 = heff_field(v_braces_243, 0);
        heff_take_n(v_braces_243, 1ULL, 1);
        V v_t_2427 = heff_tag_at_n(v_ru_24x_2413_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiImplicit, 5, (V[]){v_y_2417, v_ysp_2416, heff_dup(v_bsp_2426), v_ty_242, v_dflt_244}), heff_dup(v_b_2414)});
        V v_b_2430;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2429 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_b_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2431 = ({ V rv_1 = heff_get_n(v_b_2430, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2426, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_t_2431});
      }
      default: return heff_nomatch(v_braces_243);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETag: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInt: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EString: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ERune: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWord: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EApp: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EProject: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EPi: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELam: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_2415, 0ULL, 4);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESig: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESum: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EDo: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    default: return heff_nomatch(v_it1_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str1, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str2, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str3, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str4, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str5, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str6, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str7, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str8, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str9, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str10, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str11, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str12, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str13, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str14, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str15, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str16, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str17, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str18, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str19, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str20, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str21, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str22, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str23, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str24, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str25, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str26, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str27, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str28, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str29, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str30, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str31, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str32, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str33, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str34, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str35, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str36, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str37, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str38, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str39, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str40, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str41, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str42, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str43, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str44, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str45, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str46, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str47, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str48, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str49, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str50, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str51, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str52, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str53, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str54, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str55, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str56, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str57, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str58, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str59, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str60, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str61, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str62, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str63, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str64, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str65, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str66, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str67, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str68, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str69, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str70, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str71, 49, "an instance argument is named: `{{x : T}} -> ...`");
Clo g_heff_2esyntax_2esurface_2earrowBinop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowBinop_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowBinop(V v_x1_240, V v_rhs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Plain: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Plain = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_243 = heff_dup(heff_field(v_x11_242, 0));
      V v_sp_244 = heff_dup(heff_field(v_x11_242, 1));
      switch (heff_tag_of(v_x111_243)) {
      case TAG_EVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_248;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_247 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_248 = v_s_247;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_249 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2412;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_get_n(v_b_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_248, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2413});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2417;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2418 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2421;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_b_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2422});
      }
      case TAG_ETag: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2426;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2425 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2426 = v_s_2425;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2427 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2430;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2429 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2431 = ({ V rv_1 = heff_get_n(v_b_2430, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2426, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_t_2431});
      }
      case TAG_EInt: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2435;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2436 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2439;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2438 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2440 = ({ V rv_1 = heff_get_n(v_b_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2435, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_t_2440});
      }
      case TAG_EFloat: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2444;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2445 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2448;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2447 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2448 = v_s_2447;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2449 = ({ V rv_1 = heff_get_n(v_b_2448, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2444, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_t_2449});
      }
      case TAG_EString: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2453;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2452 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2453 = v_s_2452;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2454 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2457;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2456 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2457 = v_s_2456;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2458 = ({ V rv_1 = heff_get_n(v_b_2457, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2453, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2454, v_t_2458});
      }
      case TAG_EBytes: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2462;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2461 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2462 = v_s_2461;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2463 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2466;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2465 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2466 = v_s_2465;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2467 = ({ V rv_1 = heff_get_n(v_b_2466, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2462, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2463, v_t_2467});
      }
      case TAG_ERune: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2471;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2470 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2471 = v_s_2470;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2472 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2475;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2474 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2476 = ({ V rv_1 = heff_get_n(v_b_2475, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2471, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2472, v_t_2476});
      }
      case TAG_EWord: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2480;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2479 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2480 = v_s_2479;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2481 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2484;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2483 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2485 = ({ V rv_1 = heff_get_n(v_b_2484, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2480, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2481, v_t_2485});
      }
      case TAG_EApp: {
        V v_ru_24x111_243_24EApp = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_2490;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2489 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2490 = v_s_2489;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2491 = heff_tag_at_n(v_ru_24x111_243_24EApp, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_2494;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2493 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2495 = ({ V rv_1 = heff_get_n(v_b_2494, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2490, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2491, v_t_2495});
      }
      case TAG_EProject: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_2499;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24100 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24103;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24102 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24104 = ({ V rv_1 = heff_get_n(v_b_24103, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2499, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24100, v_t_24104});
      }
      case TAG_ENamed: {
        V v_ru_24x111_243_24ENamed = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_24109;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24110 = heff_tag_at_n(v_ru_24x111_243_24ENamed, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24113;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24112 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24114 = ({ V rv_1 = heff_get_n(v_b_24113, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24109, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24110, v_t_24114});
      }
      case TAG_EPi: {
        V v_ru_24x111_243_24EPi = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_24119;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24120 = heff_tag_at_n(v_ru_24x111_243_24EPi, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24123;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24122 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24124 = ({ V rv_1 = heff_get_n(v_b_24123, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24119, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24120, v_t_24124});
      }
      case TAG_ELam: {
        V v_ru_24x111_243_24ELam = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_24129;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24130 = heff_tag_at_n(v_ru_24x111_243_24ELam, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24133;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24132 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24133 = v_s_24132;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24134 = ({ V rv_1 = heff_get_n(v_b_24133, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24129, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24130, v_t_24134});
      }
      case TAG_EAnn: {
        V v_g_24135 = heff_field(v_x111_243, 0);
        V v_ty_24136 = heff_field(v_x111_243, 1);
        V v_ru_24x111_243_24EAnn = heff_take_reuse_n(v_x111_243, 3ULL, 2);
        heff_drop_tag(v_x11_242, 2);
        heff_drop_cell(v_ru_24x1_240_24Plain, 1);
        V v_t_24137 = heff_tag_at_n(v_ru_24x111_243_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){heff_dup(v_g_24135), heff_dup(v_ty_24136)}), v_sp_244});
        return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_24135, v_ty_24136, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_t_24137));
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_243, 0ULL, 4);
        heff_drop(v_sp_244);
        V v_dsp_24144;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24143 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24144 = v_s_24143;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24145 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24148;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24147 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24148 = v_s_24147;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24149 = ({ V rv_1 = heff_get_n(v_b_24148, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24144, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24145, v_t_24149});
      }
      case TAG_ESig: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_24153;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24152 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24153 = v_s_24152;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24154 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24157;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24156 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24157 = v_s_24156;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24158 = ({ V rv_1 = heff_get_n(v_b_24157, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24153, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24154, v_t_24158});
      }
      case TAG_ESum: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_24162;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24161 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24162 = v_s_24161;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24163 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24166;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24165 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24166 = v_s_24165;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24167 = ({ V rv_1 = heff_get_n(v_b_24166, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24162, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24163, v_t_24167});
      }
      case TAG_EStruct: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_24171;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24170 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24171 = v_s_24170;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24172 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24175;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24174 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24175 = v_s_24174;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24176 = ({ V rv_1 = heff_get_n(v_b_24175, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24171, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24172, v_t_24176});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_243_24EUpdate = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_24181;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24180 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24181 = v_s_24180;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24182 = heff_tag_at_n(v_ru_24x111_243_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24185;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24184 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24185 = v_s_24184;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24186 = ({ V rv_1 = heff_get_n(v_b_24185, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24181, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24182, v_t_24186});
      }
      case TAG_EMatch: {
        V v_ru_24x111_243_24EMatch = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_24191;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24192 = heff_tag_at_n(v_ru_24x111_243_24EMatch, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24195;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24194 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24195 = v_s_24194;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24196 = ({ V rv_1 = heff_get_n(v_b_24195, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24191, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24192, v_t_24196});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_243_24ELetIn = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_24201;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24200 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24201 = v_s_24200;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24202 = heff_tag_at_n(v_ru_24x111_243_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24205;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24204 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24205 = v_s_24204;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24206 = ({ V rv_1 = heff_get_n(v_b_24205, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24201, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24202, v_t_24206});
      }
      case TAG_EDo: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_24210;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24209 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24210 = v_s_24209;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24211 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24214;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24213 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24214 = v_s_24213;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24215 = ({ V rv_1 = heff_get_n(v_b_24214, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24210, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24211, v_t_24215});
      }
      case TAG_ELocal: {
        V v_ru_24x111_243_24ELocal = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_dsp_24220;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24219 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24220 = v_s_24219;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24221 = heff_tag_at_n(v_ru_24x111_243_24ELocal, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24224;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24223 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24224 = v_s_24223;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24225 = ({ V rv_1 = heff_get_n(v_b_24224, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24220, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24221, v_t_24225});
      }
      case TAG_EInvalid: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_dsp_24229;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24228 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_24229 = v_s_24228;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24230 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), heff_dup(v_rhs_241)});
        V v_b_24233;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24232 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24233 = v_s_24232;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24234 = ({ V rv_1 = heff_get_n(v_b_24233, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_24229, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24230, v_t_24234});
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_Braced: {
    V v_x11_24235 = heff_field(v_x1_240, 0);
    V v_dflt_24236 = heff_field(v_x1_240, 1);
    V v_bsp_24237 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x11_24235)) {
    case TAG_At: {
      V v_x111_24238 = heff_field(v_x11_24235, 0);
      V v_sp_24239 = heff_field(v_x11_24235, 1);
      V v_ru_24x11_24235_24At = heff_take_reuse_n(v_x11_24235, 3ULL, 2);
      switch (heff_tag_of(v_x111_24238)) {
      case TAG_EVar: {
        V v_ru_24x111_24238_24EVar = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24241 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str0)}), heff_dup(v_bsp_24237)});
        V v_t_24242 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EVar, TAG_PiAnon, 1, (V[]){v_t_24241}), heff_dup(v_rhs_241)});
        V v_b_24245;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24244 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24245 = v_s_24244;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24246 = ({ V rv_1 = heff_get_n(v_b_24245, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24242, v_t_24246});
      }
      case TAG_EImplicitVar: {
        V v_ru_24x111_24238_24EImplicitVar = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24248 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str1)}), heff_dup(v_bsp_24237)});
        V v_t_24249 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_t_24248}), heff_dup(v_rhs_241)});
        V v_b_24252;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24251 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24252 = v_s_24251;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24253 = ({ V rv_1 = heff_get_n(v_b_24252, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24249, v_t_24253});
      }
      case TAG_ETag: {
        V v_ru_24x111_24238_24ETag = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24255 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str2)}), heff_dup(v_bsp_24237)});
        V v_t_24256 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24ETag, TAG_PiAnon, 1, (V[]){v_t_24255}), heff_dup(v_rhs_241)});
        V v_b_24259;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24258 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24259 = v_s_24258;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24260 = ({ V rv_1 = heff_get_n(v_b_24259, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24256, v_t_24260});
      }
      case TAG_EInt: {
        V v_ru_24x111_24238_24EInt = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24262 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str3)}), heff_dup(v_bsp_24237)});
        V v_t_24263 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EInt, TAG_PiAnon, 1, (V[]){v_t_24262}), heff_dup(v_rhs_241)});
        V v_b_24266;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24265 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24266 = v_s_24265;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24267 = ({ V rv_1 = heff_get_n(v_b_24266, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24263, v_t_24267});
      }
      case TAG_EFloat: {
        V v_ru_24x111_24238_24EFloat = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24269 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str4)}), heff_dup(v_bsp_24237)});
        V v_t_24270 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EFloat, TAG_PiAnon, 1, (V[]){v_t_24269}), heff_dup(v_rhs_241)});
        V v_b_24273;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24272 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24273 = v_s_24272;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24274 = ({ V rv_1 = heff_get_n(v_b_24273, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24270, v_t_24274});
      }
      case TAG_EString: {
        V v_ru_24x111_24238_24EString = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24276 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str5)}), heff_dup(v_bsp_24237)});
        V v_t_24277 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EString, TAG_PiAnon, 1, (V[]){v_t_24276}), heff_dup(v_rhs_241)});
        V v_b_24280;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24279 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24280 = v_s_24279;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24281 = ({ V rv_1 = heff_get_n(v_b_24280, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24277, v_t_24281});
      }
      case TAG_EBytes: {
        V v_ru_24x111_24238_24EBytes = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24283 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str6)}), heff_dup(v_bsp_24237)});
        V v_t_24284 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EBytes, TAG_PiAnon, 1, (V[]){v_t_24283}), heff_dup(v_rhs_241)});
        V v_b_24287;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24286 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24287 = v_s_24286;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24288 = ({ V rv_1 = heff_get_n(v_b_24287, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24284, v_t_24288});
      }
      case TAG_ERune: {
        V v_ru_24x111_24238_24ERune = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24290 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str7)}), heff_dup(v_bsp_24237)});
        V v_t_24291 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24ERune, TAG_PiAnon, 1, (V[]){v_t_24290}), heff_dup(v_rhs_241)});
        V v_b_24294;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24293 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24294 = v_s_24293;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24295 = ({ V rv_1 = heff_get_n(v_b_24294, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24291, v_t_24295});
      }
      case TAG_EWord: {
        V v_ru_24x111_24238_24EWord = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24297 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str8)}), heff_dup(v_bsp_24237)});
        V v_t_24298 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EWord, TAG_PiAnon, 1, (V[]){v_t_24297}), heff_dup(v_rhs_241)});
        V v_b_24301;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24300 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24301 = v_s_24300;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24302 = ({ V rv_1 = heff_get_n(v_b_24301, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24298, v_t_24302});
      }
      case TAG_EApp: {
        V v_ru_24x111_24238_24EApp = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24305 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str9)}), heff_dup(v_bsp_24237)});
        V v_t_24306 = heff_tag_at_n(v_ru_24x111_24238_24EApp, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24305}), heff_dup(v_rhs_241)});
        V v_b_24309;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24308 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24309 = v_s_24308;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24310 = ({ V rv_1 = heff_get_n(v_b_24309, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24306, v_t_24310});
      }
      case TAG_EProject: {
        V v_ru_24x111_24238_24EProject = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24312 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str10)}), heff_dup(v_bsp_24237)});
        V v_t_24313 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EProject, TAG_PiAnon, 1, (V[]){v_t_24312}), heff_dup(v_rhs_241)});
        V v_b_24316;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24315 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24316 = v_s_24315;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24317 = ({ V rv_1 = heff_get_n(v_b_24316, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24313, v_t_24317});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24238_24ENamed = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24320 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str11)}), heff_dup(v_bsp_24237)});
        V v_t_24321 = heff_tag_at_n(v_ru_24x111_24238_24ENamed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24320}), heff_dup(v_rhs_241)});
        V v_b_24324;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24323 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24324 = v_s_24323;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24325 = ({ V rv_1 = heff_get_n(v_b_24324, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24321, v_t_24325});
      }
      case TAG_EPi: {
        V v_ru_24x111_24238_24EPi = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24328 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str12)}), heff_dup(v_bsp_24237)});
        V v_t_24329 = heff_tag_at_n(v_ru_24x111_24238_24EPi, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24328}), heff_dup(v_rhs_241)});
        V v_b_24332;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24331 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24332 = v_s_24331;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24333 = ({ V rv_1 = heff_get_n(v_b_24332, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24329, v_t_24333});
      }
      case TAG_ELam: {
        V v_ru_24x111_24238_24ELam = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24336 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str13)}), heff_dup(v_bsp_24237)});
        V v_t_24337 = heff_tag_at_n(v_ru_24x111_24238_24ELam, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24336}), heff_dup(v_rhs_241)});
        V v_b_24340;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24339 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24340 = v_s_24339;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24341 = ({ V rv_1 = heff_get_n(v_b_24340, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24337, v_t_24341});
      }
      case TAG_EAnn: {
        V v_g_24342 = heff_field(v_x111_24238, 0);
        V v_ty_24343 = heff_field(v_x111_24238, 1);
        heff_take_n(v_x111_24238, 3ULL, 2);
        V v_t_24344 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){heff_dup(v_g_24342), heff_dup(v_ty_24343)}), v_sp_24239});
        return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_24342, v_ty_24343, heff_tag_n(TAG_Just, 1, (V[]){v_bsp_24237}), v_dflt_24236, v_t_24344));
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24238, 0ULL, 4);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24349 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str14)}), heff_dup(v_bsp_24237)});
        V v_t_24350 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24349}), heff_dup(v_rhs_241)});
        V v_b_24353;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24352 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24353 = v_s_24352;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24354 = ({ V rv_1 = heff_get_n(v_b_24353, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24350, v_t_24354});
      }
      case TAG_ESig: {
        V v_ru_24x111_24238_24ESig = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24356 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str15)}), heff_dup(v_bsp_24237)});
        V v_t_24357 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24ESig, TAG_PiAnon, 1, (V[]){v_t_24356}), heff_dup(v_rhs_241)});
        V v_b_24360;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24359 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24360 = v_s_24359;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24361 = ({ V rv_1 = heff_get_n(v_b_24360, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24357, v_t_24361});
      }
      case TAG_ESum: {
        V v_ru_24x111_24238_24ESum = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24363 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str16)}), heff_dup(v_bsp_24237)});
        V v_t_24364 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24ESum, TAG_PiAnon, 1, (V[]){v_t_24363}), heff_dup(v_rhs_241)});
        V v_b_24367;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24366 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24367 = v_s_24366;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24368 = ({ V rv_1 = heff_get_n(v_b_24367, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24364, v_t_24368});
      }
      case TAG_EStruct: {
        V v_ru_24x111_24238_24EStruct = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24370 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str17)}), heff_dup(v_bsp_24237)});
        V v_t_24371 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EStruct, TAG_PiAnon, 1, (V[]){v_t_24370}), heff_dup(v_rhs_241)});
        V v_b_24374;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24373 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24374 = v_s_24373;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24375 = ({ V rv_1 = heff_get_n(v_b_24374, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24371, v_t_24375});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24238_24EUpdate = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24378 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str18)}), heff_dup(v_bsp_24237)});
        V v_t_24379 = heff_tag_at_n(v_ru_24x111_24238_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24378}), heff_dup(v_rhs_241)});
        V v_b_24382;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24381 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24382 = v_s_24381;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24383 = ({ V rv_1 = heff_get_n(v_b_24382, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24379, v_t_24383});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24238_24EMatch = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24386 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str19)}), heff_dup(v_bsp_24237)});
        V v_t_24387 = heff_tag_at_n(v_ru_24x111_24238_24EMatch, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24386}), heff_dup(v_rhs_241)});
        V v_b_24390;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24389 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24390 = v_s_24389;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24391 = ({ V rv_1 = heff_get_n(v_b_24390, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24387, v_t_24391});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24238_24ELetIn = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24394 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str20)}), heff_dup(v_bsp_24237)});
        V v_t_24395 = heff_tag_at_n(v_ru_24x111_24238_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24394}), heff_dup(v_rhs_241)});
        V v_b_24398;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24397 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24398 = v_s_24397;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24399 = ({ V rv_1 = heff_get_n(v_b_24398, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24395, v_t_24399});
      }
      case TAG_EDo: {
        V v_ru_24x111_24238_24EDo = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24401 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str21)}), heff_dup(v_bsp_24237)});
        V v_t_24402 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EDo, TAG_PiAnon, 1, (V[]){v_t_24401}), heff_dup(v_rhs_241)});
        V v_b_24405;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24404 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24405 = v_s_24404;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24406 = ({ V rv_1 = heff_get_n(v_b_24405, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24402, v_t_24406});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24238_24ELocal = heff_take_reuse_n(v_x111_24238, 0ULL, 2);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24409 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str22)}), heff_dup(v_bsp_24237)});
        V v_t_24410 = heff_tag_at_n(v_ru_24x111_24238_24ELocal, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24409}), heff_dup(v_rhs_241)});
        V v_b_24413;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24412 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24413 = v_s_24412;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24414 = ({ V rv_1 = heff_get_n(v_b_24413, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24410, v_t_24414});
      }
      case TAG_EInvalid: {
        V v_ru_24x111_24238_24EInvalid = heff_take_reuse_n(v_x111_24238, 0ULL, 1);
        heff_drop(v_dflt_24236);
        heff_drop(v_sp_24239);
        V v_t_24416 = heff_tag_at_n(v_ru_24x11_24235_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str23)}), heff_dup(v_bsp_24237)});
        V v_t_24417 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24238_24EInvalid, TAG_PiAnon, 1, (V[]){v_t_24416}), heff_dup(v_rhs_241)});
        V v_b_24420;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24419 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24420 = v_s_24419;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24421 = ({ V rv_1 = heff_get_n(v_b_24420, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24237, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24417, v_t_24421});
      }
      default: return heff_nomatch(v_x111_24238);
      }
    }
    default: return heff_nomatch(v_x11_24235);
    }
  }
  case TAG_Bracketed: {
    V v_x11_24422 = heff_field(v_x1_240, 0);
    V v_bsp_24423 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Bracketed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24422)) {
    case TAG_At: {
      V v_x111_24424 = heff_field(v_x11_24422, 0);
      V v_ru_24x11_24422_24At = heff_take_reuse_n(v_x11_24422, 1ULL, 2);
      switch (heff_tag_of(v_x111_24424)) {
      case TAG_EVar: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24427 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str24)}), heff_dup(v_bsp_24423)});
        V v_t_24428 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24427}), heff_dup(v_rhs_241)});
        V v_b_24431;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24430 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24431 = v_s_24430;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24432 = ({ V rv_1 = heff_get_n(v_b_24431, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24428, v_t_24432});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24434 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str25)}), heff_dup(v_bsp_24423)});
        V v_t_24435 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24434}), heff_dup(v_rhs_241)});
        V v_b_24438;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24437 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24438 = v_s_24437;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24439 = ({ V rv_1 = heff_get_n(v_b_24438, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24435, v_t_24439});
      }
      case TAG_ETag: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24441 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str26)}), heff_dup(v_bsp_24423)});
        V v_t_24442 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24441}), heff_dup(v_rhs_241)});
        V v_b_24445;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24444 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24445 = v_s_24444;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24446 = ({ V rv_1 = heff_get_n(v_b_24445, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24442, v_t_24446});
      }
      case TAG_EInt: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24448 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str27)}), heff_dup(v_bsp_24423)});
        V v_t_24449 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24448}), heff_dup(v_rhs_241)});
        V v_b_24452;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24451 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24452 = v_s_24451;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24453 = ({ V rv_1 = heff_get_n(v_b_24452, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24449, v_t_24453});
      }
      case TAG_EFloat: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24455 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str28)}), heff_dup(v_bsp_24423)});
        V v_t_24456 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24455}), heff_dup(v_rhs_241)});
        V v_b_24459;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24458 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24459 = v_s_24458;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24460 = ({ V rv_1 = heff_get_n(v_b_24459, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24456, v_t_24460});
      }
      case TAG_EString: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24462 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str29)}), heff_dup(v_bsp_24423)});
        V v_t_24463 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24462}), heff_dup(v_rhs_241)});
        V v_b_24466;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24465 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24466 = v_s_24465;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24467 = ({ V rv_1 = heff_get_n(v_b_24466, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24463, v_t_24467});
      }
      case TAG_EBytes: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24469 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str30)}), heff_dup(v_bsp_24423)});
        V v_t_24470 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24469}), heff_dup(v_rhs_241)});
        V v_b_24473;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24472 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24473 = v_s_24472;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24474 = ({ V rv_1 = heff_get_n(v_b_24473, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24470, v_t_24474});
      }
      case TAG_ERune: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24476 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str31)}), heff_dup(v_bsp_24423)});
        V v_t_24477 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24476}), heff_dup(v_rhs_241)});
        V v_b_24480;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24479 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24480 = v_s_24479;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24481 = ({ V rv_1 = heff_get_n(v_b_24480, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24477, v_t_24481});
      }
      case TAG_EWord: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24483 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str32)}), heff_dup(v_bsp_24423)});
        V v_t_24484 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24483}), heff_dup(v_rhs_241)});
        V v_b_24487;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24486 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24487 = v_s_24486;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24488 = ({ V rv_1 = heff_get_n(v_b_24487, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24484, v_t_24488});
      }
      case TAG_EApp: {
        V v_ru_24x111_24424_24EApp = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24491 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str33)}), heff_dup(v_bsp_24423)});
        V v_t_24492 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24491}), heff_dup(v_rhs_241)});
        V v_b_24495;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24494 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24495 = v_s_24494;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24496 = ({ V rv_1 = heff_get_n(v_b_24495, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24EApp, TAG_At, 2, (V[]){v_t_24492, v_t_24496});
      }
      case TAG_EProject: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24498 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str34)}), heff_dup(v_bsp_24423)});
        V v_t_24499 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24498}), heff_dup(v_rhs_241)});
        V v_b_24502;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24501 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24502 = v_s_24501;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24503 = ({ V rv_1 = heff_get_n(v_b_24502, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24499, v_t_24503});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24424_24ENamed = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24506 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str35)}), heff_dup(v_bsp_24423)});
        V v_t_24507 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24506}), heff_dup(v_rhs_241)});
        V v_b_24510;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24509 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24510 = v_s_24509;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24511 = ({ V rv_1 = heff_get_n(v_b_24510, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24ENamed, TAG_At, 2, (V[]){v_t_24507, v_t_24511});
      }
      case TAG_EPi: {
        V v_ru_24x111_24424_24EPi = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24514 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str36)}), heff_dup(v_bsp_24423)});
        V v_t_24515 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24514}), heff_dup(v_rhs_241)});
        V v_b_24518;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24517 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24518 = v_s_24517;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24519 = ({ V rv_1 = heff_get_n(v_b_24518, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24EPi, TAG_At, 2, (V[]){v_t_24515, v_t_24519});
      }
      case TAG_ELam: {
        V v_ru_24x111_24424_24ELam = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24522 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str37)}), heff_dup(v_bsp_24423)});
        V v_t_24523 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24522}), heff_dup(v_rhs_241)});
        V v_b_24526;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24525 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24526 = v_s_24525;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24527 = ({ V rv_1 = heff_get_n(v_b_24526, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24ELam, TAG_At, 2, (V[]){v_t_24523, v_t_24527});
      }
      case TAG_EAnn: {
        V v_x1111_24528 = heff_field(v_x111_24424, 0);
        V v_t_24529 = heff_field(v_x111_24424, 1);
        V v_ru_24x111_24424_24EAnn = heff_take_reuse_n(v_x111_24424, 3ULL, 2);
        switch (heff_tag_of(v_x1111_24528)) {
        case TAG_At: {
          V v_x11111_24530 = heff_field(v_x1111_24528, 0);
          V v_xsp_24531 = heff_field(v_x1111_24528, 1);
          heff_take_n(v_x1111_24528, 3ULL, 2);
          switch (heff_tag_of(v_x11111_24530)) {
          case TAG_EVar: {
            V v_x_24532 = heff_field(v_x11111_24530, 0);
            heff_take_n(v_x11111_24530, 1ULL, 1);
            heff_drop_cell(v_ru_24x111_24424_24EAnn, 2);
            V v_t_24533 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiInstance, 4, (V[]){v_x_24532, v_xsp_24531, heff_dup(v_bsp_24423), v_t_24529}), heff_dup(v_rhs_241)});
            V v_b_24536;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24535 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24536 = v_s_24535;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24537 = ({ V rv_1 = heff_get_n(v_b_24536, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24422_24At, TAG_At, 2, (V[]){v_t_24533, v_t_24537});
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24539 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str38)}), heff_dup(v_bsp_24423)});
            V v_t_24540 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24539}), heff_dup(v_rhs_241)});
            V v_b_24543;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24542 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24543 = v_s_24542;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24544 = ({ V rv_1 = heff_get_n(v_b_24543, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24540, v_t_24544});
          }
          case TAG_ETag: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24546 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str39)}), heff_dup(v_bsp_24423)});
            V v_t_24547 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24546}), heff_dup(v_rhs_241)});
            V v_b_24550;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24549 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24550 = v_s_24549;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24551 = ({ V rv_1 = heff_get_n(v_b_24550, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24547, v_t_24551});
          }
          case TAG_EInt: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24553 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str40)}), heff_dup(v_bsp_24423)});
            V v_t_24554 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24553}), heff_dup(v_rhs_241)});
            V v_b_24557;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24556 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24557 = v_s_24556;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24558 = ({ V rv_1 = heff_get_n(v_b_24557, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24554, v_t_24558});
          }
          case TAG_EFloat: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24560 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str41)}), heff_dup(v_bsp_24423)});
            V v_t_24561 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24560}), heff_dup(v_rhs_241)});
            V v_b_24564;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24563 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24564 = v_s_24563;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24565 = ({ V rv_1 = heff_get_n(v_b_24564, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24561, v_t_24565});
          }
          case TAG_EString: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24567 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str42)}), heff_dup(v_bsp_24423)});
            V v_t_24568 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24567}), heff_dup(v_rhs_241)});
            V v_b_24571;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24570 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24571 = v_s_24570;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24572 = ({ V rv_1 = heff_get_n(v_b_24571, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24568, v_t_24572});
          }
          case TAG_EBytes: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24574 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str43)}), heff_dup(v_bsp_24423)});
            V v_t_24575 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24574}), heff_dup(v_rhs_241)});
            V v_b_24578;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24577 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24578 = v_s_24577;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24579 = ({ V rv_1 = heff_get_n(v_b_24578, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24575, v_t_24579});
          }
          case TAG_ERune: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24581 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str44)}), heff_dup(v_bsp_24423)});
            V v_t_24582 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24581}), heff_dup(v_rhs_241)});
            V v_b_24585;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24584 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24585 = v_s_24584;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24586 = ({ V rv_1 = heff_get_n(v_b_24585, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24582, v_t_24586});
          }
          case TAG_EWord: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24588 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str45)}), heff_dup(v_bsp_24423)});
            V v_t_24589 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24588}), heff_dup(v_rhs_241)});
            V v_b_24592;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24591 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24592 = v_s_24591;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24593 = ({ V rv_1 = heff_get_n(v_b_24592, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24589, v_t_24593});
          }
          case TAG_EApp: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24596 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str46)}), heff_dup(v_bsp_24423)});
            V v_t_24597 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24596}), heff_dup(v_rhs_241)});
            V v_b_24600;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24599 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24600 = v_s_24599;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24601 = ({ V rv_1 = heff_get_n(v_b_24600, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24597, v_t_24601});
          }
          case TAG_EProject: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24603 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str47)}), heff_dup(v_bsp_24423)});
            V v_t_24604 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24603}), heff_dup(v_rhs_241)});
            V v_b_24607;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24606 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24607 = v_s_24606;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24608 = ({ V rv_1 = heff_get_n(v_b_24607, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24604, v_t_24608});
          }
          case TAG_ENamed: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24611 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str48)}), heff_dup(v_bsp_24423)});
            V v_t_24612 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24611}), heff_dup(v_rhs_241)});
            V v_b_24615;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24614 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24615 = v_s_24614;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24616 = ({ V rv_1 = heff_get_n(v_b_24615, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24612, v_t_24616});
          }
          case TAG_EPi: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24619 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str49)}), heff_dup(v_bsp_24423)});
            V v_t_24620 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24619}), heff_dup(v_rhs_241)});
            V v_b_24623;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24622 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24623 = v_s_24622;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24624 = ({ V rv_1 = heff_get_n(v_b_24623, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24620, v_t_24624});
          }
          case TAG_ELam: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24627 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str50)}), heff_dup(v_bsp_24423)});
            V v_t_24628 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24627}), heff_dup(v_rhs_241)});
            V v_b_24631;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24630 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24631 = v_s_24630;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24632 = ({ V rv_1 = heff_get_n(v_b_24631, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24628, v_t_24632});
          }
          case TAG_EAnn: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24635 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str51)}), heff_dup(v_bsp_24423)});
            V v_t_24636 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24635}), heff_dup(v_rhs_241)});
            V v_b_24639;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24638 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24639 = v_s_24638;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24640 = ({ V rv_1 = heff_get_n(v_b_24639, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24636, v_t_24640});
          }
          case TAG_ESpec: {
            heff_take_n(v_x11111_24530, 0ULL, 4);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24645 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str52)}), heff_dup(v_bsp_24423)});
            V v_t_24646 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24645}), heff_dup(v_rhs_241)});
            V v_b_24649;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24648 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24649 = v_s_24648;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24650 = ({ V rv_1 = heff_get_n(v_b_24649, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24646, v_t_24650});
          }
          case TAG_ESig: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24652 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str53)}), heff_dup(v_bsp_24423)});
            V v_t_24653 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24652}), heff_dup(v_rhs_241)});
            V v_b_24656;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24655 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24656 = v_s_24655;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24657 = ({ V rv_1 = heff_get_n(v_b_24656, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24653, v_t_24657});
          }
          case TAG_ESum: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24659 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str54)}), heff_dup(v_bsp_24423)});
            V v_t_24660 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24659}), heff_dup(v_rhs_241)});
            V v_b_24663;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24662 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24663 = v_s_24662;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24664 = ({ V rv_1 = heff_get_n(v_b_24663, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24660, v_t_24664});
          }
          case TAG_EStruct: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24666 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str55)}), heff_dup(v_bsp_24423)});
            V v_t_24667 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24666}), heff_dup(v_rhs_241)});
            V v_b_24670;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24669 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24670 = v_s_24669;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24671 = ({ V rv_1 = heff_get_n(v_b_24670, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24667, v_t_24671});
          }
          case TAG_EUpdate: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24674 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str56)}), heff_dup(v_bsp_24423)});
            V v_t_24675 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24674}), heff_dup(v_rhs_241)});
            V v_b_24678;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24677 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24678 = v_s_24677;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24679 = ({ V rv_1 = heff_get_n(v_b_24678, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24675, v_t_24679});
          }
          case TAG_EMatch: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24682 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str57)}), heff_dup(v_bsp_24423)});
            V v_t_24683 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24682}), heff_dup(v_rhs_241)});
            V v_b_24686;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24685 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24686 = v_s_24685;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24687 = ({ V rv_1 = heff_get_n(v_b_24686, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24683, v_t_24687});
          }
          case TAG_ELetIn: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24690 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str58)}), heff_dup(v_bsp_24423)});
            V v_t_24691 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24690}), heff_dup(v_rhs_241)});
            V v_b_24694;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24693 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24694 = v_s_24693;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24695 = ({ V rv_1 = heff_get_n(v_b_24694, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24691, v_t_24695});
          }
          case TAG_EDo: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24697 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str59)}), heff_dup(v_bsp_24423)});
            V v_t_24698 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24697}), heff_dup(v_rhs_241)});
            V v_b_24701;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24700 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24701 = v_s_24700;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24702 = ({ V rv_1 = heff_get_n(v_b_24701, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24698, v_t_24702});
          }
          case TAG_ELocal: {
            heff_take_n(v_x11111_24530, 0ULL, 2);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24705 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str60)}), heff_dup(v_bsp_24423)});
            V v_t_24706 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24705}), heff_dup(v_rhs_241)});
            V v_b_24709;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24708 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24709 = v_s_24708;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24710 = ({ V rv_1 = heff_get_n(v_b_24709, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24706, v_t_24710});
          }
          case TAG_EInvalid: {
            heff_take_n(v_x11111_24530, 0ULL, 1);
            heff_drop(v_t_24529);
            heff_drop(v_xsp_24531);
            V v_t_24712 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str61)}), heff_dup(v_bsp_24423)});
            V v_t_24713 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24712}), heff_dup(v_rhs_241)});
            V v_b_24716;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24715 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_b_24716 = v_s_24715;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24717 = ({ V rv_1 = heff_get_n(v_b_24716, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x111_24424_24EAnn, TAG_At, 2, (V[]){v_t_24713, v_t_24717});
          }
          default: return heff_nomatch(v_x11111_24530);
          }
        }
        default: return heff_nomatch(v_x1111_24528);
        }
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24424, 0ULL, 4);
        V v_t_24722 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str62)}), heff_dup(v_bsp_24423)});
        V v_t_24723 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24722}), heff_dup(v_rhs_241)});
        V v_b_24726;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24725 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24726 = v_s_24725;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24727 = ({ V rv_1 = heff_get_n(v_b_24726, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24723, v_t_24727});
      }
      case TAG_ESig: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24729 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str63)}), heff_dup(v_bsp_24423)});
        V v_t_24730 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24729}), heff_dup(v_rhs_241)});
        V v_b_24733;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24732 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24733 = v_s_24732;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24734 = ({ V rv_1 = heff_get_n(v_b_24733, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24730, v_t_24734});
      }
      case TAG_ESum: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24736 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str64)}), heff_dup(v_bsp_24423)});
        V v_t_24737 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24736}), heff_dup(v_rhs_241)});
        V v_b_24740;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24739 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24740 = v_s_24739;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24741 = ({ V rv_1 = heff_get_n(v_b_24740, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24737, v_t_24741});
      }
      case TAG_EStruct: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24743 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str65)}), heff_dup(v_bsp_24423)});
        V v_t_24744 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24743}), heff_dup(v_rhs_241)});
        V v_b_24747;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24746 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24747 = v_s_24746;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24748 = ({ V rv_1 = heff_get_n(v_b_24747, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24744, v_t_24748});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24424_24EUpdate = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24751 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str66)}), heff_dup(v_bsp_24423)});
        V v_t_24752 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24751}), heff_dup(v_rhs_241)});
        V v_b_24755;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24754 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24755 = v_s_24754;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24756 = ({ V rv_1 = heff_get_n(v_b_24755, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24EUpdate, TAG_At, 2, (V[]){v_t_24752, v_t_24756});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24424_24EMatch = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24759 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str67)}), heff_dup(v_bsp_24423)});
        V v_t_24760 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24759}), heff_dup(v_rhs_241)});
        V v_b_24763;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24762 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24763 = v_s_24762;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24764 = ({ V rv_1 = heff_get_n(v_b_24763, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24EMatch, TAG_At, 2, (V[]){v_t_24760, v_t_24764});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24424_24ELetIn = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24767 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str68)}), heff_dup(v_bsp_24423)});
        V v_t_24768 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24767}), heff_dup(v_rhs_241)});
        V v_b_24771;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24770 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24771 = v_s_24770;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24772 = ({ V rv_1 = heff_get_n(v_b_24771, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24ELetIn, TAG_At, 2, (V[]){v_t_24768, v_t_24772});
      }
      case TAG_EDo: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24774 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str69)}), heff_dup(v_bsp_24423)});
        V v_t_24775 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24774}), heff_dup(v_rhs_241)});
        V v_b_24778;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24777 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24778 = v_s_24777;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24779 = ({ V rv_1 = heff_get_n(v_b_24778, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24775, v_t_24779});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24424_24ELocal = heff_take_reuse_n(v_x111_24424, 0ULL, 2);
        V v_t_24782 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str70)}), heff_dup(v_bsp_24423)});
        V v_t_24783 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24782}), heff_dup(v_rhs_241)});
        V v_b_24786;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24785 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24786 = v_s_24785;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24787 = ({ V rv_1 = heff_get_n(v_b_24786, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x111_24424_24ELocal, TAG_At, 2, (V[]){v_t_24783, v_t_24787});
      }
      case TAG_EInvalid: {
        heff_take_n(v_x111_24424, 0ULL, 1);
        V v_t_24789 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str71)}), heff_dup(v_bsp_24423)});
        V v_t_24790 = heff_tag_at_n(v_ru_24x11_24422_24At, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24789}), heff_dup(v_rhs_241)});
        V v_b_24793;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24792 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_b_24793 = v_s_24792;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24794 = ({ V rv_1 = heff_get_n(v_b_24793, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24790, v_t_24794});
      }
      default: return heff_nomatch(v_x111_24424);
      }
    }
    default: return heff_nomatch(v_x11_24422);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowBinop(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str0, 37, "` does not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str2, 35, "` do not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str3, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str5, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str6, 39, "` are both the loosest: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str8, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str9, 85, "` are not related: add parentheses, or declare which binds tighter (`above`, `below`)");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str11, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str12, 34, "`), or import the module that does");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str13, 1, "`");
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam2, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam5, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam7, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efirstS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efirstS(V v_fix_240, V v_lenient_241, V v_before_242, V v_op_243) {
top: ;
  V v_it_244 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_fix_240), heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1))));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Tighter: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam0_clo);
  }
  case TAG_Looser: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam1_clo);
  }
  case TAG_Same: {
    V v_it1_249 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_AssocLeft: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam2_clo);
    }
    case TAG_AssocRight: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam3_clo);
    }
    case TAG_AssocNone: {
      V v_msg_2418;
      if (heff_strEq_c(heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1)))) {
        heff_drop_rec(v_before_242, 9);
        V v_t_2415 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str0));
        v_msg_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str1), v_t_2415);
      } else {
        V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str2));
        V v_t_2417 = heff_strAppend(heff_get_n(v_before_242, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str3), v_t_2416));
        v_msg_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str4), v_t_2417);
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam4, 1, 2, (V[]){v_op_243, v_msg_2418});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Unrelated: {
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop(v_fix_240);
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam5_clo);
    } else {
      V v_a_2424 = heff_get_n(v_before_242, 1, 9);
      V v_b_2425 = heff_dup(heff_rfield(v_op_243, 1));
      V v_t_2426 = (g_heff_2esyntax_2efixity_2ebothLoosest(v_fix_240, heff_dup(v_a_2424), heff_dup(v_b_2425)));
      V v_msg_2429;
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str5), heff_strAppend(v_b_2425, ((V)&g_heff_2esyntax_2esurface_2efirstS_str6)));
        v_msg_2429 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str7), heff_strAppend(v_a_2424, v_t_2427));
      } else {
        heff_drop(v_t_2426);
        V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str8), heff_strAppend(v_b_2425, ((V)&g_heff_2esyntax_2esurface_2efirstS_str9)));
        v_msg_2429 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str10), heff_strAppend(v_a_2424, v_t_2428));
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam6, 1, 2, (V[]){v_op_243, v_msg_2429});
    }
  }
  case TAG_Undeclared: {
    V v_x_2433 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      heff_drop(v_x_2433);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam7_clo);
    } else {
      V v_t_2437;
      if (heff_strEq_c(heff_dup(v_x_2433), heff_dup(heff_rfield(v_op_243, 1)))) {
        heff_drop_rec(v_before_242, 9);
        v_t_2437 = v_op_243;
      } else {
        heff_drop_rec(v_op_243, 9);
        v_t_2437 = v_before_242;
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam8, 1, 2, (V[]){v_x_2433, v_t_2437});
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efirstS(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_245});
}
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_247});
}
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args) {
  V v_st_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_st_2410});
}
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args) {
  V v_st_2412 = args[0];
  V v_t_2413 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_st_2412});
}
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args) {
  V v_st_2419 = args[0];
  V v_op_243 = heff_env(self)[0];
  V v_msg_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2418, v_t_2420, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_st_2419});
}
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args) {
  V v_st_2422 = args[0];
  V v_t_2423 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_st_2422});
}
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args) {
  V v_st_2430 = args[0];
  V v_op_243 = heff_env(self)[0];
  V v_msg_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2429, v_t_2431, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_st_2430});
}
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args) {
  V v_st_2434 = args[0];
  V v_t_2435 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_st_2434});
}
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args) {
  V v_st_2438 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_t_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str11), heff_strAppend(heff_dup(v_x_2433), ((V)&g_heff_2esyntax_2esurface_2efirstS_str12)));
  V v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str13), heff_strAppend(v_x_2433, v_t_2439));
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2437, 3), heff_get_n(v_t_2437, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2440, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2438});
}
Clo g_heff_2esyntax_2esurface_2efieldsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldsOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldsOf(V v_e_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_EParen: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Named: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Tup: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Braces: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Update: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_EUSet: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_InstB: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_EFSet: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_EFDefault: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Sum: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_ECon: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_EField: {
    V v_e1_2446 = heff_field(v_e_240, 0);
    V v_f_2447 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EField = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V t_0 = v_e1_2446;
    V t_1 = heff_tag_at_n(v_ru_24e_240_24EField, TAG_Cons, 2, (V[]){v_f_2447, v_acc_241});
    v_e_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_ENeg: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_App: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Op: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Ops: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_OpRhs: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Ann: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_BVar: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_BImp: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_BAnn: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Lam: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Case: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_EAlt: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_If: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_Do: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_ESBind: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkFields, 2, (V[]){v_e_240, v_acc_241});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2efieldsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldsOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etheoryFieldL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etheoryFieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryFieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etheoryFieldL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkTF: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ty_244 = heff_field(v_x2_241, 2);
    V v_d_245 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 13ULL, 4);
    V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_244}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etheoryFieldL_lam0, 1, 4, (V[]){v_m_246, v_r_240, v_d_245, v_x_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etheoryFieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryFieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etheoryFieldL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_245);
      heff_drop_rec(v_x_242, 9);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = (g_heff_2esyntax_2esurface_2edefaultL(v_r_240, v_d_245));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop_rec(v_x_242, 9);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_242, 3)), heff_take_field(v_x_242, 4)});
          V v_t_2420 = heff_tag_n(TAG_DeclareField, 4, (V[]){heff_dup(heff_rfield(v_x_242, 1)), v_t_2419, heff_dup(v_x_2412), heff_dup(v_x_2418)});
          V v_x1_2422;
          switch (heff_tag_of(v_x_2418)) {
          case TAG_Nothing: {
            v_x1_2422 = v_x_2412;
            break;
          }
          case TAG_Just: {
            V v_x_2421 = heff_field(v_x_2418, 0);
            heff_take_n(v_x_2418, 1ULL, 1);
            heff_drop(v_x_2412);
            v_x1_2422 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_x_2418);
          }
          V v_b_2425;
          switch (heff_tag_of(v_x1_2422)) {
          case TAG_At: {
            V v_s_2424 = heff_field(v_x1_2422, 1);
            heff_take_n(v_x1_2422, 2ULL, 2);
            v_b_2425 = v_s_2424;
            break;
          }
          default: heff_nomatch(v_x1_2422);
          }
          V v_t_2426 = ({ V rv_0 = heff_take_field(v_x_242, 3); V rr_ = heff_rec_reuse_nf(v_b_2425, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_x_2427 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_At, 2, (V[]){v_t_2420, v_t_2426});
          V v_t_2428 = heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 9), heff_dup(heff_rfield(v_st_2416, 1))});
          V v_t_2429 = ({ V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_st_2416, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){v_x_2427}), v_t_2429});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0, 5, "`: it");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1, 31, "nothing can be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3, 4, "`: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4, 28, "` cannot be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8, 2, " (");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10, 83, " is the loosest operator, below every other, declared `below` with nothing after it");
Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V v_d_240, V v_u_241, V v_g_242) {
top: ;
  V v_t_243 = heff_get_n(v_d_240, 1, 8);
  V v_t_2410;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0));
    v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1), v_t_244);
    break;
  }
  case TAG_Cons: {
    V v_op_245 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2));
    V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3), v_t_247));
    V v_t_249 = heff_strAppend(heff_get_n(v_op_245, 1, 7), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4), v_t_248));
    v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5), v_t_249);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_at_2411 = heff_get_n(v_g_242, 4, 5);
  V v_t_2413;
  if (heff_strEq_c(heff_dup(v_at_2411), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6))) {
    heff_drop(v_at_2411);
    v_t_2413 = ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7);
  } else {
    v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8), heff_strAppend(v_at_2411, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9)));
  }
  V v_msg_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10), v_t_2413));
  V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_u_241, 2), heff_get_n(v_u_241, 3, 7)});
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2414, v_t_2415, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebelowLoosestDiag(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V v_e_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2esurface_2ebracedOne(v_e_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0, 1, 1, (V[]){v_e_240});
  }
  case TAG_Just: {
    V v_f_2418 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2, 1, 2, (V[]){v_f_2418, v_e_240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args) {
  V v_st_2411 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_247}), v_st_2411});
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_240), v_st_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      V v_t_248 = ({ V a_0 = v_e_240; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_240); r_; });
      V v_m_2412;
      if (heff_strEq_c(heff_get_n(v_t_248, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0))) {
        V v_t_2410 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_247));
        v_m_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2410}));
      } else {
        v_m_2412 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1, 1, 1, (V[]){v_x_247});
      }
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_245}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_243_24MkPair, 2);
          return ({ V a_0 = v_x_2417; V a_1 = v_st_2415; V r_ = (g_heff_2esyntax_2esurface_2eparamOf(a_0, a_1)); heff_drop(v_x_2417); r_; });
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args) {
  V v_st_2419 = args[0];
  V v_f_2418 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2420 = (g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550(v_f_2418, v_st_2419));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_MkPair: {
    V v_x11_2421 = heff_field(v_x1_2420, 0);
    V v_st_2422 = heff_field(v_x1_2420, 1);
    V v_ru_24x1_2420_24MkPair = heff_take_reuse_n(v_x1_2420, 3ULL, 2);
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x11_2421, 0);
      heff_take_n(v_x11_2421, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2423}), v_st_2422});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x11_2421, 0);
      V v_ru_24x11_2421_24Right = heff_take_reuse_n(v_x11_2421, 1ULL, 1);
      V v_t_2425 = (g_heff_2esyntax_2esurface_2enameAnn(v_x_2424));
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nothing: {
        heff_drop(v_e_240);
        heff_drop_cell(v_ru_24x11_2421_24Right, 1);
        V v_span_2428;
        switch (heff_tag_of(v_x_2424)) {
        case TAG_At: {
          V v_s_2427 = heff_field(v_x_2424, 1);
          heff_take_n(v_x_2424, 2ULL, 2);
          v_span_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_x_2424);
        }
        V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1), v_span_2428, NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2429}), v_st_2422});
      }
      case TAG_Just: {
        V v_q_2430 = heff_field(v_t_2425, 0);
        heff_take_n(v_t_2425, 1ULL, 1);
        heff_drop(v_x_2424);
        V v_t_2431 = heff_tag_n(TAG_ImplicitParam, 3, (V[]){heff_take_field(v_q_2430, 0), heff_take_field(v_q_2430, 1), heff_get_n(v_q_2430, 2, 3)});
        V v_a_2432 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
        V v_b_2433 = (g_heff_2esyntax_2ecst_2elastE(v_e_240));
        V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2432, 3, 9), heff_get_n(v_b_2433, 4, 9)});
        V v_x_2435 = heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_At, 2, (V[]){v_t_2431, v_t_2434});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2421_24Right, TAG_Right, 1, (V[]){v_x_2435}), v_st_2422});
      }
      default: return heff_nomatch(v_t_2425);
      }
    }
    default: return heff_nomatch(v_x11_2421);
    }
  }
  default: return heff_nomatch(v_x1_2420);
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V v_e_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2esurface_2eatomOf(heff_dup(v_e_240)));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(v_e_240);
  }
  case TAG_Just: {
    V v_x_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop(v_e_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0, 1, 1, (V[]){v_x_242});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_242, 3)), heff_dup(heff_rfield(v_x_242, 4))});
  V v_t_245 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_242, 3)), heff_dup(heff_rfield(v_x_242, 4))});
  V v_t_247 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_x_242, 1), v_t_244, heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_t_246})});
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_get_n(v_x_242, 4, 9)});
  V v_t_249 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_t_248})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_st_243});
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0, 1, 1, (V[]){v_e_240});
  }
  case TAG_EParen: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1, 1, 1, (V[]){v_e_240});
  }
  case TAG_Named: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2, 1, 1, (V[]){v_e_240});
  }
  case TAG_Tup: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3, 1, 1, (V[]){v_e_240});
  }
  case TAG_Braces: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4, 1, 1, (V[]){v_e_240});
  }
  case TAG_Update: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5, 1, 1, (V[]){v_e_240});
  }
  case TAG_EUSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6, 1, 1, (V[]){v_e_240});
  }
  case TAG_InstB: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8, 1, 1, (V[]){v_e_240});
  }
  case TAG_EFDefault: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9, 1, 1, (V[]){v_e_240});
  }
  case TAG_Sum: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10, 1, 1, (V[]){v_e_240});
  }
  case TAG_ECon: {
    V v_c_24120 = heff_field(v_e_240, 0);
    V v_args_24121 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    V v_m_24122 = (g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(v_c_24120, v_args_24121));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11, 1, 1, (V[]){v_m_24122});
  }
  case TAG_EField: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12, 1, 1, (V[]){v_e_240});
  }
  case TAG_ENeg: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13, 1, 1, (V[]){v_e_240});
  }
  case TAG_App: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14, 1, 1, (V[]){v_e_240});
  }
  case TAG_Op: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15, 1, 1, (V[]){v_e_240});
  }
  case TAG_Ops: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16, 1, 1, (V[]){v_e_240});
  }
  case TAG_OpRhs: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17, 1, 1, (V[]){v_e_240});
  }
  case TAG_Ann: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18, 1, 1, (V[]){v_e_240});
  }
  case TAG_BVar: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19, 1, 1, (V[]){v_e_240});
  }
  case TAG_BImp: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20, 1, 1, (V[]){v_e_240});
  }
  case TAG_BAnn: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21, 1, 1, (V[]){v_e_240});
  }
  case TAG_Lam: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22, 1, 1, (V[]){v_e_240});
  }
  case TAG_Case: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23, 1, 1, (V[]){v_e_240});
  }
  case TAG_EAlt: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24, 1, 1, (V[]){v_e_240});
  }
  case TAG_If: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25, 1, 1, (V[]){v_e_240});
  }
  case TAG_Do: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26, 1, 1, (V[]){v_e_240});
  }
  case TAG_ESBind: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27, 1, 1, (V[]){v_e_240});
  }
  case TAG_ELet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28, 1, 1, (V[]){v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(a[0]);
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      V v_x_248 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_247));
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_248}), v_st_245});
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      V v_x_2418 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2417));
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2418}), v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args) {
  V v_st_2424 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2424));
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_MkPair: {
    V v_x11_2426 = heff_field(v_x1_2425, 0);
    V v_st_2427 = heff_field(v_x1_2425, 1);
    V v_ru_24x1_2425_24MkPair = heff_take_reuse_n(v_x1_2425, 3ULL, 2);
    switch (heff_tag_of(v_x11_2426)) {
    case TAG_Left: {
      V v_e_2428 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2428}), v_st_2427});
    }
    case TAG_Right: {
      V v_x_2429 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      V v_x_2430 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2429));
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2430}), v_st_2427});
    }
    default: return heff_nomatch(v_x11_2426);
    }
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args) {
  V v_st_2435 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2436 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2435));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_MkPair: {
    V v_x11_2437 = heff_field(v_x1_2436, 0);
    V v_st_2438 = heff_field(v_x1_2436, 1);
    V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_Left: {
      V v_e_2439 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      V v_x_2441 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2440));
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2441}), v_st_2438});
    }
    default: return heff_nomatch(v_x11_2437);
    }
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args) {
  V v_st_2446 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2447 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2446));
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_MkPair: {
    V v_x11_2448 = heff_field(v_x1_2447, 0);
    V v_st_2449 = heff_field(v_x1_2447, 1);
    V v_ru_24x1_2447_24MkPair = heff_take_reuse_n(v_x1_2447, 3ULL, 2);
    switch (heff_tag_of(v_x11_2448)) {
    case TAG_Left: {
      V v_e_2450 = heff_field(v_x11_2448, 0);
      heff_take_n(v_x11_2448, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2450}), v_st_2449});
    }
    case TAG_Right: {
      V v_x_2451 = heff_field(v_x11_2448, 0);
      heff_take_n(v_x11_2448, 1ULL, 1);
      V v_x_2452 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2451));
      return heff_tag_at_n(v_ru_24x1_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2449});
    }
    default: return heff_nomatch(v_x11_2448);
    }
  }
  default: return heff_nomatch(v_x1_2447);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args) {
  V v_st_2459 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2460 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2459));
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_MkPair: {
    V v_x11_2461 = heff_field(v_x1_2460, 0);
    V v_st_2462 = heff_field(v_x1_2460, 1);
    V v_ru_24x1_2460_24MkPair = heff_take_reuse_n(v_x1_2460, 3ULL, 2);
    switch (heff_tag_of(v_x11_2461)) {
    case TAG_Left: {
      V v_e_2463 = heff_field(v_x11_2461, 0);
      heff_take_n(v_x11_2461, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2463}), v_st_2462});
    }
    case TAG_Right: {
      V v_x_2464 = heff_field(v_x11_2461, 0);
      heff_take_n(v_x11_2461, 1ULL, 1);
      V v_x_2465 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2464));
      return heff_tag_at_n(v_ru_24x1_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2465}), v_st_2462});
    }
    default: return heff_nomatch(v_x11_2461);
    }
  }
  default: return heff_nomatch(v_x1_2460);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args) {
  V v_st_2469 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2470 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2469));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_MkPair: {
    V v_x11_2471 = heff_field(v_x1_2470, 0);
    V v_st_2472 = heff_field(v_x1_2470, 1);
    V v_ru_24x1_2470_24MkPair = heff_take_reuse_n(v_x1_2470, 3ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_Left: {
      V v_e_2473 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2473}), v_st_2472});
    }
    case TAG_Right: {
      V v_x_2474 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      V v_x_2475 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2474));
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2475}), v_st_2472});
    }
    default: return heff_nomatch(v_x11_2471);
    }
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args) {
  V v_st_2481 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2482 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2481));
  switch (heff_tag_of(v_x1_2482)) {
  case TAG_MkPair: {
    V v_x11_2483 = heff_field(v_x1_2482, 0);
    V v_st_2484 = heff_field(v_x1_2482, 1);
    V v_ru_24x1_2482_24MkPair = heff_take_reuse_n(v_x1_2482, 3ULL, 2);
    switch (heff_tag_of(v_x11_2483)) {
    case TAG_Left: {
      V v_e_2485 = heff_field(v_x11_2483, 0);
      heff_take_n(v_x11_2483, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2485}), v_st_2484});
    }
    case TAG_Right: {
      V v_x_2486 = heff_field(v_x11_2483, 0);
      heff_take_n(v_x11_2483, 1ULL, 1);
      V v_x_2487 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2486));
      return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2487}), v_st_2484});
    }
    default: return heff_nomatch(v_x11_2483);
    }
  }
  default: return heff_nomatch(v_x1_2482);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args) {
  V v_st_2491 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2492 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_2491));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      V v_x_2497 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2496));
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2497}), v_st_2494});
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args) {
  V v_st_24101 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24101));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24106));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args) {
  V v_st_24113 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24114 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24113));
  switch (heff_tag_of(v_x1_24114)) {
  case TAG_MkPair: {
    V v_x11_24115 = heff_field(v_x1_24114, 0);
    V v_st_24116 = heff_field(v_x1_24114, 1);
    V v_ru_24x1_24114_24MkPair = heff_take_reuse_n(v_x1_24114, 3ULL, 2);
    switch (heff_tag_of(v_x11_24115)) {
    case TAG_Left: {
      V v_e_24117 = heff_field(v_x11_24115, 0);
      heff_take_n(v_x11_24115, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24117}), v_st_24116});
    }
    case TAG_Right: {
      V v_x_24118 = heff_field(v_x11_24115, 0);
      heff_take_n(v_x11_24115, 1ULL, 1);
      V v_x_24119 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24118));
      return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24119}), v_st_24116});
    }
    default: return heff_nomatch(v_x11_24115);
    }
  }
  default: return heff_nomatch(v_x1_24114);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args) {
  V v_st_24123 = args[0];
  V v_m_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24124 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_st_24123}));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      V v_x_24129 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24128));
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24129}), v_st_24126});
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args) {
  V v_st_24132 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24133 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24132));
  switch (heff_tag_of(v_x1_24133)) {
  case TAG_MkPair: {
    V v_x11_24134 = heff_field(v_x1_24133, 0);
    V v_st_24135 = heff_field(v_x1_24133, 1);
    V v_ru_24x1_24133_24MkPair = heff_take_reuse_n(v_x1_24133, 3ULL, 2);
    switch (heff_tag_of(v_x11_24134)) {
    case TAG_Left: {
      V v_e_24136 = heff_field(v_x11_24134, 0);
      heff_take_n(v_x11_24134, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24133_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24136}), v_st_24135});
    }
    case TAG_Right: {
      V v_x_24137 = heff_field(v_x11_24134, 0);
      heff_take_n(v_x11_24134, 1ULL, 1);
      V v_x_24138 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24137));
      return heff_tag_at_n(v_ru_24x1_24133_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24138}), v_st_24135});
    }
    default: return heff_nomatch(v_x11_24134);
    }
  }
  default: return heff_nomatch(v_x1_24133);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args) {
  V v_st_24141 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24142 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24141));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_MkPair: {
    V v_x11_24143 = heff_field(v_x1_24142, 0);
    V v_st_24144 = heff_field(v_x1_24142, 1);
    V v_ru_24x1_24142_24MkPair = heff_take_reuse_n(v_x1_24142, 3ULL, 2);
    switch (heff_tag_of(v_x11_24143)) {
    case TAG_Left: {
      V v_e_24145 = heff_field(v_x11_24143, 0);
      heff_take_n(v_x11_24143, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24145}), v_st_24144});
    }
    case TAG_Right: {
      V v_x_24146 = heff_field(v_x11_24143, 0);
      heff_take_n(v_x11_24143, 1ULL, 1);
      V v_x_24147 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24146));
      return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24147}), v_st_24144});
    }
    default: return heff_nomatch(v_x11_24143);
    }
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args) {
  V v_st_24150 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24151 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24150));
  switch (heff_tag_of(v_x1_24151)) {
  case TAG_MkPair: {
    V v_x11_24152 = heff_field(v_x1_24151, 0);
    V v_st_24153 = heff_field(v_x1_24151, 1);
    V v_ru_24x1_24151_24MkPair = heff_take_reuse_n(v_x1_24151, 3ULL, 2);
    switch (heff_tag_of(v_x11_24152)) {
    case TAG_Left: {
      V v_e_24154 = heff_field(v_x11_24152, 0);
      heff_take_n(v_x11_24152, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24154}), v_st_24153});
    }
    case TAG_Right: {
      V v_x_24155 = heff_field(v_x11_24152, 0);
      heff_take_n(v_x11_24152, 1ULL, 1);
      V v_x_24156 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24155));
      return heff_tag_at_n(v_ru_24x1_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24156}), v_st_24153});
    }
    default: return heff_nomatch(v_x11_24152);
    }
  }
  default: return heff_nomatch(v_x1_24151);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args) {
  V v_st_24160 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24161 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24160));
  switch (heff_tag_of(v_x1_24161)) {
  case TAG_MkPair: {
    V v_x11_24162 = heff_field(v_x1_24161, 0);
    V v_st_24163 = heff_field(v_x1_24161, 1);
    V v_ru_24x1_24161_24MkPair = heff_take_reuse_n(v_x1_24161, 3ULL, 2);
    switch (heff_tag_of(v_x11_24162)) {
    case TAG_Left: {
      V v_e_24164 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24164}), v_st_24163});
    }
    case TAG_Right: {
      V v_x_24165 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      V v_x_24166 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24165));
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24163});
    }
    default: return heff_nomatch(v_x11_24162);
    }
  }
  default: return heff_nomatch(v_x1_24161);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args) {
  V v_st_24169 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24169));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      V v_x_24175 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24174));
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24175}), v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args) {
  V v_st_24178 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24179 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24178));
  switch (heff_tag_of(v_x1_24179)) {
  case TAG_MkPair: {
    V v_x11_24180 = heff_field(v_x1_24179, 0);
    V v_st_24181 = heff_field(v_x1_24179, 1);
    V v_ru_24x1_24179_24MkPair = heff_take_reuse_n(v_x1_24179, 3ULL, 2);
    switch (heff_tag_of(v_x11_24180)) {
    case TAG_Left: {
      V v_e_24182 = heff_field(v_x11_24180, 0);
      heff_take_n(v_x11_24180, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24179_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24182}), v_st_24181});
    }
    case TAG_Right: {
      V v_x_24183 = heff_field(v_x11_24180, 0);
      heff_take_n(v_x11_24180, 1ULL, 1);
      V v_x_24184 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24183));
      return heff_tag_at_n(v_ru_24x1_24179_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24184}), v_st_24181});
    }
    default: return heff_nomatch(v_x11_24180);
    }
  }
  default: return heff_nomatch(v_x1_24179);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args) {
  V v_st_24188 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24189 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24188));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_MkPair: {
    V v_x11_24190 = heff_field(v_x1_24189, 0);
    V v_st_24191 = heff_field(v_x1_24189, 1);
    V v_ru_24x1_24189_24MkPair = heff_take_reuse_n(v_x1_24189, 3ULL, 2);
    switch (heff_tag_of(v_x11_24190)) {
    case TAG_Left: {
      V v_e_24192 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24192}), v_st_24191});
    }
    case TAG_Right: {
      V v_x_24193 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      V v_x_24194 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24193));
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24194}), v_st_24191});
    }
    default: return heff_nomatch(v_x11_24190);
    }
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args) {
  V v_st_24196 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24197 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24196));
  switch (heff_tag_of(v_x1_24197)) {
  case TAG_MkPair: {
    V v_x11_24198 = heff_field(v_x1_24197, 0);
    V v_st_24199 = heff_field(v_x1_24197, 1);
    V v_ru_24x1_24197_24MkPair = heff_take_reuse_n(v_x1_24197, 3ULL, 2);
    switch (heff_tag_of(v_x11_24198)) {
    case TAG_Left: {
      V v_e_24200 = heff_field(v_x11_24198, 0);
      heff_take_n(v_x11_24198, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24200}), v_st_24199});
    }
    case TAG_Right: {
      V v_x_24201 = heff_field(v_x11_24198, 0);
      heff_take_n(v_x11_24198, 1ULL, 1);
      V v_x_24202 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24201));
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24202}), v_st_24199});
    }
    default: return heff_nomatch(v_x11_24198);
    }
  }
  default: return heff_nomatch(v_x1_24197);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args) {
  V v_st_24206 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24207 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24206));
  switch (heff_tag_of(v_x1_24207)) {
  case TAG_MkPair: {
    V v_x11_24208 = heff_field(v_x1_24207, 0);
    V v_st_24209 = heff_field(v_x1_24207, 1);
    V v_ru_24x1_24207_24MkPair = heff_take_reuse_n(v_x1_24207, 3ULL, 2);
    switch (heff_tag_of(v_x11_24208)) {
    case TAG_Left: {
      V v_e_24210 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24210}), v_st_24209});
    }
    case TAG_Right: {
      V v_x_24211 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      V v_x_24212 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24211));
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24212}), v_st_24209});
    }
    default: return heff_nomatch(v_x11_24208);
    }
  }
  default: return heff_nomatch(v_x1_24207);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args) {
  V v_st_24218 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24219 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24218));
  switch (heff_tag_of(v_x1_24219)) {
  case TAG_MkPair: {
    V v_x11_24220 = heff_field(v_x1_24219, 0);
    V v_st_24221 = heff_field(v_x1_24219, 1);
    V v_ru_24x1_24219_24MkPair = heff_take_reuse_n(v_x1_24219, 3ULL, 2);
    switch (heff_tag_of(v_x11_24220)) {
    case TAG_Left: {
      V v_e_24222 = heff_field(v_x11_24220, 0);
      heff_take_n(v_x11_24220, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24222}), v_st_24221});
    }
    case TAG_Right: {
      V v_x_24223 = heff_field(v_x11_24220, 0);
      heff_take_n(v_x11_24220, 1ULL, 1);
      V v_x_24224 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24223));
      return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24224}), v_st_24221});
    }
    default: return heff_nomatch(v_x11_24220);
    }
  }
  default: return heff_nomatch(v_x1_24219);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args) {
  V v_st_24229 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24230 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24229));
  switch (heff_tag_of(v_x1_24230)) {
  case TAG_MkPair: {
    V v_x11_24231 = heff_field(v_x1_24230, 0);
    V v_st_24232 = heff_field(v_x1_24230, 1);
    V v_ru_24x1_24230_24MkPair = heff_take_reuse_n(v_x1_24230, 3ULL, 2);
    switch (heff_tag_of(v_x11_24231)) {
    case TAG_Left: {
      V v_e_24233 = heff_field(v_x11_24231, 0);
      heff_take_n(v_x11_24231, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24233}), v_st_24232});
    }
    case TAG_Right: {
      V v_x_24234 = heff_field(v_x11_24231, 0);
      heff_take_n(v_x11_24231, 1ULL, 1);
      V v_x_24235 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24234));
      return heff_tag_at_n(v_ru_24x1_24230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24235}), v_st_24232});
    }
    default: return heff_nomatch(v_x11_24231);
    }
  }
  default: return heff_nomatch(v_x1_24230);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args) {
  V v_st_24240 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24241 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24240));
  switch (heff_tag_of(v_x1_24241)) {
  case TAG_MkPair: {
    V v_x11_24242 = heff_field(v_x1_24241, 0);
    V v_st_24243 = heff_field(v_x1_24241, 1);
    V v_ru_24x1_24241_24MkPair = heff_take_reuse_n(v_x1_24241, 3ULL, 2);
    switch (heff_tag_of(v_x11_24242)) {
    case TAG_Left: {
      V v_e_24244 = heff_field(v_x11_24242, 0);
      heff_take_n(v_x11_24242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24244}), v_st_24243});
    }
    case TAG_Right: {
      V v_x_24245 = heff_field(v_x11_24242, 0);
      heff_take_n(v_x11_24242, 1ULL, 1);
      V v_x_24246 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24245));
      return heff_tag_at_n(v_ru_24x1_24241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24246}), v_st_24243});
    }
    default: return heff_nomatch(v_x11_24242);
    }
  }
  default: return heff_nomatch(v_x1_24241);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args) {
  V v_st_24250 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24251 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24250));
  switch (heff_tag_of(v_x1_24251)) {
  case TAG_MkPair: {
    V v_x11_24252 = heff_field(v_x1_24251, 0);
    V v_st_24253 = heff_field(v_x1_24251, 1);
    V v_ru_24x1_24251_24MkPair = heff_take_reuse_n(v_x1_24251, 3ULL, 2);
    switch (heff_tag_of(v_x11_24252)) {
    case TAG_Left: {
      V v_e_24254 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24254}), v_st_24253});
    }
    case TAG_Right: {
      V v_x_24255 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      V v_x_24256 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24255));
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24256}), v_st_24253});
    }
    default: return heff_nomatch(v_x11_24252);
    }
  }
  default: return heff_nomatch(v_x1_24251);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args) {
  V v_st_24263 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24264 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24263));
  switch (heff_tag_of(v_x1_24264)) {
  case TAG_MkPair: {
    V v_x11_24265 = heff_field(v_x1_24264, 0);
    V v_st_24266 = heff_field(v_x1_24264, 1);
    V v_ru_24x1_24264_24MkPair = heff_take_reuse_n(v_x1_24264, 3ULL, 2);
    switch (heff_tag_of(v_x11_24265)) {
    case TAG_Left: {
      V v_e_24267 = heff_field(v_x11_24265, 0);
      heff_take_n(v_x11_24265, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24264_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24267}), v_st_24266});
    }
    case TAG_Right: {
      V v_x_24268 = heff_field(v_x11_24265, 0);
      heff_take_n(v_x11_24265, 1ULL, 1);
      V v_x_24269 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24268));
      return heff_tag_at_n(v_ru_24x1_24264_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24269}), v_st_24266});
    }
    default: return heff_nomatch(v_x11_24265);
    }
  }
  default: return heff_nomatch(v_x1_24264);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args) {
  V v_st_24272 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24273 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24272));
  switch (heff_tag_of(v_x1_24273)) {
  case TAG_MkPair: {
    V v_x11_24274 = heff_field(v_x1_24273, 0);
    V v_st_24275 = heff_field(v_x1_24273, 1);
    V v_ru_24x1_24273_24MkPair = heff_take_reuse_n(v_x1_24273, 3ULL, 2);
    switch (heff_tag_of(v_x11_24274)) {
    case TAG_Left: {
      V v_e_24276 = heff_field(v_x11_24274, 0);
      heff_take_n(v_x11_24274, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24273_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24276}), v_st_24275});
    }
    case TAG_Right: {
      V v_x_24277 = heff_field(v_x11_24274, 0);
      heff_take_n(v_x11_24274, 1ULL, 1);
      V v_x_24278 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24277));
      return heff_tag_at_n(v_ru_24x1_24273_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24278}), v_st_24275});
    }
    default: return heff_nomatch(v_x11_24274);
    }
  }
  default: return heff_nomatch(v_x1_24273);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args) {
  V v_st_24282 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24283 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24282));
  switch (heff_tag_of(v_x1_24283)) {
  case TAG_MkPair: {
    V v_x11_24284 = heff_field(v_x1_24283, 0);
    V v_st_24285 = heff_field(v_x1_24283, 1);
    V v_ru_24x1_24283_24MkPair = heff_take_reuse_n(v_x1_24283, 3ULL, 2);
    switch (heff_tag_of(v_x11_24284)) {
    case TAG_Left: {
      V v_e_24286 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24286}), v_st_24285});
    }
    case TAG_Right: {
      V v_x_24287 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      V v_x_24288 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24287));
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24288}), v_st_24285});
    }
    default: return heff_nomatch(v_x11_24284);
    }
  }
  default: return heff_nomatch(v_x1_24283);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args) {
  V v_st_24295 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24296 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_24295));
  switch (heff_tag_of(v_x1_24296)) {
  case TAG_MkPair: {
    V v_x11_24297 = heff_field(v_x1_24296, 0);
    V v_st_24298 = heff_field(v_x1_24296, 1);
    V v_ru_24x1_24296_24MkPair = heff_take_reuse_n(v_x1_24296, 3ULL, 2);
    switch (heff_tag_of(v_x11_24297)) {
    case TAG_Left: {
      V v_e_24299 = heff_field(v_x11_24297, 0);
      heff_take_n(v_x11_24297, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24296_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24299}), v_st_24298});
    }
    case TAG_Right: {
      V v_x_24300 = heff_field(v_x11_24297, 0);
      heff_take_n(v_x11_24297, 1ULL, 1);
      V v_x_24301 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24300));
      return heff_tag_at_n(v_ru_24x1_24296_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24301}), v_st_24298});
    }
    default: return heff_nomatch(v_x11_24297);
    }
  }
  default: return heff_nomatch(v_x1_24296);
  }
}
Clo g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nothing: {
    V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Just: {
    V v_x21_243 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24Just = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_d_245 = heff_field(v_x21_243, 1);
      V v_ru_24x21_243_24MkPair = heff_take_reuse_n(v_x21_243, 2ULL, 2);
      V v_x1_246 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_d_245, v_p_241));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_MkPair: {
        V v_x11_247 = heff_field(v_x1_246, 0);
        V v_st_248 = heff_field(v_x1_246, 1);
        heff_take_n(v_x1_246, 3ULL, 2);
        switch (heff_tag_of(v_x11_247)) {
        case TAG_Left: {
          V v_e_249 = heff_field(v_x11_247, 0);
          heff_take_n(v_x11_247, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24Just, TAG_Left, 1, (V[]){v_e_249}), v_st_248});
        }
        case TAG_Right: {
          V v_x_2410 = heff_field(v_x11_247, 0);
          heff_take_n(v_x11_247, 1ULL, 1);
          V v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Just, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2410})});
          return heff_tag_at_n(v_ru_24x21_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_st_248});
        }
        default: return heff_nomatch(v_x11_247);
        }
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V v_ys_240, V v_pv_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_245 = heff_field(v_x2_242, 1);
    V v_t_247 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_245));
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(v_t_247, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_248);
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 1)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2))) {
          V v_t_2413 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_249, 1))}));
          V v_t_2414 = (g_list_2eany(v_t_2413, v_pv_241));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            V v_x_2415 = heff_dup(heff_rfield(v_t_249, 1));
            V v_t_2416 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
            return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_t_2416}));
          } else {
            heff_drop(v_t_2414);
            return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
          }
        } else {
          return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
        }
      } else {
        V v_x_2417 = heff_dup(heff_rfield(v_t_249, 1));
        V v_t_2418 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
        return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_t_2418}));
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str3))) {
        V v_t_2420 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_249, 1))}));
        V v_t_2421 = (g_list_2eany(v_t_2420, v_pv_241));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          V v_x_2422 = heff_dup(heff_rfield(v_t_249, 1));
          V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, v_t_2423}));
        } else {
          heff_drop(v_t_2421);
          return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
        }
      } else {
        return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2425 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2425;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2428 = heff_field(v_x2_242, 1);
    V v_t_2432 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2428));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2432, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2433);
  }
  case TAG_POp: {
    V v_l_2434 = heff_field(v_x2_242, 0);
    V v_q_2436 = heff_field(v_x2_242, 2);
    V v_t_2437 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2434));
    V v_t_2438 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2436));
    V v_t_2439 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2437, v_t_2438));
    V v_t_2440 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2439, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2440);
  }
  case TAG_PRec: {
    V v_fs_2442 = heff_field(v_x2_242, 1);
    V v_t_2446 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2442));
    V v_t_2447 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2446, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2447);
  }
  case TAG_PField: {
    V v_q_2450 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2450;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2451 = heff_field(v_x2_242, 0);
    V v_q_2453 = heff_field(v_x2_242, 2);
    V v_x_2454 = heff_dup(heff_rfield(v_x_2451, 1));
    V v_cell_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2454, heff_hole()});
    V v_u_2456 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2455));
    heff_drop(v_u_2456);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2453;
    V t_3 = v_cell_2455;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args) {
  V v_q_246 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_246; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_246); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args) {
  V v_q_2431 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2431; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2431); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args) {
  V v_q_2445 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2445; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2445); r_; });
}