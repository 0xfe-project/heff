// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DeclTheory 39552
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_head 9693863
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2ebothLoosest(V, V, V);
V g_heff_2esyntax_2efixity_2ebothLoosest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2ebothLoosest_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2earrowNames(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V, V, V);
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V, V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
double g_heff_2esyntax_2esurface_2efloatSplit_w(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatSplit_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eipow10(V);
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eipow10_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldL(V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldL_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s708392557x194554207(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s708392557x194554207_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s708392557x194554207_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eintOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintOfText_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eintOfText(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str0))) {
    V v_t_242 = (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    return heff_intSub(MK_INT(0LL), v_t_242);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str1))) {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    } else {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(0LL)));
    }
  }
}
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintOfText(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2efloatSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatSplit_entry, 2, 0};

double g_heff_2esyntax_2esurface_2efloatSplit_w(V v_s_240, V v_eAt_241) {
top: ;
  V v_m_242 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2);
  V v_d_243 = ({ V b_0 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_247;
  if (heff_intLe_c(heff_strLength_lent(v_m_242, 0), heff_dup(v_d_243))) {
    heff_drop(v_d_243);
    v_m_247 = ({ V a_0 = v_m_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_m_242); r_; });
  } else {
    V v_t_245 = heff_strSlice(heff_dup(v_m_242), heff_intAdd(heff_dup(v_d_243), MK_INT(1LL)), heff_strLength_lent(v_m_242, 0));
    V v_t_246 = heff_strAppend(heff_strSlice(v_m_242, MK_INT(0LL), v_d_243), v_t_245);
    v_m_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_246); r_; });
  }
  V v_t_2410;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_eAt_241))) {
    v_t_2410 = MK_INT(0LL);
  } else {
    V v_t_249 = heff_strSlice(heff_dup(v_s_240), heff_intAdd(heff_dup(v_eAt_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0));
    v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2esyntax_2esurface_2eexpOf(a_0)); heff_drop(v_t_249); r_; });
  }
  V v_m_2411 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2);
  V v_d_2412 = ({ V b_0 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 6); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2415;
  if (heff_intLe_c(heff_strLength_lent(v_m_2411, 0), heff_dup(v_d_2412))) {
    heff_drop(v_m_2411);
    heff_drop(v_d_2412);
    v_t_2415 = MK_INT(0LL);
  } else {
    V v_t_2414 = heff_intSub(heff_strLength(v_m_2411), v_d_2412);
    v_t_2415 = heff_intSub(v_t_2414, MK_INT(1LL));
  }
  V v_p_2416 = heff_intSub(v_t_2410, v_t_2415);
  if (heff_intLe_c_lent(MK_INT(0LL), v_p_2416, 1)) {
    V v_t_2418 = (g_heff_2esyntax_2esurface_2eipow10(v_p_2416));
    return heff_from_int_f64(heff_intMul(v_m_247, v_t_2418));
  } else {
    V v_t_2419 = (g_heff_2esyntax_2esurface_2eipow10(heff_intSub(MK_INT(0LL), v_p_2416)));
    return (heff_from_int_f64(v_m_247) / heff_from_int_f64(v_t_2419));
  }
}
V g_heff_2esyntax_2esurface_2efloatSplit(V v_s_240, V v_eAt_241) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_eAt_241)));
}
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efloatSplit(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatOfDigits_entry, 1, 0};

double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_244 = ({ V a_0 = v_t_243; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_243); r_; });
    double v_t_245 = ({ V a_0 = v_t_242; V a_1 = v_t_244; double r_ = (g_heff_2esyntax_2esurface_2efloatSplit_w(a_0, a_1)); heff_drop(v_t_242); r_; });
    return ((0.0) - v_t_245);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str1))) {
      V v_t_247 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_248 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_249 = ({ V a_0 = v_t_248; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_248); r_; });
      return ({ V a_0 = v_t_247; V a_1 = v_t_249; double r_ = (g_heff_2esyntax_2esurface_2efloatSplit_w(a_0, a_1)); heff_drop(v_t_247); r_; });
    } else {
      V v_t_2410 = (g_heff_2esyntax_2esurface_2esplitExp(v_s_240, MK_INT(0LL)));
      return (g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_t_2410));
    }
  }
}
V g_heff_2esyntax_2esurface_2efloatOfDigits(V v_s_240) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_s_240)));
}
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efloatOfDigits(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2earrowNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowNames_entry, 6, 0};

V g_heff_2esyntax_2esurface_2earrowNames(V v_rhs_240, V v_g_241, V v_ty_242, V v_braces_243, V v_dflt_244, V v_orig_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_get_n(v_t_247, 1, 2)});
  V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a_0)); heff_drop_tag(v_t_248, 2); r_; });
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_orig_245);
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_241));
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2410, 0, 2), heff_get_n(v_t_2411, 1, 2)});
    return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2earrowNames_lam0, 2, 3, (V[]){v_braces_243, v_ty_242, v_dflt_244}); V a_1 = v_rhs_240; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop_tag(v_t_2412, 2); r_; });
  } else {
    heff_drop(v_g_241);
    heff_drop(v_ty_242);
    heff_drop(v_dflt_244);
    heff_drop(v_t_249);
    switch (heff_tag_of(v_braces_243)) {
    case TAG_Nothing: {
      V v_t_2477 = (g_heff_2esyntax_2esurface_2eplainBinder(heff_dup(v_orig_245)));
      V v_t_2480;
      switch (heff_tag_of(v_orig_245)) {
      case TAG_At: {
        V v_s_2479 = heff_field(v_orig_245, 1);
        heff_take_n(v_orig_245, 2ULL, 2);
        v_t_2480 = v_s_2479;
        break;
      }
      default: heff_nomatch(v_orig_245);
      }
      V v_t_2483;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2482 = heff_dup(heff_field(v_rhs_240, 1));
        v_t_2483 = v_s_2482;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2484 = ({ V rv_1 = heff_get_n(v_t_2483, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2480, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EPi, 2, (V[]){v_t_2477, v_rhs_240}), v_t_2484});
    }
    case TAG_Just: {
      V v_bsp_2485 = heff_field(v_braces_243, 0);
      V v_ru_24braces_243_24Just = heff_take_reuse_n(v_braces_243, 1ULL, 1);
      heff_drop(v_orig_245);
      V v_t_2486 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24braces_243_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_str0)}), heff_dup(v_bsp_2485)});
      V v_t_2487 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2486}), heff_dup(v_rhs_240)});
      V v_t_2490;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2489 = heff_field(v_rhs_240, 1);
        heff_take_n(v_rhs_240, 2ULL, 2);
        v_t_2490 = v_s_2489;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2491 = ({ V rv_1 = heff_get_n(v_t_2490, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2485, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2487, v_t_2491});
    }
    default: return heff_nomatch(v_braces_243);
    }
  }
}
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowNames(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_b_2414 = args[1];
  V v_braces_243 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_dflt_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_At: {
    V v_it1_2415 = heff_field(v_x_2413, 0);
    V v_ysp_2416 = heff_field(v_x_2413, 1);
    V v_ru_24x_2413_24At = heff_take_reuse_n(v_x_2413, 3ULL, 2);
    switch (heff_tag_of(v_it1_2415)) {
    case TAG_EVar: {
      V v_y_2417 = heff_field(v_it1_2415, 0);
      heff_take_n(v_it1_2415, 1ULL, 1);
      switch (heff_tag_of(v_braces_243)) {
      case TAG_Nothing: {
        heff_drop(v_dflt_244);
        V v_t_2418 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiNamed, 3, (V[]){v_y_2417, heff_dup(v_ysp_2416), v_ty_242}), heff_dup(v_b_2414)});
        V v_t_2421;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_ysp_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2413_24At, TAG_At, 2, (V[]){v_t_2418, v_t_2422});
      }
      case TAG_Just: {
        V v_bsp_2423 = heff_field(v_braces_243, 0);
        heff_take_n(v_braces_243, 1ULL, 1);
        V v_t_2424 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiImplicit, 5, (V[]){v_y_2417, v_ysp_2416, heff_dup(v_bsp_2423), v_ty_242, v_dflt_244}), heff_dup(v_b_2414)});
        V v_t_2427;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2413_24At, TAG_At, 2, (V[]){v_t_2424, v_t_2428});
      }
      default: return heff_nomatch(v_braces_243);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETag: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInt: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EString: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EBinary: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ERune: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWord: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EApp: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EProject: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EPi: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELam: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_2415, 0ULL, 4);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESig: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESum: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EDo: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EAssign: {
      heff_take_n(v_it1_2415, 0ULL, 3);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWhile: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EFor: {
      heff_take_n(v_it1_2415, 0ULL, 3);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EIfThen: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EBreak: {
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EContinue: {
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EReturn: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ENest: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    default: return heff_nomatch(v_it1_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str1, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str2, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str3, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str4, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str5, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str6, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str7, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str8, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str9, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str10, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str11, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str12, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str13, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str14, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str15, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str16, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str17, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str18, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str19, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str20, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str21, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str22, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str23, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str24, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str25, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str26, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str27, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str28, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str29, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str30, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str31, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str32, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str33, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str34, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str35, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str36, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str37, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str38, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str39, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str40, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str41, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str42, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str43, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str44, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str45, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str46, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str47, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str48, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str49, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str50, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str51, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str52, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str53, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str54, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str55, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str56, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str57, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str58, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str59, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str60, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str61, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str62, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str63, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str64, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str65, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str66, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str67, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str68, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str69, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str70, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str71, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str72, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str73, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str74, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str75, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str76, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str77, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str78, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str79, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str80, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str81, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str82, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str83, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str84, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str85, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str86, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str87, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str88, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str89, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str90, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str91, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str92, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str93, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str94, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str95, 49, "an instance argument is named: `{{x : T}} -> ...`");
Clo g_heff_2esyntax_2esurface_2earrowBinop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowBinop_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowBinop(V v_x1_240, V v_rhs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Plain: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Plain = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_243 = heff_dup(heff_field(v_x11_242, 0));
      V v_sp_244 = heff_dup(heff_field(v_x11_242, 1));
      switch (heff_tag_of(v_x111_243)) {
      case TAG_EVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_246 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_249;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_248 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2412;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2413});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2415 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2418;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2417 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2418 = v_s_2417;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2421;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2422});
      }
      case TAG_ETag: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2424 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2427;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2430;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2429 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2431 = ({ V rv_1 = heff_get_n(v_t_2430, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2427, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2431});
      }
      case TAG_EInt: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2433 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2436;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2439;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2438 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2440 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2436, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2433, v_t_2440});
      }
      case TAG_EFloat: {
        heff_take_na(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2442 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2445;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2444 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2448;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2447 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2448 = v_s_2447;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2449 = ({ V rv_1 = heff_get_n(v_t_2448, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2445, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2449});
      }
      case TAG_EString: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2451 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2454;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2453 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2457;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2456 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2457 = v_s_2456;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2458 = ({ V rv_1 = heff_get_n(v_t_2457, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2454, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_t_2458});
      }
      case TAG_EBinary: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2460 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2463;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2462 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2466;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2465 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2466 = v_s_2465;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2467 = ({ V rv_1 = heff_get_n(v_t_2466, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2463, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2460, v_t_2467});
      }
      case TAG_ERune: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2469 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2472;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2471 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2475;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2474 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2476 = ({ V rv_1 = heff_get_n(v_t_2475, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2472, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_t_2476});
      }
      case TAG_EWord: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2478 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2481;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2480 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2481 = v_s_2480;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2484;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2483 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2485 = ({ V rv_1 = heff_get_n(v_t_2484, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2481, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2478, v_t_2485});
      }
      case TAG_EApp: {
        V v_ru_24x111_243_24EApp = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_2488 = heff_tag_at_n(v_ru_24x111_243_24EApp, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2491;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2490 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2491 = v_s_2490;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2494;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2493 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2495 = ({ V rv_1 = heff_get_n(v_t_2494, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2491, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2488, v_t_2495});
      }
      case TAG_EProject: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_2497 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24100;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2499 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24100 = v_s_2499;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24103;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24102 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24104 = ({ V rv_1 = heff_get_n(v_t_24103, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24100, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2497, v_t_24104});
      }
      case TAG_ENamed: {
        V v_ru_24x111_243_24ENamed = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24107 = heff_tag_at_n(v_ru_24x111_243_24ENamed, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24110;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24109 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24110 = v_s_24109;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24113;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24112 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24114 = ({ V rv_1 = heff_get_n(v_t_24113, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24110, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24107, v_t_24114});
      }
      case TAG_EPi: {
        V v_ru_24x111_243_24EPi = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24117 = heff_tag_at_n(v_ru_24x111_243_24EPi, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24120;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24119 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24120 = v_s_24119;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24123;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24122 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24124 = ({ V rv_1 = heff_get_n(v_t_24123, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24120, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24117, v_t_24124});
      }
      case TAG_ELam: {
        V v_ru_24x111_243_24ELam = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24127 = heff_tag_at_n(v_ru_24x111_243_24ELam, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24130;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24129 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24130 = v_s_24129;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24133;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24132 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24133 = v_s_24132;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24134 = ({ V rv_1 = heff_get_n(v_t_24133, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24130, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24127, v_t_24134});
      }
      case TAG_EAnn: {
        V v_g_24135 = heff_field(v_x111_243, 0);
        V v_ty_24136 = heff_field(v_x111_243, 1);
        V v_ru_24x111_243_24EAnn = heff_take_reuse_n(v_x111_243, 3ULL, 2);
        heff_drop_tag(v_x11_242, 2);
        heff_drop_cell(v_ru_24x1_240_24Plain, 1);
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x111_243_24EAnn, TAG_EAnn, 2, (V[]){heff_dup(v_g_24135), heff_dup(v_ty_24136)}), v_sp_244});
        return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_24135, v_ty_24136, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_t_24137));
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_243, 0ULL, 4);
        heff_drop(v_sp_244);
        V v_t_24142 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24145;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24144 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24148;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24147 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24148 = v_s_24147;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24149 = ({ V rv_1 = heff_get_n(v_t_24148, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24145, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24142, v_t_24149});
      }
      case TAG_ESig: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24151 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24154;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24153 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24154 = v_s_24153;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24157;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24156 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24157 = v_s_24156;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24158 = ({ V rv_1 = heff_get_n(v_t_24157, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24154, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24151, v_t_24158});
      }
      case TAG_ESum: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24160 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24163;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24162 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24163 = v_s_24162;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24166;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24165 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24166 = v_s_24165;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24167 = ({ V rv_1 = heff_get_n(v_t_24166, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24163, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24160, v_t_24167});
      }
      case TAG_EStruct: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24169 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24172;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24171 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24172 = v_s_24171;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24175;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24174 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24175 = v_s_24174;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24176 = ({ V rv_1 = heff_get_n(v_t_24175, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24172, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24169, v_t_24176});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_243_24EUpdate = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24179 = heff_tag_at_n(v_ru_24x111_243_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24182;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24181 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24182 = v_s_24181;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24185;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24184 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24185 = v_s_24184;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24186 = ({ V rv_1 = heff_get_n(v_t_24185, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24182, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24179, v_t_24186});
      }
      case TAG_EMatch: {
        V v_ru_24x111_243_24EMatch = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24189 = heff_tag_at_n(v_ru_24x111_243_24EMatch, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24192;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24191 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24192 = v_s_24191;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24195;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24194 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24195 = v_s_24194;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24196 = ({ V rv_1 = heff_get_n(v_t_24195, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24192, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24189, v_t_24196});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_243_24ELetIn = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24199 = heff_tag_at_n(v_ru_24x111_243_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24202;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24201 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24202 = v_s_24201;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24205;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24204 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24205 = v_s_24204;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24206 = ({ V rv_1 = heff_get_n(v_t_24205, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24202, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24199, v_t_24206});
      }
      case TAG_EDo: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24208 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24211;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24210 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24214;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24213 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24214 = v_s_24213;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24215 = ({ V rv_1 = heff_get_n(v_t_24214, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24211, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24208, v_t_24215});
      }
      case TAG_ELocal: {
        V v_ru_24x111_243_24ELocal = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24218 = heff_tag_at_n(v_ru_24x111_243_24ELocal, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24221;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24220 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24221 = v_s_24220;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24224;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24223 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24224 = v_s_24223;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24225 = ({ V rv_1 = heff_get_n(v_t_24224, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24221, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24218, v_t_24225});
      }
      case TAG_EInvalid: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24227 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24230;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24229 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24233;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24232 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24233 = v_s_24232;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24234 = ({ V rv_1 = heff_get_n(v_t_24233, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24230, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24227, v_t_24234});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop(v_sp_244);
        V v_t_24238 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24241;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24240 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24241 = v_s_24240;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24244;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24243 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24244 = v_s_24243;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24245 = ({ V rv_1 = heff_get_n(v_t_24244, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24241, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24238, v_t_24245});
      }
      case TAG_EWhile: {
        V v_ru_24x111_243_24EWhile = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24248 = heff_tag_at_n(v_ru_24x111_243_24EWhile, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24251;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24250 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24251 = v_s_24250;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24254;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24253 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24254 = v_s_24253;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24255 = ({ V rv_1 = heff_get_n(v_t_24254, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24251, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24248, v_t_24255});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_243, 0ULL, 3);
        heff_drop(v_sp_244);
        V v_t_24259 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24262;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24261 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24262 = v_s_24261;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24265;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24264 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24265 = v_s_24264;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24266 = ({ V rv_1 = heff_get_n(v_t_24265, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24262, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24259, v_t_24266});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_243_24EIfThen = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        heff_drop(v_sp_244);
        V v_t_24269 = heff_tag_at_n(v_ru_24x111_243_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24272;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24271 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24272 = v_s_24271;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24275;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24274 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24275 = v_s_24274;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24276 = ({ V rv_1 = heff_get_n(v_t_24275, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24272, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24269, v_t_24276});
      }
      case TAG_EBreak: {
        heff_drop(v_sp_244);
        V v_t_24277 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24280;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24279 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24280 = v_s_24279;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24283;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24282 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24283 = v_s_24282;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24284 = ({ V rv_1 = heff_get_n(v_t_24283, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24280, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24277, v_t_24284});
      }
      case TAG_EContinue: {
        heff_drop(v_sp_244);
        V v_t_24285 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24288;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24287 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24288 = v_s_24287;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24291;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24290 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24292 = ({ V rv_1 = heff_get_n(v_t_24291, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24288, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24285, v_t_24292});
      }
      case TAG_EReturn: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24294 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24297;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24296 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24297 = v_s_24296;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24300;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24299 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24300 = v_s_24299;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24301 = ({ V rv_1 = heff_get_n(v_t_24300, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24297, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24294, v_t_24301});
      }
      case TAG_ENest: {
        heff_take_n(v_x111_243, 0ULL, 1);
        heff_drop(v_sp_244);
        V v_t_24303 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24306;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24305 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24306 = v_s_24305;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24309;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24308 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24309 = v_s_24308;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24310 = ({ V rv_1 = heff_get_n(v_t_24309, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24306, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24303, v_t_24310});
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_Braced: {
    V v_x11_24311 = heff_field(v_x1_240, 0);
    V v_dflt_24312 = heff_field(v_x1_240, 1);
    V v_bsp_24313 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x11_24311)) {
    case TAG_At: {
      V v_x111_24314 = heff_field(v_x11_24311, 0);
      V v_sp_24315 = heff_field(v_x11_24311, 1);
      V v_ru_24x11_24311_24At = heff_take_reuse_n(v_x11_24311, 3ULL, 2);
      switch (heff_tag_of(v_x111_24314)) {
      case TAG_EVar: {
        V v_ru_24x111_24314_24EVar = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24317 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str0)}), heff_dup(v_bsp_24313)});
        V v_t_24318 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EVar, TAG_PiAnon, 1, (V[]){v_t_24317}), heff_dup(v_rhs_241)});
        V v_t_24321;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24320 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24321 = v_s_24320;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24322 = ({ V rv_1 = heff_get_n(v_t_24321, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24318, v_t_24322});
      }
      case TAG_EImplicitVar: {
        V v_ru_24x111_24314_24EImplicitVar = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24324 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str1)}), heff_dup(v_bsp_24313)});
        V v_t_24325 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_t_24324}), heff_dup(v_rhs_241)});
        V v_t_24328;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24327 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24328 = v_s_24327;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24329 = ({ V rv_1 = heff_get_n(v_t_24328, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24325, v_t_24329});
      }
      case TAG_ETag: {
        V v_ru_24x111_24314_24ETag = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24331 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str2)}), heff_dup(v_bsp_24313)});
        V v_t_24332 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24ETag, TAG_PiAnon, 1, (V[]){v_t_24331}), heff_dup(v_rhs_241)});
        V v_t_24335;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24334 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24335 = v_s_24334;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24336 = ({ V rv_1 = heff_get_n(v_t_24335, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24332, v_t_24336});
      }
      case TAG_EInt: {
        V v_ru_24x111_24314_24EInt = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24338 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str3)}), heff_dup(v_bsp_24313)});
        V v_t_24339 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EInt, TAG_PiAnon, 1, (V[]){v_t_24338}), heff_dup(v_rhs_241)});
        V v_t_24342;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24341 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24342 = v_s_24341;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24343 = ({ V rv_1 = heff_get_n(v_t_24342, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24339, v_t_24343});
      }
      case TAG_EFloat: {
        V v_ru_24x111_24314_24EFloat = heff_take_reuse_na(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24345 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str4)}), heff_dup(v_bsp_24313)});
        V v_t_24346 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EFloat, TAG_PiAnon, 1, (V[]){v_t_24345}), heff_dup(v_rhs_241)});
        V v_t_24349;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24348 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24349 = v_s_24348;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24350 = ({ V rv_1 = heff_get_n(v_t_24349, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24346, v_t_24350});
      }
      case TAG_EString: {
        V v_ru_24x111_24314_24EString = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24352 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str5)}), heff_dup(v_bsp_24313)});
        V v_t_24353 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EString, TAG_PiAnon, 1, (V[]){v_t_24352}), heff_dup(v_rhs_241)});
        V v_t_24356;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24355 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24356 = v_s_24355;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24357 = ({ V rv_1 = heff_get_n(v_t_24356, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24353, v_t_24357});
      }
      case TAG_EBinary: {
        V v_ru_24x111_24314_24EBinary = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24359 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str6)}), heff_dup(v_bsp_24313)});
        V v_t_24360 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EBinary, TAG_PiAnon, 1, (V[]){v_t_24359}), heff_dup(v_rhs_241)});
        V v_t_24363;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24362 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24363 = v_s_24362;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24364 = ({ V rv_1 = heff_get_n(v_t_24363, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24360, v_t_24364});
      }
      case TAG_ERune: {
        V v_ru_24x111_24314_24ERune = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24366 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str7)}), heff_dup(v_bsp_24313)});
        V v_t_24367 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24ERune, TAG_PiAnon, 1, (V[]){v_t_24366}), heff_dup(v_rhs_241)});
        V v_t_24370;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24369 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24370 = v_s_24369;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24371 = ({ V rv_1 = heff_get_n(v_t_24370, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24367, v_t_24371});
      }
      case TAG_EWord: {
        V v_ru_24x111_24314_24EWord = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24373 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str8)}), heff_dup(v_bsp_24313)});
        V v_t_24374 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EWord, TAG_PiAnon, 1, (V[]){v_t_24373}), heff_dup(v_rhs_241)});
        V v_t_24377;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24376 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24377 = v_s_24376;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24378 = ({ V rv_1 = heff_get_n(v_t_24377, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24374, v_t_24378});
      }
      case TAG_EApp: {
        V v_ru_24x111_24314_24EApp = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24381 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str9)}), heff_dup(v_bsp_24313)});
        V v_t_24382 = heff_tag_at_n(v_ru_24x111_24314_24EApp, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24381}), heff_dup(v_rhs_241)});
        V v_t_24385;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24384 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24385 = v_s_24384;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24386 = ({ V rv_1 = heff_get_n(v_t_24385, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24382, v_t_24386});
      }
      case TAG_EProject: {
        V v_ru_24x111_24314_24EProject = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24388 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str10)}), heff_dup(v_bsp_24313)});
        V v_t_24389 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EProject, TAG_PiAnon, 1, (V[]){v_t_24388}), heff_dup(v_rhs_241)});
        V v_t_24392;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24391 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24392 = v_s_24391;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24393 = ({ V rv_1 = heff_get_n(v_t_24392, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24389, v_t_24393});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24314_24ENamed = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24396 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str11)}), heff_dup(v_bsp_24313)});
        V v_t_24397 = heff_tag_at_n(v_ru_24x111_24314_24ENamed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24396}), heff_dup(v_rhs_241)});
        V v_t_24400;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24399 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24400 = v_s_24399;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24401 = ({ V rv_1 = heff_get_n(v_t_24400, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24397, v_t_24401});
      }
      case TAG_EPi: {
        V v_ru_24x111_24314_24EPi = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24404 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str12)}), heff_dup(v_bsp_24313)});
        V v_t_24405 = heff_tag_at_n(v_ru_24x111_24314_24EPi, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24404}), heff_dup(v_rhs_241)});
        V v_t_24408;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24407 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24408 = v_s_24407;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24409 = ({ V rv_1 = heff_get_n(v_t_24408, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24405, v_t_24409});
      }
      case TAG_ELam: {
        V v_ru_24x111_24314_24ELam = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24412 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str13)}), heff_dup(v_bsp_24313)});
        V v_t_24413 = heff_tag_at_n(v_ru_24x111_24314_24ELam, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24412}), heff_dup(v_rhs_241)});
        V v_t_24416;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24415 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24416 = v_s_24415;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24417 = ({ V rv_1 = heff_get_n(v_t_24416, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24413, v_t_24417});
      }
      case TAG_EAnn: {
        V v_g_24418 = heff_field(v_x111_24314, 0);
        V v_ty_24419 = heff_field(v_x111_24314, 1);
        heff_take_n(v_x111_24314, 3ULL, 2);
        V v_t_24420 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){heff_dup(v_g_24418), heff_dup(v_ty_24419)}), v_sp_24315});
        return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_24418, v_ty_24419, heff_tag_n(TAG_Just, 1, (V[]){v_bsp_24313}), v_dflt_24312, v_t_24420));
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24314, 0ULL, 4);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24425 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str14)}), heff_dup(v_bsp_24313)});
        V v_t_24426 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24425}), heff_dup(v_rhs_241)});
        V v_t_24429;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24428 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24429 = v_s_24428;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24430 = ({ V rv_1 = heff_get_n(v_t_24429, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24426, v_t_24430});
      }
      case TAG_ESig: {
        V v_ru_24x111_24314_24ESig = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24432 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str15)}), heff_dup(v_bsp_24313)});
        V v_t_24433 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24ESig, TAG_PiAnon, 1, (V[]){v_t_24432}), heff_dup(v_rhs_241)});
        V v_t_24436;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24435 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24436 = v_s_24435;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24437 = ({ V rv_1 = heff_get_n(v_t_24436, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24433, v_t_24437});
      }
      case TAG_ESum: {
        V v_ru_24x111_24314_24ESum = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24439 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str16)}), heff_dup(v_bsp_24313)});
        V v_t_24440 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24ESum, TAG_PiAnon, 1, (V[]){v_t_24439}), heff_dup(v_rhs_241)});
        V v_t_24443;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24442 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24443 = v_s_24442;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24444 = ({ V rv_1 = heff_get_n(v_t_24443, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24440, v_t_24444});
      }
      case TAG_EStruct: {
        V v_ru_24x111_24314_24EStruct = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24446 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str17)}), heff_dup(v_bsp_24313)});
        V v_t_24447 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EStruct, TAG_PiAnon, 1, (V[]){v_t_24446}), heff_dup(v_rhs_241)});
        V v_t_24450;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24449 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24450 = v_s_24449;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24451 = ({ V rv_1 = heff_get_n(v_t_24450, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24447, v_t_24451});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24314_24EUpdate = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24454 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str18)}), heff_dup(v_bsp_24313)});
        V v_t_24455 = heff_tag_at_n(v_ru_24x111_24314_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24454}), heff_dup(v_rhs_241)});
        V v_t_24458;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24457 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24458 = v_s_24457;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24459 = ({ V rv_1 = heff_get_n(v_t_24458, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24455, v_t_24459});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24314_24EMatch = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24462 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str19)}), heff_dup(v_bsp_24313)});
        V v_t_24463 = heff_tag_at_n(v_ru_24x111_24314_24EMatch, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24462}), heff_dup(v_rhs_241)});
        V v_t_24466;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24465 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24466 = v_s_24465;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24467 = ({ V rv_1 = heff_get_n(v_t_24466, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24463, v_t_24467});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24314_24ELetIn = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24470 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str20)}), heff_dup(v_bsp_24313)});
        V v_t_24471 = heff_tag_at_n(v_ru_24x111_24314_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24470}), heff_dup(v_rhs_241)});
        V v_t_24474;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24473 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24474 = v_s_24473;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24475 = ({ V rv_1 = heff_get_n(v_t_24474, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24471, v_t_24475});
      }
      case TAG_EDo: {
        V v_ru_24x111_24314_24EDo = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24477 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str21)}), heff_dup(v_bsp_24313)});
        V v_t_24478 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EDo, TAG_PiAnon, 1, (V[]){v_t_24477}), heff_dup(v_rhs_241)});
        V v_t_24481;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24480 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24481 = v_s_24480;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24482 = ({ V rv_1 = heff_get_n(v_t_24481, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24478, v_t_24482});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24314_24ELocal = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24485 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str22)}), heff_dup(v_bsp_24313)});
        V v_t_24486 = heff_tag_at_n(v_ru_24x111_24314_24ELocal, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24485}), heff_dup(v_rhs_241)});
        V v_t_24489;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24488 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24489 = v_s_24488;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24490 = ({ V rv_1 = heff_get_n(v_t_24489, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24486, v_t_24490});
      }
      case TAG_EInvalid: {
        V v_ru_24x111_24314_24EInvalid = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24492 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str23)}), heff_dup(v_bsp_24313)});
        V v_t_24493 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EInvalid, TAG_PiAnon, 1, (V[]){v_t_24492}), heff_dup(v_rhs_241)});
        V v_t_24496;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24495 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24496 = v_s_24495;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24497 = ({ V rv_1 = heff_get_n(v_t_24496, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24493, v_t_24497});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_24314, 0ULL, 3);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24501 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str24)}), heff_dup(v_bsp_24313)});
        V v_t_24502 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24501}), heff_dup(v_rhs_241)});
        V v_t_24505;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24504 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24505 = v_s_24504;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24506 = ({ V rv_1 = heff_get_n(v_t_24505, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24502, v_t_24506});
      }
      case TAG_EWhile: {
        V v_ru_24x111_24314_24EWhile = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24509 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str25)}), heff_dup(v_bsp_24313)});
        V v_t_24510 = heff_tag_at_n(v_ru_24x111_24314_24EWhile, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24509}), heff_dup(v_rhs_241)});
        V v_t_24513;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24512 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24513 = v_s_24512;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24514 = ({ V rv_1 = heff_get_n(v_t_24513, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24510, v_t_24514});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_24314, 0ULL, 3);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24518 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str26)}), heff_dup(v_bsp_24313)});
        V v_t_24519 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24518}), heff_dup(v_rhs_241)});
        V v_t_24522;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24521 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24522 = v_s_24521;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24523 = ({ V rv_1 = heff_get_n(v_t_24522, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24519, v_t_24523});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_24314_24EIfThen = heff_take_reuse_n(v_x111_24314, 0ULL, 2);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24526 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str27)}), heff_dup(v_bsp_24313)});
        V v_t_24527 = heff_tag_at_n(v_ru_24x111_24314_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24526}), heff_dup(v_rhs_241)});
        V v_t_24530;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24529 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24530 = v_s_24529;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24531 = ({ V rv_1 = heff_get_n(v_t_24530, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24527, v_t_24531});
      }
      case TAG_EBreak: {
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24532 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str28)}), heff_dup(v_bsp_24313)});
        V v_t_24533 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24532}), heff_dup(v_rhs_241)});
        V v_t_24536;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24535 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24536 = v_s_24535;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24537 = ({ V rv_1 = heff_get_n(v_t_24536, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24533, v_t_24537});
      }
      case TAG_EContinue: {
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24538 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str29)}), heff_dup(v_bsp_24313)});
        V v_t_24539 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24538}), heff_dup(v_rhs_241)});
        V v_t_24542;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24541 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24542 = v_s_24541;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24543 = ({ V rv_1 = heff_get_n(v_t_24542, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24539, v_t_24543});
      }
      case TAG_EReturn: {
        V v_ru_24x111_24314_24EReturn = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24545 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str30)}), heff_dup(v_bsp_24313)});
        V v_t_24546 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24EReturn, TAG_PiAnon, 1, (V[]){v_t_24545}), heff_dup(v_rhs_241)});
        V v_t_24549;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24548 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24549 = v_s_24548;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24550 = ({ V rv_1 = heff_get_n(v_t_24549, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24546, v_t_24550});
      }
      case TAG_ENest: {
        V v_ru_24x111_24314_24ENest = heff_take_reuse_n(v_x111_24314, 0ULL, 1);
        heff_drop(v_dflt_24312);
        heff_drop(v_sp_24315);
        V v_t_24552 = heff_tag_at_n(v_ru_24x11_24311_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str31)}), heff_dup(v_bsp_24313)});
        V v_t_24553 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24314_24ENest, TAG_PiAnon, 1, (V[]){v_t_24552}), heff_dup(v_rhs_241)});
        V v_t_24556;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24555 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24556 = v_s_24555;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24557 = ({ V rv_1 = heff_get_n(v_t_24556, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24313, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24553, v_t_24557});
      }
      default: return heff_nomatch(v_x111_24314);
      }
    }
    default: return heff_nomatch(v_x11_24311);
    }
  }
  case TAG_Bracketed: {
    V v_x11_24558 = heff_field(v_x1_240, 0);
    V v_bsp_24559 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Bracketed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24558)) {
    case TAG_At: {
      V v_x111_24560 = heff_field(v_x11_24558, 0);
      V v_ru_24x11_24558_24At = heff_take_reuse_n(v_x11_24558, 1ULL, 2);
      switch (heff_tag_of(v_x111_24560)) {
      case TAG_EVar: {
        V v_ru_24x111_24560_24EVar = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24563 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str32)}), heff_dup(v_bsp_24559)});
        V v_t_24564 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EVar, TAG_PiAnon, 1, (V[]){v_t_24563}), heff_dup(v_rhs_241)});
        V v_t_24567;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24566 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24567 = v_s_24566;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24568 = ({ V rv_1 = heff_get_n(v_t_24567, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24564, v_t_24568});
      }
      case TAG_EImplicitVar: {
        V v_ru_24x111_24560_24EImplicitVar = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24570 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str33)}), heff_dup(v_bsp_24559)});
        V v_t_24571 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_t_24570}), heff_dup(v_rhs_241)});
        V v_t_24574;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24573 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24574 = v_s_24573;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24575 = ({ V rv_1 = heff_get_n(v_t_24574, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24571, v_t_24575});
      }
      case TAG_ETag: {
        V v_ru_24x111_24560_24ETag = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24577 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str34)}), heff_dup(v_bsp_24559)});
        V v_t_24578 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24ETag, TAG_PiAnon, 1, (V[]){v_t_24577}), heff_dup(v_rhs_241)});
        V v_t_24581;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24580 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24581 = v_s_24580;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24582 = ({ V rv_1 = heff_get_n(v_t_24581, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24578, v_t_24582});
      }
      case TAG_EInt: {
        V v_ru_24x111_24560_24EInt = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24584 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str35)}), heff_dup(v_bsp_24559)});
        V v_t_24585 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EInt, TAG_PiAnon, 1, (V[]){v_t_24584}), heff_dup(v_rhs_241)});
        V v_t_24588;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24587 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24588 = v_s_24587;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24589 = ({ V rv_1 = heff_get_n(v_t_24588, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24585, v_t_24589});
      }
      case TAG_EFloat: {
        V v_ru_24x111_24560_24EFloat = heff_take_reuse_na(v_x111_24560, 0ULL, 1);
        V v_t_24591 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str36)}), heff_dup(v_bsp_24559)});
        V v_t_24592 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EFloat, TAG_PiAnon, 1, (V[]){v_t_24591}), heff_dup(v_rhs_241)});
        V v_t_24595;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24594 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24595 = v_s_24594;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24596 = ({ V rv_1 = heff_get_n(v_t_24595, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24592, v_t_24596});
      }
      case TAG_EString: {
        V v_ru_24x111_24560_24EString = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24598 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str37)}), heff_dup(v_bsp_24559)});
        V v_t_24599 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EString, TAG_PiAnon, 1, (V[]){v_t_24598}), heff_dup(v_rhs_241)});
        V v_t_24602;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24601 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24602 = v_s_24601;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24603 = ({ V rv_1 = heff_get_n(v_t_24602, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24599, v_t_24603});
      }
      case TAG_EBinary: {
        V v_ru_24x111_24560_24EBinary = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24605 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str38)}), heff_dup(v_bsp_24559)});
        V v_t_24606 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EBinary, TAG_PiAnon, 1, (V[]){v_t_24605}), heff_dup(v_rhs_241)});
        V v_t_24609;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24608 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24609 = v_s_24608;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24610 = ({ V rv_1 = heff_get_n(v_t_24609, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24606, v_t_24610});
      }
      case TAG_ERune: {
        V v_ru_24x111_24560_24ERune = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24612 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str39)}), heff_dup(v_bsp_24559)});
        V v_t_24613 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24ERune, TAG_PiAnon, 1, (V[]){v_t_24612}), heff_dup(v_rhs_241)});
        V v_t_24616;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24615 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24616 = v_s_24615;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24617 = ({ V rv_1 = heff_get_n(v_t_24616, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24613, v_t_24617});
      }
      case TAG_EWord: {
        V v_ru_24x111_24560_24EWord = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24619 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str40)}), heff_dup(v_bsp_24559)});
        V v_t_24620 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EWord, TAG_PiAnon, 1, (V[]){v_t_24619}), heff_dup(v_rhs_241)});
        V v_t_24623;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24622 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24623 = v_s_24622;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24624 = ({ V rv_1 = heff_get_n(v_t_24623, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24620, v_t_24624});
      }
      case TAG_EApp: {
        V v_ru_24x111_24560_24EApp = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24627 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str41)}), heff_dup(v_bsp_24559)});
        V v_t_24628 = heff_tag_at_n(v_ru_24x111_24560_24EApp, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24627}), heff_dup(v_rhs_241)});
        V v_t_24631;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24630 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24631 = v_s_24630;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24632 = ({ V rv_1 = heff_get_n(v_t_24631, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24628, v_t_24632});
      }
      case TAG_EProject: {
        V v_ru_24x111_24560_24EProject = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24634 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str42)}), heff_dup(v_bsp_24559)});
        V v_t_24635 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EProject, TAG_PiAnon, 1, (V[]){v_t_24634}), heff_dup(v_rhs_241)});
        V v_t_24638;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24637 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24638 = v_s_24637;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24639 = ({ V rv_1 = heff_get_n(v_t_24638, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24635, v_t_24639});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24560_24ENamed = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24642 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str43)}), heff_dup(v_bsp_24559)});
        V v_t_24643 = heff_tag_at_n(v_ru_24x111_24560_24ENamed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24642}), heff_dup(v_rhs_241)});
        V v_t_24646;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24645 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24646 = v_s_24645;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24647 = ({ V rv_1 = heff_get_n(v_t_24646, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24643, v_t_24647});
      }
      case TAG_EPi: {
        V v_ru_24x111_24560_24EPi = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24650 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str44)}), heff_dup(v_bsp_24559)});
        V v_t_24651 = heff_tag_at_n(v_ru_24x111_24560_24EPi, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24650}), heff_dup(v_rhs_241)});
        V v_t_24654;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24653 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24654 = v_s_24653;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24655 = ({ V rv_1 = heff_get_n(v_t_24654, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24651, v_t_24655});
      }
      case TAG_ELam: {
        V v_ru_24x111_24560_24ELam = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24658 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str45)}), heff_dup(v_bsp_24559)});
        V v_t_24659 = heff_tag_at_n(v_ru_24x111_24560_24ELam, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24658}), heff_dup(v_rhs_241)});
        V v_t_24662;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24661 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24662 = v_s_24661;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24663 = ({ V rv_1 = heff_get_n(v_t_24662, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24659, v_t_24663});
      }
      case TAG_EAnn: {
        V v_x1111_24664 = heff_field(v_x111_24560, 0);
        V v_t_24665 = heff_field(v_x111_24560, 1);
        V v_ru_24x111_24560_24EAnn = heff_take_reuse_n(v_x111_24560, 3ULL, 2);
        switch (heff_tag_of(v_x1111_24664)) {
        case TAG_At: {
          V v_x11111_24666 = heff_field(v_x1111_24664, 0);
          V v_xsp_24667 = heff_field(v_x1111_24664, 1);
          heff_take_n(v_x1111_24664, 3ULL, 2);
          switch (heff_tag_of(v_x11111_24666)) {
          case TAG_EVar: {
            V v_x_24668 = heff_field(v_x11111_24666, 0);
            heff_take_n(v_x11111_24666, 1ULL, 1);
            heff_drop_cell(v_ru_24x111_24560_24EAnn, 2);
            V v_t_24669 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiInstance, 4, (V[]){v_x_24668, v_xsp_24667, heff_dup(v_bsp_24559), v_t_24665}), heff_dup(v_rhs_241)});
            V v_t_24672;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24671 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24672 = v_s_24671;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24673 = ({ V rv_1 = heff_get_n(v_t_24672, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24669, v_t_24673});
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24675 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str46)}), heff_dup(v_bsp_24559)});
            V v_t_24676 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24675}), heff_dup(v_rhs_241)});
            V v_t_24679;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24678 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24679 = v_s_24678;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24680 = ({ V rv_1 = heff_get_n(v_t_24679, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24676, v_t_24680});
          }
          case TAG_ETag: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24682 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str47)}), heff_dup(v_bsp_24559)});
            V v_t_24683 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24682}), heff_dup(v_rhs_241)});
            V v_t_24686;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24685 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24686 = v_s_24685;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24687 = ({ V rv_1 = heff_get_n(v_t_24686, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24683, v_t_24687});
          }
          case TAG_EInt: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24689 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str48)}), heff_dup(v_bsp_24559)});
            V v_t_24690 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24689}), heff_dup(v_rhs_241)});
            V v_t_24693;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24692 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24693 = v_s_24692;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24694 = ({ V rv_1 = heff_get_n(v_t_24693, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24690, v_t_24694});
          }
          case TAG_EFloat: {
            heff_take_na(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24696 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str49)}), heff_dup(v_bsp_24559)});
            V v_t_24697 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24696}), heff_dup(v_rhs_241)});
            V v_t_24700;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24699 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24700 = v_s_24699;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24701 = ({ V rv_1 = heff_get_n(v_t_24700, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24697, v_t_24701});
          }
          case TAG_EString: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24703 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str50)}), heff_dup(v_bsp_24559)});
            V v_t_24704 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24703}), heff_dup(v_rhs_241)});
            V v_t_24707;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24706 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24707 = v_s_24706;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24708 = ({ V rv_1 = heff_get_n(v_t_24707, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24704, v_t_24708});
          }
          case TAG_EBinary: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24710 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str51)}), heff_dup(v_bsp_24559)});
            V v_t_24711 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24710}), heff_dup(v_rhs_241)});
            V v_t_24714;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24713 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24714 = v_s_24713;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24715 = ({ V rv_1 = heff_get_n(v_t_24714, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24711, v_t_24715});
          }
          case TAG_ERune: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24717 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str52)}), heff_dup(v_bsp_24559)});
            V v_t_24718 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24717}), heff_dup(v_rhs_241)});
            V v_t_24721;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24720 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24721 = v_s_24720;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24722 = ({ V rv_1 = heff_get_n(v_t_24721, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24718, v_t_24722});
          }
          case TAG_EWord: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24724 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str53)}), heff_dup(v_bsp_24559)});
            V v_t_24725 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24724}), heff_dup(v_rhs_241)});
            V v_t_24728;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24727 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24728 = v_s_24727;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24729 = ({ V rv_1 = heff_get_n(v_t_24728, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24725, v_t_24729});
          }
          case TAG_EApp: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24732 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str54)}), heff_dup(v_bsp_24559)});
            V v_t_24733 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24732}), heff_dup(v_rhs_241)});
            V v_t_24736;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24735 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24736 = v_s_24735;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24737 = ({ V rv_1 = heff_get_n(v_t_24736, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24733, v_t_24737});
          }
          case TAG_EProject: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24739 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str55)}), heff_dup(v_bsp_24559)});
            V v_t_24740 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24739}), heff_dup(v_rhs_241)});
            V v_t_24743;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24742 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24743 = v_s_24742;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24744 = ({ V rv_1 = heff_get_n(v_t_24743, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24740, v_t_24744});
          }
          case TAG_ENamed: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24747 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str56)}), heff_dup(v_bsp_24559)});
            V v_t_24748 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24747}), heff_dup(v_rhs_241)});
            V v_t_24751;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24750 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24751 = v_s_24750;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24752 = ({ V rv_1 = heff_get_n(v_t_24751, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24748, v_t_24752});
          }
          case TAG_EPi: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24755 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str57)}), heff_dup(v_bsp_24559)});
            V v_t_24756 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24755}), heff_dup(v_rhs_241)});
            V v_t_24759;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24758 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24759 = v_s_24758;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24760 = ({ V rv_1 = heff_get_n(v_t_24759, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24756, v_t_24760});
          }
          case TAG_ELam: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24763 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str58)}), heff_dup(v_bsp_24559)});
            V v_t_24764 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24763}), heff_dup(v_rhs_241)});
            V v_t_24767;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24766 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24767 = v_s_24766;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24768 = ({ V rv_1 = heff_get_n(v_t_24767, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24764, v_t_24768});
          }
          case TAG_EAnn: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24771 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str59)}), heff_dup(v_bsp_24559)});
            V v_t_24772 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24771}), heff_dup(v_rhs_241)});
            V v_t_24775;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24774 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24775 = v_s_24774;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24776 = ({ V rv_1 = heff_get_n(v_t_24775, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24772, v_t_24776});
          }
          case TAG_ESpec: {
            heff_take_n(v_x11111_24666, 0ULL, 4);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24781 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str60)}), heff_dup(v_bsp_24559)});
            V v_t_24782 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24781}), heff_dup(v_rhs_241)});
            V v_t_24785;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24784 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24785 = v_s_24784;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24786 = ({ V rv_1 = heff_get_n(v_t_24785, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24782, v_t_24786});
          }
          case TAG_ESig: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24788 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str61)}), heff_dup(v_bsp_24559)});
            V v_t_24789 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24788}), heff_dup(v_rhs_241)});
            V v_t_24792;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24791 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24792 = v_s_24791;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24793 = ({ V rv_1 = heff_get_n(v_t_24792, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24789, v_t_24793});
          }
          case TAG_ESum: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24795 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str62)}), heff_dup(v_bsp_24559)});
            V v_t_24796 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24795}), heff_dup(v_rhs_241)});
            V v_t_24799;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24798 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24799 = v_s_24798;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24800 = ({ V rv_1 = heff_get_n(v_t_24799, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24796, v_t_24800});
          }
          case TAG_EStruct: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24802 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str63)}), heff_dup(v_bsp_24559)});
            V v_t_24803 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24802}), heff_dup(v_rhs_241)});
            V v_t_24806;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24805 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24806 = v_s_24805;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24807 = ({ V rv_1 = heff_get_n(v_t_24806, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24803, v_t_24807});
          }
          case TAG_EUpdate: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24810 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str64)}), heff_dup(v_bsp_24559)});
            V v_t_24811 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24810}), heff_dup(v_rhs_241)});
            V v_t_24814;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24813 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24814 = v_s_24813;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24815 = ({ V rv_1 = heff_get_n(v_t_24814, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24811, v_t_24815});
          }
          case TAG_EMatch: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24818 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str65)}), heff_dup(v_bsp_24559)});
            V v_t_24819 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24818}), heff_dup(v_rhs_241)});
            V v_t_24822;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24821 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24822 = v_s_24821;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24823 = ({ V rv_1 = heff_get_n(v_t_24822, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24819, v_t_24823});
          }
          case TAG_ELetIn: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24826 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str66)}), heff_dup(v_bsp_24559)});
            V v_t_24827 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24826}), heff_dup(v_rhs_241)});
            V v_t_24830;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24829 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24830 = v_s_24829;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24831 = ({ V rv_1 = heff_get_n(v_t_24830, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24827, v_t_24831});
          }
          case TAG_EDo: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24833 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str67)}), heff_dup(v_bsp_24559)});
            V v_t_24834 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24833}), heff_dup(v_rhs_241)});
            V v_t_24837;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24836 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24837 = v_s_24836;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24838 = ({ V rv_1 = heff_get_n(v_t_24837, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24834, v_t_24838});
          }
          case TAG_ELocal: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24841 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str68)}), heff_dup(v_bsp_24559)});
            V v_t_24842 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24841}), heff_dup(v_rhs_241)});
            V v_t_24845;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24844 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24845 = v_s_24844;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24846 = ({ V rv_1 = heff_get_n(v_t_24845, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24842, v_t_24846});
          }
          case TAG_EInvalid: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24848 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str69)}), heff_dup(v_bsp_24559)});
            V v_t_24849 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24848}), heff_dup(v_rhs_241)});
            V v_t_24852;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24851 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24852 = v_s_24851;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24853 = ({ V rv_1 = heff_get_n(v_t_24852, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24849, v_t_24853});
          }
          case TAG_EAssign: {
            heff_take_n(v_x11111_24666, 0ULL, 3);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24857 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str70)}), heff_dup(v_bsp_24559)});
            V v_t_24858 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24857}), heff_dup(v_rhs_241)});
            V v_t_24861;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24860 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24861 = v_s_24860;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24862 = ({ V rv_1 = heff_get_n(v_t_24861, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24858, v_t_24862});
          }
          case TAG_EWhile: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24865 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str71)}), heff_dup(v_bsp_24559)});
            V v_t_24866 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24865}), heff_dup(v_rhs_241)});
            V v_t_24869;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24868 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24869 = v_s_24868;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24870 = ({ V rv_1 = heff_get_n(v_t_24869, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24866, v_t_24870});
          }
          case TAG_EFor: {
            heff_take_n(v_x11111_24666, 0ULL, 3);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24874 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str72)}), heff_dup(v_bsp_24559)});
            V v_t_24875 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24874}), heff_dup(v_rhs_241)});
            V v_t_24878;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24877 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24878 = v_s_24877;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24879 = ({ V rv_1 = heff_get_n(v_t_24878, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24875, v_t_24879});
          }
          case TAG_EIfThen: {
            heff_take_n(v_x11111_24666, 0ULL, 2);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24882 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str73)}), heff_dup(v_bsp_24559)});
            V v_t_24883 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24882}), heff_dup(v_rhs_241)});
            V v_t_24886;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24885 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24886 = v_s_24885;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24887 = ({ V rv_1 = heff_get_n(v_t_24886, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24883, v_t_24887});
          }
          case TAG_EBreak: {
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24888 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str74)}), heff_dup(v_bsp_24559)});
            V v_t_24889 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24888}), heff_dup(v_rhs_241)});
            V v_t_24892;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24891 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24892 = v_s_24891;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24893 = ({ V rv_1 = heff_get_n(v_t_24892, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24889, v_t_24893});
          }
          case TAG_EContinue: {
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24894 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str75)}), heff_dup(v_bsp_24559)});
            V v_t_24895 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24894}), heff_dup(v_rhs_241)});
            V v_t_24898;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24897 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24898 = v_s_24897;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24899 = ({ V rv_1 = heff_get_n(v_t_24898, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24895, v_t_24899});
          }
          case TAG_EReturn: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24901 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str76)}), heff_dup(v_bsp_24559)});
            V v_t_24902 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24901}), heff_dup(v_rhs_241)});
            V v_t_24905;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24904 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24905 = v_s_24904;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24906 = ({ V rv_1 = heff_get_n(v_t_24905, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24902, v_t_24906});
          }
          case TAG_ENest: {
            heff_take_n(v_x11111_24666, 0ULL, 1);
            heff_drop(v_t_24665);
            heff_drop(v_xsp_24667);
            V v_t_24908 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str77)}), heff_dup(v_bsp_24559)});
            V v_t_24909 = heff_tag_at_n(v_ru_24x111_24560_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24908}), heff_dup(v_rhs_241)});
            V v_t_24912;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24911 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24912 = v_s_24911;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24913 = ({ V rv_1 = heff_get_n(v_t_24912, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24909, v_t_24913});
          }
          default: return heff_nomatch(v_x11111_24666);
          }
        }
        default: return heff_nomatch(v_x1111_24664);
        }
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24560, 0ULL, 4);
        V v_t_24918 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str78)}), heff_dup(v_bsp_24559)});
        V v_t_24919 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24918}), heff_dup(v_rhs_241)});
        V v_t_24922;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24921 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24922 = v_s_24921;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24923 = ({ V rv_1 = heff_get_n(v_t_24922, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24919, v_t_24923});
      }
      case TAG_ESig: {
        V v_ru_24x111_24560_24ESig = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24925 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str79)}), heff_dup(v_bsp_24559)});
        V v_t_24926 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24ESig, TAG_PiAnon, 1, (V[]){v_t_24925}), heff_dup(v_rhs_241)});
        V v_t_24929;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24928 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24929 = v_s_24928;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24930 = ({ V rv_1 = heff_get_n(v_t_24929, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24926, v_t_24930});
      }
      case TAG_ESum: {
        V v_ru_24x111_24560_24ESum = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24932 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str80)}), heff_dup(v_bsp_24559)});
        V v_t_24933 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24ESum, TAG_PiAnon, 1, (V[]){v_t_24932}), heff_dup(v_rhs_241)});
        V v_t_24936;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24935 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24936 = v_s_24935;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24937 = ({ V rv_1 = heff_get_n(v_t_24936, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24933, v_t_24937});
      }
      case TAG_EStruct: {
        V v_ru_24x111_24560_24EStruct = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24939 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str81)}), heff_dup(v_bsp_24559)});
        V v_t_24940 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EStruct, TAG_PiAnon, 1, (V[]){v_t_24939}), heff_dup(v_rhs_241)});
        V v_t_24943;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24942 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24943 = v_s_24942;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24944 = ({ V rv_1 = heff_get_n(v_t_24943, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24940, v_t_24944});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24560_24EUpdate = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24947 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str82)}), heff_dup(v_bsp_24559)});
        V v_t_24948 = heff_tag_at_n(v_ru_24x111_24560_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24947}), heff_dup(v_rhs_241)});
        V v_t_24951;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24950 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24951 = v_s_24950;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24952 = ({ V rv_1 = heff_get_n(v_t_24951, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24948, v_t_24952});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24560_24EMatch = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24955 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str83)}), heff_dup(v_bsp_24559)});
        V v_t_24956 = heff_tag_at_n(v_ru_24x111_24560_24EMatch, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24955}), heff_dup(v_rhs_241)});
        V v_t_24959;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24958 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24959 = v_s_24958;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24960 = ({ V rv_1 = heff_get_n(v_t_24959, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24956, v_t_24960});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24560_24ELetIn = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24963 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str84)}), heff_dup(v_bsp_24559)});
        V v_t_24964 = heff_tag_at_n(v_ru_24x111_24560_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24963}), heff_dup(v_rhs_241)});
        V v_t_24967;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24966 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24967 = v_s_24966;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24968 = ({ V rv_1 = heff_get_n(v_t_24967, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24964, v_t_24968});
      }
      case TAG_EDo: {
        V v_ru_24x111_24560_24EDo = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24970 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str85)}), heff_dup(v_bsp_24559)});
        V v_t_24971 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EDo, TAG_PiAnon, 1, (V[]){v_t_24970}), heff_dup(v_rhs_241)});
        V v_t_24974;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24973 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24974 = v_s_24973;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24975 = ({ V rv_1 = heff_get_n(v_t_24974, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24971, v_t_24975});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24560_24ELocal = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_24978 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str86)}), heff_dup(v_bsp_24559)});
        V v_t_24979 = heff_tag_at_n(v_ru_24x111_24560_24ELocal, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24978}), heff_dup(v_rhs_241)});
        V v_t_24982;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24981 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24982 = v_s_24981;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24983 = ({ V rv_1 = heff_get_n(v_t_24982, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24979, v_t_24983});
      }
      case TAG_EInvalid: {
        V v_ru_24x111_24560_24EInvalid = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_24985 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str87)}), heff_dup(v_bsp_24559)});
        V v_t_24986 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EInvalid, TAG_PiAnon, 1, (V[]){v_t_24985}), heff_dup(v_rhs_241)});
        V v_t_24989;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24988 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24989 = v_s_24988;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24990 = ({ V rv_1 = heff_get_n(v_t_24989, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24986, v_t_24990});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_24560, 0ULL, 3);
        V v_t_24994 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str88)}), heff_dup(v_bsp_24559)});
        V v_t_24995 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24994}), heff_dup(v_rhs_241)});
        V v_t_24998;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24997 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24998 = v_s_24997;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24999 = ({ V rv_1 = heff_get_n(v_t_24998, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_24995, v_t_24999});
      }
      case TAG_EWhile: {
        V v_ru_24x111_24560_24EWhile = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_241002 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str89)}), heff_dup(v_bsp_24559)});
        V v_t_241003 = heff_tag_at_n(v_ru_24x111_24560_24EWhile, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241002}), heff_dup(v_rhs_241)});
        V v_t_241006;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241005 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241006 = v_s_241005;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241007 = ({ V rv_1 = heff_get_n(v_t_241006, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_241003, v_t_241007});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_24560, 0ULL, 3);
        V v_t_241011 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str90)}), heff_dup(v_bsp_24559)});
        V v_t_241012 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241011}), heff_dup(v_rhs_241)});
        V v_t_241015;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241014 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241015 = v_s_241014;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241016 = ({ V rv_1 = heff_get_n(v_t_241015, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_241012, v_t_241016});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_24560_24EIfThen = heff_take_reuse_n(v_x111_24560, 0ULL, 2);
        V v_t_241019 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str91)}), heff_dup(v_bsp_24559)});
        V v_t_241020 = heff_tag_at_n(v_ru_24x111_24560_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241019}), heff_dup(v_rhs_241)});
        V v_t_241023;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241022 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241023 = v_s_241022;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241024 = ({ V rv_1 = heff_get_n(v_t_241023, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_241020, v_t_241024});
      }
      case TAG_EBreak: {
        V v_t_241025 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str92)}), heff_dup(v_bsp_24559)});
        V v_t_241026 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241025}), heff_dup(v_rhs_241)});
        V v_t_241029;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241028 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241029 = v_s_241028;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241030 = ({ V rv_1 = heff_get_n(v_t_241029, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_241026, v_t_241030});
      }
      case TAG_EContinue: {
        V v_t_241031 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str93)}), heff_dup(v_bsp_24559)});
        V v_t_241032 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241031}), heff_dup(v_rhs_241)});
        V v_t_241035;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241034 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241035 = v_s_241034;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241036 = ({ V rv_1 = heff_get_n(v_t_241035, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_241032, v_t_241036});
      }
      case TAG_EReturn: {
        V v_ru_24x111_24560_24EReturn = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_241038 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str94)}), heff_dup(v_bsp_24559)});
        V v_t_241039 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24EReturn, TAG_PiAnon, 1, (V[]){v_t_241038}), heff_dup(v_rhs_241)});
        V v_t_241042;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241041 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241042 = v_s_241041;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241043 = ({ V rv_1 = heff_get_n(v_t_241042, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_241039, v_t_241043});
      }
      case TAG_ENest: {
        V v_ru_24x111_24560_24ENest = heff_take_reuse_n(v_x111_24560, 0ULL, 1);
        V v_t_241045 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str95)}), heff_dup(v_bsp_24559)});
        V v_t_241046 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24560_24ENest, TAG_PiAnon, 1, (V[]){v_t_241045}), heff_dup(v_rhs_241)});
        V v_t_241049;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241048 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241049 = v_s_241048;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241050 = ({ V rv_1 = heff_get_n(v_t_241049, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24559, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24558_24At, TAG_At, 2, (V[]){v_t_241046, v_t_241050});
      }
      default: return heff_nomatch(v_x111_24560);
      }
    }
    default: return heff_nomatch(v_x11_24558);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowBinop(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str0, 37, "` does not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str2, 35, "` do not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str3, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str5, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str6, 39, "` are both the loosest: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str8, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str9, 85, "` are not related: add parentheses, or declare which binds tighter (`above`, `below`)");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str11, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str12, 34, "`), or import the module that does");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str13, 1, "`");
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam2, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam5, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam7, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efirstS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efirstS(V v_fix_240, V v_lenient_241, V v_before_242, V v_op_243) {
top: ;
  V v_it_244 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_fix_240), heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1))));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Tighter: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam0_clo);
  }
  case TAG_Looser: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam1_clo);
  }
  case TAG_Same: {
    V v_it1_249 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_AssocLeft: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam2_clo);
    }
    case TAG_AssocRight: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam3_clo);
    }
    case TAG_AssocNone: {
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam4, 1, 2, (V[]){v_before_242, v_op_243});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Unrelated: {
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop(v_fix_240);
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam5_clo);
    } else {
      V v_a_2424 = heff_get_n(v_before_242, 1, 9);
      V v_b_2425 = heff_dup(heff_rfield(v_op_243, 1));
      V v_t_2426 = (g_heff_2esyntax_2efixity_2ebothLoosest(v_fix_240, heff_dup(v_a_2424), heff_dup(v_b_2425)));
      V v_msg_2429;
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str5), heff_strAppend(v_b_2425, ((V)&g_heff_2esyntax_2esurface_2efirstS_str6)));
        v_msg_2429 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str7), heff_strAppend(v_a_2424, v_t_2427));
      } else {
        heff_drop(v_t_2426);
        V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str8), heff_strAppend(v_b_2425, ((V)&g_heff_2esyntax_2esurface_2efirstS_str9)));
        v_msg_2429 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str10), heff_strAppend(v_a_2424, v_t_2428));
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam6, 1, 2, (V[]){v_op_243, v_msg_2429});
    }
  }
  case TAG_Undeclared: {
    V v_x_2433 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      heff_drop(v_x_2433);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam7_clo);
    } else {
      V v_t_2437;
      if (heff_strEq_c(heff_dup(v_x_2433), heff_dup(heff_rfield(v_op_243, 1)))) {
        heff_drop_rec(v_before_242, 9);
        v_t_2437 = v_op_243;
      } else {
        heff_drop_rec(v_op_243, 9);
        v_t_2437 = v_before_242;
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam8, 1, 2, (V[]){v_x_2433, v_t_2437});
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efirstS(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_245});
}
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_247});
}
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args) {
  V v_st_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_st_2410});
}
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args) {
  V v_st_2412 = args[0];
  V v_t_2413 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_st_2412});
}
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args) {
  V v_st_2414 = args[0];
  V v_before_242 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419;
  if (heff_strEq_c(heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1)))) {
    heff_drop_rec(v_before_242, 9);
    V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str0));
    v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str1), v_t_2416);
  } else {
    V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str2));
    V v_t_2418 = heff_strAppend(heff_get_n(v_before_242, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str3), v_t_2417));
    v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str4), v_t_2418);
  }
  V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2419, v_t_2420, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args) {
  V v_st_2422 = args[0];
  V v_t_2423 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_st_2422});
}
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args) {
  V v_st_2430 = args[0];
  V v_op_243 = heff_env(self)[0];
  V v_msg_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2429, v_t_2431, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2432}), v_st_2430});
}
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args) {
  V v_st_2434 = args[0];
  V v_t_2435 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_st_2434});
}
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args) {
  V v_st_2438 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_t_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str11), heff_strAppend(heff_dup(v_x_2433), ((V)&g_heff_2esyntax_2esurface_2efirstS_str12)));
  V v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str13), heff_strAppend(v_x_2433, v_t_2439));
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2437, 3), heff_get_n(v_t_2437, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2440, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2438});
}

HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_f_242 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_242, v_x1_240}});
  }
  case TAG_EParen: {
    V v_f_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_246, v_x1_240}});
  }
  case TAG_Named: {
    V v_f_2412 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2412, v_x1_240}});
  }
  case TAG_Tup: {
    V v_f_2417 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2417, v_x1_240}});
  }
  case TAG_Seg: {
    V v_f_2421 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2421, v_x1_240}});
  }
  case TAG_Braces: {
    V v_f_2426 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2426, v_x1_240}});
  }
  case TAG_Update: {
    V v_f_2433 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2433, v_x1_240}});
  }
  case TAG_EUSet: {
    V v_f_2437 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2437, v_x1_240}});
  }
  case TAG_InstB: {
    V v_f_2443 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2443, v_x1_240}});
  }
  case TAG_EFSet: {
    V v_f_2447 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2447, v_x1_240}});
  }
  case TAG_EFDefault: {
    V v_f_2451 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2451, v_x1_240}});
  }
  case TAG_Sum: {
    V v_f_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2457, v_x1_240}});
  }
  case TAG_ECon: {
    V v_f_2460 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2460, v_x1_240}});
  }
  case TAG_EField: {
    V v_f_2463 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2463, v_x1_240}});
  }
  case TAG_ENeg: {
    V v_f_2466 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2466, v_x1_240}});
  }
  case TAG_App: {
    V v_f_2469 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2469, v_x1_240}});
  }
  case TAG_Op: {
    V v_f_2473 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2473, v_x1_240}});
  }
  case TAG_Ops: {
    V v_f_2476 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2476, v_x1_240}});
  }
  case TAG_OpRhs: {
    V v_op_2477 = heff_field(v_x1_240, 0);
    V v_e_2478 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return ((HeffT2){{v_op_2477, v_e_2478}});
  }
  case TAG_Ann: {
    V v_f_2482 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2482, v_x1_240}});
  }
  case TAG_BVar: {
    V v_f_2484 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2484, v_x1_240}});
  }
  case TAG_BImp: {
    V v_f_2488 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2488, v_x1_240}});
  }
  case TAG_BAnn: {
    V v_f_2494 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2494, v_x1_240}});
  }
  case TAG_Lam: {
    V v_f_2499 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2499, v_x1_240}});
  }
  case TAG_Case: {
    V v_f_24104 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24104, v_x1_240}});
  }
  case TAG_EAlt: {
    V v_f_24108 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24108, v_x1_240}});
  }
  case TAG_If: {
    V v_f_24115 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24115, v_x1_240}});
  }
  case TAG_Do: {
    V v_f_24118 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24118, v_x1_240}});
  }
  case TAG_ESBind: {
    V v_f_24122 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24122, v_x1_240}});
  }
  case TAG_ELet: {
    V v_f_24129 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24129, v_x1_240}});
  }
  case TAG_ELetMut: {
    V v_f_24136 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24136, v_x1_240}});
  }
  case TAG_EAssign: {
    V v_f_24140 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24140, v_x1_240}});
  }
  case TAG_EWhile: {
    V v_f_24145 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24145, v_x1_240}});
  }
  case TAG_EFor: {
    V v_f_24152 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24152, v_x1_240}});
  }
  case TAG_EJump: {
    V v_f_24154 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24154, v_x1_240}});
  }
  case TAG_EReturn: {
    V v_f_24157 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24157, v_x1_240}});
  }
  case TAG_ENest: {
    V v_f_24162 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24162, v_x1_240}});
  }
  case TAG_IfThen: {
    V v_f_24167 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24167, v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0, 2, ":=");

HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 4);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_f_2421 = heff_field(v_x12_2418, 0);
      V v_x122_2422 = heff_field(v_x12_2418, 1);
      heff_take_n(v_x12_2418, 3ULL, 2);
      switch (heff_tag_of(v_x122_2422)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_f_2421)) {
        case TAG_Atom: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EParen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Named: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Tup: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Seg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Braces: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Update: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EUSet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_InstB: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EFSet: {
          heff_take_n(v_f_2421, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFDefault: {
          V v_eq_2461 = heff_dup(heff_field(v_f_2421, 1));
          if (heff_strEq_c(heff_get_n(v_eq_2461, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
          } else {
            heff_drop_tag(v_f_2421, 3);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Sum: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ECon: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EField: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ENeg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_App: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Op: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Ops: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_OpRhs: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Ann: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BVar: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BImp: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BAnn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Lam: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Case: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EAlt: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_If: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Do: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ESBind: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELetMut: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EAssign: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EWhile: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EFor: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EJump: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EReturn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ENest: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_IfThen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        default: return ((HeffT2){{heff_nomatch(v_f_2421)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_x122_2422, 0ULL, 2);
        heff_drop(v_f_2421);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_2422)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 4);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      V v_x121_2421 = heff_dup(heff_field(v_x12_2418, 0));
      switch (heff_tag_of(v_x121_2421)) {
      case TAG_Atom: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EParen: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Named: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Tup: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Seg: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Braces: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Update: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EUSet: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_InstB: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFSet: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x12_2418}});
      }
      case TAG_EFDefault: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Sum: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ECon: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EField: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENeg: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_App: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Op: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Ops: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_OpRhs: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Ann: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_BVar: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_BImp: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_BAnn: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Lam: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Case: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAlt: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_If: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Do: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESBind: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELet: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetMut: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAssign: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWhile: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFor: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EJump: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EReturn: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENest: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_IfThen: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        heff_drop_tag(v_x12_2418, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x121_2421)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0, 64, "a unit is what a size counts: say the size, `x::size(4)-unit(8)`");

HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_s_244, 0));
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_v_243)) {
    case TAG_StrValue: {
      v_t_249 = NTAG(TAG_SegmentBinary);
      break;
    }
    case TAG_IntValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    case TAG_FloatValue: {
      v_t_249 = NTAG(TAG_SegmentFloat);
      break;
    }
    case TAG_RuneValue: {
      v_t_249 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_OtherValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    break;
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_249 = v_t_248;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_249, v_st_245));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_x11_2413 = v_field_2411;
    V v_st_2414 = v_field_2412;
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      V v_e_2415 = heff_field(v_x11_2413, 0);
      V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      heff_drop_rec(v_s_244, 5);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
    }
    case TAG_Right: {
      V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 0ULL, 1);
      V v_t_2417 = heff_dup(heff_rfield(v_s_244, 1));
      V v_t_2428;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_SizeDefault: {
        V v_t_2418 = heff_dup(heff_rfield(v_s_244, 2));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_st_2414});
          break;
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2413_24Right, 1);
          V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0), heff_dup(v_sp_241), NTAG(TAG_Nothing)});
          v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2421}), v_st_2414});
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      case TAG_SizeNumber: {
        heff_take_n(v_t_2417, 0ULL, 1);
        V v_t_2423 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2423, v_st_2414});
        break;
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2417, 0ULL, 3);
        V v_t_2427 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_st_2414});
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      switch (heff_tag_of(v_t_2428)) {
      case TAG_MkPair: {
        V v_x11_2429 = heff_field(v_t_2428, 0);
        V v_st_2430 = heff_field(v_t_2428, 1);
        V v_ru_24t_2428_24MkPair = heff_take_reuse_n(v_t_2428, 3ULL, 2);
        switch (heff_tag_of(v_x11_2429)) {
        case TAG_Left: {
          V v_e_2431 = heff_field(v_x11_2429, 0);
          V v_ru_24x11_2429_24Left = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_rec(v_s_244, 5);
          heff_drop_cell(v_ru_24t_2428_24MkPair, 2);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2429_24Left, TAG_Left, 1, (V[]){v_e_2431}), v_st_2430}});
        }
        case TAG_Right: {
          V v_ru_24x11_2429_24Right = heff_take_reuse_n(v_x11_2429, 0ULL, 1);
          V v_t_2433 = heff_dup(heff_rfield(v_s_244, 0));
          V v_t_2436;
          switch (heff_tag_of(v_t_2433)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_v_243)) {
            case TAG_StrValue: {
              v_t_2436 = NTAG(TAG_SegmentBinary);
              break;
            }
            case TAG_IntValue: {
              v_t_2436 = NTAG(TAG_SegmentInteger);
              break;
            }
            case TAG_FloatValue: {
              v_t_2436 = NTAG(TAG_SegmentFloat);
              break;
            }
            case TAG_RuneValue: {
              v_t_2436 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
              break;
            }
            case TAG_OtherValue: {
              v_t_2436 = NTAG(TAG_SegmentInteger);
              break;
            }
            default: heff_nomatch(v_v_243);
            }
            break;
          }
          case TAG_Just: {
            V v_t_2435 = heff_field(v_t_2433, 0);
            heff_take_n(v_t_2433, 1ULL, 1);
            v_t_2436 = v_t_2435;
            break;
          }
          default: heff_nomatch(v_t_2433);
          }
          V v_t_2437 = heff_dup(heff_rfield(v_s_244, 2));
          V v_unit_2444;
          switch (heff_tag_of(v_t_2437)) {
          case TAG_Nothing: {
            V v_t_2438 = heff_dup(heff_rfield(v_s_244, 0));
            V v_t_2441;
            switch (heff_tag_of(v_t_2438)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_v_243)) {
              case TAG_StrValue: {
                v_t_2441 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                v_t_2441 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                v_t_2441 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2441 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                v_t_2441 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_243);
              }
              break;
            }
            case TAG_Just: {
              V v_t_2440 = heff_field(v_t_2438, 0);
              heff_take_n(v_t_2438, 1ULL, 1);
              v_t_2441 = v_t_2440;
              break;
            }
            default: heff_nomatch(v_t_2438);
            }
            switch (heff_tag_of(v_t_2441)) {
            case TAG_SegmentInteger: {
              v_unit_2444 = MK_INT(1LL);
              break;
            }
            case TAG_SegmentBinary: {
              v_unit_2444 = MK_INT(8LL);
              break;
            }
            case TAG_SegmentBits: {
              v_unit_2444 = MK_INT(1LL);
              break;
            }
            case TAG_SegmentFloat: {
              v_unit_2444 = MK_INT(1LL);
              break;
            }
            case TAG_SegmentUtf: {
              heff_take_n(v_t_2441, 0ULL, 1);
              v_unit_2444 = MK_INT(1LL);
              break;
            }
            default: heff_nomatch(v_t_2441);
            }
            break;
          }
          case TAG_Just: {
            V v_u_2443 = heff_field(v_t_2437, 0);
            heff_take_n(v_t_2437, 1ULL, 1);
            v_unit_2444 = v_u_2443;
            break;
          }
          default: heff_nomatch(v_t_2437);
          }
          V v_t_2445 = heff_dup(heff_rfield(v_s_244, 1));
          V v_t_2450;
          switch (heff_tag_of(v_t_2445)) {
          case TAG_SizeDefault: {
            heff_drop(v_unit_2444);
            v_t_2450 = NTAG(TAG_SizeDefault);
            break;
          }
          case TAG_SizeNumber: {
            V v_n_2446 = heff_field(v_t_2445, 0);
            V v_ru_24t_2445_24SizeNumber = heff_take_reuse_n(v_t_2445, 1ULL, 1);
            v_t_2450 = heff_tag_at_n(v_ru_24t_2445_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2446, v_unit_2444)});
            break;
          }
          case TAG_SizeName: {
            V v_x_2447 = heff_field(v_t_2445, 0);
            V v_xsp_2448 = heff_field(v_t_2445, 1);
            V v_ru_24t_2445_24SizeName = heff_take_reuse_n(v_t_2445, 3ULL, 3);
            v_t_2450 = heff_tag_at_n(v_ru_24t_2445_24SizeName, TAG_SizeName, 3, (V[]){v_x_2447, v_xsp_2448, v_unit_2444});
            break;
          }
          default: heff_nomatch(v_t_2445);
          }
          V v_m_2451 = (g_heff_2esyntax_2esurface_2etypeChecks(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), heff_dup(v_s_244), v_t_2436, v_t_2450));
          V v_x1_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2430}));
          switch (heff_tag_of(v_x1_2452)) {
          case TAG_MkPair: {
            V v_x11_2453 = heff_field(v_x1_2452, 0);
            V v_st_2454 = heff_field(v_x1_2452, 1);
            heff_take_n(v_x1_2452, 3ULL, 2);
            switch (heff_tag_of(v_x11_2453)) {
            case TAG_Left: {
              V v_e_2455 = heff_field(v_x11_2453, 0);
              V v_ru_24x11_2453_24Left = heff_take_reuse_n(v_x11_2453, 1ULL, 1);
              heff_drop(v_sp_241);
              heff_drop(v_e_242);
              heff_drop(v_v_243);
              heff_drop_rec(v_s_244, 5);
              heff_drop_cell(v_ru_24t_2428_24MkPair, 2);
              heff_drop_cell(v_ru_24x11_2429_24Right, 1);
              return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2453_24Left, TAG_Left, 1, (V[]){v_e_2455}), v_st_2454}});
            }
            case TAG_Right: {
              V v_ru_24x11_2453_24Right = heff_take_reuse_n(v_x11_2453, 0ULL, 1);
              V v_t_2457 = heff_dup(heff_rfield(v_s_244, 0));
              V v_t_2460;
              switch (heff_tag_of(v_t_2457)) {
              case TAG_Nothing: {
                switch (heff_tag_of(v_v_243)) {
                case TAG_StrValue: {
                  heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                  v_t_2460 = NTAG(TAG_SegmentBinary);
                  break;
                }
                case TAG_IntValue: {
                  heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                  v_t_2460 = NTAG(TAG_SegmentInteger);
                  break;
                }
                case TAG_FloatValue: {
                  heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                  v_t_2460 = NTAG(TAG_SegmentFloat);
                  break;
                }
                case TAG_RuneValue: {
                  v_t_2460 = heff_tag_at_n(v_ru_24x11_2453_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                  break;
                }
                case TAG_OtherValue: {
                  heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                  v_t_2460 = NTAG(TAG_SegmentInteger);
                  break;
                }
                default: heff_nomatch(v_v_243);
                }
                break;
              }
              case TAG_Just: {
                V v_t_2459 = heff_field(v_t_2457, 0);
                heff_take_n(v_t_2457, 1ULL, 1);
                heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                v_t_2460 = v_t_2459;
                break;
              }
              default: heff_nomatch(v_t_2457);
              }
              V v_t_2461 = heff_take_field(v_s_244, 2);
              V v_unit_2468;
              switch (heff_tag_of(v_t_2461)) {
              case TAG_Nothing: {
                V v_t_2462 = heff_dup(heff_rfield(v_s_244, 0));
                V v_t_2465;
                switch (heff_tag_of(v_t_2462)) {
                case TAG_Nothing: {
                  switch (heff_tag_of(v_v_243)) {
                  case TAG_StrValue: {
                    v_t_2465 = NTAG(TAG_SegmentBinary);
                    break;
                  }
                  case TAG_IntValue: {
                    heff_take_n(v_v_243, 0ULL, 1);
                    v_t_2465 = NTAG(TAG_SegmentInteger);
                    break;
                  }
                  case TAG_FloatValue: {
                    v_t_2465 = NTAG(TAG_SegmentFloat);
                    break;
                  }
                  case TAG_RuneValue: {
                    v_t_2465 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                    break;
                  }
                  case TAG_OtherValue: {
                    v_t_2465 = NTAG(TAG_SegmentInteger);
                    break;
                  }
                  default: heff_nomatch(v_v_243);
                  }
                  break;
                }
                case TAG_Just: {
                  V v_t_2464 = heff_field(v_t_2462, 0);
                  heff_take_n(v_t_2462, 1ULL, 1);
                  heff_drop(v_v_243);
                  v_t_2465 = v_t_2464;
                  break;
                }
                default: heff_nomatch(v_t_2462);
                }
                switch (heff_tag_of(v_t_2465)) {
                case TAG_SegmentInteger: {
                  v_unit_2468 = MK_INT(1LL);
                  break;
                }
                case TAG_SegmentBinary: {
                  v_unit_2468 = MK_INT(8LL);
                  break;
                }
                case TAG_SegmentBits: {
                  v_unit_2468 = MK_INT(1LL);
                  break;
                }
                case TAG_SegmentFloat: {
                  v_unit_2468 = MK_INT(1LL);
                  break;
                }
                case TAG_SegmentUtf: {
                  heff_take_n(v_t_2465, 0ULL, 1);
                  v_unit_2468 = MK_INT(1LL);
                  break;
                }
                default: heff_nomatch(v_t_2465);
                }
                break;
              }
              case TAG_Just: {
                V v_u_2467 = heff_field(v_t_2461, 0);
                heff_take_n(v_t_2461, 1ULL, 1);
                heff_drop(v_v_243);
                v_unit_2468 = v_u_2467;
                break;
              }
              default: heff_nomatch(v_t_2461);
              }
              V v_t_2469 = heff_take_field(v_s_244, 1);
              V v_t_2474;
              switch (heff_tag_of(v_t_2469)) {
              case TAG_SizeDefault: {
                heff_drop(v_unit_2468);
                v_t_2474 = NTAG(TAG_SizeDefault);
                break;
              }
              case TAG_SizeNumber: {
                V v_n_2470 = heff_field(v_t_2469, 0);
                V v_ru_24t_2469_24SizeNumber = heff_take_reuse_n(v_t_2469, 1ULL, 1);
                v_t_2474 = heff_tag_at_n(v_ru_24t_2469_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2470, v_unit_2468)});
                break;
              }
              case TAG_SizeName: {
                V v_x_2471 = heff_field(v_t_2469, 0);
                V v_xsp_2472 = heff_field(v_t_2469, 1);
                V v_ru_24t_2469_24SizeName = heff_take_reuse_n(v_t_2469, 3ULL, 3);
                v_t_2474 = heff_tag_at_n(v_ru_24t_2469_24SizeName, TAG_SizeName, 3, (V[]){v_x_2471, v_xsp_2472, v_unit_2468});
                break;
              }
              default: heff_nomatch(v_t_2469);
              }
              V v_t_2475 = heff_take_field(v_s_244, 3);
              V v_t_2477;
              switch (heff_tag_of(v_t_2475)) {
              case TAG_Nothing: {
                v_t_2477 = NTAG(TAG_False);
                break;
              }
              case TAG_Just: {
                V v_b_2476 = heff_field(v_t_2475, 0);
                heff_take_n(v_t_2475, 1ULL, 1);
                v_t_2477 = v_b_2476;
                break;
              }
              default: heff_nomatch(v_t_2475);
              }
              V v_t_2478 = heff_get_n(v_s_244, 4, 5);
              V v_t_2480;
              switch (heff_tag_of(v_t_2478)) {
              case TAG_Nothing: {
                v_t_2480 = NTAG(TAG_False);
                break;
              }
              case TAG_Just: {
                V v_b_2479 = heff_field(v_t_2478, 0);
                heff_take_n(v_t_2478, 1ULL, 1);
                v_t_2480 = v_b_2479;
                break;
              }
              default: heff_nomatch(v_t_2478);
              }
              V v_t_2481 = heff_tag_at_n(v_ru_24t_2428_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2460, v_t_2474, v_t_2477, v_t_2480}), v_sp_241});
              V v_f_2482 = heff_tag_at_n(v_ru_24x11_2429_24Right, TAG_Right, 1, (V[]){v_t_2481});
              return ((HeffT2){{v_f_2482, v_st_2454}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x11_2453)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x1_2452)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2429)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2428)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2etheoryFieldL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etheoryFieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryFieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etheoryFieldL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkTF: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ty_244 = heff_field(v_x2_241, 2);
    V v_d_245 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 13ULL, 4);
    V v_m_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_244}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2etheoryFieldL_lam0, 1, 4, (V[]){v_m_246, v_r_240, v_d_245, v_x_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etheoryFieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryFieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etheoryFieldL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_245 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_245);
      heff_drop_rec(v_x_242, 9);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = (g_heff_2esyntax_2esurface_2edefaultL(v_r_240, v_d_245));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop_rec(v_x_242, 9);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_242, 3)), heff_take_field(v_x_242, 4)});
          V v_t_2420 = heff_tag_n(TAG_DeclareField, 4, (V[]){heff_dup(heff_rfield(v_x_242, 1)), v_t_2419, heff_dup(v_x_2412), heff_dup(v_x_2418)});
          V v_t_2422;
          switch (heff_tag_of(v_x_2418)) {
          case TAG_Nothing: {
            v_t_2422 = v_x_2412;
            break;
          }
          case TAG_Just: {
            V v_x_2421 = heff_field(v_x_2418, 0);
            heff_take_n(v_x_2418, 1ULL, 1);
            heff_drop(v_x_2412);
            v_t_2422 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_x_2418);
          }
          V v_t_2425;
          switch (heff_tag_of(v_t_2422)) {
          case TAG_At: {
            V v_s_2424 = heff_field(v_t_2422, 1);
            heff_take_n(v_t_2422, 2ULL, 2);
            v_t_2425 = v_s_2424;
            break;
          }
          default: heff_nomatch(v_t_2422);
          }
          V v_t_2426 = ({ V rv_0 = heff_take_field(v_x_242, 3); V rr_ = heff_rec_reuse_nf(v_t_2425, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2427 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2426})});
          V v_t_2428 = heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 9), heff_dup(heff_rfield(v_st_2416, 1))});
          V v_t_2429 = ({ V rv_1 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_st_2416, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2427, v_t_2429});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0, 5, "`: it");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1, 31, "nothing can be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3, 4, "`: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4, 28, "` cannot be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8, 2, " (");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10, 83, " is the loosest operator, below every other, declared `below` with nothing after it");
Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V v_d_240, V v_u_241, V v_g_242) {
top: ;
  V v_t_243 = heff_get_n(v_d_240, 1, 8);
  V v_t_2410;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    V v_t_244 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0));
    v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1), v_t_244);
    break;
  }
  case TAG_Cons: {
    V v_op_245 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2));
    V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_u_241, 1)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3), v_t_247));
    V v_t_249 = heff_strAppend(heff_get_n(v_op_245, 1, 7), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4), v_t_248));
    v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5), v_t_249);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_at_2411 = heff_get_n(v_g_242, 4, 5);
  V v_t_2413;
  if (heff_strEq_c_lent(v_at_2411, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6), 2)) {
    heff_drop(v_at_2411);
    v_t_2413 = ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7);
  } else {
    v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8), heff_strAppend(v_at_2411, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9)));
  }
  V v_msg_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10), v_t_2413));
  V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_u_241, 2), heff_get_n(v_u_241, 3, 7)});
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2414, v_t_2415, NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebelowLoosestDiag(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V v_names_240, V v_pats_241, V v_rhs_242, V v_w_243, V v_st_244) {
top: ;
  V v_t_245 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
  V v_f_246 = heff_get_n(v_t_245, 0, 2);
  HeffT2 v_t_247 = ({ V a_0 = heff_rfield(v_st_244, 3); V a_1 = v_f_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_f_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_t_2412;
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_249;
      v_t_2412 = v_x_2411;
    } else {
      heff_drop(v_field_249);
      v_t_2412 = NTAG(TAG_Nil);
    }
    V v_pv_2413 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2412));
    V v_m_2414 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 1)), heff_dup(v_pats_241)));
    V v_t_2415 = ({ V rv_4 = v_pv_2413; V rr_ = heff_rec_reuse_nf(v_st_244, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_t_2415}));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_MkPair: {
      V v_x11_2417 = heff_field(v_x1_2416, 0);
      V v_st_2418 = heff_field(v_x1_2416, 1);
      heff_take_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x11_2417)) {
      case TAG_Left: {
        V v_e_2419 = heff_field(v_x11_2417, 0);
        V v_ru_24x11_2417_24Left = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
        heff_drop(v_pats_241);
        heff_drop(v_rhs_242);
        heff_drop(v_t_2412);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2417_24Left, TAG_Left, 1, (V[]){v_e_2419}), v_st_2418}});
      }
      case TAG_Right: {
        V v_x_2420 = heff_field(v_x11_2417, 0);
        heff_take_n(v_x11_2417, 1ULL, 1);
        V v_t_2421 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2412));
        V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2421}));
        V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = v_pats_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_241); r_; });
        V v_t_2424 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2412); r_; });
        V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2423, v_t_2424));
        V v_t_2426 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2418, 239ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 64767u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2425, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0, 1, 4, (V[]){v_rhs_242, heff_dup(v_w_243), heff_dup(v_names_240), v_x_2420}), v_t_2426));
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2417)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2416)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args) {
  V v_st_2427 = args[0];
  V v_rhs_242 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_names_240 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2428 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_rhs_242, v_st_2427));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_MkPair: {
    V v_x11_2429 = heff_field(v_x1_2428, 0);
    V v_st_2430 = heff_field(v_x1_2428, 1);
    V v_ru_24x1_2428_24MkPair = heff_take_reuse_n(v_x1_2428, 3ULL, 2);
    switch (heff_tag_of(v_x11_2429)) {
    case TAG_Left: {
      V v_e_2431 = heff_field(v_x11_2429, 0);
      heff_take_n(v_x11_2429, 1ULL, 1);
      heff_drop(v_w_243);
      heff_drop(v_names_240);
      heff_drop(v_x_2420);
      return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2431}), v_st_2430});
    }
    case TAG_Right: {
      V v_x_2432 = heff_field(v_x11_2429, 0);
      V v_ru_24x11_2429_24Right = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
      V v_x1_2436;
      switch (heff_tag_of(v_w_243)) {
      case TAG_Nothing: {
        v_x1_2436 = heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2432}), v_st_2430});
        break;
      }
      case TAG_Just: {
        V v_it1_2433 = heff_field(v_w_243, 0);
        heff_take_n(v_w_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x1_2428_24MkPair, 2);
        switch (heff_tag_of(v_it1_2433)) {
        case TAG_MkPair: {
          V v_kw_2434 = heff_field(v_it1_2433, 0);
          V v_ds_2435 = heff_field(v_it1_2433, 1);
          heff_take_n(v_it1_2433, 3ULL, 2);
          v_x1_2436 = (g_heff_2esyntax_2esurface_2ewhereL_24s708392557x194554207(v_kw_2434, v_ds_2435, v_x_2432, v_st_2430));
          break;
        }
        default: heff_nomatch(v_it1_2433);
        }
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      switch (heff_tag_of(v_x1_2436)) {
      case TAG_MkPair: {
        V v_x11_2437 = heff_field(v_x1_2436, 0);
        V v_st_2438 = heff_field(v_x1_2436, 1);
        V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
        switch (heff_tag_of(v_x11_2437)) {
        case TAG_Left: {
          V v_e_2439 = heff_field(v_x11_2437, 0);
          heff_take_n(v_x11_2437, 1ULL, 1);
          heff_drop(v_names_240);
          heff_drop(v_x_2420);
          heff_drop_cell(v_ru_24x11_2429_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
        }
        case TAG_Right: {
          V v_x_2440 = heff_field(v_x11_2437, 0);
          heff_take_n(v_x11_2437, 1ULL, 1);
          V v_t_2441 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2442 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2443 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_240));
          V v_t_2444 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2442, 0, 2), heff_get_n(v_t_2443, 1, 2), v_x_2420, heff_dup(v_x_2440)});
          V v_t_2447;
          switch (heff_tag_of(v_names_240)) {
          case TAG_Nil: {
            v_t_2447 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2445 = heff_dup(heff_field(v_names_240, 0));
            v_t_2447 = heff_get_n(v_t_2445, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_240);
          }
          V v_t_2450;
          switch (heff_tag_of(v_x_2440)) {
          case TAG_At: {
            V v_s_2449 = heff_dup(heff_field(v_x_2440, 1));
            v_t_2450 = v_s_2449;
            break;
          }
          default: heff_nomatch(v_x_2440);
          }
          V v_t_2451 = ({ V rv_0 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_t_2450, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2454;
          switch (heff_tag_of(v_names_240)) {
          case TAG_Nil: {
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_Cons: {
            V v_t_2452 = heff_field(v_names_240, 0);
            heff_take_n(v_names_240, 1ULL, 2);
            v_t_2454 = heff_get_n(v_t_2452, 3, 9);
            break;
          }
          default: heff_nomatch(v_names_240);
          }
          V v_t_2457;
          switch (heff_tag_of(v_x_2440)) {
          case TAG_At: {
            V v_s_2456 = heff_field(v_x_2440, 1);
            heff_take_n(v_x_2440, 2ULL, 2);
            v_t_2457 = v_s_2456;
            break;
          }
          default: heff_nomatch(v_x_2440);
          }
          V v_t_2458 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_t_2457, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2459 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2441, 0, 2), heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_t_2451}), v_t_2458});
          V v_x_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2429_24Right, TAG_Right, 1, (V[]){v_x_2460}), v_st_2438});
        }
        default: return heff_nomatch(v_x11_2437);
        }
      }
      default: return heff_nomatch(v_x1_2436);
      }
    }
    default: return heff_nomatch(v_x11_2429);
    }
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1, 1, "(");
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(heff_dup(v_e_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_f_245 = v_field_243;
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0, 1, 2, (V[]){v_f_245, v_e_240});
    } else {
      heff_drop(v_field_243);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1, 1, 1, (V[]){v_e_240});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_f_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(v_f_245, v_st_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      HeffT2 v_t_2414 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(heff_dup(v_x_2413)));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop(v_x_2413);
          V v_q_2418 = v_field_2416;
          V v_t_2419 = heff_tag_n(TAG_ImplicitParam, 3, (V[]){heff_take_field(v_q_2418, 0), heff_take_field(v_q_2418, 1), heff_get_n(v_q_2418, 2, 3)});
          V v_a_2420 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
          V v_b_2421 = (g_heff_2esyntax_2ecst_2elastE(v_e_240));
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2420, 3, 9), heff_get_n(v_b_2421, 4, 9)});
          V v_x_2423 = heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_t_2422});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){v_x_2423}), v_st_2411});
        } else {
          heff_drop(v_e_240);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          heff_drop(v_field_2416);
          V v_t_2426;
          switch (heff_tag_of(v_x_2413)) {
          case TAG_At: {
            V v_s_2425 = heff_field(v_x_2413, 1);
            heff_take_n(v_x_2413, 2ULL, 2);
            v_t_2426 = v_s_2425;
            break;
          }
          default: heff_nomatch(v_x_2413);
          }
          V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0), v_t_2426, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2427}), v_st_2411});
        }
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args) {
  V v_st_2437 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2433}), v_st_2437});
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args) {
  V v_st_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_240), v_st_2428));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_t_2434 = ({ V a_0 = v_e_240; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_240); r_; });
      V v_m_2438;
      if (heff_strEq_c(heff_get_n(v_t_2434, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1))) {
        V v_t_2436 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2433));
        v_m_2438 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2436}));
      } else {
        v_m_2438 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2, 1, 1, (V[]){v_x_2433});
      }
      V v_x1_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_st_2431}));
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_MkPair: {
        V v_x11_2440 = heff_field(v_x1_2439, 0);
        V v_st_2441 = heff_field(v_x1_2439, 1);
        heff_take_n(v_x1_2439, 3ULL, 2);
        switch (heff_tag_of(v_x11_2440)) {
        case TAG_Left: {
          V v_e_2442 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
        }
        case TAG_Right: {
          V v_x_2443 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          heff_drop_cell(v_ru_24x1_2429_24MkPair, 2);
          return (g_heff_2esyntax_2esurface_2eparamOf(v_x_2443, v_st_2441));
        }
        default: return heff_nomatch(v_x11_2440);
        }
      }
      default: return heff_nomatch(v_x1_2439);
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(heff_dup(v_e_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      heff_drop(v_e_240);
      V v_x_245 = v_field_243;
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0, 1, 1, (V[]){v_x_245});
    } else {
      heff_drop(v_field_243);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(v_e_240);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_245, 3)), heff_dup(heff_rfield(v_x_245, 4))});
  V v_t_248 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_245, 3)), heff_dup(heff_rfield(v_x_245, 4))});
  V v_t_2410 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_x_245, 1), v_t_247, heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_t_249})});
  V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
  V v_t_2412 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2411})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_st_246});
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Atom: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EParen: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Named: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Tup: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Seg: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Braces: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Update: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EUSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7, 1, 1, (V[]){v_x2_240});
  }
  case TAG_InstB: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFDefault: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Sum: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ECon: {
    V v_c_24130 = heff_field(v_x2_240, 0);
    V v_args_24131 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24132 = (g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(v_c_24130, v_args_24131));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12, 1, 1, (V[]){v_m_24132});
  }
  case TAG_EField: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ENeg: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_App: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Op: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Ops: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_OpRhs: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Ann: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BVar: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BImp: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BAnn: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Lam: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Case: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAlt: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25, 1, 1, (V[]){v_x2_240});
  }
  case TAG_If: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Do: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ESBind: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELetMut: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAssign: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EWhile: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFor: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EJump: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EReturn: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ENest: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36, 1, 1, (V[]){v_x2_240});
  }
  case TAG_IfThen: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37, 1, 1, (V[]){v_x2_240});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(a[0]);
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      V v_x_248 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_247));
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_248}), v_st_245});
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      V v_x_2418 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2417));
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2418}), v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args) {
  V v_st_2424 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2424));
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_MkPair: {
    V v_x11_2426 = heff_field(v_x1_2425, 0);
    V v_st_2427 = heff_field(v_x1_2425, 1);
    V v_ru_24x1_2425_24MkPair = heff_take_reuse_n(v_x1_2425, 3ULL, 2);
    switch (heff_tag_of(v_x11_2426)) {
    case TAG_Left: {
      V v_e_2428 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2428}), v_st_2427});
    }
    case TAG_Right: {
      V v_x_2429 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      V v_x_2430 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2429));
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2430}), v_st_2427});
    }
    default: return heff_nomatch(v_x11_2426);
    }
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args) {
  V v_st_2435 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2436 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2435));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_MkPair: {
    V v_x11_2437 = heff_field(v_x1_2436, 0);
    V v_st_2438 = heff_field(v_x1_2436, 1);
    V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_Left: {
      V v_e_2439 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      V v_x_2441 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2440));
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2441}), v_st_2438});
    }
    default: return heff_nomatch(v_x11_2437);
    }
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args) {
  V v_st_2445 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2446 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2445));
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_MkPair: {
    V v_x11_2447 = heff_field(v_x1_2446, 0);
    V v_st_2448 = heff_field(v_x1_2446, 1);
    V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
    switch (heff_tag_of(v_x11_2447)) {
    case TAG_Left: {
      V v_e_2449 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
    }
    case TAG_Right: {
      V v_x_2450 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      V v_x_2451 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2450));
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2451}), v_st_2448});
    }
    default: return heff_nomatch(v_x11_2447);
    }
  }
  default: return heff_nomatch(v_x1_2446);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args) {
  V v_st_2456 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2457 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2456));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_MkPair: {
    V v_x11_2458 = heff_field(v_x1_2457, 0);
    V v_st_2459 = heff_field(v_x1_2457, 1);
    V v_ru_24x1_2457_24MkPair = heff_take_reuse_n(v_x1_2457, 3ULL, 2);
    switch (heff_tag_of(v_x11_2458)) {
    case TAG_Left: {
      V v_e_2460 = heff_field(v_x11_2458, 0);
      heff_take_n(v_x11_2458, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2460}), v_st_2459});
    }
    case TAG_Right: {
      V v_x_2461 = heff_field(v_x11_2458, 0);
      heff_take_n(v_x11_2458, 1ULL, 1);
      V v_x_2462 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2461));
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2462}), v_st_2459});
    }
    default: return heff_nomatch(v_x11_2458);
    }
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args) {
  V v_st_2469 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2470 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2469));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_MkPair: {
    V v_x11_2471 = heff_field(v_x1_2470, 0);
    V v_st_2472 = heff_field(v_x1_2470, 1);
    V v_ru_24x1_2470_24MkPair = heff_take_reuse_n(v_x1_2470, 3ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_Left: {
      V v_e_2473 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2473}), v_st_2472});
    }
    case TAG_Right: {
      V v_x_2474 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      V v_x_2475 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2474));
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2475}), v_st_2472});
    }
    default: return heff_nomatch(v_x11_2471);
    }
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args) {
  V v_st_2479 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2480 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2479));
  switch (heff_tag_of(v_x1_2480)) {
  case TAG_MkPair: {
    V v_x11_2481 = heff_field(v_x1_2480, 0);
    V v_st_2482 = heff_field(v_x1_2480, 1);
    V v_ru_24x1_2480_24MkPair = heff_take_reuse_n(v_x1_2480, 3ULL, 2);
    switch (heff_tag_of(v_x11_2481)) {
    case TAG_Left: {
      V v_e_2483 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2483}), v_st_2482});
    }
    case TAG_Right: {
      V v_x_2484 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      V v_x_2485 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2484));
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2485}), v_st_2482});
    }
    default: return heff_nomatch(v_x11_2481);
    }
  }
  default: return heff_nomatch(v_x1_2480);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args) {
  V v_st_2491 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2492 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2491));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      V v_x_2497 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2496));
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2497}), v_st_2494});
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args) {
  V v_st_24101 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24101));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24106));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args) {
  V v_st_24111 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24112 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24111));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_MkPair: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_st_24114 = heff_field(v_x1_24112, 1);
    V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_Left: {
      V v_e_24115 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
    }
    case TAG_Right: {
      V v_x_24116 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      V v_x_24117 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24116));
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24117}), v_st_24114});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args) {
  V v_st_24123 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24124 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24123));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      V v_x_24129 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24128));
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24129}), v_st_24126});
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args) {
  V v_st_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_st_24133}));
  switch (heff_tag_of(v_x1_24134)) {
  case TAG_MkPair: {
    V v_x11_24135 = heff_field(v_x1_24134, 0);
    V v_st_24136 = heff_field(v_x1_24134, 1);
    V v_ru_24x1_24134_24MkPair = heff_take_reuse_n(v_x1_24134, 3ULL, 2);
    switch (heff_tag_of(v_x11_24135)) {
    case TAG_Left: {
      V v_e_24137 = heff_field(v_x11_24135, 0);
      heff_take_n(v_x11_24135, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24137}), v_st_24136});
    }
    case TAG_Right: {
      V v_x_24138 = heff_field(v_x11_24135, 0);
      heff_take_n(v_x11_24135, 1ULL, 1);
      V v_x_24139 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24138));
      return heff_tag_at_n(v_ru_24x1_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24139}), v_st_24136});
    }
    default: return heff_nomatch(v_x11_24135);
    }
  }
  default: return heff_nomatch(v_x1_24134);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args) {
  V v_st_24142 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24143 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24142));
  switch (heff_tag_of(v_x1_24143)) {
  case TAG_MkPair: {
    V v_x11_24144 = heff_field(v_x1_24143, 0);
    V v_st_24145 = heff_field(v_x1_24143, 1);
    V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
    switch (heff_tag_of(v_x11_24144)) {
    case TAG_Left: {
      V v_e_24146 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
    }
    case TAG_Right: {
      V v_x_24147 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      V v_x_24148 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24147));
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24148}), v_st_24145});
    }
    default: return heff_nomatch(v_x11_24144);
    }
  }
  default: return heff_nomatch(v_x1_24143);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args) {
  V v_st_24151 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24152 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24151));
  switch (heff_tag_of(v_x1_24152)) {
  case TAG_MkPair: {
    V v_x11_24153 = heff_field(v_x1_24152, 0);
    V v_st_24154 = heff_field(v_x1_24152, 1);
    V v_ru_24x1_24152_24MkPair = heff_take_reuse_n(v_x1_24152, 3ULL, 2);
    switch (heff_tag_of(v_x11_24153)) {
    case TAG_Left: {
      V v_e_24155 = heff_field(v_x11_24153, 0);
      heff_take_n(v_x11_24153, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24155}), v_st_24154});
    }
    case TAG_Right: {
      V v_x_24156 = heff_field(v_x11_24153, 0);
      heff_take_n(v_x11_24153, 1ULL, 1);
      V v_x_24157 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24156));
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24157}), v_st_24154});
    }
    default: return heff_nomatch(v_x11_24153);
    }
  }
  default: return heff_nomatch(v_x1_24152);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args) {
  V v_st_24160 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24161 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24160));
  switch (heff_tag_of(v_x1_24161)) {
  case TAG_MkPair: {
    V v_x11_24162 = heff_field(v_x1_24161, 0);
    V v_st_24163 = heff_field(v_x1_24161, 1);
    V v_ru_24x1_24161_24MkPair = heff_take_reuse_n(v_x1_24161, 3ULL, 2);
    switch (heff_tag_of(v_x11_24162)) {
    case TAG_Left: {
      V v_e_24164 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24164}), v_st_24163});
    }
    case TAG_Right: {
      V v_x_24165 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      V v_x_24166 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24165));
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24163});
    }
    default: return heff_nomatch(v_x11_24162);
    }
  }
  default: return heff_nomatch(v_x1_24161);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args) {
  V v_st_24170 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24171 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24170));
  switch (heff_tag_of(v_x1_24171)) {
  case TAG_MkPair: {
    V v_x11_24172 = heff_field(v_x1_24171, 0);
    V v_st_24173 = heff_field(v_x1_24171, 1);
    V v_ru_24x1_24171_24MkPair = heff_take_reuse_n(v_x1_24171, 3ULL, 2);
    switch (heff_tag_of(v_x11_24172)) {
    case TAG_Left: {
      V v_e_24174 = heff_field(v_x11_24172, 0);
      heff_take_n(v_x11_24172, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24174}), v_st_24173});
    }
    case TAG_Right: {
      V v_x_24175 = heff_field(v_x11_24172, 0);
      heff_take_n(v_x11_24172, 1ULL, 1);
      V v_x_24176 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24175));
      return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24176}), v_st_24173});
    }
    default: return heff_nomatch(v_x11_24172);
    }
  }
  default: return heff_nomatch(v_x1_24171);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args) {
  V v_st_24179 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24180 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24179));
  switch (heff_tag_of(v_x1_24180)) {
  case TAG_MkPair: {
    V v_x11_24181 = heff_field(v_x1_24180, 0);
    V v_st_24182 = heff_field(v_x1_24180, 1);
    V v_ru_24x1_24180_24MkPair = heff_take_reuse_n(v_x1_24180, 3ULL, 2);
    switch (heff_tag_of(v_x11_24181)) {
    case TAG_Left: {
      V v_e_24183 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24183}), v_st_24182});
    }
    case TAG_Right: {
      V v_x_24184 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      V v_x_24185 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24184));
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24185}), v_st_24182});
    }
    default: return heff_nomatch(v_x11_24181);
    }
  }
  default: return heff_nomatch(v_x1_24180);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args) {
  V v_st_24188 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24189 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24188));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_MkPair: {
    V v_x11_24190 = heff_field(v_x1_24189, 0);
    V v_st_24191 = heff_field(v_x1_24189, 1);
    V v_ru_24x1_24189_24MkPair = heff_take_reuse_n(v_x1_24189, 3ULL, 2);
    switch (heff_tag_of(v_x11_24190)) {
    case TAG_Left: {
      V v_e_24192 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24192}), v_st_24191});
    }
    case TAG_Right: {
      V v_x_24193 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      V v_x_24194 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24193));
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24194}), v_st_24191});
    }
    default: return heff_nomatch(v_x11_24190);
    }
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args) {
  V v_st_24198 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24199 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24198));
  switch (heff_tag_of(v_x1_24199)) {
  case TAG_MkPair: {
    V v_x11_24200 = heff_field(v_x1_24199, 0);
    V v_st_24201 = heff_field(v_x1_24199, 1);
    V v_ru_24x1_24199_24MkPair = heff_take_reuse_n(v_x1_24199, 3ULL, 2);
    switch (heff_tag_of(v_x11_24200)) {
    case TAG_Left: {
      V v_e_24202 = heff_field(v_x11_24200, 0);
      heff_take_n(v_x11_24200, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24199_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24202}), v_st_24201});
    }
    case TAG_Right: {
      V v_x_24203 = heff_field(v_x11_24200, 0);
      heff_take_n(v_x11_24200, 1ULL, 1);
      V v_x_24204 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24203));
      return heff_tag_at_n(v_ru_24x1_24199_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24204}), v_st_24201});
    }
    default: return heff_nomatch(v_x11_24200);
    }
  }
  default: return heff_nomatch(v_x1_24199);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args) {
  V v_st_24206 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24207 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24206));
  switch (heff_tag_of(v_x1_24207)) {
  case TAG_MkPair: {
    V v_x11_24208 = heff_field(v_x1_24207, 0);
    V v_st_24209 = heff_field(v_x1_24207, 1);
    V v_ru_24x1_24207_24MkPair = heff_take_reuse_n(v_x1_24207, 3ULL, 2);
    switch (heff_tag_of(v_x11_24208)) {
    case TAG_Left: {
      V v_e_24210 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24210}), v_st_24209});
    }
    case TAG_Right: {
      V v_x_24211 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      V v_x_24212 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24211));
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24212}), v_st_24209});
    }
    default: return heff_nomatch(v_x11_24208);
    }
  }
  default: return heff_nomatch(v_x1_24207);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args) {
  V v_st_24216 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24217 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24216));
  switch (heff_tag_of(v_x1_24217)) {
  case TAG_MkPair: {
    V v_x11_24218 = heff_field(v_x1_24217, 0);
    V v_st_24219 = heff_field(v_x1_24217, 1);
    V v_ru_24x1_24217_24MkPair = heff_take_reuse_n(v_x1_24217, 3ULL, 2);
    switch (heff_tag_of(v_x11_24218)) {
    case TAG_Left: {
      V v_e_24220 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24220}), v_st_24219});
    }
    case TAG_Right: {
      V v_x_24221 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      V v_x_24222 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24221));
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24222}), v_st_24219});
    }
    default: return heff_nomatch(v_x11_24218);
    }
  }
  default: return heff_nomatch(v_x1_24217);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args) {
  V v_st_24228 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24229 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24228));
  switch (heff_tag_of(v_x1_24229)) {
  case TAG_MkPair: {
    V v_x11_24230 = heff_field(v_x1_24229, 0);
    V v_st_24231 = heff_field(v_x1_24229, 1);
    V v_ru_24x1_24229_24MkPair = heff_take_reuse_n(v_x1_24229, 3ULL, 2);
    switch (heff_tag_of(v_x11_24230)) {
    case TAG_Left: {
      V v_e_24232 = heff_field(v_x11_24230, 0);
      heff_take_n(v_x11_24230, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24232}), v_st_24231});
    }
    case TAG_Right: {
      V v_x_24233 = heff_field(v_x11_24230, 0);
      heff_take_n(v_x11_24230, 1ULL, 1);
      V v_x_24234 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24233));
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24234}), v_st_24231});
    }
    default: return heff_nomatch(v_x11_24230);
    }
  }
  default: return heff_nomatch(v_x1_24229);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args) {
  V v_st_24239 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24240 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24239));
  switch (heff_tag_of(v_x1_24240)) {
  case TAG_MkPair: {
    V v_x11_24241 = heff_field(v_x1_24240, 0);
    V v_st_24242 = heff_field(v_x1_24240, 1);
    V v_ru_24x1_24240_24MkPair = heff_take_reuse_n(v_x1_24240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24241)) {
    case TAG_Left: {
      V v_e_24243 = heff_field(v_x11_24241, 0);
      heff_take_n(v_x11_24241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24243}), v_st_24242});
    }
    case TAG_Right: {
      V v_x_24244 = heff_field(v_x11_24241, 0);
      heff_take_n(v_x11_24241, 1ULL, 1);
      V v_x_24245 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24244));
      return heff_tag_at_n(v_ru_24x1_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24245}), v_st_24242});
    }
    default: return heff_nomatch(v_x11_24241);
    }
  }
  default: return heff_nomatch(v_x1_24240);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args) {
  V v_st_24250 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24251 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24250));
  switch (heff_tag_of(v_x1_24251)) {
  case TAG_MkPair: {
    V v_x11_24252 = heff_field(v_x1_24251, 0);
    V v_st_24253 = heff_field(v_x1_24251, 1);
    V v_ru_24x1_24251_24MkPair = heff_take_reuse_n(v_x1_24251, 3ULL, 2);
    switch (heff_tag_of(v_x11_24252)) {
    case TAG_Left: {
      V v_e_24254 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24254}), v_st_24253});
    }
    case TAG_Right: {
      V v_x_24255 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      V v_x_24256 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24255));
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24256}), v_st_24253});
    }
    default: return heff_nomatch(v_x11_24252);
    }
  }
  default: return heff_nomatch(v_x1_24251);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args) {
  V v_st_24260 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24261 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24260));
  switch (heff_tag_of(v_x1_24261)) {
  case TAG_MkPair: {
    V v_x11_24262 = heff_field(v_x1_24261, 0);
    V v_st_24263 = heff_field(v_x1_24261, 1);
    V v_ru_24x1_24261_24MkPair = heff_take_reuse_n(v_x1_24261, 3ULL, 2);
    switch (heff_tag_of(v_x11_24262)) {
    case TAG_Left: {
      V v_e_24264 = heff_field(v_x11_24262, 0);
      heff_take_n(v_x11_24262, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24261_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24264}), v_st_24263});
    }
    case TAG_Right: {
      V v_x_24265 = heff_field(v_x11_24262, 0);
      heff_take_n(v_x11_24262, 1ULL, 1);
      V v_x_24266 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24265));
      return heff_tag_at_n(v_ru_24x1_24261_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24266}), v_st_24263});
    }
    default: return heff_nomatch(v_x11_24262);
    }
  }
  default: return heff_nomatch(v_x1_24261);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args) {
  V v_st_24273 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24274 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24273));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_MkPair: {
    V v_x11_24275 = heff_field(v_x1_24274, 0);
    V v_st_24276 = heff_field(v_x1_24274, 1);
    V v_ru_24x1_24274_24MkPair = heff_take_reuse_n(v_x1_24274, 3ULL, 2);
    switch (heff_tag_of(v_x11_24275)) {
    case TAG_Left: {
      V v_e_24277 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24277}), v_st_24276});
    }
    case TAG_Right: {
      V v_x_24278 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      V v_x_24279 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24278));
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24279}), v_st_24276});
    }
    default: return heff_nomatch(v_x11_24275);
    }
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args) {
  V v_st_24282 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24283 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24282));
  switch (heff_tag_of(v_x1_24283)) {
  case TAG_MkPair: {
    V v_x11_24284 = heff_field(v_x1_24283, 0);
    V v_st_24285 = heff_field(v_x1_24283, 1);
    V v_ru_24x1_24283_24MkPair = heff_take_reuse_n(v_x1_24283, 3ULL, 2);
    switch (heff_tag_of(v_x11_24284)) {
    case TAG_Left: {
      V v_e_24286 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24286}), v_st_24285});
    }
    case TAG_Right: {
      V v_x_24287 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      V v_x_24288 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24287));
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24288}), v_st_24285});
    }
    default: return heff_nomatch(v_x11_24284);
    }
  }
  default: return heff_nomatch(v_x1_24283);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args) {
  V v_st_24292 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24293 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24292));
  switch (heff_tag_of(v_x1_24293)) {
  case TAG_MkPair: {
    V v_x11_24294 = heff_field(v_x1_24293, 0);
    V v_st_24295 = heff_field(v_x1_24293, 1);
    V v_ru_24x1_24293_24MkPair = heff_take_reuse_n(v_x1_24293, 3ULL, 2);
    switch (heff_tag_of(v_x11_24294)) {
    case TAG_Left: {
      V v_e_24296 = heff_field(v_x11_24294, 0);
      heff_take_n(v_x11_24294, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24293_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24296}), v_st_24295});
    }
    case TAG_Right: {
      V v_x_24297 = heff_field(v_x11_24294, 0);
      heff_take_n(v_x11_24294, 1ULL, 1);
      V v_x_24298 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24297));
      return heff_tag_at_n(v_ru_24x1_24293_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24298}), v_st_24295});
    }
    default: return heff_nomatch(v_x11_24294);
    }
  }
  default: return heff_nomatch(v_x1_24293);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29(V self, V *args) {
  V v_st_24305 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24306 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24305));
  switch (heff_tag_of(v_x1_24306)) {
  case TAG_MkPair: {
    V v_x11_24307 = heff_field(v_x1_24306, 0);
    V v_st_24308 = heff_field(v_x1_24306, 1);
    V v_ru_24x1_24306_24MkPair = heff_take_reuse_n(v_x1_24306, 3ULL, 2);
    switch (heff_tag_of(v_x11_24307)) {
    case TAG_Left: {
      V v_e_24309 = heff_field(v_x11_24307, 0);
      heff_take_n(v_x11_24307, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24309}), v_st_24308});
    }
    case TAG_Right: {
      V v_x_24310 = heff_field(v_x11_24307, 0);
      heff_take_n(v_x11_24307, 1ULL, 1);
      V v_x_24311 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24310));
      return heff_tag_at_n(v_ru_24x1_24306_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24311}), v_st_24308});
    }
    default: return heff_nomatch(v_x11_24307);
    }
  }
  default: return heff_nomatch(v_x1_24306);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30(V self, V *args) {
  V v_st_24318 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24319 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24318));
  switch (heff_tag_of(v_x1_24319)) {
  case TAG_MkPair: {
    V v_x11_24320 = heff_field(v_x1_24319, 0);
    V v_st_24321 = heff_field(v_x1_24319, 1);
    V v_ru_24x1_24319_24MkPair = heff_take_reuse_n(v_x1_24319, 3ULL, 2);
    switch (heff_tag_of(v_x11_24320)) {
    case TAG_Left: {
      V v_e_24322 = heff_field(v_x11_24320, 0);
      heff_take_n(v_x11_24320, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24319_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24322}), v_st_24321});
    }
    case TAG_Right: {
      V v_x_24323 = heff_field(v_x11_24320, 0);
      heff_take_n(v_x11_24320, 1ULL, 1);
      V v_x_24324 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24323));
      return heff_tag_at_n(v_ru_24x1_24319_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24324}), v_st_24321});
    }
    default: return heff_nomatch(v_x11_24320);
    }
  }
  default: return heff_nomatch(v_x1_24319);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31(V self, V *args) {
  V v_st_24328 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24329 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24328));
  switch (heff_tag_of(v_x1_24329)) {
  case TAG_MkPair: {
    V v_x11_24330 = heff_field(v_x1_24329, 0);
    V v_st_24331 = heff_field(v_x1_24329, 1);
    V v_ru_24x1_24329_24MkPair = heff_take_reuse_n(v_x1_24329, 3ULL, 2);
    switch (heff_tag_of(v_x11_24330)) {
    case TAG_Left: {
      V v_e_24332 = heff_field(v_x11_24330, 0);
      heff_take_n(v_x11_24330, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24329_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24332}), v_st_24331});
    }
    case TAG_Right: {
      V v_x_24333 = heff_field(v_x11_24330, 0);
      heff_take_n(v_x11_24330, 1ULL, 1);
      V v_x_24334 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24333));
      return heff_tag_at_n(v_ru_24x1_24329_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24334}), v_st_24331});
    }
    default: return heff_nomatch(v_x11_24330);
    }
  }
  default: return heff_nomatch(v_x1_24329);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32(V self, V *args) {
  V v_st_24339 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24340 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24339));
  switch (heff_tag_of(v_x1_24340)) {
  case TAG_MkPair: {
    V v_x11_24341 = heff_field(v_x1_24340, 0);
    V v_st_24342 = heff_field(v_x1_24340, 1);
    V v_ru_24x1_24340_24MkPair = heff_take_reuse_n(v_x1_24340, 3ULL, 2);
    switch (heff_tag_of(v_x11_24341)) {
    case TAG_Left: {
      V v_e_24343 = heff_field(v_x11_24341, 0);
      heff_take_n(v_x11_24341, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24340_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24343}), v_st_24342});
    }
    case TAG_Right: {
      V v_x_24344 = heff_field(v_x11_24341, 0);
      heff_take_n(v_x11_24341, 1ULL, 1);
      V v_x_24345 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24344));
      return heff_tag_at_n(v_ru_24x1_24340_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24345}), v_st_24342});
    }
    default: return heff_nomatch(v_x11_24341);
    }
  }
  default: return heff_nomatch(v_x1_24340);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33(V self, V *args) {
  V v_st_24352 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24353 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24352));
  switch (heff_tag_of(v_x1_24353)) {
  case TAG_MkPair: {
    V v_x11_24354 = heff_field(v_x1_24353, 0);
    V v_st_24355 = heff_field(v_x1_24353, 1);
    V v_ru_24x1_24353_24MkPair = heff_take_reuse_n(v_x1_24353, 3ULL, 2);
    switch (heff_tag_of(v_x11_24354)) {
    case TAG_Left: {
      V v_e_24356 = heff_field(v_x11_24354, 0);
      heff_take_n(v_x11_24354, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24356}), v_st_24355});
    }
    case TAG_Right: {
      V v_x_24357 = heff_field(v_x11_24354, 0);
      heff_take_n(v_x11_24354, 1ULL, 1);
      V v_x_24358 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24357));
      return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24358}), v_st_24355});
    }
    default: return heff_nomatch(v_x11_24354);
    }
  }
  default: return heff_nomatch(v_x1_24353);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34(V self, V *args) {
  V v_st_24360 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24361 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24360));
  switch (heff_tag_of(v_x1_24361)) {
  case TAG_MkPair: {
    V v_x11_24362 = heff_field(v_x1_24361, 0);
    V v_st_24363 = heff_field(v_x1_24361, 1);
    V v_ru_24x1_24361_24MkPair = heff_take_reuse_n(v_x1_24361, 3ULL, 2);
    switch (heff_tag_of(v_x11_24362)) {
    case TAG_Left: {
      V v_e_24364 = heff_field(v_x11_24362, 0);
      heff_take_n(v_x11_24362, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24364}), v_st_24363});
    }
    case TAG_Right: {
      V v_x_24365 = heff_field(v_x11_24362, 0);
      heff_take_n(v_x11_24362, 1ULL, 1);
      V v_x_24366 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24365));
      return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24366}), v_st_24363});
    }
    default: return heff_nomatch(v_x11_24362);
    }
  }
  default: return heff_nomatch(v_x1_24361);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35(V self, V *args) {
  V v_st_24369 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24370 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24369));
  switch (heff_tag_of(v_x1_24370)) {
  case TAG_MkPair: {
    V v_x11_24371 = heff_field(v_x1_24370, 0);
    V v_st_24372 = heff_field(v_x1_24370, 1);
    V v_ru_24x1_24370_24MkPair = heff_take_reuse_n(v_x1_24370, 3ULL, 2);
    switch (heff_tag_of(v_x11_24371)) {
    case TAG_Left: {
      V v_e_24373 = heff_field(v_x11_24371, 0);
      heff_take_n(v_x11_24371, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24370_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24373}), v_st_24372});
    }
    case TAG_Right: {
      V v_x_24374 = heff_field(v_x11_24371, 0);
      heff_take_n(v_x11_24371, 1ULL, 1);
      V v_x_24375 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24374));
      return heff_tag_at_n(v_ru_24x1_24370_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24375}), v_st_24372});
    }
    default: return heff_nomatch(v_x11_24371);
    }
  }
  default: return heff_nomatch(v_x1_24370);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36(V self, V *args) {
  V v_st_24380 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24381 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24380));
  switch (heff_tag_of(v_x1_24381)) {
  case TAG_MkPair: {
    V v_x11_24382 = heff_field(v_x1_24381, 0);
    V v_st_24383 = heff_field(v_x1_24381, 1);
    V v_ru_24x1_24381_24MkPair = heff_take_reuse_n(v_x1_24381, 3ULL, 2);
    switch (heff_tag_of(v_x11_24382)) {
    case TAG_Left: {
      V v_e_24384 = heff_field(v_x11_24382, 0);
      heff_take_n(v_x11_24382, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24384}), v_st_24383});
    }
    case TAG_Right: {
      V v_x_24385 = heff_field(v_x11_24382, 0);
      heff_take_n(v_x11_24382, 1ULL, 1);
      V v_x_24386 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24385));
      return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24386}), v_st_24383});
    }
    default: return heff_nomatch(v_x11_24382);
    }
  }
  default: return heff_nomatch(v_x1_24381);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37(V self, V *args) {
  V v_st_24391 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24392 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24391));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_MkPair: {
    V v_x11_24393 = heff_field(v_x1_24392, 0);
    V v_st_24394 = heff_field(v_x1_24392, 1);
    V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
    switch (heff_tag_of(v_x11_24393)) {
    case TAG_Left: {
      V v_e_24395 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
    }
    case TAG_Right: {
      V v_x_24396 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      V v_x_24397 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24396));
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24397}), v_st_24394});
    }
    default: return heff_nomatch(v_x11_24393);
    }
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_fields_244, V v_z_245) {
top: ;
  V v_m_246 = (g_prelude_2etraverse_24s518454301x170091462(v_params_243));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    heff_take_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_fields_244);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_248_24Left, TAG_Left, 1, (V[]){v_e_2410}), v_st_249}});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2411)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2412, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0, 1, 5, (V[]){v_fields_244, v_name_242, v_d_240, v_kw_241, v_x_2411}), v_st_249));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args) {
  V v_st_2413 = args[0];
  V v_fields_244 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_d_240 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2414 = (g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_24cpr(v_fields_244, v_st_2413));
  {
    V v_field_2415 = v_t_2414.f[0];
    V v_field_2416 = v_t_2414.f[1];
    V v_x11_2417 = v_field_2415;
    V v_st_2418 = v_field_2416;
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      V v_ru_24x11_2417_24Left = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_x_2411);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2417_24Left, TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      V v_ru_24x11_2417_24Right = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
      V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
      V v_t_2422 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
      V v_e_2423 = heff_get_n(v_t_2422, 4, 9);
      V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2423});
      V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_x_2420}), v_t_2424});
      V v_t_2426 = heff_tag_n(TAG_DeclTheory, 4, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2421, v_x_2411, v_t_2425});
      V v_t_2427 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
      V v_e_2428 = heff_get_n(v_t_2427, 4, 9);
      V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2428});
      V v_t_2430 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_t_2429})});
      V v_x_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2417_24Right, TAG_Right, 1, (V[]){v_x_2431}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str3, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V v_ys_240, V v_pv_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_245 = heff_field(v_x2_242, 1);
    V v_t_247 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_245));
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(v_t_247, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_248);
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_242, 0);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 1)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2))) {
          V v_t_2413 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_249, 1))}));
          V v_t_2414 = (g_list_2eany(v_t_2413, v_pv_241));
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            V v_x_2415 = heff_dup(heff_rfield(v_t_249, 1));
            V v_t_2416 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
            return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_t_2416}));
          } else {
            heff_drop(v_t_2414);
            return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
          }
        } else {
          return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
        }
      } else {
        V v_x_2417 = heff_dup(heff_rfield(v_t_249, 1));
        V v_t_2418 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
        return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, v_t_2418}));
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str3))) {
        V v_t_2420 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_249, 1))}));
        V v_t_2421 = (g_list_2eany(v_t_2420, v_pv_241));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          V v_x_2422 = heff_dup(heff_rfield(v_t_249, 1));
          V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2422, v_t_2423}));
        } else {
          heff_drop(v_t_2421);
          return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
        }
      } else {
        return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2425 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2425;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2428 = heff_field(v_x2_242, 1);
    V v_t_2432 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2428));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2432, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2433);
  }
  case TAG_POp: {
    V v_l_2434 = heff_field(v_x2_242, 0);
    V v_q_2436 = heff_field(v_x2_242, 2);
    V v_t_2437 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2434));
    V v_t_2438 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2436));
    V v_t_2439 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2437, v_t_2438));
    V v_t_2440 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2439, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2440);
  }
  case TAG_PRec: {
    V v_fs_2442 = heff_field(v_x2_242, 1);
    V v_t_2446 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2442));
    V v_t_2447 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2446, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2447);
  }
  case TAG_PField: {
    V v_q_2450 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2450;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2451 = heff_field(v_x2_242, 0);
    V v_q_2453 = heff_field(v_x2_242, 2);
    V v_x_2454 = heff_dup(heff_rfield(v_x_2451, 1));
    V v_cell_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2454, heff_hole()});
    V v_u_2456 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2455));
    heff_drop(v_u_2456);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2453;
    V t_3 = v_cell_2455;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2457 = heff_field(v_x2_242, 0);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2457;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args) {
  V v_q_246 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_246; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_246); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args) {
  V v_q_2431 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2431; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2431); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args) {
  V v_q_2445 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2445; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2445); r_; });
}