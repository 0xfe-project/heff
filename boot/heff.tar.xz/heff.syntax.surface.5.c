// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBinding 25795
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Passes 47566
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_args 9498020
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_held 9694204
#define LBL_i 323
#define LBL_items 301884378
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_little 844663329
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_sigs 10025609
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_items__diags__broken__arms[] = {LBL_items, LBL_diags, LBL_broken, LBL_arms};
static uint32_t shape_name__span__ty__eqns__whole[] = {LBL_name, LBL_span, LBL_ty, LBL_eqns, LBL_whole};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_sigs__held__rest[] = {LBL_sigs, LBL_held, LBL_rest};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot, LBL_arms};
V g_heff_2esyntax_2ecst_2edeclStep(V);
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclStep_clo;
HeffT2 g_heff_2esyntax_2ecst_2edeclaredAt_24cpr(V);
V g_heff_2esyntax_2ecst_2edeclaredMore(V);
V g_heff_2esyntax_2ecst_2edeclaredMore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredMore_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eskipDecl(V);
V g_heff_2esyntax_2ecst_2eskipDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipDecl_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eappendRev(V, V);
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendRev_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2earrowNames(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_clo;
V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2edefaultL_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2egroupFrom(V, V);
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupFrom_clo;
HeffT3 g_heff_2esyntax_2esurface_2egroupFrom_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eisVarE(V);
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisVarE_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V, V);
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok2_clo;
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
HeffT3 g_heff_2esyntax_2esurface_2epickSig_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2erevOnto(V, V);
V g_heff_2esyntax_2esurface_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erevOnto_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esetBinders(V, V);
V g_heff_2esyntax_2esurface_2esetBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetBinders_clo;
V g_heff_2esyntax_2esurface_2esetKnot(V, V);
V g_heff_2esyntax_2esurface_2esetKnot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetKnot_clo;
V g_heff_2esyntax_2esurface_2esetPatVars(V, V);
V g_heff_2esyntax_2esurface_2esetPatVars_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetPatVars_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2etypeChecks_24cpr(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eunevenAt(V, V, V);
V g_heff_2esyntax_2esurface_2eunevenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunevenAt_clo;
V g_heff_2esyntax_2esurface_2eunitIn(V, V);
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitIn_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
V g_list_2eany_24s935688233x1434116625(V, V);
V g_list_2eany_24s935688233x1434116625_entry(V self, V *a);
extern Clo g_list_2eany_24s935688233x1434116625_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
HeffT2 g_prelude_2etraverse_24s956608878x365908798_24cpr(V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2esetBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esetBinders_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esetBinders(V v_b_240, V v_s_241) {
top: ;
  V v_known_242 = heff_take_field(v_s_241, 2);
  V v_patVars_243 = heff_take_field(v_s_241, 4);
  V v_fix_244 = heff_take_field(v_s_241, 5);
  V v_lenient_245 = heff_take_field(v_s_241, 6);
  V v_at_246 = heff_take_field(v_s_241, 7);
  V v_knot_247 = heff_take_field(v_s_241, 8);
  V v_arms_248 = heff_take_field(v_s_241, 9);
  return ({ V rv_2 = v_known_242; V rv_3 = v_b_240; V rv_4 = v_patVars_243; V rv_5 = v_fix_244; V rv_6 = v_lenient_245; V rv_7 = v_at_246; V rv_8 = v_knot_247; V rv_9 = v_arms_248; V rr_ = heff_rec_reuse_nf(v_s_241, 3ULL, 10, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2esurface_2esetBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esetBinders(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2esetKnot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esetKnot_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esetKnot(V v_k_240, V v_s_241) {
top: ;
  V v_known_242 = heff_take_field(v_s_241, 2);
  V v_binders_243 = heff_take_field(v_s_241, 3);
  V v_patVars_244 = heff_take_field(v_s_241, 4);
  V v_fix_245 = heff_take_field(v_s_241, 5);
  V v_lenient_246 = heff_take_field(v_s_241, 6);
  V v_at_247 = heff_take_field(v_s_241, 7);
  V v_arms_248 = heff_take_field(v_s_241, 9);
  return ({ V rv_2 = v_known_242; V rv_3 = v_binders_243; V rv_4 = v_patVars_244; V rv_5 = v_fix_245; V rv_6 = v_lenient_246; V rv_7 = v_at_247; V rv_8 = v_k_240; V rv_9 = v_arms_248; V rr_ = heff_rec_reuse_nf(v_s_241, 3ULL, 10, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2esyntax_2esurface_2esetKnot_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esetKnot(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_u_246;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eintOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintOfText_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eintOfText(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str0))) {
    V v_t_241 = (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    return heff_intSub(MK_INT(0LL), v_t_241);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str1))) {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    } else {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(0LL)));
    }
  }
}
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintOfText(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_str1, 47, "an implicit argument is named: `{x : T} -> ...`");
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2earrowNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowNames_entry, 6, 0};

V g_heff_2esyntax_2esurface_2earrowNames(V v_rhs_240, V v_g_241, V v_ty_242, V v_braces_243, V v_dflt_244, V v_orig_245) {
top: ;
  V v_t_2412;
  switch (heff_tag_of(v_g_241)) {
  case TAG_At: {
    V v_e1_246 = heff_dup(heff_field(v_g_241, 0));
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EApp: {
      V v_h_248 = heff_field(v_e1_246, 0);
      V v_xs_249 = heff_field(v_e1_246, 1);
      heff_take_n(v_e1_246, 3ULL, 2);
      switch (heff_tag_of(v_g_241)) {
      case TAG_At: {
        v_t_2412 = heff_rec_n(2, shape_head__args, (V[]){v_h_248, v_xs_249});
        break;
      }
      default: heff_nomatch(v_g_241);
      }
      break;
    }
    default: {
      heff_drop(v_e1_246);
      v_t_2412 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_241), NTAG(TAG_Nil)});
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_g_241);
  }
  V v_t_2413 = (g_heff_2esyntax_2esurface_2eisVarE(heff_rfield(v_t_2412, 0)));
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    V v_t_2420;
    switch (heff_tag_of(v_g_241)) {
    case TAG_At: {
      V v_e1_2414 = heff_dup(heff_field(v_g_241, 0));
      switch (heff_tag_of(v_e1_2414)) {
      case TAG_EApp: {
        V v_h_2416 = heff_field(v_e1_2414, 0);
        V v_xs_2417 = heff_field(v_e1_2414, 1);
        heff_take_n(v_e1_2414, 3ULL, 2);
        switch (heff_tag_of(v_g_241)) {
        case TAG_At: {
          v_t_2420 = ({ V rv_0 = v_h_2416; V rv_1 = v_xs_2417; V rr_ = heff_rec_reuse_nf(v_t_2412, 0ULL, 2, shape_head__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        default: heff_nomatch(v_g_241);
        }
        break;
      }
      default: {
        heff_drop(v_e1_2414);
        v_t_2420 = ({ V rv_0 = heff_dup(v_g_241); V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_t_2412, 0ULL, 2, shape_head__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        break;
      }
      }
      break;
    }
    default: heff_nomatch(v_g_241);
    }
    V v_t_2421 = (g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(heff_rfield(v_t_2420, 1)));
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_orig_245);
      heff_drop(v_t_2421);
      V v_f_24103 = heff_clo_n(g_heff_2esyntax_2esurface_2earrowNames_lam0, 2, 3, (V[]){v_braces_243, v_ty_242, v_dflt_244});
      V v_t_24110;
      switch (heff_tag_of(v_g_241)) {
      case TAG_At: {
        V v_e1_24104 = heff_dup(heff_field(v_g_241, 0));
        switch (heff_tag_of(v_e1_24104)) {
        case TAG_EApp: {
          V v_h_24106 = heff_field(v_e1_24104, 0);
          V v_xs_24107 = heff_field(v_e1_24104, 1);
          heff_take_n(v_e1_24104, 3ULL, 2);
          switch (heff_tag_of(v_g_241)) {
          case TAG_At: {
            v_t_24110 = ({ V rv_0 = v_h_24106; V rv_1 = v_xs_24107; V rr_ = heff_rec_reuse_nf(v_t_2420, 0ULL, 2, shape_head__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            break;
          }
          default: heff_nomatch(v_g_241);
          }
          break;
        }
        default: {
          heff_drop(v_e1_24104);
          v_t_24110 = ({ V rv_0 = heff_dup(v_g_241); V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_t_2420, 0ULL, 2, shape_head__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_241);
      }
      V v_t_24111 = heff_take_field(v_t_24110, 0);
      V v_t_24118;
      switch (heff_tag_of(v_g_241)) {
      case TAG_At: {
        V v_e1_24112 = heff_dup(heff_field(v_g_241, 0));
        switch (heff_tag_of(v_e1_24112)) {
        case TAG_EApp: {
          V v_h_24114 = heff_field(v_e1_24112, 0);
          V v_xs_24115 = heff_field(v_e1_24112, 1);
          heff_take_n(v_e1_24112, 3ULL, 2);
          switch (heff_tag_of(v_g_241)) {
          case TAG_At: {
            heff_take_n(v_g_241, 0ULL, 2);
            v_t_24118 = ({ V rv_0 = v_h_24114; V rv_1 = v_xs_24115; V rr_ = heff_rec_reuse_nf(v_t_24110, 0ULL, 2, shape_head__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
            break;
          }
          default: heff_nomatch(v_g_241);
          }
          break;
        }
        default: {
          heff_drop(v_e1_24112);
          v_t_24118 = ({ V rv_0 = v_g_241; V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_t_24110, 0ULL, 2, shape_head__args, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_241);
      }
      V v_t_24119 = ({ V a_0 = heff_dup(v_f_24103); V a_1 = v_rhs_240; V b_2 = heff_get_n(v_t_24118, 1, 2); V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tail(v_f_24103, 2, (V[]){v_t_24111, v_t_24119});
    } else {
      heff_drop(v_g_241);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_t_2420, 2);
      heff_drop(v_t_2421);
      switch (heff_tag_of(v_braces_243)) {
      case TAG_Nothing: {
        V v_t_24120 = (g_heff_2esyntax_2esurface_2eplainBinder(heff_dup(v_orig_245)));
        V v_t_24123;
        switch (heff_tag_of(v_orig_245)) {
        case TAG_At: {
          V v_s_24122 = heff_field(v_orig_245, 1);
          heff_take_n(v_orig_245, 2ULL, 2);
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_orig_245);
        }
        V v_t_24126;
        switch (heff_tag_of(v_rhs_240)) {
        case TAG_At: {
          V v_s_24125 = heff_dup(heff_field(v_rhs_240, 1));
          v_t_24126 = v_s_24125;
          break;
        }
        default: heff_nomatch(v_rhs_240);
        }
        V v_t_24127 = ({ V rv_1 = heff_get_n(v_t_24126, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24123, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EPi, 2, (V[]){v_t_24120, v_rhs_240}), v_t_24127});
      }
      case TAG_Just: {
        V v_bsp_24128 = heff_field(v_braces_243, 0);
        V v_ru_24braces_243_24Just = heff_take_reuse_n(v_braces_243, 1ULL, 1);
        heff_drop(v_orig_245);
        V v_t_24131;
        switch (heff_tag_of(v_rhs_240)) {
        case TAG_At: {
          V v_s_24130 = heff_dup(heff_field(v_rhs_240, 1));
          v_t_24131 = v_s_24130;
          break;
        }
        default: heff_nomatch(v_rhs_240);
        }
        V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24braces_243_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_str0)}), heff_dup(v_bsp_24128)});
        V v_t_24133 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24132}), v_rhs_240});
        V v_t_24134 = ({ V rv_1 = heff_get_n(v_t_24131, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24128, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24133, v_t_24134});
      }
      default: return heff_nomatch(v_braces_243);
      }
    }
  } else {
    heff_drop(v_g_241);
    heff_drop(v_ty_242);
    heff_drop(v_dflt_244);
    heff_drop_rec(v_t_2412, 2);
    heff_drop(v_t_2413);
    switch (heff_tag_of(v_braces_243)) {
    case TAG_Nothing: {
      V v_t_24135 = (g_heff_2esyntax_2esurface_2eplainBinder(heff_dup(v_orig_245)));
      V v_t_24138;
      switch (heff_tag_of(v_orig_245)) {
      case TAG_At: {
        V v_s_24137 = heff_field(v_orig_245, 1);
        heff_take_n(v_orig_245, 2ULL, 2);
        v_t_24138 = v_s_24137;
        break;
      }
      default: heff_nomatch(v_orig_245);
      }
      V v_t_24141;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_24140 = heff_dup(heff_field(v_rhs_240, 1));
        v_t_24141 = v_s_24140;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_24142 = ({ V rv_1 = heff_get_n(v_t_24141, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24138, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EPi, 2, (V[]){v_t_24135, v_rhs_240}), v_t_24142});
    }
    case TAG_Just: {
      V v_bsp_24143 = heff_field(v_braces_243, 0);
      V v_ru_24braces_243_24Just = heff_take_reuse_n(v_braces_243, 1ULL, 1);
      heff_drop(v_orig_245);
      V v_t_24146;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_24145 = heff_dup(heff_field(v_rhs_240, 1));
        v_t_24146 = v_s_24145;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24braces_243_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_str1)}), heff_dup(v_bsp_24143)});
      V v_t_24148 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24147}), v_rhs_240});
      V v_t_24149 = ({ V rv_1 = heff_get_n(v_t_24146, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24143, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_24148, v_t_24149});
    }
    default: return heff_nomatch(v_braces_243);
    }
  }
}
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowNames(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_b_2423 = args[1];
  V v_braces_243 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_dflt_244 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_At: {
    V v_it1_2424 = heff_field(v_x_2422, 0);
    V v_ysp_2425 = heff_field(v_x_2422, 1);
    V v_ru_24x_2422_24At = heff_take_reuse_n(v_x_2422, 3ULL, 2);
    switch (heff_tag_of(v_it1_2424)) {
    case TAG_EVar: {
      V v_y_2426 = heff_field(v_it1_2424, 0);
      heff_take_n(v_it1_2424, 1ULL, 1);
      heff_clo_take(self, 3);
      switch (heff_tag_of(v_braces_243)) {
      case TAG_Nothing: {
        heff_drop(v_dflt_244);
        V v_t_2429;
        switch (heff_tag_of(v_ty_242)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_ty_242, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_ty_242);
        }
        V v_dsp_2430 = ({ V rv_0 = heff_dup(heff_rfield(v_ysp_2425, 0)); V rr_ = heff_rec_reuse_nf(v_t_2429, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2433;
        switch (heff_tag_of(v_b_2423)) {
        case TAG_At: {
          V v_s_2432 = heff_dup(heff_field(v_b_2423, 1));
          v_t_2433 = v_s_2432;
          break;
        }
        default: heff_nomatch(v_b_2423);
        }
        V v_t_2434 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiNamed, 3, (V[]){v_y_2426, v_ysp_2425, v_ty_242}), v_b_2423});
        V v_t_2435 = ({ V rv_1 = heff_get_n(v_t_2433, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2430, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2422_24At, TAG_At, 2, (V[]){v_t_2434, v_t_2435});
      }
      case TAG_Just: {
        V v_bsp_2436 = heff_field(v_braces_243, 0);
        heff_take_n(v_braces_243, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_b_2423)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_b_2423, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_b_2423);
        }
        V v_t_2440 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiImplicit, 5, (V[]){v_y_2426, v_ysp_2425, heff_dup(v_bsp_2436), v_ty_242, v_dflt_244}), v_b_2423});
        V v_t_2441 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2436, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2422_24At, TAG_At, 2, (V[]){v_t_2440, v_t_2441});
      }
      default: return heff_nomatch(v_braces_243);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ENotationVar: {
      heff_take_n(v_it1_2424, 0ULL, 3);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ETag: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EInt: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EFloat: {
      heff_take_nf(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EString: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EBinary: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ERune: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EWord: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EApp: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EProject: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EPi: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELam: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_2424, 0ULL, 4);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ESig: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ESum: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EDo: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EAssign: {
      heff_take_n(v_it1_2424, 0ULL, 3);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EWhile: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EFor: {
      heff_take_n(v_it1_2424, 0ULL, 3);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EIfThen: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EBreak: {
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EContinue: {
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EReturn: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ENest: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELazy: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ETuple: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ETry: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EWith: {
      heff_take_n(v_it1_2424, 0ULL, 4);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EWithBound: {
      heff_take_n(v_it1_2424, 0ULL, 3);
      heff_drop(self);
      heff_drop_rec(v_ysp_2425, 2);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    default: return heff_nomatch(v_it1_2424);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str1, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str2, 49, "an instance argument is named: `{{x : T}} -> ...`");
Clo g_heff_2esyntax_2esurface_2earrowBinop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowBinop_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowBinop(V v_x1_240, V v_rhs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Plain: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Plain = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_243 = heff_dup(heff_field(v_x11_242, 0));
      switch (heff_tag_of(v_x111_243)) {
      case TAG_EAnn: {
        V v_g_245 = heff_field(v_x111_243, 0);
        V v_ty_246 = heff_field(v_x111_243, 1);
        V v_ru_24x111_243_24EAnn = heff_take_reuse_n(v_x111_243, 3ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Plain, 1);
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_sp_248 = heff_field(v_x11_242, 1);
          V v_ru_24x11_242_24At = heff_take_reuse_n(v_x11_242, 2ULL, 2);
          V v_t_249 = heff_tag_re_n(v_ru_24x11_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x111_243_24EAnn, TAG_EAnn, 2, (V[]){heff_dup(v_g_245), heff_dup(v_ty_246)}), v_sp_248});
          return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_245, v_ty_246, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_t_249));
        }
        default: return heff_nomatch(v_x11_242);
        }
      }
      default: {
        heff_drop(v_x111_243);
        V v_dsp_2412;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_x11_242, 1));
          v_dsp_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2415;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_rhs_241, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2416 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){v_x11_242}), v_rhs_241});
        V v_t_2417 = ({ V rv_1 = heff_get_n(v_t_2415, 1, 2); V rr_ = heff_rec_reuse_nf(v_dsp_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_t_2417});
      }
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_Braced: {
    V v_x11_2418 = heff_field(v_x1_240, 0);
    V v_dflt_2419 = heff_field(v_x1_240, 1);
    V v_bsp_2420 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_At: {
      V v_x111_2421 = heff_field(v_x11_2418, 0);
      V v_sp_2422 = heff_field(v_x11_2418, 1);
      V v_ru_24x11_2418_24At = heff_take_reuse_n(v_x11_2418, 3ULL, 2);
      switch (heff_tag_of(v_x111_2421)) {
      case TAG_EAnn: {
        V v_g_2423 = heff_field(v_x111_2421, 0);
        V v_ty_2424 = heff_field(v_x111_2421, 1);
        V v_ru_24x111_2421_24EAnn = heff_take_reuse_n(v_x111_2421, 3ULL, 2);
        V v_t_2425 = heff_tag_re_n(v_ru_24x11_2418_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x111_2421_24EAnn, TAG_EAnn, 2, (V[]){heff_dup(v_g_2423), heff_dup(v_ty_2424)}), v_sp_2422});
        return ({ V a_0 = v_bsp_2420; V a_1 = v_rhs_241; V a_2 = v_g_2423; V a_3 = v_ty_2424; V a_4 = v_dflt_2419; V a_5 = v_t_2425; V r_ = (g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_t_2425, 2); r_; });
      }
      default: {
        heff_drop(v_dflt_2419);
        heff_drop(v_x111_2421);
        heff_drop(v_sp_2422);
        V v_t_2428;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_rhs_241, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2429 = heff_tag_at_n(v_ru_24x11_2418_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str0)}), heff_dup(v_bsp_2420)});
        V v_t_2430 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2429}), v_rhs_241});
        V v_t_2431 = ({ V rv_1 = heff_get_n(v_t_2428, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2420, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2430, v_t_2431});
      }
      }
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  case TAG_Bracketed: {
    V v_x11_2432 = heff_field(v_x1_240, 0);
    V v_bsp_2433 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Bracketed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_At: {
      V v_x111_2434 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24At = heff_take_reuse_n(v_x11_2432, 1ULL, 2);
      switch (heff_tag_of(v_x111_2434)) {
      case TAG_EAnn: {
        V v_x1111_2436 = heff_field(v_x111_2434, 0);
        V v_t_2437 = heff_field(v_x111_2434, 1);
        V v_ru_24x111_2434_24EAnn = heff_take_reuse_n(v_x111_2434, 3ULL, 2);
        switch (heff_tag_of(v_x1111_2436)) {
        case TAG_At: {
          V v_x11111_2438 = heff_field(v_x1111_2436, 0);
          V v_xsp_2439 = heff_field(v_x1111_2436, 1);
          heff_take_n(v_x1111_2436, 3ULL, 2);
          switch (heff_tag_of(v_x11111_2438)) {
          case TAG_EVar: {
            V v_x_2440 = heff_field(v_x11111_2438, 0);
            heff_take_n(v_x11111_2438, 1ULL, 1);
            heff_drop_cell(v_ru_24x111_2434_24EAnn, 2);
            V v_t_2443;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_2442 = heff_dup(heff_field(v_rhs_241, 1));
              v_t_2443 = v_s_2442;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_2444 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiInstance, 4, (V[]){v_x_2440, v_xsp_2439, heff_dup(v_bsp_2433), v_t_2437}), v_rhs_241});
            V v_t_2445 = ({ V rv_1 = heff_get_n(v_t_2443, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2433, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_2432_24At, TAG_At, 2, (V[]){v_t_2444, v_t_2445});
          }
          default: {
            heff_drop(v_t_2437);
            heff_drop(v_x11111_2438);
            heff_drop(v_xsp_2439);
            V v_t_2448;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_2447 = heff_dup(heff_field(v_rhs_241, 1));
              v_t_2448 = v_s_2447;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_2449 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str1)}), heff_dup(v_bsp_2433)});
            V v_t_2450 = heff_tag_at_n(v_ru_24x111_2434_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2449}), v_rhs_241});
            V v_t_2451 = ({ V rv_1 = heff_get_n(v_t_2448, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2433, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_2432_24At, TAG_At, 2, (V[]){v_t_2450, v_t_2451});
          }
          }
        }
        default: return heff_nomatch(v_x1111_2436);
        }
      }
      default: {
        heff_drop(v_x111_2434);
        V v_t_2454;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_rhs_241, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2455 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str2)}), heff_dup(v_bsp_2433)});
        V v_t_2456 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2455}), v_rhs_241});
        V v_t_2457 = ({ V rv_1 = heff_get_n(v_t_2454, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2433, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_2432_24At, TAG_At, 2, (V[]){v_t_2456, v_t_2457});
      }
      }
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowBinop(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str1, 37, "` does not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str3, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str4, 35, "` do not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str6, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str7, 39, "` are both the loosest: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str9, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str10, 85, "` are not related: add parentheses, or declare which binds tighter (`above`, `below`)");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str12, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str13, 34, "`), or import the module that does");
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam2, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam5, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam9(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam9, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam10(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efirstS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efirstS(V v_fix_240, V v_lenient_241, V v_before_242, V v_op_243) {
top: ;
  V v_it_244 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_fix_240), heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1))));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Tighter: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam0_clo);
  }
  case TAG_Looser: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam1_clo);
  }
  case TAG_Same: {
    V v_it1_249 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_AssocLeft: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam2_clo);
    }
    case TAG_AssocRight: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam3_clo);
    }
    case TAG_AssocNone: {
      V v_span_2414 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_243, 3)), heff_dup(heff_rfield(v_op_243, 4))});
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam4, 1, 3, (V[]){v_before_242, v_op_243, v_span_2414});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Unrelated: {
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop(v_fix_240);
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam5_clo);
    } else {
      V v_span_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_take_field(v_op_243, 4)});
      V v_a_2424 = heff_get_n(v_before_242, 1, 9);
      V v_b_2425 = heff_get_n(v_op_243, 1, 9);
      V v_f_2426 = v_fix_240;
      V v_op_2427 = heff_dup(v_a_2424);
      V v_op_27_2428 = heff_dup(v_b_2425);
      HeffT2 v_t_2430 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam6, 1, 1, (V[]){v_op_2427}), heff_rfield(v_f_2426, 0)));
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        V v_t_2440;
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_g_2433 = v_field_2432;
          V v_t_2434 = heff_get_n(v_g_2433, 3, 5);
          if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
            heff_drop(v_t_2434);
            HeffT2 v_t_2436 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam7, 1, 1, (V[]){v_op_27_2428}); V b_1 = heff_get_n(v_f_2426, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_2438 = v_t_2436.f[1];
              int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
              if ((v_tag_2437 == ((int64_t)0ULL))) {
                V v_g_2439 = v_field_2438;
                v_t_2440 = heff_get_n(v_g_2439, 3, 5);
              } else {
                heff_drop(v_field_2438);
                v_t_2440 = NTAG(TAG_False);
              }
            }
          } else {
            heff_drop_rec(v_f_2426, 2);
            heff_drop(v_op_27_2428);
            heff_drop(v_t_2434);
            v_t_2440 = NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_f_2426, 2);
          heff_drop(v_op_27_2428);
          heff_drop(v_field_2432);
          v_t_2440 = NTAG(TAG_False);
        }
        V v_msg_2443;
        if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
          heff_drop(v_t_2440);
          V v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str5), v_a_2424), ((V)&g_heff_2esyntax_2esurface_2efirstS_str6));
          v_msg_2443 = heff_strAppend(heff_strAppend(v_t_2441, v_b_2425), ((V)&g_heff_2esyntax_2esurface_2efirstS_str7));
        } else {
          heff_drop(v_t_2440);
          V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str8), v_a_2424), ((V)&g_heff_2esyntax_2esurface_2efirstS_str9));
          v_msg_2443 = heff_strAppend(heff_strAppend(v_t_2442, v_b_2425), ((V)&g_heff_2esyntax_2esurface_2efirstS_str10));
        }
        return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam8, 1, 2, (V[]){v_msg_2443, v_span_2423});
      }
    }
  }
  case TAG_Undeclared: {
    V v_x_2446 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      heff_drop(v_x_2446);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam9_clo);
    } else {
      V v_t_2449;
      if (heff_strEq_c(heff_dup(v_x_2446), heff_dup(heff_rfield(v_op_243, 1)))) {
        heff_drop_rec(v_before_242, 9);
        v_t_2449 = v_op_243;
      } else {
        heff_drop_rec(v_op_243, 9);
        v_t_2449 = v_before_242;
      }
      V v_start_2450 = heff_take_field(v_t_2449, 3);
      V v_end_2451 = heff_get_n(v_t_2449, 4, 9);
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam10, 1, 3, (V[]){v_x_2446, v_start_2450, v_end_2451});
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efirstS(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_245});
}
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_247});
}
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args) {
  V v_st_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_st_2410});
}
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args) {
  V v_st_2412 = args[0];
  V v_t_2413 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_st_2412});
}
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args) {
  V v_st_2415 = args[0];
  V v_before_242 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  V v_span_2414 = heff_env(self)[2];
  V v_t_2419;
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1)))) {
    heff_drop_rec(v_before_242, 9);
    V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str0), heff_get_n(v_op_243, 1, 9));
    v_t_2419 = heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurface_2efirstS_str1));
  } else {
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str2), heff_get_n(v_before_242, 1, 9));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_heff_2esyntax_2esurface_2efirstS_str3)), heff_get_n(v_op_243, 1, 9));
    v_t_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2esyntax_2esurface_2efirstS_str4));
  }
  V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2419, v_span_2414, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2420}), v_st_2415});
}
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args) {
  V v_st_2421 = args[0];
  V v_t_2422 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_st_2421});
}
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args) {
  V v_g_2429 = args[0];
  V v_op_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_op_2427; V b_1 = heff_get_n(v_g_2429, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, b_1)); heff_drop(v_op_2427); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args) {
  V v_g_2435 = args[0];
  V v_op_27_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_op_27_2428; V b_1 = heff_get_n(v_g_2435, 2, 5); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, b_1)); heff_drop(v_op_27_2428); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args) {
  V v_st_2444 = args[0];
  V v_msg_2443 = heff_env(self)[0];
  V v_span_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2443, v_span_2423, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2445}), v_st_2444});
}
V g_heff_2esyntax_2esurface_2efirstS_lam9(V self, V *args) {
  V v_st_2447 = args[0];
  V v_t_2448 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_st_2447});
}
V g_heff_2esyntax_2esurface_2efirstS_lam10(V self, V *args) {
  V v_st_2452 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_start_2450 = heff_env(self)[1];
  V v_end_2451 = heff_env(self)[2];
  V v_t_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str11), heff_dup(v_x_2446)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str12));
  heff_clo_take(self, 3);
  V v_t_2454 = heff_strAppend(heff_strAppend(v_t_2453, v_x_2446), ((V)&g_heff_2esyntax_2esurface_2efirstS_str13));
  V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2454, heff_rec_n(2, shape_start__end, (V[]){v_start_2450, v_end_2451}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2455}), v_st_2452});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str1, 22, "` is first defined at ");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str3, 22, "` is first defined at ");
V g_heff_2esyntax_2esurface_2edefinedStep_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefinedStep_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinedStep_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefinedStep_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edefinedStep_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefinedStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinedStep_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edefinedStep(V v_at_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Names: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_next_245 = heff_field(v_x3_242, 2);
    V v_msg_246 = heff_field(v_x3_242, 3);
    V v_prim_247 = heff_field(v_x3_242, 4);
    V v_seen_248 = heff_dup(heff_rfield(v_d_241, 0));
    HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_248, v_x_243));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_t_2413;
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2411;
        heff_drop(v_x_2412);
        v_t_2413 = v_seen_248;
      } else {
        heff_drop(v_field_2411);
        v_t_2413 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_248, heff_dup(v_x_243), heff_dup(v_sp_244)));
      }
      V v_prims_2414 = heff_dup(heff_rfield(v_d_241, 1));
      V v_t_2415;
      if ((heff_dup(v_prim_247) == NTAG(TAG_True))) {
        v_t_2415 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_prims_2414, heff_dup(v_x_243), NTAG(TAG_MkUnit)));
      } else {
        v_t_2415 = v_prims_2414;
      }
      V v_t_2439;
      if ((heff_dup(v_prim_247) == NTAG(TAG_True))) {
        HeffT2 v_t_2416 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_d_241, 1), v_x_243));
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            heff_drop(v_at_240);
            V v_x_2419 = v_field_2418;
            heff_drop(v_x_2419);
            v_t_2439 = ((V)&g_heff_2esyntax_2esurface_2edefinedStep_lam0_clo);
          } else {
            heff_drop(v_field_2418);
            HeffT2 v_t_2421 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_d_241, 0), v_x_243));
            {
              V v_field_2423 = v_t_2421.f[1];
              V v_tag_2422 = heff_box_i64(((int64_t)v_t_2421.f[0]));
              v_t_2439 = heff_clo_n(g_heff_2esyntax_2esurface_2edefinedStep_lam1, 1, 6, (V[]){v_tag_2422, v_field_2423, v_at_240, heff_dup(v_x_243), heff_dup(v_msg_246), heff_dup(v_sp_244)});
            }
          }
        }
      } else {
        HeffT2 v_t_2430 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_d_241, 0), v_x_243));
        {
          V v_field_2432 = v_t_2430.f[1];
          V v_tag_2431 = heff_box_i64(((int64_t)v_t_2430.f[0]));
          v_t_2439 = heff_clo_n(g_heff_2esyntax_2esurface_2edefinedStep_lam2, 1, 6, (V[]){v_tag_2431, v_field_2432, v_at_240, heff_dup(v_x_243), heff_dup(v_msg_246), heff_dup(v_sp_244)});
        }
      }
      V v_t_2440 = heff_tr(heff_call(v_t_2439, 1, (V[]){heff_take_field(v_d_241, 3)}));
      return ({ V rv_0 = v_t_2413; V rv_1 = v_t_2415; V rv_2 = heff_dup(v_next_245); V rv_3 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_d_241, 0ULL, 4, shape_seen__prims__open__diags, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    }
  }
  case TAG_Passes: {
    heff_drop(v_at_240);
    return v_d_241;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2edefinedStep(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2edefinedStep_lam0(V self, V *args) {
  V v_diags_2420 = args[0];
  return v_diags_2420;
}
V g_heff_2esyntax_2esurface_2edefinedStep_lam1(V self, V *args) {
  V v_diags_2424 = args[0];
  V v_tag_2422 = heff_env(self)[0];
  V v_field_2423 = heff_env(self)[1];
  V v_at_240 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_msg_246 = heff_env(self)[4];
  V v_sp_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_unbox_i64(v_tag_2422) == ((int64_t)0ULL))) {
    V v_first_2425 = v_field_2423;
    V v_t_2426 = heff_tr(heff_call(v_at_240, 1, (V[]){heff_get_n(v_first_2425, 0, 2)}));
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str0), v_x_243), ((V)&g_heff_2esyntax_2esurface_2edefinedStep_str1));
    V v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_t_2427, v_t_2426)});
    V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(153LL), NTAG(TAG_SError), v_msg_246, v_sp_244, v_t_2428});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_diags_2424});
  } else {
    heff_drop(v_field_2423);
    heff_drop(v_at_240);
    heff_drop(v_x_243);
    heff_drop(v_msg_246);
    heff_drop(v_sp_244);
    return v_diags_2424;
  }
}
V g_heff_2esyntax_2esurface_2edefinedStep_lam2(V self, V *args) {
  V v_diags_2433 = args[0];
  V v_tag_2431 = heff_env(self)[0];
  V v_field_2432 = heff_env(self)[1];
  V v_at_240 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_msg_246 = heff_env(self)[4];
  V v_sp_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_unbox_i64(v_tag_2431) == ((int64_t)0ULL))) {
    V v_first_2434 = v_field_2432;
    V v_t_2435 = heff_tr(heff_call(v_at_240, 1, (V[]){heff_get_n(v_first_2434, 0, 2)}));
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str2), v_x_243), ((V)&g_heff_2esyntax_2esurface_2edefinedStep_str3));
    V v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_t_2436, v_t_2435)});
    V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(153LL), NTAG(TAG_SError), v_msg_246, v_sp_244, v_t_2437});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_diags_2433});
  } else {
    heff_drop(v_field_2432);
    heff_drop(v_at_240);
    heff_drop(v_x_243);
    heff_drop(v_msg_246);
    heff_drop(v_sp_244);
    return v_diags_2433;
  }
}

HeffT3 g_heff_2esyntax_2esurface_2egroupFrom_24cpr(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_sp_240, 2);
    return ((HeffT3){{NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_it_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      V v_sp2_248 = heff_dup(heff_field(v_it_242, 4));
      V v_start_249 = heff_take_field(v_sp2_248, 0);
      V v_end_2410 = heff_get_n(v_sp2_248, 1, 2);
      v_t_2416 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(v_start_249)) && heff_intEq_c(heff_dup(heff_rfield(v_sp_240, 1)), heff_dup(v_end_2410))));
      heff_drop(v_start_249);
      heff_drop(v_end_2410);
      break;
    }
    case TAG_Eqn: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    case TAG_Whole: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    case TAG_Doc: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_t_2416);
      HeffT3 v_t_2417 = (g_heff_2esyntax_2esurface_2egroupFrom_24cpr(v_sp_240, v_rest_243));
      {
        V v_field_2418 = v_t_2417.f[0];
        V v_field_2419 = v_t_2417.f[1];
        V v_field_2420 = v_t_2417.f[2];
        return ((HeffT3){{heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_242, v_field_2418}), v_field_2419, v_field_2420}});
      }
    } else {
      heff_drop(v_t_2416);
      V v_t_2453;
      switch (heff_tag_of(v_it_242)) {
      case TAG_Sig: {
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      case TAG_Eqn: {
        v_t_2453 = NTAG(TAG_False);
        break;
      }
      case TAG_Whole: {
        V v_d_2429 = heff_dup(heff_field(v_it_242, 0));
        switch (heff_tag_of(v_d_2429)) {
        case TAG_At: {
          V v_x11_2430 = heff_field(v_d_2429, 0);
          heff_take_n(v_d_2429, 1ULL, 2);
          switch (heff_tag_of(v_x11_2430)) {
          case TAG_DeclEquations: {
            heff_take_n(v_x11_2430, 0ULL, 5);
            v_t_2453 = NTAG(TAG_False);
            break;
          }
          case TAG_DeclDefine: {
            heff_take_n(v_x11_2430, 0ULL, 5);
            v_t_2453 = NTAG(TAG_False);
            break;
          }
          case TAG_DeclTheory: {
            heff_take_n(v_x11_2430, 0ULL, 4);
            v_t_2453 = NTAG(TAG_False);
            break;
          }
          case TAG_DeclPrimitive: {
            heff_take_n(v_x11_2430, 0ULL, 3);
            v_t_2453 = NTAG(TAG_False);
            break;
          }
          case TAG_DeclTest: {
            heff_take_n(v_x11_2430, 0ULL, 2);
            v_t_2453 = NTAG(TAG_True);
            break;
          }
          case TAG_DeclWatch: {
            heff_take_n(v_x11_2430, 0ULL, 1);
            v_t_2453 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x11_2430);
          }
          break;
        }
        default: heff_nomatch(v_d_2429);
        }
        break;
      }
      case TAG_Doc: {
        v_t_2453 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it_242);
      }
      if ((heff_dup(v_t_2453) == NTAG(TAG_True))) {
        heff_drop(v_t_2453);
        HeffT3 v_t_2454 = (g_heff_2esyntax_2esurface_2egroupFrom_24cpr(v_sp_240, heff_dup(v_rest_243)));
        {
          V v_field_2455 = v_t_2454.f[0];
          V v_field_2456 = v_t_2454.f[1];
          V v_field_2457 = v_t_2454.f[2];
          V v_t_2458 = heff_dup(v_field_2455);
          switch (heff_tag_of(v_t_2458)) {
          case TAG_Nil: {
            heff_drop(v_field_2455);
            heff_drop(v_field_2456);
            heff_drop(v_field_2457);
            return ((HeffT3){{NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_it_242, v_rest_243})}});
          }
          case TAG_Cons: {
            heff_take_n(v_t_2458, 0ULL, 2);
            heff_drop(v_rest_243);
            return ((HeffT3){{v_field_2455, heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_242, v_field_2456}), v_field_2457}});
          }
          default: return ((HeffT3){{heff_nomatch(v_t_2458)}});
          }
        }
      } else {
        heff_drop_rec(v_sp_240, 2);
        heff_drop(v_t_2453);
        return ((HeffT3){{NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_it_242, v_rest_243})}});
      }
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str11, 0, "");
Clo g_heff_2esyntax_2esurface_2espreadGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2espreadGo_entry, 5, 0};

V g_heff_2esyntax_2esurface_2espreadGo(V v_waiting_240, V v_held_241, V v_open_242, V v_x4_243, V v_acc_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_open_242);
    V v_t_245 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
    V v_xs_246 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_245));
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  }
  case TAG_Cons: {
    V v_it_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_waiting_240)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_held_241)) {
      case TAG_Nil: {
        heff_drop(v_open_242);
        V v_g_2419;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          V v_sp_2413 = heff_dup(heff_field(v_it_247, 4));
          v_g_2419 = (g_heff_2esyntax_2esurface_2egroupFrom(v_sp_2413, heff_dup(v_rest_248)));
          break;
        }
        case TAG_Eqn: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        case TAG_Whole: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        case TAG_Doc: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        V v_sigs_2420 = heff_take_field(v_g_2419, 0);
        V v_held_2421 = heff_take_field(v_g_2419, 1);
        V v_rest_2422 = heff_get_n(v_g_2419, 2, 3);
        V v_t_2423 = heff_dup(v_sigs_2420);
        switch (heff_tag_of(v_t_2423)) {
        case TAG_Nil: {
          heff_drop(v_sigs_2420);
          heff_drop(v_held_2421);
          heff_drop(v_rest_2422);
          V t_0 = NTAG(TAG_Nil);
          V t_1 = NTAG(TAG_Nil);
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_rest_248;
          V t_4 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, v_acc_244});
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        }
        case TAG_Cons: {
          heff_take_n(v_t_2423, 0ULL, 2);
          heff_drop(v_rest_248);
          V t_0 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, v_sigs_2420});
          V t_1 = v_held_2421;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_rest_2422;
          V t_4 = v_acc_244;
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        }
        default: return heff_nomatch(v_t_2423);
        }
      }
      case TAG_Cons: {
        V v_t_2450;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          v_t_2450 = NTAG(TAG_False);
          break;
        }
        case TAG_Eqn: {
          switch (heff_tag_of(v_open_242)) {
          case TAG_Nothing: {
            v_t_2450 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_f_2436 = heff_dup(heff_field(v_open_242, 0));
            V v_t_2447;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              V v_f_2438 = heff_dup(heff_field(v_it_247, 1));
              v_t_2447 = v_f_2438;
              break;
            }
            case TAG_Eqn: {
              V v_f_2442 = heff_dup(heff_field(v_it_247, 0));
              v_t_2447 = v_f_2442;
              break;
            }
            case TAG_Whole: {
              v_t_2447 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str0);
              break;
            }
            case TAG_Doc: {
              v_t_2447 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str1);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            v_t_2450 = heff_bool(heff_strEq_c_lent(v_f_2436, v_t_2447, 0));
            heff_drop(v_f_2436);
            heff_drop(v_t_2447);
            break;
          }
          default: heff_nomatch(v_open_242);
          }
          break;
        }
        case TAG_Whole: {
          v_t_2450 = NTAG(TAG_False);
          break;
        }
        case TAG_Doc: {
          v_t_2450 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
          heff_drop(v_t_2450);
          V t_0 = v_waiting_240;
          V t_1 = v_held_241;
          V t_2 = v_open_242;
          V t_3 = v_rest_248;
          V t_4 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, v_acc_244});
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2450);
          V v_t_2461;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            v_t_2461 = NTAG(TAG_False);
            break;
          }
          case TAG_Eqn: {
            v_t_2461 = NTAG(TAG_True);
            break;
          }
          case TAG_Whole: {
            v_t_2461 = NTAG(TAG_False);
            break;
          }
          case TAG_Doc: {
            v_t_2461 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
            heff_drop(v_open_242);
            heff_drop(v_t_2461);
            V v_t_2472;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              V v_f_2463 = heff_dup(heff_field(v_it_247, 1));
              v_t_2472 = v_f_2463;
              break;
            }
            case TAG_Eqn: {
              V v_f_2467 = heff_dup(heff_field(v_it_247, 0));
              v_t_2472 = v_f_2467;
              break;
            }
            case TAG_Whole: {
              v_t_2472 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str2);
              break;
            }
            case TAG_Doc: {
              v_t_2472 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str3);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            HeffT3 v_t_2473 = ({ V a_0 = v_t_2472; V a_1 = heff_dup(v_waiting_240); HeffT3 r_ = (g_heff_2esyntax_2esurface_2epickSig_24cpr(a_0, a_1)); heff_drop(v_t_2472); r_; });
            {
              V v_field_2475 = v_t_2473.f[1];
              V v_field_2476 = v_t_2473.f[2];
              int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
              if ((v_tag_2474 == ((int64_t)0ULL))) {
                V v_s_2477 = v_field_2475;
                V v_more_2478 = v_field_2476;
                V v_t_2489;
                switch (heff_tag_of(v_it_247)) {
                case TAG_Sig: {
                  V v_f_2480 = heff_dup(heff_field(v_it_247, 1));
                  v_t_2489 = v_f_2480;
                  break;
                }
                case TAG_Eqn: {
                  V v_f_2484 = heff_dup(heff_field(v_it_247, 0));
                  v_t_2489 = v_f_2484;
                  break;
                }
                case TAG_Whole: {
                  v_t_2489 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str4);
                  break;
                }
                case TAG_Doc: {
                  v_t_2489 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str5);
                  break;
                }
                default: heff_nomatch(v_it_247);
                }
                V v_t_2490 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, heff_tag_n(TAG_Cons, 2, (V[]){v_s_2477, v_acc_244})});
                V t_0 = v_more_2478;
                V t_1 = v_held_241;
                V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2489});
                V t_3 = v_rest_248;
                V t_4 = v_t_2490;
                v_waiting_240 = t_0;
                v_held_241 = t_1;
                v_open_242 = t_2;
                v_x4_243 = t_3;
                v_acc_244 = t_4;
                goto top;
              } else {
                heff_drop(v_field_2475);
                heff_drop(v_field_2476);
                V v_t_2491 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
                V v_t_2492 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_2491));
                V t_0 = NTAG(TAG_Nil);
                V t_1 = NTAG(TAG_Nil);
                V t_2 = NTAG(TAG_Nothing);
                V t_3 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_it_247, v_rest_248});
                V t_4 = v_t_2492;
                v_waiting_240 = t_0;
                v_held_241 = t_1;
                v_open_242 = t_2;
                v_x4_243 = t_3;
                v_acc_244 = t_4;
                goto top;
              }
            }
          } else {
            heff_drop(v_t_2461);
            V v_t_24125;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              v_t_24125 = NTAG(TAG_False);
              break;
            }
            case TAG_Eqn: {
              v_t_24125 = NTAG(TAG_False);
              break;
            }
            case TAG_Whole: {
              V v_d_24101 = heff_dup(heff_field(v_it_247, 0));
              switch (heff_tag_of(v_d_24101)) {
              case TAG_At: {
                V v_x11_24102 = heff_field(v_d_24101, 0);
                heff_take_n(v_d_24101, 1ULL, 2);
                switch (heff_tag_of(v_x11_24102)) {
                case TAG_DeclEquations: {
                  heff_take_n(v_x11_24102, 0ULL, 5);
                  v_t_24125 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclDefine: {
                  heff_take_n(v_x11_24102, 0ULL, 5);
                  v_t_24125 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclTheory: {
                  heff_take_n(v_x11_24102, 0ULL, 4);
                  v_t_24125 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclPrimitive: {
                  heff_take_n(v_x11_24102, 0ULL, 3);
                  v_t_24125 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclTest: {
                  heff_take_n(v_x11_24102, 0ULL, 2);
                  v_t_24125 = NTAG(TAG_True);
                  break;
                }
                case TAG_DeclWatch: {
                  heff_take_n(v_x11_24102, 0ULL, 1);
                  v_t_24125 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_x11_24102);
                }
                break;
              }
              default: heff_nomatch(v_d_24101);
              }
              break;
            }
            case TAG_Doc: {
              v_t_24125 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            if ((heff_dup(v_t_24125) == NTAG(TAG_True))) {
              heff_drop(v_t_24125);
              V t_0 = v_waiting_240;
              V t_1 = v_held_241;
              V t_2 = v_open_242;
              V t_3 = v_rest_248;
              V t_4 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, v_acc_244});
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            } else {
              heff_drop(v_open_242);
              heff_drop(v_t_24125);
              V v_t_24126 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
              V v_t_24127 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24126));
              V t_0 = NTAG(TAG_Nil);
              V t_1 = NTAG(TAG_Nil);
              V t_2 = NTAG(TAG_Nothing);
              V t_3 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_it_247, v_rest_248});
              V t_4 = v_t_24127;
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            }
          }
        }
      }
      default: return heff_nomatch(v_held_241);
      }
    }
    case TAG_Cons: {
      V v_t_24152;
      switch (heff_tag_of(v_it_247)) {
      case TAG_Sig: {
        v_t_24152 = NTAG(TAG_False);
        break;
      }
      case TAG_Eqn: {
        switch (heff_tag_of(v_open_242)) {
        case TAG_Nothing: {
          v_t_24152 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_f_24138 = heff_dup(heff_field(v_open_242, 0));
          V v_t_24149;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            V v_f_24140 = heff_dup(heff_field(v_it_247, 1));
            v_t_24149 = v_f_24140;
            break;
          }
          case TAG_Eqn: {
            V v_f_24144 = heff_dup(heff_field(v_it_247, 0));
            v_t_24149 = v_f_24144;
            break;
          }
          case TAG_Whole: {
            v_t_24149 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str6);
            break;
          }
          case TAG_Doc: {
            v_t_24149 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str7);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          v_t_24152 = heff_bool(heff_strEq_c_lent(v_f_24138, v_t_24149, 0));
          heff_drop(v_f_24138);
          heff_drop(v_t_24149);
          break;
        }
        default: heff_nomatch(v_open_242);
        }
        break;
      }
      case TAG_Whole: {
        v_t_24152 = NTAG(TAG_False);
        break;
      }
      case TAG_Doc: {
        v_t_24152 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it_247);
      }
      if ((heff_dup(v_t_24152) == NTAG(TAG_True))) {
        heff_drop(v_t_24152);
        V t_0 = v_waiting_240;
        V t_1 = v_held_241;
        V t_2 = v_open_242;
        V t_3 = v_rest_248;
        V t_4 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, v_acc_244});
        v_waiting_240 = t_0;
        v_held_241 = t_1;
        v_open_242 = t_2;
        v_x4_243 = t_3;
        v_acc_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_24152);
        V v_t_24163;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          v_t_24163 = NTAG(TAG_False);
          break;
        }
        case TAG_Eqn: {
          v_t_24163 = NTAG(TAG_True);
          break;
        }
        case TAG_Whole: {
          v_t_24163 = NTAG(TAG_False);
          break;
        }
        case TAG_Doc: {
          v_t_24163 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        if ((heff_dup(v_t_24163) == NTAG(TAG_True))) {
          heff_drop(v_open_242);
          heff_drop(v_t_24163);
          V v_t_24174;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            V v_f_24165 = heff_dup(heff_field(v_it_247, 1));
            v_t_24174 = v_f_24165;
            break;
          }
          case TAG_Eqn: {
            V v_f_24169 = heff_dup(heff_field(v_it_247, 0));
            v_t_24174 = v_f_24169;
            break;
          }
          case TAG_Whole: {
            v_t_24174 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str8);
            break;
          }
          case TAG_Doc: {
            v_t_24174 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str9);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          HeffT3 v_t_24175 = ({ V a_0 = v_t_24174; V a_1 = heff_dup(v_waiting_240); HeffT3 r_ = (g_heff_2esyntax_2esurface_2epickSig_24cpr(a_0, a_1)); heff_drop(v_t_24174); r_; });
          {
            V v_field_24177 = v_t_24175.f[1];
            V v_field_24178 = v_t_24175.f[2];
            int64_t v_tag_24176 = ((int64_t)v_t_24175.f[0]);
            if ((v_tag_24176 == ((int64_t)0ULL))) {
              heff_drop_tag(v_waiting_240, 2);
              V v_s_24179 = v_field_24177;
              V v_more_24180 = v_field_24178;
              V v_t_24191;
              switch (heff_tag_of(v_it_247)) {
              case TAG_Sig: {
                V v_f_24182 = heff_dup(heff_field(v_it_247, 1));
                v_t_24191 = v_f_24182;
                break;
              }
              case TAG_Eqn: {
                V v_f_24186 = heff_dup(heff_field(v_it_247, 0));
                v_t_24191 = v_f_24186;
                break;
              }
              case TAG_Whole: {
                v_t_24191 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str10);
                break;
              }
              case TAG_Doc: {
                v_t_24191 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str11);
                break;
              }
              default: heff_nomatch(v_it_247);
              }
              V v_t_24192 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, heff_tag_n(TAG_Cons, 2, (V[]){v_s_24179, v_acc_244})});
              V t_0 = v_more_24180;
              V t_1 = v_held_241;
              V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24191});
              V t_3 = v_rest_248;
              V t_4 = v_t_24192;
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            } else {
              heff_drop(v_field_24177);
              heff_drop(v_field_24178);
              V v_t_24193 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
              V v_t_24194 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24193));
              V t_0 = NTAG(TAG_Nil);
              V t_1 = NTAG(TAG_Nil);
              V t_2 = NTAG(TAG_Nothing);
              V t_3 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_it_247, v_rest_248});
              V t_4 = v_t_24194;
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            }
          }
        } else {
          heff_drop(v_t_24163);
          V v_t_24227;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            v_t_24227 = NTAG(TAG_False);
            break;
          }
          case TAG_Eqn: {
            v_t_24227 = NTAG(TAG_False);
            break;
          }
          case TAG_Whole: {
            V v_d_24203 = heff_dup(heff_field(v_it_247, 0));
            switch (heff_tag_of(v_d_24203)) {
            case TAG_At: {
              V v_x11_24204 = heff_field(v_d_24203, 0);
              heff_take_n(v_d_24203, 1ULL, 2);
              switch (heff_tag_of(v_x11_24204)) {
              case TAG_DeclEquations: {
                heff_take_n(v_x11_24204, 0ULL, 5);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclDefine: {
                heff_take_n(v_x11_24204, 0ULL, 5);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclTheory: {
                heff_take_n(v_x11_24204, 0ULL, 4);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclPrimitive: {
                heff_take_n(v_x11_24204, 0ULL, 3);
                v_t_24227 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclTest: {
                heff_take_n(v_x11_24204, 0ULL, 2);
                v_t_24227 = NTAG(TAG_True);
                break;
              }
              case TAG_DeclWatch: {
                heff_take_n(v_x11_24204, 0ULL, 1);
                v_t_24227 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_x11_24204);
              }
              break;
            }
            default: heff_nomatch(v_d_24203);
            }
            break;
          }
          case TAG_Doc: {
            v_t_24227 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          if ((heff_dup(v_t_24227) == NTAG(TAG_True))) {
            heff_drop(v_t_24227);
            V t_0 = v_waiting_240;
            V t_1 = v_held_241;
            V t_2 = v_open_242;
            V t_3 = v_rest_248;
            V t_4 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_it_247, v_acc_244});
            v_waiting_240 = t_0;
            v_held_241 = t_1;
            v_open_242 = t_2;
            v_x4_243 = t_3;
            v_acc_244 = t_4;
            goto top;
          } else {
            heff_drop(v_open_242);
            heff_drop(v_t_24227);
            V v_t_24228 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
            V v_t_24229 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24228));
            V t_0 = NTAG(TAG_Nil);
            V t_1 = NTAG(TAG_Nil);
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = heff_tag_re_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_it_247, v_rest_248});
            V t_4 = v_t_24229;
            v_waiting_240 = t_0;
            v_held_241 = t_1;
            v_open_242 = t_2;
            v_x4_243 = t_3;
            v_acc_244 = t_4;
            goto top;
          }
        }
      }
    }
    default: return heff_nomatch(v_waiting_240);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2espreadGo(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0, 2, ":=");

HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_f_2421 = heff_field(v_x12_2418, 0);
      V v_x122_2422 = heff_field(v_x12_2418, 1);
      switch (heff_tag_of(v_x122_2422)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_f_2421)) {
        case TAG_Atom: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EParen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Named: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Tup: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Seg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Braces: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Update: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EUSet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_InstB: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EFSet: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFDefault: {
          V v_eq_2461 = heff_field(v_f_2421, 1);
          if (heff_strEq_c(heff_dup(heff_rfield(v_eq_2461, 1)), ((V)&g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Sum: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ECon: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EField: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ENeg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ETilde: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_App: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Op: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Ops: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_OpRhs: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Ann: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_BVar: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_BImp: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_BAnn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_BPat: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Lam: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Case: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EAlt: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_If: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_Do: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ESBind: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ELet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ELetElse: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ELetMut: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EAssign: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EWhile: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EFor: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EJump: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EReturn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ENest: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EArrow: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_IfThen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ETry: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_ECatch: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EWith: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EWithBound: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        case TAG_EBinding: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_f_2421)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_f_2421)}});
        }
      }
      case TAG_Cons: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_2422)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWithBound: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBinding: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      V v_x121_2421 = heff_field(v_x12_2418, 0);
      switch (heff_tag_of(v_x121_2421)) {
      case TAG_Atom: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EParen: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Named: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Tup: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Seg: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Braces: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Update: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EUSet: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_InstB: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EFSet: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x12_2418)}});
      }
      case TAG_EFDefault: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Sum: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ECon: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EField: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ENeg: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ETilde: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_App: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Op: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Ops: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_OpRhs: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Ann: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BVar: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BImp: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BAnn: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BPat: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Lam: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Case: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EAlt: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_If: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Do: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ESBind: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ELet: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ELetElse: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ELetMut: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EAssign: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EWhile: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EFor: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EJump: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EReturn: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ENest: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EArrow: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_IfThen: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ETry: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ECatch: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EWith: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EWithBound: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EBinding: {
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x121_2421)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWithBound: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBinding: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(V v_lit_240, V v_lit_241, V v_m_242, V v_st_243) {
top: ;
  V v_x1_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    heff_take_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Left = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_245_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_247}), v_st_246}});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24Right = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      V v_x1_249 = heff_dup(v_x_248);
      V v_t_2474;
      switch (heff_tag_of(v_x1_249)) {
      case TAG_At: {
        V v_x11_2410 = heff_field(v_x1_249, 0);
        heff_take_n(v_x1_249, 1ULL, 2);
        switch (heff_tag_of(v_x11_2410)) {
        case TAG_EVar: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ENotationVar: {
          heff_take_n(v_x11_2410, 0ULL, 3);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ETag: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EInt: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EFloat: {
          heff_take_nf(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EString: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EBinary: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ERune: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EWord: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EApp: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EProject: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ENamed: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EPi: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ELam: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EAnn: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_True);
          break;
        }
        case TAG_ESpec: {
          heff_take_n(v_x11_2410, 0ULL, 4);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ESig: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ESum: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EStruct: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EUpdate: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EMatch: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ELetIn: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EDo: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ELocal: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EInvalid: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EAssign: {
          heff_take_n(v_x11_2410, 0ULL, 3);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EWhile: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EFor: {
          heff_take_n(v_x11_2410, 0ULL, 3);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EIfThen: {
          heff_take_n(v_x11_2410, 0ULL, 2);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EBreak: {
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EContinue: {
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EReturn: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ENest: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ELazy: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ETuple: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_ETry: {
          heff_take_n(v_x11_2410, 0ULL, 1);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EWith: {
          heff_take_n(v_x11_2410, 0ULL, 4);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        case TAG_EWithBound: {
          heff_take_n(v_x11_2410, 0ULL, 3);
          v_t_2474 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2410);
        }
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
        heff_drop(v_lit_240);
        heff_drop(v_lit_241);
        heff_drop(v_t_2474);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x11_245_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_248}), v_st_246}});
      } else {
        heff_drop_cell(v_ru_24x11_245_24Right, 1);
        heff_drop(v_t_2474);
        V v_t_2477;
        switch (heff_tag_of(v_x_248)) {
        case TAG_At: {
          V v_a_2476 = heff_field(v_x_248, 1);
          heff_take_n(v_x_248, 2ULL, 2);
          v_t_2477 = v_a_2476;
          break;
        }
        default: heff_nomatch(v_x_248);
        }
        V v_t_2478 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){v_lit_240, NTAG(TAG_SError), v_lit_241, v_t_2477, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2478}), v_st_246}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
  }
}
Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldDeclOf(V v_e_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_243 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EAnn: {
      V v_e11_244 = heff_field(v_e1_242, 0);
      V v_t_245 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      switch (heff_tag_of(v_e11_244)) {
      case TAG_At: {
        V v_e111_246 = heff_field(v_e11_244, 0);
        V v_xsp_247 = heff_field(v_e11_244, 1);
        heff_take_n(v_e11_244, 3ULL, 2);
        switch (heff_tag_of(v_e111_246)) {
        case TAG_EVar: {
          V v_x_248 = heff_field(v_e111_246, 0);
          heff_take_n(v_e111_246, 1ULL, 1);
          heff_drop_tag(v_e_240, 2);
          V v_t_2413;
          switch (heff_tag_of(v_d_241)) {
          case TAG_Nothing: {
            v_t_2413 = v_sp_243;
            break;
          }
          case TAG_Just: {
            V v_d_249 = heff_dup(heff_field(v_d_241, 0));
            V v_t_2412;
            switch (heff_tag_of(v_d_249)) {
            case TAG_At: {
              V v_s_2411 = heff_field(v_d_249, 1);
              heff_take_n(v_d_249, 2ULL, 2);
              v_t_2412 = v_s_2411;
              break;
            }
            default: heff_nomatch(v_d_249);
            }
            v_t_2413 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            break;
          }
          default: heff_nomatch(v_d_241);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclareField, 4, (V[]){v_x_248, v_xsp_247, v_t_245, v_d_241}), v_t_2413});
        }
        default: {
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_245);
          heff_drop(v_e111_246);
          heff_drop(v_xsp_247);
          V v_t_2416;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2415 = heff_dup(heff_field(v_e_240, 1));
            v_t_2416 = v_s_2415;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2416});
        }
        }
      }
      default: return heff_nomatch(v_e11_244);
      }
    }
    default: {
      heff_drop(v_d_241);
      heff_drop(v_e1_242);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2419;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2418 = heff_dup(heff_field(v_e_240, 1));
        v_t_2419 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2419});
    }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldDeclOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparenL_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eparenL_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eparenL_str2, 2, "->");
Clo g_heff_2esyntax_2esurface_2eparenL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparenL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eparenL(V v_r_240, V v_o_241, V v_e_242, V v_c_243, V v_z_244) {
top: ;
  V v_x1_245 = heff_dup(v_e_242);
  V v_t_24170;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Atom: {
    V v_t_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Atom = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_246, 0)), ((V)&g_heff_2esyntax_2esurface_2eparenL_str0))) {
      v_t_24170 = heff_tag_at_n(v_ru_24x1_245_24Atom, TAG_Just, 1, (V[]){v_t_246});
    } else {
      heff_drop_rec(v_t_246, 9);
      heff_drop_cell(v_ru_24x1_245_24Atom, 1);
      v_t_24170 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_EParen: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Named: {
    heff_take_n(v_x1_245, 0ULL, 5);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Tup: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Seg: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Braces: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Update: {
    heff_take_n(v_x1_245, 0ULL, 6);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_InstB: {
    heff_take_n(v_x1_245, 0ULL, 5);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Sum: {
    heff_take_n(v_x1_245, 0ULL, 5);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECon: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EField: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_App: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Op: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Ops: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Ann: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_BVar: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_BImp: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_245, 0ULL, 5);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_BPat: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Lam: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Case: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_If: {
    heff_take_n(v_x1_245, 0ULL, 6);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Do: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_x1_245, 0ULL, 6);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_245, 0ULL, 7);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_245, 0ULL, 6);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFor: {
    heff_take_n(v_x1_245, 0ULL, 6);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EJump: {
    heff_take_n(v_x1_245, 0ULL, 1);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ENest: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_245, 0ULL, 2);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETry: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_245, 0ULL, 4);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EWith: {
    heff_take_n(v_x1_245, 0ULL, 6);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EWithBound: {
    heff_take_n(v_x1_245, 0ULL, 5);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EBinding: {
    heff_take_n(v_x1_245, 0ULL, 3);
    v_t_24170 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  switch (heff_tag_of(v_t_24170)) {
  case TAG_Nothing: {
    V v_m_24171 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_242}));
    V v_x1_24172 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_24172)) {
    case TAG_MkPair: {
      V v_x11_24173 = heff_field(v_x1_24172, 0);
      V v_st_24174 = heff_field(v_x1_24172, 1);
      V v_ru_24x1_24172_24MkPair = heff_take_reuse_n(v_x1_24172, 3ULL, 2);
      switch (heff_tag_of(v_x11_24173)) {
      case TAG_Left: {
        V v_e_24175 = heff_field(v_x11_24173, 0);
        V v_ru_24x11_24173_24Left = heff_take_reuse_n(v_x11_24173, 1ULL, 1);
        heff_drop_rec(v_c_243, 9);
        return heff_tag_re_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24173_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24175}), v_st_24174});
      }
      case TAG_Right: {
        V v_x_24176 = heff_field(v_x11_24173, 0);
        V v_ru_24x11_24173_24Right = heff_take_reuse_n(v_x11_24173, 1ULL, 1);
        V v_xs_24177 = heff_dup(heff_rfield(v_st_24174, 0));
        V v_i_24178 = heff_intAdd(heff_get_n(v_c_243, 7, 9), MK_INT(1LL));
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_24178, 1) && heff_intLt_c_lent(v_i_24178, heff_arrayLength_lent(v_xs_24177, 0), 2))) {
          V v_u_24179 = heff_arrayIndex(v_xs_24177, v_i_24178);
          V v_kind_24180 = heff_take_field(v_u_24179, 0);
          V v_text_24181 = heff_get_n(v_u_24179, 1, 9);
          if ((heff_strEq_c_lent(v_kind_24180, ((V)&g_heff_2esyntax_2esurface_2eparenL_str1), 2) && heff_strEq_c_lent(v_text_24181, ((V)&g_heff_2esyntax_2esurface_2eparenL_str2), 2))) {
            heff_drop_cell(v_ru_24x11_24173_24Right, 1);
            heff_drop(v_kind_24180);
            heff_drop(v_text_24181);
            V v_t_24182 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_24176));
            return (g_heff_2esyntax_2esurface_2easBinderOn_24tok2(v_ru_24x1_24172_24MkPair, v_t_24182, v_st_24174));
          } else {
            heff_drop(v_kind_24180);
            heff_drop(v_text_24181);
            return heff_tag_re_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24173_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24176}), v_st_24174});
          }
        } else {
          heff_drop(v_xs_24177);
          heff_drop(v_i_24178);
          return heff_tag_re_n(v_ru_24x1_24172_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24173_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24176}), v_st_24174});
        }
      }
      default: return heff_nomatch(v_x11_24173);
      }
    }
    default: return heff_nomatch(v_x1_24172);
    }
  }
  case TAG_Just: {
    V v_t_24183 = heff_field(v_t_24170, 0);
    V v_ru_24t_24170_24Just = heff_take_reuse_n(v_t_24170, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_e_242);
    heff_drop_rec(v_c_243, 9);
    V v_text_24184 = heff_take_field(v_t_24183, 1);
    V v_start_24185 = heff_take_field(v_t_24183, 3);
    V v_end_24186 = heff_get_n(v_t_24183, 4, 9);
    V v_t_24187 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24t_24170_24Just, TAG_EVar, 1, (V[]){v_text_24184}), heff_rec_n(2, shape_start__end, (V[]){v_start_24185, v_end_24186})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24187}), v_z_244});
  }
  default: return heff_nomatch(v_t_24170);
  }
}
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eparenL(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0, 64, "a unit is what a size counts: say the size, `x::size(4)-unit(8)`");

HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_s_244, 0));
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_v_243)) {
    case TAG_StrValue: {
      v_t_249 = NTAG(TAG_SegmentBinary);
      break;
    }
    case TAG_IntValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    case TAG_FloatValue: {
      v_t_249 = NTAG(TAG_SegmentFloat);
      break;
    }
    case TAG_RuneValue: {
      v_t_249 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_OtherValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    break;
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_249 = v_t_248;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_249, v_st_245));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_x11_2413 = v_field_2411;
    V v_st_2414 = v_field_2412;
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      V v_e_2415 = heff_field(v_x11_2413, 0);
      V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
      heff_drop(v_inPat_240);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      heff_drop_rec(v_s_244, 5);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2413_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2415}), v_st_2414}});
    }
    case TAG_Right: {
      V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 0ULL, 1);
      V v_t_2417 = heff_dup(heff_rfield(v_s_244, 1));
      V v_x11_2428;
      V v_st_2429;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_SizeDefault: {
        V v_t_2418 = heff_dup(heff_rfield(v_s_244, 2));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          v_x11_2428 = v_t_2419;
          v_st_2429 = v_st_2414;
          break;
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2413_24Right, 1);
          V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0), heff_dup(v_sp_241), NTAG(TAG_Nothing)});
          v_x11_2428 = heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2421});
          v_st_2429 = v_st_2414;
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      case TAG_SizeNumber: {
        heff_take_n(v_t_2417, 0ULL, 1);
        V v_t_2423 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_x11_2428 = v_t_2423;
        v_st_2429 = v_st_2414;
        break;
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2417, 0ULL, 3);
        V v_t_2427 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_x11_2428 = v_t_2427;
        v_st_2429 = v_st_2414;
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      switch (heff_tag_of(v_x11_2428)) {
      case TAG_Left: {
        V v_e_2430 = heff_field(v_x11_2428, 0);
        V v_ru_24x11_2428_24Left = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
        heff_drop(v_inPat_240);
        heff_drop(v_sp_241);
        heff_drop(v_e_242);
        heff_drop(v_v_243);
        heff_drop_rec(v_s_244, 5);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2428_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2430}), v_st_2429}});
      }
      case TAG_Right: {
        V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 0ULL, 1);
        V v_t_2432 = heff_dup(heff_rfield(v_s_244, 0));
        V v_t_2435;
        switch (heff_tag_of(v_t_2432)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            v_t_2435 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            v_t_2435 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            v_t_2435 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2435 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            v_t_2435 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          break;
        }
        case TAG_Just: {
          V v_t_2434 = heff_field(v_t_2432, 0);
          heff_take_n(v_t_2432, 1ULL, 1);
          v_t_2435 = v_t_2434;
          break;
        }
        default: heff_nomatch(v_t_2432);
        }
        V v_t_2436 = heff_dup(heff_rfield(v_s_244, 0));
        V v_t_2439;
        switch (heff_tag_of(v_t_2436)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            v_t_2439 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            v_t_2439 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            v_t_2439 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2439 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            v_t_2439 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          break;
        }
        case TAG_Just: {
          V v_t_2438 = heff_field(v_t_2436, 0);
          heff_take_n(v_t_2436, 1ULL, 1);
          v_t_2439 = v_t_2438;
          break;
        }
        default: heff_nomatch(v_t_2436);
        }
        V v_unit_2440 = ({ V a_0 = v_t_2439; V a_1 = heff_rfield(v_s_244, 2); V r_ = (g_heff_2esyntax_2esurface_2eunitIn(a_0, a_1)); heff_drop(v_t_2439); r_; });
        V v_t_2441 = heff_dup(heff_rfield(v_s_244, 1));
        V v_t_2446;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_SizeDefault: {
          heff_drop(v_unit_2440);
          v_t_2446 = NTAG(TAG_SizeDefault);
          break;
        }
        case TAG_SizeNumber: {
          V v_n_2442 = heff_field(v_t_2441, 0);
          V v_ru_24t_2441_24SizeNumber = heff_take_reuse_n(v_t_2441, 1ULL, 1);
          v_t_2446 = heff_tag_at_n(v_ru_24t_2441_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2442, v_unit_2440)});
          break;
        }
        case TAG_SizeName: {
          V v_x_2443 = heff_field(v_t_2441, 0);
          V v_xsp_2444 = heff_field(v_t_2441, 1);
          V v_ru_24t_2441_24SizeName = heff_take_reuse_n(v_t_2441, 3ULL, 3);
          v_t_2446 = heff_tag_re_n(v_ru_24t_2441_24SizeName, TAG_SizeName, 3, 3ULL, (V[]){v_x_2443, v_xsp_2444, v_unit_2440});
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        HeffT2 v_t_2447 = (g_heff_2esyntax_2esurface_2etypeChecks_24cpr(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), heff_dup(v_s_244), v_t_2435, v_t_2446, v_st_2429));
        {
          V v_field_2448 = v_t_2447.f[0];
          V v_field_2449 = v_t_2447.f[1];
          V v_x11_2450 = v_field_2448;
          V v_st_2451 = v_field_2449;
          switch (heff_tag_of(v_x11_2450)) {
          case TAG_Left: {
            V v_e_2452 = heff_field(v_x11_2450, 0);
            V v_ru_24x11_2450_24Left = heff_take_reuse_n(v_x11_2450, 1ULL, 1);
            heff_drop(v_sp_241);
            heff_drop(v_e_242);
            heff_drop(v_v_243);
            heff_drop_rec(v_s_244, 5);
            heff_drop_cell(v_ru_24x11_2428_24Right, 1);
            return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2450_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2452}), v_st_2451}});
          }
          case TAG_Right: {
            V v_ru_24x11_2450_24Right = heff_take_reuse_n(v_x11_2450, 0ULL, 1);
            V v_t_2454 = heff_dup(heff_rfield(v_s_244, 0));
            V v_t_2457;
            switch (heff_tag_of(v_t_2454)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_v_243)) {
              case TAG_StrValue: {
                heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                v_t_2457 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                v_t_2457 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                v_t_2457 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2457 = heff_tag_at_n(v_ru_24x11_2450_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                heff_drop_cell(v_ru_24x11_2450_24Right, 1);
                v_t_2457 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_243);
              }
              break;
            }
            case TAG_Just: {
              V v_t_2456 = heff_field(v_t_2454, 0);
              heff_take_n(v_t_2454, 1ULL, 1);
              heff_drop_cell(v_ru_24x11_2450_24Right, 1);
              v_t_2457 = v_t_2456;
              break;
            }
            default: heff_nomatch(v_t_2454);
            }
            V v_t_2458 = heff_take_field(v_s_244, 0);
            V v_t_2461;
            switch (heff_tag_of(v_t_2458)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_v_243)) {
              case TAG_StrValue: {
                v_t_2461 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                heff_take_n(v_v_243, 0ULL, 1);
                v_t_2461 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                v_t_2461 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2461 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                v_t_2461 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_243);
              }
              break;
            }
            case TAG_Just: {
              V v_t_2460 = heff_field(v_t_2458, 0);
              heff_take_n(v_t_2458, 1ULL, 1);
              heff_drop(v_v_243);
              v_t_2461 = v_t_2460;
              break;
            }
            default: heff_nomatch(v_t_2458);
            }
            V v_unit_2462 = ({ V a_0 = v_t_2461; V a_1 = heff_rfield(v_s_244, 2); V r_ = (g_heff_2esyntax_2esurface_2eunitIn(a_0, a_1)); heff_drop(v_t_2461); r_; });
            V v_t_2463 = heff_take_field(v_s_244, 1);
            V v_t_2468;
            switch (heff_tag_of(v_t_2463)) {
            case TAG_SizeDefault: {
              heff_drop(v_unit_2462);
              v_t_2468 = NTAG(TAG_SizeDefault);
              break;
            }
            case TAG_SizeNumber: {
              V v_n_2464 = heff_field(v_t_2463, 0);
              V v_ru_24t_2463_24SizeNumber = heff_take_reuse_n(v_t_2463, 1ULL, 1);
              v_t_2468 = heff_tag_at_n(v_ru_24t_2463_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2464, v_unit_2462)});
              break;
            }
            case TAG_SizeName: {
              V v_x_2465 = heff_field(v_t_2463, 0);
              V v_xsp_2466 = heff_field(v_t_2463, 1);
              V v_ru_24t_2463_24SizeName = heff_take_reuse_n(v_t_2463, 3ULL, 3);
              v_t_2468 = heff_tag_re_n(v_ru_24t_2463_24SizeName, TAG_SizeName, 3, 3ULL, (V[]){v_x_2465, v_xsp_2466, v_unit_2462});
              break;
            }
            default: heff_nomatch(v_t_2463);
            }
            V v_t_2469 = heff_take_field(v_s_244, 3);
            V v_t_2471;
            switch (heff_tag_of(v_t_2469)) {
            case TAG_Nothing: {
              v_t_2471 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              V v_b_2470 = heff_field(v_t_2469, 0);
              heff_take_n(v_t_2469, 1ULL, 1);
              v_t_2471 = v_b_2470;
              break;
            }
            default: heff_nomatch(v_t_2469);
            }
            V v_t_2472 = heff_get_n(v_s_244, 4, 5);
            V v_t_2474;
            switch (heff_tag_of(v_t_2472)) {
            case TAG_Nothing: {
              v_t_2474 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              V v_b_2473 = heff_field(v_t_2472, 0);
              heff_take_n(v_t_2472, 1ULL, 1);
              v_t_2474 = v_b_2473;
              break;
            }
            default: heff_nomatch(v_t_2472);
            }
            V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2457, v_t_2468, v_t_2471, v_t_2474}), v_sp_241});
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){v_t_2475}), v_st_2451}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2450)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2428)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str1, 33, "` is named twice in one signature");

HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_n_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s935688233x1434116625(heff_dup(v_n_242), v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_seen_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str0), heff_take_field(v_n_242, 0));
      V v_f_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_245, ((V)&g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str1)), heff_get_n(v_n_242, 1, 2), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_t_244);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_n_242, 0, 2), v_seen_240});
      V t_0 = v_t_247;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2edefaultL_24cpr(V v_r_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
    return ((HeffT2){{v_t_243, v_z_242}});
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      V v_x1_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x11_249 = heff_field(v_x1_248, 0);
        V v_st_2410 = heff_field(v_x1_248, 1);
        heff_take_n(v_x1_248, 3ULL, 2);
        switch (heff_tag_of(v_x11_249)) {
        case TAG_Left: {
          V v_e_2411 = heff_field(v_x11_249, 0);
          V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x11_249_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2411}), v_st_2410}});
        }
        case TAG_Right: {
          V v_x_2412 = heff_field(v_x11_249, 0);
          V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
          V v_t_2413 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_2412})});
          return ((HeffT2){{v_t_2413, v_st_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_249)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2emutualDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualDefs_entry, 1, 0};

V g_heff_2esyntax_2esurface_2emutualDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V v_f_244 = heff_field(v_x11_241, 1);
      V v_fsp_245 = heff_field(v_x11_241, 2);
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_sp_247 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 30ULL, 5);
      V v_start_248 = heff_take_field(v_sp_247, 0);
      V v_end_249 = heff_take_field(v_sp_247, 1);
      HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_244, heff_dup(v_rest_242)));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_es_2413 = v_field_2412;
          V v_end_2414 = heff_take_field(v_es_2413, 1);
          V v_eqns_2415 = heff_get_n(v_es_2413, 0, 2);
          V v_a_2416 = v_start_248;
          V v_a_2417 = v_end_249;
          V v_b_2418 = v_end_2414;
          V v_t_2419;
          if (heff_intLt_c_lent(v_a_2417, v_b_2418, 0)) {
            heff_drop(v_a_2417);
            v_t_2419 = v_b_2418;
          } else {
            heff_drop(v_b_2418);
            v_t_2419 = v_a_2417;
          }
          V v_t_2420 = heff_rec_n(5, shape_name__span__ty__eqns__whole, (V[]){v_f_244, v_fsp_245, v_ty_246, v_eqns_2415, ({ V rv_0 = v_a_2416; V rv_1 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_sp_247, 0ULL, 2, shape_start__end, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; })});
          V v_cell_2421 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), heff_hole()});
          V v_u_2422 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, v_cell_2421));
          heff_drop(v_u_2422);
          return v_cell_2421;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_f_244);
          heff_drop(v_fsp_245);
          heff_drop(v_ty_246);
          heff_drop_rec(v_sp_247, 2);
          heff_drop(v_start_248);
          heff_drop(v_end_249);
          heff_drop(v_field_2412);
          V t_0 = v_rest_242;
          v_x1_240 = t_0;
          goto top;
        }
      }
    }
    case TAG_Eqn: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Whole: {
      V v_cell_2427 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_241}), heff_hole()});
      V v_u_2428 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, v_cell_2427));
      heff_drop(v_u_2428);
      return v_cell_2427;
    }
    case TAG_Doc: {
      V v_cell_2430 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_241}), heff_hole()});
      V v_u_2431 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, v_cell_2430));
      heff_drop(v_u_2431);
      return v_cell_2430;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualDefs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunevenAt_str0, 19, "every equation of `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunevenAt_str1, 6, "` has ");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunevenAt_str2, 40, " pattern(s), as its first: this one has ");
Clo g_heff_2esyntax_2esurface_2eunevenAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunevenAt_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunevenAt(V v_f_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_At: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      V v_sp_246 = heff_field(v_x31_243, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_MkEquation: {
        V v_pats_249 = heff_field(v_x311_245, 2);
        V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_pats_249));
        if (heff_intEq_c_lent(v_t_2411, v_n_241, 1)) {
          V t_0 = v_f_240;
          V t_1 = v_n_241;
          V t_2 = v_rest_244;
          v_f_240 = t_0;
          v_n_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_pats_249));
          V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eunevenAt_str0), v_f_240), ((V)&g_heff_2esyntax_2esurface_2eunevenAt_str1));
          V v_t_2414 = heff_strAppend(v_t_2413, heff_intShow(v_n_241));
          V v_msg_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2esurface_2eunevenAt_str2)), heff_intShow(v_t_2412));
          V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2415, heff_dup(v_sp_246), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
        }
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eunevenAt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eunevenAt(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V v_names_240, V v_pats_241, V v_rhs_242, V v_w_243, V v_st_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_240));
  {
    V v_field_246 = v_t_245.f[0];
    heff_drop(v_t_245.f[1]);
    V v_f_248 = v_field_246;
    HeffT2 v_t_249 = ({ V a_0 = heff_rfield(v_st_244, 3); V a_1 = v_f_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_t_2413;
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2412 = v_field_2411;
        v_t_2413 = v_x_2412;
      } else {
        heff_drop(v_field_2411);
        v_t_2413 = NTAG(TAG_Nil);
      }
      V v_t_2414 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2413));
      V v_st_2415 = (g_heff_2esyntax_2esurface_2esetPatVars(v_t_2414, v_st_244));
      V v_t_2416 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 1)), heff_dup(v_pats_241)));
      V v_x1_2417 = heff_tr(heff_call(v_t_2416, 1, (V[]){v_st_2415}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_pats_241);
          heff_drop(v_rhs_242);
          heff_drop(v_t_2413);
          heff_drop_cell(v_ru_24x1_2417_24MkPair, 2);
          return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2420}), v_st_2419}});
        }
        case TAG_Right: {
          V v_x_2421 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          V v_st_2422 = (g_heff_2esyntax_2esurface_2esetPatVars(NTAG(TAG_Nil), v_st_2419));
          V v_t_2423 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2413));
          V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2423}));
          V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_pats_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_241); r_; });
          V v_t_2426 = ({ V a_0 = v_t_2413; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2413); r_; });
          V v_t_2427 = (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x1_2417_24MkPair, v_t_2425, v_t_2426));
          return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2427, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0, 1, 4, (V[]){v_rhs_242, heff_dup(v_w_243), heff_dup(v_names_240), v_x_2421}), v_st_2422));
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2418)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2417)}});
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1(V self, V *args) {
  V v_st_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2433}), v_st_2434});
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2(V self, V *args) {
  V v_rhs_27_2439 = args[0];
  V v_z_2440 = args[1];
  V v_names_240 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  HeffT2 v_t_2441 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_240));
  {
    V v_field_2442 = v_t_2441.f[0];
    heff_drop(v_t_2441.f[1]);
    HeffT2 v_t_2444 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_240));
    {
      V v_field_2445 = v_t_2444.f[0];
      heff_drop(v_t_2444.f[1]);
      HeffT2 v_t_2447 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_names_240));
      {
        V v_field_2449 = v_t_2447.f[1];
        heff_drop(v_t_2447.f[0]);
        V v_t_2452;
        heff_clo_take(self, 2);
        switch (heff_tag_of(v_names_240)) {
        case TAG_Nil: {
          v_t_2452 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          V v_t_2450 = heff_dup(heff_field(v_names_240, 0));
          v_t_2452 = heff_get_n(v_t_2450, 3, 9);
          break;
        }
        default: heff_nomatch(v_names_240);
        }
        V v_t_2455;
        switch (heff_tag_of(v_rhs_27_2439)) {
        case TAG_At: {
          V v_s_2454 = heff_dup(heff_field(v_rhs_27_2439, 1));
          v_t_2455 = v_s_2454;
          break;
        }
        default: heff_nomatch(v_rhs_27_2439);
        }
        V v_t_2458;
        switch (heff_tag_of(v_names_240)) {
        case TAG_Nil: {
          v_t_2458 = MK_INT(0LL);
          break;
        }
        case TAG_Cons: {
          V v_t_2456 = heff_field(v_names_240, 0);
          heff_take_n(v_names_240, 1ULL, 2);
          v_t_2458 = heff_get_n(v_t_2456, 3, 9);
          break;
        }
        default: heff_nomatch(v_names_240);
        }
        V v_t_2461;
        switch (heff_tag_of(v_rhs_27_2439)) {
        case TAG_At: {
          V v_s_2460 = heff_dup(heff_field(v_rhs_27_2439, 1));
          v_t_2461 = v_s_2460;
          break;
        }
        default: heff_nomatch(v_rhs_27_2439);
        }
        V v_t_2462 = ({ V rv_0 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_t_2455, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_field_2445, v_field_2449, v_x_2421, v_rhs_27_2439}), v_t_2462});
        V v_t_2464 = ({ V rv_0 = v_t_2458; V rr_ = heff_rec_reuse_nf(v_t_2461, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_x_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Eqn, 3, (V[]){v_field_2442, v_t_2463, v_t_2464}), NTAG(TAG_Nil)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2465}), v_z_2440});
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args) {
  V v_st_2428 = args[0];
  V v_rhs_242 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_names_240 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2429 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_rhs_242, v_st_2428));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      V v_ru_24x11_2430_24Left = heff_take_reuse_n(v_x11_2430, 1ULL, 1);
      heff_drop(v_w_243);
      heff_drop(v_names_240);
      heff_drop(v_x_2421);
      return heff_tag_re_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2430_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_t_2438;
      switch (heff_tag_of(v_w_243)) {
      case TAG_Nothing: {
        v_t_2438 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1, 1, 1, (V[]){v_x_2433});
        break;
      }
      case TAG_Just: {
        V v_it1_2435 = heff_field(v_w_243, 0);
        heff_take_n(v_w_243, 1ULL, 1);
        switch (heff_tag_of(v_it1_2435)) {
        case TAG_MkPair: {
          V v_kw_2436 = heff_field(v_it1_2435, 0);
          V v_ds_2437 = heff_field(v_it1_2435, 1);
          heff_take_n(v_it1_2435, 3ULL, 2);
          v_t_2438 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo), 3, (V[]){v_kw_2436, v_ds_2437, v_x_2433}));
          break;
        }
        default: heff_nomatch(v_it1_2435);
        }
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_2429_24MkPair, v_t_2438, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2, 2, 2, (V[]){v_names_240, v_x_2421}), v_st_2431));
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str2, 1, "(");
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(v_e_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_f_244 = v_field_243;
      return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0, 1, 1, (V[]){v_f_244}), heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1, 2, 1, (V[]){v_e_240})});
    } else {
      heff_drop(v_field_243);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2, 1, 1, (V[]){v_e_240});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_f_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_f_244, v_st_245));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_247_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2410));
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2411}));
      return (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(v_ru_24x1_246_24MkPair, MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0), v_t_2412, v_st_248));
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args) {
  V v_d_2413 = args[0];
  V v_z_2414 = args[1];
  V v_e_240 = heff_env(self)[0];
  HeffT2 v_t_2415 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(v_d_2413));
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop(v_d_2413);
      V v_q_2418 = v_field_2417;
      V v_name_2419 = heff_take_field(v_q_2418, 0);
      V v_span_2420 = heff_take_field(v_q_2418, 1);
      V v_ty_2421 = heff_get_n(v_q_2418, 2, 3);
      V v_a_2422 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
      heff_clo_take(self, 1);
      V v_b_2423 = (g_heff_2esyntax_2ecst_2elastE(v_e_240));
      V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2422, 3, 9), heff_get_n(v_b_2423, 4, 9)});
      V v_x_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_name_2419, v_span_2420, v_ty_2421}), v_t_2424});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2425}), v_z_2414});
    } else {
      heff_drop(self);
      heff_drop(v_field_2417);
      V v_t_2428;
      switch (heff_tag_of(v_d_2413)) {
      case TAG_At: {
        V v_s_2427 = heff_field(v_d_2413, 1);
        heff_take_n(v_d_2413, 2ULL, 2);
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_d_2413);
      }
      V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1), v_t_2428, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2429}), v_z_2414});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam3(V self, V *args) {
  V v_st_2438 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2435}), v_st_2438});
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args) {
  V v_st_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x1_2431 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_240), v_st_2430));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Left = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      heff_drop(self);
      return heff_tag_re_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2432_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_t_2436 = ({ V a_0 = v_e_240; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_240); r_; });
      V v_m_2439;
      if (heff_strEq_c(heff_get_n(v_t_2436, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str2))) {
        V v_t_2437 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2435));
        v_m_2439 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2437}));
      } else {
        v_m_2439 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam3, 1, 1, (V[]){v_x_2435});
      }
      V v_x1_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2433}));
      switch (heff_tag_of(v_x1_2440)) {
      case TAG_MkPair: {
        V v_x11_2441 = heff_field(v_x1_2440, 0);
        V v_st_2442 = heff_field(v_x1_2440, 1);
        heff_take_n(v_x1_2440, 3ULL, 2);
        switch (heff_tag_of(v_x11_2441)) {
        case TAG_Left: {
          V v_e_2443 = heff_field(v_x11_2441, 0);
          heff_take_n(v_x11_2441, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Left, 1, (V[]){v_e_2443}), v_st_2442});
        }
        case TAG_Right: {
          V v_x_2444 = heff_field(v_x11_2441, 0);
          heff_take_n(v_x11_2441, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_2432_24Right, 1);
          return ({ V a_0 = v_ru_24x1_2431_24MkPair; V a_1 = v_x_2444; V a_2 = v_st_2442; V r_ = (g_heff_2esyntax_2esurface_2eparamOf_24tok2(a_0, a_1, a_2)); heff_drop(v_x_2444); r_; });
        }
        default: return heff_nomatch(v_x11_2441);
        }
      }
      default: return heff_nomatch(v_x1_2440);
      }
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_fields_244, V v_z_245) {
top: ;
  V v_text_246 = heff_take_field(v_name_242, 1);
  V v_start_247 = heff_take_field(v_name_242, 3);
  V v_end_248 = heff_get_n(v_name_242, 4, 9);
  V v_m_249 = (g_prelude_2etraverse_24s518454301x170091462(v_params_243));
  V v_x1_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    heff_take_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_fields_244);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2411_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2413}), v_st_2412}});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2414)));
      V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0, 1, 1, (V[]){v_fields_244}), heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam1, 2, 6, (V[]){v_d_240, v_kw_241, v_text_246, v_start_247, v_end_248, v_x_2414})}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2415, v_t_2439, v_st_2412));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2411)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2410)}});
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args) {
  V v_st_2416 = args[0];
  V v_fields_244 = heff_env(self)[0];
  V v_t_2417 = heff_dup(heff_rfield(v_st_2416, 1));
  heff_clo_take(self, 1);
  HeffT2 v_t_2418 = (g_prelude_2etraverse_24s956608878x365908798_24cpr(v_fields_244, v_st_2416));
  {
    V v_field_2419 = v_t_2418.f[0];
    V v_field_2420 = v_t_2418.f[1];
    V v_x11_2421 = v_field_2419;
    V v_st_2422 = v_field_2420;
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x11_2421, 0);
      V v_ru_24x11_2421_24Left = heff_take_reuse_n(v_x11_2421, 1ULL, 1);
      heff_drop(v_t_2417);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2421_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2423}), v_st_2422});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x11_2421, 0);
      V v_ru_24x11_2421_24Right = heff_take_reuse_n(v_x11_2421, 1ULL, 1);
      V v_st_2425 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2417, v_st_2422));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2421_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_2424}), v_st_2425});
    }
    default: return heff_nomatch(v_x11_2421);
    }
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam1(V self, V *args) {
  V v_fields_27_2426 = args[0];
  V v_z_2427 = args[1];
  V v_d_240 = heff_env(self)[0];
  V v_kw_241 = heff_env(self)[1];
  V v_text_246 = heff_env(self)[2];
  V v_start_247 = heff_env(self)[3];
  V v_end_248 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_t_2428 = ({ V a_0 = v_fields_27_2426; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_fields_27_2426); r_; });
  V v_t_2429 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
  V v_e_2430 = heff_get_n(v_t_2429, 4, 9);
  heff_clo_take(self, 6);
  V v_t_2431 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
  V v_e_2432 = heff_get_n(v_t_2431, 4, 9);
  V v_t_2433 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2430});
  V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_t_2428}), v_t_2433});
  V v_t_2435 = heff_tag_n(TAG_DeclTheory, 4, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), v_x_2414, v_t_2434});
  V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2432});
  V v_t_2437 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, v_t_2436})});
  V v_x_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2438}), v_z_2427});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str2, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str3, 1, "`");
Clo g_heff_2esyntax_2esurface_2eprogGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprogGo_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eprogGo(V v_cs_240, V v_s_241, V v_items_242, V v_diags_243, V v_broken_244) {
top: ;
  V v_top_245 = heff_dup(heff_rfield(v_cs_240, 1));
  V v_start_246 = heff_dup(heff_rfield(v_cs_240, 1));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_248 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs_240, 0)), heff_dup(heff_rfield(v_cs_240, 1)), v_top_245, v_t_247, v_start_246});
  V v_t_249 = (g_heff_2esyntax_2ecst_2etokAt(v_t_248, heff_dup(heff_rfield(v_cs_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_249, 0, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str0))) {
    heff_drop_rec(v_cs_240, 5);
    V v_items_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_diags_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_diags_243));
    V v_broken_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_broken_244));
    return heff_rec_n(4, shape_items__diags__broken__arms, (V[]){v_items_2410, v_diags_2411, v_broken_2412, heff_get_n(v_s_241, 9, 10)});
  } else {
    V v_it_2413 = heff_tr(g_heff_2esyntax_2ecst_2edeclStep(v_cs_240));
    switch (heff_tag_of(v_it_2413)) {
    case TAG_MkPair: {
      V v_it1_2414 = heff_field(v_it_2413, 0);
      V v_cs2_2415 = heff_field(v_it_2413, 1);
      V v_ru_24it_2413_24MkPair = heff_take_reuse_n(v_it_2413, 3ULL, 2);
      switch (heff_tag_of(v_it1_2414)) {
      case TAG_Left: {
        V v_d_2416 = heff_field(v_it1_2414, 0);
        heff_take_n(v_it1_2414, 1ULL, 1);
        V v_t_2417 = (g_heff_2esyntax_2ecst_2eskipDecl(heff_dup(v_cs2_2415)));
        V v_t_2418 = (g_heff_2esyntax_2ecst_2edeclaredMore(heff_dup(v_cs2_2415)));
        HeffT2 v_t_2419 = (g_heff_2esyntax_2ecst_2edeclaredAt_24cpr(v_cs2_2415));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          V v_t_2423;
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_x_2422 = v_field_2421;
            v_t_2423 = heff_tag_at_n(v_ru_24it_2413_24MkPair, TAG_Cons, 2, (V[]){v_x_2422, v_broken_244});
          } else {
            heff_drop_cell(v_ru_24it_2413_24MkPair, 2);
            heff_drop(v_field_2421);
            v_t_2423 = v_broken_244;
          }
          V v_t_2424 = (g_heff_2esyntax_2esurface_2eappendRev(v_t_2418, v_t_2423));
          V t_0 = v_t_2417;
          V t_1 = v_s_241;
          V t_2 = v_items_242;
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2416, v_diags_243});
          V t_4 = v_t_2424;
          v_cs_240 = t_0;
          v_s_241 = t_1;
          v_items_242 = t_2;
          v_diags_243 = t_3;
          v_broken_244 = t_4;
          goto top;
        }
      }
      case TAG_Right: {
        V v_dc_2425 = heff_field(v_it1_2414, 0);
        heff_take_n(v_it1_2414, 1ULL, 1);
        V v_st_2426 = (g_heff_2esyntax_2esurface_2esetScope(NTAG(TAG_Nil), v_s_241));
        HeffT2 v_t_2427 = (g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(v_dc_2425, v_st_2426));
        {
          V v_field_2428 = v_t_2427.f[0];
          V v_field_2429 = v_t_2427.f[1];
          V v_it1_2430 = v_field_2428;
          V v_s2_2431 = v_field_2429;
          switch (heff_tag_of(v_it1_2430)) {
          case TAG_Left: {
            V v_d_2432 = heff_field(v_it1_2430, 0);
            heff_take_n(v_it1_2430, 1ULL, 1);
            V v_t_2433 = (g_heff_2esyntax_2ecst_2eskipDecl(heff_dup(v_cs2_2415)));
            V v_t_2434 = (g_heff_2esyntax_2ecst_2edeclaredMore(heff_dup(v_cs2_2415)));
            HeffT2 v_t_2435 = (g_heff_2esyntax_2ecst_2edeclaredAt_24cpr(v_cs2_2415));
            {
              V v_field_2437 = v_t_2435.f[1];
              int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
              V v_t_2439;
              if ((v_tag_2436 == ((int64_t)0ULL))) {
                V v_x_2438 = v_field_2437;
                v_t_2439 = heff_tag_at_n(v_ru_24it_2413_24MkPair, TAG_Cons, 2, (V[]){v_x_2438, v_broken_244});
              } else {
                heff_drop_cell(v_ru_24it_2413_24MkPair, 2);
                heff_drop(v_field_2437);
                v_t_2439 = v_broken_244;
              }
              V v_t_2440 = (g_heff_2esyntax_2esurface_2eappendRev(v_t_2434, v_t_2439));
              V t_0 = v_t_2433;
              V t_1 = v_s2_2431;
              V t_2 = v_items_242;
              V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2432, v_diags_243});
              V t_4 = v_t_2440;
              v_cs_240 = t_0;
              v_s_241 = t_1;
              v_items_242 = t_2;
              v_diags_243 = t_3;
              v_broken_244 = t_4;
              goto top;
            }
          }
          case TAG_Right: {
            V v_ds_2441 = heff_field(v_it1_2430, 0);
            heff_take_n(v_it1_2430, 1ULL, 1);
            V v_t_2442 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2415), heff_dup(heff_rfield(v_cs2_2415, 1))));
            if (heff_strEq_c(heff_get_n(v_t_2442, 0, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str1))) {
              heff_drop_cell(v_ru_24it_2413_24MkPair, 2);
              V v_t_2443 = (g_heff_2esyntax_2esurface_2eappendRev(v_ds_2441, v_items_242));
              V t_0 = v_cs2_2415;
              V t_1 = v_s2_2431;
              V t_2 = v_t_2443;
              V t_3 = v_diags_243;
              V t_4 = v_broken_244;
              v_cs_240 = t_0;
              v_s_241 = t_1;
              v_items_242 = t_2;
              v_diags_243 = t_3;
              v_broken_244 = t_4;
              goto top;
            } else {
              V v_t_2444 = (g_heff_2esyntax_2ecst_2eskipDecl(heff_dup(v_cs2_2415)));
              V v_t_2445 = (g_heff_2esyntax_2esurface_2eappendRev(v_ds_2441, v_items_242));
              V v_t_2446 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2415), heff_dup(heff_rfield(v_cs2_2415, 1))));
              V v_start_2447 = heff_take_field(v_t_2446, 3);
              V v_end_2448 = heff_get_n(v_t_2446, 4, 9);
              V v_t_2449 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2415), heff_get_n(v_cs2_2415, 1, 5)));
              V v_t_2450 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eprogGo_str2), heff_get_n(v_t_2449, 1, 9));
              V v_msg_2451 = heff_strAppend(v_t_2450, ((V)&g_heff_2esyntax_2esurface_2eprogGo_str3));
              V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2451, heff_rec_n(2, shape_start__end, (V[]){v_start_2447, v_end_2448}), NTAG(TAG_Nothing)});
              V t_0 = v_t_2444;
              V t_1 = v_s2_2431;
              V t_2 = v_t_2445;
              V t_3 = heff_tag_at_n(v_ru_24it_2413_24MkPair, TAG_Cons, 2, (V[]){v_t_2452, v_diags_243});
              V t_4 = v_broken_244;
              v_cs_240 = t_0;
              v_s_241 = t_1;
              v_items_242 = t_2;
              v_diags_243 = t_3;
              v_broken_244 = t_4;
              goto top;
            }
          }
          default: return heff_nomatch(v_it1_2430);
          }
        }
      }
      default: return heff_nomatch(v_it1_2414);
      }
    }
    default: return heff_nomatch(v_it_2413);
    }
  }
}
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprogGo(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V v_ys_240, V v_pv_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_245 = heff_field(v_x2_242, 1);
    V v_t_247 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_245));
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(v_t_247, v_ys_240));
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_248);
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_242, 0);
    if ((heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0)) && !heff_strEq_c(heff_dup(heff_rfield(v_t_249, 1)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1)))) {
      V v_x_2410 = heff_dup(heff_rfield(v_t_249, 1));
      V v_t_2411 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
      return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_t_2411}));
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2))) {
        V v_t_2412 = (g_list_2eany_24s565534491x447967237(heff_dup(v_t_249), v_pv_241));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_x_2413 = heff_dup(heff_rfield(v_t_249, 1));
          V v_t_2414 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_setField(heff_dup(v_d_243), MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_t_2414}));
        } else {
          heff_drop(v_t_2412);
          return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_ys_240);
        }
      } else {
        return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_ys_240);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2416 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2416;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2419 = heff_field(v_x2_242, 1);
    V v_t_2423 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2419));
    V v_t_2424 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2423, v_ys_240));
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_2424);
  }
  case TAG_POp: {
    V v_l_2425 = heff_field(v_x2_242, 0);
    V v_q_2427 = heff_field(v_x2_242, 2);
    V v_t_2428 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2425));
    V v_t_2429 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2427));
    V v_t_2430 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2428, v_t_2429));
    V v_t_2431 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2430, v_ys_240));
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_2431);
  }
  case TAG_PRec: {
    V v_fs_2433 = heff_field(v_x2_242, 1);
    V v_t_2437 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2433));
    V v_t_2438 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2437, v_ys_240));
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), v_t_2438);
  }
  case TAG_PField: {
    V v_q_2441 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2441;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2442 = heff_field(v_x2_242, 0);
    V v_q_2444 = heff_field(v_x2_242, 2);
    V v_x_2445 = heff_dup(heff_rfield(v_x_2442, 1));
    V v_cell_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2445, heff_hole()});
    V v_u_2447 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2446);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2444;
    V t_3 = v_u_2447;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2448 = heff_field(v_x2_242, 0);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2448;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args) {
  V v_q_246 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_246; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_246); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args) {
  V v_q_2422 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2422; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2422); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args) {
  V v_q_2436 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2436; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2436); r_; });
}