// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Bracketed 50577
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_ImplicitParam 51130
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Looser 37443
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Plain 3036
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Same 22203
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tighter 5275
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_fix 310927
#define LBL_head 9693863
#define LBL_held 9694204
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_sigs 10025609
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__span__ty__eqns__whole[] = {LBL_name, LBL_span, LBL_ty, LBL_eqns, LBL_whole};
static uint32_t shape_sigs__held__rest[] = {LBL_sigs, LBL_held, LBL_rest};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2ebothLoosest(V, V, V);
V g_heff_2esyntax_2efixity_2ebothLoosest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2ebothLoosest_clo;
V g_heff_2esyntax_2efixity_2erelate(V, V, V);
V g_heff_2esyntax_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2erelate_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V, V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2earrowBinop(V, V);
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowBinop_clo;
V g_heff_2esyntax_2esurface_2earrowNames(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_clo;
V g_heff_2esyntax_2esurface_2earrowNames_24tok1(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V, V, V);
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(V, V);
V g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eexpOf(V);
V g_heff_2esyntax_2esurface_2eexpOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexpOf_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
double g_heff_2esyntax_2esurface_2efloatSplit_w(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit(V, V);
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatSplit_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2egroupFrom(V, V);
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupFrom_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eipow10(V);
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eipow10_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emagnitudeOf(V, V);
V g_heff_2esyntax_2esurface_2emagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emagnitudeOf_clo;
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V, V);
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2epickSig_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eplainBinder(V);
V g_heff_2esyntax_2esurface_2eplainBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplainBinder_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2erevOnto(V, V);
V g_heff_2esyntax_2esurface_2erevOnto_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erevOnto_clo;
HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_clo;
V g_heff_2esyntax_2esurface_2eunitIn(V, V);
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitIn_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_prelude_2etraverse_24s956608878x365908798(V);
V g_prelude_2etraverse_24s956608878x365908798_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s956608878x365908798_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2eintOfText_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2eintOfText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eintOfText_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eintOfText(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str0))) {
    V v_t_241 = (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    return heff_intSub(MK_INT(0LL), v_t_241);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2eintOfText_str1))) {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(1LL)));
    } else {
      return (g_heff_2esyntax_2esurface_2emagnitudeOf(v_s_240, MK_INT(0LL)));
    }
  }
}
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eintOfText(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2efloatSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatSplit_entry, 2, 0};

double g_heff_2esyntax_2esurface_2efloatSplit_w(V v_s_240, V v_eAt_241) {
top: ;
  V v_m_242 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2);
  V v_d_243 = ({ V b_0 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_246;
  if (heff_intLe_c(heff_strLength_lent(v_m_242, 0), heff_dup(v_d_243))) {
    heff_drop(v_d_243);
    v_m_246 = ({ V a_0 = v_m_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_m_242); r_; });
  } else {
    V v_t_244 = heff_strSlice(heff_dup(v_m_242), heff_intAdd(heff_dup(v_d_243), MK_INT(1LL)), heff_strLength_lent(v_m_242, 0));
    V v_t_245 = heff_strAppend(heff_strSlice(v_m_242, MK_INT(0LL), v_d_243), v_t_244);
    v_m_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_245); r_; });
  }
  V v_t_248;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_eAt_241))) {
    v_t_248 = MK_INT(0LL);
  } else {
    V v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_intAdd(heff_dup(v_eAt_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0));
    v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2esyntax_2esurface_2eexpOf(a_0)); heff_drop(v_t_247); r_; });
  }
  V v_m_249 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 2);
  V v_d_2410 = ({ V b_0 = heff_strSlice_lent(v_s_240, MK_INT(0LL), v_eAt_241, 6); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2412;
  if (heff_intLe_c(heff_strLength_lent(v_m_249, 0), heff_dup(v_d_2410))) {
    heff_drop(v_m_249);
    heff_drop(v_d_2410);
    v_t_2412 = MK_INT(0LL);
  } else {
    V v_t_2411 = heff_intSub(heff_strLength(v_m_249), v_d_2410);
    v_t_2412 = heff_intSub(v_t_2411, MK_INT(1LL));
  }
  V v_p_2413 = heff_intSub(v_t_248, v_t_2412);
  if (heff_intLe_c_lent(MK_INT(0LL), v_p_2413, 1)) {
    V v_t_2414 = (g_heff_2esyntax_2esurface_2eipow10(v_p_2413));
    return heff_from_int_f64(heff_intMul(v_m_246, v_t_2414));
  } else {
    V v_t_2415 = (g_heff_2esyntax_2esurface_2eipow10(heff_intSub(MK_INT(0LL), v_p_2413)));
    return (heff_from_int_f64(v_m_246) / heff_from_int_f64(v_t_2415));
  }
}
V g_heff_2esyntax_2esurface_2efloatSplit(V v_s_240, V v_eAt_241) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_eAt_241)));
}
V g_heff_2esyntax_2esurface_2efloatSplit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efloatSplit(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2efloatOfDigits_str1, 1, "+");
Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efloatOfDigits_entry, 1, 0};

double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str0))) {
    V v_t_241 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_242 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_243 = ({ V a_0 = v_t_242; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_242); r_; });
    double v_t_244 = ({ V a_0 = v_t_241; V a_1 = v_t_243; double r_ = (g_heff_2esyntax_2esurface_2efloatSplit_w(a_0, a_1)); heff_drop(v_t_241); r_; });
    return ((0.0) - v_t_244);
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2efloatOfDigits_str1))) {
      V v_t_245 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_246 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_246); r_; });
      return ({ V a_0 = v_t_245; V a_1 = v_t_247; double r_ = (g_heff_2esyntax_2esurface_2efloatSplit_w(a_0, a_1)); heff_drop(v_t_245); r_; });
    } else {
      V v_t_248 = (g_heff_2esyntax_2esurface_2esplitExp(v_s_240, MK_INT(0LL)));
      return (g_heff_2esyntax_2esurface_2efloatSplit_w(v_s_240, v_t_248));
    }
  }
}
V g_heff_2esyntax_2esurface_2efloatOfDigits(V v_s_240) {
  return heff_box_f64((g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_s_240)));
}
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2efloatOfDigits(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2earrowNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowNames_entry, 6, 0};

V g_heff_2esyntax_2esurface_2earrowNames(V v_rhs_240, V v_g_241, V v_ty_242, V v_braces_243, V v_dflt_244, V v_orig_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_get_n(v_t_247, 1, 2)});
  V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a_0)); heff_drop_tag(v_t_248, 2); r_; });
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_orig_245);
    heff_drop(v_t_249);
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_g_241)));
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2espineOf(v_g_241));
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2410, 0, 2), heff_get_n(v_t_2411, 1, 2)});
    return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2earrowNames_lam0, 2, 3, (V[]){v_braces_243, v_ty_242, v_dflt_244}); V a_1 = v_rhs_240; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop_tag(v_t_2412, 2); r_; });
  } else {
    heff_drop(v_g_241);
    heff_drop(v_ty_242);
    heff_drop(v_dflt_244);
    heff_drop(v_t_249);
    switch (heff_tag_of(v_braces_243)) {
    case TAG_Nothing: {
      V v_t_2484 = (g_heff_2esyntax_2esurface_2eplainBinder(heff_dup(v_orig_245)));
      V v_t_2487;
      switch (heff_tag_of(v_orig_245)) {
      case TAG_At: {
        V v_s_2486 = heff_field(v_orig_245, 1);
        heff_take_n(v_orig_245, 2ULL, 2);
        v_t_2487 = v_s_2486;
        break;
      }
      default: heff_nomatch(v_orig_245);
      }
      V v_t_2490;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2489 = heff_dup(heff_field(v_rhs_240, 1));
        v_t_2490 = v_s_2489;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2491 = ({ V rv_1 = heff_get_n(v_t_2490, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2487, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EPi, 2, (V[]){v_t_2484, v_rhs_240}), v_t_2491});
    }
    case TAG_Just: {
      V v_bsp_2492 = heff_field(v_braces_243, 0);
      V v_ru_24braces_243_24Just = heff_take_reuse_n(v_braces_243, 1ULL, 1);
      heff_drop(v_orig_245);
      V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24braces_243_24Just, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_str0)}), heff_dup(v_bsp_2492)});
      V v_t_2494 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2493}), heff_dup(v_rhs_240)});
      V v_t_2497;
      switch (heff_tag_of(v_rhs_240)) {
      case TAG_At: {
        V v_s_2496 = heff_field(v_rhs_240, 1);
        heff_take_n(v_rhs_240, 2ULL, 2);
        v_t_2497 = v_s_2496;
        break;
      }
      default: heff_nomatch(v_rhs_240);
      }
      V v_t_2498 = ({ V rv_1 = heff_get_n(v_t_2497, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2492, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2494, v_t_2498});
    }
    default: return heff_nomatch(v_braces_243);
    }
  }
}
V g_heff_2esyntax_2esurface_2earrowNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowNames(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2earrowNames_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_b_2414 = args[1];
  V v_braces_243 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_dflt_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_At: {
    V v_it1_2415 = heff_field(v_x_2413, 0);
    V v_ysp_2416 = heff_field(v_x_2413, 1);
    V v_ru_24x_2413_24At = heff_take_reuse_n(v_x_2413, 3ULL, 2);
    switch (heff_tag_of(v_it1_2415)) {
    case TAG_EVar: {
      V v_y_2417 = heff_field(v_it1_2415, 0);
      heff_take_n(v_it1_2415, 1ULL, 1);
      switch (heff_tag_of(v_braces_243)) {
      case TAG_Nothing: {
        heff_drop(v_dflt_244);
        V v_t_2418 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiNamed, 3, (V[]){v_y_2417, heff_dup(v_ysp_2416), v_ty_242}), heff_dup(v_b_2414)});
        V v_t_2421;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_ysp_2416, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2413_24At, TAG_At, 2, (V[]){v_t_2418, v_t_2422});
      }
      case TAG_Just: {
        V v_bsp_2423 = heff_field(v_braces_243, 0);
        heff_take_n(v_braces_243, 1ULL, 1);
        V v_t_2424 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiImplicit, 5, (V[]){v_y_2417, v_ysp_2416, heff_dup(v_bsp_2423), v_ty_242, v_dflt_244}), heff_dup(v_b_2414)});
        V v_t_2427;
        switch (heff_tag_of(v_b_2414)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_b_2414, 1);
          heff_take_n(v_b_2414, 2ULL, 2);
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_b_2414);
        }
        V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_2423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x_2413_24At, TAG_At, 2, (V[]){v_t_2424, v_t_2428});
      }
      default: return heff_nomatch(v_braces_243);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETag: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInt: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EString: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EBinary: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ERune: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWord: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EApp: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EProject: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EPi: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELam: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_2415, 0ULL, 4);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESig: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ESum: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EDo: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EAssign: {
      heff_take_n(v_it1_2415, 0ULL, 3);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWhile: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EFor: {
      heff_take_n(v_it1_2415, 0ULL, 3);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EIfThen: {
      heff_take_n(v_it1_2415, 0ULL, 2);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EBreak: {
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EContinue: {
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EReturn: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ENest: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ELazy: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETuple: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_ETry: {
      heff_take_n(v_it1_2415, 0ULL, 1);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    case TAG_EWith: {
      heff_take_n(v_it1_2415, 0ULL, 4);
      heff_drop(v_braces_243);
      heff_drop(v_ty_242);
      heff_drop(v_dflt_244);
      heff_drop_rec(v_ysp_2416, 2);
      heff_drop_cell(v_ru_24x_2413_24At, 2);
      return v_b_2414;
    }
    default: return heff_nomatch(v_it1_2415);
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str1, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str2, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str3, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str4, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str5, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str6, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str7, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str8, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str9, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str10, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str11, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str12, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str13, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str14, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str15, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str16, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str17, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str18, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str19, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str20, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str21, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str22, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str23, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str24, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str25, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str26, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str27, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str28, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str29, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str30, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str31, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str32, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str33, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str34, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str35, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str36, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str37, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str38, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str39, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str40, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str41, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str42, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str43, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str44, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str45, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str46, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str47, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str48, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str49, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str50, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str51, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str52, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str53, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str54, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str55, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str56, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str57, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str58, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str59, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str60, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str61, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str62, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str63, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str64, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str65, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str66, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str67, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str68, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str69, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str70, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str71, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str72, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str73, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str74, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str75, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str76, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str77, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str78, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str79, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str80, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str81, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str82, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str83, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str84, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str85, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str86, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str87, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str88, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str89, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str90, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str91, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str92, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str93, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str94, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str95, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str96, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str97, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str98, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str99, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str100, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str101, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str102, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str103, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str104, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str105, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str106, 49, "an instance argument is named: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowBinop_str107, 49, "an instance argument is named: `{{x : T}} -> ...`");
Clo g_heff_2esyntax_2esurface_2earrowBinop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowBinop_entry, 2, 0};

V g_heff_2esyntax_2esurface_2earrowBinop(V v_x1_240, V v_rhs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Plain: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Plain = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_243 = heff_dup(heff_field(v_x11_242, 0));
      switch (heff_tag_of(v_x111_243)) {
      case TAG_EVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_246 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_249;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_248 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2412;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2413 = ({ V rv_1 = heff_get_n(v_t_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2413});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2415 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2418;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2417 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2418 = v_s_2417;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2421;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2421 = v_s_2420;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2422});
      }
      case TAG_ETag: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2424 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2427;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2430;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2429 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2430 = v_s_2429;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2431 = ({ V rv_1 = heff_get_n(v_t_2430, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2427, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2431});
      }
      case TAG_EInt: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2433 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2436;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2435 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2439;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2438 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2440 = ({ V rv_1 = heff_get_n(v_t_2439, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2436, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2433, v_t_2440});
      }
      case TAG_EFloat: {
        heff_take_na(v_x111_243, 0ULL, 1);
        V v_t_2442 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2445;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2444 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2448;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2447 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2448 = v_s_2447;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2449 = ({ V rv_1 = heff_get_n(v_t_2448, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2445, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2449});
      }
      case TAG_EString: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2451 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2454;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2453 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2457;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2456 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2457 = v_s_2456;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2458 = ({ V rv_1 = heff_get_n(v_t_2457, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2454, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_t_2458});
      }
      case TAG_EBinary: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2460 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2463;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2462 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2466;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2465 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2466 = v_s_2465;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2467 = ({ V rv_1 = heff_get_n(v_t_2466, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2463, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2460, v_t_2467});
      }
      case TAG_ERune: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2469 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2472;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2471 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2475;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2474 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2475 = v_s_2474;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2476 = ({ V rv_1 = heff_get_n(v_t_2475, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2472, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_t_2476});
      }
      case TAG_EWord: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2478 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2481;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2480 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2481 = v_s_2480;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2484;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2483 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2485 = ({ V rv_1 = heff_get_n(v_t_2484, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2481, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2478, v_t_2485});
      }
      case TAG_EApp: {
        V v_ru_24x111_243_24EApp = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_2488 = heff_tag_at_n(v_ru_24x111_243_24EApp, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_2491;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2490 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_2491 = v_s_2490;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_2494;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_2493 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_2495 = ({ V rv_1 = heff_get_n(v_t_2494, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2491, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2488, v_t_2495});
      }
      case TAG_EProject: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_2497 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24100;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_2499 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24100 = v_s_2499;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24103;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24102 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24104 = ({ V rv_1 = heff_get_n(v_t_24103, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24100, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2497, v_t_24104});
      }
      case TAG_ENamed: {
        V v_ru_24x111_243_24ENamed = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24107 = heff_tag_at_n(v_ru_24x111_243_24ENamed, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24110;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24109 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24110 = v_s_24109;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24113;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24112 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24114 = ({ V rv_1 = heff_get_n(v_t_24113, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24110, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24107, v_t_24114});
      }
      case TAG_EPi: {
        V v_ru_24x111_243_24EPi = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24117 = heff_tag_at_n(v_ru_24x111_243_24EPi, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24120;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24119 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24120 = v_s_24119;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24123;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24122 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24124 = ({ V rv_1 = heff_get_n(v_t_24123, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24120, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24117, v_t_24124});
      }
      case TAG_ELam: {
        V v_ru_24x111_243_24ELam = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24127 = heff_tag_at_n(v_ru_24x111_243_24ELam, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24130;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24129 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24130 = v_s_24129;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24133;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24132 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24133 = v_s_24132;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24134 = ({ V rv_1 = heff_get_n(v_t_24133, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24130, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24127, v_t_24134});
      }
      case TAG_EAnn: {
        V v_g_24135 = heff_field(v_x111_243, 0);
        V v_ty_24136 = heff_field(v_x111_243, 1);
        V v_ru_24x111_243_24EAnn = heff_take_reuse_n(v_x111_243, 3ULL, 2);
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_sp_24138 = heff_field(v_x11_242, 1);
          V v_ru_24x11_242_24At = heff_take_reuse_n(v_x11_242, 2ULL, 2);
          V v_t_24139 = heff_tag_at_n(v_ru_24x11_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x111_243_24EAnn, TAG_EAnn, 2, (V[]){heff_dup(v_g_24135), heff_dup(v_ty_24136)}), v_sp_24138});
          return (g_heff_2esyntax_2esurface_2earrowNames_24tok1(v_ru_24x1_240_24Plain, v_rhs_241, v_g_24135, v_ty_24136, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_t_24139));
        }
        default: return heff_nomatch(v_x11_242);
        }
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_243, 0ULL, 4);
        V v_t_24144 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24147;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24146 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24147 = v_s_24146;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24150;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24149 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24151 = ({ V rv_1 = heff_get_n(v_t_24150, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24147, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24144, v_t_24151});
      }
      case TAG_ESig: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24153 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24156;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24155 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24156 = v_s_24155;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24159;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24158 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24159 = v_s_24158;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24160 = ({ V rv_1 = heff_get_n(v_t_24159, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24156, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24153, v_t_24160});
      }
      case TAG_ESum: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24162 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24165;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24164 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24165 = v_s_24164;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24168;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24167 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24168 = v_s_24167;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24169 = ({ V rv_1 = heff_get_n(v_t_24168, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24165, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24162, v_t_24169});
      }
      case TAG_EStruct: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24171 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24174;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24173 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24174 = v_s_24173;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24177;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24176 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24177 = v_s_24176;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24178 = ({ V rv_1 = heff_get_n(v_t_24177, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24174, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24171, v_t_24178});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_243_24EUpdate = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24181 = heff_tag_at_n(v_ru_24x111_243_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24184;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24183 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24184 = v_s_24183;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24187;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24186 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24187 = v_s_24186;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24188 = ({ V rv_1 = heff_get_n(v_t_24187, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24184, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24181, v_t_24188});
      }
      case TAG_EMatch: {
        V v_ru_24x111_243_24EMatch = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24191 = heff_tag_at_n(v_ru_24x111_243_24EMatch, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24194;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24193 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24194 = v_s_24193;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24197;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24196 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24197 = v_s_24196;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24198 = ({ V rv_1 = heff_get_n(v_t_24197, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24194, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24191, v_t_24198});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_243_24ELetIn = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24201 = heff_tag_at_n(v_ru_24x111_243_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24204;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24203 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24204 = v_s_24203;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24207;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24206 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24208 = ({ V rv_1 = heff_get_n(v_t_24207, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24204, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24201, v_t_24208});
      }
      case TAG_EDo: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24210 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24213;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24212 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24213 = v_s_24212;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24216;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24215 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24216 = v_s_24215;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24217 = ({ V rv_1 = heff_get_n(v_t_24216, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24213, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24210, v_t_24217});
      }
      case TAG_ELocal: {
        V v_ru_24x111_243_24ELocal = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24220 = heff_tag_at_n(v_ru_24x111_243_24ELocal, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24223;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24222 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24223 = v_s_24222;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24226;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24225 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24226 = v_s_24225;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24227 = ({ V rv_1 = heff_get_n(v_t_24226, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24223, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24220, v_t_24227});
      }
      case TAG_EInvalid: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24229 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24232;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24231 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24232 = v_s_24231;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24235;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24234 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24235 = v_s_24234;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24236 = ({ V rv_1 = heff_get_n(v_t_24235, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24232, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24229, v_t_24236});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_243, 0ULL, 3);
        V v_t_24240 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24243;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24242 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24243 = v_s_24242;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24246;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24245 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24246 = v_s_24245;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24247 = ({ V rv_1 = heff_get_n(v_t_24246, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24240, v_t_24247});
      }
      case TAG_EWhile: {
        V v_ru_24x111_243_24EWhile = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24250 = heff_tag_at_n(v_ru_24x111_243_24EWhile, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24253;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24252 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24253 = v_s_24252;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24256;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24255 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24256 = v_s_24255;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24257 = ({ V rv_1 = heff_get_n(v_t_24256, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24253, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24250, v_t_24257});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_243, 0ULL, 3);
        V v_t_24261 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24264;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24263 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24264 = v_s_24263;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24267;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24266 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24267 = v_s_24266;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24268 = ({ V rv_1 = heff_get_n(v_t_24267, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24264, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24261, v_t_24268});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_243_24EIfThen = heff_take_reuse_n(v_x111_243, 0ULL, 2);
        V v_t_24271 = heff_tag_at_n(v_ru_24x111_243_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24274;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24273 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24274 = v_s_24273;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24277;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24276 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24277 = v_s_24276;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24278 = ({ V rv_1 = heff_get_n(v_t_24277, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24274, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24271, v_t_24278});
      }
      case TAG_EBreak: {
        V v_t_24279 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24282;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24281 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24282 = v_s_24281;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24285;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24284 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24285 = v_s_24284;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24286 = ({ V rv_1 = heff_get_n(v_t_24285, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24282, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24279, v_t_24286});
      }
      case TAG_EContinue: {
        V v_t_24287 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24290;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24289 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24290 = v_s_24289;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24293;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24292 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24293 = v_s_24292;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24294 = ({ V rv_1 = heff_get_n(v_t_24293, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24290, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24287, v_t_24294});
      }
      case TAG_EReturn: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24296 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24299;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24298 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24299 = v_s_24298;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24302;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24301 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24302 = v_s_24301;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24303 = ({ V rv_1 = heff_get_n(v_t_24302, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24299, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24296, v_t_24303});
      }
      case TAG_ENest: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24305 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24308;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24307 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24308 = v_s_24307;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24311;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24310 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24311 = v_s_24310;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24312 = ({ V rv_1 = heff_get_n(v_t_24311, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24308, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24305, v_t_24312});
      }
      case TAG_ELazy: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24314 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24317;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24316 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24317 = v_s_24316;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24320;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24319 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24320 = v_s_24319;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24321 = ({ V rv_1 = heff_get_n(v_t_24320, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24317, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24314, v_t_24321});
      }
      case TAG_ETuple: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24323 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24326;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24325 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24326 = v_s_24325;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24329;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24328 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24329 = v_s_24328;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24330 = ({ V rv_1 = heff_get_n(v_t_24329, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24326, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24323, v_t_24330});
      }
      case TAG_ETry: {
        heff_take_n(v_x111_243, 0ULL, 1);
        V v_t_24332 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24335;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24334 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24335 = v_s_24334;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24338;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24337 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24338 = v_s_24337;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24339 = ({ V rv_1 = heff_get_n(v_t_24338, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24335, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24332, v_t_24339});
      }
      case TAG_EWith: {
        heff_take_n(v_x111_243, 0ULL, 4);
        V v_t_24344 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24Plain, TAG_PiAnon, 1, (V[]){heff_dup(v_x11_242)}), heff_dup(v_rhs_241)});
        V v_t_24347;
        switch (heff_tag_of(v_x11_242)) {
        case TAG_At: {
          V v_s_24346 = heff_field(v_x11_242, 1);
          heff_take_n(v_x11_242, 2ULL, 2);
          v_t_24347 = v_s_24346;
          break;
        }
        default: heff_nomatch(v_x11_242);
        }
        V v_t_24350;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24349 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24350 = v_s_24349;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24351 = ({ V rv_1 = heff_get_n(v_t_24350, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24347, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24344, v_t_24351});
      }
      default: return heff_nomatch(v_x111_243);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_Braced: {
    V v_x11_24352 = heff_field(v_x1_240, 0);
    V v_dflt_24353 = heff_field(v_x1_240, 1);
    V v_bsp_24354 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    switch (heff_tag_of(v_x11_24352)) {
    case TAG_At: {
      V v_x111_24355 = heff_field(v_x11_24352, 0);
      V v_sp_24356 = heff_field(v_x11_24352, 1);
      V v_ru_24x11_24352_24At = heff_take_reuse_n(v_x11_24352, 3ULL, 2);
      switch (heff_tag_of(v_x111_24355)) {
      case TAG_EVar: {
        V v_ru_24x111_24355_24EVar = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24358 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str0)}), heff_dup(v_bsp_24354)});
        V v_t_24359 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EVar, TAG_PiAnon, 1, (V[]){v_t_24358}), heff_dup(v_rhs_241)});
        V v_t_24362;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24361 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24362 = v_s_24361;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24363 = ({ V rv_1 = heff_get_n(v_t_24362, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24359, v_t_24363});
      }
      case TAG_EImplicitVar: {
        V v_ru_24x111_24355_24EImplicitVar = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24365 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str1)}), heff_dup(v_bsp_24354)});
        V v_t_24366 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_t_24365}), heff_dup(v_rhs_241)});
        V v_t_24369;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24368 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24369 = v_s_24368;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24370 = ({ V rv_1 = heff_get_n(v_t_24369, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24366, v_t_24370});
      }
      case TAG_ETag: {
        V v_ru_24x111_24355_24ETag = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24372 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str2)}), heff_dup(v_bsp_24354)});
        V v_t_24373 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ETag, TAG_PiAnon, 1, (V[]){v_t_24372}), heff_dup(v_rhs_241)});
        V v_t_24376;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24375 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24376 = v_s_24375;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24377 = ({ V rv_1 = heff_get_n(v_t_24376, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24373, v_t_24377});
      }
      case TAG_EInt: {
        V v_ru_24x111_24355_24EInt = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24379 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str3)}), heff_dup(v_bsp_24354)});
        V v_t_24380 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EInt, TAG_PiAnon, 1, (V[]){v_t_24379}), heff_dup(v_rhs_241)});
        V v_t_24383;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24382 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24383 = v_s_24382;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24384 = ({ V rv_1 = heff_get_n(v_t_24383, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24380, v_t_24384});
      }
      case TAG_EFloat: {
        V v_ru_24x111_24355_24EFloat = heff_take_reuse_na(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24386 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str4)}), heff_dup(v_bsp_24354)});
        V v_t_24387 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EFloat, TAG_PiAnon, 1, (V[]){v_t_24386}), heff_dup(v_rhs_241)});
        V v_t_24390;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24389 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24390 = v_s_24389;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24391 = ({ V rv_1 = heff_get_n(v_t_24390, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24387, v_t_24391});
      }
      case TAG_EString: {
        V v_ru_24x111_24355_24EString = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24393 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str5)}), heff_dup(v_bsp_24354)});
        V v_t_24394 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EString, TAG_PiAnon, 1, (V[]){v_t_24393}), heff_dup(v_rhs_241)});
        V v_t_24397;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24396 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24397 = v_s_24396;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24398 = ({ V rv_1 = heff_get_n(v_t_24397, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24394, v_t_24398});
      }
      case TAG_EBinary: {
        V v_ru_24x111_24355_24EBinary = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24400 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str6)}), heff_dup(v_bsp_24354)});
        V v_t_24401 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EBinary, TAG_PiAnon, 1, (V[]){v_t_24400}), heff_dup(v_rhs_241)});
        V v_t_24404;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24403 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24404 = v_s_24403;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24405 = ({ V rv_1 = heff_get_n(v_t_24404, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24401, v_t_24405});
      }
      case TAG_ERune: {
        V v_ru_24x111_24355_24ERune = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24407 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str7)}), heff_dup(v_bsp_24354)});
        V v_t_24408 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ERune, TAG_PiAnon, 1, (V[]){v_t_24407}), heff_dup(v_rhs_241)});
        V v_t_24411;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24410 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24411 = v_s_24410;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24412 = ({ V rv_1 = heff_get_n(v_t_24411, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24408, v_t_24412});
      }
      case TAG_EWord: {
        V v_ru_24x111_24355_24EWord = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24414 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str8)}), heff_dup(v_bsp_24354)});
        V v_t_24415 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EWord, TAG_PiAnon, 1, (V[]){v_t_24414}), heff_dup(v_rhs_241)});
        V v_t_24418;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24417 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24418 = v_s_24417;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24419 = ({ V rv_1 = heff_get_n(v_t_24418, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24415, v_t_24419});
      }
      case TAG_EApp: {
        V v_ru_24x111_24355_24EApp = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24422 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str9)}), heff_dup(v_bsp_24354)});
        V v_t_24423 = heff_tag_at_n(v_ru_24x111_24355_24EApp, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24422}), heff_dup(v_rhs_241)});
        V v_t_24426;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24425 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24426 = v_s_24425;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24427 = ({ V rv_1 = heff_get_n(v_t_24426, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24423, v_t_24427});
      }
      case TAG_EProject: {
        V v_ru_24x111_24355_24EProject = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24429 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str10)}), heff_dup(v_bsp_24354)});
        V v_t_24430 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EProject, TAG_PiAnon, 1, (V[]){v_t_24429}), heff_dup(v_rhs_241)});
        V v_t_24433;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24432 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24433 = v_s_24432;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24434 = ({ V rv_1 = heff_get_n(v_t_24433, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24430, v_t_24434});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24355_24ENamed = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24437 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str11)}), heff_dup(v_bsp_24354)});
        V v_t_24438 = heff_tag_at_n(v_ru_24x111_24355_24ENamed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24437}), heff_dup(v_rhs_241)});
        V v_t_24441;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24440 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24441 = v_s_24440;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24442 = ({ V rv_1 = heff_get_n(v_t_24441, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24438, v_t_24442});
      }
      case TAG_EPi: {
        V v_ru_24x111_24355_24EPi = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24445 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str12)}), heff_dup(v_bsp_24354)});
        V v_t_24446 = heff_tag_at_n(v_ru_24x111_24355_24EPi, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24445}), heff_dup(v_rhs_241)});
        V v_t_24449;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24448 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24449 = v_s_24448;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24450 = ({ V rv_1 = heff_get_n(v_t_24449, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24446, v_t_24450});
      }
      case TAG_ELam: {
        V v_ru_24x111_24355_24ELam = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24453 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str13)}), heff_dup(v_bsp_24354)});
        V v_t_24454 = heff_tag_at_n(v_ru_24x111_24355_24ELam, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24453}), heff_dup(v_rhs_241)});
        V v_t_24457;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24456 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24457 = v_s_24456;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24458 = ({ V rv_1 = heff_get_n(v_t_24457, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24454, v_t_24458});
      }
      case TAG_EAnn: {
        V v_g_24459 = heff_field(v_x111_24355, 0);
        V v_ty_24460 = heff_field(v_x111_24355, 1);
        heff_take_n(v_x111_24355, 3ULL, 2);
        V v_t_24461 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){heff_dup(v_g_24459), heff_dup(v_ty_24460)}), v_sp_24356});
        return (g_heff_2esyntax_2esurface_2earrowNames(v_rhs_241, v_g_24459, v_ty_24460, heff_tag_n(TAG_Just, 1, (V[]){v_bsp_24354}), v_dflt_24353, v_t_24461));
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24355, 0ULL, 4);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24466 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str14)}), heff_dup(v_bsp_24354)});
        V v_t_24467 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24466}), heff_dup(v_rhs_241)});
        V v_t_24470;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24469 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24470 = v_s_24469;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24471 = ({ V rv_1 = heff_get_n(v_t_24470, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24467, v_t_24471});
      }
      case TAG_ESig: {
        V v_ru_24x111_24355_24ESig = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24473 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str15)}), heff_dup(v_bsp_24354)});
        V v_t_24474 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ESig, TAG_PiAnon, 1, (V[]){v_t_24473}), heff_dup(v_rhs_241)});
        V v_t_24477;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24476 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24477 = v_s_24476;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24478 = ({ V rv_1 = heff_get_n(v_t_24477, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24474, v_t_24478});
      }
      case TAG_ESum: {
        V v_ru_24x111_24355_24ESum = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24480 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str16)}), heff_dup(v_bsp_24354)});
        V v_t_24481 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ESum, TAG_PiAnon, 1, (V[]){v_t_24480}), heff_dup(v_rhs_241)});
        V v_t_24484;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24483 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24484 = v_s_24483;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24485 = ({ V rv_1 = heff_get_n(v_t_24484, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24481, v_t_24485});
      }
      case TAG_EStruct: {
        V v_ru_24x111_24355_24EStruct = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24487 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str17)}), heff_dup(v_bsp_24354)});
        V v_t_24488 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EStruct, TAG_PiAnon, 1, (V[]){v_t_24487}), heff_dup(v_rhs_241)});
        V v_t_24491;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24490 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24491 = v_s_24490;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24492 = ({ V rv_1 = heff_get_n(v_t_24491, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24488, v_t_24492});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24355_24EUpdate = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24495 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str18)}), heff_dup(v_bsp_24354)});
        V v_t_24496 = heff_tag_at_n(v_ru_24x111_24355_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24495}), heff_dup(v_rhs_241)});
        V v_t_24499;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24498 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24499 = v_s_24498;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24500 = ({ V rv_1 = heff_get_n(v_t_24499, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24496, v_t_24500});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24355_24EMatch = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24503 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str19)}), heff_dup(v_bsp_24354)});
        V v_t_24504 = heff_tag_at_n(v_ru_24x111_24355_24EMatch, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24503}), heff_dup(v_rhs_241)});
        V v_t_24507;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24506 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24507 = v_s_24506;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24508 = ({ V rv_1 = heff_get_n(v_t_24507, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24504, v_t_24508});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24355_24ELetIn = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24511 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str20)}), heff_dup(v_bsp_24354)});
        V v_t_24512 = heff_tag_at_n(v_ru_24x111_24355_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24511}), heff_dup(v_rhs_241)});
        V v_t_24515;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24514 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24515 = v_s_24514;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24516 = ({ V rv_1 = heff_get_n(v_t_24515, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24512, v_t_24516});
      }
      case TAG_EDo: {
        V v_ru_24x111_24355_24EDo = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24518 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str21)}), heff_dup(v_bsp_24354)});
        V v_t_24519 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EDo, TAG_PiAnon, 1, (V[]){v_t_24518}), heff_dup(v_rhs_241)});
        V v_t_24522;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24521 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24522 = v_s_24521;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24523 = ({ V rv_1 = heff_get_n(v_t_24522, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24519, v_t_24523});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24355_24ELocal = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24526 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str22)}), heff_dup(v_bsp_24354)});
        V v_t_24527 = heff_tag_at_n(v_ru_24x111_24355_24ELocal, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24526}), heff_dup(v_rhs_241)});
        V v_t_24530;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24529 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24530 = v_s_24529;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24531 = ({ V rv_1 = heff_get_n(v_t_24530, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24527, v_t_24531});
      }
      case TAG_EInvalid: {
        V v_ru_24x111_24355_24EInvalid = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24533 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str23)}), heff_dup(v_bsp_24354)});
        V v_t_24534 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EInvalid, TAG_PiAnon, 1, (V[]){v_t_24533}), heff_dup(v_rhs_241)});
        V v_t_24537;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24536 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24537 = v_s_24536;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24538 = ({ V rv_1 = heff_get_n(v_t_24537, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24534, v_t_24538});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_24355, 0ULL, 3);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24542 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str24)}), heff_dup(v_bsp_24354)});
        V v_t_24543 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24542}), heff_dup(v_rhs_241)});
        V v_t_24546;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24545 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24546 = v_s_24545;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24547 = ({ V rv_1 = heff_get_n(v_t_24546, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24543, v_t_24547});
      }
      case TAG_EWhile: {
        V v_ru_24x111_24355_24EWhile = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24550 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str25)}), heff_dup(v_bsp_24354)});
        V v_t_24551 = heff_tag_at_n(v_ru_24x111_24355_24EWhile, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24550}), heff_dup(v_rhs_241)});
        V v_t_24554;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24553 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24554 = v_s_24553;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24555 = ({ V rv_1 = heff_get_n(v_t_24554, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24551, v_t_24555});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_24355, 0ULL, 3);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24559 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str26)}), heff_dup(v_bsp_24354)});
        V v_t_24560 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24559}), heff_dup(v_rhs_241)});
        V v_t_24563;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24562 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24563 = v_s_24562;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24564 = ({ V rv_1 = heff_get_n(v_t_24563, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24560, v_t_24564});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_24355_24EIfThen = heff_take_reuse_n(v_x111_24355, 0ULL, 2);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24567 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str27)}), heff_dup(v_bsp_24354)});
        V v_t_24568 = heff_tag_at_n(v_ru_24x111_24355_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24567}), heff_dup(v_rhs_241)});
        V v_t_24571;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24570 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24571 = v_s_24570;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24572 = ({ V rv_1 = heff_get_n(v_t_24571, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24568, v_t_24572});
      }
      case TAG_EBreak: {
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24573 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str28)}), heff_dup(v_bsp_24354)});
        V v_t_24574 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24573}), heff_dup(v_rhs_241)});
        V v_t_24577;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24576 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24577 = v_s_24576;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24578 = ({ V rv_1 = heff_get_n(v_t_24577, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24574, v_t_24578});
      }
      case TAG_EContinue: {
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24579 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str29)}), heff_dup(v_bsp_24354)});
        V v_t_24580 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24579}), heff_dup(v_rhs_241)});
        V v_t_24583;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24582 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24583 = v_s_24582;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24584 = ({ V rv_1 = heff_get_n(v_t_24583, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24580, v_t_24584});
      }
      case TAG_EReturn: {
        V v_ru_24x111_24355_24EReturn = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24586 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str30)}), heff_dup(v_bsp_24354)});
        V v_t_24587 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24EReturn, TAG_PiAnon, 1, (V[]){v_t_24586}), heff_dup(v_rhs_241)});
        V v_t_24590;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24589 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24590 = v_s_24589;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24591 = ({ V rv_1 = heff_get_n(v_t_24590, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24587, v_t_24591});
      }
      case TAG_ENest: {
        V v_ru_24x111_24355_24ENest = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24593 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str31)}), heff_dup(v_bsp_24354)});
        V v_t_24594 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ENest, TAG_PiAnon, 1, (V[]){v_t_24593}), heff_dup(v_rhs_241)});
        V v_t_24597;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24596 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24597 = v_s_24596;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24598 = ({ V rv_1 = heff_get_n(v_t_24597, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24594, v_t_24598});
      }
      case TAG_ELazy: {
        V v_ru_24x111_24355_24ELazy = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24600 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str32)}), heff_dup(v_bsp_24354)});
        V v_t_24601 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ELazy, TAG_PiAnon, 1, (V[]){v_t_24600}), heff_dup(v_rhs_241)});
        V v_t_24604;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24603 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24604 = v_s_24603;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24605 = ({ V rv_1 = heff_get_n(v_t_24604, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24601, v_t_24605});
      }
      case TAG_ETuple: {
        V v_ru_24x111_24355_24ETuple = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24607 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str33)}), heff_dup(v_bsp_24354)});
        V v_t_24608 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ETuple, TAG_PiAnon, 1, (V[]){v_t_24607}), heff_dup(v_rhs_241)});
        V v_t_24611;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24610 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24611 = v_s_24610;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24612 = ({ V rv_1 = heff_get_n(v_t_24611, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24608, v_t_24612});
      }
      case TAG_ETry: {
        V v_ru_24x111_24355_24ETry = heff_take_reuse_n(v_x111_24355, 0ULL, 1);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24614 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str34)}), heff_dup(v_bsp_24354)});
        V v_t_24615 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24355_24ETry, TAG_PiAnon, 1, (V[]){v_t_24614}), heff_dup(v_rhs_241)});
        V v_t_24618;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24617 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24618 = v_s_24617;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24619 = ({ V rv_1 = heff_get_n(v_t_24618, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24615, v_t_24619});
      }
      case TAG_EWith: {
        heff_take_n(v_x111_24355, 0ULL, 4);
        heff_drop(v_dflt_24353);
        heff_drop(v_sp_24356);
        V v_t_24624 = heff_tag_at_n(v_ru_24x11_24352_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str35)}), heff_dup(v_bsp_24354)});
        V v_t_24625 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24624}), heff_dup(v_rhs_241)});
        V v_t_24628;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24627 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24628 = v_s_24627;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24629 = ({ V rv_1 = heff_get_n(v_t_24628, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24354, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_24625, v_t_24629});
      }
      default: return heff_nomatch(v_x111_24355);
      }
    }
    default: return heff_nomatch(v_x11_24352);
    }
  }
  case TAG_Bracketed: {
    V v_x11_24630 = heff_field(v_x1_240, 0);
    V v_bsp_24631 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Bracketed = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_24630)) {
    case TAG_At: {
      V v_x111_24632 = heff_field(v_x11_24630, 0);
      V v_ru_24x11_24630_24At = heff_take_reuse_n(v_x11_24630, 1ULL, 2);
      switch (heff_tag_of(v_x111_24632)) {
      case TAG_EVar: {
        V v_ru_24x111_24632_24EVar = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24635 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str36)}), heff_dup(v_bsp_24631)});
        V v_t_24636 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EVar, TAG_PiAnon, 1, (V[]){v_t_24635}), heff_dup(v_rhs_241)});
        V v_t_24639;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24638 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24639 = v_s_24638;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24640 = ({ V rv_1 = heff_get_n(v_t_24639, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24636, v_t_24640});
      }
      case TAG_EImplicitVar: {
        V v_ru_24x111_24632_24EImplicitVar = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24642 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str37)}), heff_dup(v_bsp_24631)});
        V v_t_24643 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EImplicitVar, TAG_PiAnon, 1, (V[]){v_t_24642}), heff_dup(v_rhs_241)});
        V v_t_24646;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24645 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24646 = v_s_24645;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24647 = ({ V rv_1 = heff_get_n(v_t_24646, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24643, v_t_24647});
      }
      case TAG_ETag: {
        V v_ru_24x111_24632_24ETag = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24649 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str38)}), heff_dup(v_bsp_24631)});
        V v_t_24650 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ETag, TAG_PiAnon, 1, (V[]){v_t_24649}), heff_dup(v_rhs_241)});
        V v_t_24653;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24652 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24653 = v_s_24652;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24654 = ({ V rv_1 = heff_get_n(v_t_24653, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24650, v_t_24654});
      }
      case TAG_EInt: {
        V v_ru_24x111_24632_24EInt = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24656 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str39)}), heff_dup(v_bsp_24631)});
        V v_t_24657 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EInt, TAG_PiAnon, 1, (V[]){v_t_24656}), heff_dup(v_rhs_241)});
        V v_t_24660;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24659 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24660 = v_s_24659;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24661 = ({ V rv_1 = heff_get_n(v_t_24660, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24657, v_t_24661});
      }
      case TAG_EFloat: {
        V v_ru_24x111_24632_24EFloat = heff_take_reuse_na(v_x111_24632, 0ULL, 1);
        V v_t_24663 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str40)}), heff_dup(v_bsp_24631)});
        V v_t_24664 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EFloat, TAG_PiAnon, 1, (V[]){v_t_24663}), heff_dup(v_rhs_241)});
        V v_t_24667;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24666 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24667 = v_s_24666;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24668 = ({ V rv_1 = heff_get_n(v_t_24667, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24664, v_t_24668});
      }
      case TAG_EString: {
        V v_ru_24x111_24632_24EString = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24670 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str41)}), heff_dup(v_bsp_24631)});
        V v_t_24671 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EString, TAG_PiAnon, 1, (V[]){v_t_24670}), heff_dup(v_rhs_241)});
        V v_t_24674;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24673 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24674 = v_s_24673;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24675 = ({ V rv_1 = heff_get_n(v_t_24674, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24671, v_t_24675});
      }
      case TAG_EBinary: {
        V v_ru_24x111_24632_24EBinary = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24677 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str42)}), heff_dup(v_bsp_24631)});
        V v_t_24678 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EBinary, TAG_PiAnon, 1, (V[]){v_t_24677}), heff_dup(v_rhs_241)});
        V v_t_24681;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24680 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24681 = v_s_24680;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24682 = ({ V rv_1 = heff_get_n(v_t_24681, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24678, v_t_24682});
      }
      case TAG_ERune: {
        V v_ru_24x111_24632_24ERune = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24684 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str43)}), heff_dup(v_bsp_24631)});
        V v_t_24685 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ERune, TAG_PiAnon, 1, (V[]){v_t_24684}), heff_dup(v_rhs_241)});
        V v_t_24688;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24687 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24688 = v_s_24687;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24689 = ({ V rv_1 = heff_get_n(v_t_24688, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24685, v_t_24689});
      }
      case TAG_EWord: {
        V v_ru_24x111_24632_24EWord = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24691 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str44)}), heff_dup(v_bsp_24631)});
        V v_t_24692 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EWord, TAG_PiAnon, 1, (V[]){v_t_24691}), heff_dup(v_rhs_241)});
        V v_t_24695;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24694 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24695 = v_s_24694;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24696 = ({ V rv_1 = heff_get_n(v_t_24695, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24692, v_t_24696});
      }
      case TAG_EApp: {
        V v_ru_24x111_24632_24EApp = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_24699 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str45)}), heff_dup(v_bsp_24631)});
        V v_t_24700 = heff_tag_at_n(v_ru_24x111_24632_24EApp, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24699}), heff_dup(v_rhs_241)});
        V v_t_24703;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24702 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24703 = v_s_24702;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24704 = ({ V rv_1 = heff_get_n(v_t_24703, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24700, v_t_24704});
      }
      case TAG_EProject: {
        V v_ru_24x111_24632_24EProject = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_24706 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str46)}), heff_dup(v_bsp_24631)});
        V v_t_24707 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EProject, TAG_PiAnon, 1, (V[]){v_t_24706}), heff_dup(v_rhs_241)});
        V v_t_24710;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24709 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24710 = v_s_24709;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24711 = ({ V rv_1 = heff_get_n(v_t_24710, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24707, v_t_24711});
      }
      case TAG_ENamed: {
        V v_ru_24x111_24632_24ENamed = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_24714 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str47)}), heff_dup(v_bsp_24631)});
        V v_t_24715 = heff_tag_at_n(v_ru_24x111_24632_24ENamed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24714}), heff_dup(v_rhs_241)});
        V v_t_24718;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24717 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24718 = v_s_24717;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24719 = ({ V rv_1 = heff_get_n(v_t_24718, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24715, v_t_24719});
      }
      case TAG_EPi: {
        V v_ru_24x111_24632_24EPi = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_24722 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str48)}), heff_dup(v_bsp_24631)});
        V v_t_24723 = heff_tag_at_n(v_ru_24x111_24632_24EPi, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24722}), heff_dup(v_rhs_241)});
        V v_t_24726;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24725 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24726 = v_s_24725;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24727 = ({ V rv_1 = heff_get_n(v_t_24726, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24723, v_t_24727});
      }
      case TAG_ELam: {
        V v_ru_24x111_24632_24ELam = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_24730 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str49)}), heff_dup(v_bsp_24631)});
        V v_t_24731 = heff_tag_at_n(v_ru_24x111_24632_24ELam, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24730}), heff_dup(v_rhs_241)});
        V v_t_24734;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_24733 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_24734 = v_s_24733;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_24735 = ({ V rv_1 = heff_get_n(v_t_24734, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24731, v_t_24735});
      }
      case TAG_EAnn: {
        V v_x1111_24736 = heff_field(v_x111_24632, 0);
        V v_t_24737 = heff_field(v_x111_24632, 1);
        V v_ru_24x111_24632_24EAnn = heff_take_reuse_n(v_x111_24632, 3ULL, 2);
        switch (heff_tag_of(v_x1111_24736)) {
        case TAG_At: {
          V v_x11111_24738 = heff_field(v_x1111_24736, 0);
          V v_xsp_24739 = heff_field(v_x1111_24736, 1);
          heff_take_n(v_x1111_24736, 3ULL, 2);
          switch (heff_tag_of(v_x11111_24738)) {
          case TAG_EVar: {
            V v_x_24740 = heff_field(v_x11111_24738, 0);
            heff_take_n(v_x11111_24738, 1ULL, 1);
            heff_drop_cell(v_ru_24x111_24632_24EAnn, 2);
            V v_t_24741 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiInstance, 4, (V[]){v_x_24740, v_xsp_24739, heff_dup(v_bsp_24631), v_t_24737}), heff_dup(v_rhs_241)});
            V v_t_24744;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24743 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24744 = v_s_24743;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24745 = ({ V rv_1 = heff_get_n(v_t_24744, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24741, v_t_24745});
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24747 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str50)}), heff_dup(v_bsp_24631)});
            V v_t_24748 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24747}), heff_dup(v_rhs_241)});
            V v_t_24751;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24750 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24751 = v_s_24750;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24752 = ({ V rv_1 = heff_get_n(v_t_24751, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24748, v_t_24752});
          }
          case TAG_ETag: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24754 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str51)}), heff_dup(v_bsp_24631)});
            V v_t_24755 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24754}), heff_dup(v_rhs_241)});
            V v_t_24758;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24757 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24758 = v_s_24757;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24759 = ({ V rv_1 = heff_get_n(v_t_24758, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24755, v_t_24759});
          }
          case TAG_EInt: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24761 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str52)}), heff_dup(v_bsp_24631)});
            V v_t_24762 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24761}), heff_dup(v_rhs_241)});
            V v_t_24765;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24764 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24765 = v_s_24764;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24766 = ({ V rv_1 = heff_get_n(v_t_24765, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24762, v_t_24766});
          }
          case TAG_EFloat: {
            heff_take_na(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24768 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str53)}), heff_dup(v_bsp_24631)});
            V v_t_24769 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24768}), heff_dup(v_rhs_241)});
            V v_t_24772;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24771 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24772 = v_s_24771;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24773 = ({ V rv_1 = heff_get_n(v_t_24772, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24769, v_t_24773});
          }
          case TAG_EString: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24775 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str54)}), heff_dup(v_bsp_24631)});
            V v_t_24776 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24775}), heff_dup(v_rhs_241)});
            V v_t_24779;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24778 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24779 = v_s_24778;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24780 = ({ V rv_1 = heff_get_n(v_t_24779, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24776, v_t_24780});
          }
          case TAG_EBinary: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24782 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str55)}), heff_dup(v_bsp_24631)});
            V v_t_24783 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24782}), heff_dup(v_rhs_241)});
            V v_t_24786;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24785 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24786 = v_s_24785;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24787 = ({ V rv_1 = heff_get_n(v_t_24786, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24783, v_t_24787});
          }
          case TAG_ERune: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24789 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str56)}), heff_dup(v_bsp_24631)});
            V v_t_24790 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24789}), heff_dup(v_rhs_241)});
            V v_t_24793;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24792 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24793 = v_s_24792;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24794 = ({ V rv_1 = heff_get_n(v_t_24793, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24790, v_t_24794});
          }
          case TAG_EWord: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24796 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str57)}), heff_dup(v_bsp_24631)});
            V v_t_24797 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24796}), heff_dup(v_rhs_241)});
            V v_t_24800;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24799 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24800 = v_s_24799;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24801 = ({ V rv_1 = heff_get_n(v_t_24800, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24797, v_t_24801});
          }
          case TAG_EApp: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24804 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str58)}), heff_dup(v_bsp_24631)});
            V v_t_24805 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24804}), heff_dup(v_rhs_241)});
            V v_t_24808;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24807 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24808 = v_s_24807;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24809 = ({ V rv_1 = heff_get_n(v_t_24808, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24805, v_t_24809});
          }
          case TAG_EProject: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24811 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str59)}), heff_dup(v_bsp_24631)});
            V v_t_24812 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24811}), heff_dup(v_rhs_241)});
            V v_t_24815;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24814 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24815 = v_s_24814;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24816 = ({ V rv_1 = heff_get_n(v_t_24815, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24812, v_t_24816});
          }
          case TAG_ENamed: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24819 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str60)}), heff_dup(v_bsp_24631)});
            V v_t_24820 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24819}), heff_dup(v_rhs_241)});
            V v_t_24823;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24822 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24823 = v_s_24822;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24824 = ({ V rv_1 = heff_get_n(v_t_24823, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24820, v_t_24824});
          }
          case TAG_EPi: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24827 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str61)}), heff_dup(v_bsp_24631)});
            V v_t_24828 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24827}), heff_dup(v_rhs_241)});
            V v_t_24831;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24830 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24831 = v_s_24830;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24832 = ({ V rv_1 = heff_get_n(v_t_24831, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24828, v_t_24832});
          }
          case TAG_ELam: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24835 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str62)}), heff_dup(v_bsp_24631)});
            V v_t_24836 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24835}), heff_dup(v_rhs_241)});
            V v_t_24839;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24838 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24839 = v_s_24838;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24840 = ({ V rv_1 = heff_get_n(v_t_24839, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24836, v_t_24840});
          }
          case TAG_EAnn: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24843 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str63)}), heff_dup(v_bsp_24631)});
            V v_t_24844 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24843}), heff_dup(v_rhs_241)});
            V v_t_24847;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24846 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24847 = v_s_24846;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24848 = ({ V rv_1 = heff_get_n(v_t_24847, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24844, v_t_24848});
          }
          case TAG_ESpec: {
            heff_take_n(v_x11111_24738, 0ULL, 4);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24853 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str64)}), heff_dup(v_bsp_24631)});
            V v_t_24854 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24853}), heff_dup(v_rhs_241)});
            V v_t_24857;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24856 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24857 = v_s_24856;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24858 = ({ V rv_1 = heff_get_n(v_t_24857, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24854, v_t_24858});
          }
          case TAG_ESig: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24860 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str65)}), heff_dup(v_bsp_24631)});
            V v_t_24861 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24860}), heff_dup(v_rhs_241)});
            V v_t_24864;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24863 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24864 = v_s_24863;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24865 = ({ V rv_1 = heff_get_n(v_t_24864, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24861, v_t_24865});
          }
          case TAG_ESum: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24867 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str66)}), heff_dup(v_bsp_24631)});
            V v_t_24868 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24867}), heff_dup(v_rhs_241)});
            V v_t_24871;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24870 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24871 = v_s_24870;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24872 = ({ V rv_1 = heff_get_n(v_t_24871, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24868, v_t_24872});
          }
          case TAG_EStruct: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24874 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str67)}), heff_dup(v_bsp_24631)});
            V v_t_24875 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24874}), heff_dup(v_rhs_241)});
            V v_t_24878;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24877 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24878 = v_s_24877;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24879 = ({ V rv_1 = heff_get_n(v_t_24878, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24875, v_t_24879});
          }
          case TAG_EUpdate: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24882 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str68)}), heff_dup(v_bsp_24631)});
            V v_t_24883 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24882}), heff_dup(v_rhs_241)});
            V v_t_24886;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24885 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24886 = v_s_24885;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24887 = ({ V rv_1 = heff_get_n(v_t_24886, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24883, v_t_24887});
          }
          case TAG_EMatch: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24890 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str69)}), heff_dup(v_bsp_24631)});
            V v_t_24891 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24890}), heff_dup(v_rhs_241)});
            V v_t_24894;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24893 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24894 = v_s_24893;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24895 = ({ V rv_1 = heff_get_n(v_t_24894, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24891, v_t_24895});
          }
          case TAG_ELetIn: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24898 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str70)}), heff_dup(v_bsp_24631)});
            V v_t_24899 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24898}), heff_dup(v_rhs_241)});
            V v_t_24902;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24901 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24902 = v_s_24901;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24903 = ({ V rv_1 = heff_get_n(v_t_24902, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24899, v_t_24903});
          }
          case TAG_EDo: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24905 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str71)}), heff_dup(v_bsp_24631)});
            V v_t_24906 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24905}), heff_dup(v_rhs_241)});
            V v_t_24909;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24908 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24909 = v_s_24908;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24910 = ({ V rv_1 = heff_get_n(v_t_24909, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24906, v_t_24910});
          }
          case TAG_ELocal: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24913 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str72)}), heff_dup(v_bsp_24631)});
            V v_t_24914 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24913}), heff_dup(v_rhs_241)});
            V v_t_24917;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24916 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24917 = v_s_24916;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24918 = ({ V rv_1 = heff_get_n(v_t_24917, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24914, v_t_24918});
          }
          case TAG_EInvalid: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24920 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str73)}), heff_dup(v_bsp_24631)});
            V v_t_24921 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24920}), heff_dup(v_rhs_241)});
            V v_t_24924;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24923 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24924 = v_s_24923;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24925 = ({ V rv_1 = heff_get_n(v_t_24924, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24921, v_t_24925});
          }
          case TAG_EAssign: {
            heff_take_n(v_x11111_24738, 0ULL, 3);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24929 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str74)}), heff_dup(v_bsp_24631)});
            V v_t_24930 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24929}), heff_dup(v_rhs_241)});
            V v_t_24933;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24932 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24933 = v_s_24932;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24934 = ({ V rv_1 = heff_get_n(v_t_24933, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24930, v_t_24934});
          }
          case TAG_EWhile: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24937 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str75)}), heff_dup(v_bsp_24631)});
            V v_t_24938 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24937}), heff_dup(v_rhs_241)});
            V v_t_24941;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24940 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24941 = v_s_24940;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24942 = ({ V rv_1 = heff_get_n(v_t_24941, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24938, v_t_24942});
          }
          case TAG_EFor: {
            heff_take_n(v_x11111_24738, 0ULL, 3);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24946 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str76)}), heff_dup(v_bsp_24631)});
            V v_t_24947 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24946}), heff_dup(v_rhs_241)});
            V v_t_24950;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24949 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24950 = v_s_24949;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24951 = ({ V rv_1 = heff_get_n(v_t_24950, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24947, v_t_24951});
          }
          case TAG_EIfThen: {
            heff_take_n(v_x11111_24738, 0ULL, 2);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24954 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str77)}), heff_dup(v_bsp_24631)});
            V v_t_24955 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24954}), heff_dup(v_rhs_241)});
            V v_t_24958;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24957 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24958 = v_s_24957;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24959 = ({ V rv_1 = heff_get_n(v_t_24958, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24955, v_t_24959});
          }
          case TAG_EBreak: {
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24960 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str78)}), heff_dup(v_bsp_24631)});
            V v_t_24961 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24960}), heff_dup(v_rhs_241)});
            V v_t_24964;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24963 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24964 = v_s_24963;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24965 = ({ V rv_1 = heff_get_n(v_t_24964, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24961, v_t_24965});
          }
          case TAG_EContinue: {
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24966 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str79)}), heff_dup(v_bsp_24631)});
            V v_t_24967 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24966}), heff_dup(v_rhs_241)});
            V v_t_24970;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24969 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24970 = v_s_24969;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24971 = ({ V rv_1 = heff_get_n(v_t_24970, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24967, v_t_24971});
          }
          case TAG_EReturn: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24973 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str80)}), heff_dup(v_bsp_24631)});
            V v_t_24974 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24973}), heff_dup(v_rhs_241)});
            V v_t_24977;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24976 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24977 = v_s_24976;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24978 = ({ V rv_1 = heff_get_n(v_t_24977, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24974, v_t_24978});
          }
          case TAG_ENest: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24980 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str81)}), heff_dup(v_bsp_24631)});
            V v_t_24981 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24980}), heff_dup(v_rhs_241)});
            V v_t_24984;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24983 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24984 = v_s_24983;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24985 = ({ V rv_1 = heff_get_n(v_t_24984, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24981, v_t_24985});
          }
          case TAG_ELazy: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24987 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str82)}), heff_dup(v_bsp_24631)});
            V v_t_24988 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24987}), heff_dup(v_rhs_241)});
            V v_t_24991;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24990 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24991 = v_s_24990;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24992 = ({ V rv_1 = heff_get_n(v_t_24991, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24988, v_t_24992});
          }
          case TAG_ETuple: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_24994 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str83)}), heff_dup(v_bsp_24631)});
            V v_t_24995 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24994}), heff_dup(v_rhs_241)});
            V v_t_24998;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_24997 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_24998 = v_s_24997;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_24999 = ({ V rv_1 = heff_get_n(v_t_24998, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_24995, v_t_24999});
          }
          case TAG_ETry: {
            heff_take_n(v_x11111_24738, 0ULL, 1);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_241001 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str84)}), heff_dup(v_bsp_24631)});
            V v_t_241002 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241001}), heff_dup(v_rhs_241)});
            V v_t_241005;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_241004 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_241005 = v_s_241004;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_241006 = ({ V rv_1 = heff_get_n(v_t_241005, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241002, v_t_241006});
          }
          case TAG_EWith: {
            heff_take_n(v_x11111_24738, 0ULL, 4);
            heff_drop(v_t_24737);
            heff_drop(v_xsp_24739);
            V v_t_241011 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str85)}), heff_dup(v_bsp_24631)});
            V v_t_241012 = heff_tag_at_n(v_ru_24x111_24632_24EAnn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241011}), heff_dup(v_rhs_241)});
            V v_t_241015;
            switch (heff_tag_of(v_rhs_241)) {
            case TAG_At: {
              V v_s_241014 = heff_field(v_rhs_241, 1);
              heff_take_n(v_rhs_241, 2ULL, 2);
              v_t_241015 = v_s_241014;
              break;
            }
            default: heff_nomatch(v_rhs_241);
            }
            V v_t_241016 = ({ V rv_1 = heff_get_n(v_t_241015, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241012, v_t_241016});
          }
          default: return heff_nomatch(v_x11111_24738);
          }
        }
        default: return heff_nomatch(v_x1111_24736);
        }
      }
      case TAG_ESpec: {
        heff_take_n(v_x111_24632, 0ULL, 4);
        V v_t_241021 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str86)}), heff_dup(v_bsp_24631)});
        V v_t_241022 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241021}), heff_dup(v_rhs_241)});
        V v_t_241025;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241024 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241025 = v_s_241024;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241026 = ({ V rv_1 = heff_get_n(v_t_241025, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241022, v_t_241026});
      }
      case TAG_ESig: {
        V v_ru_24x111_24632_24ESig = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241028 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str87)}), heff_dup(v_bsp_24631)});
        V v_t_241029 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ESig, TAG_PiAnon, 1, (V[]){v_t_241028}), heff_dup(v_rhs_241)});
        V v_t_241032;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241031 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241032 = v_s_241031;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241033 = ({ V rv_1 = heff_get_n(v_t_241032, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241029, v_t_241033});
      }
      case TAG_ESum: {
        V v_ru_24x111_24632_24ESum = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241035 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str88)}), heff_dup(v_bsp_24631)});
        V v_t_241036 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ESum, TAG_PiAnon, 1, (V[]){v_t_241035}), heff_dup(v_rhs_241)});
        V v_t_241039;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241038 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241039 = v_s_241038;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241040 = ({ V rv_1 = heff_get_n(v_t_241039, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241036, v_t_241040});
      }
      case TAG_EStruct: {
        V v_ru_24x111_24632_24EStruct = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241042 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str89)}), heff_dup(v_bsp_24631)});
        V v_t_241043 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EStruct, TAG_PiAnon, 1, (V[]){v_t_241042}), heff_dup(v_rhs_241)});
        V v_t_241046;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241045 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241046 = v_s_241045;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241047 = ({ V rv_1 = heff_get_n(v_t_241046, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241043, v_t_241047});
      }
      case TAG_EUpdate: {
        V v_ru_24x111_24632_24EUpdate = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_241050 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str90)}), heff_dup(v_bsp_24631)});
        V v_t_241051 = heff_tag_at_n(v_ru_24x111_24632_24EUpdate, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241050}), heff_dup(v_rhs_241)});
        V v_t_241054;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241053 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241054 = v_s_241053;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241055 = ({ V rv_1 = heff_get_n(v_t_241054, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241051, v_t_241055});
      }
      case TAG_EMatch: {
        V v_ru_24x111_24632_24EMatch = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_241058 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str91)}), heff_dup(v_bsp_24631)});
        V v_t_241059 = heff_tag_at_n(v_ru_24x111_24632_24EMatch, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241058}), heff_dup(v_rhs_241)});
        V v_t_241062;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241061 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241062 = v_s_241061;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241063 = ({ V rv_1 = heff_get_n(v_t_241062, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241059, v_t_241063});
      }
      case TAG_ELetIn: {
        V v_ru_24x111_24632_24ELetIn = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_241066 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str92)}), heff_dup(v_bsp_24631)});
        V v_t_241067 = heff_tag_at_n(v_ru_24x111_24632_24ELetIn, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241066}), heff_dup(v_rhs_241)});
        V v_t_241070;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241069 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241070 = v_s_241069;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241071 = ({ V rv_1 = heff_get_n(v_t_241070, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241067, v_t_241071});
      }
      case TAG_EDo: {
        V v_ru_24x111_24632_24EDo = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241073 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str93)}), heff_dup(v_bsp_24631)});
        V v_t_241074 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EDo, TAG_PiAnon, 1, (V[]){v_t_241073}), heff_dup(v_rhs_241)});
        V v_t_241077;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241076 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241077 = v_s_241076;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241078 = ({ V rv_1 = heff_get_n(v_t_241077, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241074, v_t_241078});
      }
      case TAG_ELocal: {
        V v_ru_24x111_24632_24ELocal = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_241081 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str94)}), heff_dup(v_bsp_24631)});
        V v_t_241082 = heff_tag_at_n(v_ru_24x111_24632_24ELocal, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241081}), heff_dup(v_rhs_241)});
        V v_t_241085;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241084 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241085 = v_s_241084;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241086 = ({ V rv_1 = heff_get_n(v_t_241085, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241082, v_t_241086});
      }
      case TAG_EInvalid: {
        V v_ru_24x111_24632_24EInvalid = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241088 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str95)}), heff_dup(v_bsp_24631)});
        V v_t_241089 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EInvalid, TAG_PiAnon, 1, (V[]){v_t_241088}), heff_dup(v_rhs_241)});
        V v_t_241092;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241091 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241092 = v_s_241091;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241093 = ({ V rv_1 = heff_get_n(v_t_241092, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241089, v_t_241093});
      }
      case TAG_EAssign: {
        heff_take_n(v_x111_24632, 0ULL, 3);
        V v_t_241097 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str96)}), heff_dup(v_bsp_24631)});
        V v_t_241098 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241097}), heff_dup(v_rhs_241)});
        V v_t_241101;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241100 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241101 = v_s_241100;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241102 = ({ V rv_1 = heff_get_n(v_t_241101, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241098, v_t_241102});
      }
      case TAG_EWhile: {
        V v_ru_24x111_24632_24EWhile = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_241105 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str97)}), heff_dup(v_bsp_24631)});
        V v_t_241106 = heff_tag_at_n(v_ru_24x111_24632_24EWhile, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241105}), heff_dup(v_rhs_241)});
        V v_t_241109;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241108 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241109 = v_s_241108;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241110 = ({ V rv_1 = heff_get_n(v_t_241109, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241106, v_t_241110});
      }
      case TAG_EFor: {
        heff_take_n(v_x111_24632, 0ULL, 3);
        V v_t_241114 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str98)}), heff_dup(v_bsp_24631)});
        V v_t_241115 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241114}), heff_dup(v_rhs_241)});
        V v_t_241118;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241117 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241118 = v_s_241117;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241119 = ({ V rv_1 = heff_get_n(v_t_241118, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241115, v_t_241119});
      }
      case TAG_EIfThen: {
        V v_ru_24x111_24632_24EIfThen = heff_take_reuse_n(v_x111_24632, 0ULL, 2);
        V v_t_241122 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str99)}), heff_dup(v_bsp_24631)});
        V v_t_241123 = heff_tag_at_n(v_ru_24x111_24632_24EIfThen, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241122}), heff_dup(v_rhs_241)});
        V v_t_241126;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241125 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241126 = v_s_241125;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241127 = ({ V rv_1 = heff_get_n(v_t_241126, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241123, v_t_241127});
      }
      case TAG_EBreak: {
        V v_t_241128 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str100)}), heff_dup(v_bsp_24631)});
        V v_t_241129 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241128}), heff_dup(v_rhs_241)});
        V v_t_241132;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241131 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241132 = v_s_241131;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241133 = ({ V rv_1 = heff_get_n(v_t_241132, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241129, v_t_241133});
      }
      case TAG_EContinue: {
        V v_t_241134 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str101)}), heff_dup(v_bsp_24631)});
        V v_t_241135 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241134}), heff_dup(v_rhs_241)});
        V v_t_241138;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241137 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241138 = v_s_241137;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241139 = ({ V rv_1 = heff_get_n(v_t_241138, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241135, v_t_241139});
      }
      case TAG_EReturn: {
        V v_ru_24x111_24632_24EReturn = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241141 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str102)}), heff_dup(v_bsp_24631)});
        V v_t_241142 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24EReturn, TAG_PiAnon, 1, (V[]){v_t_241141}), heff_dup(v_rhs_241)});
        V v_t_241145;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241144 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241145 = v_s_241144;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241146 = ({ V rv_1 = heff_get_n(v_t_241145, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241142, v_t_241146});
      }
      case TAG_ENest: {
        V v_ru_24x111_24632_24ENest = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241148 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str103)}), heff_dup(v_bsp_24631)});
        V v_t_241149 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ENest, TAG_PiAnon, 1, (V[]){v_t_241148}), heff_dup(v_rhs_241)});
        V v_t_241152;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241151 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241152 = v_s_241151;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241153 = ({ V rv_1 = heff_get_n(v_t_241152, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241149, v_t_241153});
      }
      case TAG_ELazy: {
        V v_ru_24x111_24632_24ELazy = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241155 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str104)}), heff_dup(v_bsp_24631)});
        V v_t_241156 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ELazy, TAG_PiAnon, 1, (V[]){v_t_241155}), heff_dup(v_rhs_241)});
        V v_t_241159;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241158 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241159 = v_s_241158;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241160 = ({ V rv_1 = heff_get_n(v_t_241159, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241156, v_t_241160});
      }
      case TAG_ETuple: {
        V v_ru_24x111_24632_24ETuple = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241162 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str105)}), heff_dup(v_bsp_24631)});
        V v_t_241163 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ETuple, TAG_PiAnon, 1, (V[]){v_t_241162}), heff_dup(v_rhs_241)});
        V v_t_241166;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241165 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241166 = v_s_241165;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241167 = ({ V rv_1 = heff_get_n(v_t_241166, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241163, v_t_241167});
      }
      case TAG_ETry: {
        V v_ru_24x111_24632_24ETry = heff_take_reuse_n(v_x111_24632, 0ULL, 1);
        V v_t_241169 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str106)}), heff_dup(v_bsp_24631)});
        V v_t_241170 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_at_n(v_ru_24x111_24632_24ETry, TAG_PiAnon, 1, (V[]){v_t_241169}), heff_dup(v_rhs_241)});
        V v_t_241173;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241172 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241173 = v_s_241172;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241174 = ({ V rv_1 = heff_get_n(v_t_241173, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241170, v_t_241174});
      }
      case TAG_EWith: {
        heff_take_n(v_x111_24632, 0ULL, 4);
        V v_t_241179 = heff_tag_at_n(v_ru_24x1_240_24Bracketed, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowBinop_str107)}), heff_dup(v_bsp_24631)});
        V v_t_241180 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_241179}), heff_dup(v_rhs_241)});
        V v_t_241183;
        switch (heff_tag_of(v_rhs_241)) {
        case TAG_At: {
          V v_s_241182 = heff_field(v_rhs_241, 1);
          heff_take_n(v_rhs_241, 2ULL, 2);
          v_t_241183 = v_s_241182;
          break;
        }
        default: heff_nomatch(v_rhs_241);
        }
        V v_t_241184 = ({ V rv_1 = heff_get_n(v_t_241183, 1, 2); V rr_ = heff_rec_reuse_nf(v_bsp_24631, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x11_24630_24At, TAG_At, 2, (V[]){v_t_241180, v_t_241184});
      }
      default: return heff_nomatch(v_x111_24632);
      }
    }
    default: return heff_nomatch(v_x11_24630);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2earrowBinop_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2earrowBinop(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str0, 37, "` does not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str2, 35, "` do not associate: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str3, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str5, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str6, 39, "` are both the loosest: add parentheses");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str8, 7, "` and `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str9, 85, "` are not related: add parentheses, or declare which binds tighter (`above`, `below`)");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str11, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str12, 34, "`), or import the module that does");
HEFF_LIT(g_heff_2esyntax_2esurface_2efirstS_str13, 1, "`");
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam1, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam2, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam5, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurface_2efirstS_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_lam7, 1, 0};
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efirstS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efirstS_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efirstS(V v_fix_240, V v_lenient_241, V v_before_242, V v_op_243) {
top: ;
  V v_it_244 = (g_heff_2esyntax_2efixity_2erelate(heff_dup(v_fix_240), heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1))));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Tighter: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam0_clo);
  }
  case TAG_Looser: {
    heff_drop(v_fix_240);
    heff_drop_rec(v_before_242, 9);
    heff_drop_rec(v_op_243, 9);
    return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam1_clo);
  }
  case TAG_Same: {
    V v_it1_249 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_AssocLeft: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam2_clo);
    }
    case TAG_AssocRight: {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam3_clo);
    }
    case TAG_AssocNone: {
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam4, 1, 2, (V[]){v_before_242, v_op_243});
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_Unrelated: {
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop(v_fix_240);
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam5_clo);
    } else {
      V v_a_2423 = heff_get_n(v_before_242, 1, 9);
      V v_b_2424 = heff_dup(heff_rfield(v_op_243, 1));
      V v_t_2425 = (g_heff_2esyntax_2efixity_2ebothLoosest(v_fix_240, heff_dup(v_a_2423), heff_dup(v_b_2424)));
      V v_msg_2428;
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_t_2425);
        V v_t_2426 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str5), heff_strAppend(v_b_2424, ((V)&g_heff_2esyntax_2esurface_2efirstS_str6)));
        v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str7), heff_strAppend(v_a_2423, v_t_2426));
      } else {
        heff_drop(v_t_2425);
        V v_t_2427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str8), heff_strAppend(v_b_2424, ((V)&g_heff_2esyntax_2esurface_2efirstS_str9)));
        v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str10), heff_strAppend(v_a_2423, v_t_2427));
      }
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam6, 1, 2, (V[]){v_op_243, v_msg_2428});
    }
  }
  case TAG_Undeclared: {
    V v_x_2432 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop(v_fix_240);
    if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
      heff_drop_rec(v_before_242, 9);
      heff_drop_rec(v_op_243, 9);
      heff_drop(v_x_2432);
      return ((V)&g_heff_2esyntax_2esurface_2efirstS_lam7_clo);
    } else {
      V v_t_2435;
      if (heff_strEq_c(heff_dup(v_x_2432), heff_dup(heff_rfield(v_op_243, 1)))) {
        heff_drop_rec(v_before_242, 9);
        v_t_2435 = v_op_243;
      } else {
        heff_drop_rec(v_op_243, 9);
        v_t_2435 = v_before_242;
      }
      V v_start_2436 = heff_take_field(v_t_2435, 3);
      V v_end_2437 = heff_get_n(v_t_2435, 4, 9);
      return heff_clo_n(g_heff_2esyntax_2esurface_2efirstS_lam8, 1, 3, (V[]){v_x_2432, v_start_2436, v_end_2437});
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2efirstS(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2efirstS_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_st_245});
}
V g_heff_2esyntax_2esurface_2efirstS_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_247});
}
V g_heff_2esyntax_2esurface_2efirstS_lam2(V self, V *args) {
  V v_st_2410 = args[0];
  V v_t_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_st_2410});
}
V g_heff_2esyntax_2esurface_2efirstS_lam3(V self, V *args) {
  V v_st_2412 = args[0];
  V v_t_2413 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_False)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_st_2412});
}
V g_heff_2esyntax_2esurface_2efirstS_lam4(V self, V *args) {
  V v_st_2414 = args[0];
  V v_before_242 = heff_env(self)[0];
  V v_op_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418;
  if (heff_strEq_c(heff_dup(heff_rfield(v_before_242, 1)), heff_dup(heff_rfield(v_op_243, 1)))) {
    heff_drop_rec(v_before_242, 9);
    V v_t_2415 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str0));
    v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str1), v_t_2415);
  } else {
    V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_op_243, 1)), ((V)&g_heff_2esyntax_2esurface_2efirstS_str2));
    V v_t_2417 = heff_strAppend(heff_get_n(v_before_242, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str3), v_t_2416));
    v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str4), v_t_2417);
  }
  V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2418, v_t_2419, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2420}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2efirstS_lam5(V self, V *args) {
  V v_st_2421 = args[0];
  V v_t_2422 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, v_st_2421});
}
V g_heff_2esyntax_2esurface_2efirstS_lam6(V self, V *args) {
  V v_st_2429 = args[0];
  V v_op_243 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_243, 3), heff_get_n(v_op_243, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2efirstS_lam7(V self, V *args) {
  V v_st_2433 = args[0];
  V v_t_2434 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_True)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_st_2433});
}
V g_heff_2esyntax_2esurface_2efirstS_lam8(V self, V *args) {
  V v_st_2438 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_start_2436 = heff_env(self)[1];
  V v_end_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str11), heff_strAppend(heff_dup(v_x_2432), ((V)&g_heff_2esyntax_2esurface_2efirstS_str12)));
  V v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efirstS_str13), heff_strAppend(v_x_2432, v_t_2439));
  V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2440, heff_rec_n(2, shape_start__end, (V[]){v_start_2436, v_end_2437}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2441}), v_st_2438});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2espreadGo_str11, 0, "");
Clo g_heff_2esyntax_2esurface_2espreadGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2espreadGo_entry, 5, 0};

V g_heff_2esyntax_2esurface_2espreadGo(V v_waiting_240, V v_held_241, V v_open_242, V v_x4_243, V v_acc_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_open_242);
    V v_t_245 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
    V v_xs_246 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_245));
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
  }
  case TAG_Cons: {
    V v_it_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_waiting_240)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_held_241)) {
      case TAG_Nil: {
        heff_drop(v_open_242);
        V v_g_2419;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          V v_sp_2413 = heff_dup(heff_field(v_it_247, 4));
          v_g_2419 = (g_heff_2esyntax_2esurface_2egroupFrom(v_sp_2413, heff_dup(v_rest_248)));
          break;
        }
        case TAG_Eqn: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        case TAG_Whole: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        case TAG_Doc: {
          v_g_2419 = heff_rec_n(3, shape_sigs__held__rest, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(v_rest_248)});
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        V v_sigs_2420 = heff_take_field(v_g_2419, 0);
        V v_held_2421 = heff_take_field(v_g_2419, 1);
        V v_rest_2422 = heff_get_n(v_g_2419, 2, 3);
        switch (heff_tag_of(v_sigs_2420)) {
        case TAG_Nil: {
          heff_drop(v_held_2421);
          heff_drop(v_rest_2422);
          V t_0 = NTAG(TAG_Nil);
          V t_1 = NTAG(TAG_Nil);
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_rest_248;
          V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        }
        case TAG_Cons: {
          heff_drop(v_rest_248);
          V t_0 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_sigs_2420});
          V t_1 = v_held_2421;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = v_rest_2422;
          V t_4 = v_acc_244;
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        }
        default: return heff_nomatch(v_sigs_2420);
        }
      }
      case TAG_Cons: {
        V v_t_2449;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          v_t_2449 = NTAG(TAG_False);
          break;
        }
        case TAG_Eqn: {
          switch (heff_tag_of(v_open_242)) {
          case TAG_Nothing: {
            v_t_2449 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_f_2435 = heff_dup(heff_field(v_open_242, 0));
            V v_t_2446;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              V v_f_2437 = heff_dup(heff_field(v_it_247, 1));
              v_t_2446 = v_f_2437;
              break;
            }
            case TAG_Eqn: {
              V v_f_2441 = heff_dup(heff_field(v_it_247, 0));
              v_t_2446 = v_f_2441;
              break;
            }
            case TAG_Whole: {
              v_t_2446 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str0);
              break;
            }
            case TAG_Doc: {
              v_t_2446 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str1);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            v_t_2449 = heff_bool(heff_strEq_c_lent(v_f_2435, v_t_2446, 0));
            heff_drop(v_f_2435);
            heff_drop(v_t_2446);
            break;
          }
          default: heff_nomatch(v_open_242);
          }
          break;
        }
        case TAG_Whole: {
          v_t_2449 = NTAG(TAG_False);
          break;
        }
        case TAG_Doc: {
          v_t_2449 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
          heff_drop(v_t_2449);
          V t_0 = v_waiting_240;
          V t_1 = v_held_241;
          V t_2 = v_open_242;
          V t_3 = v_rest_248;
          V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
          v_waiting_240 = t_0;
          v_held_241 = t_1;
          v_open_242 = t_2;
          v_x4_243 = t_3;
          v_acc_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2449);
          V v_t_2460;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            v_t_2460 = NTAG(TAG_False);
            break;
          }
          case TAG_Eqn: {
            v_t_2460 = NTAG(TAG_True);
            break;
          }
          case TAG_Whole: {
            v_t_2460 = NTAG(TAG_False);
            break;
          }
          case TAG_Doc: {
            v_t_2460 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
            heff_drop(v_open_242);
            heff_drop(v_t_2460);
            V v_t_2471;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              V v_f_2462 = heff_dup(heff_field(v_it_247, 1));
              v_t_2471 = v_f_2462;
              break;
            }
            case TAG_Eqn: {
              V v_f_2466 = heff_dup(heff_field(v_it_247, 0));
              v_t_2471 = v_f_2466;
              break;
            }
            case TAG_Whole: {
              v_t_2471 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str2);
              break;
            }
            case TAG_Doc: {
              v_t_2471 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str3);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            HeffT2 v_t_2472 = ({ V a_0 = v_t_2471; V a_1 = heff_dup(v_waiting_240); HeffT2 r_ = (g_heff_2esyntax_2esurface_2epickSig_24cpr(a_0, a_1)); heff_drop(v_t_2471); r_; });
            {
              V v_field_2474 = v_t_2472.f[1];
              int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
              if ((v_tag_2473 == ((int64_t)0ULL))) {
                V v_it_271_2475 = v_field_2474;
                switch (heff_tag_of(v_it_271_2475)) {
                case TAG_MkPair: {
                  V v_s_2476 = heff_field(v_it_271_2475, 0);
                  V v_more_2477 = heff_field(v_it_271_2475, 1);
                  heff_take_n(v_it_271_2475, 3ULL, 2);
                  V v_t_2488;
                  switch (heff_tag_of(v_it_247)) {
                  case TAG_Sig: {
                    V v_f_2479 = heff_dup(heff_field(v_it_247, 1));
                    v_t_2488 = v_f_2479;
                    break;
                  }
                  case TAG_Eqn: {
                    V v_f_2483 = heff_dup(heff_field(v_it_247, 0));
                    v_t_2488 = v_f_2483;
                    break;
                  }
                  case TAG_Whole: {
                    v_t_2488 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str4);
                    break;
                  }
                  case TAG_Doc: {
                    v_t_2488 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str5);
                    break;
                  }
                  default: heff_nomatch(v_it_247);
                  }
                  V v_t_2489 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, heff_tag_n(TAG_Cons, 2, (V[]){v_s_2476, v_acc_244})});
                  V t_0 = v_more_2477;
                  V t_1 = v_held_241;
                  V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2488});
                  V t_3 = v_rest_248;
                  V t_4 = v_t_2489;
                  v_waiting_240 = t_0;
                  v_held_241 = t_1;
                  v_open_242 = t_2;
                  v_x4_243 = t_3;
                  v_acc_244 = t_4;
                  goto top;
                }
                default: return heff_nomatch(v_it_271_2475);
                }
              } else {
                heff_drop(v_field_2474);
                V v_t_2490 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
                V v_t_2491 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_2490));
                V t_0 = NTAG(TAG_Nil);
                V t_1 = NTAG(TAG_Nil);
                V t_2 = NTAG(TAG_Nothing);
                V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
                V t_4 = v_t_2491;
                v_waiting_240 = t_0;
                v_held_241 = t_1;
                v_open_242 = t_2;
                v_x4_243 = t_3;
                v_acc_244 = t_4;
                goto top;
              }
            }
          } else {
            heff_drop(v_t_2460);
            V v_t_24124;
            switch (heff_tag_of(v_it_247)) {
            case TAG_Sig: {
              v_t_24124 = NTAG(TAG_False);
              break;
            }
            case TAG_Eqn: {
              v_t_24124 = NTAG(TAG_False);
              break;
            }
            case TAG_Whole: {
              V v_d_24100 = heff_dup(heff_field(v_it_247, 0));
              switch (heff_tag_of(v_d_24100)) {
              case TAG_At: {
                V v_x11_24101 = heff_field(v_d_24100, 0);
                heff_take_n(v_d_24100, 1ULL, 2);
                switch (heff_tag_of(v_x11_24101)) {
                case TAG_DeclEquations: {
                  heff_take_n(v_x11_24101, 0ULL, 5);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclDefine: {
                  heff_take_n(v_x11_24101, 0ULL, 5);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclTheory: {
                  heff_take_n(v_x11_24101, 0ULL, 4);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclPrimitive: {
                  heff_take_n(v_x11_24101, 0ULL, 3);
                  v_t_24124 = NTAG(TAG_False);
                  break;
                }
                case TAG_DeclTest: {
                  heff_take_n(v_x11_24101, 0ULL, 2);
                  v_t_24124 = NTAG(TAG_True);
                  break;
                }
                case TAG_DeclWatch: {
                  heff_take_n(v_x11_24101, 0ULL, 1);
                  v_t_24124 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_x11_24101);
                }
                break;
              }
              default: heff_nomatch(v_d_24100);
              }
              break;
            }
            case TAG_Doc: {
              v_t_24124 = NTAG(TAG_True);
              break;
            }
            default: heff_nomatch(v_it_247);
            }
            if ((heff_dup(v_t_24124) == NTAG(TAG_True))) {
              heff_drop(v_t_24124);
              V t_0 = v_waiting_240;
              V t_1 = v_held_241;
              V t_2 = v_open_242;
              V t_3 = v_rest_248;
              V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            } else {
              heff_drop(v_open_242);
              heff_drop(v_t_24124);
              V v_t_24125 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
              V v_t_24126 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24125));
              V t_0 = NTAG(TAG_Nil);
              V t_1 = NTAG(TAG_Nil);
              V t_2 = NTAG(TAG_Nothing);
              V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
              V t_4 = v_t_24126;
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            }
          }
        }
      }
      default: return heff_nomatch(v_held_241);
      }
    }
    case TAG_Cons: {
      V v_t_24151;
      switch (heff_tag_of(v_it_247)) {
      case TAG_Sig: {
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      case TAG_Eqn: {
        switch (heff_tag_of(v_open_242)) {
        case TAG_Nothing: {
          v_t_24151 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_f_24137 = heff_dup(heff_field(v_open_242, 0));
          V v_t_24148;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            V v_f_24139 = heff_dup(heff_field(v_it_247, 1));
            v_t_24148 = v_f_24139;
            break;
          }
          case TAG_Eqn: {
            V v_f_24143 = heff_dup(heff_field(v_it_247, 0));
            v_t_24148 = v_f_24143;
            break;
          }
          case TAG_Whole: {
            v_t_24148 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str6);
            break;
          }
          case TAG_Doc: {
            v_t_24148 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str7);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          v_t_24151 = heff_bool(heff_strEq_c_lent(v_f_24137, v_t_24148, 0));
          heff_drop(v_f_24137);
          heff_drop(v_t_24148);
          break;
        }
        default: heff_nomatch(v_open_242);
        }
        break;
      }
      case TAG_Whole: {
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      case TAG_Doc: {
        v_t_24151 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it_247);
      }
      if ((heff_dup(v_t_24151) == NTAG(TAG_True))) {
        heff_drop(v_t_24151);
        V t_0 = v_waiting_240;
        V t_1 = v_held_241;
        V t_2 = v_open_242;
        V t_3 = v_rest_248;
        V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
        v_waiting_240 = t_0;
        v_held_241 = t_1;
        v_open_242 = t_2;
        v_x4_243 = t_3;
        v_acc_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_24151);
        V v_t_24162;
        switch (heff_tag_of(v_it_247)) {
        case TAG_Sig: {
          v_t_24162 = NTAG(TAG_False);
          break;
        }
        case TAG_Eqn: {
          v_t_24162 = NTAG(TAG_True);
          break;
        }
        case TAG_Whole: {
          v_t_24162 = NTAG(TAG_False);
          break;
        }
        case TAG_Doc: {
          v_t_24162 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_it_247);
        }
        if ((heff_dup(v_t_24162) == NTAG(TAG_True))) {
          heff_drop(v_open_242);
          heff_drop(v_t_24162);
          V v_t_24173;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            V v_f_24164 = heff_dup(heff_field(v_it_247, 1));
            v_t_24173 = v_f_24164;
            break;
          }
          case TAG_Eqn: {
            V v_f_24168 = heff_dup(heff_field(v_it_247, 0));
            v_t_24173 = v_f_24168;
            break;
          }
          case TAG_Whole: {
            v_t_24173 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str8);
            break;
          }
          case TAG_Doc: {
            v_t_24173 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str9);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          HeffT2 v_t_24174 = ({ V a_0 = v_t_24173; V a_1 = heff_dup(v_waiting_240); HeffT2 r_ = (g_heff_2esyntax_2esurface_2epickSig_24cpr(a_0, a_1)); heff_drop(v_t_24173); r_; });
          {
            V v_field_24176 = v_t_24174.f[1];
            int64_t v_tag_24175 = ((int64_t)v_t_24174.f[0]);
            if ((v_tag_24175 == ((int64_t)0ULL))) {
              heff_drop_tag(v_waiting_240, 2);
              V v_it_271_24177 = v_field_24176;
              switch (heff_tag_of(v_it_271_24177)) {
              case TAG_MkPair: {
                V v_s_24178 = heff_field(v_it_271_24177, 0);
                V v_more_24179 = heff_field(v_it_271_24177, 1);
                heff_take_n(v_it_271_24177, 3ULL, 2);
                V v_t_24190;
                switch (heff_tag_of(v_it_247)) {
                case TAG_Sig: {
                  V v_f_24181 = heff_dup(heff_field(v_it_247, 1));
                  v_t_24190 = v_f_24181;
                  break;
                }
                case TAG_Eqn: {
                  V v_f_24185 = heff_dup(heff_field(v_it_247, 0));
                  v_t_24190 = v_f_24185;
                  break;
                }
                case TAG_Whole: {
                  v_t_24190 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str10);
                  break;
                }
                case TAG_Doc: {
                  v_t_24190 = ((V)&g_heff_2esyntax_2esurface_2espreadGo_str11);
                  break;
                }
                default: heff_nomatch(v_it_247);
                }
                V v_t_24191 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, heff_tag_n(TAG_Cons, 2, (V[]){v_s_24178, v_acc_244})});
                V t_0 = v_more_24179;
                V t_1 = v_held_241;
                V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24190});
                V t_3 = v_rest_248;
                V t_4 = v_t_24191;
                v_waiting_240 = t_0;
                v_held_241 = t_1;
                v_open_242 = t_2;
                v_x4_243 = t_3;
                v_acc_244 = t_4;
                goto top;
              }
              default: return heff_nomatch(v_it_271_24177);
              }
            } else {
              heff_drop(v_field_24176);
              V v_t_24192 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
              V v_t_24193 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24192));
              V t_0 = NTAG(TAG_Nil);
              V t_1 = NTAG(TAG_Nil);
              V t_2 = NTAG(TAG_Nothing);
              V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
              V t_4 = v_t_24193;
              v_waiting_240 = t_0;
              v_held_241 = t_1;
              v_open_242 = t_2;
              v_x4_243 = t_3;
              v_acc_244 = t_4;
              goto top;
            }
          }
        } else {
          heff_drop(v_t_24162);
          V v_t_24226;
          switch (heff_tag_of(v_it_247)) {
          case TAG_Sig: {
            v_t_24226 = NTAG(TAG_False);
            break;
          }
          case TAG_Eqn: {
            v_t_24226 = NTAG(TAG_False);
            break;
          }
          case TAG_Whole: {
            V v_d_24202 = heff_dup(heff_field(v_it_247, 0));
            switch (heff_tag_of(v_d_24202)) {
            case TAG_At: {
              V v_x11_24203 = heff_field(v_d_24202, 0);
              heff_take_n(v_d_24202, 1ULL, 2);
              switch (heff_tag_of(v_x11_24203)) {
              case TAG_DeclEquations: {
                heff_take_n(v_x11_24203, 0ULL, 5);
                v_t_24226 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclDefine: {
                heff_take_n(v_x11_24203, 0ULL, 5);
                v_t_24226 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclTheory: {
                heff_take_n(v_x11_24203, 0ULL, 4);
                v_t_24226 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclPrimitive: {
                heff_take_n(v_x11_24203, 0ULL, 3);
                v_t_24226 = NTAG(TAG_False);
                break;
              }
              case TAG_DeclTest: {
                heff_take_n(v_x11_24203, 0ULL, 2);
                v_t_24226 = NTAG(TAG_True);
                break;
              }
              case TAG_DeclWatch: {
                heff_take_n(v_x11_24203, 0ULL, 1);
                v_t_24226 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_x11_24203);
              }
              break;
            }
            default: heff_nomatch(v_d_24202);
            }
            break;
          }
          case TAG_Doc: {
            v_t_24226 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it_247);
          }
          if ((heff_dup(v_t_24226) == NTAG(TAG_True))) {
            heff_drop(v_t_24226);
            V t_0 = v_waiting_240;
            V t_1 = v_held_241;
            V t_2 = v_open_242;
            V t_3 = v_rest_248;
            V t_4 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_acc_244});
            v_waiting_240 = t_0;
            v_held_241 = t_1;
            v_open_242 = t_2;
            v_x4_243 = t_3;
            v_acc_244 = t_4;
            goto top;
          } else {
            heff_drop(v_open_242);
            heff_drop(v_t_24226);
            V v_t_24227 = (g_heff_2esyntax_2esurface_2erevOnto(v_waiting_240, v_acc_244));
            V v_t_24228 = (g_heff_2esyntax_2esurface_2erevOnto(v_held_241, v_t_24227));
            V t_0 = NTAG(TAG_Nil);
            V t_1 = NTAG(TAG_Nil);
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_it_247, v_rest_248});
            V t_4 = v_t_24228;
            v_waiting_240 = t_0;
            v_held_241 = t_1;
            v_open_242 = t_2;
            v_x4_243 = t_3;
            v_acc_244 = t_4;
            goto top;
          }
        }
      }
    }
    default: return heff_nomatch(v_waiting_240);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2espreadGo(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_f_242 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_242, v_x1_240}});
  }
  case TAG_EParen: {
    V v_f_246 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_246, v_x1_240}});
  }
  case TAG_Named: {
    V v_f_2412 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2412, v_x1_240}});
  }
  case TAG_Tup: {
    V v_f_2417 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2417, v_x1_240}});
  }
  case TAG_Seg: {
    V v_f_2421 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2421, v_x1_240}});
  }
  case TAG_Braces: {
    V v_f_2426 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2426, v_x1_240}});
  }
  case TAG_Update: {
    V v_f_2433 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2433, v_x1_240}});
  }
  case TAG_EUSet: {
    V v_f_2437 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2437, v_x1_240}});
  }
  case TAG_InstB: {
    V v_f_2443 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2443, v_x1_240}});
  }
  case TAG_EFSet: {
    V v_f_2447 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2447, v_x1_240}});
  }
  case TAG_EFDefault: {
    V v_f_2451 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2451, v_x1_240}});
  }
  case TAG_Sum: {
    V v_f_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2457, v_x1_240}});
  }
  case TAG_ECon: {
    V v_f_2460 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2460, v_x1_240}});
  }
  case TAG_EField: {
    V v_f_2463 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2463, v_x1_240}});
  }
  case TAG_ENeg: {
    V v_f_2466 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2466, v_x1_240}});
  }
  case TAG_ETilde: {
    V v_f_2469 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2469, v_x1_240}});
  }
  case TAG_App: {
    V v_f_2472 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2472, v_x1_240}});
  }
  case TAG_Op: {
    V v_f_2476 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2476, v_x1_240}});
  }
  case TAG_Ops: {
    V v_f_2479 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2479, v_x1_240}});
  }
  case TAG_OpRhs: {
    V v_op_2480 = heff_field(v_x1_240, 0);
    V v_e_2481 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return ((HeffT2){{v_op_2480, v_e_2481}});
  }
  case TAG_Ann: {
    V v_f_2485 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2485, v_x1_240}});
  }
  case TAG_BVar: {
    V v_f_2487 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2487, v_x1_240}});
  }
  case TAG_BImp: {
    V v_f_2491 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2491, v_x1_240}});
  }
  case TAG_BAnn: {
    V v_f_2497 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2497, v_x1_240}});
  }
  case TAG_BPat: {
    V v_f_2499 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_2499, v_x1_240}});
  }
  case TAG_Lam: {
    V v_f_24104 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24104, v_x1_240}});
  }
  case TAG_Case: {
    V v_f_24109 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24109, v_x1_240}});
  }
  case TAG_EAlt: {
    V v_f_24113 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24113, v_x1_240}});
  }
  case TAG_If: {
    V v_f_24120 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24120, v_x1_240}});
  }
  case TAG_Do: {
    V v_f_24123 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24123, v_x1_240}});
  }
  case TAG_ESBind: {
    V v_f_24127 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24127, v_x1_240}});
  }
  case TAG_ELet: {
    V v_f_24134 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24134, v_x1_240}});
  }
  case TAG_ELetElse: {
    V v_f_24142 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24142, v_x1_240}});
  }
  case TAG_ELetMut: {
    V v_f_24149 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24149, v_x1_240}});
  }
  case TAG_EAssign: {
    V v_f_24153 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24153, v_x1_240}});
  }
  case TAG_EWhile: {
    V v_f_24158 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24158, v_x1_240}});
  }
  case TAG_EFor: {
    V v_f_24165 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24165, v_x1_240}});
  }
  case TAG_EJump: {
    V v_f_24167 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24167, v_x1_240}});
  }
  case TAG_EReturn: {
    V v_f_24170 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24170, v_x1_240}});
  }
  case TAG_ENest: {
    V v_f_24175 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24175, v_x1_240}});
  }
  case TAG_EArrow: {
    V v_f_24178 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24178, v_x1_240}});
  }
  case TAG_IfThen: {
    V v_f_24183 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24183, v_x1_240}});
  }
  case TAG_ETry: {
    V v_f_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24188, v_x1_240}});
  }
  case TAG_ECatch: {
    V v_f_24193 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24193, v_x1_240}});
  }
  case TAG_EWith: {
    V v_f_24200 = (g_heff_2esyntax_2ecst_2efirstE(v_x1_240));
    return ((HeffT2){{v_f_24200, v_x1_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0, 2, ":=");

HeffT2 g_heff_2esyntax_2esurface_2ebracedOne_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 4);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_f_2421 = heff_field(v_x12_2418, 0);
      V v_x122_2422 = heff_field(v_x12_2418, 1);
      heff_take_n(v_x12_2418, 3ULL, 2);
      switch (heff_tag_of(v_x122_2422)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_f_2421)) {
        case TAG_Atom: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EParen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Named: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Tup: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Seg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Braces: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Update: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EUSet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_InstB: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EFSet: {
          heff_take_n(v_f_2421, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFDefault: {
          V v_eq_2461 = heff_dup(heff_field(v_f_2421, 1));
          if (heff_strEq_c(heff_get_n(v_eq_2461, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ebracedOne_24cpr_str0))) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
          } else {
            heff_drop_tag(v_f_2421, 3);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_Sum: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ECon: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EField: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ENeg: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ETilde: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_App: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Op: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Ops: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_OpRhs: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Ann: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BVar: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BImp: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BAnn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_BPat: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Lam: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Case: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EAlt: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_If: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_Do: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ESBind: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELet: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELetElse: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ELetMut: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EAssign: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EWhile: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EFor: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EJump: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EReturn: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ENest: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EArrow: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_IfThen: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ETry: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_ECatch: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        case TAG_EWith: {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2421}});
        }
        default: return ((HeffT2){{heff_nomatch(v_f_2421)}});
        }
      }
      case TAG_Cons: {
        heff_take_n(v_x122_2422, 0ULL, 2);
        heff_drop(v_f_2421);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_2422)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_heff_2esyntax_2esurface_2esettingsOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 4);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      V v_x121_2421 = heff_dup(heff_field(v_x12_2418, 0));
      switch (heff_tag_of(v_x121_2421)) {
      case TAG_Atom: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EParen: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Named: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Tup: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Seg: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Braces: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Update: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EUSet: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_InstB: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EFSet: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x12_2418}});
      }
      case TAG_EFDefault: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Sum: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ECon: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EField: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ENeg: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ETilde: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_App: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Op: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Ops: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_OpRhs: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Ann: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BVar: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BImp: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BAnn: {
        heff_take_n(v_x121_2421, 0ULL, 5);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_BPat: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Lam: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Case: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EAlt: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_If: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_Do: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ESBind: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ELet: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ELetElse: {
        heff_take_n(v_x121_2421, 0ULL, 7);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ELetMut: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EAssign: {
        heff_take_n(v_x121_2421, 0ULL, 3);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EWhile: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EFor: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EJump: {
        heff_take_n(v_x121_2421, 0ULL, 1);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EReturn: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ENest: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EArrow: {
        heff_take_n(v_x121_2421, 0ULL, 2);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_IfThen: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ETry: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_ECatch: {
        heff_take_n(v_x121_2421, 0ULL, 4);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      case TAG_EWith: {
        heff_take_n(v_x121_2421, 0ULL, 6);
        switch (heff_tag_of(v_x12_2418)) {
        case TAG_Cons: {
          heff_take_n(v_x12_2418, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x121_2421)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_2418)}});
    }
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETilde: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BPat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetElse: {
    heff_take_n(v_x1_240, 0ULL, 7);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EArrow: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0, 64, "a unit is what a size counts: say the size, `x::size(4)-unit(8)`");

HeffT2 g_heff_2esyntax_2esurface_2esegmentOf_24cpr(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_s_244, V v_st_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_s_244, 0));
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_v_243)) {
    case TAG_StrValue: {
      v_t_249 = NTAG(TAG_SegmentBinary);
      break;
    }
    case TAG_IntValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    case TAG_FloatValue: {
      v_t_249 = NTAG(TAG_SegmentFloat);
      break;
    }
    case TAG_RuneValue: {
      v_t_249 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_OtherValue: {
      v_t_249 = NTAG(TAG_SegmentInteger);
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    break;
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_249 = v_t_248;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_249, v_st_245));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_x11_2413 = v_field_2411;
    V v_st_2414 = v_field_2412;
    switch (heff_tag_of(v_x11_2413)) {
    case TAG_Left: {
      V v_e_2415 = heff_field(v_x11_2413, 0);
      V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      heff_drop_rec(v_s_244, 5);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
    }
    case TAG_Right: {
      V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 0ULL, 1);
      V v_t_2417 = heff_dup(heff_rfield(v_s_244, 1));
      V v_x11_2428;
      V v_st_2429;
      switch (heff_tag_of(v_t_2417)) {
      case TAG_SizeDefault: {
        V v_t_2418 = heff_dup(heff_rfield(v_s_244, 2));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          v_x11_2428 = v_t_2419;
          v_st_2429 = v_st_2414;
          break;
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_cell(v_ru_24x11_2413_24Right, 1);
          V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esegmentOf_24cpr_str0), heff_dup(v_sp_241), NTAG(TAG_Nothing)});
          v_x11_2428 = heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2421});
          v_st_2429 = v_st_2414;
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      case TAG_SizeNumber: {
        heff_take_n(v_t_2417, 0ULL, 1);
        V v_t_2423 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_x11_2428 = v_t_2423;
        v_st_2429 = v_st_2414;
        break;
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2417, 0ULL, 3);
        V v_t_2427 = heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        v_x11_2428 = v_t_2427;
        v_st_2429 = v_st_2414;
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      switch (heff_tag_of(v_x11_2428)) {
      case TAG_Left: {
        V v_e_2430 = heff_field(v_x11_2428, 0);
        V v_ru_24x11_2428_24Left = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
        heff_drop(v_sp_241);
        heff_drop(v_e_242);
        heff_drop(v_v_243);
        heff_drop_rec(v_s_244, 5);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2428_24Left, TAG_Left, 1, (V[]){v_e_2430}), v_st_2429}});
      }
      case TAG_Right: {
        V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 0ULL, 1);
        V v_t_2432 = heff_dup(heff_rfield(v_s_244, 0));
        V v_t_2435;
        switch (heff_tag_of(v_t_2432)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            v_t_2435 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            v_t_2435 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            v_t_2435 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2435 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            v_t_2435 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          break;
        }
        case TAG_Just: {
          V v_t_2434 = heff_field(v_t_2432, 0);
          heff_take_n(v_t_2432, 1ULL, 1);
          v_t_2435 = v_t_2434;
          break;
        }
        default: heff_nomatch(v_t_2432);
        }
        V v_t_2436 = heff_dup(heff_rfield(v_s_244, 0));
        V v_t_2439;
        switch (heff_tag_of(v_t_2436)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            v_t_2439 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            v_t_2439 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            v_t_2439 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2439 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            v_t_2439 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          break;
        }
        case TAG_Just: {
          V v_t_2438 = heff_field(v_t_2436, 0);
          heff_take_n(v_t_2436, 1ULL, 1);
          v_t_2439 = v_t_2438;
          break;
        }
        default: heff_nomatch(v_t_2436);
        }
        V v_unit_2440 = ({ V a_0 = v_t_2439; V a_1 = heff_rfield(v_s_244, 2); V r_ = (g_heff_2esyntax_2esurface_2eunitIn(a_0, a_1)); heff_drop(v_t_2439); r_; });
        V v_t_2441 = heff_dup(heff_rfield(v_s_244, 1));
        V v_t_2446;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_SizeDefault: {
          heff_drop(v_unit_2440);
          v_t_2446 = NTAG(TAG_SizeDefault);
          break;
        }
        case TAG_SizeNumber: {
          V v_n_2442 = heff_field(v_t_2441, 0);
          V v_ru_24t_2441_24SizeNumber = heff_take_reuse_n(v_t_2441, 1ULL, 1);
          v_t_2446 = heff_tag_at_n(v_ru_24t_2441_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2442, v_unit_2440)});
          break;
        }
        case TAG_SizeName: {
          V v_x_2443 = heff_field(v_t_2441, 0);
          V v_xsp_2444 = heff_field(v_t_2441, 1);
          V v_ru_24t_2441_24SizeName = heff_take_reuse_n(v_t_2441, 3ULL, 3);
          v_t_2446 = heff_tag_at_n(v_ru_24t_2441_24SizeName, TAG_SizeName, 3, (V[]){v_x_2443, v_xsp_2444, v_unit_2440});
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        V v_m_2447 = (g_heff_2esyntax_2esurface_2etypeChecks(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), heff_dup(v_s_244), v_t_2435, v_t_2446));
        V v_x1_2448 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_st_2429}));
        switch (heff_tag_of(v_x1_2448)) {
        case TAG_MkPair: {
          V v_x11_2449 = heff_field(v_x1_2448, 0);
          V v_st_2450 = heff_field(v_x1_2448, 1);
          V v_ru_24x1_2448_24MkPair = heff_take_reuse_n(v_x1_2448, 3ULL, 2);
          switch (heff_tag_of(v_x11_2449)) {
          case TAG_Left: {
            V v_e_2451 = heff_field(v_x11_2449, 0);
            V v_ru_24x11_2449_24Left = heff_take_reuse_n(v_x11_2449, 1ULL, 1);
            heff_drop(v_sp_241);
            heff_drop(v_e_242);
            heff_drop(v_v_243);
            heff_drop_rec(v_s_244, 5);
            heff_drop_cell(v_ru_24x11_2428_24Right, 1);
            heff_drop_cell(v_ru_24x1_2448_24MkPair, 2);
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2449_24Left, TAG_Left, 1, (V[]){v_e_2451}), v_st_2450}});
          }
          case TAG_Right: {
            V v_ru_24x11_2449_24Right = heff_take_reuse_n(v_x11_2449, 0ULL, 1);
            V v_t_2453 = heff_dup(heff_rfield(v_s_244, 0));
            V v_t_2456;
            switch (heff_tag_of(v_t_2453)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_v_243)) {
              case TAG_StrValue: {
                heff_drop_cell(v_ru_24x11_2449_24Right, 1);
                v_t_2456 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                heff_drop_cell(v_ru_24x11_2449_24Right, 1);
                v_t_2456 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                heff_drop_cell(v_ru_24x11_2449_24Right, 1);
                v_t_2456 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2456 = heff_tag_at_n(v_ru_24x11_2449_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                heff_drop_cell(v_ru_24x11_2449_24Right, 1);
                v_t_2456 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_243);
              }
              break;
            }
            case TAG_Just: {
              V v_t_2455 = heff_field(v_t_2453, 0);
              heff_take_n(v_t_2453, 1ULL, 1);
              heff_drop_cell(v_ru_24x11_2449_24Right, 1);
              v_t_2456 = v_t_2455;
              break;
            }
            default: heff_nomatch(v_t_2453);
            }
            V v_t_2457 = heff_take_field(v_s_244, 0);
            V v_t_2460;
            switch (heff_tag_of(v_t_2457)) {
            case TAG_Nothing: {
              switch (heff_tag_of(v_v_243)) {
              case TAG_StrValue: {
                v_t_2460 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                heff_take_n(v_v_243, 0ULL, 1);
                v_t_2460 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                v_t_2460 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2460 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                v_t_2460 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_243);
              }
              break;
            }
            case TAG_Just: {
              V v_t_2459 = heff_field(v_t_2457, 0);
              heff_take_n(v_t_2457, 1ULL, 1);
              heff_drop(v_v_243);
              v_t_2460 = v_t_2459;
              break;
            }
            default: heff_nomatch(v_t_2457);
            }
            V v_unit_2461 = ({ V a_0 = v_t_2460; V a_1 = heff_rfield(v_s_244, 2); V r_ = (g_heff_2esyntax_2esurface_2eunitIn(a_0, a_1)); heff_drop(v_t_2460); r_; });
            V v_t_2462 = heff_take_field(v_s_244, 1);
            V v_t_2467;
            switch (heff_tag_of(v_t_2462)) {
            case TAG_SizeDefault: {
              heff_drop(v_unit_2461);
              v_t_2467 = NTAG(TAG_SizeDefault);
              break;
            }
            case TAG_SizeNumber: {
              V v_n_2463 = heff_field(v_t_2462, 0);
              V v_ru_24t_2462_24SizeNumber = heff_take_reuse_n(v_t_2462, 1ULL, 1);
              v_t_2467 = heff_tag_at_n(v_ru_24t_2462_24SizeNumber, TAG_SizeNumber, 1, (V[]){heff_intMul(v_n_2463, v_unit_2461)});
              break;
            }
            case TAG_SizeName: {
              V v_x_2464 = heff_field(v_t_2462, 0);
              V v_xsp_2465 = heff_field(v_t_2462, 1);
              V v_ru_24t_2462_24SizeName = heff_take_reuse_n(v_t_2462, 3ULL, 3);
              v_t_2467 = heff_tag_at_n(v_ru_24t_2462_24SizeName, TAG_SizeName, 3, (V[]){v_x_2464, v_xsp_2465, v_unit_2461});
              break;
            }
            default: heff_nomatch(v_t_2462);
            }
            V v_t_2468 = heff_take_field(v_s_244, 3);
            V v_t_2470;
            switch (heff_tag_of(v_t_2468)) {
            case TAG_Nothing: {
              v_t_2470 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              V v_b_2469 = heff_field(v_t_2468, 0);
              heff_take_n(v_t_2468, 1ULL, 1);
              v_t_2470 = v_b_2469;
              break;
            }
            default: heff_nomatch(v_t_2468);
            }
            V v_t_2471 = heff_get_n(v_s_244, 4, 5);
            V v_t_2473;
            switch (heff_tag_of(v_t_2471)) {
            case TAG_Nothing: {
              v_t_2473 = NTAG(TAG_False);
              break;
            }
            case TAG_Just: {
              V v_b_2472 = heff_field(v_t_2471, 0);
              heff_take_n(v_t_2471, 1ULL, 1);
              v_t_2473 = v_b_2472;
              break;
            }
            default: heff_nomatch(v_t_2471);
            }
            V v_t_2474 = heff_tag_at_n(v_ru_24x1_2448_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2456, v_t_2467, v_t_2470, v_t_2473}), v_sp_241});
            V v_f_2475 = heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){v_t_2474});
            return ((HeffT2){{v_f_2475, v_st_2450}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2449)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2448)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2428)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str1, 33, "` is named twice in one signature");

HeffT2 g_heff_2esyntax_2esurface_2erepeatedIn_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_n_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_name_244 = heff_take_field(v_n_242, 0);
    V v_span_245 = heff_get_n(v_n_242, 1, 2);
    V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_name_244)}));
    V v_t_247 = (g_list_2eany(v_t_246, v_seen_240));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_seen_240);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_247);
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str0), heff_strAppend(v_name_244, ((V)&g_heff_2esyntax_2esurface_2erepeatedIn_24cpr_str1)));
      V v_f_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_248, v_span_245, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
    } else {
      heff_drop(v_span_245);
      heff_drop(v_t_247);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_name_244, v_seen_240});
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2emutualDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualDefs_entry, 1, 0};

V g_heff_2esyntax_2esurface_2emutualDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Sig: {
      V v_f_244 = heff_field(v_x11_241, 1);
      V v_fsp_245 = heff_field(v_x11_241, 2);
      V v_ty_246 = heff_field(v_x11_241, 3);
      V v_sp_247 = heff_field(v_x11_241, 4);
      heff_take_n(v_x11_241, 30ULL, 5);
      V v_end_248 = heff_take_field(v_sp_247, 1);
      V v_start_249 = heff_get_n(v_sp_247, 0, 2);
      HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_244, heff_dup(v_rest_242)));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_es_2413 = v_field_2412;
          V v_eqns_2414 = heff_take_field(v_es_2413, 0);
          V v_end_2415 = heff_get_n(v_es_2413, 1, 2);
          V v_a_2416 = v_end_248;
          V v_b_2417 = v_end_2415;
          V v_t_2418;
          if (heff_intLt_c_lent(v_a_2416, v_b_2417, 0)) {
            heff_drop(v_a_2416);
            v_t_2418 = v_b_2417;
          } else {
            heff_drop(v_b_2417);
            v_t_2418 = v_a_2416;
          }
          V v_t_2419 = heff_rec_n(5, shape_name__span__ty__eqns__whole, (V[]){v_f_244, v_fsp_245, v_ty_246, v_eqns_2414, heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_t_2418})});
          V v_cell_2420 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2419}), heff_hole()});
          V v_u_2421 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, heff_dup(v_cell_2420)));
          heff_drop(v_u_2421);
          return v_cell_2420;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_f_244);
          heff_drop(v_fsp_245);
          heff_drop(v_ty_246);
          heff_drop(v_end_248);
          heff_drop(v_start_249);
          heff_drop(v_field_2412);
          V t_0 = v_rest_242;
          v_x1_240 = t_0;
          goto top;
        }
      }
    }
    case TAG_Eqn: {
      heff_take_n(v_x11_241, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Whole: {
      V v_cell_2426 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_241}), heff_hole()});
      V v_u_2427 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, heff_dup(v_cell_2426)));
      heff_drop(v_u_2427);
      return v_cell_2426;
    }
    case TAG_Doc: {
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_241}), heff_hole()});
      V v_u_2430 = (g_heff_2esyntax_2esurface_2emutualDefs_24dps(v_rest_242, heff_dup(v_cell_2429)));
      heff_drop(v_u_2430);
      return v_cell_2429;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualDefs(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0, 31, "nothing can be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1, 5, "`: it");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2, 4, "`: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4, 28, "` cannot be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8, 2, " (");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10, 83, " is the loosest operator, below every other, declared `below` with nothing after it");
Clo g_heff_2esyntax_2esurface_2ebelowLoosestDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebelowLoosestDiag(V v_d_240, V v_u_241, V v_g_242) {
top: ;
  V v_text_243 = heff_take_field(v_u_241, 1);
  V v_start_244 = heff_take_field(v_u_241, 2);
  V v_end_245 = heff_get_n(v_u_241, 3, 7);
  V v_t_246 = heff_get_n(v_d_240, 1, 8);
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str0), heff_strAppend(v_text_243, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str1)));
    break;
  }
  case TAG_Cons: {
    V v_op_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str2), heff_strAppend(heff_dup(v_text_243), ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str3)));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str4), heff_strAppend(v_text_243, v_t_249));
    V v_t_2411 = heff_strAppend(heff_get_n(v_op_247, 1, 7), v_t_2410);
    v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str5), v_t_2411);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_at_2413 = heff_get_n(v_g_242, 4, 5);
  V v_t_2414;
  if (heff_strEq_c_lent(v_at_2413, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str6), 2)) {
    heff_drop(v_at_2413);
    v_t_2414 = ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str7);
  } else {
    v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str8), heff_strAppend(v_at_2413, ((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str9)));
  }
  V v_msg_2415 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ebelowLoosestDiag_str10), v_t_2414));
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2415, heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
}
V g_heff_2esyntax_2esurface_2ebelowLoosestDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebelowLoosestDiag(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr(V v_names_240, V v_pats_241, V v_rhs_242, V v_w_243, V v_st_244) {
top: ;
  V v_binders_245 = heff_take_field(v_st_244, 3);
  V v_toks_246 = heff_take_field(v_st_244, 0);
  V v_scope_247 = heff_take_field(v_st_244, 1);
  V v_known_248 = heff_take_field(v_st_244, 2);
  V v_fix_249 = heff_take_field(v_st_244, 5);
  V v_lenient_2410 = heff_take_field(v_st_244, 6);
  V v_at_2411 = heff_take_field(v_st_244, 7);
  V v_knot_2412 = heff_get_n(v_st_244, 8, 9);
  V v_t_2413 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_f_2414 = heff_get_n(v_t_2413, 0, 2);
  HeffT2 v_t_2415 = ({ V a_0 = v_binders_245; V a_1 = v_f_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_f_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_t_2419;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2417;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2417);
      v_t_2419 = NTAG(TAG_Nil);
    }
    V v_pv_2420 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2419));
    V v_m_2421 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 1)), heff_dup(v_pats_241)));
    V v_x1_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){heff_rec_n(9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, (V[]){v_toks_246, v_scope_247, v_known_248, v_binders_245, v_pv_2420, v_fix_249, v_lenient_2410, v_at_2411, v_knot_2412})}));
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_MkPair: {
      V v_x11_2423 = heff_field(v_x1_2422, 0);
      V v_st_2424 = heff_field(v_x1_2422, 1);
      V v_ru_24x1_2422_24MkPair = heff_take_reuse_n(v_x1_2422, 3ULL, 2);
      switch (heff_tag_of(v_x11_2423)) {
      case TAG_Left: {
        V v_e_2425 = heff_field(v_x11_2423, 0);
        V v_ru_24x11_2423_24Left = heff_take_reuse_n(v_x11_2423, 1ULL, 1);
        heff_drop(v_names_240);
        heff_drop(v_pats_241);
        heff_drop(v_rhs_242);
        heff_drop(v_t_2419);
        heff_drop_cell(v_ru_24x1_2422_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2423_24Left, TAG_Left, 1, (V[]){v_e_2425}), v_st_2424}});
      }
      case TAG_Right: {
        V v_x_2426 = heff_field(v_x11_2423, 0);
        heff_take_n(v_x11_2423, 1ULL, 1);
        V v_t_2427 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2419));
        V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2427}));
        V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_pats_241; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_241); r_; });
        V v_t_2430 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2419); r_; });
        V v_t_2431 = (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x1_2422_24MkPair, v_t_2429, v_t_2430));
        V v_t_2432 = ({ V rv_4 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_st_2424, 495ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261375u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2431, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0, 1, 4, (V[]){v_rhs_242, heff_dup(v_w_243), v_names_240, v_x_2426}), v_t_2432));
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2423)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2422)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1(V self, V *args) {
  V v_st_2439 = args[0];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2438}), v_st_2439});
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2(V self, V *args) {
  V v_rhs_27_2444 = args[0];
  V v_z_2445 = args[1];
  V v_names_240 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_t_2447 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_t_2448 = (g_heff_2esyntax_2esurface_2edeclNameOf(heff_dup(v_names_240)));
  V v_t_2449 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2447, 0, 2), heff_get_n(v_t_2448, 1, 2), v_x_2426, heff_dup(v_rhs_27_2444)});
  V v_t_2452;
  switch (heff_tag_of(v_names_240)) {
  case TAG_Nil: {
    v_t_2452 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2450 = heff_dup(heff_field(v_names_240, 0));
    v_t_2452 = heff_get_n(v_t_2450, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_240);
  }
  V v_t_2455;
  switch (heff_tag_of(v_rhs_27_2444)) {
  case TAG_At: {
    V v_s_2454 = heff_dup(heff_field(v_rhs_27_2444, 1));
    v_t_2455 = v_s_2454;
    break;
  }
  default: heff_nomatch(v_rhs_27_2444);
  }
  V v_t_2456 = ({ V rv_0 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_t_2455, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2459;
  switch (heff_tag_of(v_names_240)) {
  case TAG_Nil: {
    v_t_2459 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2457 = heff_field(v_names_240, 0);
    heff_take_n(v_names_240, 1ULL, 2);
    v_t_2459 = heff_get_n(v_t_2457, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_240);
  }
  V v_t_2462;
  switch (heff_tag_of(v_rhs_27_2444)) {
  case TAG_At: {
    V v_s_2461 = heff_field(v_rhs_27_2444, 1);
    heff_take_n(v_rhs_27_2444, 2ULL, 2);
    v_t_2462 = v_s_2461;
    break;
  }
  default: heff_nomatch(v_rhs_27_2444);
  }
  V v_t_2463 = ({ V rv_0 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_t_2462, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2464 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2446, 0, 2), heff_tag_n(TAG_At, 2, (V[]){v_t_2449, v_t_2456}), v_t_2463});
  V v_x_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2465}), v_z_2445});
}
V g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam0(V self, V *args) {
  V v_st_2433 = args[0];
  V v_rhs_242 = heff_env(self)[0];
  V v_w_243 = heff_env(self)[1];
  V v_names_240 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2434 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_rhs_242, v_st_2433));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_MkPair: {
    V v_x11_2435 = heff_field(v_x1_2434, 0);
    V v_st_2436 = heff_field(v_x1_2434, 1);
    V v_ru_24x1_2434_24MkPair = heff_take_reuse_n(v_x1_2434, 3ULL, 2);
    switch (heff_tag_of(v_x11_2435)) {
    case TAG_Left: {
      V v_e_2437 = heff_field(v_x11_2435, 0);
      heff_take_n(v_x11_2435, 1ULL, 1);
      heff_drop(v_w_243);
      heff_drop(v_names_240);
      heff_drop(v_x_2426);
      return heff_tag_at_n(v_ru_24x1_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2437}), v_st_2436});
    }
    case TAG_Right: {
      V v_x_2438 = heff_field(v_x11_2435, 0);
      heff_take_n(v_x11_2435, 1ULL, 1);
      V v_t_2443;
      switch (heff_tag_of(v_w_243)) {
      case TAG_Nothing: {
        v_t_2443 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam1, 1, 1, (V[]){v_x_2438});
        break;
      }
      case TAG_Just: {
        V v_it1_2440 = heff_field(v_w_243, 0);
        heff_take_n(v_w_243, 1ULL, 1);
        switch (heff_tag_of(v_it1_2440)) {
        case TAG_MkPair: {
          V v_kw_2441 = heff_field(v_it1_2440, 0);
          V v_ds_2442 = heff_field(v_it1_2440, 1);
          heff_take_n(v_it1_2440, 3ULL, 2);
          v_t_2443 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_24s1448449087x1522943570_clo), 3, (V[]){v_kw_2441, v_ds_2442, v_x_2438}));
          break;
        }
        default: heff_nomatch(v_it1_2440);
        }
        break;
      }
      default: heff_nomatch(v_w_243);
      }
      return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_2434_24MkPair, v_t_2443, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24s264252993x1642491133_24cpr_lam2, 2, 2, (V[]){v_names_240, v_x_2426}), v_st_2436));
    }
    default: return heff_nomatch(v_x11_2435);
    }
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1, 1, "(");
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2ebracedOne_24cpr(heff_dup(v_e_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_f_244 = v_field_243;
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0, 1, 2, (V[]){v_f_244, v_e_240});
    } else {
      heff_drop(v_field_243);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1, 1, 1, (V[]){v_e_240});
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2edeclarationL_24s1582704578x1612600550_24cpr(v_f_244, v_st_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x11_249 = v_field_247;
    V v_st_2410 = v_field_248;
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      HeffT2 v_t_2413 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(heff_dup(v_x_2412)));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          heff_drop(v_x_2412);
          V v_q_2416 = v_field_2415;
          V v_name_2417 = heff_take_field(v_q_2416, 0);
          V v_span_2418 = heff_take_field(v_q_2416, 1);
          V v_ty_2419 = heff_get_n(v_q_2416, 2, 3);
          V v_a_2420 = (g_heff_2esyntax_2ecst_2efirstE(v_e_240));
          V v_b_2421 = (g_heff_2esyntax_2ecst_2elastE(v_e_240));
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_a_2420, 3, 9), heff_get_n(v_b_2421, 4, 9)});
          V v_x_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_name_2417, v_span_2418, v_ty_2419}), v_t_2422});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){v_x_2423}), v_st_2410});
        } else {
          heff_drop(v_e_240);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          heff_drop(v_field_2415);
          V v_t_2426;
          switch (heff_tag_of(v_x_2412)) {
          case TAG_At: {
            V v_s_2425 = heff_field(v_x_2412, 1);
            heff_take_n(v_x_2412, 2ULL, 2);
            v_t_2426 = v_s_2425;
            break;
          }
          default: heff_nomatch(v_x_2412);
          }
          V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str0), v_t_2426, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2427}), v_st_2410});
        }
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2(V self, V *args) {
  V v_st_2436 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2433}), v_st_2436});
}
V g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam1(V self, V *args) {
  V v_st_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_e_240), v_st_2428));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      heff_drop(v_e_240);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_t_2434 = ({ V a_0 = v_e_240; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_240); r_; });
      V v_m_2437;
      if (heff_strEq_c(heff_get_n(v_t_2434, 1, 9), ((V)&g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_str1))) {
        V v_t_2435 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2433));
        v_m_2437 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2435}));
      } else {
        v_m_2437 = heff_clo_n(g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602_lam2, 1, 1, (V[]){v_x_2433});
      }
      V v_x1_2438 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_st_2431}));
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_MkPair: {
        V v_x11_2439 = heff_field(v_x1_2438, 0);
        V v_st_2440 = heff_field(v_x1_2438, 1);
        heff_take_n(v_x1_2438, 3ULL, 2);
        switch (heff_tag_of(v_x11_2439)) {
        case TAG_Left: {
          V v_e_2441 = heff_field(v_x11_2439, 0);
          heff_take_n(v_x11_2439, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2441}), v_st_2440});
        }
        case TAG_Right: {
          V v_x_2442 = heff_field(v_x11_2439, 0);
          heff_take_n(v_x11_2439, 1ULL, 1);
          return (g_heff_2esyntax_2esurface_2eparamOf_24tok2(v_ru_24x1_2429_24MkPair, v_x_2442, v_st_2440));
        }
        default: return heff_nomatch(v_x11_2439);
        }
      }
      default: return heff_nomatch(v_x1_2438);
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V v_e_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(heff_dup(v_e_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      heff_drop(v_e_240);
      V v_x_244 = v_field_243;
      V v_text_245 = heff_take_field(v_x_244, 1);
      V v_start_246 = heff_take_field(v_x_244, 3);
      V v_end_247 = heff_get_n(v_x_244, 4, 9);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0, 1, 3, (V[]){v_start_246, v_end_247, v_text_245});
    } else {
      heff_drop(v_field_243);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf_24s1674347541x1924888602(v_e_240);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(a[0]);
}
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_lam0(V self, V *args) {
  V v_st_248 = args[0];
  V v_start_246 = heff_env(self)[0];
  V v_end_247 = heff_env(self)[1];
  V v_text_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_246), heff_dup(v_end_247)})});
  V v_t_2411 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_text_245, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_246), heff_dup(v_end_247)}), v_t_2410});
  V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2412}), v_st_248});
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam44(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Atom: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EParen: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Named: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Tup: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Seg: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Braces: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Update: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EUSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7, 1, 1, (V[]){v_x2_240});
  }
  case TAG_InstB: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFSet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFDefault: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Sum: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ECon: {
    V v_c_24130 = heff_field(v_x2_240, 0);
    V v_args_24131 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24132 = (g_heff_2esyntax_2esurface_2econL_24s2127692828x1347224016(v_c_24130, v_args_24131));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12, 1, 1, (V[]){v_m_24132});
  }
  case TAG_EField: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ENeg: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ETilde: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_App: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Op: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Ops: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_OpRhs: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Ann: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BVar: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BImp: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BAnn: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23, 1, 1, (V[]){v_x2_240});
  }
  case TAG_BPat: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Lam: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Case: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAlt: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27, 1, 1, (V[]){v_x2_240});
  }
  case TAG_If: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28, 1, 1, (V[]){v_x2_240});
  }
  case TAG_Do: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ESBind: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELet: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELetElse: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELetMut: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAssign: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EWhile: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFor: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EJump: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EReturn: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam38, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ENest: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam39, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EArrow: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam40, 1, 1, (V[]){v_x2_240});
  }
  case TAG_IfThen: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam41, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ETry: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam42, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ECatch: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam43, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EWith: {
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam44, 1, 1, (V[]){v_x2_240});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366(a[0]);
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_243 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_242));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      V v_x_248 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_247));
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_248}), v_st_245});
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2413 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      V v_x_2418 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2417));
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2418}), v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam2(V self, V *args) {
  V v_st_2424 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2425 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2424));
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_MkPair: {
    V v_x11_2426 = heff_field(v_x1_2425, 0);
    V v_st_2427 = heff_field(v_x1_2425, 1);
    V v_ru_24x1_2425_24MkPair = heff_take_reuse_n(v_x1_2425, 3ULL, 2);
    switch (heff_tag_of(v_x11_2426)) {
    case TAG_Left: {
      V v_e_2428 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2428}), v_st_2427});
    }
    case TAG_Right: {
      V v_x_2429 = heff_field(v_x11_2426, 0);
      heff_take_n(v_x11_2426, 1ULL, 1);
      V v_x_2430 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2429));
      return heff_tag_at_n(v_ru_24x1_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2430}), v_st_2427});
    }
    default: return heff_nomatch(v_x11_2426);
    }
  }
  default: return heff_nomatch(v_x1_2425);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam3(V self, V *args) {
  V v_st_2435 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2436 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2435));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_MkPair: {
    V v_x11_2437 = heff_field(v_x1_2436, 0);
    V v_st_2438 = heff_field(v_x1_2436, 1);
    V v_ru_24x1_2436_24MkPair = heff_take_reuse_n(v_x1_2436, 3ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_Left: {
      V v_e_2439 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2439}), v_st_2438});
    }
    case TAG_Right: {
      V v_x_2440 = heff_field(v_x11_2437, 0);
      heff_take_n(v_x11_2437, 1ULL, 1);
      V v_x_2441 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2440));
      return heff_tag_at_n(v_ru_24x1_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2441}), v_st_2438});
    }
    default: return heff_nomatch(v_x11_2437);
    }
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam4(V self, V *args) {
  V v_st_2445 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2446 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2445));
  switch (heff_tag_of(v_x1_2446)) {
  case TAG_MkPair: {
    V v_x11_2447 = heff_field(v_x1_2446, 0);
    V v_st_2448 = heff_field(v_x1_2446, 1);
    V v_ru_24x1_2446_24MkPair = heff_take_reuse_n(v_x1_2446, 3ULL, 2);
    switch (heff_tag_of(v_x11_2447)) {
    case TAG_Left: {
      V v_e_2449 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2449}), v_st_2448});
    }
    case TAG_Right: {
      V v_x_2450 = heff_field(v_x11_2447, 0);
      heff_take_n(v_x11_2447, 1ULL, 1);
      V v_x_2451 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2450));
      return heff_tag_at_n(v_ru_24x1_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2451}), v_st_2448});
    }
    default: return heff_nomatch(v_x11_2447);
    }
  }
  default: return heff_nomatch(v_x1_2446);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam5(V self, V *args) {
  V v_st_2456 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2457 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2456));
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_MkPair: {
    V v_x11_2458 = heff_field(v_x1_2457, 0);
    V v_st_2459 = heff_field(v_x1_2457, 1);
    V v_ru_24x1_2457_24MkPair = heff_take_reuse_n(v_x1_2457, 3ULL, 2);
    switch (heff_tag_of(v_x11_2458)) {
    case TAG_Left: {
      V v_e_2460 = heff_field(v_x11_2458, 0);
      heff_take_n(v_x11_2458, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2460}), v_st_2459});
    }
    case TAG_Right: {
      V v_x_2461 = heff_field(v_x11_2458, 0);
      heff_take_n(v_x11_2458, 1ULL, 1);
      V v_x_2462 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2461));
      return heff_tag_at_n(v_ru_24x1_2457_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2462}), v_st_2459});
    }
    default: return heff_nomatch(v_x11_2458);
    }
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam6(V self, V *args) {
  V v_st_2469 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2470 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2469));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_MkPair: {
    V v_x11_2471 = heff_field(v_x1_2470, 0);
    V v_st_2472 = heff_field(v_x1_2470, 1);
    V v_ru_24x1_2470_24MkPair = heff_take_reuse_n(v_x1_2470, 3ULL, 2);
    switch (heff_tag_of(v_x11_2471)) {
    case TAG_Left: {
      V v_e_2473 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2473}), v_st_2472});
    }
    case TAG_Right: {
      V v_x_2474 = heff_field(v_x11_2471, 0);
      heff_take_n(v_x11_2471, 1ULL, 1);
      V v_x_2475 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2474));
      return heff_tag_at_n(v_ru_24x1_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2475}), v_st_2472});
    }
    default: return heff_nomatch(v_x11_2471);
    }
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam7(V self, V *args) {
  V v_st_2479 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2480 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2479));
  switch (heff_tag_of(v_x1_2480)) {
  case TAG_MkPair: {
    V v_x11_2481 = heff_field(v_x1_2480, 0);
    V v_st_2482 = heff_field(v_x1_2480, 1);
    V v_ru_24x1_2480_24MkPair = heff_take_reuse_n(v_x1_2480, 3ULL, 2);
    switch (heff_tag_of(v_x11_2481)) {
    case TAG_Left: {
      V v_e_2483 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2483}), v_st_2482});
    }
    case TAG_Right: {
      V v_x_2484 = heff_field(v_x11_2481, 0);
      heff_take_n(v_x11_2481, 1ULL, 1);
      V v_x_2485 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2484));
      return heff_tag_at_n(v_ru_24x1_2480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2485}), v_st_2482});
    }
    default: return heff_nomatch(v_x11_2481);
    }
  }
  default: return heff_nomatch(v_x1_2480);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam8(V self, V *args) {
  V v_st_2491 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2492 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_2491));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      V v_x_2497 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2496));
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2497}), v_st_2494});
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam9(V self, V *args) {
  V v_st_24101 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24101));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24106));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam10(V self, V *args) {
  V v_st_24111 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24112 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24111));
  switch (heff_tag_of(v_x1_24112)) {
  case TAG_MkPair: {
    V v_x11_24113 = heff_field(v_x1_24112, 0);
    V v_st_24114 = heff_field(v_x1_24112, 1);
    V v_ru_24x1_24112_24MkPair = heff_take_reuse_n(v_x1_24112, 3ULL, 2);
    switch (heff_tag_of(v_x11_24113)) {
    case TAG_Left: {
      V v_e_24115 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24115}), v_st_24114});
    }
    case TAG_Right: {
      V v_x_24116 = heff_field(v_x11_24113, 0);
      heff_take_n(v_x11_24113, 1ULL, 1);
      V v_x_24117 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24116));
      return heff_tag_at_n(v_ru_24x1_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24117}), v_st_24114});
    }
    default: return heff_nomatch(v_x11_24113);
    }
  }
  default: return heff_nomatch(v_x1_24112);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam11(V self, V *args) {
  V v_st_24123 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24124 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24123));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      V v_x_24129 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24128));
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24129}), v_st_24126});
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam12(V self, V *args) {
  V v_st_24133 = args[0];
  V v_m_24132 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24134 = heff_tr(heff_call(v_m_24132, 1, (V[]){v_st_24133}));
  switch (heff_tag_of(v_x1_24134)) {
  case TAG_MkPair: {
    V v_x11_24135 = heff_field(v_x1_24134, 0);
    V v_st_24136 = heff_field(v_x1_24134, 1);
    V v_ru_24x1_24134_24MkPair = heff_take_reuse_n(v_x1_24134, 3ULL, 2);
    switch (heff_tag_of(v_x11_24135)) {
    case TAG_Left: {
      V v_e_24137 = heff_field(v_x11_24135, 0);
      heff_take_n(v_x11_24135, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24137}), v_st_24136});
    }
    case TAG_Right: {
      V v_x_24138 = heff_field(v_x11_24135, 0);
      heff_take_n(v_x11_24135, 1ULL, 1);
      V v_x_24139 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24138));
      return heff_tag_at_n(v_ru_24x1_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24139}), v_st_24136});
    }
    default: return heff_nomatch(v_x11_24135);
    }
  }
  default: return heff_nomatch(v_x1_24134);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam13(V self, V *args) {
  V v_st_24142 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24143 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24142));
  switch (heff_tag_of(v_x1_24143)) {
  case TAG_MkPair: {
    V v_x11_24144 = heff_field(v_x1_24143, 0);
    V v_st_24145 = heff_field(v_x1_24143, 1);
    V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
    switch (heff_tag_of(v_x11_24144)) {
    case TAG_Left: {
      V v_e_24146 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
    }
    case TAG_Right: {
      V v_x_24147 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      V v_x_24148 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24147));
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24148}), v_st_24145});
    }
    default: return heff_nomatch(v_x11_24144);
    }
  }
  default: return heff_nomatch(v_x1_24143);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam14(V self, V *args) {
  V v_st_24151 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24152 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24151));
  switch (heff_tag_of(v_x1_24152)) {
  case TAG_MkPair: {
    V v_x11_24153 = heff_field(v_x1_24152, 0);
    V v_st_24154 = heff_field(v_x1_24152, 1);
    V v_ru_24x1_24152_24MkPair = heff_take_reuse_n(v_x1_24152, 3ULL, 2);
    switch (heff_tag_of(v_x11_24153)) {
    case TAG_Left: {
      V v_e_24155 = heff_field(v_x11_24153, 0);
      heff_take_n(v_x11_24153, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24155}), v_st_24154});
    }
    case TAG_Right: {
      V v_x_24156 = heff_field(v_x11_24153, 0);
      heff_take_n(v_x11_24153, 1ULL, 1);
      V v_x_24157 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24156));
      return heff_tag_at_n(v_ru_24x1_24152_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24157}), v_st_24154});
    }
    default: return heff_nomatch(v_x11_24153);
    }
  }
  default: return heff_nomatch(v_x1_24152);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam15(V self, V *args) {
  V v_st_24160 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24161 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24160));
  switch (heff_tag_of(v_x1_24161)) {
  case TAG_MkPair: {
    V v_x11_24162 = heff_field(v_x1_24161, 0);
    V v_st_24163 = heff_field(v_x1_24161, 1);
    V v_ru_24x1_24161_24MkPair = heff_take_reuse_n(v_x1_24161, 3ULL, 2);
    switch (heff_tag_of(v_x11_24162)) {
    case TAG_Left: {
      V v_e_24164 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24164}), v_st_24163});
    }
    case TAG_Right: {
      V v_x_24165 = heff_field(v_x11_24162, 0);
      heff_take_n(v_x11_24162, 1ULL, 1);
      V v_x_24166 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24165));
      return heff_tag_at_n(v_ru_24x1_24161_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24163});
    }
    default: return heff_nomatch(v_x11_24162);
    }
  }
  default: return heff_nomatch(v_x1_24161);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam16(V self, V *args) {
  V v_st_24169 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24170 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24169));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_MkPair: {
    V v_x11_24171 = heff_field(v_x1_24170, 0);
    V v_st_24172 = heff_field(v_x1_24170, 1);
    V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
    switch (heff_tag_of(v_x11_24171)) {
    case TAG_Left: {
      V v_e_24173 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
    }
    case TAG_Right: {
      V v_x_24174 = heff_field(v_x11_24171, 0);
      heff_take_n(v_x11_24171, 1ULL, 1);
      V v_x_24175 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24174));
      return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24175}), v_st_24172});
    }
    default: return heff_nomatch(v_x11_24171);
    }
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam17(V self, V *args) {
  V v_st_24179 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24180 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24179));
  switch (heff_tag_of(v_x1_24180)) {
  case TAG_MkPair: {
    V v_x11_24181 = heff_field(v_x1_24180, 0);
    V v_st_24182 = heff_field(v_x1_24180, 1);
    V v_ru_24x1_24180_24MkPair = heff_take_reuse_n(v_x1_24180, 3ULL, 2);
    switch (heff_tag_of(v_x11_24181)) {
    case TAG_Left: {
      V v_e_24183 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24183}), v_st_24182});
    }
    case TAG_Right: {
      V v_x_24184 = heff_field(v_x11_24181, 0);
      heff_take_n(v_x11_24181, 1ULL, 1);
      V v_x_24185 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24184));
      return heff_tag_at_n(v_ru_24x1_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24185}), v_st_24182});
    }
    default: return heff_nomatch(v_x11_24181);
    }
  }
  default: return heff_nomatch(v_x1_24180);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam18(V self, V *args) {
  V v_st_24188 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24189 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24188));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_MkPair: {
    V v_x11_24190 = heff_field(v_x1_24189, 0);
    V v_st_24191 = heff_field(v_x1_24189, 1);
    V v_ru_24x1_24189_24MkPair = heff_take_reuse_n(v_x1_24189, 3ULL, 2);
    switch (heff_tag_of(v_x11_24190)) {
    case TAG_Left: {
      V v_e_24192 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24192}), v_st_24191});
    }
    case TAG_Right: {
      V v_x_24193 = heff_field(v_x11_24190, 0);
      heff_take_n(v_x11_24190, 1ULL, 1);
      V v_x_24194 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24193));
      return heff_tag_at_n(v_ru_24x1_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24194}), v_st_24191});
    }
    default: return heff_nomatch(v_x11_24190);
    }
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam19(V self, V *args) {
  V v_st_24197 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24198 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24197));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_x11_24199 = heff_field(v_x1_24198, 0);
    V v_st_24200 = heff_field(v_x1_24198, 1);
    V v_ru_24x1_24198_24MkPair = heff_take_reuse_n(v_x1_24198, 3ULL, 2);
    switch (heff_tag_of(v_x11_24199)) {
    case TAG_Left: {
      V v_e_24201 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
    }
    case TAG_Right: {
      V v_x_24202 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      V v_x_24203 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24202));
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24203}), v_st_24200});
    }
    default: return heff_nomatch(v_x11_24199);
    }
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam20(V self, V *args) {
  V v_st_24207 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24208 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24207));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_MkPair: {
    V v_x11_24209 = heff_field(v_x1_24208, 0);
    V v_st_24210 = heff_field(v_x1_24208, 1);
    V v_ru_24x1_24208_24MkPair = heff_take_reuse_n(v_x1_24208, 3ULL, 2);
    switch (heff_tag_of(v_x11_24209)) {
    case TAG_Left: {
      V v_e_24211 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24211}), v_st_24210});
    }
    case TAG_Right: {
      V v_x_24212 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      V v_x_24213 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24212));
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24210});
    }
    default: return heff_nomatch(v_x11_24209);
    }
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam21(V self, V *args) {
  V v_st_24215 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24216 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24215));
  switch (heff_tag_of(v_x1_24216)) {
  case TAG_MkPair: {
    V v_x11_24217 = heff_field(v_x1_24216, 0);
    V v_st_24218 = heff_field(v_x1_24216, 1);
    V v_ru_24x1_24216_24MkPair = heff_take_reuse_n(v_x1_24216, 3ULL, 2);
    switch (heff_tag_of(v_x11_24217)) {
    case TAG_Left: {
      V v_e_24219 = heff_field(v_x11_24217, 0);
      heff_take_n(v_x11_24217, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24216_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24219}), v_st_24218});
    }
    case TAG_Right: {
      V v_x_24220 = heff_field(v_x11_24217, 0);
      heff_take_n(v_x11_24217, 1ULL, 1);
      V v_x_24221 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24220));
      return heff_tag_at_n(v_ru_24x1_24216_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24221}), v_st_24218});
    }
    default: return heff_nomatch(v_x11_24217);
    }
  }
  default: return heff_nomatch(v_x1_24216);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam22(V self, V *args) {
  V v_st_24225 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24226 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24225));
  switch (heff_tag_of(v_x1_24226)) {
  case TAG_MkPair: {
    V v_x11_24227 = heff_field(v_x1_24226, 0);
    V v_st_24228 = heff_field(v_x1_24226, 1);
    V v_ru_24x1_24226_24MkPair = heff_take_reuse_n(v_x1_24226, 3ULL, 2);
    switch (heff_tag_of(v_x11_24227)) {
    case TAG_Left: {
      V v_e_24229 = heff_field(v_x11_24227, 0);
      heff_take_n(v_x11_24227, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24229}), v_st_24228});
    }
    case TAG_Right: {
      V v_x_24230 = heff_field(v_x11_24227, 0);
      heff_take_n(v_x11_24227, 1ULL, 1);
      V v_x_24231 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24230));
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24231}), v_st_24228});
    }
    default: return heff_nomatch(v_x11_24227);
    }
  }
  default: return heff_nomatch(v_x1_24226);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam23(V self, V *args) {
  V v_st_24237 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24237));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_MkPair: {
    V v_x11_24239 = heff_field(v_x1_24238, 0);
    V v_st_24240 = heff_field(v_x1_24238, 1);
    V v_ru_24x1_24238_24MkPair = heff_take_reuse_n(v_x1_24238, 3ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_Left: {
      V v_e_24241 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24241}), v_st_24240});
    }
    case TAG_Right: {
      V v_x_24242 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      V v_x_24243 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24242));
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24243}), v_st_24240});
    }
    default: return heff_nomatch(v_x11_24239);
    }
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam24(V self, V *args) {
  V v_st_24245 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24246 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24245));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_MkPair: {
    V v_x11_24247 = heff_field(v_x1_24246, 0);
    V v_st_24248 = heff_field(v_x1_24246, 1);
    V v_ru_24x1_24246_24MkPair = heff_take_reuse_n(v_x1_24246, 3ULL, 2);
    switch (heff_tag_of(v_x11_24247)) {
    case TAG_Left: {
      V v_e_24249 = heff_field(v_x11_24247, 0);
      heff_take_n(v_x11_24247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24249}), v_st_24248});
    }
    case TAG_Right: {
      V v_x_24250 = heff_field(v_x11_24247, 0);
      heff_take_n(v_x11_24247, 1ULL, 1);
      V v_x_24251 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24250));
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24251}), v_st_24248});
    }
    default: return heff_nomatch(v_x11_24247);
    }
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam25(V self, V *args) {
  V v_st_24256 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24257 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24256));
  switch (heff_tag_of(v_x1_24257)) {
  case TAG_MkPair: {
    V v_x11_24258 = heff_field(v_x1_24257, 0);
    V v_st_24259 = heff_field(v_x1_24257, 1);
    V v_ru_24x1_24257_24MkPair = heff_take_reuse_n(v_x1_24257, 3ULL, 2);
    switch (heff_tag_of(v_x11_24258)) {
    case TAG_Left: {
      V v_e_24260 = heff_field(v_x11_24258, 0);
      heff_take_n(v_x11_24258, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24260}), v_st_24259});
    }
    case TAG_Right: {
      V v_x_24261 = heff_field(v_x11_24258, 0);
      heff_take_n(v_x11_24258, 1ULL, 1);
      V v_x_24262 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24261));
      return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24262}), v_st_24259});
    }
    default: return heff_nomatch(v_x11_24258);
    }
  }
  default: return heff_nomatch(v_x1_24257);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam26(V self, V *args) {
  V v_st_24267 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24268 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24267));
  switch (heff_tag_of(v_x1_24268)) {
  case TAG_MkPair: {
    V v_x11_24269 = heff_field(v_x1_24268, 0);
    V v_st_24270 = heff_field(v_x1_24268, 1);
    V v_ru_24x1_24268_24MkPair = heff_take_reuse_n(v_x1_24268, 3ULL, 2);
    switch (heff_tag_of(v_x11_24269)) {
    case TAG_Left: {
      V v_e_24271 = heff_field(v_x11_24269, 0);
      heff_take_n(v_x11_24269, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24271}), v_st_24270});
    }
    case TAG_Right: {
      V v_x_24272 = heff_field(v_x11_24269, 0);
      heff_take_n(v_x11_24269, 1ULL, 1);
      V v_x_24273 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24272));
      return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24273}), v_st_24270});
    }
    default: return heff_nomatch(v_x11_24269);
    }
  }
  default: return heff_nomatch(v_x1_24268);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam27(V self, V *args) {
  V v_st_24277 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24278 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24277));
  switch (heff_tag_of(v_x1_24278)) {
  case TAG_MkPair: {
    V v_x11_24279 = heff_field(v_x1_24278, 0);
    V v_st_24280 = heff_field(v_x1_24278, 1);
    V v_ru_24x1_24278_24MkPair = heff_take_reuse_n(v_x1_24278, 3ULL, 2);
    switch (heff_tag_of(v_x11_24279)) {
    case TAG_Left: {
      V v_e_24281 = heff_field(v_x11_24279, 0);
      heff_take_n(v_x11_24279, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24278_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24281}), v_st_24280});
    }
    case TAG_Right: {
      V v_x_24282 = heff_field(v_x11_24279, 0);
      heff_take_n(v_x11_24279, 1ULL, 1);
      V v_x_24283 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24282));
      return heff_tag_at_n(v_ru_24x1_24278_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24283}), v_st_24280});
    }
    default: return heff_nomatch(v_x11_24279);
    }
  }
  default: return heff_nomatch(v_x1_24278);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam28(V self, V *args) {
  V v_st_24290 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24291 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24290));
  switch (heff_tag_of(v_x1_24291)) {
  case TAG_MkPair: {
    V v_x11_24292 = heff_field(v_x1_24291, 0);
    V v_st_24293 = heff_field(v_x1_24291, 1);
    V v_ru_24x1_24291_24MkPair = heff_take_reuse_n(v_x1_24291, 3ULL, 2);
    switch (heff_tag_of(v_x11_24292)) {
    case TAG_Left: {
      V v_e_24294 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24294}), v_st_24293});
    }
    case TAG_Right: {
      V v_x_24295 = heff_field(v_x11_24292, 0);
      heff_take_n(v_x11_24292, 1ULL, 1);
      V v_x_24296 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24295));
      return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24296}), v_st_24293});
    }
    default: return heff_nomatch(v_x11_24292);
    }
  }
  default: return heff_nomatch(v_x1_24291);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam29(V self, V *args) {
  V v_st_24299 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24300 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24299));
  switch (heff_tag_of(v_x1_24300)) {
  case TAG_MkPair: {
    V v_x11_24301 = heff_field(v_x1_24300, 0);
    V v_st_24302 = heff_field(v_x1_24300, 1);
    V v_ru_24x1_24300_24MkPair = heff_take_reuse_n(v_x1_24300, 3ULL, 2);
    switch (heff_tag_of(v_x11_24301)) {
    case TAG_Left: {
      V v_e_24303 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24303}), v_st_24302});
    }
    case TAG_Right: {
      V v_x_24304 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      V v_x_24305 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24304));
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24305}), v_st_24302});
    }
    default: return heff_nomatch(v_x11_24301);
    }
  }
  default: return heff_nomatch(v_x1_24300);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam30(V self, V *args) {
  V v_st_24309 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24310 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24309));
  switch (heff_tag_of(v_x1_24310)) {
  case TAG_MkPair: {
    V v_x11_24311 = heff_field(v_x1_24310, 0);
    V v_st_24312 = heff_field(v_x1_24310, 1);
    V v_ru_24x1_24310_24MkPair = heff_take_reuse_n(v_x1_24310, 3ULL, 2);
    switch (heff_tag_of(v_x11_24311)) {
    case TAG_Left: {
      V v_e_24313 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24313}), v_st_24312});
    }
    case TAG_Right: {
      V v_x_24314 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      V v_x_24315 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24314));
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24315}), v_st_24312});
    }
    default: return heff_nomatch(v_x11_24311);
    }
  }
  default: return heff_nomatch(v_x1_24310);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam31(V self, V *args) {
  V v_st_24322 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24323 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24322));
  switch (heff_tag_of(v_x1_24323)) {
  case TAG_MkPair: {
    V v_x11_24324 = heff_field(v_x1_24323, 0);
    V v_st_24325 = heff_field(v_x1_24323, 1);
    V v_ru_24x1_24323_24MkPair = heff_take_reuse_n(v_x1_24323, 3ULL, 2);
    switch (heff_tag_of(v_x11_24324)) {
    case TAG_Left: {
      V v_e_24326 = heff_field(v_x11_24324, 0);
      heff_take_n(v_x11_24324, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24323_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24326}), v_st_24325});
    }
    case TAG_Right: {
      V v_x_24327 = heff_field(v_x11_24324, 0);
      heff_take_n(v_x11_24324, 1ULL, 1);
      V v_x_24328 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24327));
      return heff_tag_at_n(v_ru_24x1_24323_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24328}), v_st_24325});
    }
    default: return heff_nomatch(v_x11_24324);
    }
  }
  default: return heff_nomatch(v_x1_24323);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam32(V self, V *args) {
  V v_st_24336 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24337 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24336));
  switch (heff_tag_of(v_x1_24337)) {
  case TAG_MkPair: {
    V v_x11_24338 = heff_field(v_x1_24337, 0);
    V v_st_24339 = heff_field(v_x1_24337, 1);
    V v_ru_24x1_24337_24MkPair = heff_take_reuse_n(v_x1_24337, 3ULL, 2);
    switch (heff_tag_of(v_x11_24338)) {
    case TAG_Left: {
      V v_e_24340 = heff_field(v_x11_24338, 0);
      heff_take_n(v_x11_24338, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24340}), v_st_24339});
    }
    case TAG_Right: {
      V v_x_24341 = heff_field(v_x11_24338, 0);
      heff_take_n(v_x11_24338, 1ULL, 1);
      V v_x_24342 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24341));
      return heff_tag_at_n(v_ru_24x1_24337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24342}), v_st_24339});
    }
    default: return heff_nomatch(v_x11_24338);
    }
  }
  default: return heff_nomatch(v_x1_24337);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam33(V self, V *args) {
  V v_st_24349 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24350 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24349));
  switch (heff_tag_of(v_x1_24350)) {
  case TAG_MkPair: {
    V v_x11_24351 = heff_field(v_x1_24350, 0);
    V v_st_24352 = heff_field(v_x1_24350, 1);
    V v_ru_24x1_24350_24MkPair = heff_take_reuse_n(v_x1_24350, 3ULL, 2);
    switch (heff_tag_of(v_x11_24351)) {
    case TAG_Left: {
      V v_e_24353 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24353}), v_st_24352});
    }
    case TAG_Right: {
      V v_x_24354 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      V v_x_24355 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24354));
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24355}), v_st_24352});
    }
    default: return heff_nomatch(v_x11_24351);
    }
  }
  default: return heff_nomatch(v_x1_24350);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam34(V self, V *args) {
  V v_st_24359 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24360 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24359));
  switch (heff_tag_of(v_x1_24360)) {
  case TAG_MkPair: {
    V v_x11_24361 = heff_field(v_x1_24360, 0);
    V v_st_24362 = heff_field(v_x1_24360, 1);
    V v_ru_24x1_24360_24MkPair = heff_take_reuse_n(v_x1_24360, 3ULL, 2);
    switch (heff_tag_of(v_x11_24361)) {
    case TAG_Left: {
      V v_e_24363 = heff_field(v_x11_24361, 0);
      heff_take_n(v_x11_24361, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24360_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24363}), v_st_24362});
    }
    case TAG_Right: {
      V v_x_24364 = heff_field(v_x11_24361, 0);
      heff_take_n(v_x11_24361, 1ULL, 1);
      V v_x_24365 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24364));
      return heff_tag_at_n(v_ru_24x1_24360_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24365}), v_st_24362});
    }
    default: return heff_nomatch(v_x11_24361);
    }
  }
  default: return heff_nomatch(v_x1_24360);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam35(V self, V *args) {
  V v_st_24370 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24371 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24370));
  switch (heff_tag_of(v_x1_24371)) {
  case TAG_MkPair: {
    V v_x11_24372 = heff_field(v_x1_24371, 0);
    V v_st_24373 = heff_field(v_x1_24371, 1);
    V v_ru_24x1_24371_24MkPair = heff_take_reuse_n(v_x1_24371, 3ULL, 2);
    switch (heff_tag_of(v_x11_24372)) {
    case TAG_Left: {
      V v_e_24374 = heff_field(v_x11_24372, 0);
      heff_take_n(v_x11_24372, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24371_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24374}), v_st_24373});
    }
    case TAG_Right: {
      V v_x_24375 = heff_field(v_x11_24372, 0);
      heff_take_n(v_x11_24372, 1ULL, 1);
      V v_x_24376 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24375));
      return heff_tag_at_n(v_ru_24x1_24371_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24376}), v_st_24373});
    }
    default: return heff_nomatch(v_x11_24372);
    }
  }
  default: return heff_nomatch(v_x1_24371);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam36(V self, V *args) {
  V v_st_24383 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24384 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24383));
  switch (heff_tag_of(v_x1_24384)) {
  case TAG_MkPair: {
    V v_x11_24385 = heff_field(v_x1_24384, 0);
    V v_st_24386 = heff_field(v_x1_24384, 1);
    V v_ru_24x1_24384_24MkPair = heff_take_reuse_n(v_x1_24384, 3ULL, 2);
    switch (heff_tag_of(v_x11_24385)) {
    case TAG_Left: {
      V v_e_24387 = heff_field(v_x11_24385, 0);
      heff_take_n(v_x11_24385, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24384_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24387}), v_st_24386});
    }
    case TAG_Right: {
      V v_x_24388 = heff_field(v_x11_24385, 0);
      heff_take_n(v_x11_24385, 1ULL, 1);
      V v_x_24389 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24388));
      return heff_tag_at_n(v_ru_24x1_24384_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24389}), v_st_24386});
    }
    default: return heff_nomatch(v_x11_24385);
    }
  }
  default: return heff_nomatch(v_x1_24384);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam37(V self, V *args) {
  V v_st_24391 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24392 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24391));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_MkPair: {
    V v_x11_24393 = heff_field(v_x1_24392, 0);
    V v_st_24394 = heff_field(v_x1_24392, 1);
    V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
    switch (heff_tag_of(v_x11_24393)) {
    case TAG_Left: {
      V v_e_24395 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
    }
    case TAG_Right: {
      V v_x_24396 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      V v_x_24397 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24396));
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24397}), v_st_24394});
    }
    default: return heff_nomatch(v_x11_24393);
    }
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam38(V self, V *args) {
  V v_st_24400 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24401 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24400));
  switch (heff_tag_of(v_x1_24401)) {
  case TAG_MkPair: {
    V v_x11_24402 = heff_field(v_x1_24401, 0);
    V v_st_24403 = heff_field(v_x1_24401, 1);
    V v_ru_24x1_24401_24MkPair = heff_take_reuse_n(v_x1_24401, 3ULL, 2);
    switch (heff_tag_of(v_x11_24402)) {
    case TAG_Left: {
      V v_e_24404 = heff_field(v_x11_24402, 0);
      heff_take_n(v_x11_24402, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24401_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24404}), v_st_24403});
    }
    case TAG_Right: {
      V v_x_24405 = heff_field(v_x11_24402, 0);
      heff_take_n(v_x11_24402, 1ULL, 1);
      V v_x_24406 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24405));
      return heff_tag_at_n(v_ru_24x1_24401_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24406}), v_st_24403});
    }
    default: return heff_nomatch(v_x11_24402);
    }
  }
  default: return heff_nomatch(v_x1_24401);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam39(V self, V *args) {
  V v_st_24411 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24412 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24411));
  switch (heff_tag_of(v_x1_24412)) {
  case TAG_MkPair: {
    V v_x11_24413 = heff_field(v_x1_24412, 0);
    V v_st_24414 = heff_field(v_x1_24412, 1);
    V v_ru_24x1_24412_24MkPair = heff_take_reuse_n(v_x1_24412, 3ULL, 2);
    switch (heff_tag_of(v_x11_24413)) {
    case TAG_Left: {
      V v_e_24415 = heff_field(v_x11_24413, 0);
      heff_take_n(v_x11_24413, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24415}), v_st_24414});
    }
    case TAG_Right: {
      V v_x_24416 = heff_field(v_x11_24413, 0);
      heff_take_n(v_x11_24413, 1ULL, 1);
      V v_x_24417 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24416));
      return heff_tag_at_n(v_ru_24x1_24412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24417}), v_st_24414});
    }
    default: return heff_nomatch(v_x11_24413);
    }
  }
  default: return heff_nomatch(v_x1_24412);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam40(V self, V *args) {
  V v_st_24420 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24421 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24420));
  switch (heff_tag_of(v_x1_24421)) {
  case TAG_MkPair: {
    V v_x11_24422 = heff_field(v_x1_24421, 0);
    V v_st_24423 = heff_field(v_x1_24421, 1);
    V v_ru_24x1_24421_24MkPair = heff_take_reuse_n(v_x1_24421, 3ULL, 2);
    switch (heff_tag_of(v_x11_24422)) {
    case TAG_Left: {
      V v_e_24424 = heff_field(v_x11_24422, 0);
      heff_take_n(v_x11_24422, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24424}), v_st_24423});
    }
    case TAG_Right: {
      V v_x_24425 = heff_field(v_x11_24422, 0);
      heff_take_n(v_x11_24422, 1ULL, 1);
      V v_x_24426 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24425));
      return heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24426}), v_st_24423});
    }
    default: return heff_nomatch(v_x11_24422);
    }
  }
  default: return heff_nomatch(v_x1_24421);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam41(V self, V *args) {
  V v_st_24431 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24432 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24431));
  switch (heff_tag_of(v_x1_24432)) {
  case TAG_MkPair: {
    V v_x11_24433 = heff_field(v_x1_24432, 0);
    V v_st_24434 = heff_field(v_x1_24432, 1);
    V v_ru_24x1_24432_24MkPair = heff_take_reuse_n(v_x1_24432, 3ULL, 2);
    switch (heff_tag_of(v_x11_24433)) {
    case TAG_Left: {
      V v_e_24435 = heff_field(v_x11_24433, 0);
      heff_take_n(v_x11_24433, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24435}), v_st_24434});
    }
    case TAG_Right: {
      V v_x_24436 = heff_field(v_x11_24433, 0);
      heff_take_n(v_x11_24433, 1ULL, 1);
      V v_x_24437 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24436));
      return heff_tag_at_n(v_ru_24x1_24432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24437}), v_st_24434});
    }
    default: return heff_nomatch(v_x11_24433);
    }
  }
  default: return heff_nomatch(v_x1_24432);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam42(V self, V *args) {
  V v_st_24442 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24443 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24442));
  switch (heff_tag_of(v_x1_24443)) {
  case TAG_MkPair: {
    V v_x11_24444 = heff_field(v_x1_24443, 0);
    V v_st_24445 = heff_field(v_x1_24443, 1);
    V v_ru_24x1_24443_24MkPair = heff_take_reuse_n(v_x1_24443, 3ULL, 2);
    switch (heff_tag_of(v_x11_24444)) {
    case TAG_Left: {
      V v_e_24446 = heff_field(v_x11_24444, 0);
      heff_take_n(v_x11_24444, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24446}), v_st_24445});
    }
    case TAG_Right: {
      V v_x_24447 = heff_field(v_x11_24444, 0);
      heff_take_n(v_x11_24444, 1ULL, 1);
      V v_x_24448 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24447));
      return heff_tag_at_n(v_ru_24x1_24443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24448}), v_st_24445});
    }
    default: return heff_nomatch(v_x11_24444);
    }
  }
  default: return heff_nomatch(v_x1_24443);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam43(V self, V *args) {
  V v_st_24453 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24454 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24453));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_MkPair: {
    V v_x11_24455 = heff_field(v_x1_24454, 0);
    V v_st_24456 = heff_field(v_x1_24454, 1);
    V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
    switch (heff_tag_of(v_x11_24455)) {
    case TAG_Left: {
      V v_e_24457 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
    }
    case TAG_Right: {
      V v_x_24458 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      V v_x_24459 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24458));
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24459}), v_st_24456});
    }
    default: return heff_nomatch(v_x11_24455);
    }
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_24s1512833203x1945504366_lam44(V self, V *args) {
  V v_st_24466 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24467 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_x2_240, v_st_24466));
  switch (heff_tag_of(v_x1_24467)) {
  case TAG_MkPair: {
    V v_x11_24468 = heff_field(v_x1_24467, 0);
    V v_st_24469 = heff_field(v_x1_24467, 1);
    V v_ru_24x1_24467_24MkPair = heff_take_reuse_n(v_x1_24467, 3ULL, 2);
    switch (heff_tag_of(v_x11_24468)) {
    case TAG_Left: {
      V v_e_24470 = heff_field(v_x11_24468, 0);
      heff_take_n(v_x11_24468, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24470}), v_st_24469});
    }
    case TAG_Right: {
      V v_x_24471 = heff_field(v_x11_24468, 0);
      heff_take_n(v_x11_24468, 1ULL, 1);
      V v_x_24472 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_24471));
      return heff_tag_at_n(v_ru_24x1_24467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24472}), v_st_24469});
    }
    default: return heff_nomatch(v_x11_24468);
    }
  }
  default: return heff_nomatch(v_x1_24467);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_fields_244, V v_z_245) {
top: ;
  V v_text_246 = heff_take_field(v_name_242, 1);
  V v_start_247 = heff_take_field(v_name_242, 3);
  V v_end_248 = heff_get_n(v_name_242, 4, 9);
  V v_m_249 = (g_prelude_2etraverse_24s518454301x170091462(v_params_243));
  V v_x1_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    heff_take_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_fields_244);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2411_24Left, TAG_Left, 1, (V[]){v_e_2413}), v_st_2412}});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2414)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2415, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0, 1, 7, (V[]){v_fields_244, v_d_240, v_kw_241, v_text_246, v_start_247, v_end_248, v_x_2414}), v_st_2412));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2411)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2410)}});
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_24cpr_lam0(V self, V *args) {
  V v_st_2416 = args[0];
  V v_fields_244 = heff_env(self)[0];
  V v_d_240 = heff_env(self)[1];
  V v_kw_241 = heff_env(self)[2];
  V v_text_246 = heff_env(self)[3];
  V v_start_247 = heff_env(self)[4];
  V v_end_248 = heff_env(self)[5];
  V v_x_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_m_2417 = (g_prelude_2etraverse_24s956608878x365908798(v_fields_244));
  V v_x1_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){heff_dup(v_st_2416)}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_MkPair: {
    V v_x11_2419 = heff_field(v_x1_2418, 0);
    V v_st_2420 = heff_field(v_x1_2418, 1);
    V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
    switch (heff_tag_of(v_x11_2419)) {
    case TAG_Left: {
      V v_e_2421 = heff_field(v_x11_2419, 0);
      heff_take_n(v_x11_2419, 1ULL, 1);
      heff_drop_rec(v_st_2416, 9);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_text_246);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_x_2414);
      return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
    }
    case TAG_Right: {
      V v_x_2422 = heff_field(v_x11_2419, 0);
      V v_ru_24x11_2419_24Right = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
      V v_st_2423 = ({ V rv_1 = heff_get_n(v_st_2416, 1, 9); V rr_ = heff_rec_reuse_nf(v_st_2420, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2424 = ({ V a_0 = v_x_2422; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2422); r_; });
      V v_t_2425 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
      V v_e_2426 = heff_get_n(v_t_2425, 4, 9);
      V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2426});
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2419_24Right, TAG_ESig, 1, (V[]){v_t_2424}), v_t_2427});
      V v_t_2429 = heff_tag_n(TAG_DeclTheory, 4, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), v_x_2414, v_t_2428});
      V v_t_2430 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
      V v_e_2431 = heff_get_n(v_t_2430, 4, 9);
      V v_t_2432 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2431});
      V v_t_2433 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2432})});
      V v_x_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2423});
    }
    default: return heff_nomatch(v_x11_2419);
    }
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(V v_ys_240, V v_pv_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_PCon: {
    V v_args_245 = heff_field(v_x2_242, 1);
    V v_t_247 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_241)}), v_args_245));
    V v_t_248 = (g_heff_2esyntax_2esurface_2eappendS(v_t_247, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_248);
  }
  case TAG_PAtom: {
    V v_t_249 = heff_field(v_x2_242, 0);
    V v_kind_2410 = heff_dup(heff_rfield(v_t_249, 0));
    V v_text_2411 = heff_dup(heff_rfield(v_t_249, 1));
    if ((heff_strEq_c_lent(v_kind_2410, ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str0), 2) && !heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str1), 2))) {
      heff_drop(v_kind_2410);
      V v_x_2412 = v_text_2411;
      V v_t_2413 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
      return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_t_2413}));
    } else {
      if (heff_strEq_c(v_kind_2410, ((V)&g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_str2))) {
        V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_2411)}));
        V v_t_2415 = (g_list_2eany(v_t_2414, v_pv_241));
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          V v_x_2416 = v_text_2411;
          V v_t_2417 = (g_heff_2esyntax_2esurface_2eappendS(NTAG(TAG_Nil), v_ys_240));
          return heff_setField(v_d_243, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_t_2417}));
        } else {
          heff_drop(v_text_2411);
          heff_drop(v_t_2415);
          return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
        }
      } else {
        heff_drop(v_text_2411);
        return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
      }
    }
  }
  case TAG_PParen: {
    V v_q_2419 = heff_field(v_x2_242, 1);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2419;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2422 = heff_field(v_x2_242, 1);
    V v_t_2426 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_241)}), v_ps_2422));
    V v_t_2427 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2426, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2427);
  }
  case TAG_POp: {
    V v_l_2428 = heff_field(v_x2_242, 0);
    V v_q_2430 = heff_field(v_x2_242, 2);
    V v_t_2431 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_l_2428));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_241, v_q_2430));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2431, v_t_2432));
    V v_t_2434 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2433, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2434);
  }
  case TAG_PRec: {
    V v_fs_2436 = heff_field(v_x2_242, 1);
    V v_t_2440 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_241)}), v_fs_2436));
    V v_t_2441 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2440, v_ys_240));
    return heff_setField(v_d_243, MK_INT(1LL), v_t_2441);
  }
  case TAG_PField: {
    V v_q_2444 = heff_field(v_x2_242, 2);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2444;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2445 = heff_field(v_x2_242, 0);
    V v_q_2447 = heff_field(v_x2_242, 2);
    V v_x_2448 = heff_dup(heff_rfield(v_x_2445, 1));
    V v_cell_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2448, heff_hole()});
    V v_u_2450 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2449));
    heff_drop(v_u_2450);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2447;
    V t_3 = v_cell_2449;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2451 = heff_field(v_x2_242, 0);
    V t_0 = v_ys_240;
    V t_1 = v_pv_241;
    V t_2 = v_q_2451;
    V t_3 = v_d_243;
    v_ys_240 = t_0;
    v_pv_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam0(V self, V *args) {
  V v_q_246 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_246; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_246); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam1(V self, V *args) {
  V v_q_2425 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2425; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2425); r_; });
}
V g_heff_2esyntax_2esurface_2eappendS_24f487811590x694133344_24dps_lam2(V self, V *args) {
  V v_q_2439 = args[0];
  V v_pv_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_241; V a_1 = v_q_2439; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_241); heff_drop(v_q_2439); r_; });
}