// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Describe 2650
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940 61712
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_fields 672433636
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_large 304101205
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_aliases__tags[] = {LBL_aliases, LBL_tags};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx__matched[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx, LBL_matched};
static uint32_t shape_level__fields__defaults__large[] = {LBL_level, LBL_fields, LBL_defaults, LBL_large};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_heff_2eelab_2eenvironment_2ebindAt(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ebindAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindAt_clo;
V g_heff_2eelab_2eenvironment_2ematchedTo(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ematchedTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ematchedTo_clo;
HeffT2 g_heff_2eelab_2eenvironment_2epartOf_24cpr(V, V);
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
HeffT2 g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2eprimFloat_get(void);
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2eforcedRb(V);
V g_heff_2eelab_2ereadback_2eforcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eforcedRb_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24dps_clo;
V g_heff_2eelab_2erules_2eappendP_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24tok2_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2eatFloat64_w(V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64(V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_clo;
V g_heff_2eelab_2erules_2eatFloat64_24tok1_w(V, V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_24tok1_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2ecasesWith(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesWith_clo;
V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V, V);
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo;
V g_heff_2eelab_2erules_2echeckSetting(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSetting_clo;
V g_heff_2eelab_2erules_2echeckSetting_24generate0(V, V, V);
V g_heff_2eelab_2erules_2echeckSetting_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSetting_24generate0_clo;
V g_heff_2eelab_2erules_2echeckSetting_24map0(V, V);
V g_heff_2eelab_2erules_2echeckSetting_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSetting_24map0_clo;
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2eeqBareStr(V, V, V, V);
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqBareStr_clo;
V g_heff_2eelab_2erules_2eevidenceFound(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceFound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceFound_clo;
V g_heff_2eelab_2erules_2eevidenceGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_clo;
V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_clo;
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
V g_heff_2eelab_2erules_2efindOr(V, V, V);
V g_heff_2eelab_2erules_2efindOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindOr_clo;
HeffT1 g_heff_2eelab_2erules_2efindOr_24cpr(V, V, V);
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2efracDefault_w(V, V, V, double, V, V);
V g_heff_2eelab_2erules_2efracDefault(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efracDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efracDefault_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2einOrder(V, V, V, V, V);
V g_heff_2eelab_2erules_2einOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einOrder_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
HeffT1 g_heff_2eelab_2erules_2elambdaChk_24cpr(V, V, V, V);
HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V, V, V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo;
V g_heff_2eelab_2erules_2emetaOf(V);
V g_heff_2eelab_2erules_2emetaOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOf_clo;
V g_heff_2eelab_2erules_2enamesFor(V);
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
V g_heff_2eelab_2erules_2eseeArm(V, V, V, V, V);
V g_heff_2eelab_2erules_2eseeArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eseeArm_clo;
V g_heff_2eelab_2erules_2eselfAdvance_24generate0(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_24generate0_clo;
V g_heff_2eelab_2erules_2esettled(V, V, V, V);
V g_heff_2eelab_2erules_2esettled_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_clo;
V g_heff_2eelab_2erules_2esettled_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2esettled_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_24tok1_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2estandsFor_get(void);
HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2etagChk(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagChk_clo;
V g_heff_2eelab_2erules_2etermSizeGo(V, V, V);
V g_heff_2eelab_2erules_2etermSizeGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etermSizeGo_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2eunspecForced(V);
V g_heff_2eelab_2erules_2eunspecForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunspecForced_clo;
HeffT2 g_heff_2eelab_2erules_2eworldOf_24cpr(V);
V g_heff_2eelab_2erules_2ewrittenAt(V, V);
V g_heff_2eelab_2erules_2ewrittenAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewrittenAt_clo;
HeffT2 g_heff_2eelab_2erules_2ewrittenAt_24cpr(V, V);
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
HeffT2 g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(V);
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojAt(V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_clo;
V g_heff_2eelab_2evalue_2eprojAt_24tok1(V, V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_24tok1_clo;
V g_heff_2eelab_2evalue_2ereflect(V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_clo;
V g_heff_2eelab_2evalue_2ereflect_24tok2(V, V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24tok2_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str1, 0, "");
Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V v_d_240, V v_t_241) {
top: ;
  return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940), v_d_240, v_t_241, ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str0), ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str1)));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str0, 4, "meta");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str1, 1, "\?");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str3, 4, ") : ");
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam0, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam5, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efreshMeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_entry, 7, 0};

V g_heff_2eelab_2erules_2efreshMeta(V v_len_240, V v_locals_241, V v_ty_242, V v_name_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_bind_247 = heff_take_field(v_hd_245, 1);
  V v_malg_248 = heff_get_n(v_hd_245, 2, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_247), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam1, 1, 8, (V[]){v_ty_242, v_len_240, v_name_243, v_sp_244, v_malg_248, v_bind_247, heff_dup(v_locals_241), v_k_246})});
}
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2efreshMeta(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 4, 9);
}
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_rec_n(6, shape_ty__sol__solStx__arity__name__span, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_len_240, v_name_243, v_sp_244});
  V v_mc_2416 = (g_std_2eordmap_2einsert_24s1703101629x493626677(heff_take_field(v_c_2414, 3), heff_dup(v_x_2413), v_t_2415));
  return ({ V rv_3 = v_mc_2416; V rv_4 = heff_intAdd(v_x_2413, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_c_2414, 487ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 261183u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args) {
  V v_c_2425 = args[0];
  return heff_get_n(v_c_2425, 3, 9);
}
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_len_240 = heff_env(self)[3];
  V v_ty_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2430);
  V v_t_2431 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str1), heff_intShow(v_x_2413));
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2eelab_2erules_2efreshMeta_str2)), v_name_243);
  V v_mc_2433 = v_x_2429;
  V v_len_2434 = v_len_240;
  V v_ty_2435 = v_ty_242;
  V v_xs_2436 = (g_heff_2eelab_2erules_2enamesFor(heff_dup(v_len_2434)));
  V v_t_2456;
  switch (heff_tag_of(v_ty_2435)) {
  case TAG_VU: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2448 = heff_dup(heff_field(v_ty_2435, 5));
    v_t_2456 = v_folded_2448;
    break;
  }
  case TAG_VRecord: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2456 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_ty_2435);
  }
  V v_t_2457 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(v_len_2434, v_ty_2435, v_t_2456));
  V v_t_2458 = ({ V a_0 = v_mc_2433; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_mc_2433); r_; });
  V v_t_2459 = heff_tr(heff_call(heff_get_n(v_t_2458, 1, 2), 1, (V[]){v_t_2457}));
  V v_t_2460 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2436; V a_3 = v_t_2459; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s159113285x973327903(a_0, a_1, a_2, a_3)); heff_drop(v_t_2459); r_; });
  return heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2eelab_2erules_2efreshMeta_str3)), v_t_2460);
}
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args) {
  V v_sp_27_2468 = args[0];
  V v_i_2469 = args[1];
  V v_locals_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2470 = ({ V a_0 = v_locals_241; V a_1 = v_i_2469; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_locals_241); r_; });
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_27_2468, v_t_2470});
}
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args) {
  V v_u_2472 = args[0];
  V v_sp_2471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2472);
  return v_sp_2471;
}
V g_heff_2eelab_2erules_2efreshMeta_lam11(V self, V *args) {
  V v_u_2473 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return v_ty_242;
}
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args) {
  V v_x_2463 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_locals_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2463);
  V v_t_2464 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(heff_dup(v_len_240), MK_INT(1LL))));
  V v_t_2465 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_len_240), heff_dup(v_ty_242)));
  V v_t_2466 = heff_tag_n(TAG_SMetaApp, 3, (V[]){heff_dup(v_x_2413), heff_arrayFromList(v_t_2464), v_t_2465});
  V v_t_2467 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(v_len_240, MK_INT(1LL))));
  V v_sp_2471 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam9, 2, 1, (V[]){v_locals_241}); V a_1 = NTAG(TAG_SpId); V a_2 = v_t_2467; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2467); r_; });
  V v_t_2474 = (g_heff_2eelab_2evalue_2ereflect(heff_tag_n(TAG_HMeta, 1, (V[]){v_x_2413}), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam10, 1, 1, (V[]){v_sp_2471}), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam11, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_x_2475 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2466, v_t_2474});
  V f_ = v_k_246;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_len_240 = heff_env(self)[3];
  V v_ty_242 = heff_env(self)[4];
  V v_malg_248 = heff_env(self)[5];
  V v_bind_247 = heff_env(self)[6];
  V v_locals_241 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2461 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_244, ((V)&g_heff_2eelab_2erules_2efreshMeta_str0), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam7, 1, 5, (V[]){heff_dup(v_x_2413), v_name_243, v_x_2429, heff_dup(v_len_240), heff_dup(v_ty_242)})}), NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tr(heff_call(v_malg_248, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})}));
  V f_ = v_bind_247;
  heff_room[0] = v_t_2462;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam8, 1, 5, (V[]){v_len_240, v_ty_242, v_x_2413, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_malg_248 = heff_env(self)[0];
  V v_bind_247 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  V v_len_240 = heff_env(self)[5];
  V v_ty_242 = heff_env(self)[6];
  V v_locals_241 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2424);
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam5_clo)})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){v_t_2427}));
  V f_ = heff_dup(v_bind_247);
  heff_room[0] = v_t_2428;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam6, 1, 9, (V[]){v_sp_244, v_x_2413, v_name_243, v_len_240, v_ty_242, v_malg_248, v_bind_247, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_malg_248 = heff_env(self)[0];
  V v_bind_247 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  V v_len_240 = heff_env(self)[5];
  V v_ty_242 = heff_env(self)[6];
  V v_locals_241 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2421 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2420, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})}));
  V f_ = heff_dup(v_bind_247);
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam4, 1, 9, (V[]){v_malg_248, v_bind_247, v_sp_244, v_x_2413, v_name_243, v_len_240, v_ty_242, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_malg_248 = heff_env(self)[4];
  V v_bind_247 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam2, 1, 5, (V[]){heff_dup(v_ty_242), heff_dup(v_len_240), heff_dup(v_name_243), heff_dup(v_sp_244), heff_dup(v_x_2413)})})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){v_t_2418}));
  V f_ = heff_dup(v_bind_247);
  heff_room[0] = v_t_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam3, 1, 9, (V[]){v_malg_248, v_bind_247, v_sp_244, v_x_2413, v_name_243, v_len_240, v_ty_242, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str0, 5, "solve");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str1, 1, "\?");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str3, 5, ") := ");
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam0, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam3, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esolveHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_entry, 8, 0};

V g_heff_2eelab_2erules_2esolveHole(V v_g_240, V v_cs_241, V v_m_242, V v_holeVal_243, V v_argStx_244, V v_argVal_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam1, 1, 8, (V[]){v_m_242, v_g_240, v_argStx_244, v_hd_246, v_k_247, v_cs_241, v_holeVal_243, v_argVal_245})});
}
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esolveHole(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 9);
}
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args) {
  V v_c_2419 = args[0];
  return heff_get_n(v_c_2419, 3, 9);
}
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args) {
  V v_u_2424 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_e_2416 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2424);
  V v_t_2425 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str1), heff_intShow(v_m_242));
  V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2eelab_2erules_2esolveHole_str2)), heff_take_field(v_e_2416, 4));
  V v_t_2427 = (g_heff_2eelab_2eunify_2elamsU(heff_get_n(v_e_2416, 3, 6), v_argStx_244));
  V v_t_2428 = ({ V a_0 = v_x_2423; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2423); r_; });
  V v_e_2429 = heff_tr(heff_call(heff_get_n(v_t_2428, 0, 2), 1, (V[]){v_t_2427}));
  V v_t_2430 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_2429));
  return heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2eelab_2erules_2esolveHole_str3)), v_t_2430);
}
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_247;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_2416 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(heff_rfield(v_e_2416, 5)), ((V)&g_heff_2eelab_2erules_2esolveHole_str0), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam5, 1, 4, (V[]){v_m_242, v_e_2416, v_argStx_244, v_x_2423})});
  V v_t_2432 = heff_tag_n(TAG_Trace, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2433;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam6, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_e_2416 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_argStx_244 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2418);
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam3_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam4, 1, 5, (V[]){v_e_2416, v_m_242, v_argStx_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_cs_241 = heff_env(self)[5];
  V v_holeVal_243 = heff_env(self)[6];
  V v_argVal_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2413 = ({ V a_0 = v_x_2412; V a_1 = heff_dup(v_m_242); HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_x_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_e_2416 = v_field_2415;
      V v_t_2417 = heff_dup(heff_rfield(v_e_2416, 1));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop(v_cs_241);
        heff_drop(v_holeVal_243);
        heff_drop(v_argVal_245);
        return (g_heff_2eelab_2erules_2efillHole(v_g_240, heff_dup(v_m_242), heff_dup(v_e_2416), heff_dup(v_argStx_244), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam2, 1, 5, (V[]){v_hd_246, v_e_2416, v_m_242, v_argStx_244, v_k_247})));
      }
      case TAG_Just: {
        heff_take_n(v_t_2417, 0ULL, 1);
        heff_drop(v_m_242);
        heff_drop(v_argStx_244);
        heff_drop_rec(v_e_2416, 6);
        V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_240, v_cs_241, v_holeVal_243, v_argVal_245}));
        return (g_heff_2eelab_2emeta_2eliftU(v_t_2437, v_hd_246, v_k_247));
      }
      default: return heff_nomatch(v_t_2417);
      }
    } else {
      heff_drop(v_m_242);
      heff_drop(v_argStx_244);
      heff_drop(v_field_2415);
      V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_240, v_cs_241, v_holeVal_243, v_argVal_245}));
      return (g_heff_2eelab_2emeta_2eliftU(v_t_2438, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqBareStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqBareStr_entry, 4, 0};

V g_heff_2eelab_2erules_2eeqBareStr(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243) {
top: ;
  V v_len_244 = heff_take_field(v_cs_241, 0);
  V v_names_245 = heff_get_n(v_cs_241, 1, 2);
  V v_e_246 = (g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(v_len_244, v_h_242, v_sp_243));
  V v_t_2414 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqBareStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 0, 2), 1, (V[]){v_e_246}));
  HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), v_names_245, v_e_2415);
}
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqBareStr(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_x_247; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_249); heff_drop(v_x_247); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_d_248);
      V v_x_2413 = v_field_2412;
      return v_x_2413;
    } else {
      heff_drop(v_field_2412);
      return v_d_248;
    }
  }
}
Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecatMaybesR_24dps(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2emetaOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2emetaOf_entry, 1, 0};

V g_heff_2eelab_2erules_2emetaOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SMetaApp: {
    V v_k_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_k_241);
  }
  default: {
    return MK_INT(-1LL);
  }
  }
}
V g_heff_2eelab_2erules_2emetaOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2emetaOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str0, 23, "the instance found for ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str2, 6, ", has ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str3, 3, " = ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str4, 6, ", but ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str5, 10, " is wanted");
V g_heff_2eelab_2erules_2echeckSetting_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckSetting_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_lam0, 1, 0};
V g_heff_2eelab_2erules_2echeckSetting_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckSetting_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_lam2, 1, 0};
V g_heff_2eelab_2erules_2echeckSetting_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckSetting_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_lam4, 1, 0};
V g_heff_2eelab_2erules_2echeckSetting_lam5(V self, V *args);
V g_heff_2eelab_2erules_2echeckSetting_lam7(V self, V *args);
V g_heff_2eelab_2erules_2echeckSetting_lam6(V self, V *args);
V g_heff_2eelab_2erules_2echeckSetting_lam3(V self, V *args);
V g_heff_2eelab_2erules_2echeckSetting_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_entry, 9, 0};

V g_heff_2eelab_2erules_2echeckSetting(V v_e_240, V v_sp_241, V v_w_242, V v_goal_243, V v_found_244, V v_final_245, V v_x7_246, V v_p_247, V v_p_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x7_246, 0);
    V v_v_2410 = heff_field(v_x7_246, 1);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2echeckSetting_lam0_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_247, 2)), 1, (V[]){v_t_2413}));
    return heff_tail(heff_dup(heff_rfield(v_p_247, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam1, 1, 10, (V[]){v_p_247, v_goal_243, v_found_244, heff_dup(v_x_249), v_e_240, heff_dup(v_v_2410), v_w_242, v_sp_241, heff_dup(v_final_245), v_p_248})});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2erules_2echeckSetting_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a6 = a[6]; V r = g_heff_2eelab_2erules_2echeckSetting(a[0], a[1], a[2], a[3], a[4], a5, a6, a[7], a[8]); heff_drop(a5); heff_drop(a6); return r;
}
V g_heff_2eelab_2erules_2echeckSetting_lam0(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 5, 9);
}
V g_heff_2eelab_2erules_2echeckSetting_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  return heff_get_n(v_c_2416, 3, 9);
}
V g_heff_2eelab_2erules_2echeckSetting_lam4(V self, V *args) {
  V v_u_2441 = args[0];
  heff_drop(v_u_2441);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2echeckSetting_lam5(V self, V *args) {
  V v_p_2466 = args[0];
  V v_p_2467 = args[1];
  V v_g_2462 = heff_env(self)[0];
  V v_len_2464 = heff_env(self)[1];
  V v_names_2465 = heff_env(self)[2];
  V v_x_2461 = heff_env(self)[3];
  V v_v_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_2462, heff_rec_n(2, shape_len__names, (V[]){v_len_2464, v_names_2465}), v_x_2461, v_v_2410}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2468, v_p_2466, v_p_2467));
}
V g_heff_2eelab_2erules_2echeckSetting_lam7(V self, V *args) {
  V v_x_2487 = args[0];
  V v_globals_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2488 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2487)));
  V v_t_2489 = ({ V b_0 = heff_get_n(v_globals_2482, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2490 = ({ V a_0 = v_t_2489; V a_1 = v_x_2487; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2489); heff_drop(v_x_2487); r_; });
  {
    V v_field_2492 = v_t_2490.f[1];
    int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
    if ((v_tag_2491 == ((int64_t)0ULL))) {
      heff_drop(v_d_2488);
      V v_x_2493 = v_field_2492;
      return v_x_2493;
    } else {
      heff_drop(v_field_2492);
      return v_d_2488;
    }
  }
}
V g_heff_2eelab_2erules_2echeckSetting_lam6(V self, V *args) {
  V v_r_2469 = args[0];
  V v_z_2470 = args[1];
  V v_z_2471 = args[2];
  V v_x_2420 = heff_env(self)[0];
  V v_goal_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_w_242 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_x_2461 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_final_245 = heff_env(self)[7];
  V v_x_2415 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_r_2469)) {
  case TAG_Left: {
    V v_err_2472 = heff_field(v_r_2469, 0);
    V v_ru_24r_2469_24Left = heff_take_reuse_n(v_r_2469, 1ULL, 1);
    heff_drop(v_final_245);
    heff_drop(v_x_2415);
    V v_t_2473 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2420, heff_dup(v_goal_243)));
    V v_t_2474 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2473));
    V v_t_2475 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2420, v_t_2474));
    V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckSetting_str0), v_t_2475), ((V)&g_heff_2eelab_2erules_2echeckSetting_str1));
    V v_t_2477 = heff_tr(heff_call(heff_get_n(v_w_242, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2478 = heff_strAppend(heff_strAppend(v_t_2476, v_t_2477), ((V)&g_heff_2eelab_2erules_2echeckSetting_str2));
    V v_t_2479 = heff_strAppend(heff_strAppend(v_t_2478, v_x_249), ((V)&g_heff_2eelab_2erules_2echeckSetting_str3));
    V v_e_2480 = heff_dup(v_e_240);
    V v_scope_2481 = heff_take_field(v_e_2480, 0);
    V v_globals_2482 = heff_get_n(v_e_2480, 1, 6);
    V v_mc_2483 = heff_dup(v_x_2420);
    V v_v_2484 = v_x_2461;
    V v_t_2485 = ({ V a_0 = v_mc_2483; V r_ = (g_heff_2eelab_2ereadback_2eforcedRb(a_0)); heff_drop(v_mc_2483); r_; });
    V v_e_2486 = heff_tr(heff_call(heff_get_n(v_t_2485, 0, 2), 2, (V[]){heff_take_field(v_scope_2481, 0), v_v_2484}));
    V v_t_2494 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam7, 1, 1, (V[]){v_globals_2482})));
    V v_e_2495 = heff_tr(heff_call(heff_get_n(v_t_2494, 0, 2), 1, (V[]){v_e_2486}));
    V v_t_2496 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_scope_2481, 1, 5), v_e_2495));
    V v_t_2497 = heff_strAppend(heff_strAppend(v_t_2479, v_t_2496), ((V)&g_heff_2eelab_2erules_2echeckSetting_str4));
    V v_t_2498 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_x_2420; V a_2 = v_goal_243; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2420); r_; });
    V v_msg_2499 = heff_strAppend(heff_strAppend(v_t_2497, v_t_2498), ((V)&g_heff_2eelab_2erules_2echeckSetting_str5));
    V v_note_24100 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2472; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2472); r_; });
    V v_t_24101 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(354LL), NTAG(TAG_SError), v_msg_2499, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_24100})});
    V v_t_24102 = heff_tag_at_n(v_ru_24r_2469_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tr(heff_call(heff_take_field(v_z_2470, 2), 1, (V[]){v_t_24103}));
    V f_ = heff_get_n(v_z_2470, 1, 3);
    args[0] = v_t_24104;
    args[1] = v_z_2471;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Right: {
    V v_ru_24r_2469_24Right = heff_take_reuse_n(v_r_2469, 0ULL, 1);
    heff_drop(v_x_2420);
    heff_drop(v_goal_243);
    heff_drop_rec(v_e_240, 6);
    heff_drop_rec(v_w_242, 6);
    heff_drop(v_x_249);
    heff_drop(v_x_2461);
    heff_drop(v_sp_241);
    return ({ V a_0 = v_ru_24r_2469_24Right; V a_1 = v_final_245; V a_2 = v_x_2415; V a_3 = v_z_2470; V a_4 = v_z_2471; V r_ = (g_heff_2eelab_2erules_2esettled_24tok1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_final_245); r_; });
  }
  default: return heff_nomatch(v_r_2469);
  }
}
V g_heff_2eelab_2erules_2echeckSetting_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_goal_243 = heff_env(self)[0];
  V v_found_244 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_v_2410 = heff_env(self)[4];
  V v_w_242 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_final_245 = heff_env(self)[7];
  V v_x_2415 = heff_env(self)[8];
  V v_p_247 = heff_env(self)[9];
  V v_p_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2421 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2420, heff_dup(v_goal_243)));
  V v_t_2422 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2421));
  V v_v_2423 = heff_dup(v_found_244);
  V v_x_2424 = heff_dup(v_x_249);
  V v_t_2425 = (g_heff_2eelab_2evalue_2ebehavior(v_t_2422));
  V v_t_2456;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2425, 0ULL, 1);
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2425, 0ULL, 4);
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeRecord: {
    V v_capture_2432 = heff_field(v_t_2425, 1);
    V v_fieldTypes_2433 = heff_field(v_t_2425, 2);
    heff_take_n(v_t_2425, 6ULL, 3);
    HeffT2 v_t_2434 = ({ V a_0 = v_v_2423; HeffT2 r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(a_0)); heff_drop(v_v_2423); r_; });
    V v_d_2438;
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_fields_2437 = v_field_2436;
        v_d_2438 = v_fields_2437;
      } else {
        heff_drop(v_field_2436);
        v_d_2438 = heff_abandon();
      }
    }
    V v_xs_2439 = heff_take_field(v_d_2438, 2);
    V v_m_2440 = heff_arrayLength_lent(v_xs_2439, 0);
    V v_t_2448;
    if ((heff_peek_word(v_m_2440) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_2439);
      v_t_2448 = heff_arrayGenerate(v_m_2440, ((V)&g_heff_2eelab_2erules_2echeckSetting_lam4_clo));
    } else {
      V v_e_2442 = heff_arrayIndex_lent(v_xs_2439, MK_INT(0LL), 2);
      V v_y_2446;
      switch (heff_tag_of(v_e_2442)) {
      case TAG_Nom: {
        V v_x_2443 = heff_field(v_e_2442, 0);
        heff_take_n(v_e_2442, 1ULL, 1);
        v_y_2446 = v_x_2443;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_e_2442, 0ULL, 1);
        v_y_2446 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2445 = heff_field(v_e_2442, 0);
        heff_take_n(v_e_2442, 1ULL, 1);
        v_y_2446 = v_x_2445;
        break;
      }
      default: heff_nomatch(v_e_2442);
      }
      V v_t_2447 = heff_arrayKeepsAs_lent(v_xs_2439, v_y_2446, 0);
      if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
        heff_drop(v_m_2440);
        heff_drop(v_t_2447);
        v_t_2448 = (g_heff_2eelab_2erules_2echeckSetting_24map0(MK_INT(1LL), heff_arraySet(v_xs_2439, MK_INT(0LL), v_y_2446)));
      } else {
        heff_drop(v_t_2447);
        v_t_2448 = ({ V a_0 = v_xs_2439; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2440, v_y_2446); V r_ = (g_heff_2eelab_2erules_2echeckSetting_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
      }
    }
    V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_d_2438, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_x1_2450 = ({ V a_0 = v_capture_2432; V a_1 = v_fieldTypes_2433; V a_2 = v_x_2424; V a_3 = v_t_2449; V r_ = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(a_0, a_1, a_2, a_3)); heff_drop(v_x_2424); r_; });
    switch (heff_tag_of(v_x1_2450)) {
    case TAG_MkField: {
      V v_ty_2451 = heff_field(v_x1_2450, 0);
      heff_take_n(v_x1_2450, 1ULL, 2);
      v_t_2456 = v_ty_2451;
      break;
    }
    default: heff_nomatch(v_x1_2450);
    }
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2425, 0ULL, 1);
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeInt: {
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeFloat: {
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeString: {
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeRune: {
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2425, 0ULL, 1);
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2425, 0ULL, 1);
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  case TAG_NoRules: {
    heff_drop(v_v_2423);
    heff_drop(v_x_2424);
    v_t_2456 = heff_abandon();
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  V v_x1_2457 = (g_heff_2eelab_2evalue_2eprojAt(v_found_244, heff_dup(v_x_249), v_t_2456));
  V v_x_2461;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_x_2461 = v_x_2458;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    v_x_2461 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_x_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_g_2462 = heff_dup(heff_rfield(v_e_240, 1));
  V v_c_2463 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_2464 = heff_take_field(v_c_2463, 0);
  V v_names_2465 = heff_get_n(v_c_2463, 1, 5);
  return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam5, 2, 5, (V[]){v_g_2462, v_len_2464, v_names_2465, heff_dup(v_x_2461), v_v_2410}), heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam6, 3, 9, (V[]){v_x_2420, v_goal_243, v_e_240, v_w_242, v_x_249, v_x_2461, v_sp_241, v_final_245, v_x_2415}), v_p_247, v_p_248));
}
V g_heff_2eelab_2erules_2echeckSetting_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_247 = heff_env(self)[0];
  V v_goal_243 = heff_env(self)[1];
  V v_found_244 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_v_2410 = heff_env(self)[5];
  V v_w_242 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  V v_final_245 = heff_env(self)[8];
  V v_p_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2echeckSetting_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_247, 2)), 1, (V[]){v_t_2418}));
  V f_ = heff_dup(heff_rfield(v_p_247, 1));
  heff_room[0] = v_t_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam3, 1, 11, (V[]){v_goal_243, v_found_244, v_x_249, v_e_240, v_v_2410, v_w_242, v_sp_241, v_final_245, v_x_2415, v_p_247, v_p_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eworldOf_24cpr_str0, 5, "co.<:");

HeffT2 g_heff_2eelab_2erules_2eworldOf_24cpr(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SDecode: {
    V v_t1_242 = heff_field(v_t_240, 0);
    switch (heff_tag_of(v_t1_242)) {
    case TAG_SLocal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      V v_t11_246 = heff_field(v_t1_242, 0);
      V v_w_247 = heff_field(v_t1_242, 1);
      switch (heff_tag_of(v_t11_246)) {
      case TAG_SLocal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SGlobal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCode: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SApp: {
        V v_t111_2411 = heff_field(v_t11_246, 0);
        switch (heff_tag_of(v_t111_2411)) {
        case TAG_SLocal: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          V v_k_2414 = heff_field(v_t111_2411, 0);
          if (heff_strEq_c_lent(v_k_2414, ((V)&g_heff_2eelab_2erules_2eworldOf_24cpr_str0), 2)) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_w_247)}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_SCode: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SOpaque: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t111_2411)}});
        }
      }
      case TAG_SLam: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCons: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SProj: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_STag: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMatch: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SSpecialize: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SIs: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SOpaque: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SAbandon: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SRec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SFix: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SImplicit: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SPrim: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMetaApp: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitInt: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitString: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitBytes: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitRune: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFixed: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat32: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t11_246)}});
      }
    }
    case TAG_SLam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SOpaque: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t1_242)}});
    }
  }
  case TAG_SFunction: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRecord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIsTy: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimArray: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str3, 1, "_");
V g_heff_2eelab_2erules_2eevidenceGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam14(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam13(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eevidenceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceGo_entry, 8, 0};

V g_heff_2eelab_2erules_2eevidenceGo(V v_sp_240, V v_x_241, V v_cand_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam0, 1, 1, (V[]){v_ty0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam1, 1, 7, (V[]){v_sp_240, v_x_241, v_hd_246, v_k_247, v_e_243, v_cand_242, v_m_244})});
}
V g_heff_2eelab_2erules_2eevidenceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eevidenceGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eevidenceGo_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_ty0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_ty0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eevidenceGo_lam5(V self, V *args) {
  V v_u2_2435 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2435);
  V v_x1_2436 = heff_tr(heff_call(heff_get_n(v_x_2430, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2436)) {
  case TAG_Nom: {
    V v_x_2437 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    return v_x_2437;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2436, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2439 = heff_field(v_x1_2436, 0);
    heff_take_n(v_x1_2436, 1ULL, 1);
    return v_x_2439;
  }
  default: return heff_nomatch(v_x1_2436);
  }
}
V g_heff_2eelab_2erules_2eevidenceGo_lam4(V self, V *args) {
  V v_f_2434 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2434, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam5, 1, 1, (V[]){v_x_2430})));
}
V g_heff_2eelab_2erules_2eevidenceGo_lam3(V self, V *args) {
  V v_u_2432 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2432);
  V v_t_2433 = heff_tr(heff_call(heff_get_n(v_m_244, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam4, 1, 1, (V[]){v_x_2430}), v_t_2433));
}
V g_heff_2eelab_2erules_2eevidenceGo_lam6(V self, V *args) {
  V v_u_2444 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2444);
  V v_x1_2445 = heff_tr(heff_call(heff_get_n(v_x_2430, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2445)) {
  case TAG_Nom: {
    V v_x_2446 = heff_field(v_x1_2445, 0);
    heff_take_n(v_x1_2445, 1ULL, 1);
    return v_x_2446;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2448 = heff_field(v_x1_2445, 0);
    heff_take_n(v_x1_2445, 1ULL, 1);
    return v_x_2448;
  }
  default: return heff_nomatch(v_x1_2445);
  }
}
V g_heff_2eelab_2erules_2eevidenceGo_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_implicit_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_cod_2417 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440;
  switch (heff_tag_of(v_implicit_2418)) {
  case TAG_Expl: {
    heff_drop(v_x_241);
    V v_t_2431 = heff_tag_n(TAG_SApp, 2, (V[]){heff_dup(heff_rfield(v_m_244, 0)), heff_dup(heff_rfield(v_x_2430, 0))});
    v_t_2440 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2431, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam3, 1, 2, (V[]){v_m_244, heff_dup(v_x_2430)})});
    break;
  }
  case TAG_Impl: {
    v_t_2440 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2430)));
    break;
  }
  case TAG_Inst: {
    v_t_2440 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2430)));
    break;
  }
  default: heff_nomatch(v_implicit_2418);
  }
  V v_x1_2450;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2442 = heff_field(v_cod_2417, 1);
    V v_body_2443 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2450 = heff_tr(heff_call(v_body_2443, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2442, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam6, 1, 1, (V[]){v_x_2430})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2449 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2430, 2);
    v_x1_2450 = v_body_2449;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2454;
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_Nom: {
    V v_x_2451 = heff_field(v_x1_2450, 0);
    heff_take_n(v_x1_2450, 1ULL, 1);
    v_t_2454 = v_x_2451;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2450, 0ULL, 1);
    v_t_2454 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2453 = heff_field(v_x1_2450, 0);
    heff_take_n(v_x1_2450, 1ULL, 1);
    v_t_2454 = v_x_2453;
    break;
  }
  default: heff_nomatch(v_x1_2450);
  }
  V v_x_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_t_2454});
  V f_ = v_k_247;
  args[0] = v_x_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eevidenceGo_lam8(V self, V *args) {
  V v_b_2460 = args[0];
  V v_e_2424 = heff_env(self)[0];
  V v_sp_2425 = heff_env(self)[1];
  V v_x_2459 = heff_env(self)[2];
  V v_goal_2426 = heff_env(self)[3];
  V v_cand_2428 = heff_env(self)[4];
  V v_hd_2429 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_e_2424; V a_1 = v_sp_2425; V a_2 = v_x_2459; V a_3 = v_goal_2426; V a_4 = v_cand_2428; V a_5 = v_b_2460; V a_6 = heff_dup(v_hd_2429); V a_7 = heff_get_n(v_hd_2429, 0, 3); V r_ = (g_heff_2eelab_2erules_2eevidenceFound(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_b_2460); r_; });
}
V g_heff_2eelab_2erules_2eevidenceGo_lam10(V self, V *args) {
  V v_u_2465 = args[0];
  V v_x_2459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2465);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2459, 1, 2)});
}
V g_heff_2eelab_2erules_2eevidenceGo_lam9(V self, V *args) {
  V v_x_2464 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_k_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2464);
  V v_t_2466 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam10, 1, 1, (V[]){heff_dup(v_x_2459)}); V rr_ = heff_rec_reuse_nf(v_x_2459, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2456;
  args[0] = v_t_2466;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eevidenceGo_lam7(V self, V *args) {
  V v_x_2459 = args[0];
  V v_sp_2425 = heff_env(self)[0];
  V v_e_2424 = heff_env(self)[1];
  V v_goal_2426 = heff_env(self)[2];
  V v_cand_2428 = heff_env(self)[3];
  V v_hd_2429 = heff_env(self)[4];
  V v_k_2456 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2461 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_2425), heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam8, 1, 6, (V[]){v_e_2424, v_sp_2425, heff_dup(v_x_2459), v_goal_2426, v_cand_2428, heff_dup(v_hd_2429)}), NTAG(TAG_MkUnit)});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2462}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  heff_room[0] = v_t_2463;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam9, 1, 2, (V[]){v_x_2459, v_k_2456});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eevidenceGo_lam12(V self, V *args) {
  V v_u_2484 = args[0];
  V v_x_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2484);
  V v_x1_2485 = heff_tr(heff_call(heff_get_n(v_x_2474, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2485)) {
  case TAG_Nom: {
    V v_x_2486 = heff_field(v_x1_2485, 0);
    heff_take_n(v_x1_2485, 1ULL, 1);
    return v_x_2486;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2485, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2488 = heff_field(v_x1_2485, 0);
    heff_take_n(v_x1_2485, 1ULL, 1);
    return v_x_2488;
  }
  default: return heff_nomatch(v_x1_2485);
  }
}
V g_heff_2eelab_2erules_2eevidenceGo_lam11(V self, V *args) {
  V v_x_2474 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cand_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2479;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2475 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2479 = v_n_2475;
    break;
  }
  case TAG_CloConst: {
    v_t_2479 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2480 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2479, v_m_244, heff_dup(v_x_2474)));
  V v_x1_2490;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2482 = heff_field(v_cod_2417, 1);
    V v_body_2483 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2490 = heff_tr(heff_call(v_body_2483, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2482, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam12, 1, 1, (V[]){v_x_2474})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2489 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2474, 2);
    v_x1_2490 = v_body_2489;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2494;
  switch (heff_tag_of(v_x1_2490)) {
  case TAG_Nom: {
    V v_x_2491 = heff_field(v_x1_2490, 0);
    heff_take_n(v_x1_2490, 1ULL, 1);
    v_t_2494 = v_x_2491;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2490, 0ULL, 1);
    v_t_2494 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2493 = heff_field(v_x1_2490, 0);
    heff_take_n(v_x1_2490, 1ULL, 1);
    v_t_2494 = v_x_2493;
    break;
  }
  default: heff_nomatch(v_x1_2490);
  }
  return (g_heff_2eelab_2erules_2eevidenceGo(v_sp_240, v_x_241, v_cand_242, v_e_243, v_t_2480, v_t_2494, v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2eevidenceGo_lam14(V self, V *args) {
  V v_u_24110 = args[0];
  V v_x_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24110);
  V v_x1_24111 = heff_tr(heff_call(heff_get_n(v_x_24100, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_24111)) {
  case TAG_Nom: {
    V v_x_24112 = heff_field(v_x1_24111, 0);
    heff_take_n(v_x1_24111, 1ULL, 1);
    return v_x_24112;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24111, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_24114 = heff_field(v_x1_24111, 0);
    heff_take_n(v_x1_24111, 1ULL, 1);
    return v_x_24114;
  }
  default: return heff_nomatch(v_x1_24111);
  }
}
V g_heff_2eelab_2erules_2eevidenceGo_lam13(V self, V *args) {
  V v_x_24100 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cand_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24105;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_24101 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_24105 = v_n_24101;
    break;
  }
  case TAG_CloConst: {
    v_t_24105 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_24106 = (g_heff_2eelab_2ememoed_2eiapp(v_t_24105, v_m_244, heff_dup(v_x_24100)));
  V v_x1_24116;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_24108 = heff_field(v_cod_2417, 1);
    V v_body_24109 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_24116 = heff_tr(heff_call(v_body_24109, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24108, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam14, 1, 1, (V[]){v_x_24100})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24115 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_24100, 2);
    v_x1_24116 = v_body_24115;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_24120;
  switch (heff_tag_of(v_x1_24116)) {
  case TAG_Nom: {
    V v_x_24117 = heff_field(v_x1_24116, 0);
    heff_take_n(v_x1_24116, 1ULL, 1);
    v_t_24120 = v_x_24117;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24116, 0ULL, 1);
    v_t_24120 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24119 = heff_field(v_x1_24116, 0);
    heff_take_n(v_x1_24116, 1ULL, 1);
    v_t_24120 = v_x_24119;
    break;
  }
  default: heff_nomatch(v_x1_24116);
  }
  return (g_heff_2eelab_2erules_2eevidenceGo(v_sp_240, v_x_241, v_cand_242, v_e_243, v_t_24106, v_t_24120, v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2eevidenceGo_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_cand_242 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2413, 1);
    V v_cod_2417 = heff_field(v_t_2413, 2);
    V v_implicit_2418 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_cod_2417)) {
    case TAG_MkClo: {
      V v_n_2419 = heff_dup(heff_field(v_cod_2417, 0));
      v_t_2423 = heff_bool(heff_strEq_c_lent(v_n_2419, v_x_241, 0));
      heff_drop(v_n_2419);
      break;
    }
    case TAG_CloConst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_cod_2417);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_t_2423);
      V v_e_2424 = v_e_243;
      V v_sp_2425 = v_sp_240;
      V v_goal_2426 = v_dom_2416;
      V v_name_2427 = heff_dup(v_x_241);
      V v_cand_2428 = v_cand_242;
      V v_hd_2429 = v_hd_246;
      V v_k_2456 = heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam2, 1, 5, (V[]){v_implicit_2418, v_m_244, v_x_241, v_cod_2417, v_k_247});
      V v_t_2457 = heff_get_n(heff_dup(heff_rfield(v_e_2424, 0)), 0, 5);
      V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_2424, 0)), 2, 5);
      return ({ V a_0 = v_t_2457; V a_1 = v_t_2458; V a_2 = heff_dup(v_goal_2426); V a_3 = v_name_2427; V a_4 = heff_dup(v_sp_2425); V a_5 = heff_dup(v_hd_2429); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam7, 1, 6, (V[]){v_sp_2425, v_e_2424, v_goal_2426, v_cand_2428, v_hd_2429, v_k_2456}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2458); r_; });
    } else {
      heff_drop(v_t_2423);
      V v_t_2467;
      switch (heff_tag_of(v_implicit_2418)) {
      case TAG_Expl: {
        v_t_2467 = NTAG(TAG_False);
        break;
      }
      case TAG_Impl: {
        v_t_2467 = NTAG(TAG_True);
        break;
      }
      case TAG_Inst: {
        v_t_2467 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_implicit_2418);
      }
      if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
        heff_drop(v_implicit_2418);
        heff_drop(v_t_2467);
        V v_t_2472;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2468 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2472 = v_n_2468;
          break;
        }
        case TAG_CloConst: {
          v_t_2472 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2473 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_243), heff_dup(v_sp_240), v_x_2412, v_dom_2416, v_t_2472));
        V f_ = v_c_2473;
        heff_room[0] = heff_dup(v_hd_246);
        heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam11, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_cand_242, v_e_243, v_hd_246, v_k_247});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_x_2412);
        heff_drop(v_t_2467);
        switch (heff_tag_of(v_implicit_2418)) {
        case TAG_Expl: {
          heff_drop(v_e_243);
          heff_drop(v_cand_242);
          heff_drop_rec(v_m_244, 2);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
        case TAG_Impl: {
          heff_drop(v_e_243);
          heff_drop(v_cand_242);
          heff_drop_rec(v_m_244, 2);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
        case TAG_Inst: {
          V v_t_2499;
          switch (heff_tag_of(v_cod_2417)) {
          case TAG_MkClo: {
            V v_n_2495 = heff_dup(heff_field(v_cod_2417, 0));
            v_t_2499 = v_n_2495;
            break;
          }
          case TAG_CloConst: {
            v_t_2499 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str2);
            break;
          }
          default: heff_nomatch(v_cod_2417);
          }
          return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_243), heff_dup(v_sp_240), v_dom_2416, v_t_2499, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam13, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_cand_242, v_e_243, v_hd_246, v_k_247})));
        }
        default: return heff_nomatch(v_implicit_2418);
        }
      }
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop_rec(v_m_244, 2);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimFloat_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimFloat_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimFloat_st;
static V g_heff_2eelab_2erules_2eprimFloat_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimFloat_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimFloat_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimFloat_st)) return g_heff_2eelab_2erules_2eprimFloat_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimFloat_val, &g_heff_2eelab_2erules_2eprimFloat_st, g_heff_2eelab_2erules_2eprimFloat_init);
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat32_str0, 21, " is out of range for ");
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat32_str1, 48, "Float32, whose greatest is 3.4028234663852886e38");
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eatFloat32_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_lam2, 1, 0};
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eatFloat32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_entry, 3, 0};

V g_heff_2eelab_2erules_2eatFloat32(V v_sp_240, V v_text_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL)));
  V v_t_244 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL)));
  double v_y_245 = heff_from_int_f64(heff_intSub(v_t_243, v_t_244));
  V v_t_246 = heff_bool((v_y_245 <= heff_peek_f64(v_x_242)));
  if (((heff_dup(v_t_246) == NTAG(TAG_True)) || ({ V v_t_247 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL))); int c_ = ({ V v_t_248 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL))); int c_ = ({ double v_t_2422 = heff_from_int_f64(heff_intSub(heff_dup(v_t_247), heff_dup(v_t_248))); int c_ = (heff_peek_f64(v_x_242) <= v_t_2422); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }))) {
    heff_drop(v_x_242);
    heff_drop(v_t_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam0, 2, 2, (V[]){v_text_241, v_sp_240});
  } else {
    heff_drop(v_sp_240);
    heff_drop(v_text_241);
    heff_drop(v_t_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam1, 2, 1, (V[]){v_x_242});
  }
}
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eatFloat32(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_text_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2411 = heff_take_field(v_hd_249, 1);
  V v_malg_2412 = heff_get_n(v_hd_249, 2, 3);
  V v_t_2413 = heff_strAppend(heff_strAppend(v_text_241, ((V)&g_heff_2eelab_2erules_2eatFloat32_str0)), ((V)&g_heff_2eelab_2erules_2eatFloat32_str1));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), v_t_2413, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(v_malg_2412, 1, (V[]){v_t_2416}));
  V f_ = v_bind_2411;
  args[0] = v_t_2417;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args) {
  V v_u_2420 = args[0];
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V v_t_2421 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_242))}), ((V)&g_heff_2eelab_2erules_2eatFloat32_lam2_clo)});
  V f_ = v_k_2419;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2efracDefault_str0, 11, "the literal");
V g_heff_2eelab_2erules_2efracDefault_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2efracDefault_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efracDefault_lam1, 1, 0};
V g_heff_2eelab_2erules_2efracDefault_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efracDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efracDefault_entry, 6, 0};

V g_heff_2eelab_2erules_2efracDefault_w(V v_sp_240, V v_e_241, V v_a_242, double v_x_243, V v_z_244, V v_z_245) {
top: ;
  if (((v_x_243 - v_x_243) == (0.0))) {
    HeffT1 v_t_2412 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efracDefault_lam0, 3, 1, (V[]){heff_box_f64(v_x_243)})}); HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_2413 = v_t_2412.f[0];
      V v_f_2414 = v_field_2413;
      return heff_tail(v_f_2414, 4, (V[]){v_e_241, v_a_242, v_z_244, v_z_245});
    }
  } else {
    heff_drop(v_e_241);
    heff_drop(v_a_242);
    V v_t_2415;
    if (((v_x_243 - v_x_243) == (0.0))) {
      v_t_2415 = heff_floatShow(heff_box_f64(v_x_243));
    } else {
      v_t_2415 = ((V)&g_heff_2eelab_2erules_2efracDefault_str0);
    }
    return (g_heff_2eelab_2erules_2eatFloat64_w(v_sp_240, v_t_2415, v_x_243, v_z_244, v_z_245));
  }
}
V g_heff_2eelab_2erules_2efracDefault(V v_sp_240, V v_e_241, V v_a_242, V v_box_24x_243, V v_z_244, V v_z_245) {
  double v_x_243 = heff_unbox_f64(v_box_24x_243);
  return (g_heff_2eelab_2erules_2efracDefault_w(v_sp_240, v_e_241, v_a_242, v_x_243, v_z_244, v_z_245));
}
V g_heff_2eelab_2erules_2efracDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efracDefault(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2efracDefault_lam1(V self, V *args) {
  V v_u_249 = args[0];
  heff_drop(v_u_249);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2efracDefault_lam0(V self, V *args) {
  V v_e_246 = args[0];
  V v_hd_247 = args[1];
  V v_k_248 = args[2];
  V v_box_24x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  double v_x_243 = heff_unbox_f64(v_box_24x_243);
  heff_drop(v_e_246);
  heff_drop(v_hd_247);
  V v_t_2410 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_x_243)}), ((V)&g_heff_2eelab_2erules_2efracDefault_lam1_clo)});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, NTAG(TAG_VPrimFloat)});
  V f_ = v_k_248;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eformGo_str0, 87, "a field's default names the fields before it and definitions, not the type's parameters");
HEFF_LIT(g_heff_2eelab_2erules_2eformGo_str1, 3, " : ");
HEFF_LIT(g_heff_2eelab_2erules_2eformGo_str2, 3, " : ");
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eformGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_lam0, 2, 0};
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2eformGo_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_lam3, 2, 0};
V g_heff_2eelab_2erules_2eformGo_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2eformGo_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_lam7, 1, 0};
V g_heff_2eelab_2erules_2eformGo_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eformGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eformGo(V v_e_27_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_27_240, 6);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2erules_2eformGo_lam0_clo);
  }
  case TAG_Cons: {
    V v_fd_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_typ_248 = heff_take_field(v_fd_246, 1);
    V v_dflt_249 = heff_take_field(v_fd_246, 2);
    V v_name_2410 = heff_get_n(v_fd_246, 0, 3);
    V v_c_2412;
    switch (heff_tag_of(v_typ_248)) {
    case TAG_MkTyp: {
      V v_f_2411 = heff_field(v_typ_248, 0);
      heff_take_n(v_typ_248, 1ULL, 1);
      v_c_2412 = heff_tr(heff_call(v_f_2411, 1, (V[]){heff_dup(v_e_27_240)}));
      break;
    }
    default: heff_nomatch(v_typ_248);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam1, 2, 6, (V[]){v_c_2412, v_e_27_240, v_i_241, v_dflt_249, v_name_2410, v_rest_247});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eformGo(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(4, shape_level__fields__defaults__large, (V[]){NTAG(TAG_Small), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam7(V self, V *args) {
  V v_c0_2440 = args[0];
  return heff_get_n(v_c0_2440, 3, 9);
}
V g_heff_2eelab_2erules_2eformGo_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_2439 = heff_env(self)[0];
  V v_i_2431 = heff_env(self)[1];
  V v_sp_2430 = heff_env(self)[2];
  V v_hd_2437 = heff_env(self)[3];
  V v_k_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2444); r_; });
  V v_stx_2446 = heff_tr(heff_call(heff_get_n(v_t_2445, 0, 2), 1, (V[]){heff_take_field(v_x_2439, 0)}));
  V v_t_2447 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_i_2431, heff_dup(v_stx_2446)));
  if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2439, 2);
    heff_drop(v_stx_2446);
    heff_drop(v_t_2447);
    V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(343LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eformGo_str0), v_sp_2430, NTAG(TAG_Nothing)});
    V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_2437, 2), 1, (V[]){v_t_2450}));
    V f_ = heff_get_n(v_hd_2437, 1, 3);
    heff_room[0] = v_t_2451;
    heff_room[1] = v_k_2438;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_sp_2430);
    heff_drop_rec(v_hd_2437, 3);
    heff_drop(v_t_2447);
    V v_t_2452 = ({ V rv_0 = v_stx_2446; V rr_ = heff_rec_reuse_nf(v_x_2439, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_2438;
    args[0] = v_t_2452;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2erules_2eformGo_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2437 = heff_env(self)[0];
  V v_i_2431 = heff_env(self)[1];
  V v_sp_2430 = heff_env(self)[2];
  V v_k_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eformGo_lam7_clo)})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2437, 2)), 1, (V[]){v_t_2442}));
  V f_ = heff_dup(heff_rfield(v_hd_2437, 1));
  heff_room[0] = v_t_2443;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam8, 1, 5, (V[]){v_x_2439, v_i_2431, v_sp_2430, v_hd_2437, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eformGo_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_i_2431 = heff_env(self)[1];
  V v_sp_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam6, 1, 4, (V[]){v_hd_2437, v_i_2431, v_sp_2430, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args) {
  V v_e_2433 = args[0];
  V v_a_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  V v_i_2431 = heff_env(self)[1];
  V v_sp_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2436;
  switch (heff_tag_of(v_c_2432)) {
  case TAG_MkChk: {
    V v_f_2435 = heff_field(v_c_2432, 0);
    heff_take_n(v_c_2432, 1ULL, 1);
    v_c_2436 = heff_tr(heff_call(v_f_2435, 2, (V[]){v_e_2433, v_a_2434}));
    break;
  }
  default: heff_nomatch(v_c_2432);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam5, 2, 3, (V[]){v_c_2436, v_i_2431, v_sp_2430});
}
V g_heff_2eelab_2erules_2eformGo_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_k_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2459, 0, 2)});
  V f_ = v_k_2458;
  args[0] = v_t_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam9(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  V v_c_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2456;
  args[0] = v_hd_2457;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam10, 1, 1, (V[]){v_k_2458});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eformGo_lam12(V self, V *args) {
  V v_x_2471 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_name_2410 = heff_env(self)[1];
  V v_x_2462 = heff_env(self)[2];
  V v_e_27_240 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_level_2472 = heff_take_field(v_x_2471, 0);
  V v_fields_2473 = heff_take_field(v_x_2471, 1);
  V v_defaults_2474 = heff_take_field(v_x_2471, 2);
  V v_large_2475 = heff_get_n(v_x_2471, 3, 4);
  V v_l1_2476 = v_level_2472;
  V v_x1_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2415, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_l2_2481;
  switch (heff_tag_of(v_x1_2477)) {
  case TAG_Nom: {
    V v_t_2478 = heff_field(v_x1_2477, 0);
    heff_take_n(v_x1_2477, 1ULL, 1);
    v_l2_2481 = ({ V a_0 = v_t_2478; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2478); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2479 = heff_field(v_x1_2477, 0);
    heff_take_n(v_x1_2477, 1ULL, 1);
    v_l2_2481 = ({ V a_0 = v_t_2479; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2479); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2480 = heff_field(v_x1_2477, 0);
    heff_take_n(v_x1_2477, 1ULL, 1);
    v_l2_2481 = ({ V a_0 = v_t_2480; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2480); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2477);
  }
  V v_t_2482;
  switch (heff_tag_of(v_l1_2476)) {
  case TAG_Small: {
    v_t_2482 = v_l2_2481;
    break;
  }
  case TAG_Large: {
    switch (heff_tag_of(v_l2_2481)) {
    case TAG_Small: {
      v_t_2482 = v_l1_2476;
      break;
    }
    case TAG_Large: {
      v_t_2482 = v_l2_2481;
      break;
    }
    case TAG_TopL: {
      v_t_2482 = v_l2_2481;
      break;
    }
    default: heff_nomatch(v_l2_2481);
    }
    break;
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_l2_2481)) {
    case TAG_Small: {
      v_t_2482 = v_l1_2476;
      break;
    }
    case TAG_Large: {
      v_t_2482 = v_l1_2476;
      break;
    }
    case TAG_TopL: {
      v_t_2482 = v_l2_2481;
      break;
    }
    default: heff_nomatch(v_l2_2481);
    }
    break;
  }
  default: heff_nomatch(v_l1_2476);
  }
  V v_t_2483 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_name_2410), heff_dup(heff_rfield(v_x_2415, 0))});
  V v_ds_2484 = v_defaults_2474;
  V v_t_2486;
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Nothing: {
    v_t_2486 = v_ds_2484;
    break;
  }
  case TAG_Just: {
    V v_d_2485 = heff_field(v_x_2462, 0);
    heff_take_n(v_x_2462, 1ULL, 1);
    v_t_2486 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_name_2410), v_d_2485}), v_ds_2484});
    break;
  }
  default: heff_nomatch(v_x_2462);
  }
  V v_e_2487 = v_e_27_240;
  V v_x_2488 = v_name_2410;
  V v_ty_2489 = v_x_2415;
  V v_after_2490 = v_large_2475;
  V v_x1_2491 = heff_tr(heff_call(heff_dup(heff_rfield(v_ty_2489, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2495;
  switch (heff_tag_of(v_x1_2491)) {
  case TAG_Nom: {
    V v_t_2492 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_x1_2495 = ({ V a_0 = v_t_2492; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2492); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2493 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_x1_2495 = ({ V a_0 = v_t_2493; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2493); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2494 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_x1_2495 = ({ V a_0 = v_t_2494; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2494); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2491);
  }
  V v_t_24100;
  switch (heff_tag_of(v_x1_2495)) {
  case TAG_Small: {
    heff_drop(v_e_2487);
    heff_drop(v_x_2488);
    heff_drop_rec(v_ty_2489, 2);
    v_t_24100 = v_after_2490;
    break;
  }
  case TAG_Large: {
    heff_drop(v_after_2490);
    V v_t_2496 = (g_heff_2eelab_2erules_2etyStrM(v_e_2487, v_ty_2489));
    V v_t_2497 = heff_strAppend(heff_strAppend(v_x_2488, ((V)&g_heff_2eelab_2erules_2eformGo_str1)), v_t_2496);
    v_t_24100 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2497});
    break;
  }
  case TAG_TopL: {
    heff_drop(v_after_2490);
    V v_t_2498 = (g_heff_2eelab_2erules_2etyStrM(v_e_2487, v_ty_2489));
    V v_t_2499 = heff_strAppend(heff_strAppend(v_x_2488, ((V)&g_heff_2eelab_2erules_2eformGo_str2)), v_t_2498);
    v_t_24100 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2499});
    break;
  }
  default: heff_nomatch(v_x1_2495);
  }
  V v_x_24101 = heff_rec_n(4, shape_level__fields__defaults__large, (V[]){v_t_2482, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2483, v_fields_2473}), v_t_2486, v_t_24100});
  V f_ = v_k_2414;
  args[0] = v_x_24101;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam11(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_name_2410 = heff_env(self)[1];
  V v_e_27_240 = heff_env(self)[2];
  V v_i_241 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2463 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2415, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2467;
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_Nom: {
    V v_x_2464 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    v_a_2467 = v_x_2464;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_a_2467 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2466 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    v_a_2467 = v_x_2466;
    break;
  }
  default: heff_nomatch(v_x1_2463);
  }
  V v_sc_2468 = (g_heff_2eelab_2eenvironment_2ebindAt(heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), heff_dup(v_name_2410), v_a_2467, heff_dup(heff_rfield(v_e_27_240, 0))));
  V v_t_2469 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2468, heff_dup(heff_rfield(v_e_27_240, 1)), heff_dup(heff_rfield(v_e_27_240, 2)), heff_dup(heff_rfield(v_e_27_240, 3)), heff_dup(heff_rfield(v_e_27_240, 4)), heff_dup(heff_rfield(v_e_27_240, 5))});
  V v_c_2470 = (g_heff_2eelab_2erules_2eformGo(v_t_2469, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_247));
  V f_ = v_c_2470;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam12, 1, 5, (V[]){v_x_2415, v_name_2410, v_x_2462, v_e_27_240, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_27_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_dflt_249 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_name_2410 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_e_2416 = heff_dup(v_e_27_240);
  V v_i_2417 = heff_dup(v_i_241);
  V v_ty_2418 = heff_dup(v_x_2415);
  V v_x4_2419 = v_dflt_249;
  V v_c_2461;
  switch (heff_tag_of(v_x4_2419)) {
  case TAG_Nothing: {
    heff_drop(v_e_2416);
    heff_drop(v_i_2417);
    heff_drop_rec(v_ty_2418, 2);
    v_c_2461 = ((V)&g_heff_2eelab_2erules_2eformGo_lam3_clo);
    break;
  }
  case TAG_Just: {
    V v_d_2422 = heff_field(v_x4_2419, 0);
    V v_ru_24x4_2419_24Just = heff_take_reuse_n(v_x4_2419, 1ULL, 1);
    V v_span_2423 = heff_take_field(v_d_2422, 1);
    V v_chk_2424 = heff_get_n(v_d_2422, 0, 2);
    V v_x1_2425 = heff_tr(heff_call(heff_get_n(v_ty_2418, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2429;
    switch (heff_tag_of(v_x1_2425)) {
    case TAG_Nom: {
      V v_x_2426 = heff_field(v_x1_2425, 0);
      heff_take_n(v_x1_2425, 1ULL, 1);
      v_a_2429 = v_x_2426;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2425, 0ULL, 1);
      v_a_2429 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2428 = heff_field(v_x1_2425, 0);
      heff_take_n(v_x1_2425, 1ULL, 1);
      v_a_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x1_2425);
    }
    V v_sp_2430 = v_span_2423;
    V v_i_2431 = v_i_2417;
    V v_c_2432 = v_chk_2424;
    HeffT1 v_t_2453 = ({ V b_0 = heff_tag_at_n(v_ru_24x4_2419_24Just, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam4, 2, 3, (V[]){v_c_2432, v_i_2431, v_sp_2430})}); HeffT1 r_ = (g_heff_2eelab_2erules_2erecovering_24cpr(b_0)); heff_drop(b_0); r_; });
    V v_c_2456;
    {
      V v_field_2454 = v_t_2453.f[0];
      V v_f_2455 = v_field_2454;
      v_c_2456 = heff_tr(heff_call(v_f_2455, 2, (V[]){v_e_2416, v_a_2429}));
    }
    v_c_2461 = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam9, 2, 1, (V[]){v_c_2456});
    break;
  }
  default: heff_nomatch(v_x4_2419);
  }
  V f_ = v_c_2461;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam11, 1, 7, (V[]){v_x_2415, v_name_2410, v_e_27_240, v_i_241, v_rest_247, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_e_27_240 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  V v_dflt_249 = heff_env(self)[3];
  V v_name_2410 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam2, 1, 7, (V[]){v_e_27_240, v_i_241, v_dflt_249, v_hd_2413, v_name_2410, v_rest_247, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eselfAdvance_24generate0_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eselfAdvance_24generate0_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eselfAdvance_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_24generate0_entry, 6, 0};

V g_heff_2eelab_2erules_2eselfAdvance_24generate0(V v_xs_240, V v_done_241, V v_gk_242, V v_a_243, V v_box_24i_244, V v_a_245) {
  int64_t v_i_244 = heff_unbox_word(v_box_24i_244);
  v_a_245 = heff_arrayOwn(v_a_245);
  if (((((int64_t)0ULL) <= v_i_244) && (heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
      V v_f_246 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_244), 2);
      HeffT2 v_t_247 = (g_heff_2eelab_2erules_2elookupP_24cpr(v_done_241, v_f_246));
      V v_t_2413;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_f_246);
          V v_v_2410 = v_field_249;
          v_t_2413 = heff_tag_n(TAG_Nom, 1, (V[]){v_v_2410});
        } else {
          heff_drop(v_field_249);
          V v_t_2412 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_gk_242)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_24generate0_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
          v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_f_246; V r_ = (g_heff_2eelab_2evalue_2eproj(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_f_246); r_; });
        }
      }
      V t_0 = v_xs_240;
      V t_1 = v_done_241;
      V t_2 = v_gk_242;
      V t_3 = v_a_243;
      int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
      V t_5 = heff_arraySetOwnedIn(v_a_245, heff_box_word(v_i_244), v_t_2413);
      v_xs_240 = t_0;
      v_done_241 = t_1;
      v_gk_242 = t_2;
      v_a_243 = t_3;
      v_i_244 = t_4;
      v_a_245 = t_5;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_gk_242);
      heff_drop(v_a_243);
      return v_a_245;
    }
  } else {
  }
top: ;
  if ((v_i_244 < heff_unbox_word(heff_arrayLength_lent(v_a_245, 0)))) {
    V v_f_246 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_244), 2);
    HeffT2 v_t_247 = (g_heff_2eelab_2erules_2elookupP_24cpr(v_done_241, v_f_246));
    V v_t_2413;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop(v_f_246);
        V v_v_2410 = v_field_249;
        v_t_2413 = heff_tag_n(TAG_Nom, 1, (V[]){v_v_2410});
      } else {
        heff_drop(v_field_249);
        V v_t_2412 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_gk_242)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_24generate0_lam1, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
        v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_f_246; V r_ = (g_heff_2eelab_2evalue_2eproj(a_0, a_1)); heff_drop(v_t_2412); heff_drop(v_f_246); r_; });
      }
    }
    V t_0 = v_xs_240;
    V t_1 = v_done_241;
    V t_2 = v_gk_242;
    V t_3 = v_a_243;
    int64_t t_4 = (v_i_244 + ((int64_t)1ULL));
    V t_5 = heff_arraySetOwned(v_a_245, heff_box_word(v_i_244), v_t_2413);
    v_xs_240 = t_0;
    v_done_241 = t_1;
    v_gk_242 = t_2;
    v_a_243 = t_3;
    v_i_244 = t_4;
    v_a_245 = t_5;
    goto top;
  } else {
    heff_drop(v_gk_242);
    heff_drop(v_a_243);
    return v_a_245;
  }
}
V g_heff_2eelab_2erules_2eselfAdvance_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eselfAdvance_24generate0(a0, a1, a[2], a[3], a[4], a[5]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eselfAdvance_24generate0_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return v_a_243;
}
V g_heff_2eelab_2erules_2eselfAdvance_24generate0_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return v_a_243;
}
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str1, 3, "tag");
V g_heff_2eelab_2erules_2etagChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam5(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam3(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam6(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etagChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagChk_entry, 5, 0};

V g_heff_2eelab_2erules_2etagChk(V v_wait_240, V v_sp_241, V v_tsp_242, V v_x_243, V v_cs_244) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam0, 4, 5, (V[]){v_tsp_242, v_cs_244, v_sp_241, v_x_243, heff_dup(v_wait_240)})});
}
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2etagChk(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2etagChk_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 9); V a_1 = v_a0_246; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2etagChk_lam5(V self, V *args) {
  V v_u_2428 = args[0];
  V v_dom_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return v_dom_2421;
}
V g_heff_2eelab_2erules_2etagChk_lam4(V self, V *args) {
  V v_u_2427 = args[0];
  V v_l_2420 = heff_env(self)[0];
  V v_dom_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2427);
  V v_t_2429 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_l_2420}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam5, 1, 1, (V[]){v_dom_2421}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2429});
}
V g_heff_2eelab_2erules_2etagChk_lam3(V self, V *args) {
  V v_e_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  V v_l_2420 = heff_env(self)[0];
  V v_dom_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2423);
  V v_t_2425 = heff_get_n(heff_get_n(v_e_2422, 0, 6), 0, 5);
  V v_t_2426 = heff_intSub(heff_intSub(v_t_2425, heff_dup(v_l_2420)), MK_INT(1LL));
  V v_t_2430 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_t_2426}), heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam4, 1, 2, (V[]){v_l_2420, heff_dup(v_dom_2421)})});
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_dom_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagChk_lam6(V self, V *args) {
  V v_chk_2468 = args[0];
  V v_hd_2469 = args[1];
  V v_k2_2470 = args[2];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_tr(heff_call(v_chk_2468, 2, (V[]){heff_dup(v_hd_2469), heff_dup(heff_rfield(v_hd_2469, 0))}));
  V v_t_2472 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2413, v_t_2471, NTAG(TAG_MkUnit)});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){v_t_2473}));
  V f_ = heff_get_n(v_hd_2469, 1, 3);
  args[0] = v_t_2474;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2etagChk_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_tsp_242 = heff_env(self)[0];
  V v_e_245 = heff_env(self)[1];
  V v_cs_244 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  V v_wait_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2413)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2414, 1);
    V v_implicit_2418 = heff_field(v_t_2414, 3);
    heff_take_n(v_t_2414, 10ULL, 4);
    heff_drop(v_wait_240);
    switch (heff_tag_of(v_implicit_2418)) {
    case TAG_Expl: {
      V v_sp_2419 = heff_dup(v_tsp_242);
      V v_l_2420 = heff_get_n(heff_dup(heff_rfield(v_e_245, 0)), 0, 5);
      V v_dom_2421 = v_dom_2416;
      V v_t_2431 = ({ V a_0 = v_sp_2419; V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam3, 3, 2, (V[]){v_l_2420, v_dom_2421})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
      V v_t_2433 = (g_heff_2eelab_2erules_2eappendP(v_cs_244, v_t_2432));
      V v_body_2434 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_t_2433; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      HeffT1 v_t_2435 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str0); V a_3 = v_body_2434; HeffT1 r_ = (g_heff_2eelab_2erules_2elambdaChk_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_body_2434); r_; });
      {
        V v_field_2436 = v_t_2435.f[0];
        V v_f_2437 = v_field_2436;
        V f_ = v_f_2437;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
    case TAG_Impl: {
      heff_drop(v_dom_2416);
      HeffT1 v_t_2438 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_2439 = v_t_2438.f[0];
        V v_f_2440 = v_field_2439;
        V f_ = v_f_2440;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
    case TAG_Inst: {
      heff_drop(v_dom_2416);
      HeffT1 v_t_2441 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_2442 = v_t_2441.f[0];
        V v_f_2443 = v_field_2442;
        V f_ = v_f_2443;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
    default: return heff_nomatch(v_implicit_2418);
    }
  }
  default: {
    heff_drop(v_t_2414);
    V v_t_2466;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2445 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_2445)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2445, 0ULL, 1);
          v_t_2466 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2445, 0ULL, 1);
          v_t_2466 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_2445, 0ULL, 1);
          v_t_2466 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_2466 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_2445);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_2466 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_2466 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
      heff_drop(v_t_2466);
      V v_c_2467 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam6, 3, 1, (V[]){heff_dup(v_x_2413)}); V a_1 = v_e_245; V a_2 = v_sp_241; V a_3 = ((V)&g_heff_2eelab_2erules_2etagChk_str1); V a_4 = v_c_2467; V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2467); r_; });
    } else {
      heff_drop(v_t_2466);
      HeffT1 v_t_2475 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_2476 = v_t_2475.f[0];
        V v_f_2477 = v_field_2476;
        V f_ = v_f_2477;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  }
}
V g_heff_2eelab_2erules_2etagChk_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_a0_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V v_tsp_242 = heff_env(self)[0];
  V v_cs_244 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_wait_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam1, 1, 1, (V[]){v_a0_246})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_t_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam2, 1, 8, (V[]){v_tsp_242, v_e_245, v_cs_244, v_sp_241, v_x_243, v_hd_247, v_k_248, v_wait_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2ecasesWith_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecasesWith_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecasesWith_str2, 1, "_");
V g_heff_2eelab_2erules_2ecasesWith_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ecasesWith_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecasesWith_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2ecasesWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesWith_lam5, 1, 0};
V g_heff_2eelab_2erules_2ecasesWith_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecasesWith_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecasesWith_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ecasesWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesWith_entry, 13, 0};

V g_heff_2eelab_2erules_2ecasesWith(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_part_245, V v_tags_246, V v_every_247, V v_named_248, V v_casesChk_249, V v_d_2410, V v_z_2411, V v_z_2412) {
top: ;
  V v_c_2416 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2ecasesWith_lam0, 1, 7, (V[]){heff_dup(v_sp_240), heff_dup(v_e_241), heff_dup(v_b_242), heff_dup(v_a_244), heff_dup(v_part_245), heff_dup(v_tags_246), heff_dup(v_casesChk_249)}), heff_dup(v_named_248)));
  return heff_tail(v_c_2416, 2, (V[]){heff_dup(v_z_2411), heff_clo_n(g_heff_2eelab_2erules_2ecasesWith_lam1, 1, 12, (V[]){v_casesChk_249, v_every_247, heff_dup(v_tags_246), v_e_241, v_part_245, v_z_2411, v_sp_240, heff_dup(v_d_2410), v_b_242, v_named_248, v_scrut_243, v_z_2412})});
}
V g_heff_2eelab_2erules_2ecasesWith_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V a10 = a[10]; V r = g_heff_2eelab_2erules_2ecasesWith(a[0], a[1], a[2], a[3], a4, a[5], a6, a[7], a[8], a[9], a10, a[11], a[12]); heff_drop(a4); heff_drop(a6); heff_drop(a10); return r;
}
V g_heff_2eelab_2erules_2ecasesWith_lam0(V self, V *args) {
  V v_p_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_part_245 = heff_env(self)[4];
  V v_tags_246 = heff_env(self)[5];
  V v_casesChk_249 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_p_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    V v_fs_2415 = heff_field(v_p_2413, 1);
    heff_take_n(v_p_2413, 3ULL, 2);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_a_244; V a_4 = v_part_245; V a_5 = v_tags_246; V a_6 = v_x_2414; V a_7 = heff_arrayToList(v_fs_2415); V a_8 = v_casesChk_249; V r_ = (g_heff_2eelab_2erules_2ecaseArm(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_a_244); heff_drop(v_tags_246); r_; });
  }
  default: return heff_nomatch(v_p_2413);
  }
}
V g_heff_2eelab_2erules_2ecasesWith_lam2(V self, V *args) {
  V v_p_2418 = args[0];
  V v_casesChk_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_p_2418, 0);
    heff_take_n(v_p_2418, 1ULL, 2);
    HeffT2 v_t_2421 = ({ V a_0 = heff_rfield(v_casesChk_249, 1); V a_1 = v_x_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_2419); r_; });
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2422 == ((int64_t)0ULL)) ? ({ V v_i_2424 = heff_dup(v_field_2423); int c_ = ({ V v_xs_2425 = heff_dup(heff_rfield(v_casesChk_249, 2)); int c_ = ((heff_intLe_c_lent(MK_INT(0LL), v_i_2424, 1) && heff_intLt_c(heff_dup(v_i_2424), heff_arrayLength_lent(v_xs_2425, 0))) ? ({ V v_x_2426 = heff_arrayIndex_lent(v_xs_2425, v_i_2424, 0); int c_ = 0; heff_drop(v_x_2426); c_; }) : 1); heff_drop(v_xs_2425); c_; }); heff_drop(v_i_2424); c_; }) : 1));
      heff_drop_rec(v_casesChk_249, 3);
      heff_drop(v_field_2423);
      return v_ret_24bool;
    }
  }
  default: return heff_nomatch(v_p_2418);
  }
}
V g_heff_2eelab_2erules_2ecasesWith_lam5(V self, V *args) {
  V v_u_2461 = args[0];
  heff_drop(v_u_2461);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2ecasesWith_lam4(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_casesChk_249 = heff_env(self)[1];
  V v_every_247 = heff_env(self)[2];
  V v_named_248 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  V v_scrut_243 = heff_env(self)[5];
  V v_z_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_n_2442 = heff_get_n(heff_get_n(v_e_241, 0, 6), 0, 5);
  V v_body_2443 = heff_get_n(v_x_2441, 0, 2);
  V v_casesChk_2444 = v_casesChk_249;
  V v_every_2445 = v_every_247;
  V v_named_2446 = v_named_248;
  V v_cases_2447 = v_x_2417;
  V v_t_2448 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_named_2446; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_named_2446); r_; });
  V v_t_2449 = (g_list_2edrop(v_t_2448, v_every_2445));
  V v_t_2450 = (g_list_2emap_24s258116700x992061112(heff_dup(v_body_2443), v_t_2449));
  V v_x_2451 = (g_heff_2eelab_2erules_2etermSizeGo(MK_INT(100LL), MK_INT(0LL), v_t_2450));
  V v_pairs_2455;
  if (heff_intLt_c(MK_INT(100LL), v_x_2451)) {
    heff_drop(v_n_2442);
    heff_drop(v_casesChk_2444);
    heff_drop(v_every_2445);
    V v_t_2452 = heff_arrayFromList(NTAG(TAG_Nil));
    V v_t_2453 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2erules_2ecasesWith_str2), heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_body_2443})});
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    v_pairs_2455 = (g_heff_2eelab_2erules_2eappendP(v_cases_2447, v_t_2454));
  } else {
    v_pairs_2455 = (g_heff_2eelab_2erules_2einOrder(v_n_2442, v_body_2443, v_casesChk_2444, v_every_2445, v_cases_2447));
  }
  V v_t_2456 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2455)));
  V v_t_2457 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2455));
  V v_t_2458 = (g_list_2emap_24s1173914895x100384474(v_pairs_2455));
  V v_cases_2459 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2456), v_t_2457, heff_arrayFromList(v_t_2458)});
  V v_t_2460 = heff_tag_n(TAG_SMatch, 2, (V[]){heff_get_n(v_scrut_243, 0, 2), v_cases_2459});
  V f_ = v_z_2412;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2460, ((V)&g_heff_2eelab_2erules_2ecasesWith_lam5_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecasesWith_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_tags_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_part_245 = heff_env(self)[2];
  V v_rest_2428 = heff_env(self)[3];
  V v_e_241 = heff_env(self)[4];
  V v_d_2410 = heff_env(self)[5];
  V v_b_242 = heff_env(self)[6];
  V v_z_2411 = heff_env(self)[7];
  V v_casesChk_249 = heff_env(self)[8];
  V v_every_247 = heff_env(self)[9];
  V v_named_248 = heff_env(self)[10];
  V v_x_2417 = heff_env(self)[11];
  V v_scrut_243 = heff_env(self)[12];
  V v_z_2412 = heff_env(self)[13];
  heff_clo_take(self, 14);
  heff_drop(v_x_2431);
  HeffT2 v_t_2432 = ({ V a_0 = v_tags_246; V b_1 = ((V)&g_heff_2eelab_2erules_2ecasesWith_str1); HeffT2 r_ = (g_heff_2eelab_2erules_2ewrittenAt_24cpr(a_0, b_1)); heff_drop(v_tags_246); heff_drop(b_1); r_; });
  V v_t_2436;
  {
    V v_field_2434 = v_t_2432.f[1];
    int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
    if ((v_tag_2433 == ((int64_t)0ULL))) {
      heff_drop(v_sp_240);
      V v_at_2435 = v_field_2434;
      v_t_2436 = v_at_2435;
    } else {
      heff_drop(v_field_2434);
      v_t_2436 = v_sp_240;
    }
  }
  V v_sc_2437 = ({ V a_0 = v_part_245; V a_1 = v_rest_2428; V a_2 = v_t_2436; V a_3 = heff_dup(heff_rfield(v_e_241, 0)); V r_ = (g_heff_2eelab_2eenvironment_2ematchedTo(a_0, a_1, a_2, a_3)); heff_drop(v_part_245); r_; });
  V v_c_2440;
  switch (heff_tag_of(v_d_2410)) {
  case TAG_MkChk: {
    V v_f_2438 = heff_field(v_d_2410, 0);
    heff_take_n(v_d_2410, 1ULL, 1);
    V v_t_2439 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2437, heff_dup(heff_rfield(v_e_241, 1)), heff_dup(heff_rfield(v_e_241, 2)), heff_dup(heff_rfield(v_e_241, 3)), heff_dup(heff_rfield(v_e_241, 4)), heff_dup(heff_rfield(v_e_241, 5))});
    v_c_2440 = heff_tr(heff_call(v_f_2438, 2, (V[]){v_t_2439, v_b_242}));
    break;
  }
  default: heff_nomatch(v_d_2410);
  }
  V f_ = v_c_2440;
  heff_room[0] = v_z_2411;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesWith_lam4, 1, 7, (V[]){v_e_241, v_casesChk_249, v_every_247, v_named_248, v_x_2417, v_scrut_243, v_z_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecasesWith_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_casesChk_249 = heff_env(self)[0];
  V v_every_247 = heff_env(self)[1];
  V v_tags_246 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_part_245 = heff_env(self)[4];
  V v_z_2411 = heff_env(self)[5];
  V v_sp_240 = heff_env(self)[6];
  V v_d_2410 = heff_env(self)[7];
  V v_b_242 = heff_env(self)[8];
  V v_named_248 = heff_env(self)[9];
  V v_scrut_243 = heff_env(self)[10];
  V v_z_2412 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2427 = (g_list_2ekeepIf(heff_clo_n(g_heff_2eelab_2erules_2ecasesWith_lam2, 1, 1, (V[]){heff_dup(v_casesChk_249)}), heff_dup(v_every_247)));
  V v_rest_2428 = (g_list_2emap_24s1937570095x2110149801(v_t_2427));
  V v_t_2429 = ({ V a_0 = v_tags_246; V b_1 = ((V)&g_heff_2eelab_2erules_2ecasesWith_str0); V r_ = (g_heff_2eelab_2erules_2ewrittenAt(a_0, b_1)); heff_drop(b_1); r_; });
  V v_c_2430 = (g_heff_2eelab_2erules_2eseeArm(heff_dup(heff_rfield(v_e_241, 0)), heff_dup(v_part_245), heff_dup(v_rest_2428), heff_dup(g_heff_2eelab_2erules_2estandsFor_get()), v_t_2429));
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_z_2411);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesWith_lam3, 1, 14, (V[]){v_tags_246, v_sp_240, v_part_245, v_rest_2428, v_e_241, v_d_2410, v_b_242, v_z_2411, v_casesChk_249, v_every_247, v_named_248, v_x_2417, v_scrut_243, v_z_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam11(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam10(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam9(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseLet_entry, 3, 0};

V g_heff_2eelab_2erules_2ecaseLet(V v_x_240, V v_scrutSyn_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam0, 2, 3, (V[]){heff_dup(v_scrutSyn_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2ecaseLet(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args) {
  V v_c_2414 = args[0];
  V v_a0_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2414, 3, 9); V a_1 = v_a0_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args) {
  V v_v_2430 = args[0];
  V v_scope_27_2431 = args[1];
  V v_body_242 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2430);
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2432 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2433 = ({ V rv_0 = v_scope_27_2431; V rr_ = heff_rec_reuse_nf(v_e_243, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2432;
    args[0] = v_t_2433;
    args[1] = v_b_244;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args) {
  V v_u_2443 = args[0];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2443);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2418});
}
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args) {
  V v_u_2447 = args[0];
  V v_b_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2447);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_244});
}
V g_heff_2eelab_2erules_2ecaseLet_lam11(V self, V *args) {
  V v_u2_2457 = args[0];
  V v_val_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2457);
  V v_x1_2458 = heff_tr(heff_call(v_val_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2458)) {
  case TAG_Nom: {
    V v_x_2459 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2459;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2458, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2461 = heff_field(v_x1_2458, 0);
    heff_take_n(v_x1_2458, 1ULL, 1);
    return v_x_2461;
  }
  default: return heff_nomatch(v_x1_2458);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam10(V self, V *args) {
  V v_f_2456 = args[0];
  V v_val_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2evalue_2eapp(v_f_2456, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam11, 1, 1, (V[]){v_val_2413})));
}
V g_heff_2eelab_2erules_2ecaseLet_lam9(V self, V *args) {
  V v_u_2454 = args[0];
  V v_field_2453 = heff_env(self)[0];
  V v_val_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2454);
  V v_t_2455 = heff_tr(heff_call(v_field_2453, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2evalue_2eebind(heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam10, 1, 1, (V[]){v_val_2413}), v_t_2455));
}
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  V v_x_240 = heff_env(self)[3];
  V v_stx_2412 = heff_env(self)[4];
  V v_val_2413 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2436 = heff_take_field(v_e_243, 2);
  V v_t_2439;
  switch (heff_tag_of(v_t_2436)) {
  case TAG_ForNominative: {
    v_t_2439 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2436, 0ULL, 2);
    v_t_2439 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2436);
  }
  V v_t_2440 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 5);
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 5);
  V v_t_2442 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2441, heff_dup(v_x_2418)));
  V v_dom_2444 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2442, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam7, 1, 1, (V[]){v_x_2418})});
  V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 5);
  V v_t_2446 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2445, MK_INT(1LL)), heff_dup(v_b_244)));
  V v_cod_2448 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2446, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam8, 1, 1, (V[]){v_b_244})})});
  V v_t_2449 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 5);
  V v_t_2450 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_243, 1)), v_t_2449, v_dom_2444, v_cod_2448));
  HeffT2 v_t_2451 = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr(v_x_240, v_x_2435, v_t_2439, heff_get_n(v_e_243, 1, 6), v_t_2440, v_t_2450));
  {
    V v_field_2452 = v_t_2451.f[0];
    V v_field_2453 = v_t_2451.f[1];
    V v_t_2462 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_field_2452, v_stx_2412}), heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam9, 1, 2, (V[]){v_field_2453, v_val_2413})});
    V f_ = v_k_248;
    args[0] = v_t_2462;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_stx_2412 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_val_2413 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_l_2419 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 5);
  HeffT2 v_t_2420 = (g_heff_2eelab_2eenvironment_2epartOf_24cpr(heff_dup(heff_rfield(v_e_243, 0)), heff_dup(v_stx_2412)));
  V v_t_2429;
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    V v_sc_2423 = heff_dup(heff_rfield(v_e_243, 0));
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_p_2424 = v_field_2422;
      V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_sc_2423, 4)), 0, 2);
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2419, v_p_2424}), v_t_2425});
      V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_sc_2423, 4)), 1, 2);
      V v_k_2428 = heff_rec_n(2, shape_aliases__tags, (V[]){v_t_2426, v_t_2427});
      v_t_2429 = ({ V rv_4 = v_k_2428; V rr_ = heff_rec_reuse_nf(v_sc_2423, 15ULL, 5, shape_len__names__locals__ctx__matched, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      heff_drop(v_l_2419);
      heff_drop(v_field_2422);
      v_t_2429 = v_sc_2423;
    }
  }
  V v_c_2434 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), heff_dup(v_x_2418), v_t_2429, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam5, 2, 3, (V[]){v_body_242, heff_dup(v_e_243), heff_dup(v_b_244)})));
  V f_ = v_c_2434;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam6, 1, 7, (V[]){v_e_243, v_x_2418, v_b_244, v_x_240, v_stx_2412, v_val_2413, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_scrut_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_stx_2412 = heff_take_field(v_scrut_2410, 0);
    V v_val_2413 = heff_get_n(v_scrut_2410, 1, 2);
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam3, 1, 1, (V[]){v_a0_2411})})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2416}));
    V f_ = heff_dup(heff_rfield(v_hd_247, 1));
    heff_room[0] = v_t_2417;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam4, 1, 8, (V[]){v_e_243, v_stx_2412, v_x_240, v_body_242, v_b_244, v_hd_247, v_val_2413, v_k_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam2, 1, 6, (V[]){v_hd_247, v_e_243, v_x_240, v_body_242, v_b_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_b_244 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246;
  switch (heff_tag_of(v_scrutSyn_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_scrutSyn_241, 0);
    heff_take_n(v_scrutSyn_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_scrutSyn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam1, 2, 5, (V[]){v_c_246, v_e_243, v_x_240, v_body_242, v_b_244});
}
Clo g_heff_2eelab_2erules_2efindOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efindOr_entry, 3, 0};

V g_heff_2eelab_2erules_2efindOr(V v_sp_240, V v_x_241, V v_unbound_242) {
top: ;
  HeffT1 v_t_243 = (g_heff_2eelab_2erules_2efindOr_24cpr(v_sp_240, v_x_241, v_unbound_242));
  {
    V v_field_244 = v_t_243.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_244});
  }
}
V g_heff_2eelab_2erules_2efindOr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efindOr(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2erules_2eappendP_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24tok2_entry, 3, 0};

V g_heff_2eelab_2erules_2eappendP_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2eelab_2erules_2eappendP_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2erules_2eappendP_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eappendP_24tok2(a[0], a[1], a[2]);
}