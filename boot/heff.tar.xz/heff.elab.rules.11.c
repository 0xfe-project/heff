// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940 61712
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_fields 672433636
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_large 304101205
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_level__fields__defaults__large[] = {LBL_level, LBL_fields, LBL_defaults, LBL_large};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void);
V g_heff_2eelab_2eenvironment_2ebindName(V, V, V);
V g_heff_2eelab_2eenvironment_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindName_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2eglobals_2eisBroken(V, V);
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eisBroken_clo;
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimFloat_get(void);
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eadvanceSelf(V, V, V, V);
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eadvanceSelf_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V, V);
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo;
V g_heff_2eelab_2erules_2echeckSetting(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSetting_clo;
V g_heff_2eelab_2erules_2edefaultAt(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultAt_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2eeqBareStr(V, V, V, V);
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqBareStr_clo;
V g_heff_2eelab_2erules_2eetaArg(V, V, V);
V g_heff_2eelab_2erules_2eetaArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eetaArg_clo;
V g_heff_2eelab_2erules_2eevidenceArg(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceArg_clo;
V g_heff_2eelab_2erules_2eevidenceGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_clo;
V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240_clo;
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
HeffT1 g_heff_2eelab_2erules_2efind_24cpr(V, V);
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionIntro_24cpr(V, V, V);
V g_heff_2eelab_2erules_2egivenType(V);
V g_heff_2eelab_2erules_2egivenType_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenType_clo;
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
HeffT2 g_heff_2eelab_2erules_2eindexOfName_24cpr(V, V, V);
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2ekeepRecovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ekeepRecovered_clo;
V g_heff_2eelab_2erules_2elargeField(V, V, V, V);
V g_heff_2eelab_2erules_2elargeField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elargeField_clo;
HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(V, V, V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle_clo;
V g_heff_2eelab_2erules_2emetaTyShown(V, V, V);
V g_heff_2eelab_2erules_2emetaTyShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaTyShown_clo;
V g_heff_2eelab_2erules_2eplacesSaid(V);
V g_heff_2eelab_2erules_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eplacesSaid_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordTagIn(V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordTagIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTagIn_clo;
V g_heff_2eelab_2erules_2erecoverWith(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecoverWith_clo;
V g_heff_2eelab_2erules_2esettled(V, V, V, V);
V g_heff_2eelab_2erules_2esettled_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_clo;
V g_heff_2eelab_2erules_2esettled_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2esettled_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esettled_24tok1_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2etagChk(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagChk_clo;
V g_heff_2eelab_2erules_2etupleChk(V, V, V, V);
V g_heff_2eelab_2erules_2etupleChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etupleChk_clo;
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2erules_2eunspecForced(V);
V g_heff_2eelab_2erules_2eunspecForced_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunspecForced_clo;
V g_heff_2eelab_2erules_2evalShown(V, V, V);
V g_heff_2eelab_2erules_2evalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evalShown_clo;
HeffT2 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2erules_2eworldOf_24cpr(V);
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get(void);
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojAt(V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_clo;
V g_heff_2eelab_2evalue_2eprojAt_24tok1(V, V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_24tok1_clo;
V g_heff_2eelab_2evalue_2eprojTy(V, V, V);
V g_heff_2eelab_2evalue_2eprojTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTy_clo;
V g_heff_2eelab_2evalue_2ereflect(V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_clo;
V g_heff_2eelab_2evalue_2ereflect_24tok2(V, V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24tok2_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str1, 0, "");
Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V v_d_240, V v_t_241) {
top: ;
  return (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940), v_d_240, v_t_241, ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str0), ((V)&g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_str1)));
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str0, 4, "meta");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str1, 4, ") : ");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str3, 1, "\?");
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam0, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam5, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efreshMeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_entry, 7, 0};

V g_heff_2eelab_2erules_2efreshMeta(V v_len_240, V v_locals_241, V v_ty_242, V v_name_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_bind_247 = heff_take_field(v_hd_245, 1);
  V v_malg_248 = heff_get_n(v_hd_245, 2, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_247), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam1, 1, 8, (V[]){v_ty_242, v_len_240, v_name_243, v_sp_244, v_malg_248, v_bind_247, heff_dup(v_locals_241), v_k_246})});
}
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2efreshMeta(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 4, 8);
}
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_metas_2415 = heff_take_field(v_c_2414, 3);
  V v_infos_2416 = heff_take_field(v_c_2414, 0);
  V v_recovered_2417 = heff_take_field(v_c_2414, 1);
  V v_poisoned_2418 = heff_take_field(v_c_2414, 2);
  V v_postponed_2419 = heff_take_field(v_c_2414, 5);
  V v_trace_2420 = heff_take_field(v_c_2414, 6);
  V v_selfKey_2421 = heff_get_n(v_c_2414, 7, 8);
  V v_t_2422 = heff_rec_n(6, shape_ty__sol__solStx__arity__name__span, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_len_240, v_name_243, v_sp_244});
  V v_mc_2423 = (g_std_2emap_2einsert_24s170109517x1206653089(v_metas_2415, heff_dup(v_x_2413), v_t_2422));
  return heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_2416, v_recovered_2417, v_poisoned_2418, v_mc_2423, heff_intAdd(v_x_2413, MK_INT(1LL)), v_postponed_2419, v_trace_2420, v_selfKey_2421});
}
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args) {
  V v_c_2432 = args[0];
  return heff_get_n(v_c_2432, 3, 8);
}
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args) {
  V v_u_2437 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_name_243 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2437);
  V v_t_2438 = ({ V a_0 = v_x_2436; V a_1 = v_len_240; V a_2 = v_ty_242; V r_ = (g_heff_2eelab_2erules_2emetaTyShown(a_0, a_1, a_2)); heff_drop(v_x_2436); r_; });
  V v_t_2439 = heff_strAppend(v_name_243, heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str1), v_t_2438));
  V v_t_2440 = heff_strAppend(heff_intShow(v_x_2413), heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str2), v_t_2439));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str3), v_t_2440);
}
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args) {
  V v_sp_27_2448 = args[0];
  V v_i_2449 = args[1];
  V v_locals_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = ({ V a_0 = v_locals_241; V a_1 = v_i_2449; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_locals_241); r_; });
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_27_2448, v_t_2450});
}
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args) {
  V v_u_2452 = args[0];
  V v_sp_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2452);
  return v_sp_2451;
}
V g_heff_2eelab_2erules_2efreshMeta_lam11(V self, V *args) {
  V v_u_2453 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  return v_ty_242;
}
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_locals_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2443);
  V v_t_2444 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(heff_dup(v_len_240), MK_INT(1LL))));
  V v_t_2445 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_len_240), heff_dup(v_ty_242)));
  V v_t_2446 = heff_tag_n(TAG_SMetaApp, 3, (V[]){heff_dup(v_x_2413), heff_arrayFromList(v_t_2444), v_t_2445});
  V v_t_2447 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(v_len_240, MK_INT(1LL))));
  V v_sp_2451 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam9, 2, 1, (V[]){v_locals_241}); V a_1 = NTAG(TAG_SpId); V a_2 = v_t_2447; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2447); r_; });
  V v_t_2454 = (g_heff_2eelab_2evalue_2ereflect(heff_tag_n(TAG_HMeta, 1, (V[]){v_x_2413}), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam10, 1, 1, (V[]){v_sp_2451}), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam11, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_x_2455 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2446, v_t_2454});
  V f_ = v_k_246;
  args[0] = v_x_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_name_243 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_malg_248 = heff_env(self)[5];
  V v_bind_247 = heff_env(self)[6];
  V v_locals_241 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2441 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_244, ((V)&g_heff_2eelab_2erules_2efreshMeta_str0), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam7, 1, 5, (V[]){v_x_2436, heff_dup(v_len_240), heff_dup(v_ty_242), v_name_243, heff_dup(v_x_2413)})}), NTAG(TAG_MkUnit)});
  V v_t_2442 = heff_tr(heff_call(v_malg_248, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
  V f_ = v_bind_247;
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam8, 1, 5, (V[]){v_len_240, v_ty_242, v_x_2413, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_malg_248 = heff_env(self)[0];
  V v_bind_247 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_len_240 = heff_env(self)[3];
  V v_ty_242 = heff_env(self)[4];
  V v_name_243 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_locals_241 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2431);
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam5_clo)})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){v_t_2434}));
  V f_ = heff_dup(v_bind_247);
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam6, 1, 9, (V[]){v_sp_244, v_len_240, v_ty_242, v_name_243, v_x_2413, v_malg_248, v_bind_247, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_malg_248 = heff_env(self)[0];
  V v_bind_247 = heff_env(self)[1];
  V v_sp_244 = heff_env(self)[2];
  V v_len_240 = heff_env(self)[3];
  V v_ty_242 = heff_env(self)[4];
  V v_name_243 = heff_env(self)[5];
  V v_x_2413 = heff_env(self)[6];
  V v_locals_241 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2428 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2427, NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})}));
  V f_ = heff_dup(v_bind_247);
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam4, 1, 9, (V[]){v_malg_248, v_bind_247, v_sp_244, v_len_240, v_ty_242, v_name_243, v_x_2413, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_malg_248 = heff_env(self)[4];
  V v_bind_247 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam2, 1, 5, (V[]){heff_dup(v_ty_242), heff_dup(v_len_240), heff_dup(v_name_243), heff_dup(v_sp_244), heff_dup(v_x_2413)})})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_dup(v_malg_248), 1, (V[]){v_t_2425}));
  V f_ = heff_dup(v_bind_247);
  heff_room[0] = v_t_2426;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam3, 1, 9, (V[]){v_malg_248, v_bind_247, v_sp_244, v_len_240, v_ty_242, v_name_243, v_x_2413, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str0, 5, "solve");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str1, 5, ") := ");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str3, 1, "\?");
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam0, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam3, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esolveHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_entry, 8, 0};

V g_heff_2eelab_2erules_2esolveHole(V v_g_240, V v_cs_241, V v_m_242, V v_holeVal_243, V v_argStx_244, V v_argVal_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam1, 1, 8, (V[]){v_m_242, v_g_240, v_argStx_244, v_hd_246, v_k_247, v_cs_241, v_holeVal_243, v_argVal_245})});
}
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esolveHole(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args) {
  V v_c_2419 = args[0];
  return heff_get_n(v_c_2419, 3, 8);
}
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args) {
  V v_u_2424 = args[0];
  V v_e_2416 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2424);
  V v_t_2425 = (g_heff_2eelab_2eunify_2elamsU(heff_take_field(v_e_2416, 3), v_argStx_244));
  V v_t_2426 = ({ V a_0 = v_x_2423; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2423); r_; });
  V v_e_2427 = heff_tr(heff_call(heff_get_n(v_t_2426, 0, 2), 1, (V[]){v_t_2425}));
  V v_t_2428 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_2427));
  V v_t_2429 = heff_strAppend(heff_get_n(v_e_2416, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str1), v_t_2428));
  V v_t_2430 = heff_strAppend(heff_intShow(v_m_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str2), v_t_2429));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str3), v_t_2430);
}
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_247;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_e_2416 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(heff_rfield(v_e_2416, 5)), ((V)&g_heff_2eelab_2erules_2esolveHole_str0), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam5, 1, 4, (V[]){v_e_2416, v_argStx_244, v_x_2423, v_m_242})});
  V v_t_2432 = heff_tag_n(TAG_Trace, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2433;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam6, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_e_2416 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2418);
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam3_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam4, 1, 5, (V[]){v_e_2416, v_argStx_244, v_m_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_cs_241 = heff_env(self)[5];
  V v_holeVal_243 = heff_env(self)[6];
  V v_argVal_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2413 = ({ V a_0 = v_x_2412; V a_1 = heff_dup(v_m_242); HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_e_2416 = v_field_2415;
      V v_t_2417 = heff_dup(heff_rfield(v_e_2416, 1));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_Nothing: {
        heff_drop(v_cs_241);
        heff_drop(v_holeVal_243);
        heff_drop(v_argVal_245);
        return (g_heff_2eelab_2erules_2efillHole(v_g_240, heff_dup(v_m_242), heff_dup(v_e_2416), heff_dup(v_argStx_244), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam2, 1, 5, (V[]){v_hd_246, v_e_2416, v_argStx_244, v_m_242, v_k_247})));
      }
      case TAG_Just: {
        heff_take_n(v_t_2417, 0ULL, 1);
        heff_drop(v_m_242);
        heff_drop(v_argStx_244);
        heff_drop_rec(v_e_2416, 6);
        V v_t_2437 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
        return (g_heff_2eelab_2emeta_2eliftU(v_t_2437, v_hd_246, v_k_247));
      }
      default: return heff_nomatch(v_t_2417);
      }
    } else {
      heff_drop(v_m_242);
      heff_drop(v_argStx_244);
      heff_drop(v_field_2415);
      V v_t_2438 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
      return (g_heff_2eelab_2emeta_2eliftU(v_t_2438, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqBareStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqBareStr_entry, 4, 0};

V g_heff_2eelab_2erules_2eeqBareStr(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243) {
top: ;
  V v_len_244 = heff_take_field(v_cs_241, 0);
  V v_names_245 = heff_get_n(v_cs_241, 1, 2);
  V v_e_246 = (g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(v_len_244, v_h_242, v_sp_243));
  V v_t_2414 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqBareStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 0, 2), 1, (V[]){v_e_246}));
  HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), v_names_245, v_e_2415);
}
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqBareStr(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_x_247; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_247); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_d_248);
      V v_x_2413 = v_field_2412;
      return v_x_2413;
    } else {
      heff_drop(v_field_2412);
      return v_d_248;
    }
  }
}
V g_heff_2eelab_2erules_2erecoverWith_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecoverWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecoverWith_entry, 7, 0};

V g_heff_2eelab_2erules_2erecoverWith(V v_e_240, V v_a_241, V v_d_242, V v_saved_243, V v_waiting_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_241), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam0, 1, 6, (V[]){v_d_242, v_saved_243, v_waiting_244, v_hd_245, v_a_241, v_k_246})));
}
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erecoverWith(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2erecoverWith_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return v_a_241;
}
V g_heff_2eelab_2erules_2erecoverWith_lam2(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  V v_t_2412 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam3, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2412});
}
V g_heff_2eelab_2erules_2erecoverWith_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2413 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam2, 1, 1, (V[]){v_a_241})});
  V f_ = v_k_246;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecoverWith_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_saved_243 = heff_env(self)[1];
  V v_waiting_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248;
  if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
    heff_drop(v_x_247);
    v_t_248 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_d_242, 30ULL, 5, shape_code__severity__msg__span__note, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_x_247);
    v_t_248 = v_d_242;
  }
  return (g_heff_2eelab_2erules_2ekeepRecovered(v_t_248, v_saved_243, v_waiting_244, v_hd_245, heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam1, 1, 2, (V[]){v_a_241, v_k_246})));
}
Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecatMaybesR_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str0, 6, ", but ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str1, 10, " is wanted");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str2, 3, " = ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str3, 6, ", has ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str4, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2echeckSetting_str5, 23, "the instance found for ");
V g_heff_2eelab_2erules_2echeckSetting_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckSetting_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_lam0, 1, 0};
V g_heff_2eelab_2erules_2echeckSetting_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2echeckSetting_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_lam2, 1, 0};
V g_heff_2eelab_2erules_2echeckSetting_lam4(V self, V *args);
V g_heff_2eelab_2erules_2echeckSetting_lam3(V self, V *args);
V g_heff_2eelab_2erules_2echeckSetting_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSetting_entry, 9, 0};

V g_heff_2eelab_2erules_2echeckSetting(V v_e_240, V v_sp_241, V v_w_242, V v_goal_243, V v_found_244, V v_final_245, V v_x7_246, V v_p_247, V v_p_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x7_246, 0);
    V v_v_2410 = heff_field(v_x7_246, 1);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2echeckSetting_lam0_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_247, 2)), 1, (V[]){v_t_2413}));
    return heff_tail(heff_dup(heff_rfield(v_p_247, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam1, 1, 10, (V[]){v_p_247, v_goal_243, v_found_244, heff_dup(v_x_249), v_e_240, heff_dup(v_v_2410), v_w_242, v_sp_241, v_p_248, heff_dup(v_final_245)})});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2erules_2echeckSetting_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a6 = a[6]; V r = g_heff_2eelab_2erules_2echeckSetting(a[0], a[1], a[2], a[3], a[4], a5, a6, a[7], a[8]); heff_drop(a5); heff_drop(a6); return r;
}
V g_heff_2eelab_2erules_2echeckSetting_lam0(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 5, 8);
}
V g_heff_2eelab_2erules_2echeckSetting_lam2(V self, V *args) {
  V v_c_2416 = args[0];
  return heff_get_n(v_c_2416, 3, 8);
}
V g_heff_2eelab_2erules_2echeckSetting_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2420 = heff_env(self)[0];
  V v_goal_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_w_242 = heff_env(self)[3];
  V v_x_2428 = heff_env(self)[4];
  V v_x_249 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  V v_final_245 = heff_env(self)[9];
  V v_x_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_err_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    heff_drop(v_final_245);
    heff_drop(v_x_2415);
    V v_t_2435 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2420, heff_dup(v_goal_243)));
    V v_t_2436 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2435));
    V v_t_2437 = (g_heff_2eelab_2erules_2egoalShown(heff_dup(v_e_240), v_x_2420, v_t_2436));
    V v_t_2438 = heff_tr(heff_call(heff_get_n(v_w_242, 0, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2439 = (g_heff_2eelab_2erules_2evalShown(heff_dup(v_e_240), v_x_2420, v_x_2428));
    V v_t_2440 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_x_2420; V a_2 = v_goal_243; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2420); r_; });
    V v_t_2441 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckSetting_str0), heff_strAppend(v_t_2440, ((V)&g_heff_2eelab_2erules_2echeckSetting_str1)));
    V v_t_2442 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckSetting_str2), heff_strAppend(v_t_2439, v_t_2441));
    V v_t_2443 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckSetting_str3), heff_strAppend(v_x_249, v_t_2442));
    V v_t_2444 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckSetting_str4), heff_strAppend(v_t_2438, v_t_2443));
    V v_msg_2445 = heff_strAppend(((V)&g_heff_2eelab_2erules_2echeckSetting_str5), heff_strAppend(v_t_2437, v_t_2444));
    V v_note_2446 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2434; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2434); r_; });
    V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(354LL), NTAG(TAG_SError), v_msg_2445, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2446})});
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tr(heff_call(heff_take_field(v_p_247, 2), 1, (V[]){v_t_2449}));
    V f_ = heff_get_n(v_p_247, 1, 3);
    heff_room[0] = v_t_2450;
    heff_room[1] = v_p_248;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_ru_24x_2433_24Right = heff_take_reuse_n(v_x_2433, 0ULL, 1);
    heff_drop(v_x_2420);
    heff_drop(v_goal_243);
    heff_drop_rec(v_e_240, 6);
    heff_drop_rec(v_w_242, 6);
    heff_drop(v_x_2428);
    heff_drop(v_x_249);
    heff_drop(v_sp_241);
    return ({ V a_0 = v_ru_24x_2433_24Right; V a_1 = v_final_245; V a_2 = v_x_2415; V a_3 = v_p_247; V a_4 = v_p_248; V r_ = (g_heff_2eelab_2erules_2esettled_24tok1(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_final_245); r_; });
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2eelab_2erules_2echeckSetting_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_goal_243 = heff_env(self)[0];
  V v_found_244 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_v_2410 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  V v_w_242 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  V v_final_245 = heff_env(self)[9];
  V v_x_2415 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2421 = (g_heff_2eelab_2evalue_2eforceTy(v_x_2420, heff_dup(v_goal_243)));
  V v_t_2422 = (g_heff_2eelab_2erules_2eunspecForced(v_t_2421));
  V v_t_2423 = (g_heff_2eelab_2evalue_2eprojTy(v_t_2422, heff_dup(v_found_244), v_x_249));
  V v_x1_2424 = (g_heff_2eelab_2evalue_2eprojAt(v_found_244, heff_dup(v_x_249), v_t_2423));
  V v_x_2428;
  switch (heff_tag_of(v_x1_2424)) {
  case TAG_Nom: {
    V v_x_2425 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_x_2428 = v_x_2425;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2424, 0ULL, 1);
    v_x_2428 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2427 = heff_field(v_x1_2424, 0);
    heff_take_n(v_x1_2424, 1ULL, 1);
    v_x_2428 = v_x_2427;
    break;
  }
  default: heff_nomatch(v_x1_2424);
  }
  V v_c_2429 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_2430 = heff_take_field(v_c_2429, 0);
  V v_names_2431 = heff_get_n(v_c_2429, 1, 4);
  V v_t_2432 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), heff_dup(heff_rfield(v_e_240, 1)), heff_rec_n(2, shape_len__names, (V[]){v_len_2430, v_names_2431}), heff_dup(v_x_2428), v_v_2410));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2432, heff_dup(v_p_247), heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam4, 1, 11, (V[]){v_x_2420, v_goal_243, v_e_240, v_w_242, v_x_2428, v_x_249, v_sp_241, v_p_247, v_p_248, v_final_245, v_x_2415})));
}
V g_heff_2eelab_2erules_2echeckSetting_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_247 = heff_env(self)[0];
  V v_goal_243 = heff_env(self)[1];
  V v_found_244 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_v_2410 = heff_env(self)[5];
  V v_w_242 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  V v_final_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2echeckSetting_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_247, 2)), 1, (V[]){v_t_2418}));
  V f_ = heff_dup(heff_rfield(v_p_247, 1));
  heff_room[0] = v_t_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2echeckSetting_lam3, 1, 11, (V[]){v_goal_243, v_found_244, v_x_249, v_e_240, v_v_2410, v_p_247, v_w_242, v_sp_241, v_p_248, v_final_245, v_x_2415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eworldOf_24cpr_str0, 5, "co.<:");

HeffT2 g_heff_2eelab_2erules_2eworldOf_24cpr(V v_t_240) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SDecode: {
    V v_t1_242 = heff_field(v_t_240, 0);
    switch (heff_tag_of(v_t1_242)) {
    case TAG_SLocal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SGlobal: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCode: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SApp: {
      V v_t11_246 = heff_field(v_t1_242, 0);
      V v_w_247 = heff_field(v_t1_242, 1);
      switch (heff_tag_of(v_t11_246)) {
      case TAG_SLocal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SGlobal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCode: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SApp: {
        V v_t111_2411 = heff_field(v_t11_246, 0);
        switch (heff_tag_of(v_t111_2411)) {
        case TAG_SLocal: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SGlobal: {
          V v_k_2414 = heff_field(v_t111_2411, 0);
          if (heff_strEq_c_lent(v_k_2414, ((V)&g_heff_2eelab_2erules_2eworldOf_24cpr_str0), 2)) {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_w_247)}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_SCode: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SApp: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLam: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SCons: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SProj: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_STag: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMatch: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SSpecialize: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SIs: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SOpaque: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SAbandon: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SRec: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SFix: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SImplicit: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SPrim: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SMetaApp: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitInt: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitString: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitBytes: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitRune: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFixed: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SLitFloat32: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t111_2411)}});
        }
      }
      case TAG_SLam: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SCons: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SProj: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_STag: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMatch: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SSpecialize: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SIs: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SOpaque: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SAbandon: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SRec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SFix: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SImplicit: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SPrim: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SMetaApp: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitInt: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitString: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitBytes: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitRune: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFixed: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_SLitFloat32: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t11_246)}});
      }
    }
    case TAG_SLam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SCons: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SProj: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_STag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMatch: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SSpecialize: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SIs: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SOpaque: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SAbandon: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SRec: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SFix: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SImplicit: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SPrim: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SMetaApp: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitString: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitBytes: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitRune: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_SLitFloat32: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t1_242)}});
    }
  }
  case TAG_SFunction: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SRecord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SSum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SIsTy: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SPrimArray: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_SFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceGo_str3, 1, "_");
V g_heff_2eelab_2erules_2eevidenceGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eevidenceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceGo_entry, 8, 0};

V g_heff_2eelab_2erules_2eevidenceGo(V v_sp_240, V v_x_241, V v_cand_242, V v_e_243, V v_m_244, V v_ty0_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam0, 1, 1, (V[]){v_ty0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam1, 1, 7, (V[]){v_sp_240, v_x_241, v_hd_246, v_k_247, v_e_243, v_cand_242, v_m_244})});
}
V g_heff_2eelab_2erules_2eevidenceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eevidenceGo(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2eevidenceGo_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_ty0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_ty0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eevidenceGo_lam3(V self, V *args) {
  V v_u_2429 = args[0];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  V v_x1_2430 = heff_tr(heff_call(heff_get_n(v_x_2424, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_Nom: {
    V v_x_2431 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    return v_x_2431;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2430, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2433 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    return v_x_2433;
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2eelab_2erules_2eevidenceGo_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_implicit_2418 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_cod_2417 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_implicit_2418)) {
  case TAG_Expl: {
    heff_drop(v_x_241);
    v_t_2425 = (g_heff_2eelab_2ememoed_2eapp(v_m_244, heff_dup(v_x_2424)));
    break;
  }
  case TAG_Impl: {
    v_t_2425 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2424)));
    break;
  }
  case TAG_Inst: {
    v_t_2425 = (g_heff_2eelab_2ememoed_2eiapp(v_x_241, v_m_244, heff_dup(v_x_2424)));
    break;
  }
  default: heff_nomatch(v_implicit_2418);
  }
  V v_x1_2435;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2427 = heff_field(v_cod_2417, 1);
    V v_body_2428 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2435 = heff_tr(heff_call(v_body_2428, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2427, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam3, 1, 1, (V[]){v_x_2424})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2434 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2424, 2);
    v_x1_2435 = v_body_2434;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2439;
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Nom: {
    V v_x_2436 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2436;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2435, 0ULL, 1);
    v_t_2439 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2438 = heff_field(v_x1_2435, 0);
    heff_take_n(v_x1_2435, 1ULL, 1);
    v_t_2439 = v_x_2438;
    break;
  }
  default: heff_nomatch(v_x1_2435);
  }
  V v_x_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_t_2439});
  V f_ = v_k_247;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eevidenceGo_lam5(V self, V *args) {
  V v_u_2458 = args[0];
  V v_x_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  V v_x1_2459 = heff_tr(heff_call(heff_get_n(v_x_2448, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2459)) {
  case TAG_Nom: {
    V v_x_2460 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    return v_x_2460;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2459, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2462 = heff_field(v_x1_2459, 0);
    heff_take_n(v_x1_2459, 1ULL, 1);
    return v_x_2462;
  }
  default: return heff_nomatch(v_x1_2459);
  }
}
V g_heff_2eelab_2erules_2eevidenceGo_lam4(V self, V *args) {
  V v_x_2448 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cand_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2453;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2449 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2453 = v_n_2449;
    break;
  }
  case TAG_CloConst: {
    v_t_2453 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str1);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2454 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2453, v_m_244, heff_dup(v_x_2448)));
  V v_x1_2464;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2456 = heff_field(v_cod_2417, 1);
    V v_body_2457 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2464 = heff_tr(heff_call(v_body_2457, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2456, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam5, 1, 1, (V[]){v_x_2448})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2463 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2448, 2);
    v_x1_2464 = v_body_2463;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2468;
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_Nom: {
    V v_x_2465 = heff_field(v_x1_2464, 0);
    heff_take_n(v_x1_2464, 1ULL, 1);
    v_t_2468 = v_x_2465;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2464, 0ULL, 1);
    v_t_2468 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2467 = heff_field(v_x1_2464, 0);
    heff_take_n(v_x1_2464, 1ULL, 1);
    v_t_2468 = v_x_2467;
    break;
  }
  default: heff_nomatch(v_x1_2464);
  }
  return (g_heff_2eelab_2erules_2eevidenceGo(v_sp_240, v_x_241, v_cand_242, v_e_243, v_t_2454, v_t_2468, v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2eevidenceGo_lam7(V self, V *args) {
  V v_u_2484 = args[0];
  V v_x_2474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2484);
  V v_x1_2485 = heff_tr(heff_call(heff_get_n(v_x_2474, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2485)) {
  case TAG_Nom: {
    V v_x_2486 = heff_field(v_x1_2485, 0);
    heff_take_n(v_x1_2485, 1ULL, 1);
    return v_x_2486;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2485, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2488 = heff_field(v_x1_2485, 0);
    heff_take_n(v_x1_2485, 1ULL, 1);
    return v_x_2488;
  }
  default: return heff_nomatch(v_x1_2485);
  }
}
V g_heff_2eelab_2erules_2eevidenceGo_lam6(V self, V *args) {
  V v_x_2474 = args[0];
  V v_cod_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cand_242 = heff_env(self)[4];
  V v_e_243 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2479;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_n_2475 = heff_dup(heff_field(v_cod_2417, 0));
    v_t_2479 = v_n_2475;
    break;
  }
  case TAG_CloConst: {
    v_t_2479 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str3);
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2480 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2479, v_m_244, heff_dup(v_x_2474)));
  V v_x1_2490;
  switch (heff_tag_of(v_cod_2417)) {
  case TAG_MkClo: {
    V v_vs_2482 = heff_field(v_cod_2417, 1);
    V v_body_2483 = heff_field(v_cod_2417, 2);
    heff_take_n(v_cod_2417, 6ULL, 3);
    v_x1_2490 = heff_tr(heff_call(v_body_2483, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2482, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam7, 1, 1, (V[]){v_x_2474})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2489 = heff_field(v_cod_2417, 0);
    heff_take_n(v_cod_2417, 1ULL, 1);
    heff_drop_rec(v_x_2474, 2);
    v_x1_2490 = v_body_2489;
    break;
  }
  default: heff_nomatch(v_cod_2417);
  }
  V v_t_2494;
  switch (heff_tag_of(v_x1_2490)) {
  case TAG_Nom: {
    V v_x_2491 = heff_field(v_x1_2490, 0);
    heff_take_n(v_x1_2490, 1ULL, 1);
    v_t_2494 = v_x_2491;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2490, 0ULL, 1);
    v_t_2494 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2493 = heff_field(v_x1_2490, 0);
    heff_take_n(v_x1_2490, 1ULL, 1);
    v_t_2494 = v_x_2493;
    break;
  }
  default: heff_nomatch(v_x1_2490);
  }
  return (g_heff_2eelab_2erules_2eevidenceGo(v_sp_240, v_x_241, v_cand_242, v_e_243, v_t_2480, v_t_2494, v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2eevidenceGo_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_e_243 = heff_env(self)[4];
  V v_cand_242 = heff_env(self)[5];
  V v_m_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFunction: {
    V v_dom_2416 = heff_field(v_t_2413, 1);
    V v_cod_2417 = heff_field(v_t_2413, 2);
    V v_implicit_2418 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_cod_2417)) {
    case TAG_MkClo: {
      V v_n_2419 = heff_dup(heff_field(v_cod_2417, 0));
      v_t_2423 = heff_bool(heff_strEq_c_lent(v_n_2419, v_x_241, 0));
      heff_drop(v_n_2419);
      break;
    }
    case TAG_CloConst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_cod_2417);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_t_2423);
      return (g_heff_2eelab_2erules_2eevidenceArg(v_e_243, v_sp_240, v_dom_2416, heff_dup(v_x_241), v_cand_242, v_hd_246, heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam2, 1, 5, (V[]){v_implicit_2418, v_m_244, v_x_241, v_cod_2417, v_k_247})));
    } else {
      heff_drop(v_t_2423);
      V v_t_2441;
      switch (heff_tag_of(v_implicit_2418)) {
      case TAG_Expl: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_Impl: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_Inst: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_implicit_2418);
      }
      if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
        heff_drop(v_implicit_2418);
        heff_drop(v_t_2441);
        V v_t_2446;
        switch (heff_tag_of(v_cod_2417)) {
        case TAG_MkClo: {
          V v_n_2442 = heff_dup(heff_field(v_cod_2417, 0));
          v_t_2446 = v_n_2442;
          break;
        }
        case TAG_CloConst: {
          v_t_2446 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str0);
          break;
        }
        default: heff_nomatch(v_cod_2417);
        }
        V v_c_2447 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_243), heff_dup(v_sp_240), v_x_2412, v_dom_2416, v_t_2446));
        V f_ = v_c_2447;
        heff_room[0] = heff_dup(v_hd_246);
        heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam4, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_cand_242, v_e_243, v_hd_246, v_k_247});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_x_2412);
        heff_drop(v_t_2441);
        switch (heff_tag_of(v_implicit_2418)) {
        case TAG_Expl: {
          heff_drop(v_e_243);
          heff_drop(v_cand_242);
          heff_drop(v_m_244);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
        case TAG_Impl: {
          heff_drop(v_e_243);
          heff_drop(v_cand_242);
          heff_drop(v_m_244);
          heff_drop(v_dom_2416);
          heff_drop(v_cod_2417);
          return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
        }
        case TAG_Inst: {
          V v_t_2473;
          switch (heff_tag_of(v_cod_2417)) {
          case TAG_MkClo: {
            V v_n_2469 = heff_dup(heff_field(v_cod_2417, 0));
            v_t_2473 = v_n_2469;
            break;
          }
          case TAG_CloConst: {
            v_t_2473 = ((V)&g_heff_2eelab_2erules_2eevidenceGo_str2);
            break;
          }
          default: heff_nomatch(v_cod_2417);
          }
          return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_243), heff_dup(v_sp_240), v_dom_2416, v_t_2473, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2eevidenceGo_lam6, 1, 8, (V[]){v_cod_2417, v_m_244, v_sp_240, v_x_241, v_cand_242, v_e_243, v_hd_246, v_k_247})));
        }
        default: return heff_nomatch(v_implicit_2418);
        }
      }
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_e_243);
    heff_drop(v_cand_242);
    heff_drop(v_m_244);
    return (g_heff_2eelab_2erules_2eevidenceGo_2enoArgNamed_240(v_sp_240, v_x_241, v_hd_246, v_k_247));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayChkOn_str0, 5, "delay");
HEFF_LIT(g_heff_2eelab_2erules_2edelayChkOn_str1, 21, " waits for its type \?");
V g_heff_2eelab_2erules_2edelayChkOn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayChkOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayChkOn_entry, 8, 0};

V g_heff_2eelab_2erules_2edelayChkOn(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_keyTy_244, V v_ty_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = heff_dup(v_ty_245); V a_3 = heff_dup(v_what_242); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam0, 1, 8, (V[]){v_e_240, v_sp_241, v_what_242, heff_dup(v_c_243), v_ty_245, v_hd_246, v_keyTy_244, v_k_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2edelayChkOn(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2edelayChkOn_lam2(V self, V *args) {
  V v_u_2454 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2454);
  V v_t_2455 = heff_get_n(v_x_2410, 0, 2);
  V v_t_2491;
  switch (heff_tag_of(v_t_2455)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2455, 0ULL, 3);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2480 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 3);
    v_t_2491 = v_k_2480;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2455);
  }
  V v_t_2492 = heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayChkOn_str1), heff_intShow(v_t_2491));
  return heff_strAppend(v_what_242, v_t_2492);
}
V g_heff_2eelab_2erules_2edelayChkOn_lam4(V self, V *args) {
  V v_u_2496 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2496);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2edelayChkOn_lam3(V self, V *args) {
  V v_x_2495 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2497 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam4, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_nf(v_x_2410, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2497;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edelayChkOn_lam1(V self, V *args) {
  V v_x_2453 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2453);
  V v_t_2493 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2edelayChkOn_str0), heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam2, 1, 2, (V[]){heff_dup(v_x_2410), v_what_242})}), NTAG(TAG_MkUnit)});
  V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2494;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam3, 1, 2, (V[]){v_x_2410, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2edelayChkOn_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_ty_245 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_keyTy_244 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = heff_dup(heff_rfield(v_x_2410, 0));
  V v_t_2447;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2411, 0ULL, 3);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2436 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 3);
    v_t_2447 = v_k_2436;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_chk_2448 = ({ V a_0 = v_e_240; V a_1 = heff_dup(v_sp_241); V a_2 = heff_dup(v_what_242); V a_3 = v_c_243; V a_4 = v_ty_245; V a_5 = v_t_2447; V a_6 = heff_dup(v_x_2410); V r_ = (g_heff_2eelab_2erules_2edelayedCheck(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_243); r_; });
  V v_t_2449 = heff_tr(heff_call(v_chk_2448, 2, (V[]){heff_dup(v_hd_246), heff_dup(heff_rfield(v_hd_246, 0))}));
  V v_t_2450 = heff_tag_n(TAG_Delay, 3, (V[]){v_keyTy_244, v_t_2449, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2451}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2452;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam1, 1, 5, (V[]){v_sp_241, v_x_2410, v_what_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimFloat_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimFloat_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimFloat_st;
static V g_heff_2eelab_2erules_2eprimFloat_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimFloat_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimFloat_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimFloat_st)) return g_heff_2eelab_2erules_2eprimFloat_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimFloat_val, &g_heff_2eelab_2erules_2eprimFloat_st, g_heff_2eelab_2erules_2eprimFloat_init);
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat32_str0, 70, " is out of range for Float32, whose greatest is 3.4028234663852886e+38");
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eatFloat32_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_lam2, 1, 0};
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eatFloat32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_entry, 3, 0};

V g_heff_2eelab_2erules_2eatFloat32(V v_sp_240, V v_text_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL)));
  V v_t_244 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL)));
  double v_y_245 = heff_from_int_f64(heff_intSub(v_t_243, v_t_244));
  V v_t_246 = heff_bool((v_y_245 <= heff_peek_f64(v_x_242)));
  if (((heff_dup(v_t_246) == NTAG(TAG_True)) || ({ V v_t_247 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL))); int c_ = ({ V v_t_248 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL))); int c_ = ({ double v_t_2421 = heff_from_int_f64(heff_intSub(heff_dup(v_t_247), heff_dup(v_t_248))); int c_ = (heff_peek_f64(v_x_242) <= v_t_2421); c_; }); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }))) {
    heff_drop(v_x_242);
    heff_drop(v_t_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam0, 2, 2, (V[]){v_text_241, v_sp_240});
  } else {
    heff_drop(v_sp_240);
    heff_drop(v_text_241);
    heff_drop(v_t_246);
    return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam1, 2, 1, (V[]){v_x_242});
  }
}
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eatFloat32(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_text_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2411 = heff_take_field(v_hd_249, 1);
  V v_malg_2412 = heff_get_n(v_hd_249, 2, 3);
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), heff_strAppend(v_text_241, ((V)&g_heff_2eelab_2erules_2eatFloat32_str0)), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(v_malg_2412, 1, (V[]){v_t_2415}));
  V f_ = v_bind_2411;
  args[0] = v_t_2416;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args) {
  V v_u_2419 = args[0];
  heff_drop(v_u_2419);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V v_t_2420 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_242))}), ((V)&g_heff_2eelab_2erules_2eatFloat32_lam2_clo)});
  V f_ = v_k_2418;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eformGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_lam0, 2, 0};
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eformGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eformGo(V v_e_27_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_27_240, 6);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2erules_2eformGo_lam0_clo);
  }
  case TAG_Cons: {
    V v_fd_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_typ_248 = heff_take_field(v_fd_246, 1);
    V v_dflt_249 = heff_take_field(v_fd_246, 2);
    V v_name_2410 = heff_get_n(v_fd_246, 0, 3);
    V v_c_2412;
    switch (heff_tag_of(v_typ_248)) {
    case TAG_MkTyp: {
      V v_f_2411 = heff_field(v_typ_248, 0);
      heff_take_n(v_typ_248, 1ULL, 1);
      v_c_2412 = heff_tr(heff_call(v_f_2411, 1, (V[]){heff_dup(v_e_27_240)}));
      break;
    }
    default: heff_nomatch(v_typ_248);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam1, 2, 6, (V[]){v_c_2412, v_e_27_240, v_i_241, v_dflt_249, v_name_2410, v_rest_247});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eformGo(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(4, shape_level__fields__defaults__large, (V[]){NTAG(TAG_Small), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_name_2410 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_e_27_240 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_level_2427 = heff_take_field(v_x_2426, 0);
  V v_fields_2428 = heff_take_field(v_x_2426, 1);
  V v_defaults_2429 = heff_take_field(v_x_2426, 2);
  V v_large_2430 = heff_get_n(v_x_2426, 3, 4);
  V v_l1_2431 = v_level_2427;
  V v_x1_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2415, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_l2_2436;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_Nom: {
    V v_t_2433 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_l2_2436 = ({ V a_0 = v_t_2433; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2433); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2434 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_l2_2436 = ({ V a_0 = v_t_2434; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2434); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2435 = heff_field(v_x1_2432, 0);
    heff_take_n(v_x1_2432, 1ULL, 1);
    v_l2_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2435); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V v_t_2437;
  switch (heff_tag_of(v_l1_2431)) {
  case TAG_Small: {
    v_t_2437 = v_l2_2436;
    break;
  }
  case TAG_Large: {
    switch (heff_tag_of(v_l2_2436)) {
    case TAG_Small: {
      v_t_2437 = v_l1_2431;
      break;
    }
    case TAG_Large: {
      v_t_2437 = v_l2_2436;
      break;
    }
    case TAG_TopL: {
      v_t_2437 = v_l2_2436;
      break;
    }
    default: heff_nomatch(v_l2_2436);
    }
    break;
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_l2_2436)) {
    case TAG_Small: {
      v_t_2437 = v_l1_2431;
      break;
    }
    case TAG_Large: {
      v_t_2437 = v_l1_2431;
      break;
    }
    case TAG_TopL: {
      v_t_2437 = v_l2_2436;
      break;
    }
    default: heff_nomatch(v_l2_2436);
    }
    break;
  }
  default: heff_nomatch(v_l1_2431);
  }
  V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_name_2410), heff_dup(heff_rfield(v_x_2415, 0))});
  V v_ds_2439 = v_defaults_2429;
  V v_t_2441;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    v_t_2441 = v_ds_2439;
    break;
  }
  case TAG_Just: {
    V v_d_2440 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_name_2410), v_d_2440}), v_ds_2439});
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V v_t_2442 = (g_heff_2eelab_2erules_2elargeField(v_e_27_240, v_name_2410, v_x_2415, v_large_2430));
  V v_x_2443 = heff_rec_n(4, shape_level__fields__defaults__large, (V[]){v_t_2437, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_fields_2428}), v_t_2441, v_t_2442});
  V f_ = v_k_2414;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_name_2410 = heff_env(self)[1];
  V v_e_27_240 = heff_env(self)[2];
  V v_i_241 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2415, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2422;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_Nom: {
    V v_x_2419 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2419;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2418, 0ULL, 1);
    v_t_2422 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2421 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    v_t_2422 = v_x_2421;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_sc_2423 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_name_2410), v_t_2422, heff_dup(heff_rfield(v_e_27_240, 0))));
  V v_t_2424 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2423, heff_dup(heff_rfield(v_e_27_240, 1)), heff_dup(heff_rfield(v_e_27_240, 2)), heff_dup(heff_rfield(v_e_27_240, 3)), heff_dup(heff_rfield(v_e_27_240, 4)), heff_dup(heff_rfield(v_e_27_240, 5))});
  V v_c_2425 = (g_heff_2eelab_2erules_2eformGo(v_t_2424, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_247));
  V f_ = v_c_2425;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam4, 1, 5, (V[]){v_x_2415, v_name_2410, v_x_2417, v_e_27_240, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_27_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_dflt_249 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_name_2410 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2416 = (g_heff_2eelab_2erules_2edefaultAt(heff_dup(v_e_27_240), heff_dup(v_i_241), heff_dup(v_x_2415), v_dflt_249));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam3, 1, 7, (V[]){v_x_2415, v_name_2410, v_e_27_240, v_i_241, v_rest_247, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_e_27_240 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  V v_dflt_249 = heff_env(self)[3];
  V v_name_2410 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam2, 1, 7, (V[]){v_e_27_240, v_i_241, v_dflt_249, v_hd_2413, v_name_2410, v_rest_247, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eadvanceSelf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eadvanceSelf_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2eadvanceSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eadvanceSelf_entry, 4, 0};

V g_heff_2eelab_2erules_2eadvanceSelf(V v_gk_240, V v_a_241, V v_fieldTypes_242, V v_done_243) {
top: ;
  V v_keys_244 = heff_take_field(v_fieldTypes_242, 0);
  V v_byName_245 = heff_get_n(v_fieldTypes_242, 1, 3);
  V v_xs_246 = heff_dup(v_keys_244);
  V v_t_2415 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_246, 0), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam0, 1, 4, (V[]){v_xs_246, v_done_243, heff_dup(v_gk_240), heff_dup(v_a_241)}));
  V v_t_2416 = heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_244, v_byName_245, v_t_2415});
  V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_VCons, 1, (V[]){v_t_2416})});
  HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam2, 1, 1, (V[]){v_a_241}), v_t_2417);
}
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eadvanceSelf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam1(V self, V *args) {
  V v_u_2413 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_a_241;
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam0(V self, V *args) {
  V v_i_247 = args[0];
  V v_xs_246 = heff_env(self)[0];
  V v_done_243 = heff_env(self)[1];
  V v_gk_240 = heff_env(self)[2];
  V v_a_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_f_248 = heff_arrayIndex(v_xs_246, v_i_247);
  HeffT2 v_t_249 = (g_heff_2eelab_2erules_2elookupP_24cpr(v_done_243, v_f_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_gk_240);
      heff_drop(v_a_241);
      heff_drop(v_f_248);
      V v_v_2412 = v_field_2411;
      return heff_tag_n(TAG_Nom, 1, (V[]){v_v_2412});
    } else {
      heff_drop(v_field_2411);
      V v_t_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam1, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)));
      return ({ V a_0 = v_t_2414; V a_1 = v_f_248; V r_ = (g_heff_2eelab_2evalue_2eproj(a_0, a_1)); heff_drop(v_f_248); r_; });
    }
  }
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam2(V self, V *args) {
  V v_u_2418 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2418);
  return v_a_241;
}
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str0, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str2, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str3, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str4, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str5, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str6, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str7, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str8, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str9, 3, "tag");
HEFF_LIT(g_heff_2eelab_2erules_2etagChk_str10, 3, "tag");
V g_heff_2eelab_2erules_2etagChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etagChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etagChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagChk_entry, 5, 0};

V g_heff_2eelab_2erules_2etagChk(V v_wait_240, V v_sp_241, V v_tsp_242, V v_x_243, V v_cs_244) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam0, 4, 5, (V[]){heff_dup(v_wait_240), v_sp_241, v_tsp_242, v_x_243, v_cs_244})});
}
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2etagChk(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2etagChk_lam1(V self, V *args) {
  V v_c_249 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_249, 3, 8); V a_1 = v_a0_246; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2etagChk_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_wait_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_tsp_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_cs_244 = heff_env(self)[4];
  V v_e_245 = heff_env(self)[5];
  V v_hd_247 = heff_env(self)[6];
  V v_k_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2413)));
  switch (heff_tag_of(v_t_2414)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2414, 0ULL, 1);
    V v_t_2438;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2417 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_2417)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2417, 0ULL, 1);
          v_t_2438 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2417, 0ULL, 1);
          v_t_2438 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_2417, 0ULL, 1);
          v_t_2438 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_2438 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_2417);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_2438 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_2438 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
      heff_drop(v_t_2438);
      V v_c_2439 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str0); V a_3 = v_c_2439; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2439); r_; });
    } else {
      heff_drop(v_t_2438);
      HeffT1 v_t_2440 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_2441 = v_t_2440.f[0];
        V v_f_2442 = v_field_2441;
        V f_ = v_f_2442;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeFunction: {
    V v_dom_2444 = heff_field(v_t_2414, 1);
    V v_implicit_2446 = heff_field(v_t_2414, 3);
    heff_take_n(v_t_2414, 10ULL, 4);
    heff_drop(v_wait_240);
    switch (heff_tag_of(v_implicit_2446)) {
    case TAG_Expl: {
      V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_e_245, 0)), 0, 4);
      V v_t_2448 = (g_heff_2eelab_2erules_2eetaArg(heff_dup(v_tsp_242), v_t_2447, v_dom_2444));
      V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
      V v_t_2450 = (g_heff_2eelab_2erules_2eappendP(v_cs_244, v_t_2449));
      V v_t_2451 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_t_2450; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      HeffT1 v_t_2452 = ({ V a_0 = v_sp_241; V a_1 = ((V)&g_heff_2eelab_2erules_2etagChk_str1); V a_2 = v_t_2451; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionIntro_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2451); r_; });
      {
        V v_field_2453 = v_t_2452.f[0];
        V v_f_2454 = v_field_2453;
        V f_ = v_f_2454;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
    case TAG_Impl: {
      heff_drop(v_dom_2444);
      HeffT1 v_t_2455 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_2456 = v_t_2455.f[0];
        V v_f_2457 = v_field_2456;
        V f_ = v_f_2457;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
    case TAG_Inst: {
      heff_drop(v_dom_2444);
      HeffT1 v_t_2458 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_2459 = v_t_2458.f[0];
        V v_f_2460 = v_field_2459;
        V f_ = v_f_2460;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
    default: return heff_nomatch(v_implicit_2446);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2414, 0ULL, 3);
    V v_t_2486;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2465 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_2465)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2465, 0ULL, 1);
          v_t_2486 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2465, 0ULL, 1);
          v_t_2486 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_2465, 0ULL, 1);
          v_t_2486 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_2486 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_2465);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_2486 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_2486 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
      heff_drop(v_t_2486);
      V v_c_2487 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str2); V a_3 = v_c_2487; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2487); r_; });
    } else {
      heff_drop(v_t_2486);
      HeffT1 v_t_2488 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_2489 = v_t_2488.f[0];
        V v_f_2490 = v_field_2489;
        V f_ = v_f_2490;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2414, 0ULL, 1);
    V v_t_24114;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_2493 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_2493)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_2493, 0ULL, 1);
          v_t_24114 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_2493, 0ULL, 1);
          v_t_24114 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_2493, 0ULL, 1);
          v_t_24114 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24114 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_2493);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24114 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24114 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24114) == NTAG(TAG_True))) {
      heff_drop(v_t_24114);
      V v_c_24115 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str3); V a_3 = v_c_24115; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24115); r_; });
    } else {
      heff_drop(v_t_24114);
      HeffT1 v_t_24116 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24117 = v_t_24116.f[0];
        V v_f_24118 = v_field_24117;
        V f_ = v_f_24118;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeInt: {
    V v_t_24141;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24120 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_24120)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24120, 0ULL, 1);
          v_t_24141 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24120, 0ULL, 1);
          v_t_24141 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_24120, 0ULL, 1);
          v_t_24141 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24141 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_24120);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24141 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24141 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24141) == NTAG(TAG_True))) {
      heff_drop(v_t_24141);
      V v_c_24142 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str4); V a_3 = v_c_24142; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24142); r_; });
    } else {
      heff_drop(v_t_24141);
      HeffT1 v_t_24143 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24144 = v_t_24143.f[0];
        V v_f_24145 = v_field_24144;
        V f_ = v_f_24145;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeFloat: {
    V v_t_24168;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24147 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_24147)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24147, 0ULL, 1);
          v_t_24168 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24147, 0ULL, 1);
          v_t_24168 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_24147, 0ULL, 1);
          v_t_24168 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24168 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_24147);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24168 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24168 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24168) == NTAG(TAG_True))) {
      heff_drop(v_t_24168);
      V v_c_24169 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str5); V a_3 = v_c_24169; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24169); r_; });
    } else {
      heff_drop(v_t_24168);
      HeffT1 v_t_24170 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24171 = v_t_24170.f[0];
        V v_f_24172 = v_field_24171;
        V f_ = v_f_24172;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeString: {
    V v_t_24195;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24174 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_24174)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24174, 0ULL, 1);
          v_t_24195 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24174, 0ULL, 1);
          v_t_24195 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_24174, 0ULL, 1);
          v_t_24195 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24195 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_24174);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24195 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24195 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24195) == NTAG(TAG_True))) {
      heff_drop(v_t_24195);
      V v_c_24196 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str6); V a_3 = v_c_24196; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24196); r_; });
    } else {
      heff_drop(v_t_24195);
      HeffT1 v_t_24197 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24198 = v_t_24197.f[0];
        V v_f_24199 = v_field_24198;
        V f_ = v_f_24199;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeRune: {
    V v_t_24222;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24201 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_24201)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24201, 0ULL, 1);
          v_t_24222 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24201, 0ULL, 1);
          v_t_24222 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_24201, 0ULL, 1);
          v_t_24222 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24222 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_24201);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24222 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24222 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24222) == NTAG(TAG_True))) {
      heff_drop(v_t_24222);
      V v_c_24223 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str7); V a_3 = v_c_24223; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24223); r_; });
    } else {
      heff_drop(v_t_24222);
      HeffT1 v_t_24224 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24225 = v_t_24224.f[0];
        V v_f_24226 = v_field_24225;
        V f_ = v_f_24226;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2414, 0ULL, 1);
    V v_t_24250;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24229 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_24229)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24229, 0ULL, 1);
          v_t_24250 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24229, 0ULL, 1);
          v_t_24250 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_24229, 0ULL, 1);
          v_t_24250 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24250 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_24229);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24250 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24250 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24250) == NTAG(TAG_True))) {
      heff_drop(v_t_24250);
      V v_c_24251 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str8); V a_3 = v_c_24251; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24251); r_; });
    } else {
      heff_drop(v_t_24250);
      HeffT1 v_t_24252 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24253 = v_t_24252.f[0];
        V v_f_24254 = v_field_24253;
        V f_ = v_f_24254;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2414, 0ULL, 1);
    V v_t_24278;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24257 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_24257)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24257, 0ULL, 1);
          v_t_24278 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24257, 0ULL, 1);
          v_t_24278 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_24257, 0ULL, 1);
          v_t_24278 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24278 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_24257);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24278 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24278 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24278) == NTAG(TAG_True))) {
      heff_drop(v_t_24278);
      V v_c_24279 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str9); V a_3 = v_c_24279; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24279); r_; });
    } else {
      heff_drop(v_t_24278);
      HeffT1 v_t_24280 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24281 = v_t_24280.f[0];
        V v_f_24282 = v_field_24281;
        V f_ = v_f_24282;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_NoRules: {
    V v_t_24305;
    if ((heff_dup(v_wait_240) == NTAG(TAG_True))) {
      heff_drop(v_wait_240);
      switch (heff_tag_of(v_x_2413)) {
      case TAG_VU: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VDecode: {
        V v_t1_24284 = heff_dup(heff_field(v_x_2413, 0));
        switch (heff_tag_of(v_t1_24284)) {
        case TAG_HLocal: {
          heff_take_n(v_t1_24284, 0ULL, 1);
          v_t_24305 = NTAG(TAG_False);
          break;
        }
        case TAG_HGlobal: {
          heff_take_n(v_t1_24284, 0ULL, 1);
          v_t_24305 = NTAG(TAG_False);
          break;
        }
        case TAG_HMeta: {
          heff_take_n(v_t1_24284, 0ULL, 1);
          v_t_24305 = NTAG(TAG_True);
          break;
        }
        case TAG_HError: {
          v_t_24305 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t1_24284);
        }
        break;
      }
      case TAG_VFunction: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VRecord: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VSum: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimString: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      case TAG_VFixed: {
        v_t_24305 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
    } else {
      heff_drop(v_wait_240);
      v_t_24305 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24305) == NTAG(TAG_True))) {
      heff_drop(v_t_24305);
      V v_c_24306 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_tsp_242; V a_3 = v_x_243; V a_4 = v_cs_244; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      return ({ V a_0 = v_e_245; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2etagChk_str10); V a_3 = v_c_24306; V a_4 = heff_dup(v_x_2413); V a_5 = v_x_2413; V a_6 = v_hd_247; V a_7 = v_k_248; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_24306); r_; });
    } else {
      heff_drop(v_t_24305);
      HeffT1 v_t_24307 = (g_heff_2eelab_2erules_2esumIntroNow_24cpr(v_sp_241, v_tsp_242, v_x_243, v_cs_244));
      {
        V v_field_24308 = v_t_24307.f[0];
        V v_f_24309 = v_field_24308;
        V f_ = v_f_24309;
        heff_room[0] = v_e_245;
        heff_room[1] = v_x_2413;
        heff_room[2] = v_hd_247;
        heff_room[3] = v_k_248;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2eelab_2erules_2etagChk_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_a0_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V v_wait_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_tsp_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_cs_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam1, 1, 1, (V[]){v_a0_246})})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_t_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etagChk_lam2, 1, 8, (V[]){v_wait_240, v_sp_241, v_tsp_242, v_x_243, v_cs_244, v_e_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordTagIn_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam1, 2, 0};
Clo g_heff_2eelab_2erules_2erecordTagIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_entry, 5, 0};

V g_heff_2eelab_2erules_2erecordTagIn(V v_e_240, V v_a_241, V v_vs_242, V v_x_243, V v_tsp_244) {
top: ;
  V v_byName_245 = heff_take_field(v_vs_242, 1);
  V v_values_246 = heff_get_n(v_vs_242, 2, 3);
  HeffT2 v_t_247 = ({ V a_0 = v_byName_245; V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_byName_245); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_i_2410 = v_field_249;
      V v_xs_2411 = v_values_246;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2410, 1) && heff_intLt_c(heff_dup(v_i_2410), heff_arrayLength_lent(v_xs_2411, 0)))) {
        V v_x_2412 = heff_arrayIndex(v_xs_2411, v_i_2410);
        heff_drop(v_x_2412);
        return heff_tail(((V)&g_heff_2eelab_2erules_2erecordName_clo), 5, (V[]){v_e_240, heff_dup(v_a_241), v_x_243, v_tsp_244, v_a_241});
      } else {
        heff_drop(v_e_240);
        heff_drop(v_a_241);
        heff_drop(v_x_243);
        heff_drop(v_tsp_244);
        heff_drop(v_i_2410);
        heff_drop(v_xs_2411);
        return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam0_clo);
      }
    } else {
      heff_drop(v_e_240);
      heff_drop(v_a_241);
      heff_drop(v_x_243);
      heff_drop(v_tsp_244);
      heff_drop(v_values_246);
      heff_drop(v_field_249);
      return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam1_clo);
    }
  }
}
V g_heff_2eelab_2erules_2erecordTagIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordTagIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseLet_entry, 3, 0};

V g_heff_2eelab_2erules_2ecaseLet(V v_x_240, V v_scrutSyn_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam0, 2, 3, (V[]){heff_dup(v_scrutSyn_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2ecaseLet(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args) {
  V v_c_2412 = args[0];
  V v_a0_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2412, 3, 8); V a_1 = v_a0_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args) {
  V v_v_2417 = args[0];
  V v_scope_27_2418 = args[1];
  V v_body_242 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2417);
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2419 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2420 = ({ V rv_0 = v_scope_27_2418; V rr_ = heff_rec_reuse_nf(v_e_243, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2419;
    args[0] = v_t_2420;
    args[1] = v_b_244;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2416});
}
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args) {
  V v_u_2434 = args[0];
  V v_b_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_244});
}
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  V v_x_240 = heff_env(self)[3];
  V v_scrut_2410 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_take_field(v_e_243, 2);
  V v_t_2426;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_ForNominative: {
    v_t_2426 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2423, 0ULL, 2);
    v_t_2426 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2429 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2428, heff_dup(v_x_2416)));
  V v_dom_2431 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2429, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam7, 1, 1, (V[]){v_x_2416})});
  V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2433 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2432, MK_INT(1LL)), heff_dup(v_b_244)));
  V v_cod_2435 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2433, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam8, 1, 1, (V[]){v_b_244})})});
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2437 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_243, 1)), v_t_2436, v_dom_2431, v_cod_2435));
  V v_t_2438 = (g_heff_2eelab_2ememoed_2elam(v_t_2426, heff_get_n(v_e_243, 1, 6), v_t_2427, v_t_2437, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, v_x_2422})));
  V v_x_2439 = (g_heff_2eelab_2ememoed_2eapp(v_t_2438, v_scrut_2410));
  V f_ = v_k_248;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_b_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_scrut_2410 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2421 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), heff_dup(v_x_2416), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam5, 2, 3, (V[]){v_body_242, heff_dup(v_e_243), heff_dup(v_b_244)})));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam6, 1, 6, (V[]){v_e_243, v_x_2416, v_b_244, v_x_240, v_scrut_2410, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_scrut_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam3, 1, 1, (V[]){v_a0_2411})})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2414}));
    V f_ = heff_dup(heff_rfield(v_hd_247, 1));
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam4, 1, 7, (V[]){v_x_240, v_e_243, v_body_242, v_b_244, v_hd_247, v_scrut_2410, v_k_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam2, 1, 6, (V[]){v_hd_247, v_x_240, v_e_243, v_body_242, v_b_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_b_244 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246;
  switch (heff_tag_of(v_scrutSyn_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_scrutSyn_241, 0);
    heff_take_n(v_scrutSyn_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_scrutSyn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam1, 2, 5, (V[]){v_c_246, v_x_240, v_e_243, v_body_242, v_b_244});
}
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str0, 13, "` is defined ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str1, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str2, 5, "uses ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str3, 26, ", which does not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str4, 17, "no such variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str5, 9, " in scope");
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str6, 9, "variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efind_24cpr_str7, 162, " is the definition being elaborated: it is in hand only under a lambda, where a type is expected of it (an argument, a branch, the result -- not a case scrutinee)");
V g_heff_2eelab_2erules_2efind_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efind_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efind_24cpr(V v_sp_240, V v_x_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam0, 1, 2, (V[]){v_x_241, v_sp_240})}});
}
V g_heff_2eelab_2erules_2efind_24cpr_lam1(V self, V *args) {
  V v_k_2415 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_get_n(heff_get_n(v_e_242, 1, 6), 5, 8);
  HeffT2 v_t_2417 = ({ V a_0 = v_t_2416; V a_1 = v_k_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2416); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      heff_drop(v_k_2415);
      V v_place_2420 = v_field_2419;
      return v_place_2420;
    } else {
      heff_drop(v_field_2419);
      return v_k_2415;
    }
  }
}
V g_heff_2eelab_2erules_2efind_24cpr_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_msg_2424 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2427 = heff_take_field(v_hd_2425, 1);
  V v_malg_2428 = heff_get_n(v_hd_2425, 2, 3);
  V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(330LL), NTAG(TAG_SError), v_msg_2424, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(v_malg_2428, 1, (V[]){v_t_2431}));
  V f_ = v_bind_2427;
  args[0] = v_t_2432;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam4(V self, V *args) {
  V v_mc_2445 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_type_5f_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_242; V a_1 = v_mc_2445; V a_2 = v_type_5f_2439; V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2445); r_; });
}
V g_heff_2eelab_2erules_2efind_24cpr_lam6(V self, V *args) {
  V v_u_2450 = args[0];
  V v_value_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2450);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_value_2440});
}
V g_heff_2eelab_2erules_2efind_24cpr_lam5(V self, V *args) {
  V v_x_2449 = args[0];
  V v_key_2437 = heff_env(self)[0];
  V v_value_2440 = heff_env(self)[1];
  V v_k_2442 = heff_env(self)[2];
  V v_type_5f_2439 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2449);
  V v_t_2451 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_key_2437}), heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam6, 1, 1, (V[]){v_value_2440})});
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2451, v_type_5f_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam3(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_key_2437 = heff_env(self)[2];
  V v_e_242 = heff_env(self)[3];
  V v_type_5f_2439 = heff_env(self)[4];
  V v_value_2440 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_bind_2443 = heff_take_field(v_hd_2441, 1);
  V v_malg_2444 = heff_get_n(v_hd_2441, 2, 3);
  V v_t_2446 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_key_2437)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam4, 1, 2, (V[]){v_e_242, heff_dup(v_type_5f_2439)})});
  V v_t_2447 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tr(heff_call(v_malg_2444, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
  V f_ = v_bind_2443;
  args[0] = v_t_2448;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam5, 1, 4, (V[]){v_key_2437, v_value_2440, v_k_2442, v_type_5f_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam7(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2455 = heff_take_field(v_hd_2453, 1);
  V v_malg_2456 = heff_get_n(v_hd_2453, 2, 3);
  V v_t_2457 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_24cpr_str2), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_24cpr_str3)));
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_t_2457, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(v_malg_2456, 1, (V[]){v_t_2460}));
  V f_ = v_bind_2455;
  args[0] = v_t_2461;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam8(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2464 = heff_take_field(v_hd_2462, 1);
  V v_malg_2465 = heff_get_n(v_hd_2462, 2, 3);
  V v_t_2466 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_24cpr_str4), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_24cpr_str5)));
  V v_t_2467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2466, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tr(heff_call(v_malg_2465, 1, (V[]){v_t_2469}));
  V f_ = v_bind_2464;
  args[0] = v_t_2470;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam9(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k2_2472 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2473 = heff_take_field(v_hd_2471, 1);
  V v_malg_2474 = heff_get_n(v_hd_2471, 2, 3);
  V v_t_2475 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_24cpr_str6), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2efind_24cpr_str7)));
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(319LL), NTAG(TAG_SError), v_t_2475, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_call(v_malg_2474, 1, (V[]){v_t_2478}));
  V f_ = v_bind_2473;
  args[0] = v_t_2479;
  args[1] = v_k2_2472;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam10(V self, V *args) {
  V v_mc_2490 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_ty_2482 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_242; V a_1 = v_mc_2490; V a_2 = v_ty_2482; V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2490); r_; });
}
V g_heff_2eelab_2erules_2efind_24cpr_lam12(V self, V *args) {
  V v_x_2498 = args[0];
  V v_k_2493 = heff_env(self)[0];
  V v_m_2481 = heff_env(self)[1];
  V v_ty_2482 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2498);
  V f_ = v_k_2493;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2481, v_ty_2482});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam11(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_i_2491 = heff_env(self)[0];
  V v_m_2481 = heff_env(self)[1];
  V v_ty_2482 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2494 = heff_take_field(v_hd_2492, 1);
  V v_malg_2495 = heff_get_n(v_hd_2492, 2, 3);
  V v_t_2496 = heff_tag_n(TAG_Record, 2, (V[]){v_i_2491, NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tr(heff_call(v_malg_2495, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})}));
  V f_ = v_bind_2494;
  args[0] = v_t_2497;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam12, 1, 3, (V[]){v_k_2493, v_m_2481, v_ty_2482});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efind_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 1, 4);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 3, 4);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 2, 4);
  HeffT2 v_t_246 = ({ V a_0 = v_x_241; V a_1 = v_t_243; V a_2 = v_t_244; V a_3 = v_t_245; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); HeffT2 r_ = (g_heff_2eelab_2erules_2evarGo_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_244); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_it1_249 = v_field_248;
      switch (heff_tag_of(v_it1_249)) {
      case TAG_NotInScope: {
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 4, 8);
        HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2410); r_; });
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_ks_2414 = v_field_2413;
            V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam1, 1, 1, (V[]){v_e_242}), v_ks_2414));
            V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2erules_2eplacesSaid(a_0)); heff_drop(v_t_2421); r_; });
            V v_t_2423 = heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_24cpr_str0), v_t_2422));
            V v_msg_2424 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efind_24cpr_str1), v_t_2423);
            return heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam2, 2, 2, (V[]){v_msg_2424, v_sp_240});
          } else {
            heff_drop(v_field_2413);
            HeffT2 v_t_2433 = (g_heff_2eelab_2eglobals_2elookupKey_24cpr(heff_dup(heff_rfield(v_e_242, 1)), heff_dup(v_x_241)));
            {
              V v_field_2435 = v_t_2433.f[1];
              int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
              if ((v_tag_2434 == ((int64_t)0ULL))) {
                V v_it1_2436 = v_field_2435;
                switch (heff_tag_of(v_it1_2436)) {
                case TAG_MkPair: {
                  V v_key_2437 = heff_field(v_it1_2436, 0);
                  V v_ge_2438 = heff_field(v_it1_2436, 1);
                  heff_take_n(v_it1_2436, 3ULL, 2);
                  V v_type_5f_2439 = heff_take_field(v_ge_2438, 3);
                  V v_value_2440 = heff_get_n(v_ge_2438, 2, 4);
                  return heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam3, 2, 6, (V[]){v_sp_240, v_x_241, v_key_2437, v_e_242, v_type_5f_2439, v_value_2440});
                }
                default: return heff_nomatch(v_it1_2436);
                }
              } else {
                heff_drop(v_field_2435);
                V v_t_2452 = (g_heff_2eelab_2eglobals_2eisBroken(heff_get_n(v_e_242, 1, 6), v_x_241));
                if ((heff_dup(v_t_2452) == NTAG(TAG_True))) {
                  heff_drop(v_t_2452);
                  return heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam7, 2, 2, (V[]){v_x_241, v_sp_240});
                } else {
                  heff_drop(v_t_2452);
                  return heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam8, 2, 2, (V[]){v_x_241, v_sp_240});
                }
              }
            }
          }
        }
      }
      case TAG_Delayed2: {
        heff_drop_rec(v_e_242, 6);
        return heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam9, 2, 2, (V[]){v_x_241, v_sp_240});
      }
      default: return heff_nomatch(v_it1_249);
      }
    } else {
      V v_it1_2480 = v_field_248;
      switch (heff_tag_of(v_it1_2480)) {
      case TAG_MkPair: {
        V v_m_2481 = heff_field(v_it1_2480, 0);
        V v_ty_2482 = heff_field(v_it1_2480, 1);
        heff_take_n(v_it1_2480, 3ULL, 2);
        V v_t_2483 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 1, 4);
        HeffT2 v_t_2484 = (g_heff_2eelab_2erules_2eindexOfName_24cpr(v_t_2483, v_x_241, MK_INT(0LL)));
        V v_t_2489;
        {
          V v_field_2486 = v_t_2484.f[1];
          int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
          if ((v_tag_2485 == ((int64_t)0ULL))) {
            V v_i_2487 = v_field_2486;
            V v_t_2488 = heff_get_n(heff_dup(heff_rfield(v_e_242, 0)), 0, 4);
            if (heff_intEq_c(v_i_2487, heff_intSub(v_t_2488, MK_INT(1LL)))) {
              v_t_2489 = heff_dup(heff_rfield(v_e_242, 4));
            } else {
              v_t_2489 = NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_field_2486);
            v_t_2489 = NTAG(TAG_Nothing);
          }
        }
        V v_i_2491 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, v_x_241, v_t_2489, NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam10, 1, 2, (V[]){v_e_242, heff_dup(v_ty_2482)})});
        return heff_clo_n(g_heff_2eelab_2erules_2efind_24cpr_lam11, 2, 3, (V[]){v_i_2491, v_m_2481, v_ty_2482});
      }
      default: return heff_nomatch(v_it1_2480);
      }
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str0, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str1, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str2, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str3, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str4, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str5, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str6, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str7, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str8, 12, "prelude.Pair");
HEFF_LIT(g_heff_2eelab_2erules_2etupleChk_str9, 12, "prelude.Pair");
V g_heff_2eelab_2erules_2etupleChk_lam1(V self, V *args);
V g_heff_2eelab_2erules_2etupleChk_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etupleChk_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etupleChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etupleChk_entry, 4, 0};

V g_heff_2eelab_2erules_2etupleChk(V v_sp_240, V v_t_241, V v_parts_242, V v_v_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleChk_lam0, 4, 4, (V[]){v_sp_240, heff_dup(v_t_241), heff_dup(v_parts_242), heff_dup(v_v_243)})});
}
V g_heff_2eelab_2erules_2etupleChk_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2etupleChk(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2etupleChk_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2etupleChk_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_parts_242 = heff_env(self)[5];
  V v_v_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_parts_242);
    heff_drop(v_v_243);
    HeffT1 v_t_2415 = ({ V a_0 = v_sp_240; V a_1 = v_t_241; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_241); r_; });
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_f_2417 = v_field_2416;
      V f_ = v_f_2417;
      heff_room[0] = v_e_244;
      heff_room[1] = v_x_2412;
      heff_room[2] = v_hd_246;
      heff_room[3] = v_k_247;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop(v_t_241);
    V v_t_2444;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_2423 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_2423)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_2423, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_2429 = heff_field(v_x11_2423, 0);
        heff_take_n(v_x11_2423, 1ULL, 1);
        v_t_2444 = heff_bool(heff_strEq_c_lent(v_k_2429, ((V)&g_heff_2eelab_2erules_2etupleChk_str0), 2));
        heff_drop(v_k_2429);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_2423, 0ULL, 1);
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2444 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2423);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_2444);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_2445 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_2445;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_2444);
      HeffT1 v_t_2446 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_2447 = v_t_2446.f[0];
        V v_f_2448 = v_field_2447;
        V f_ = v_f_2448;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_t_241);
    V v_t_2474;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_2453 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_2453)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_2453, 0ULL, 1);
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_2459 = heff_field(v_x11_2453, 0);
        heff_take_n(v_x11_2453, 1ULL, 1);
        v_t_2474 = heff_bool(heff_strEq_c_lent(v_k_2459, ((V)&g_heff_2eelab_2erules_2etupleChk_str1), 2));
        heff_drop(v_k_2459);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_2453, 0ULL, 1);
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2474 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2453);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2474 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_2474);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_2475 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_2475;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_2474);
      HeffT1 v_t_2476 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_2477 = v_t_2476.f[0];
        V v_f_2478 = v_field_2477;
        V f_ = v_f_2478;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_t_241);
    V v_t_24102;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_2481 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_2481)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_2481, 0ULL, 1);
        v_t_24102 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_2487 = heff_field(v_x11_2481, 0);
        heff_take_n(v_x11_2481, 1ULL, 1);
        v_t_24102 = heff_bool(heff_strEq_c_lent(v_k_2487, ((V)&g_heff_2eelab_2erules_2etupleChk_str2), 2));
        heff_drop(v_k_2487);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_2481, 0ULL, 1);
        v_t_24102 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24102 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2481);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24102 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24102) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24102);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24103 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24103;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24102);
      HeffT1 v_t_24104 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24105 = v_t_24104.f[0];
        V v_f_24106 = v_field_24105;
        V f_ = v_f_24106;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_t_241);
    V v_t_24129;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_24108 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_24108)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_24108, 0ULL, 1);
        v_t_24129 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_24114 = heff_field(v_x11_24108, 0);
        heff_take_n(v_x11_24108, 1ULL, 1);
        v_t_24129 = heff_bool(heff_strEq_c_lent(v_k_24114, ((V)&g_heff_2eelab_2erules_2etupleChk_str3), 2));
        heff_drop(v_k_24114);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_24108, 0ULL, 1);
        v_t_24129 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24129 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24108);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24129 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24129) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24129);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24130 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24130;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24129);
      HeffT1 v_t_24131 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24132 = v_t_24131.f[0];
        V v_f_24133 = v_field_24132;
        V f_ = v_f_24133;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeFloat: {
    heff_drop(v_t_241);
    V v_t_24156;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_24135 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_24135)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_24135, 0ULL, 1);
        v_t_24156 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_24141 = heff_field(v_x11_24135, 0);
        heff_take_n(v_x11_24135, 1ULL, 1);
        v_t_24156 = heff_bool(heff_strEq_c_lent(v_k_24141, ((V)&g_heff_2eelab_2erules_2etupleChk_str4), 2));
        heff_drop(v_k_24141);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_24135, 0ULL, 1);
        v_t_24156 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24156 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24135);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24156 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24156) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24156);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24157 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24157;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24156);
      HeffT1 v_t_24158 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24159 = v_t_24158.f[0];
        V v_f_24160 = v_field_24159;
        V f_ = v_f_24160;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeString: {
    heff_drop(v_t_241);
    V v_t_24183;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_24162 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_24162)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_24162, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_24168 = heff_field(v_x11_24162, 0);
        heff_take_n(v_x11_24162, 1ULL, 1);
        v_t_24183 = heff_bool(heff_strEq_c_lent(v_k_24168, ((V)&g_heff_2eelab_2erules_2etupleChk_str5), 2));
        heff_drop(v_k_24168);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_24162, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24162);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24183 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24183) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24183);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24184 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24184;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24183);
      HeffT1 v_t_24185 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24186 = v_t_24185.f[0];
        V v_f_24187 = v_field_24186;
        V f_ = v_f_24187;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeRune: {
    heff_drop(v_t_241);
    V v_t_24210;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_24189 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_24189)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_24189, 0ULL, 1);
        v_t_24210 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_24195 = heff_field(v_x11_24189, 0);
        heff_take_n(v_x11_24189, 1ULL, 1);
        v_t_24210 = heff_bool(heff_strEq_c_lent(v_k_24195, ((V)&g_heff_2eelab_2erules_2etupleChk_str6), 2));
        heff_drop(v_k_24195);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_24189, 0ULL, 1);
        v_t_24210 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24210 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24189);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24210 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24210) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24210);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24211 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24211;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24210);
      HeffT1 v_t_24212 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24213 = v_t_24212.f[0];
        V v_f_24214 = v_field_24213;
        V f_ = v_f_24214;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_t_241);
    V v_t_24238;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_24217 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_24217)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_24217, 0ULL, 1);
        v_t_24238 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_24223 = heff_field(v_x11_24217, 0);
        heff_take_n(v_x11_24217, 1ULL, 1);
        v_t_24238 = heff_bool(heff_strEq_c_lent(v_k_24223, ((V)&g_heff_2eelab_2erules_2etupleChk_str7), 2));
        heff_drop(v_k_24223);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_24217, 0ULL, 1);
        v_t_24238 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24238 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24217);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24238) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24238);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24239 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24239;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24238);
      HeffT1 v_t_24240 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24241 = v_t_24240.f[0];
        V v_f_24242 = v_field_24241;
        V f_ = v_f_24242;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2413, 0ULL, 1);
    heff_drop(v_t_241);
    V v_t_24266;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_24245 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_24245)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_24245, 0ULL, 1);
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_24251 = heff_field(v_x11_24245, 0);
        heff_take_n(v_x11_24245, 1ULL, 1);
        v_t_24266 = heff_bool(heff_strEq_c_lent(v_k_24251, ((V)&g_heff_2eelab_2erules_2etupleChk_str8), 2));
        heff_drop(v_k_24251);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_24245, 0ULL, 1);
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24266 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24245);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24266 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24266) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24266);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24267 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24267;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24266);
      HeffT1 v_t_24268 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24269 = v_t_24268.f[0];
        V v_f_24270 = v_field_24269;
        V f_ = v_f_24270;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  case TAG_NoRules: {
    heff_drop(v_t_241);
    V v_t_24293;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_x11_24272 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_x11_24272)) {
      case TAG_HLocal: {
        heff_take_n(v_x11_24272, 0ULL, 1);
        v_t_24293 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        V v_k_24278 = heff_field(v_x11_24272, 0);
        heff_take_n(v_x11_24272, 1ULL, 1);
        v_t_24293 = heff_bool(heff_strEq_c_lent(v_k_24278, ((V)&g_heff_2eelab_2erules_2etupleChk_str9), 2));
        heff_drop(v_k_24278);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_x11_24272, 0ULL, 1);
        v_t_24293 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_24293 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24272);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24293 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24293) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop(v_v_243);
      heff_drop(v_t_24293);
      switch (heff_tag_of(v_parts_242)) {
      case TAG_MkChk: {
        V v_f_24294 = heff_field(v_parts_242, 0);
        heff_take_n(v_parts_242, 1ULL, 1);
        V f_ = v_f_24294;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
      default: return heff_nomatch(v_parts_242);
      }
    } else {
      heff_drop(v_parts_242);
      heff_drop(v_t_24293);
      HeffT1 v_t_24295 = ({ V a_0 = v_sp_240; V a_1 = v_v_243; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_v_243); r_; });
      {
        V v_field_24296 = v_t_24295.f[0];
        V v_f_24297 = v_field_24296;
        V f_ = v_f_24297;
        heff_room[0] = v_e_244;
        heff_room[1] = v_x_2412;
        heff_room[2] = v_hd_246;
        heff_room[3] = v_k_247;
        if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
      }
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2etupleChk_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_parts_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2etupleChk_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etupleChk_lam2, 1, 7, (V[]){v_sp_240, v_t_241, v_e_244, v_hd_246, v_k_247, v_parts_242, v_v_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2egivenType_lam2(V self, V *args);
V g_heff_2eelab_2erules_2egivenType_lam1(V self, V *args);
V g_heff_2eelab_2erules_2egivenType_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2egivenType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2egivenType_entry, 1, 0};

V g_heff_2eelab_2erules_2egivenType(V v_t_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2egivenType_lam0, 2, 1, (V[]){v_t_240})});
}
V g_heff_2eelab_2erules_2egivenType_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2egivenType(a[0]);
}
V g_heff_2eelab_2erules_2egivenType_lam2(V self, V *args) {
  V v_u_247 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  V v_t_2427;
  switch (heff_tag_of(v_t_240)) {
  case TAG_VU: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VDecode: {
    V v_a_2413 = heff_field(v_t_240, 4);
    heff_take_n(v_t_240, 16ULL, 5);
    v_t_2427 = heff_tr(heff_call(v_a_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
    break;
  }
  case TAG_VFunction: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VRecord: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VSum: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VPrimInt: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VPrimString: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VPrimRune: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VPrimArray: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  case TAG_VFixed: {
    v_t_2427 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_240});
    break;
  }
  default: heff_nomatch(v_t_240);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2427});
}
V g_heff_2eelab_2erules_2egivenType_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_t_244 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_245);
  V v_t_2428 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_t_244}), heff_clo_n(g_heff_2eelab_2erules_2egivenType_lam2, 1, 1, (V[]){v_t_240})});
  V f_ = v_k_246;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2egivenType_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_242);
  V v_t_243 = heff_get_n(heff_get_n(v_e_241, 0, 6), 0, 4);
  V v_t_244 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_243, heff_dup(v_t_240)));
  return heff_clo_n(g_heff_2eelab_2erules_2egivenType_lam1, 2, 2, (V[]){v_t_244, v_t_240});
}