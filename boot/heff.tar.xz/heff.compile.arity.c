// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_go 10063
#define LBL_key 315609
static uint32_t shape_go[] = {LBL_go};
V g_heff_2ecompile_2earity_2earityOne(V, V);
V g_heff_2ecompile_2earity_2earityOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2earityOne_clo;
V g_heff_2ecompile_2earity_2ecallOf(V, V, V, V);
V g_heff_2ecompile_2earity_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2ecallOf_clo;
V g_heff_2ecompile_2earity_2edropA(V, V);
V g_heff_2ecompile_2earity_2edropA_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2edropA_clo;
V g_heff_2ecompile_2earity_2esatGo(V, V, V);
V g_heff_2ecompile_2earity_2esatGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2esatGo_clo;
V g_heff_2ecompile_2earity_2esatOf(V);
V g_heff_2ecompile_2earity_2esatOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2esatOf_clo;
V g_heff_2ecompile_2earity_2etakeA(V, V);
V g_heff_2ecompile_2earity_2etakeA_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2etakeA_clo;
V g_heff_2ecompile_2earity_2etakeA_24dps(V, V, V);
V g_heff_2ecompile_2earity_2etakeA_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2earity_2etakeA_24dps_clo;
HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V);
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
HeffT2 g_heff_2ecompile_2eprims_2eprimArityGo_24cpr(V, V);
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2earity_2earityOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earity_2earityOne_entry, 2, 0};

V g_heff_2ecompile_2earity_2earityOne(V v_m_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_240, heff_get_n(v_d_241, 0, 3), v_t_247));
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return v_m_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2earity_2earityOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earity_2earityOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2earity_2etakeA_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earity_2etakeA_entry, 2, 0};

V g_heff_2ecompile_2earity_2etakeA(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2earity_2etakeA_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2earity_2etakeA_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earity_2etakeA(a[0], a[1]);
}
Clo g_heff_2ecompile_2earity_2etakeA_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earity_2etakeA_24dps_entry, 3, 0};

V g_heff_2ecompile_2earity_2etakeA_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2earity_2etakeA_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earity_2etakeA_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2earity_2edropA_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earity_2edropA_entry, 2, 0};

V g_heff_2ecompile_2earity_2edropA(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2earity_2edropA_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2earity_2edropA(a[0], a[1]);
}
Clo g_heff_2ecompile_2earity_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earity_2ecallOf_entry, 4, 0};

V g_heff_2ecompile_2earity_2ecallOf(V v_r_240, V v_ar_241, V v_h_242, V v_args_243) {
top: ;
  switch (heff_tag_of(v_h_242)) {
  case TAG_EVar: {
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_245, v_args_243});
  }
  case TAG_EGlobal: {
    V v_g_246 = heff_dup(heff_field(v_h_242, 0));
    HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_ar_241, v_g_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_n_2411 = v_field_249;
        V v_x_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
        if (heff_intLe_c_lent(v_n_2411, v_x_2412, 2)) {
          heff_drop_rec(v_r_240, 1);
          heff_drop_tag(v_h_242, 1);
          V v_t_2414 = (g_heff_2ecompile_2earity_2etakeA(heff_dup(v_n_2411), heff_dup(v_args_243)));
          V v_f_2415 = heff_tag_n(TAG_ECall, 2, (V[]){v_g_246, v_t_2414});
          V v_args_2416 = (g_heff_2ecompile_2earity_2edropA(v_n_2411, v_args_243));
          V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2416));
          if (heff_intEq_c(v_t_2417, MK_INT(0LL))) {
            heff_drop(v_args_2416);
            return v_f_2415;
          } else {
            return heff_tag_n(TAG_EApp, 2, (V[]){v_f_2415, v_args_2416});
          }
        } else {
          heff_drop(v_g_246);
          heff_drop(v_n_2411);
          V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
          return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2419, v_args_243});
        }
      } else {
        heff_drop(v_g_246);
        heff_drop(v_field_249);
        V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2420, v_args_243});
      }
    }
  }
  case TAG_ELam: {
    V v_t_2423 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2423, v_args_243});
  }
  case TAG_EApp: {
    V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2426, v_args_243});
  }
  case TAG_ELet: {
    V v_t_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2430, v_args_243});
  }
  case TAG_ERecord: {
    V v_t_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2433, v_args_243});
  }
  case TAG_EProj: {
    V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2438, v_args_243});
  }
  case TAG_ETag: {
    V v_t_2442 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2442, v_args_243});
  }
  case TAG_EMatch: {
    V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2445, v_args_243});
  }
  case TAG_EPrim: {
    V v_p_2446 = heff_dup(heff_field(v_h_242, 0));
    HeffT2 v_t_2447 = (g_heff_2ecompile_2eprims_2eprimArityGo_24cpr(v_p_2446, heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get())));
    {
      V v_field_2449 = v_t_2447.f[1];
      int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
      if ((v_tag_2448 == ((int64_t)0ULL))) {
        V v_n_2451 = v_field_2449;
        V v_x_2452 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
        if (heff_intLe_c_lent(v_n_2451, v_x_2452, 2)) {
          heff_drop_rec(v_r_240, 1);
          heff_drop_tag(v_h_242, 1);
          V v_t_2454 = (g_heff_2ecompile_2earity_2etakeA(heff_dup(v_n_2451), heff_dup(v_args_243)));
          V v_f_2455 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2446, v_t_2454});
          V v_args_2456 = (g_heff_2ecompile_2earity_2edropA(v_n_2451, v_args_243));
          V v_t_2457 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2456));
          if (heff_intEq_c(v_t_2457, MK_INT(0LL))) {
            heff_drop(v_args_2456);
            return v_f_2455;
          } else {
            return heff_tag_n(TAG_EApp, 2, (V[]){v_f_2455, v_args_2456});
          }
        } else {
          heff_drop(v_p_2446);
          heff_drop(v_n_2451);
          V v_t_2459 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
          return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2459, v_args_243});
        }
      } else {
        heff_drop(v_p_2446);
        heff_drop(v_field_2449);
        V v_t_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2460, v_args_243});
      }
    }
  }
  case TAG_EPrimCall: {
    V v_t_2463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2463, v_args_243});
  }
  case TAG_ECall: {
    V v_t_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2466, v_args_243});
  }
  case TAG_EInt: {
    V v_t_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2468, v_args_243});
  }
  case TAG_EFloat: {
    V v_t_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2470, v_args_243});
  }
  case TAG_EStr: {
    V v_t_2472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2472, v_args_243});
  }
  case TAG_EBytes: {
    V v_t_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2474, v_args_243});
  }
  case TAG_EFixed: {
    V v_t_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2477, v_args_243});
  }
  case TAG_EFloat32: {
    V v_t_2479 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2479, v_args_243});
  }
  case TAG_EAbandon: {
    V v_t_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2480, v_args_243});
  }
  case TAG_EFix: {
    V v_t_2483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_h_242}));
    return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2483, v_args_243});
  }
  default: return heff_nomatch(v_h_242);
  }
}
V g_heff_2ecompile_2earity_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2earity_2ecallOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2earity_2esatGo_lam0(V self, V *args);
V g_heff_2ecompile_2earity_2esatGo_lam1(V self, V *args);
V g_heff_2ecompile_2earity_2esatGo_lam2(V self, V *args);
V g_heff_2ecompile_2earity_2esatGo_lam3(V self, V *args);
V g_heff_2ecompile_2earity_2esatGo_lam4(V self, V *args);
V g_heff_2ecompile_2earity_2esatGo_lam5(V self, V *args);
Clo g_heff_2ecompile_2earity_2esatGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earity_2esatGo_entry, 3, 0};

V g_heff_2ecompile_2earity_2esatGo(V v_r_240, V v_ar_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_242, 0);
    V v_b_246 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_b_246}));
    return heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_245, v_t_247});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_as0_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2eir_2espine_24cpr(heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_f_248, v_as0_249})));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_h_2413 = v_field_2411;
      V v_args_2414 = v_field_2412;
      V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2earity_2esatGo_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_args_2414));
      return (g_heff_2ecompile_2earity_2ecallOf(v_r_240, v_ar_241, v_h_2413, v_t_2416));
    }
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_242, 0);
    V v_a_2418 = heff_field(v_e_242, 1);
    V v_b_2419 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2418}));
    V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_b_2419}));
    return heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_2417, v_t_2420, v_t_2421});
  }
  case TAG_ERecord: {
    V v_fs_2422 = heff_field(v_e_242, 0);
    V v_ts_2423 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2428 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2earity_2esatGo_lam1, 1, 1, (V[]){v_r_240}), v_fs_2422));
    return heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2428, v_ts_2423});
  }
  case TAG_EProj: {
    V v_e2_2429 = heff_field(v_e_242, 0);
    V v_l_2430 = heff_field(v_e_242, 1);
    V v_sh_2431 = heff_field(v_e_242, 2);
    V v_t_2432 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    V v_t_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_e2_2429}));
    return heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_t_2433, v_l_2430, v_sh_2431, v_t_2432});
  }
  case TAG_ETag: {
    V v_t_2434 = heff_field(v_e_242, 0);
    V v_args_2435 = heff_field(v_e_242, 1);
    V v_ts_2436 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2earity_2esatGo_lam2, 1, 1, (V[]){v_r_240}), v_args_2435));
    return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2434, v_t_2438, v_ts_2436});
  }
  case TAG_EMatch: {
    V v_s_2439 = heff_field(v_e_242, 0);
    V v_arms_2440 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2441 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_2439}));
    V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2earity_2esatGo_lam3, 1, 1, (V[]){v_r_240}), v_arms_2440));
    return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_2441, v_t_2447});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    V v_p_2449 = heff_field(v_e_242, 0);
    V v_args_2450 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2earity_2esatGo_lam4, 1, 1, (V[]){v_r_240}), v_args_2450));
    return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2449, v_t_2452});
  }
  case TAG_ECall: {
    V v_g_2453 = heff_field(v_e_242, 0);
    V v_args_2454 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2earity_2esatGo_lam5, 1, 1, (V[]){v_r_240}), v_args_2454));
    return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2453, v_t_2456});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 1);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2earity_2esatGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2earity_2esatGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2earity_2esatGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 1);
  args[0] = v_a_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2earity_2esatGo_lam1(V self, V *args) {
  V v_p_2424 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2424)) {
  case TAG_MkPair: {
    V v_l_2425 = heff_field(v_p_2424, 0);
    V v_e2_2426 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24MkPair = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_e2_2426}));
    return heff_tag_at_n(v_ru_24p_2424_24MkPair, TAG_MkPair, 2, (V[]){v_l_2425, v_t_2427});
  }
  default: return heff_nomatch(v_p_2424);
  }
}
V g_heff_2ecompile_2earity_2esatGo_lam2(V self, V *args) {
  V v_a_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 1);
  args[0] = v_a_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2earity_2esatGo_lam3(V self, V *args) {
  V v_a_2442 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2442)) {
  case TAG_MkArm: {
    V v_t_2443 = heff_field(v_a_2442, 0);
    V v_vs_2444 = heff_field(v_a_2442, 1);
    V v_b_2445 = heff_field(v_a_2442, 2);
    V v_ru_24a_2442_24MkArm = heff_take_reuse_n(v_a_2442, 7ULL, 3);
    V v_t_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 1), 1, (V[]){v_b_2445}));
    return heff_tag_at_n(v_ru_24a_2442_24MkArm, TAG_MkArm, 3, (V[]){v_t_2443, v_vs_2444, v_t_2446});
  }
  default: return heff_nomatch(v_a_2442);
  }
}
V g_heff_2ecompile_2earity_2esatGo_lam4(V self, V *args) {
  V v_a_2451 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 1);
  args[0] = v_a_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2earity_2esatGo_lam5(V self, V *args) {
  V v_a_2455 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 1);
  args[0] = v_a_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2earity_2esatOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2earity_2esatOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2earity_2esatOf_entry, 1, 0};

V g_heff_2ecompile_2earity_2esatOf(V v_ar_240) {
top: ;
  return heff_rec_n(1, shape_go, (V[]){heff_clo_n(g_heff_2ecompile_2earity_2esatOf_lam0, 1, 1, (V[]){heff_dup(v_ar_240)})});
}
V g_heff_2ecompile_2earity_2esatOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2earity_2esatOf(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2earity_2esatOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_ar_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2ecompile_2earity_2esatOf(v_ar_240));
  return ({ V a_0 = v_t_242; V a_1 = v_ar_240; V a_2 = v_e_241; V r_ = (g_heff_2ecompile_2earity_2esatGo(a_0, a_1, a_2)); heff_drop(v_ar_240); r_; });
}