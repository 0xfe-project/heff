// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SegmentBinary 41188
#define TAG_SegmentInteger 22664
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_end 310101
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryWith(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryWith_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryWith_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2edoFrom(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoFrom_clo;
V g_heff_2esyntax_2epresyntax_2edoStep(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoStep_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo;
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2esegmentPart(V, V);
V g_heff_2esyntax_2epresyntax_2esegmentPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esegmentPart_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
V g_heff_2esyntax_2epresyntax_2ewholeInteger(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewholeInteger_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeInteger_clo;
V g_heff_2esyntax_2epresyntax_2ewholeSegment(V);
V g_heff_2esyntax_2epresyntax_2ewholeSegment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeSegment_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1150457979x1978067071(V);
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1253308387x88241051(V);
V g_list_2emap_24s1253308387x88241051_entry(V self, V *a);
extern Clo g_list_2emap_24s1253308387x88241051_clo;
V g_list_2emap_24s1374235278x875430684(V);
V g_list_2emap_24s1374235278x875430684_entry(V self, V *a);
extern Clo g_list_2emap_24s1374235278x875430684_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s503326960x1200444853(V);
V g_list_2emap_24s503326960x1200444853_entry(V self, V *a);
extern Clo g_list_2emap_24s503326960x1200444853_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereversedBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereversedBytes(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_t_244, v_acc_242);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ereversedBytes(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etwoTo_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etwoTo(V v_k_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etwoTo(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2elastOr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      V v_sp_245 = heff_dup(heff_field(v_f_240, 1));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_247 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2410;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_f_240, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2413;
        switch (heff_tag_of(v_x1_247)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x1_247, 1);
          heff_take_n(v_x1_247, 2ULL, 2);
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_x1_247);
        }
        V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2414});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2419;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2418 = heff_dup(heff_field(v_f_240, 1));
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2422;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2416, 1);
          heff_take_n(v_x1_2416, 2ULL, 2);
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      case TAG_ETag: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2425 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2428;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_f_240, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2431;
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x1_2425, 1);
          heff_take_n(v_x1_2425, 2ULL, 2);
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        V v_t_2432 = ({ V rv_1 = heff_get_n(v_t_2431, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2428, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2432});
      }
      case TAG_EInt: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2434 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2437;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_f_240, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2440;
        switch (heff_tag_of(v_x1_2434)) {
        case TAG_At: {
          V v_s_2439 = heff_field(v_x1_2434, 1);
          heff_take_n(v_x1_2434, 2ULL, 2);
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_x1_2434);
        }
        V v_t_2441 = ({ V rv_1 = heff_get_n(v_t_2440, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2437, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2441});
      }
      case TAG_EFloat: {
        heff_take_na(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2443 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2446;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2445 = heff_dup(heff_field(v_f_240, 1));
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2449;
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_At: {
          V v_s_2448 = heff_field(v_x1_2443, 1);
          heff_take_n(v_x1_2443, 2ULL, 2);
          v_t_2449 = v_s_2448;
          break;
        }
        default: heff_nomatch(v_x1_2443);
        }
        V v_t_2450 = ({ V rv_1 = heff_get_n(v_t_2449, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2446, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2450});
      }
      case TAG_EString: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2452 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2455;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2454 = heff_dup(heff_field(v_f_240, 1));
          v_t_2455 = v_s_2454;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2458;
        switch (heff_tag_of(v_x1_2452)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x1_2452, 1);
          heff_take_n(v_x1_2452, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x1_2452);
        }
        V v_t_2459 = ({ V rv_1 = heff_get_n(v_t_2458, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2455, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2459});
      }
      case TAG_EBinary: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2461 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2464;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2463 = heff_dup(heff_field(v_f_240, 1));
          v_t_2464 = v_s_2463;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2467;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x1_2461, 1);
          heff_take_n(v_x1_2461, 2ULL, 2);
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        V v_t_2468 = ({ V rv_1 = heff_get_n(v_t_2467, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2464, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2468});
      }
      case TAG_ERune: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2470 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2473;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_f_240, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2476;
        switch (heff_tag_of(v_x1_2470)) {
        case TAG_At: {
          V v_s_2475 = heff_field(v_x1_2470, 1);
          heff_take_n(v_x1_2470, 2ULL, 2);
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_x1_2470);
        }
        V v_t_2477 = ({ V rv_1 = heff_get_n(v_t_2476, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2473, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2477});
      }
      case TAG_EWord: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2479 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2482;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2481 = heff_dup(heff_field(v_f_240, 1));
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2485;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_At: {
          V v_s_2484 = heff_field(v_x1_2479, 1);
          heff_take_n(v_x1_2479, 2ULL, 2);
          v_t_2485 = v_s_2484;
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_t_2486 = ({ V rv_1 = heff_get_n(v_t_2485, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2482, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2486});
      }
      case TAG_EApp: {
        V v_h_2487 = heff_field(v_f1_244, 0);
        V v_xs_2488 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        heff_drop_tag(v_f_240, 2);
        V v_t_2489 = (g_prelude_2e_2b_2b(v_xs_2488, heff_dup(v_args_241)));
        V v_x1_2490 = ({ V a_0 = heff_dup(v_h_2487); V a_1 = v_args_241; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
        V v_t_2493;
        switch (heff_tag_of(v_x1_2490)) {
        case TAG_At: {
          V v_s_2492 = heff_field(v_x1_2490, 1);
          heff_take_n(v_x1_2490, 2ULL, 2);
          v_t_2493 = v_s_2492;
          break;
        }
        default: heff_nomatch(v_x1_2490);
        }
        V v_t_2494 = ({ V rv_1 = heff_get_n(v_t_2493, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24f1_244_24EApp, TAG_EApp, 2, (V[]){v_h_2487, v_t_2489}), v_t_2494});
      }
      case TAG_EProject: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2496 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2499;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_f_240, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24102;
        switch (heff_tag_of(v_x1_2496)) {
        case TAG_At: {
          V v_s_24101 = heff_field(v_x1_2496, 1);
          heff_take_n(v_x1_2496, 2ULL, 2);
          v_t_24102 = v_s_24101;
          break;
        }
        default: heff_nomatch(v_x1_2496);
        }
        V v_t_24103 = ({ V rv_1 = heff_get_n(v_t_24102, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2499, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24103});
      }
      case TAG_ENamed: {
        V v_ru_24f1_244_24ENamed = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24106 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24109;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_f_240, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24112;
        switch (heff_tag_of(v_x1_24106)) {
        case TAG_At: {
          V v_s_24111 = heff_field(v_x1_24106, 1);
          heff_take_n(v_x1_24106, 2ULL, 2);
          v_t_24112 = v_s_24111;
          break;
        }
        default: heff_nomatch(v_x1_24106);
        }
        V v_t_24113 = ({ V rv_1 = heff_get_n(v_t_24112, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24109, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24113});
      }
      case TAG_EPi: {
        V v_ru_24f1_244_24EPi = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24116 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24119;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_f_240, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24122;
        switch (heff_tag_of(v_x1_24116)) {
        case TAG_At: {
          V v_s_24121 = heff_field(v_x1_24116, 1);
          heff_take_n(v_x1_24116, 2ULL, 2);
          v_t_24122 = v_s_24121;
          break;
        }
        default: heff_nomatch(v_x1_24116);
        }
        V v_t_24123 = ({ V rv_1 = heff_get_n(v_t_24122, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24119, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24123});
      }
      case TAG_ELam: {
        V v_ru_24f1_244_24ELam = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24126 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24129;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_f_240, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24132;
        switch (heff_tag_of(v_x1_24126)) {
        case TAG_At: {
          V v_s_24131 = heff_field(v_x1_24126, 1);
          heff_take_n(v_x1_24126, 2ULL, 2);
          v_t_24132 = v_s_24131;
          break;
        }
        default: heff_nomatch(v_x1_24126);
        }
        V v_t_24133 = ({ V rv_1 = heff_get_n(v_t_24132, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24129, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24133});
      }
      case TAG_EAnn: {
        V v_ru_24f1_244_24EAnn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24136 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24139;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24138 = heff_dup(heff_field(v_f_240, 1));
          v_t_24139 = v_s_24138;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24142;
        switch (heff_tag_of(v_x1_24136)) {
        case TAG_At: {
          V v_s_24141 = heff_field(v_x1_24136, 1);
          heff_take_n(v_x1_24136, 2ULL, 2);
          v_t_24142 = v_s_24141;
          break;
        }
        default: heff_nomatch(v_x1_24136);
        }
        V v_t_24143 = ({ V rv_1 = heff_get_n(v_t_24142, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24139, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24143});
      }
      case TAG_ESpec: {
        heff_take_n(v_f1_244, 0ULL, 4);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24148 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24151;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24150 = heff_dup(heff_field(v_f_240, 1));
          v_t_24151 = v_s_24150;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24154;
        switch (heff_tag_of(v_x1_24148)) {
        case TAG_At: {
          V v_s_24153 = heff_field(v_x1_24148, 1);
          heff_take_n(v_x1_24148, 2ULL, 2);
          v_t_24154 = v_s_24153;
          break;
        }
        default: heff_nomatch(v_x1_24148);
        }
        V v_t_24155 = ({ V rv_1 = heff_get_n(v_t_24154, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24151, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24155});
      }
      case TAG_ESig: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24157 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24160;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24159 = heff_dup(heff_field(v_f_240, 1));
          v_t_24160 = v_s_24159;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24163;
        switch (heff_tag_of(v_x1_24157)) {
        case TAG_At: {
          V v_s_24162 = heff_field(v_x1_24157, 1);
          heff_take_n(v_x1_24157, 2ULL, 2);
          v_t_24163 = v_s_24162;
          break;
        }
        default: heff_nomatch(v_x1_24157);
        }
        V v_t_24164 = ({ V rv_1 = heff_get_n(v_t_24163, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24160, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24164});
      }
      case TAG_ESum: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24166 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24169;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24168 = heff_dup(heff_field(v_f_240, 1));
          v_t_24169 = v_s_24168;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24172;
        switch (heff_tag_of(v_x1_24166)) {
        case TAG_At: {
          V v_s_24171 = heff_field(v_x1_24166, 1);
          heff_take_n(v_x1_24166, 2ULL, 2);
          v_t_24172 = v_s_24171;
          break;
        }
        default: heff_nomatch(v_x1_24166);
        }
        V v_t_24173 = ({ V rv_1 = heff_get_n(v_t_24172, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24169, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24173});
      }
      case TAG_EStruct: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24175 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24178;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24177 = heff_dup(heff_field(v_f_240, 1));
          v_t_24178 = v_s_24177;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24181;
        switch (heff_tag_of(v_x1_24175)) {
        case TAG_At: {
          V v_s_24180 = heff_field(v_x1_24175, 1);
          heff_take_n(v_x1_24175, 2ULL, 2);
          v_t_24181 = v_s_24180;
          break;
        }
        default: heff_nomatch(v_x1_24175);
        }
        V v_t_24182 = ({ V rv_1 = heff_get_n(v_t_24181, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24178, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24182});
      }
      case TAG_EUpdate: {
        V v_ru_24f1_244_24EUpdate = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24185 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24188;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24187 = heff_dup(heff_field(v_f_240, 1));
          v_t_24188 = v_s_24187;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24191;
        switch (heff_tag_of(v_x1_24185)) {
        case TAG_At: {
          V v_s_24190 = heff_field(v_x1_24185, 1);
          heff_take_n(v_x1_24185, 2ULL, 2);
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_x1_24185);
        }
        V v_t_24192 = ({ V rv_1 = heff_get_n(v_t_24191, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24188, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24192});
      }
      case TAG_EMatch: {
        V v_ru_24f1_244_24EMatch = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24195 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24198;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24197 = heff_dup(heff_field(v_f_240, 1));
          v_t_24198 = v_s_24197;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24201;
        switch (heff_tag_of(v_x1_24195)) {
        case TAG_At: {
          V v_s_24200 = heff_field(v_x1_24195, 1);
          heff_take_n(v_x1_24195, 2ULL, 2);
          v_t_24201 = v_s_24200;
          break;
        }
        default: heff_nomatch(v_x1_24195);
        }
        V v_t_24202 = ({ V rv_1 = heff_get_n(v_t_24201, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24198, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24202});
      }
      case TAG_ELetIn: {
        V v_ru_24f1_244_24ELetIn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24205 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24208;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24207 = heff_dup(heff_field(v_f_240, 1));
          v_t_24208 = v_s_24207;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24211;
        switch (heff_tag_of(v_x1_24205)) {
        case TAG_At: {
          V v_s_24210 = heff_field(v_x1_24205, 1);
          heff_take_n(v_x1_24205, 2ULL, 2);
          v_t_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_x1_24205);
        }
        V v_t_24212 = ({ V rv_1 = heff_get_n(v_t_24211, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24208, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24212});
      }
      case TAG_EDo: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24214 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24217;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24216 = heff_dup(heff_field(v_f_240, 1));
          v_t_24217 = v_s_24216;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24220;
        switch (heff_tag_of(v_x1_24214)) {
        case TAG_At: {
          V v_s_24219 = heff_field(v_x1_24214, 1);
          heff_take_n(v_x1_24214, 2ULL, 2);
          v_t_24220 = v_s_24219;
          break;
        }
        default: heff_nomatch(v_x1_24214);
        }
        V v_t_24221 = ({ V rv_1 = heff_get_n(v_t_24220, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24217, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24221});
      }
      case TAG_ELocal: {
        V v_ru_24f1_244_24ELocal = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24224 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24227;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24226 = heff_dup(heff_field(v_f_240, 1));
          v_t_24227 = v_s_24226;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24230;
        switch (heff_tag_of(v_x1_24224)) {
        case TAG_At: {
          V v_s_24229 = heff_field(v_x1_24224, 1);
          heff_take_n(v_x1_24224, 2ULL, 2);
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_x1_24224);
        }
        V v_t_24231 = ({ V rv_1 = heff_get_n(v_t_24230, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24227, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24231});
      }
      case TAG_EInvalid: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24233 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24236;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24235 = heff_dup(heff_field(v_f_240, 1));
          v_t_24236 = v_s_24235;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24239;
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_At: {
          V v_s_24238 = heff_field(v_x1_24233, 1);
          heff_take_n(v_x1_24233, 2ULL, 2);
          v_t_24239 = v_s_24238;
          break;
        }
        default: heff_nomatch(v_x1_24233);
        }
        V v_t_24240 = ({ V rv_1 = heff_get_n(v_t_24239, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24236, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24240});
      }
      default: return heff_nomatch(v_f1_244);
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eapp(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2edoFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edoFrom_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2edoFrom(V v_sp_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    return v_e_242;
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2edoFrom(heff_dup(v_sp_240), v_rest_244, v_e_242));
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2edoStep(v_sp_240, heff_dup(v_s_243), v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2edoFrom_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2edoFrom(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsType = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsType, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24d_2420_24Just, TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsInferable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsInferable, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsCheckable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_b_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_b_243)) {
  case TAG_IsInferable: {
    V v_b1_245 = heff_field(v_b_243, 0);
    V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b1_245}), v_sp_244});
    return heff_tag_at_n(v_ru_24b_243_24IsInferable, TAG_IsInferable, 1, (V[]){v_t_246});
  }
  case TAG_IsCheckable: {
    V v_t_2417;
    switch (heff_tag_of(v_b_243)) {
    case TAG_IsInferable: {
      V v_i_248 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2412 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      v_t_2417 = v_c_2412;
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsType = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsType, TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2417}), v_sp_244});
    return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2418});
  }
  case TAG_IsType: {
    V v_t_2429;
    switch (heff_tag_of(v_b_243)) {
    case TAG_IsInferable: {
      V v_i_2420 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2423;
      switch (heff_tag_of(v_i_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_i_2420);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2424 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      v_t_2429 = v_c_2424;
      break;
    }
    case TAG_IsType: {
      V v_t_2425 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsType = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2429}), v_sp_244});
    return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2430});
  }
  default: return heff_nomatch(v_b_243);
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_str3, 0, "");
Clo g_heff_2esyntax_2epresyntax_2ewholeInteger_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewholeInteger_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewholeInteger(V v_x1_240, V v_little_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_v_242, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_b_247 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(MK_INT(8LL), MK_INT(8LL)), heff_intMod(v_t_245, v_t_246), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_str0)));
    V v_t_248;
    if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
      v_t_248 = (g_heff_2esyntax_2epresyntax_2ereversedBytes(v_b_247, MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_str1)));
    } else {
      v_t_248 = v_b_247;
    }
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
  }
  case TAG_SizeNumber: {
    V v_n_249 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
    V v_t_2412 = heff_intAdd(heff_intMod(v_v_242, v_t_2410), v_t_2411);
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
    V v_b_2414 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(v_n_249, MK_INT(8LL)), heff_intMod(v_t_2412, v_t_2413), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_str2)));
    V v_t_2415;
    if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
      v_t_2415 = (g_heff_2esyntax_2epresyntax_2ereversedBytes(v_b_2414, MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_str3)));
    } else {
      v_t_2415 = v_b_2414;
    }
    return heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_Just, 1, (V[]){v_t_2415});
  }
  case TAG_SizeName: {
    heff_take_n(v_x1_240, 0ULL, 2);
    heff_drop(v_v_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewholeInteger_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ewholeInteger(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewholeBinary_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewholeBinary(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_seg_244 = heff_field(v_x11_242, 0);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2ewholeSegment(v_seg_244));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop(v_acc_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_s_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        V t_0 = v_rest_243;
        V t_1 = heff_strAppend(v_acc_241, v_s_247);
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ewholeBinary(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esegmentPart_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esegmentPart_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esegmentPart_str2, 18, "prelude.bytesSized");
Clo g_heff_2esyntax_2epresyntax_2esegmentPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esegmentPart_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2esegmentPart(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkSegment: {
      V v_v_244 = heff_field(v_x21_242, 0);
      V v_x212_245 = heff_field(v_x21_242, 1);
      V v_size_246 = heff_field(v_x21_242, 2);
      V v_little_247 = heff_field(v_x21_242, 3);
      V v_signed_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 31ULL, 5);
      switch (heff_tag_of(v_x212_245)) {
      case TAG_SegmentInteger: {
        V v_t_2415;
        switch (heff_tag_of(v_size_246)) {
        case TAG_SizeDefault: {
          V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(8LL)}), heff_dup(v_sp_243)});
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_243)});
          break;
        }
        case TAG_SizeNumber: {
          V v_n_2410 = heff_field(v_size_246, 0);
          V v_ru_24size_246_24SizeNumber = heff_take_reuse_n(v_size_246, 1ULL, 1);
          V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2410}), heff_dup(v_sp_243)});
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24size_246_24SizeNumber, TAG_CInf, 1, (V[]){v_t_2411}), heff_dup(v_sp_243)});
          break;
        }
        case TAG_SizeName: {
          V v_x_2412 = heff_field(v_size_246, 0);
          V v_xsp_2413 = heff_field(v_size_246, 1);
          V v_ru_24size_246_24SizeName = heff_take_reuse_n(v_size_246, 3ULL, 2);
          V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2412}), heff_dup(v_xsp_2413)});
          v_t_2415 = heff_tag_at_n(v_ru_24size_246_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), v_xsp_2413});
          break;
        }
        default: heff_nomatch(v_size_246);
        }
        V v_t_2416;
        if ((heff_dup(v_little_247) == NTAG(TAG_True))) {
          heff_drop(v_little_247);
          v_t_2416 = MK_INT(1LL);
        } else {
          heff_drop(v_little_247);
          v_t_2416 = MK_INT(0LL);
        }
        V v_t_2417;
        if ((heff_dup(v_signed_248) == NTAG(TAG_True))) {
          heff_drop(v_signed_248);
          v_t_2417 = MK_INT(2LL);
        } else {
          heff_drop(v_signed_248);
          v_t_2417 = MK_INT(0LL);
        }
        V v_t_2418 = heff_tag_n(TAG_IInt, 1, (V[]){heff_intAdd(v_t_2416, v_t_2417)});
        V v_i_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_243)});
        V v_t_2422;
        switch (heff_tag_of(v_i_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_i_2419);
        }
        V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
        V v_x1_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
        V v_t_2434;
        switch (heff_tag_of(v_x1_2424)) {
        case TAG_IsInferable: {
          V v_i_2425 = heff_field(v_x1_2424, 0);
          V v_ru_24x1_2424_24IsInferable = heff_take_reuse_n(v_x1_2424, 1ULL, 1);
          V v_t_2428;
          switch (heff_tag_of(v_i_2425)) {
          case TAG_At: {
            V v_s_2427 = heff_dup(heff_field(v_i_2425, 1));
            v_t_2428 = v_s_2427;
            break;
          }
          default: heff_nomatch(v_i_2425);
          }
          v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2424_24IsInferable, TAG_CInf, 1, (V[]){v_i_2425}), v_t_2428});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2429 = heff_field(v_x1_2424, 0);
          heff_take_n(v_x1_2424, 1ULL, 1);
          v_t_2434 = v_c_2429;
          break;
        }
        case TAG_IsType: {
          V v_t_2430 = heff_field(v_x1_2424, 0);
          V v_ru_24x1_2424_24IsType = heff_take_reuse_n(v_x1_2424, 1ULL, 1);
          V v_t_2433;
          switch (heff_tag_of(v_t_2430)) {
          case TAG_At: {
            V v_s_2432 = heff_dup(heff_field(v_t_2430, 1));
            v_t_2433 = v_s_2432;
            break;
          }
          default: heff_nomatch(v_t_2430);
          }
          v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2424_24IsType, TAG_CType, 1, (V[]){v_t_2430}), v_t_2433});
          break;
        }
        default: heff_nomatch(v_x1_2424);
        }
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
        V v_args_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2435})});
        V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esegmentPart_str0)}), heff_dup(v_sp_243)});
        V v_t_2438 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2436));
        V v_i_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2437, v_t_2438}), v_sp_243});
        V v_t_2442;
        switch (heff_tag_of(v_i_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_i_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_i_2439);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2439}), v_t_2442});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_247);
        heff_drop(v_signed_248);
        switch (heff_tag_of(v_size_246)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_243);
          V v_x1_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          switch (heff_tag_of(v_x1_2443)) {
          case TAG_IsInferable: {
            V v_i_2444 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            V v_t_2447;
            switch (heff_tag_of(v_i_2444)) {
            case TAG_At: {
              V v_s_2446 = heff_dup(heff_field(v_i_2444, 1));
              v_t_2447 = v_s_2446;
              break;
            }
            default: heff_nomatch(v_i_2444);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2444}), v_t_2447});
          }
          case TAG_IsCheckable: {
            V v_c_2448 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            return v_c_2448;
          }
          case TAG_IsType: {
            V v_t_2449 = heff_field(v_x1_2443, 0);
            heff_take_n(v_x1_2443, 1ULL, 1);
            V v_t_2452;
            switch (heff_tag_of(v_t_2449)) {
            case TAG_At: {
              V v_s_2451 = heff_dup(heff_field(v_t_2449, 1));
              v_t_2452 = v_s_2451;
              break;
            }
            default: heff_nomatch(v_t_2449);
            }
            return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2449}), v_t_2452});
          }
          default: return heff_nomatch(v_x1_2443);
          }
        }
        case TAG_SizeNumber: {
          V v_t_2460;
          switch (heff_tag_of(v_size_246)) {
          case TAG_SizeDefault: {
            V v_t_2454 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_243)});
            v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2454}), heff_dup(v_sp_243)});
            break;
          }
          case TAG_SizeNumber: {
            V v_n_2455 = heff_field(v_size_246, 0);
            V v_ru_24size_246_24SizeNumber = heff_take_reuse_n(v_size_246, 1ULL, 1);
            V v_t_2456 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2455}), heff_dup(v_sp_243)});
            v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24size_246_24SizeNumber, TAG_CInf, 1, (V[]){v_t_2456}), heff_dup(v_sp_243)});
            break;
          }
          case TAG_SizeName: {
            V v_x_2457 = heff_field(v_size_246, 0);
            V v_xsp_2458 = heff_field(v_size_246, 1);
            V v_ru_24size_246_24SizeName = heff_take_reuse_n(v_size_246, 3ULL, 2);
            V v_t_2459 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2457}), heff_dup(v_xsp_2458)});
            v_t_2460 = heff_tag_at_n(v_ru_24size_246_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2459}), v_xsp_2458});
            break;
          }
          default: heff_nomatch(v_size_246);
          }
          V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2471;
          switch (heff_tag_of(v_x1_2461)) {
          case TAG_IsInferable: {
            V v_i_2462 = heff_field(v_x1_2461, 0);
            V v_ru_24x1_2461_24IsInferable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
            V v_t_2465;
            switch (heff_tag_of(v_i_2462)) {
            case TAG_At: {
              V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
              v_t_2465 = v_s_2464;
              break;
            }
            default: heff_nomatch(v_i_2462);
            }
            v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsInferable, TAG_CInf, 1, (V[]){v_i_2462}), v_t_2465});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2466 = heff_field(v_x1_2461, 0);
            heff_take_n(v_x1_2461, 1ULL, 1);
            v_t_2471 = v_c_2466;
            break;
          }
          case TAG_IsType: {
            V v_t_2467 = heff_field(v_x1_2461, 0);
            V v_ru_24x1_2461_24IsType = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
            V v_t_2470;
            switch (heff_tag_of(v_t_2467)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_t_2467, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_t_2467);
            }
            v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsType, TAG_CType, 1, (V[]){v_t_2467}), v_t_2470});
            break;
          }
          default: heff_nomatch(v_x1_2461);
          }
          V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
          V v_args_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2472});
          V v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esegmentPart_str1)}), heff_dup(v_sp_243)});
          V v_t_2475 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2473));
          V v_i_2476 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2474, v_t_2475}), v_sp_243});
          V v_t_2479;
          switch (heff_tag_of(v_i_2476)) {
          case TAG_At: {
            V v_s_2478 = heff_dup(heff_field(v_i_2476, 1));
            v_t_2479 = v_s_2478;
            break;
          }
          default: heff_nomatch(v_i_2476);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2476}), v_t_2479});
        }
        case TAG_SizeName: {
          V v_t_2488;
          switch (heff_tag_of(v_size_246)) {
          case TAG_SizeDefault: {
            V v_t_2482 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_243)});
            v_t_2488 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2482}), heff_dup(v_sp_243)});
            break;
          }
          case TAG_SizeNumber: {
            V v_n_2483 = heff_field(v_size_246, 0);
            V v_ru_24size_246_24SizeNumber = heff_take_reuse_n(v_size_246, 1ULL, 1);
            V v_t_2484 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_n_2483}), heff_dup(v_sp_243)});
            v_t_2488 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24size_246_24SizeNumber, TAG_CInf, 1, (V[]){v_t_2484}), heff_dup(v_sp_243)});
            break;
          }
          case TAG_SizeName: {
            V v_x_2485 = heff_field(v_size_246, 0);
            V v_xsp_2486 = heff_field(v_size_246, 1);
            V v_ru_24size_246_24SizeName = heff_take_reuse_n(v_size_246, 3ULL, 2);
            V v_t_2487 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2485}), heff_dup(v_xsp_2486)});
            v_t_2488 = heff_tag_at_n(v_ru_24size_246_24SizeName, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2487}), v_xsp_2486});
            break;
          }
          default: heff_nomatch(v_size_246);
          }
          V v_x1_2489 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_244}));
          V v_t_2499;
          switch (heff_tag_of(v_x1_2489)) {
          case TAG_IsInferable: {
            V v_i_2490 = heff_field(v_x1_2489, 0);
            V v_ru_24x1_2489_24IsInferable = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
            V v_t_2493;
            switch (heff_tag_of(v_i_2490)) {
            case TAG_At: {
              V v_s_2492 = heff_dup(heff_field(v_i_2490, 1));
              v_t_2493 = v_s_2492;
              break;
            }
            default: heff_nomatch(v_i_2490);
            }
            v_t_2499 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2489_24IsInferable, TAG_CInf, 1, (V[]){v_i_2490}), v_t_2493});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_2494 = heff_field(v_x1_2489, 0);
            heff_take_n(v_x1_2489, 1ULL, 1);
            v_t_2499 = v_c_2494;
            break;
          }
          case TAG_IsType: {
            V v_t_2495 = heff_field(v_x1_2489, 0);
            V v_ru_24x1_2489_24IsType = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
            V v_t_2498;
            switch (heff_tag_of(v_t_2495)) {
            case TAG_At: {
              V v_s_2497 = heff_dup(heff_field(v_t_2495, 1));
              v_t_2498 = v_s_2497;
              break;
            }
            default: heff_nomatch(v_t_2495);
            }
            v_t_2499 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2489_24IsType, TAG_CType, 1, (V[]){v_t_2495}), v_t_2498});
            break;
          }
          default: heff_nomatch(v_x1_2489);
          }
          V v_t_24100 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2499, NTAG(TAG_Nil)});
          V v_args_24101 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, v_t_24100});
          V v_t_24102 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esegmentPart_str2)}), heff_dup(v_sp_243)});
          V v_t_24103 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_24101));
          V v_i_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24102, v_t_24103}), v_sp_243});
          V v_t_24107;
          switch (heff_tag_of(v_i_24104)) {
          case TAG_At: {
            V v_s_24106 = heff_dup(heff_field(v_i_24104, 1));
            v_t_24107 = v_s_24106;
            break;
          }
          default: heff_nomatch(v_i_24104);
          }
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24104}), v_t_24107});
        }
        default: return heff_nomatch(v_size_246);
        }
      }
      default: return heff_nomatch(v_x212_245);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2esegmentPart_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esegmentPart(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str1, 4, "Cons");
Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elistOfChk_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elistOfChk(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str0), heff_dup(v_sp_241), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_xs_244, heff_dup(v_sp_241)));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str1), heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_246})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elistOfChk(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_249 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_248, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_249, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2410 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_2410}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_EFloat: {
      double v_x_2412 = heff_tflat_f64(v_x21_242, 0);
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2412)}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2413});
    }
    case TAG_EString: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EString, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_EBinary: {
      V v_segs_2416 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2417 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_2416, ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0)));
      return (g_heff_2esyntax_2epresyntax_2ebinaryWith(v_r_240, v_segs_2416, v_sp_243, v_t_2417));
    }
    case TAG_ERune: {
      V v_c_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2418}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_IsInferable, 1, (V[]){v_t_2419});
    }
    case TAG_EWord: {
      V v_w_2420 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2ewordOf(v_w_2420, v_sp_243);
    }
    case TAG_EApp: {
      V v_h_2421 = heff_field(v_x21_242, 0);
      V v_args_2422 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2eappOf(v_r_240, v_h_2421, v_args_2422, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2424 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2424, v_sp_243})});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2427 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2427, v_sp_243})});
    }
    case TAG_EPi: {
      V v_b_2428 = heff_field(v_x21_242, 0);
      V v_cod_2429 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2428));
      V v_x1_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2429}));
      V v_t_2441;
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_IsInferable: {
        V v_i_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        V v_t_2435;
        switch (heff_tag_of(v_i_2432)) {
        case TAG_At: {
          V v_s_2434 = heff_dup(heff_field(v_i_2432, 1));
          v_t_2435 = v_s_2434;
          break;
        }
        default: heff_nomatch(v_i_2432);
        }
        v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2432}), v_t_2435});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2436 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_c_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_c_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_c_2436);
        }
        v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2436}), v_t_2439});
        break;
      }
      case TAG_IsType: {
        V v_t_2440 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2441 = v_t_2440;
        break;
      }
      default: heff_nomatch(v_x1_2431);
      }
      V v_t_2442 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2430, v_t_2441}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2442});
    }
    case TAG_ELam: {
      V v_x211_2443 = heff_field(v_x21_242, 0);
      V v_body_2444 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2443)) {
      case TAG_LamName: {
        V v_x_2445 = heff_field(v_x211_2443, 0);
        V v_xsp_2446 = heff_field(v_x211_2443, 1);
        heff_take_n(v_x211_2443, 3ULL, 2);
        V v_x1_2447 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        V v_t_2457;
        switch (heff_tag_of(v_x1_2447)) {
        case TAG_IsInferable: {
          V v_i_2448 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          V v_t_2451;
          switch (heff_tag_of(v_i_2448)) {
          case TAG_At: {
            V v_s_2450 = heff_dup(heff_field(v_i_2448, 1));
            v_t_2451 = v_s_2450;
            break;
          }
          default: heff_nomatch(v_i_2448);
          }
          v_t_2457 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2448}), v_t_2451});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2452 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2457 = v_c_2452;
          break;
        }
        case TAG_IsType: {
          V v_t_2453 = heff_field(v_x1_2447, 0);
          heff_take_n(v_x1_2447, 1ULL, 1);
          V v_t_2456;
          switch (heff_tag_of(v_t_2453)) {
          case TAG_At: {
            V v_s_2455 = heff_dup(heff_field(v_t_2453, 1));
            v_t_2456 = v_s_2455;
            break;
          }
          default: heff_nomatch(v_t_2453);
          }
          v_t_2457 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2453}), v_t_2456});
          break;
        }
        default: heff_nomatch(v_x1_2447);
        }
        V v_t_2458 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2445, v_xsp_2446, v_t_2457}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2458});
      }
      case TAG_LamImplicit: {
        V v_x_2459 = heff_field(v_x211_2443, 0);
        V v_xsp_2460 = heff_field(v_x211_2443, 1);
        heff_take_n(v_x211_2443, 3ULL, 2);
        V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        V v_t_2471;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_IsInferable: {
          V v_i_2462 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          V v_t_2465;
          switch (heff_tag_of(v_i_2462)) {
          case TAG_At: {
            V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
            v_t_2465 = v_s_2464;
            break;
          }
          default: heff_nomatch(v_i_2462);
          }
          v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2462}), v_t_2465});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2466 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2471 = v_c_2466;
          break;
        }
        case TAG_IsType: {
          V v_t_2467 = heff_field(v_x1_2461, 0);
          heff_take_n(v_x1_2461, 1ULL, 1);
          V v_t_2470;
          switch (heff_tag_of(v_t_2467)) {
          case TAG_At: {
            V v_s_2469 = heff_dup(heff_field(v_t_2467, 1));
            v_t_2470 = v_s_2469;
            break;
          }
          default: heff_nomatch(v_t_2467);
          }
          v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2467}), v_t_2470});
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        V v_t_2472 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2459, v_xsp_2460, v_t_2471}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2472});
      }
      case TAG_LamAnn: {
        V v_x_2473 = heff_field(v_x211_2443, 0);
        V v_xsp_2474 = heff_field(v_x211_2443, 1);
        V v_t_2475 = heff_field(v_x211_2443, 2);
        heff_take_n(v_x211_2443, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        V v_x1_2476 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2475}));
        V v_t_2486;
        switch (heff_tag_of(v_x1_2476)) {
        case TAG_IsInferable: {
          V v_i_2477 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          V v_t_2480;
          switch (heff_tag_of(v_i_2477)) {
          case TAG_At: {
            V v_s_2479 = heff_dup(heff_field(v_i_2477, 1));
            v_t_2480 = v_s_2479;
            break;
          }
          default: heff_nomatch(v_i_2477);
          }
          v_t_2486 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2477}), v_t_2480});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2481 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          V v_t_2484;
          switch (heff_tag_of(v_c_2481)) {
          case TAG_At: {
            V v_s_2483 = heff_dup(heff_field(v_c_2481, 1));
            v_t_2484 = v_s_2483;
            break;
          }
          default: heff_nomatch(v_c_2481);
          }
          v_t_2486 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2481}), v_t_2484});
          break;
        }
        case TAG_IsType: {
          V v_t_2485 = heff_field(v_x1_2476, 0);
          heff_take_n(v_x1_2476, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2486 = v_t_2485;
          break;
        }
        default: heff_nomatch(v_x1_2476);
        }
        V v_t_2487 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2473, v_xsp_2474, v_t_2486, v_t_2487, v_sp_243));
      }
      default: return heff_nomatch(v_x211_2443);
      }
    }
    case TAG_EAnn: {
      V v_a_2488 = heff_field(v_x21_242, 0);
      V v_t_2489 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2488}));
      V v_t_24100;
      switch (heff_tag_of(v_x1_2490)) {
      case TAG_IsInferable: {
        V v_i_2491 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        V v_t_2494;
        switch (heff_tag_of(v_i_2491)) {
        case TAG_At: {
          V v_s_2493 = heff_dup(heff_field(v_i_2491, 1));
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_i_2491);
        }
        v_t_24100 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2491}), v_t_2494});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2495 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24100 = v_c_2495;
        break;
      }
      case TAG_IsType: {
        V v_t_2496 = heff_field(v_x1_2490, 0);
        heff_take_n(v_x1_2490, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_t_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_t_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_t_2496);
        }
        v_t_24100 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2496}), v_t_2499});
        break;
      }
      default: heff_nomatch(v_x1_2490);
      }
      V v_x1_24101 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2489}));
      V v_t_24111;
      switch (heff_tag_of(v_x1_24101)) {
      case TAG_IsInferable: {
        V v_i_24102 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        V v_t_24105;
        switch (heff_tag_of(v_i_24102)) {
        case TAG_At: {
          V v_s_24104 = heff_dup(heff_field(v_i_24102, 1));
          v_t_24105 = v_s_24104;
          break;
        }
        default: heff_nomatch(v_i_24102);
        }
        v_t_24111 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24102}), v_t_24105});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24106 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        V v_t_24109;
        switch (heff_tag_of(v_c_24106)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_c_24106, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_c_24106);
        }
        v_t_24111 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24106}), v_t_24109});
        break;
      }
      case TAG_IsType: {
        V v_t_24110 = heff_field(v_x1_24101, 0);
        heff_take_n(v_x1_24101, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24111 = v_t_24110;
        break;
      }
      default: heff_nomatch(v_x1_24101);
      }
      V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24100, v_t_24111}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24112});
    }
    case TAG_ESpec: {
      V v_a_24113 = heff_field(v_x21_242, 0);
      V v_x_24114 = heff_field(v_x21_242, 1);
      V v_fsp_24115 = heff_field(v_x21_242, 2);
      V v_v_24116 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24ESpec = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_24117 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24113}));
      V v_t_24118 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24117));
      V v_x1_24119 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24116}));
      V v_t_24129;
      switch (heff_tag_of(v_x1_24119)) {
      case TAG_IsInferable: {
        V v_i_24120 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        V v_t_24123;
        switch (heff_tag_of(v_i_24120)) {
        case TAG_At: {
          V v_s_24122 = heff_dup(heff_field(v_i_24120, 1));
          v_t_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_i_24120);
        }
        v_t_24129 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24120}), v_t_24123});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24124 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24129 = v_c_24124;
        break;
      }
      case TAG_IsType: {
        V v_t_24125 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 1);
        V v_t_24128;
        switch (heff_tag_of(v_t_24125)) {
        case TAG_At: {
          V v_s_24127 = heff_dup(heff_field(v_t_24125, 1));
          v_t_24128 = v_s_24127;
          break;
        }
        default: heff_nomatch(v_t_24125);
        }
        v_t_24129 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24125}), v_t_24128});
        break;
      }
      default: heff_nomatch(v_x1_24119);
      }
      V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24118, v_x_24114, v_fsp_24115, v_t_24129}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24130});
    }
    case TAG_ESig: {
      V v_fs_24131 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24132 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo), 1, (V[]){v_r_240}));
      V v_t_24133 = (g_list_2emap(v_t_24132, v_fs_24131));
      V v_t_24134 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24133}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_IsType, 1, (V[]){v_t_24134});
    }
    case TAG_ESum: {
      V v_vs_24135 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24136 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2evariantOf_clo), 1, (V[]){v_r_240}));
      V v_t_24137 = (g_list_2emap(v_t_24136, v_vs_24135));
      V v_t_24138 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24137}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_IsType, 1, (V[]){v_t_24138});
    }
    case TAG_EStruct: {
      V v_fs_24139 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24140 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2efieldSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24141 = (g_list_2emap(v_t_24140, v_fs_24139));
      V v_t_24142 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24141}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_IsCheckable, 1, (V[]){v_t_24142});
    }
    case TAG_EUpdate: {
      V v_a_24143 = heff_field(v_x21_242, 0);
      V v_fs_24144 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24145 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24143}));
      V v_t_24146 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24145));
      V v_t_24147 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24148 = (g_list_2emap(v_t_24147, v_fs_24144));
      V v_t_24149 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24146, v_t_24148}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24149});
    }
    case TAG_EMatch: {
      V v_s_24150 = heff_field(v_x21_242, 0);
      V v_alts_24151 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24152 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24150}));
      V v_t_24153 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24152));
      V v_t_24154 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24155 = (g_list_2emap(v_t_24154, v_alts_24151));
      V v_t_24156 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24153, v_t_24155}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24156});
    }
    case TAG_ELetIn: {
      V v_rhs_24157 = heff_field(v_x21_242, 0);
      V v_a_24158 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24159 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24157}));
      V v_t_24160 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24159));
      V v_t_24176;
      switch (heff_tag_of(v_a_24158)) {
      case TAG_At: {
        V v_x21_24161 = heff_field(v_a_24158, 0);
        V v_sp_24162 = heff_field(v_a_24158, 1);
        heff_take_n(v_a_24158, 3ULL, 2);
        switch (heff_tag_of(v_x21_24161)) {
        case TAG_MkAlt: {
          V v_p_24163 = heff_field(v_x21_24161, 0);
          V v_b_24164 = heff_field(v_x21_24161, 1);
          heff_take_n(v_x21_24161, 3ULL, 2);
          V v_x1_24165 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_24164}));
          V v_t_24175;
          switch (heff_tag_of(v_x1_24165)) {
          case TAG_IsInferable: {
            V v_i_24166 = heff_field(v_x1_24165, 0);
            heff_take_n(v_x1_24165, 1ULL, 1);
            V v_t_24169;
            switch (heff_tag_of(v_i_24166)) {
            case TAG_At: {
              V v_s_24168 = heff_dup(heff_field(v_i_24166, 1));
              v_t_24169 = v_s_24168;
              break;
            }
            default: heff_nomatch(v_i_24166);
            }
            v_t_24175 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24166}), v_t_24169});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24170 = heff_field(v_x1_24165, 0);
            heff_take_n(v_x1_24165, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_24175 = v_c_24170;
            break;
          }
          case TAG_IsType: {
            V v_t_24171 = heff_field(v_x1_24165, 0);
            heff_take_n(v_x1_24165, 1ULL, 1);
            V v_t_24174;
            switch (heff_tag_of(v_t_24171)) {
            case TAG_At: {
              V v_s_24173 = heff_dup(heff_field(v_t_24171, 1));
              v_t_24174 = v_s_24173;
              break;
            }
            default: heff_nomatch(v_t_24171);
            }
            v_t_24175 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24171}), v_t_24174});
            break;
          }
          default: heff_nomatch(v_x1_24165);
          }
          v_t_24176 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24163, v_t_24175}), v_sp_24162});
          break;
        }
        default: heff_nomatch(v_x21_24161);
        }
        break;
      }
      default: heff_nomatch(v_a_24158);
      }
      V v_t_24177 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24160, v_t_24176}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24177});
    }
    case TAG_EDo: {
      V v_stmts_24178 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24179 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_24178));
      switch (heff_tag_of(v_t_24179)) {
      case TAG_Nil: {
        heff_drop_rec(v_r_240, 2);
        V v_t_24180 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3), NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24180, v_sp_243})});
      }
      case TAG_Cons: {
        V v_last_24181 = heff_field(v_t_24179, 0);
        V v_init_24182 = heff_field(v_t_24179, 1);
        heff_take_n(v_t_24179, 3ULL, 2);
        V v_init_24183 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_init_24182));
        V v_t_24193;
        switch (heff_tag_of(v_last_24181)) {
        case TAG_At: {
          V v_x31_24184 = heff_field(v_last_24181, 0);
          heff_take_n(v_last_24181, 1ULL, 2);
          switch (heff_tag_of(v_x31_24184)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24184, 0ULL, 3);
            heff_drop_cell(v_ru_24x21_242_24EDo, 1);
            heff_drop(v_init_24183);
            v_t_24193 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24184, 0ULL, 2);
            heff_drop_cell(v_ru_24x21_242_24EDo, 1);
            heff_drop(v_init_24183);
            v_t_24193 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24191 = heff_field(v_x31_24184, 0);
            heff_take_n(v_x31_24184, 1ULL, 1);
            V v_t_24192 = ({ V a_0 = heff_dup(v_sp_243); V a_1 = v_init_24183; V a_2 = v_e_24191; V r_ = (g_heff_2esyntax_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24183); r_; });
            v_t_24193 = heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_Just, 1, (V[]){v_t_24192});
            break;
          }
          default: heff_nomatch(v_x31_24184);
          }
          break;
        }
        default: heff_nomatch(v_last_24181);
        }
        switch (heff_tag_of(v_t_24193)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 2);
          V v_t_24194 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str4), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24194, v_sp_243})});
        }
        case TAG_Just: {
          V v_e_27_24195 = heff_field(v_t_24193, 0);
          heff_take_n(v_t_24193, 1ULL, 1);
          heff_drop(v_sp_243);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_27_24195});
        }
        default: return heff_nomatch(v_t_24193);
        }
      }
      default: return heff_nomatch(v_t_24179);
      }
    }
    case TAG_ELocal: {
      V v_body_24196 = heff_field(v_x21_242, 0);
      V v_ds_24197 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_24198 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24196}));
      V v_t_24208;
      switch (heff_tag_of(v_x1_24198)) {
      case TAG_IsInferable: {
        V v_i_24199 = heff_field(v_x1_24198, 0);
        heff_take_n(v_x1_24198, 1ULL, 1);
        V v_t_24202;
        switch (heff_tag_of(v_i_24199)) {
        case TAG_At: {
          V v_s_24201 = heff_dup(heff_field(v_i_24199, 1));
          v_t_24202 = v_s_24201;
          break;
        }
        default: heff_nomatch(v_i_24199);
        }
        v_t_24208 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24199}), v_t_24202});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24203 = heff_field(v_x1_24198, 0);
        heff_take_n(v_x1_24198, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24208 = v_c_24203;
        break;
      }
      case TAG_IsType: {
        V v_t_24204 = heff_field(v_x1_24198, 0);
        heff_take_n(v_x1_24198, 1ULL, 1);
        V v_t_24207;
        switch (heff_tag_of(v_t_24204)) {
        case TAG_At: {
          V v_s_24206 = heff_dup(heff_field(v_t_24204, 1));
          v_t_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_t_24204);
        }
        v_t_24208 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24204}), v_t_24207});
        break;
      }
      default: heff_nomatch(v_x1_24198);
      }
      V v_t_24209 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24197));
      V v_t_24210 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24208, v_t_24209}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24210});
    }
    case TAG_EInvalid: {
      V v_why_24211 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24212 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24211, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24212, v_sp_243})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ExplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_ImplicitParam: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      V v_xsp_2419 = heff_field(v_x21_242, 1);
      V v_t_2420 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ImplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2420}));
      V v_t_2431;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_IsInferable: {
        V v_i_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_i_2422)) {
        case TAG_At: {
          V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
          v_t_2425 = v_s_2424;
          break;
        }
        default: heff_nomatch(v_i_2422);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2426 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_c_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_c_2426);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
        break;
      }
      case TAG_IsType: {
        V v_t_2430 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2431 = v_t_2430;
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2418, v_xsp_2419, v_t_2431}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str0), NTAG(TAG_Nothing)});
    V v_t_2416;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_247 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_247)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_i_247, 1);
        heff_take_n(v_i_247, 2ULL, 2);
        v_t_2416 = v_s_249;
        break;
      }
      default: heff_nomatch(v_i_247);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_c_2410, 1);
        heff_take_n(v_c_2410, 2ULL, 2);
        v_t_2416 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 2ULL, 2);
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2417 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2416})});
    V v_t_2427;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2418 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2418)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_i_2418, 1);
        heff_take_n(v_i_2418, 2ULL, 2);
        v_t_2427 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_i_2418);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2421 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_field(v_c_2421, 1);
        heff_take_n(v_c_2421, 2ULL, 2);
        v_t_2427 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_c_2421);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2424 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_t_2424, 1);
        heff_take_n(v_t_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2427});
  }
  case TAG_IsType: {
    V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str1), NTAG(TAG_Nothing)});
    V v_t_2439;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2430 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2430)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_i_2430, 1);
        heff_take_n(v_i_2430, 2ULL, 2);
        v_t_2439 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_i_2430);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2433 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2433)) {
      case TAG_At: {
        V v_s_2435 = heff_field(v_c_2433, 1);
        heff_take_n(v_c_2433, 2ULL, 2);
        v_t_2439 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_c_2433);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2436 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_t_2436, 1);
        heff_take_n(v_t_2436, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2440 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2439})});
    V v_t_2450;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2441 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2441)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_i_2441, 1);
        heff_take_n(v_i_2441, 2ULL, 2);
        v_t_2450 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_i_2441);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2444 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2444)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_c_2444, 1);
        heff_take_n(v_c_2444, 2ULL, 2);
        v_t_2450 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_c_2444);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2447 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2447)) {
      case TAG_At: {
        V v_s_2449 = heff_field(v_t_2447, 1);
        heff_take_n(v_t_2447, 2ULL, 2);
        v_t_2450 = v_s_2449;
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_t_2450});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewatchOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_x1_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_243));
    V v_t_2414;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_IsInferable: {
      V v_i_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24IsInferable = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_t_248;
      switch (heff_tag_of(v_i_245)) {
      case TAG_At: {
        V v_s_247 = heff_dup(heff_field(v_i_245, 1));
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_i_245);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_244_24IsInferable, TAG_TInf, 1, (V[]){v_i_245}), v_t_248});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_249 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24IsCheckable = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_c_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_c_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_244_24IsCheckable, TAG_TChk, 1, (V[]){v_c_249}), v_t_2412});
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      v_t_2414 = v_t_2413;
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_xsp_242, v_t_2414});
  }
  case TAG_PiImplicit: {
    V v_x_2415 = heff_field(v_x2_240, 0);
    V v_xsp_2416 = heff_field(v_x2_240, 1);
    V v_bsp_2417 = heff_field(v_x2_240, 2);
    V v_t_2418 = heff_field(v_x2_240, 3);
    V v_d_2419 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_x1_2420 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2418));
    V v_t_2430;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_IsInferable: {
      V v_i_2421 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      V v_t_2424;
      switch (heff_tag_of(v_i_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_i_2421);
      }
      v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2425 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24IsCheckable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_c_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_c_2425);
      }
      v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
      break;
    }
    case TAG_IsType: {
      V v_t_2429 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 1);
      v_t_2430 = v_t_2429;
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    V v_t_2443;
    switch (heff_tag_of(v_d_2419)) {
    case TAG_Nothing: {
      v_t_2443 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2431 = heff_field(v_d_2419, 0);
      V v_ru_24d_2419_24Just = heff_take_reuse_n(v_d_2419, 1ULL, 1);
      V v_x1_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_2431));
      V v_t_2442;
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_IsInferable: {
        V v_i_2433 = heff_field(v_x1_2432, 0);
        V v_ru_24x1_2432_24IsInferable = heff_take_reuse_n(v_x1_2432, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_i_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_i_2433);
        }
        v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2432_24IsInferable, TAG_CInf, 1, (V[]){v_i_2433}), v_t_2436});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2437 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        v_t_2442 = v_c_2437;
        break;
      }
      case TAG_IsType: {
        V v_t_2438 = heff_field(v_x1_2432, 0);
        V v_ru_24x1_2432_24IsType = heff_take_reuse_n(v_x1_2432, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_t_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_t_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_t_2438);
        }
        v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2432_24IsType, TAG_CType, 1, (V[]){v_t_2438}), v_t_2441});
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      v_t_2443 = heff_tag_at_n(v_ru_24d_2419_24Just, TAG_Just, 1, (V[]){v_t_2442});
      break;
    }
    default: heff_nomatch(v_d_2419);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2415, v_xsp_2416, v_bsp_2417, v_t_2430, v_t_2443});
  }
  case TAG_PiInstance: {
    V v_x_2444 = heff_field(v_x2_240, 0);
    V v_xsp_2445 = heff_field(v_x2_240, 1);
    V v_bsp_2446 = heff_field(v_x2_240, 2);
    V v_t_2447 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_x1_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2447));
    V v_t_2458;
    switch (heff_tag_of(v_x1_2448)) {
    case TAG_IsInferable: {
      V v_i_2449 = heff_field(v_x1_2448, 0);
      V v_ru_24x1_2448_24IsInferable = heff_take_reuse_n(v_x1_2448, 1ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_i_2449)) {
      case TAG_At: {
        V v_s_2451 = heff_dup(heff_field(v_i_2449, 1));
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_i_2449);
      }
      v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2448_24IsInferable, TAG_TInf, 1, (V[]){v_i_2449}), v_t_2452});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2453 = heff_field(v_x1_2448, 0);
      V v_ru_24x1_2448_24IsCheckable = heff_take_reuse_n(v_x1_2448, 1ULL, 1);
      V v_t_2456;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_At: {
        V v_s_2455 = heff_dup(heff_field(v_c_2453, 1));
        v_t_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2448_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2453}), v_t_2456});
      break;
    }
    case TAG_IsType: {
      V v_t_2457 = heff_field(v_x1_2448, 0);
      heff_take_n(v_x1_2448, 1ULL, 1);
      v_t_2458 = v_t_2457;
      break;
    }
    default: heff_nomatch(v_x1_2448);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2444, v_xsp_2445, v_bsp_2446, v_t_2458});
  }
  case TAG_PiAnon: {
    V v_t_2459 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_x1_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2459));
    V v_t_2470;
    switch (heff_tag_of(v_x1_2460)) {
    case TAG_IsInferable: {
      V v_i_2461 = heff_field(v_x1_2460, 0);
      V v_ru_24x1_2460_24IsInferable = heff_take_reuse_n(v_x1_2460, 1ULL, 1);
      V v_t_2464;
      switch (heff_tag_of(v_i_2461)) {
      case TAG_At: {
        V v_s_2463 = heff_dup(heff_field(v_i_2461, 1));
        v_t_2464 = v_s_2463;
        break;
      }
      default: heff_nomatch(v_i_2461);
      }
      v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2460_24IsInferable, TAG_TInf, 1, (V[]){v_i_2461}), v_t_2464});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2465 = heff_field(v_x1_2460, 0);
      V v_ru_24x1_2460_24IsCheckable = heff_take_reuse_n(v_x1_2460, 1ULL, 1);
      V v_t_2468;
      switch (heff_tag_of(v_c_2465)) {
      case TAG_At: {
        V v_s_2467 = heff_dup(heff_field(v_c_2465, 1));
        v_t_2468 = v_s_2467;
        break;
      }
      default: heff_nomatch(v_c_2465);
      }
      v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2460_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2465}), v_t_2468});
      break;
    }
    case TAG_IsType: {
      V v_t_2469 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      v_t_2470 = v_t_2469;
      break;
    }
    default: heff_nomatch(v_x1_2460);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2470});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str2, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str3, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str4, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_243}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_IsInferable, 1, (V[]){v_t_244});
    }
    case TAG_EImplicitVar: {
      V v_x_245 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EImplicitVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_245}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_246});
    }
    case TAG_ETag: {
      V v_t_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ETag = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_248 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_247, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_241_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_248, v_sp_242})});
    }
    case TAG_EInt: {
      V v_i_249 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EInt = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_249}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_IsInferable, 1, (V[]){v_t_2410});
    }
    case TAG_EFloat: {
      double v_x_2411 = heff_tflat_f64(v_x21_241, 0);
      V v_ru_24x21_241_24EFloat = heff_take_reuse_na(v_x21_241, 0ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2411)}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2412});
    }
    case TAG_EString: {
      V v_x_2413 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EString = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2413}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EString, TAG_IsInferable, 1, (V[]){v_t_2414});
    }
    case TAG_EBinary: {
      V v_segs_2415 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_t_2416 = (g_heff_2esyntax_2epresyntax_2ewholeBinary(v_segs_2415, ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str0)));
      return (g_heff_2esyntax_2epresyntax_2ebinaryWith_24s715464553x270190051(v_segs_2415, v_sp_242, v_t_2416));
    }
    case TAG_ERune: {
      V v_c_2417 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ERune = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2417}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_IsInferable, 1, (V[]){v_t_2418});
    }
    case TAG_EWord: {
      V v_w_2419 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf(v_w_2419, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2420 = heff_field(v_x21_241, 0);
      V v_args_2421 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(v_h_2420, v_args_2421, v_sp_242));
    }
    case TAG_EProject: {
      V v_ru_24x21_241_24EProject = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      V v_t_2423 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str1), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_241_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2423, v_sp_242})});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_2426 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str2), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2426, v_sp_242})});
    }
    case TAG_EPi: {
      V v_b_2427 = heff_field(v_x21_241, 0);
      V v_cod_2428 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_2429 = (g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(v_b_2427));
      V v_x1_2430 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_cod_2428));
      V v_t_2440;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_IsInferable: {
        V v_i_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        V v_t_2434;
        switch (heff_tag_of(v_i_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_i_2431, 1));
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_i_2431);
        }
        v_t_2440 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2431}), v_t_2434});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2435 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        V v_t_2438;
        switch (heff_tag_of(v_c_2435)) {
        case TAG_At: {
          V v_s_2437 = heff_dup(heff_field(v_c_2435, 1));
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_c_2435);
        }
        v_t_2440 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2435}), v_t_2438});
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2440 = v_t_2439;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V v_t_2441 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2429, v_t_2440}), v_sp_242});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2441});
    }
    case TAG_ELam: {
      V v_x211_2442 = heff_field(v_x21_241, 0);
      V v_body_2443 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x211_2442)) {
      case TAG_LamName: {
        V v_x_2444 = heff_field(v_x211_2442, 0);
        V v_xsp_2445 = heff_field(v_x211_2442, 1);
        heff_take_n(v_x211_2442, 3ULL, 2);
        V v_x1_2446 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2443));
        V v_t_2456;
        switch (heff_tag_of(v_x1_2446)) {
        case TAG_IsInferable: {
          V v_i_2447 = heff_field(v_x1_2446, 0);
          heff_take_n(v_x1_2446, 1ULL, 1);
          V v_t_2450;
          switch (heff_tag_of(v_i_2447)) {
          case TAG_At: {
            V v_s_2449 = heff_dup(heff_field(v_i_2447, 1));
            v_t_2450 = v_s_2449;
            break;
          }
          default: heff_nomatch(v_i_2447);
          }
          v_t_2456 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2447}), v_t_2450});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2451 = heff_field(v_x1_2446, 0);
          heff_take_n(v_x1_2446, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          v_t_2456 = v_c_2451;
          break;
        }
        case TAG_IsType: {
          V v_t_2452 = heff_field(v_x1_2446, 0);
          heff_take_n(v_x1_2446, 1ULL, 1);
          V v_t_2455;
          switch (heff_tag_of(v_t_2452)) {
          case TAG_At: {
            V v_s_2454 = heff_dup(heff_field(v_t_2452, 1));
            v_t_2455 = v_s_2454;
            break;
          }
          default: heff_nomatch(v_t_2452);
          }
          v_t_2456 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2452}), v_t_2455});
          break;
        }
        default: heff_nomatch(v_x1_2446);
        }
        V v_t_2457 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2444, v_xsp_2445, v_t_2456}), v_sp_242});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2457});
      }
      case TAG_LamImplicit: {
        V v_x_2458 = heff_field(v_x211_2442, 0);
        V v_xsp_2459 = heff_field(v_x211_2442, 1);
        heff_take_n(v_x211_2442, 3ULL, 2);
        V v_x1_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2443));
        V v_t_2470;
        switch (heff_tag_of(v_x1_2460)) {
        case TAG_IsInferable: {
          V v_i_2461 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          V v_t_2464;
          switch (heff_tag_of(v_i_2461)) {
          case TAG_At: {
            V v_s_2463 = heff_dup(heff_field(v_i_2461, 1));
            v_t_2464 = v_s_2463;
            break;
          }
          default: heff_nomatch(v_i_2461);
          }
          v_t_2470 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2461}), v_t_2464});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2465 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          v_t_2470 = v_c_2465;
          break;
        }
        case TAG_IsType: {
          V v_t_2466 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          V v_t_2469;
          switch (heff_tag_of(v_t_2466)) {
          case TAG_At: {
            V v_s_2468 = heff_dup(heff_field(v_t_2466, 1));
            v_t_2469 = v_s_2468;
            break;
          }
          default: heff_nomatch(v_t_2466);
          }
          v_t_2470 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2466}), v_t_2469});
          break;
        }
        default: heff_nomatch(v_x1_2460);
        }
        V v_t_2471 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2458, v_xsp_2459, v_t_2470}), v_sp_242});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2471});
      }
      case TAG_LamAnn: {
        V v_x_2472 = heff_field(v_x211_2442, 0);
        V v_xsp_2473 = heff_field(v_x211_2442, 1);
        V v_t_2474 = heff_field(v_x211_2442, 2);
        heff_take_n(v_x211_2442, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_241_24ELam, 2);
        V v_x1_2475 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2474));
        V v_t_2485;
        switch (heff_tag_of(v_x1_2475)) {
        case TAG_IsInferable: {
          V v_i_2476 = heff_field(v_x1_2475, 0);
          heff_take_n(v_x1_2475, 1ULL, 1);
          V v_t_2479;
          switch (heff_tag_of(v_i_2476)) {
          case TAG_At: {
            V v_s_2478 = heff_dup(heff_field(v_i_2476, 1));
            v_t_2479 = v_s_2478;
            break;
          }
          default: heff_nomatch(v_i_2476);
          }
          v_t_2485 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2476}), v_t_2479});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2480 = heff_field(v_x1_2475, 0);
          heff_take_n(v_x1_2475, 1ULL, 1);
          V v_t_2483;
          switch (heff_tag_of(v_c_2480)) {
          case TAG_At: {
            V v_s_2482 = heff_dup(heff_field(v_c_2480, 1));
            v_t_2483 = v_s_2482;
            break;
          }
          default: heff_nomatch(v_c_2480);
          }
          v_t_2485 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2480}), v_t_2483});
          break;
        }
        case TAG_IsType: {
          V v_t_2484 = heff_field(v_x1_2475, 0);
          heff_take_n(v_x1_2475, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          v_t_2485 = v_t_2484;
          break;
        }
        default: heff_nomatch(v_x1_2475);
        }
        V v_t_2486 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2443));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2472, v_xsp_2473, v_t_2485, v_t_2486, v_sp_242));
      }
      default: return heff_nomatch(v_x211_2442);
      }
    }
    case TAG_EAnn: {
      V v_a_2487 = heff_field(v_x21_241, 0);
      V v_t_2488 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_2489 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_2487));
      V v_t_2499;
      switch (heff_tag_of(v_x1_2489)) {
      case TAG_IsInferable: {
        V v_i_2490 = heff_field(v_x1_2489, 0);
        heff_take_n(v_x1_2489, 1ULL, 1);
        V v_t_2493;
        switch (heff_tag_of(v_i_2490)) {
        case TAG_At: {
          V v_s_2492 = heff_dup(heff_field(v_i_2490, 1));
          v_t_2493 = v_s_2492;
          break;
        }
        default: heff_nomatch(v_i_2490);
        }
        v_t_2499 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2490}), v_t_2493});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2494 = heff_field(v_x1_2489, 0);
        heff_take_n(v_x1_2489, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2499 = v_c_2494;
        break;
      }
      case TAG_IsType: {
        V v_t_2495 = heff_field(v_x1_2489, 0);
        heff_take_n(v_x1_2489, 1ULL, 1);
        V v_t_2498;
        switch (heff_tag_of(v_t_2495)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_t_2495, 1));
          v_t_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_t_2495);
        }
        v_t_2499 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2495}), v_t_2498});
        break;
      }
      default: heff_nomatch(v_x1_2489);
      }
      V v_x1_24100 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2488));
      V v_t_24110;
      switch (heff_tag_of(v_x1_24100)) {
      case TAG_IsInferable: {
        V v_i_24101 = heff_field(v_x1_24100, 0);
        heff_take_n(v_x1_24100, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_i_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_i_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_i_24101);
        }
        v_t_24110 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24101}), v_t_24104});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24105 = heff_field(v_x1_24100, 0);
        heff_take_n(v_x1_24100, 1ULL, 1);
        V v_t_24108;
        switch (heff_tag_of(v_c_24105)) {
        case TAG_At: {
          V v_s_24107 = heff_dup(heff_field(v_c_24105, 1));
          v_t_24108 = v_s_24107;
          break;
        }
        default: heff_nomatch(v_c_24105);
        }
        v_t_24110 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24105}), v_t_24108});
        break;
      }
      case TAG_IsType: {
        V v_t_24109 = heff_field(v_x1_24100, 0);
        heff_take_n(v_x1_24100, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
        v_t_24110 = v_t_24109;
        break;
      }
      default: heff_nomatch(v_x1_24100);
      }
      V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2499, v_t_24110}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24111});
    }
    case TAG_ESpec: {
      V v_a_24112 = heff_field(v_x21_241, 0);
      V v_x_24113 = heff_field(v_x21_241, 1);
      V v_fsp_24114 = heff_field(v_x21_241, 2);
      V v_v_24115 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24ESpec = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_24116 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24112));
      V v_t_24117 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24116));
      V v_x1_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_v_24115));
      V v_t_24128;
      switch (heff_tag_of(v_x1_24118)) {
      case TAG_IsInferable: {
        V v_i_24119 = heff_field(v_x1_24118, 0);
        heff_take_n(v_x1_24118, 1ULL, 1);
        V v_t_24122;
        switch (heff_tag_of(v_i_24119)) {
        case TAG_At: {
          V v_s_24121 = heff_dup(heff_field(v_i_24119, 1));
          v_t_24122 = v_s_24121;
          break;
        }
        default: heff_nomatch(v_i_24119);
        }
        v_t_24128 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24119}), v_t_24122});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24123 = heff_field(v_x1_24118, 0);
        heff_take_n(v_x1_24118, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_24128 = v_c_24123;
        break;
      }
      case TAG_IsType: {
        V v_t_24124 = heff_field(v_x1_24118, 0);
        heff_take_n(v_x1_24118, 1ULL, 1);
        V v_t_24127;
        switch (heff_tag_of(v_t_24124)) {
        case TAG_At: {
          V v_s_24126 = heff_dup(heff_field(v_t_24124, 1));
          v_t_24127 = v_s_24126;
          break;
        }
        default: heff_nomatch(v_t_24124);
        }
        v_t_24128 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24124}), v_t_24127});
        break;
      }
      default: heff_nomatch(v_x1_24118);
      }
      V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24117, v_x_24113, v_fsp_24114, v_t_24128}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24129});
    }
    case TAG_ESig: {
      V v_fs_24130 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESig = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24131 = (g_list_2emap_24s1253308387x88241051(v_fs_24130));
      V v_t_24132 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24131}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_IsType, 1, (V[]){v_t_24132});
    }
    case TAG_ESum: {
      V v_vs_24133 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESum = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24134 = (g_list_2emap_24s503326960x1200444853(v_vs_24133));
      V v_t_24135 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24134}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_IsType, 1, (V[]){v_t_24135});
    }
    case TAG_EStruct: {
      V v_fs_24136 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EStruct = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24137 = (g_list_2emap_24s1374235278x875430684(v_fs_24136));
      V v_t_24138 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24137}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_IsCheckable, 1, (V[]){v_t_24138});
    }
    case TAG_EUpdate: {
      V v_a_24139 = heff_field(v_x21_241, 0);
      V v_fs_24140 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24141 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24139));
      V v_t_24142 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24141));
      V v_t_24143 = (g_list_2emap_24s137457135x961689574(v_fs_24140));
      V v_t_24144 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24142, v_t_24143}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24144});
    }
    case TAG_EMatch: {
      V v_s_24145 = heff_field(v_x21_241, 0);
      V v_alts_24146 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24147 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_s_24145));
      V v_t_24148 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24147));
      V v_t_24149 = (g_list_2emap_24s1230969749x2018313496(v_alts_24146));
      V v_t_24150 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24148, v_t_24149}), v_sp_242});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24150});
    }
    case TAG_ELetIn: {
      V v_rhs_24151 = heff_field(v_x21_241, 0);
      V v_a_24152 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24153 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_24151));
      V v_t_24154 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24153));
      V v_t_24170;
      switch (heff_tag_of(v_a_24152)) {
      case TAG_At: {
        V v_x21_24155 = heff_field(v_a_24152, 0);
        V v_sp_24156 = heff_field(v_a_24152, 1);
        heff_take_n(v_a_24152, 3ULL, 2);
        switch (heff_tag_of(v_x21_24155)) {
        case TAG_MkAlt: {
          V v_p_24157 = heff_field(v_x21_24155, 0);
          V v_b_24158 = heff_field(v_x21_24155, 1);
          heff_take_n(v_x21_24155, 3ULL, 2);
          V v_x1_24159 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_b_24158));
          V v_t_24169;
          switch (heff_tag_of(v_x1_24159)) {
          case TAG_IsInferable: {
            V v_i_24160 = heff_field(v_x1_24159, 0);
            heff_take_n(v_x1_24159, 1ULL, 1);
            V v_t_24163;
            switch (heff_tag_of(v_i_24160)) {
            case TAG_At: {
              V v_s_24162 = heff_dup(heff_field(v_i_24160, 1));
              v_t_24163 = v_s_24162;
              break;
            }
            default: heff_nomatch(v_i_24160);
            }
            v_t_24169 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24160}), v_t_24163});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24164 = heff_field(v_x1_24159, 0);
            heff_take_n(v_x1_24159, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            v_t_24169 = v_c_24164;
            break;
          }
          case TAG_IsType: {
            V v_t_24165 = heff_field(v_x1_24159, 0);
            heff_take_n(v_x1_24159, 1ULL, 1);
            V v_t_24168;
            switch (heff_tag_of(v_t_24165)) {
            case TAG_At: {
              V v_s_24167 = heff_dup(heff_field(v_t_24165, 1));
              v_t_24168 = v_s_24167;
              break;
            }
            default: heff_nomatch(v_t_24165);
            }
            v_t_24169 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24165}), v_t_24168});
            break;
          }
          default: heff_nomatch(v_x1_24159);
          }
          v_t_24170 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24157, v_t_24169}), v_sp_24156});
          break;
        }
        default: heff_nomatch(v_x21_24155);
        }
        break;
      }
      default: heff_nomatch(v_a_24152);
      }
      V v_t_24171 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24154, v_t_24170}), v_sp_242});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24171});
    }
    case TAG_EDo: {
      V v_stmts_24172 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EDo = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24173 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_24172));
      switch (heff_tag_of(v_t_24173)) {
      case TAG_Nil: {
        V v_t_24174 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str3), NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24174, v_sp_242})});
      }
      case TAG_Cons: {
        V v_last_24175 = heff_field(v_t_24173, 0);
        V v_init_24176 = heff_field(v_t_24173, 1);
        heff_take_n(v_t_24173, 3ULL, 2);
        V v_init_24177 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_init_24176));
        V v_t_24187;
        switch (heff_tag_of(v_last_24175)) {
        case TAG_At: {
          V v_x31_24178 = heff_field(v_last_24175, 0);
          heff_take_n(v_last_24175, 1ULL, 2);
          switch (heff_tag_of(v_x31_24178)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24178, 0ULL, 3);
            heff_drop_cell(v_ru_24x21_241_24EDo, 1);
            heff_drop(v_init_24177);
            v_t_24187 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24178, 0ULL, 2);
            heff_drop_cell(v_ru_24x21_241_24EDo, 1);
            heff_drop(v_init_24177);
            v_t_24187 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24185 = heff_field(v_x31_24178, 0);
            heff_take_n(v_x31_24178, 1ULL, 1);
            V v_t_24186 = ({ V a_0 = heff_dup(v_sp_242); V a_1 = v_init_24177; V a_2 = v_e_24185; V r_ = (g_heff_2esyntax_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24177); r_; });
            v_t_24187 = heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_Just, 1, (V[]){v_t_24186});
            break;
          }
          default: heff_nomatch(v_x31_24178);
          }
          break;
        }
        default: heff_nomatch(v_last_24175);
        }
        switch (heff_tag_of(v_t_24187)) {
        case TAG_Nothing: {
          V v_t_24188 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str4), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24188, v_sp_242})});
        }
        case TAG_Just: {
          V v_e_27_24189 = heff_field(v_t_24187, 0);
          heff_take_n(v_t_24187, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V t_0 = v_e_27_24189;
          v_x2_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_t_24187);
        }
      }
      default: return heff_nomatch(v_t_24173);
      }
    }
    case TAG_ELocal: {
      V v_body_24190 = heff_field(v_x21_241, 0);
      V v_ds_24191 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_24192 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_24190));
      V v_t_24202;
      switch (heff_tag_of(v_x1_24192)) {
      case TAG_IsInferable: {
        V v_i_24193 = heff_field(v_x1_24192, 0);
        heff_take_n(v_x1_24192, 1ULL, 1);
        V v_t_24196;
        switch (heff_tag_of(v_i_24193)) {
        case TAG_At: {
          V v_s_24195 = heff_dup(heff_field(v_i_24193, 1));
          v_t_24196 = v_s_24195;
          break;
        }
        default: heff_nomatch(v_i_24193);
        }
        v_t_24202 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24193}), v_t_24196});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24197 = heff_field(v_x1_24192, 0);
        heff_take_n(v_x1_24192, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_24202 = v_c_24197;
        break;
      }
      case TAG_IsType: {
        V v_t_24198 = heff_field(v_x1_24192, 0);
        heff_take_n(v_x1_24192, 1ULL, 1);
        V v_t_24201;
        switch (heff_tag_of(v_t_24198)) {
        case TAG_At: {
          V v_s_24200 = heff_dup(heff_field(v_t_24198, 1));
          v_t_24201 = v_s_24200;
          break;
        }
        default: heff_nomatch(v_t_24198);
        }
        v_t_24202 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24198}), v_t_24201});
        break;
      }
      default: heff_nomatch(v_x1_24192);
      }
      V v_t_24203 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2epresyntax_2eclassifier_get(), 1)), v_ds_24191));
      V v_t_24204 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24202, v_t_24203}), v_sp_242});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24204});
    }
    case TAG_EInvalid: {
      V v_why_24205 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EInvalid = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24206 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24205, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_241_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24206, v_sp_242})});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkEquation: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_ps_245 = heff_field(v_x21_241, 2);
      V v_rhs_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24MkEquation = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_246));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_243, v_fsp_244, v_ps_245, v_t_2417}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_t_243, 0);
      V v_sp_245 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_sp_242, v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_240, 0);
    V v_sp_248 = heff_field(v_x2_240, 1);
    V v_sp2_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = heff_field(v_x2_240, 3);
    V v_d_2411 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      V v_sp_2413 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2420;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_d_2411, 0);
      V v_ru_24d_2411_24Just = heff_take_reuse_n(v_d_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_n_2416 = heff_field(v_x_2415, 0);
        V v_sp_2417 = heff_field(v_x_2415, 1);
        V v_ru_24x_2415_24At = heff_take_reuse_n(v_x_2415, 3ULL, 2);
        V v_t_2418 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2415_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_2417});
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      v_t_2420 = heff_tag_at_n(v_ru_24d_2411_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_247, v_sp_248, v_sp2_249, v_t_2414, v_t_2420});
  }
  case TAG_PiInstance: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_sp2_2423 = heff_field(v_x2_240, 2);
    V v_t_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_t_2424, 0);
      V v_sp_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2426, v_n_2425));
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2421, v_sp_2422, v_sp2_2423, v_t_2427});
  }
  case TAG_PiAnon: {
    V v_t_2428 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_t_2428, 0);
      V v_sp_2430 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_IVar: {
    return v_n_240;
  }
  case TAG_IInt: {
    return v_n_240;
  }
  case TAG_IFloat: {
    return v_n_240;
  }
  case TAG_IString: {
    return v_n_240;
  }
  case TAG_IBytes: {
    return v_n_240;
  }
  case TAG_IPrim: {
    return v_n_240;
  }
  case TAG_IRune: {
    return v_n_240;
  }
  case TAG_IApp: {
    V v_h_248 = heff_field(v_n_240, 0);
    V v_args_249 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IApp = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_h_248)) {
    case TAG_At: {
      V v_n_2410 = heff_field(v_h_248, 0);
      V v_sp_2411 = heff_field(v_h_248, 1);
      V v_ru_24h_248_24At = heff_take_reuse_n(v_h_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2410));
      v_t_2413 = heff_tag_at_n(v_ru_24h_248_24At, TAG_At, 2, (V[]){v_t_2412, v_sp_2411});
      break;
    }
    default: heff_nomatch(v_h_248);
    }
    V v_t_2414 = (g_list_2emap_24s1150457979x1978067071(v_args_249));
    return heff_tag_at_n(v_ru_24n_240_24IApp, TAG_IApp, 2, (V[]){v_t_2413, v_t_2414});
  }
  case TAG_IAnn: {
    V v_c_2415 = heff_field(v_n_240, 0);
    V v_t_2416 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IAnn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_c_2415)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_c_2415, 0);
      V v_sp_2418 = heff_field(v_c_2415, 1);
      V v_ru_24c_2415_24At = heff_take_reuse_n(v_c_2415, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24c_2415_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_c_2415);
    }
    V v_t_2423;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_At: {
      V v_n_2421 = heff_field(v_t_2416, 0);
      V v_sp_2422 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 3ULL, 2);
      v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2422, v_n_2421));
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnn, TAG_IAnn, 2, (V[]){v_t_2420, v_t_2423});
  }
  case TAG_ISpec: {
    V v_a_2424 = heff_field(v_n_240, 0);
    V v_x_2425 = heff_field(v_n_240, 1);
    V v_sp_2426 = heff_field(v_n_240, 2);
    V v_v_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ISpec = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2431;
    switch (heff_tag_of(v_a_2424)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_a_2424, 0);
      V v_sp_2429 = heff_field(v_a_2424, 1);
      V v_ru_24a_2424_24At = heff_take_reuse_n(v_a_2424, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2428));
      v_t_2431 = heff_tag_at_n(v_ru_24a_2424_24At, TAG_At, 2, (V[]){v_t_2430, v_sp_2429});
      break;
    }
    default: heff_nomatch(v_a_2424);
    }
    V v_t_2435;
    switch (heff_tag_of(v_v_2427)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_v_2427, 0);
      V v_sp_2433 = heff_field(v_v_2427, 1);
      V v_ru_24v_2427_24At = heff_take_reuse_n(v_v_2427, 3ULL, 2);
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2432));
      v_t_2435 = heff_tag_at_n(v_ru_24v_2427_24At, TAG_At, 2, (V[]){v_t_2434, v_sp_2433});
      break;
    }
    default: heff_nomatch(v_v_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24ISpec, TAG_ISpec, 4, (V[]){v_t_2431, v_x_2425, v_sp_2426, v_t_2435});
  }
  case TAG_IUpdate: {
    V v_a_2436 = heff_field(v_n_240, 0);
    V v_fs_2437 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IUpdate = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2441;
    switch (heff_tag_of(v_a_2436)) {
    case TAG_At: {
      V v_n_2438 = heff_field(v_a_2436, 0);
      V v_sp_2439 = heff_field(v_a_2436, 1);
      V v_ru_24a_2436_24At = heff_take_reuse_n(v_a_2436, 3ULL, 2);
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2438));
      v_t_2441 = heff_tag_at_n(v_ru_24a_2436_24At, TAG_At, 2, (V[]){v_t_2440, v_sp_2439});
      break;
    }
    default: heff_nomatch(v_a_2436);
    }
    V v_t_2442 = (g_list_2emap_24s366989016x166432442(v_fs_2437));
    return heff_tag_at_n(v_ru_24n_240_24IUpdate, TAG_IUpdate, 2, (V[]){v_t_2441, v_t_2442});
  }
  case TAG_IAnnLam: {
    V v_x_2443 = heff_field(v_n_240, 0);
    V v_sp_2444 = heff_field(v_n_240, 1);
    V v_t_2445 = heff_field(v_n_240, 2);
    V v_b_2446 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24IAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2449;
    switch (heff_tag_of(v_t_2445)) {
    case TAG_At: {
      V v_n_2447 = heff_field(v_t_2445, 0);
      V v_sp_2448 = heff_field(v_t_2445, 1);
      heff_take_n(v_t_2445, 3ULL, 2);
      v_t_2449 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2448, v_n_2447));
      break;
    }
    default: heff_nomatch(v_t_2445);
    }
    V v_t_2453;
    switch (heff_tag_of(v_b_2446)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_b_2446, 0);
      V v_sp_2451 = heff_field(v_b_2446, 1);
      V v_ru_24b_2446_24At = heff_take_reuse_n(v_b_2446, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24b_2446_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_b_2446);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_x_2443, v_sp_2444, v_t_2449, v_t_2453});
  }
  case TAG_IInvalid: {
    return v_n_240;
  }
  case TAG_INominal: {
    return v_n_240;
  }
  case TAG_ILitEq: {
    V v_x_2458 = heff_field(v_n_240, 0);
    V v_sp_2459 = heff_field(v_n_240, 1);
    V v_eq_2460 = heff_field(v_n_240, 2);
    V v_lit_2461 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ILitEq = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2465;
    switch (heff_tag_of(v_lit_2461)) {
    case TAG_At: {
      V v_n_2462 = heff_field(v_lit_2461, 0);
      V v_sp_2463 = heff_field(v_lit_2461, 1);
      V v_ru_24lit_2461_24At = heff_take_reuse_n(v_lit_2461, 3ULL, 2);
      V v_t_2464 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2462));
      v_t_2465 = heff_tag_at_n(v_ru_24lit_2461_24At, TAG_At, 2, (V[]){v_t_2464, v_sp_2463});
      break;
    }
    default: heff_nomatch(v_lit_2461);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILitEq, TAG_ILitEq, 4, (V[]){v_x_2458, v_sp_2459, v_eq_2460, v_t_2465});
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_245 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_fs_246})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TSum, 1, (V[]){v_vs_248})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2411 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2415 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2417 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2425 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2426 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_i_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_i_2426, 0);
      V v_sp_2428 = heff_field(v_i_2426, 1);
      heff_take_n(v_i_2426, 3ULL, 2);
      v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_i_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2429}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2430 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_c_2430)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_c_2430, 0);
      V v_sp_2432 = heff_field(v_c_2430, 1);
      heff_take_n(v_c_2430, 3ULL, 2);
      v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
      break;
    }
    default: heff_nomatch(v_c_2430);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2433}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2436 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(a[0], a[1]);
}