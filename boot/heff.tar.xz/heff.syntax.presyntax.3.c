// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TypeWord 10401
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_end 310101
#define LBL_start 311115900
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2edoFrom(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoFrom_clo;
V g_heff_2esyntax_2epresyntax_2edoStep(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoStep_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2enatBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2enatBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2enatBytes_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo;
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2ereversedBytes(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eupdateSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2eupdateSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewholeBinary(V, V);
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1150457979x1978067071(V);
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s137457135x961689574(V);
V g_list_2emap_24s137457135x961689574_entry(V self, V *a);
extern Clo g_list_2emap_24s137457135x961689574_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s2016093283x1174801437(V, V);
V g_list_2emap_24s2016093283x1174801437_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_clo;
V g_list_2emap_24s2039279853x710813703(V, V);
V g_list_2emap_24s2039279853x710813703_entry(V self, V *a);
extern Clo g_list_2emap_24s2039279853x710813703_clo;
V g_list_2emap_24s205414595x1692305030(V);
V g_list_2emap_24s205414595x1692305030_entry(V self, V *a);
extern Clo g_list_2emap_24s205414595x1692305030_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s529174x2075875906(V);
V g_list_2emap_24s529174x2075875906_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s97919758x216970748(V, V);
V g_list_2emap_24s97919758x216970748_entry(V self, V *a);
extern Clo g_list_2emap_24s97919758x216970748_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2epresyntax_2ereversedBytes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereversedBytes_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereversedBytes(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    heff_drop(v_s_240);
    return v_acc_242;
  } else {
    V v_t_244 = heff_strSlice_lent(v_s_240, heff_box_word(v_i_241), heff_box_word((v_i_241 + ((int64_t)1ULL))), 6);
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_t_244, v_acc_242);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2esyntax_2epresyntax_2ereversedBytes_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ereversedBytes(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etwoTo_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etwoTo(V v_k_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etwoTo(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2elastOr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      V v_sp_245 = heff_dup(heff_field(v_f_240, 1));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_247 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2410;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_f_240, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2413;
        switch (heff_tag_of(v_x1_247)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x1_247, 1);
          heff_take_n(v_x1_247, 2ULL, 2);
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_x1_247);
        }
        V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2414});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2419;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2418 = heff_dup(heff_field(v_f_240, 1));
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2422;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2416, 1);
          heff_take_n(v_x1_2416, 2ULL, 2);
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      case TAG_ETag: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2425 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2428;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_f_240, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2431;
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x1_2425, 1);
          heff_take_n(v_x1_2425, 2ULL, 2);
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x1_2425);
        }
        V v_t_2432 = ({ V rv_1 = heff_get_n(v_t_2431, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2428, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2432});
      }
      case TAG_EInt: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2434 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2437;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_f_240, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2440;
        switch (heff_tag_of(v_x1_2434)) {
        case TAG_At: {
          V v_s_2439 = heff_field(v_x1_2434, 1);
          heff_take_n(v_x1_2434, 2ULL, 2);
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_x1_2434);
        }
        V v_t_2441 = ({ V rv_1 = heff_get_n(v_t_2440, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2437, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2441});
      }
      case TAG_EFloat: {
        heff_take_na(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2443 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2446;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2445 = heff_dup(heff_field(v_f_240, 1));
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2449;
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_At: {
          V v_s_2448 = heff_field(v_x1_2443, 1);
          heff_take_n(v_x1_2443, 2ULL, 2);
          v_t_2449 = v_s_2448;
          break;
        }
        default: heff_nomatch(v_x1_2443);
        }
        V v_t_2450 = ({ V rv_1 = heff_get_n(v_t_2449, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2446, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2450});
      }
      case TAG_EString: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2452 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2455;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2454 = heff_dup(heff_field(v_f_240, 1));
          v_t_2455 = v_s_2454;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2458;
        switch (heff_tag_of(v_x1_2452)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x1_2452, 1);
          heff_take_n(v_x1_2452, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x1_2452);
        }
        V v_t_2459 = ({ V rv_1 = heff_get_n(v_t_2458, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2455, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2459});
      }
      case TAG_EBinary: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2461 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2464;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2463 = heff_dup(heff_field(v_f_240, 1));
          v_t_2464 = v_s_2463;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2467;
        switch (heff_tag_of(v_x1_2461)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x1_2461, 1);
          heff_take_n(v_x1_2461, 2ULL, 2);
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x1_2461);
        }
        V v_t_2468 = ({ V rv_1 = heff_get_n(v_t_2467, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2464, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2468});
      }
      case TAG_ERune: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2470 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2473;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_f_240, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2476;
        switch (heff_tag_of(v_x1_2470)) {
        case TAG_At: {
          V v_s_2475 = heff_field(v_x1_2470, 1);
          heff_take_n(v_x1_2470, 2ULL, 2);
          v_t_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_x1_2470);
        }
        V v_t_2477 = ({ V rv_1 = heff_get_n(v_t_2476, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2473, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2477});
      }
      case TAG_EWord: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2479 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2482;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2481 = heff_dup(heff_field(v_f_240, 1));
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_2485;
        switch (heff_tag_of(v_x1_2479)) {
        case TAG_At: {
          V v_s_2484 = heff_field(v_x1_2479, 1);
          heff_take_n(v_x1_2479, 2ULL, 2);
          v_t_2485 = v_s_2484;
          break;
        }
        default: heff_nomatch(v_x1_2479);
        }
        V v_t_2486 = ({ V rv_1 = heff_get_n(v_t_2485, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2482, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2486});
      }
      case TAG_EApp: {
        V v_h_2487 = heff_field(v_f1_244, 0);
        V v_xs_2488 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        heff_drop_tag(v_f_240, 2);
        V v_t_2489 = (g_prelude_2e_2b_2b(v_xs_2488, heff_dup(v_args_241)));
        V v_x1_2490 = ({ V a_0 = heff_dup(v_h_2487); V a_1 = v_args_241; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
        V v_t_2493;
        switch (heff_tag_of(v_x1_2490)) {
        case TAG_At: {
          V v_s_2492 = heff_field(v_x1_2490, 1);
          heff_take_n(v_x1_2490, 2ULL, 2);
          v_t_2493 = v_s_2492;
          break;
        }
        default: heff_nomatch(v_x1_2490);
        }
        V v_t_2494 = ({ V rv_1 = heff_get_n(v_t_2493, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24f1_244_24EApp, TAG_EApp, 2, (V[]){v_h_2487, v_t_2489}), v_t_2494});
      }
      case TAG_EProject: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_2496 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2499;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_f_240, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24102;
        switch (heff_tag_of(v_x1_2496)) {
        case TAG_At: {
          V v_s_24101 = heff_field(v_x1_2496, 1);
          heff_take_n(v_x1_2496, 2ULL, 2);
          v_t_24102 = v_s_24101;
          break;
        }
        default: heff_nomatch(v_x1_2496);
        }
        V v_t_24103 = ({ V rv_1 = heff_get_n(v_t_24102, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2499, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24103});
      }
      case TAG_ENamed: {
        V v_ru_24f1_244_24ENamed = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24106 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24109;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_f_240, 1));
          v_t_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24112;
        switch (heff_tag_of(v_x1_24106)) {
        case TAG_At: {
          V v_s_24111 = heff_field(v_x1_24106, 1);
          heff_take_n(v_x1_24106, 2ULL, 2);
          v_t_24112 = v_s_24111;
          break;
        }
        default: heff_nomatch(v_x1_24106);
        }
        V v_t_24113 = ({ V rv_1 = heff_get_n(v_t_24112, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24109, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24113});
      }
      case TAG_EPi: {
        V v_ru_24f1_244_24EPi = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24116 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24119;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_f_240, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24122;
        switch (heff_tag_of(v_x1_24116)) {
        case TAG_At: {
          V v_s_24121 = heff_field(v_x1_24116, 1);
          heff_take_n(v_x1_24116, 2ULL, 2);
          v_t_24122 = v_s_24121;
          break;
        }
        default: heff_nomatch(v_x1_24116);
        }
        V v_t_24123 = ({ V rv_1 = heff_get_n(v_t_24122, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24119, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24123});
      }
      case TAG_ELam: {
        V v_ru_24f1_244_24ELam = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24126 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24129;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_f_240, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24132;
        switch (heff_tag_of(v_x1_24126)) {
        case TAG_At: {
          V v_s_24131 = heff_field(v_x1_24126, 1);
          heff_take_n(v_x1_24126, 2ULL, 2);
          v_t_24132 = v_s_24131;
          break;
        }
        default: heff_nomatch(v_x1_24126);
        }
        V v_t_24133 = ({ V rv_1 = heff_get_n(v_t_24132, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24129, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24133});
      }
      case TAG_EAnn: {
        V v_ru_24f1_244_24EAnn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24136 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24139;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24138 = heff_dup(heff_field(v_f_240, 1));
          v_t_24139 = v_s_24138;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24142;
        switch (heff_tag_of(v_x1_24136)) {
        case TAG_At: {
          V v_s_24141 = heff_field(v_x1_24136, 1);
          heff_take_n(v_x1_24136, 2ULL, 2);
          v_t_24142 = v_s_24141;
          break;
        }
        default: heff_nomatch(v_x1_24136);
        }
        V v_t_24143 = ({ V rv_1 = heff_get_n(v_t_24142, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24139, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24143});
      }
      case TAG_ESpec: {
        heff_take_n(v_f1_244, 0ULL, 4);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24148 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24151;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24150 = heff_dup(heff_field(v_f_240, 1));
          v_t_24151 = v_s_24150;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24154;
        switch (heff_tag_of(v_x1_24148)) {
        case TAG_At: {
          V v_s_24153 = heff_field(v_x1_24148, 1);
          heff_take_n(v_x1_24148, 2ULL, 2);
          v_t_24154 = v_s_24153;
          break;
        }
        default: heff_nomatch(v_x1_24148);
        }
        V v_t_24155 = ({ V rv_1 = heff_get_n(v_t_24154, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24151, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24155});
      }
      case TAG_ESig: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24157 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24160;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24159 = heff_dup(heff_field(v_f_240, 1));
          v_t_24160 = v_s_24159;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24163;
        switch (heff_tag_of(v_x1_24157)) {
        case TAG_At: {
          V v_s_24162 = heff_field(v_x1_24157, 1);
          heff_take_n(v_x1_24157, 2ULL, 2);
          v_t_24163 = v_s_24162;
          break;
        }
        default: heff_nomatch(v_x1_24157);
        }
        V v_t_24164 = ({ V rv_1 = heff_get_n(v_t_24163, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24160, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24164});
      }
      case TAG_ESum: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24166 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24169;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24168 = heff_dup(heff_field(v_f_240, 1));
          v_t_24169 = v_s_24168;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24172;
        switch (heff_tag_of(v_x1_24166)) {
        case TAG_At: {
          V v_s_24171 = heff_field(v_x1_24166, 1);
          heff_take_n(v_x1_24166, 2ULL, 2);
          v_t_24172 = v_s_24171;
          break;
        }
        default: heff_nomatch(v_x1_24166);
        }
        V v_t_24173 = ({ V rv_1 = heff_get_n(v_t_24172, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24169, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24173});
      }
      case TAG_EStruct: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24175 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24178;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24177 = heff_dup(heff_field(v_f_240, 1));
          v_t_24178 = v_s_24177;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24181;
        switch (heff_tag_of(v_x1_24175)) {
        case TAG_At: {
          V v_s_24180 = heff_field(v_x1_24175, 1);
          heff_take_n(v_x1_24175, 2ULL, 2);
          v_t_24181 = v_s_24180;
          break;
        }
        default: heff_nomatch(v_x1_24175);
        }
        V v_t_24182 = ({ V rv_1 = heff_get_n(v_t_24181, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24178, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24182});
      }
      case TAG_EUpdate: {
        V v_ru_24f1_244_24EUpdate = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24185 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24188;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24187 = heff_dup(heff_field(v_f_240, 1));
          v_t_24188 = v_s_24187;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24191;
        switch (heff_tag_of(v_x1_24185)) {
        case TAG_At: {
          V v_s_24190 = heff_field(v_x1_24185, 1);
          heff_take_n(v_x1_24185, 2ULL, 2);
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_x1_24185);
        }
        V v_t_24192 = ({ V rv_1 = heff_get_n(v_t_24191, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24188, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24192});
      }
      case TAG_EMatch: {
        V v_ru_24f1_244_24EMatch = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24195 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24198;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24197 = heff_dup(heff_field(v_f_240, 1));
          v_t_24198 = v_s_24197;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24201;
        switch (heff_tag_of(v_x1_24195)) {
        case TAG_At: {
          V v_s_24200 = heff_field(v_x1_24195, 1);
          heff_take_n(v_x1_24195, 2ULL, 2);
          v_t_24201 = v_s_24200;
          break;
        }
        default: heff_nomatch(v_x1_24195);
        }
        V v_t_24202 = ({ V rv_1 = heff_get_n(v_t_24201, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24198, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24202});
      }
      case TAG_ELetIn: {
        V v_ru_24f1_244_24ELetIn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24205 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24208;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24207 = heff_dup(heff_field(v_f_240, 1));
          v_t_24208 = v_s_24207;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24211;
        switch (heff_tag_of(v_x1_24205)) {
        case TAG_At: {
          V v_s_24210 = heff_field(v_x1_24205, 1);
          heff_take_n(v_x1_24205, 2ULL, 2);
          v_t_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_x1_24205);
        }
        V v_t_24212 = ({ V rv_1 = heff_get_n(v_t_24211, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24208, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24212});
      }
      case TAG_EDo: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24214 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24217;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24216 = heff_dup(heff_field(v_f_240, 1));
          v_t_24217 = v_s_24216;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24220;
        switch (heff_tag_of(v_x1_24214)) {
        case TAG_At: {
          V v_s_24219 = heff_field(v_x1_24214, 1);
          heff_take_n(v_x1_24214, 2ULL, 2);
          v_t_24220 = v_s_24219;
          break;
        }
        default: heff_nomatch(v_x1_24214);
        }
        V v_t_24221 = ({ V rv_1 = heff_get_n(v_t_24220, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24217, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24221});
      }
      case TAG_ELocal: {
        V v_ru_24f1_244_24ELocal = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24224 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24227;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24226 = heff_dup(heff_field(v_f_240, 1));
          v_t_24227 = v_s_24226;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24230;
        switch (heff_tag_of(v_x1_24224)) {
        case TAG_At: {
          V v_s_24229 = heff_field(v_x1_24224, 1);
          heff_take_n(v_x1_24224, 2ULL, 2);
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_x1_24224);
        }
        V v_t_24231 = ({ V rv_1 = heff_get_n(v_t_24230, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24227, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24231});
      }
      case TAG_EInvalid: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_x1_24233 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_24236;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24235 = heff_dup(heff_field(v_f_240, 1));
          v_t_24236 = v_s_24235;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_t_24239;
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_At: {
          V v_s_24238 = heff_field(v_x1_24233, 1);
          heff_take_n(v_x1_24233, 2ULL, 2);
          v_t_24239 = v_s_24238;
          break;
        }
        default: heff_nomatch(v_x1_24233);
        }
        V v_t_24240 = ({ V rv_1 = heff_get_n(v_t_24239, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24236, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24240});
      }
      default: return heff_nomatch(v_f1_244);
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eapp(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2edoFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edoFrom_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2edoFrom(V v_sp_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    return v_e_242;
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2edoFrom(heff_dup(v_sp_240), v_rest_244, v_e_242));
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2edoStep(v_sp_240, heff_dup(v_s_243), v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2edoFrom_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2edoFrom(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsInferable = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsInferable, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        V v_ru_24x1_2433_24IsType = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2433_24IsType, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24d_2420_24Just, TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsInferable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsInferable, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24IsCheckable = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2461_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          V v_ru_24x1_2420_24IsType = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsType, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_240, v_xsp_241, v_t_242, v_x4_243, v_sp_244));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_247});
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_247});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_247});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str3, 0, "");

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V v_x1_240, V v_little_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_v_242, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2etwoTo(MK_INT(8LL)));
    V v_b_247 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_box_word((((int64_t)8ULL) / ((int64_t)8ULL))), heff_intMod(v_t_245, v_t_246), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str0)));
    V v_f_248;
    if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
      v_f_248 = (g_heff_2esyntax_2epresyntax_2ereversedBytes(v_b_247, MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str1)));
    } else {
      v_f_248 = v_b_247;
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
  }
  case TAG_SizeNumber: {
    V v_n_249 = heff_field(v_x1_240, 0);
    if ((heff_unbox_word(heff_intMod(heff_dup(v_n_249), MK_INT(8LL))) == ((int64_t)0ULL))) {
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_t_2413 = heff_intAdd(heff_intMod(v_v_242, v_t_2411), v_t_2412);
      V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_dup(v_n_249)));
      V v_b_2415 = (g_heff_2esyntax_2epresyntax_2enatBytes(heff_intDiv(heff_dup(v_n_249), MK_INT(8LL)), heff_intMod(v_t_2413, v_t_2414), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str2)));
      V v_f_2416;
      if ((heff_dup(v_little_241) == NTAG(TAG_True))) {
        v_f_2416 = (g_heff_2esyntax_2epresyntax_2ereversedBytes(v_b_2415, MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr_str3)));
      } else {
        v_f_2416 = v_b_2415;
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
    } else {
      heff_drop(v_v_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_SizeName: {
    heff_drop(v_v_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2ewholeBinary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewholeBinary_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewholeBinary(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_seg_244 = heff_field(v_x11_242, 0);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_244));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_s_2410 = v_field_248;
          V t_0 = v_rest_243;
          V t_1 = heff_strAppend(v_acc_241, v_s_2410);
          v_x1_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop(v_field_248);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewholeBinary_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ewholeBinary(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str1, 4, "Cons");
Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elistOfChk_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elistOfChk(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str0), heff_dup(v_sp_241), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_xs_244, heff_dup(v_sp_241)));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str1), heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_246})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elistOfChk(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_249 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_248, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_249, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2410 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_2410}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_EFloat: {
      double v_x_2412 = heff_tflat_f64(v_x21_242, 0);
      V v_ru_24x21_242_24EFloat = heff_take_reuse_na(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2412)}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2413});
    }
    case TAG_EString: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EString, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_EBinary: {
      V v_segs_2416 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = v_r_240; V b_1 = NTAG(TAG_False); V a_2 = v_segs_2416; V a_3 = v_sp_243; V r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
    }
    case TAG_ERune: {
      V v_c_2417 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2417}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_IsInferable, 1, (V[]){v_t_2418});
    }
    case TAG_EWord: {
      V v_w_2419 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2ewordOf(v_w_2419, v_sp_243);
    }
    case TAG_EApp: {
      V v_h_2420 = heff_field(v_x21_242, 0);
      V v_args_2421 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2eappOf(v_r_240, v_h_2420, v_args_2421, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2423 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0), NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2423, v_sp_243})});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2426 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2426, v_sp_243})});
    }
    case TAG_EPi: {
      V v_b_2427 = heff_field(v_x21_242, 0);
      V v_cod_2428 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2429 = (g_heff_2esyntax_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2427));
      V v_x1_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2428}));
      V v_t_2440;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_IsInferable: {
        V v_i_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        V v_t_2434;
        switch (heff_tag_of(v_i_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_dup(heff_field(v_i_2431, 1));
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_i_2431);
        }
        v_t_2440 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2431}), v_t_2434});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2435 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        V v_t_2438;
        switch (heff_tag_of(v_c_2435)) {
        case TAG_At: {
          V v_s_2437 = heff_dup(heff_field(v_c_2435, 1));
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_c_2435);
        }
        v_t_2440 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2435}), v_t_2438});
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2440 = v_t_2439;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V v_t_2441 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2429, v_t_2440}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2441});
    }
    case TAG_ELam: {
      V v_x211_2442 = heff_field(v_x21_242, 0);
      V v_body_2443 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2442)) {
      case TAG_LamName: {
        V v_x_2444 = heff_field(v_x211_2442, 0);
        V v_xsp_2445 = heff_field(v_x211_2442, 1);
        heff_take_n(v_x211_2442, 3ULL, 2);
        V v_x1_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2443}));
        V v_t_2456;
        switch (heff_tag_of(v_x1_2446)) {
        case TAG_IsInferable: {
          V v_i_2447 = heff_field(v_x1_2446, 0);
          heff_take_n(v_x1_2446, 1ULL, 1);
          V v_t_2450;
          switch (heff_tag_of(v_i_2447)) {
          case TAG_At: {
            V v_s_2449 = heff_dup(heff_field(v_i_2447, 1));
            v_t_2450 = v_s_2449;
            break;
          }
          default: heff_nomatch(v_i_2447);
          }
          v_t_2456 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2447}), v_t_2450});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2451 = heff_field(v_x1_2446, 0);
          heff_take_n(v_x1_2446, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2456 = v_c_2451;
          break;
        }
        case TAG_IsType: {
          V v_t_2452 = heff_field(v_x1_2446, 0);
          heff_take_n(v_x1_2446, 1ULL, 1);
          V v_t_2455;
          switch (heff_tag_of(v_t_2452)) {
          case TAG_At: {
            V v_s_2454 = heff_dup(heff_field(v_t_2452, 1));
            v_t_2455 = v_s_2454;
            break;
          }
          default: heff_nomatch(v_t_2452);
          }
          v_t_2456 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2452}), v_t_2455});
          break;
        }
        default: heff_nomatch(v_x1_2446);
        }
        V v_t_2457 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2444, v_xsp_2445, v_t_2456}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2457});
      }
      case TAG_LamImplicit: {
        V v_x_2458 = heff_field(v_x211_2442, 0);
        V v_xsp_2459 = heff_field(v_x211_2442, 1);
        heff_take_n(v_x211_2442, 3ULL, 2);
        V v_x1_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2443}));
        V v_t_2470;
        switch (heff_tag_of(v_x1_2460)) {
        case TAG_IsInferable: {
          V v_i_2461 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          V v_t_2464;
          switch (heff_tag_of(v_i_2461)) {
          case TAG_At: {
            V v_s_2463 = heff_dup(heff_field(v_i_2461, 1));
            v_t_2464 = v_s_2463;
            break;
          }
          default: heff_nomatch(v_i_2461);
          }
          v_t_2470 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2461}), v_t_2464});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2465 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2470 = v_c_2465;
          break;
        }
        case TAG_IsType: {
          V v_t_2466 = heff_field(v_x1_2460, 0);
          heff_take_n(v_x1_2460, 1ULL, 1);
          V v_t_2469;
          switch (heff_tag_of(v_t_2466)) {
          case TAG_At: {
            V v_s_2468 = heff_dup(heff_field(v_t_2466, 1));
            v_t_2469 = v_s_2468;
            break;
          }
          default: heff_nomatch(v_t_2466);
          }
          v_t_2470 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2466}), v_t_2469});
          break;
        }
        default: heff_nomatch(v_x1_2460);
        }
        V v_t_2471 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2458, v_xsp_2459, v_t_2470}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2471});
      }
      case TAG_LamAnn: {
        V v_x_2472 = heff_field(v_x211_2442, 0);
        V v_xsp_2473 = heff_field(v_x211_2442, 1);
        V v_t_2474 = heff_field(v_x211_2442, 2);
        heff_take_n(v_x211_2442, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        V v_x1_2475 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2474}));
        V v_t_2485;
        switch (heff_tag_of(v_x1_2475)) {
        case TAG_IsInferable: {
          V v_i_2476 = heff_field(v_x1_2475, 0);
          heff_take_n(v_x1_2475, 1ULL, 1);
          V v_t_2479;
          switch (heff_tag_of(v_i_2476)) {
          case TAG_At: {
            V v_s_2478 = heff_dup(heff_field(v_i_2476, 1));
            v_t_2479 = v_s_2478;
            break;
          }
          default: heff_nomatch(v_i_2476);
          }
          v_t_2485 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2476}), v_t_2479});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2480 = heff_field(v_x1_2475, 0);
          heff_take_n(v_x1_2475, 1ULL, 1);
          V v_t_2483;
          switch (heff_tag_of(v_c_2480)) {
          case TAG_At: {
            V v_s_2482 = heff_dup(heff_field(v_c_2480, 1));
            v_t_2483 = v_s_2482;
            break;
          }
          default: heff_nomatch(v_c_2480);
          }
          v_t_2485 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2480}), v_t_2483});
          break;
        }
        case TAG_IsType: {
          V v_t_2484 = heff_field(v_x1_2475, 0);
          heff_take_n(v_x1_2475, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2485 = v_t_2484;
          break;
        }
        default: heff_nomatch(v_x1_2475);
        }
        V v_t_2486 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2443}));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2472, v_xsp_2473, v_t_2485, v_t_2486, v_sp_243));
      }
      default: return heff_nomatch(v_x211_2442);
      }
    }
    case TAG_EAnn: {
      V v_a_2487 = heff_field(v_x21_242, 0);
      V v_t_2488 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_2489 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2487}));
      V v_t_2499;
      switch (heff_tag_of(v_x1_2489)) {
      case TAG_IsInferable: {
        V v_i_2490 = heff_field(v_x1_2489, 0);
        heff_take_n(v_x1_2489, 1ULL, 1);
        V v_t_2493;
        switch (heff_tag_of(v_i_2490)) {
        case TAG_At: {
          V v_s_2492 = heff_dup(heff_field(v_i_2490, 1));
          v_t_2493 = v_s_2492;
          break;
        }
        default: heff_nomatch(v_i_2490);
        }
        v_t_2499 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2490}), v_t_2493});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2494 = heff_field(v_x1_2489, 0);
        heff_take_n(v_x1_2489, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2499 = v_c_2494;
        break;
      }
      case TAG_IsType: {
        V v_t_2495 = heff_field(v_x1_2489, 0);
        heff_take_n(v_x1_2489, 1ULL, 1);
        V v_t_2498;
        switch (heff_tag_of(v_t_2495)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_t_2495, 1));
          v_t_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_t_2495);
        }
        v_t_2499 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2495}), v_t_2498});
        break;
      }
      default: heff_nomatch(v_x1_2489);
      }
      V v_x1_24100 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2488}));
      V v_t_24110;
      switch (heff_tag_of(v_x1_24100)) {
      case TAG_IsInferable: {
        V v_i_24101 = heff_field(v_x1_24100, 0);
        heff_take_n(v_x1_24100, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_i_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_i_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_i_24101);
        }
        v_t_24110 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24101}), v_t_24104});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24105 = heff_field(v_x1_24100, 0);
        heff_take_n(v_x1_24100, 1ULL, 1);
        V v_t_24108;
        switch (heff_tag_of(v_c_24105)) {
        case TAG_At: {
          V v_s_24107 = heff_dup(heff_field(v_c_24105, 1));
          v_t_24108 = v_s_24107;
          break;
        }
        default: heff_nomatch(v_c_24105);
        }
        v_t_24110 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24105}), v_t_24108});
        break;
      }
      case TAG_IsType: {
        V v_t_24109 = heff_field(v_x1_24100, 0);
        heff_take_n(v_x1_24100, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24110 = v_t_24109;
        break;
      }
      default: heff_nomatch(v_x1_24100);
      }
      V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2499, v_t_24110}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24111});
    }
    case TAG_ESpec: {
      V v_a_24112 = heff_field(v_x21_242, 0);
      V v_x_24113 = heff_field(v_x21_242, 1);
      V v_fsp_24114 = heff_field(v_x21_242, 2);
      V v_v_24115 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24ESpec = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_24116 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24112}));
      V v_t_24117 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24116));
      V v_x1_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24115}));
      V v_t_24128;
      switch (heff_tag_of(v_x1_24118)) {
      case TAG_IsInferable: {
        V v_i_24119 = heff_field(v_x1_24118, 0);
        heff_take_n(v_x1_24118, 1ULL, 1);
        V v_t_24122;
        switch (heff_tag_of(v_i_24119)) {
        case TAG_At: {
          V v_s_24121 = heff_dup(heff_field(v_i_24119, 1));
          v_t_24122 = v_s_24121;
          break;
        }
        default: heff_nomatch(v_i_24119);
        }
        v_t_24128 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24119}), v_t_24122});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24123 = heff_field(v_x1_24118, 0);
        heff_take_n(v_x1_24118, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24128 = v_c_24123;
        break;
      }
      case TAG_IsType: {
        V v_t_24124 = heff_field(v_x1_24118, 0);
        heff_take_n(v_x1_24118, 1ULL, 1);
        V v_t_24127;
        switch (heff_tag_of(v_t_24124)) {
        case TAG_At: {
          V v_s_24126 = heff_dup(heff_field(v_t_24124, 1));
          v_t_24127 = v_s_24126;
          break;
        }
        default: heff_nomatch(v_t_24124);
        }
        v_t_24128 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24124}), v_t_24127});
        break;
      }
      default: heff_nomatch(v_x1_24118);
      }
      V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24117, v_x_24113, v_fsp_24114, v_t_24128}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24129});
    }
    case TAG_ESig: {
      V v_fs_24130 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24131 = (g_list_2emap_24s2016093283x1174801437(v_r_240, v_fs_24130));
      V v_t_24132 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24131}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_IsType, 1, (V[]){v_t_24132});
    }
    case TAG_ESum: {
      V v_vs_24133 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24134 = (g_list_2emap_24s97919758x216970748(v_r_240, v_vs_24133));
      V v_t_24135 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24134}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_IsType, 1, (V[]){v_t_24135});
    }
    case TAG_EStruct: {
      V v_fs_24136 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24137 = (g_list_2emap_24s2039279853x710813703(v_r_240, v_fs_24136));
      V v_t_24138 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24137}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_IsCheckable, 1, (V[]){v_t_24138});
    }
    case TAG_EUpdate: {
      V v_a_24139 = heff_field(v_x21_242, 0);
      V v_fs_24140 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24141 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24139}));
      V v_t_24142 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24141));
      V v_t_24143 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eupdateSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24144 = (g_list_2emap(v_t_24143, v_fs_24140));
      V v_t_24145 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24142, v_t_24144}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24145});
    }
    case TAG_EMatch: {
      V v_s_24146 = heff_field(v_x21_242, 0);
      V v_alts_24147 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_24148 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24146}));
      V v_t_24149 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24148));
      V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24151 = (g_list_2emap(v_t_24150, v_alts_24147));
      V v_t_24152 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24149, v_t_24151}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24152});
    }
    case TAG_ELetIn: {
      V v_rhs_24153 = heff_field(v_x21_242, 0);
      V v_a_24154 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24155 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24153}));
      V v_t_24156 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24155));
      V v_t_24172;
      switch (heff_tag_of(v_a_24154)) {
      case TAG_At: {
        V v_x21_24157 = heff_field(v_a_24154, 0);
        V v_sp_24158 = heff_field(v_a_24154, 1);
        heff_take_n(v_a_24154, 3ULL, 2);
        switch (heff_tag_of(v_x21_24157)) {
        case TAG_MkAlt: {
          V v_p_24159 = heff_field(v_x21_24157, 0);
          V v_b_24160 = heff_field(v_x21_24157, 1);
          heff_take_n(v_x21_24157, 3ULL, 2);
          V v_x1_24161 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_24160}));
          V v_t_24171;
          switch (heff_tag_of(v_x1_24161)) {
          case TAG_IsInferable: {
            V v_i_24162 = heff_field(v_x1_24161, 0);
            heff_take_n(v_x1_24161, 1ULL, 1);
            V v_t_24165;
            switch (heff_tag_of(v_i_24162)) {
            case TAG_At: {
              V v_s_24164 = heff_dup(heff_field(v_i_24162, 1));
              v_t_24165 = v_s_24164;
              break;
            }
            default: heff_nomatch(v_i_24162);
            }
            v_t_24171 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24162}), v_t_24165});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24166 = heff_field(v_x1_24161, 0);
            heff_take_n(v_x1_24161, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_24171 = v_c_24166;
            break;
          }
          case TAG_IsType: {
            V v_t_24167 = heff_field(v_x1_24161, 0);
            heff_take_n(v_x1_24161, 1ULL, 1);
            V v_t_24170;
            switch (heff_tag_of(v_t_24167)) {
            case TAG_At: {
              V v_s_24169 = heff_dup(heff_field(v_t_24167, 1));
              v_t_24170 = v_s_24169;
              break;
            }
            default: heff_nomatch(v_t_24167);
            }
            v_t_24171 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24167}), v_t_24170});
            break;
          }
          default: heff_nomatch(v_x1_24161);
          }
          v_t_24172 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24159, v_t_24171}), v_sp_24158});
          break;
        }
        default: heff_nomatch(v_x21_24157);
        }
        break;
      }
      default: heff_nomatch(v_a_24154);
      }
      V v_t_24173 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24156, v_t_24172}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24173});
    }
    case TAG_EDo: {
      V v_stmts_24174 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24175 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_24174));
      switch (heff_tag_of(v_t_24175)) {
      case TAG_Nil: {
        heff_drop_rec(v_r_240, 2);
        V v_t_24176 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2), NTAG(TAG_Nothing)});
        return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24176, v_sp_243})});
      }
      case TAG_Cons: {
        V v_last_24177 = heff_field(v_t_24175, 0);
        V v_init_24178 = heff_field(v_t_24175, 1);
        heff_take_n(v_t_24175, 3ULL, 2);
        V v_init_24179 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_init_24178));
        V v_t_24189;
        switch (heff_tag_of(v_last_24177)) {
        case TAG_At: {
          V v_x31_24180 = heff_field(v_last_24177, 0);
          heff_take_n(v_last_24177, 1ULL, 2);
          switch (heff_tag_of(v_x31_24180)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24180, 0ULL, 3);
            heff_drop_cell(v_ru_24x21_242_24EDo, 1);
            heff_drop(v_init_24179);
            v_t_24189 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24180, 0ULL, 2);
            heff_drop_cell(v_ru_24x21_242_24EDo, 1);
            heff_drop(v_init_24179);
            v_t_24189 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24187 = heff_field(v_x31_24180, 0);
            heff_take_n(v_x31_24180, 1ULL, 1);
            V v_t_24188 = ({ V a_0 = heff_dup(v_sp_243); V a_1 = v_init_24179; V a_2 = v_e_24187; V r_ = (g_heff_2esyntax_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24179); r_; });
            v_t_24189 = heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_Just, 1, (V[]){v_t_24188});
            break;
          }
          default: heff_nomatch(v_x31_24180);
          }
          break;
        }
        default: heff_nomatch(v_last_24177);
        }
        switch (heff_tag_of(v_t_24189)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 2);
          V v_t_24190 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24190, v_sp_243})});
        }
        case TAG_Just: {
          V v_e_27_24191 = heff_field(v_t_24189, 0);
          heff_take_n(v_t_24189, 1ULL, 1);
          heff_drop(v_sp_243);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_27_24191});
        }
        default: return heff_nomatch(v_t_24189);
        }
      }
      default: return heff_nomatch(v_t_24175);
      }
    }
    case TAG_ELocal: {
      V v_body_24192 = heff_field(v_x21_242, 0);
      V v_ds_24193 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_24194 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24192}));
      V v_t_24204;
      switch (heff_tag_of(v_x1_24194)) {
      case TAG_IsInferable: {
        V v_i_24195 = heff_field(v_x1_24194, 0);
        heff_take_n(v_x1_24194, 1ULL, 1);
        V v_t_24198;
        switch (heff_tag_of(v_i_24195)) {
        case TAG_At: {
          V v_s_24197 = heff_dup(heff_field(v_i_24195, 1));
          v_t_24198 = v_s_24197;
          break;
        }
        default: heff_nomatch(v_i_24195);
        }
        v_t_24204 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24195}), v_t_24198});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24199 = heff_field(v_x1_24194, 0);
        heff_take_n(v_x1_24194, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24204 = v_c_24199;
        break;
      }
      case TAG_IsType: {
        V v_t_24200 = heff_field(v_x1_24194, 0);
        heff_take_n(v_x1_24194, 1ULL, 1);
        V v_t_24203;
        switch (heff_tag_of(v_t_24200)) {
        case TAG_At: {
          V v_s_24202 = heff_dup(heff_field(v_t_24200, 1));
          v_t_24203 = v_s_24202;
          break;
        }
        default: heff_nomatch(v_t_24200);
        }
        v_t_24204 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24200}), v_t_24203});
        break;
      }
      default: heff_nomatch(v_x1_24194);
      }
      V v_t_24205 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24193));
      V v_t_24206 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24204, v_t_24205}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24206});
    }
    case TAG_EInvalid: {
      V v_why_24207 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24208 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24207, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24208, v_sp_243})});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ExplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_ImplicitParam: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      V v_xsp_2419 = heff_field(v_x21_242, 1);
      V v_t_2420 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ImplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2420}));
      V v_t_2431;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_IsInferable: {
        V v_i_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_i_2422)) {
        case TAG_At: {
          V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
          v_t_2425 = v_s_2424;
          break;
        }
        default: heff_nomatch(v_i_2422);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2426 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_c_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_c_2426);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
        break;
      }
      case TAG_IsType: {
        V v_t_2430 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2431 = v_t_2430;
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2418, v_xsp_2419, v_t_2431}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str0), NTAG(TAG_Nothing)});
    V v_t_2416;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_247 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_247)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_i_247, 1);
        heff_take_n(v_i_247, 2ULL, 2);
        v_t_2416 = v_s_249;
        break;
      }
      default: heff_nomatch(v_i_247);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_c_2410, 1);
        heff_take_n(v_c_2410, 2ULL, 2);
        v_t_2416 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 2ULL, 2);
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2417 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2416})});
    V v_t_2427;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2418 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2418)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_i_2418, 1);
        heff_take_n(v_i_2418, 2ULL, 2);
        v_t_2427 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_i_2418);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2421 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_field(v_c_2421, 1);
        heff_take_n(v_c_2421, 2ULL, 2);
        v_t_2427 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_c_2421);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2424 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_t_2424, 1);
        heff_take_n(v_t_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2427});
  }
  case TAG_IsType: {
    V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str1), NTAG(TAG_Nothing)});
    V v_t_2439;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2430 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2430)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_i_2430, 1);
        heff_take_n(v_i_2430, 2ULL, 2);
        v_t_2439 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_i_2430);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2433 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2433)) {
      case TAG_At: {
        V v_s_2435 = heff_field(v_c_2433, 1);
        heff_take_n(v_c_2433, 2ULL, 2);
        v_t_2439 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_c_2433);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2436 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_t_2436, 1);
        heff_take_n(v_t_2436, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2440 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2439})});
    V v_t_2450;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2441 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2441)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_i_2441, 1);
        heff_take_n(v_i_2441, 2ULL, 2);
        v_t_2450 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_i_2441);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2444 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2444)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_c_2444, 1);
        heff_take_n(v_c_2444, 2ULL, 2);
        v_t_2450 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_c_2444);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2447 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2447)) {
      case TAG_At: {
        V v_s_2449 = heff_field(v_t_2447, 1);
        heff_take_n(v_t_2447, 2ULL, 2);
        v_t_2450 = v_s_2449;
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_t_2450});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewatchOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(V v_lit_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop(v_lit_240);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IBytes, 1, (V[]){v_s_245}), heff_dup(v_sp_246)});
        V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_247}), heff_dup(v_sp_246)});
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        V v_a_2410 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_246), v_t_249));
        V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_lit_240}), heff_dup(v_sp_246)});
        V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2411, v_a_2410}), heff_dup(v_sp_246)});
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2412}), v_sp_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_2414 = heff_field(v_x2_241, 0);
    V v_rest_2415 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2414)) {
    case TAG_At: {
      V v_seg_2416 = heff_field(v_x21_2414, 0);
      V v_sp_2417 = heff_field(v_x21_2414, 1);
      V v_ru_24x21_2414_24At = heff_take_reuse_n(v_x21_2414, 3ULL, 2);
      HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2416));
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2416);
          heff_drop_cell(v_ru_24x21_2414_24At, 2);
          V v_s_2422 = v_field_2420;
          V v_t_2428;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2422, v_sp_2417})});
            break;
          }
          case TAG_Just: {
            V v_x11_2423 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2423)) {
            case TAG_MkPair: {
              V v_s0_2424 = heff_field(v_x11_2423, 0);
              V v_sp0_2425 = heff_field(v_x11_2423, 1);
              V v_ru_24x11_2423_24MkPair = heff_take_reuse_n(v_x11_2423, 3ULL, 2);
              V v_t_2426 = ({ V rv_1 = heff_get_n(v_sp_2417, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2425, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2427 = heff_tag_at_n(v_ru_24x11_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2424, v_s_2422), v_t_2426});
              v_t_2428 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2427});
              break;
            }
            default: heff_nomatch(v_x11_2423);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = v_t_2428;
          V t_3 = v_acc_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2420);
          V v_t_2429 = (g_heff_2esyntax_2epresyntax_2ebitsPart_24s1464660178x99199498(heff_tag_at_n(v_ru_24x21_2414_24At, TAG_At, 2, (V[]){v_seg_2416, v_sp_2417})));
          V v_t_2440;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2440 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2430 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2430)) {
            case TAG_MkPair: {
              V v_s_2431 = heff_field(v_x21_2430, 0);
              V v_sp_2432 = heff_field(v_x21_2430, 1);
              V v_ru_24x21_2430_24MkPair = heff_take_reuse_n(v_x21_2430, 3ULL, 2);
              V v_t_2433 = heff_tag_at_n(v_ru_24x21_2430_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IBytes, 1, (V[]){v_s_2431}), heff_dup(v_sp_2432)});
              V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), heff_dup(v_sp_2432)});
              V v_t_2435 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2434, NTAG(TAG_Nil)});
              V v_a_2436 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2432), v_t_2435));
              V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){heff_dup(v_lit_240)}), heff_dup(v_sp_2432)});
              V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2437, v_a_2436}), heff_dup(v_sp_2432)});
              V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2438}), v_sp_2432});
              v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2430);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2440});
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_2414);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4, 10, "bitsConcat");

HeffT2 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V v_segs_240, V v_sp_241, V v_x5_242) {
top: ;
  if ((heff_dup(v_x5_242) == NTAG(TAG_True))) {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_241)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_241)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2)}), heff_dup(v_sp_241)});
    V v_t_2413 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2411));
    V v_f_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2414}});
  } else {
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2125399760x1127935158(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_241)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4)}), heff_dup(v_sp_241)});
    V v_t_2420 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2418));
    V v_f_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2420}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2421}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT2 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2427;
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = v_field_2415;
            v_t_2427 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              V v_i_2419 = v_field_2415;
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = v_field_2415;
              V v_t_2426;
              switch (heff_tag_of(v_t_2423)) {
              case TAG_At: {
                V v_s_2425 = heff_dup(heff_field(v_t_2423, 1));
                v_t_2426 = v_s_2425;
                break;
              }
              default: heff_nomatch(v_t_2423);
              }
              v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2423}), v_t_2426});
            }
          }
        }
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2428});
        V v_args_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2429});
        V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2430));
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0)}), heff_dup(v_sp_242)});
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2431}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2436 = v_t_2434.f[1];
            int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
            if ((v_tag_2435 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2438 = v_field_2436;
              return v_c_2438;
            } else {
              if ((v_tag_2435 == ((int64_t)1ULL))) {
                V v_i_2440 = v_field_2436;
                V v_t_2443;
                switch (heff_tag_of(v_i_2440)) {
                case TAG_At: {
                  V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
                  v_t_2443 = v_s_2442;
                  break;
                }
                default: heff_nomatch(v_i_2440);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
              } else {
                V v_t_2444 = v_field_2436;
                V v_t_2447;
                switch (heff_tag_of(v_t_2444)) {
                case TAG_At: {
                  V v_s_2446 = heff_dup(heff_field(v_t_2444, 1));
                  v_t_2447 = v_s_2446;
                  break;
                }
                default: heff_nomatch(v_t_2444);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2444}), v_t_2447});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2449 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2464;
          {
            V v_field_2452 = v_t_2450.f[1];
            int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
            if ((v_tag_2451 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2454 = v_field_2452;
              v_t_2464 = v_c_2454;
            } else {
              if ((v_tag_2451 == ((int64_t)1ULL))) {
                V v_i_2456 = v_field_2452;
                V v_t_2459;
                switch (heff_tag_of(v_i_2456)) {
                case TAG_At: {
                  V v_s_2458 = heff_dup(heff_field(v_i_2456, 1));
                  v_t_2459 = v_s_2458;
                  break;
                }
                default: heff_nomatch(v_i_2456);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2456}), v_t_2459});
              } else {
                V v_t_2460 = v_field_2452;
                V v_t_2463;
                switch (heff_tag_of(v_t_2460)) {
                case TAG_At: {
                  V v_s_2462 = heff_dup(heff_field(v_t_2460, 1));
                  v_t_2463 = v_s_2462;
                  break;
                }
                default: heff_nomatch(v_t_2460);
                }
                v_t_2464 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2460}), v_t_2463});
              }
            }
          }
          V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
          V v_args_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2465});
          V v_t_2467 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2466));
          V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1)}), heff_dup(v_sp_242)});
          V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2468, v_t_2467}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2469}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2473 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT2 v_t_2474 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2488;
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            if ((v_tag_2475 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_2478 = v_field_2476;
              v_t_2488 = v_c_2478;
            } else {
              if ((v_tag_2475 == ((int64_t)1ULL))) {
                V v_i_2480 = v_field_2476;
                V v_t_2483;
                switch (heff_tag_of(v_i_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_i_2480);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
              } else {
                V v_t_2484 = v_field_2476;
                V v_t_2487;
                switch (heff_tag_of(v_t_2484)) {
                case TAG_At: {
                  V v_s_2486 = heff_dup(heff_field(v_t_2484, 1));
                  v_t_2487 = v_s_2486;
                  break;
                }
                default: heff_nomatch(v_t_2484);
                }
                v_t_2488 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2484}), v_t_2487});
              }
            }
          }
          V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2488, NTAG(TAG_Nil)});
          V v_args_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2473, v_t_2489});
          V v_t_2491 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2490));
          V v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2)}), heff_dup(v_sp_242)});
          V v_t_2493 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2492, v_t_2491}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2493}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT2 v_t_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24108;
        {
          V v_field_2496 = v_t_2494.f[1];
          int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
          if ((v_tag_2495 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2498 = v_field_2496;
            v_t_24108 = v_c_2498;
          } else {
            if ((v_tag_2495 == ((int64_t)1ULL))) {
              V v_i_24100 = v_field_2496;
              V v_t_24103;
              switch (heff_tag_of(v_i_24100)) {
              case TAG_At: {
                V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
                v_t_24103 = v_s_24102;
                break;
              }
              default: heff_nomatch(v_i_24100);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24100}), v_t_24103});
            } else {
              V v_t_24104 = v_field_2496;
              V v_t_24107;
              switch (heff_tag_of(v_t_24104)) {
              case TAG_At: {
                V v_s_24106 = heff_dup(heff_field(v_t_24104, 1));
                v_t_24107 = v_s_24106;
                break;
              }
              default: heff_nomatch(v_t_24104);
              }
              v_t_24108 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24104}), v_t_24107});
            }
          }
        }
        V v_args_24109 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, NTAG(TAG_Nil)});
        V v_t_24110 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24109));
        V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3)}), heff_dup(v_sp_242)});
        V v_t_24112 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24110}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24112}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24113 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24114;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24114 = ((int64_t)0ULL);
        }
        V v_t_24115 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24114 + ((int64_t)0ULL)))});
        V v_t_24116 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24115, heff_dup(v_sp_242)})});
        V v_t_24117 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT2 v_t_24118 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24132;
        {
          V v_field_24120 = v_t_24118.f[1];
          int64_t v_tag_24119 = ((int64_t)v_t_24118.f[0]);
          if ((v_tag_24119 == ((int64_t)0ULL))) {
            V v_c_24122 = v_field_24120;
            v_t_24132 = v_c_24122;
          } else {
            if ((v_tag_24119 == ((int64_t)1ULL))) {
              V v_i_24124 = v_field_24120;
              V v_t_24127;
              switch (heff_tag_of(v_i_24124)) {
              case TAG_At: {
                V v_s_24126 = heff_dup(heff_field(v_i_24124, 1));
                v_t_24127 = v_s_24126;
                break;
              }
              default: heff_nomatch(v_i_24124);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24124}), v_t_24127});
            } else {
              V v_t_24128 = v_field_24120;
              V v_t_24131;
              switch (heff_tag_of(v_t_24128)) {
              case TAG_At: {
                V v_s_24130 = heff_dup(heff_field(v_t_24128, 1));
                v_t_24131 = v_s_24130;
                break;
              }
              default: heff_nomatch(v_t_24128);
              }
              v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24128}), v_t_24131});
            }
          }
        }
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
        V v_args_24134 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_t_24133});
        V v_t_24135 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24134));
        V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4)}), heff_dup(v_sp_242)});
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24136, v_t_24135}), heff_dup(v_sp_242)});
        V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24137}), heff_dup(v_sp_242)});
        V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
        V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24116, heff_dup(v_sp_242)}), v_t_24139});
        V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24113, v_t_24140});
        V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
        V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5)}), heff_dup(v_sp_242)});
        V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24145 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c(heff_dup(v_x2121_24145), MK_INT(8LL))) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24145);
          V v_t_24147 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24148 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24147, NTAG(TAG_Nil)});
          V v_t_24149 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24148));
          V v_t_24150 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6)}), heff_dup(v_sp_242)});
          V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24150, v_t_24149}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_CInf, 1, (V[]){v_t_24151}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24145, MK_INT(16LL))) {
            int64_t v_t_24153;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24153 = ((int64_t)0ULL);
            }
            V v_t_24154 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24153 + ((int64_t)0ULL)))});
            V v_t_24155 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24154, heff_dup(v_sp_242)})});
            V v_t_24156 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24157 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24156, NTAG(TAG_Nil)});
            V v_args_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24155, heff_dup(v_sp_242)}), v_t_24157});
            V v_t_24159 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24158));
            V v_t_24160 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7)}), heff_dup(v_sp_242)});
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24160, v_t_24159}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24161}), v_sp_242});
          } else {
            int64_t v_t_24162;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24162 = ((int64_t)0ULL);
            }
            V v_t_24163 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24162 + ((int64_t)0ULL)))});
            V v_t_24164 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24163, heff_dup(v_sp_242)})});
            V v_t_24165 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24166 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
            V v_args_24167 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24164, heff_dup(v_sp_242)}), v_t_24166});
            V v_t_24168 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24167));
            V v_t_24169 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8)}), heff_dup(v_sp_242)});
            V v_t_24170 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24169, v_t_24168}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24170}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr_str0, 11, "bytesConcat");

HeffT2 g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr(V v_segs_240, V v_sp_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s2090434460x112088295(v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesBinary_24s164675078x1710946710_24cpr_str0)}), heff_dup(v_sp_241)});
    V v_t_248 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_f_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_248}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_249}});
  }
  case TAG_Just: {
    V v_s_2410 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24Just = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_segs_240);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24Just, TAG_IBytes, 1, (V[]){v_s_2410}), v_sp_241});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2411}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1, 22, "`Array` takes one type");

HeffT2 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V v_h_240, V v_args_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_243 = heff_dup(heff_field(v_h_240, 0));
    V v_tsp_244 = heff_dup(heff_field(v_h_240, 1));
    switch (heff_tag_of(v_h1_243)) {
    case TAG_EVar: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_247 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_246));
      V v_t_248 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_248}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_249}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2411));
      V v_t_2413 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2414}});
    }
    case TAG_ETag: {
      V v_t_2415 = heff_field(v_h1_243, 0);
      heff_take_n(v_h1_243, 1ULL, 1);
      heff_drop_tag(v_h_240, 2);
      V v_t_2416 = (g_list_2emap_24s1844509821x2028168277(v_args_241));
      V v_f_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_2415, v_tsp_244, v_t_2416}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2417}});
    }
    case TAG_EInt: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2420 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2419));
      V v_t_2421 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2420, v_t_2421}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2422}});
    }
    case TAG_EFloat: {
      heff_take_na(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2425 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2424));
      V v_t_2426 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2425, v_t_2426}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2427}});
    }
    case TAG_EString: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2429 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2429));
      V v_t_2431 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2431}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2432}});
    }
    case TAG_EBinary: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2434));
      V v_t_2436 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2435, v_t_2436}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2437}});
    }
    case TAG_ERune: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2439 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2439));
      V v_t_2441 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2440, v_t_2441}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2442}});
    }
    case TAG_EWord: {
      V v_h11_2443 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24EWord = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      heff_drop(v_tsp_244);
      switch (heff_tag_of(v_h11_2443)) {
      case TAG_TypeWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2444 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2445 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2444));
        V v_t_2446 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2445, v_t_2446}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2447}});
      }
      case TAG_IntWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2449 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2448));
        V v_t_2450 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2449, v_t_2450}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2451}});
      }
      case TAG_FloatWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2452 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2453 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2452));
        V v_t_2454 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2453, v_t_2454}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2455}});
      }
      case TAG_StringWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2456 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2457 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2456));
        V v_t_2458 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2457, v_t_2458}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2459}});
      }
      case TAG_RuneWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2461 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2460));
        V v_t_2462 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2461, v_t_2462}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2463}});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_240, 2);
        switch (heff_tag_of(v_args_241)) {
        case TAG_Nil: {
          V v_t_2464 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0), NTAG(TAG_Nothing)});
          V v_t_2465 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2464, heff_dup(v_sp_242)})});
          return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_At, 2, (V[]){v_t_2465, v_sp_242})}});
        }
        case TAG_Cons: {
          V v_a_2466 = heff_field(v_args_241, 0);
          V v_args2_2467 = heff_field(v_args_241, 1);
          V v_ru_24args_241_24Cons = heff_take_reuse_n(v_args_241, 3ULL, 2);
          switch (heff_tag_of(v_args2_2467)) {
          case TAG_Nil: {
            HeffT2 v_t_2468 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_2466));
            V v_t_2482;
            {
              V v_field_2470 = v_t_2468.f[1];
              int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
              if ((v_tag_2469 == ((int64_t)0ULL))) {
                V v_c_2472 = v_field_2470;
                V v_t_2475;
                switch (heff_tag_of(v_c_2472)) {
                case TAG_At: {
                  V v_s_2474 = heff_dup(heff_field(v_c_2472, 1));
                  v_t_2475 = v_s_2474;
                  break;
                }
                default: heff_nomatch(v_c_2472);
                }
                v_t_2482 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TChk, 1, (V[]){v_c_2472}), v_t_2475});
              } else {
                if ((v_tag_2469 == ((int64_t)1ULL))) {
                  V v_i_2477 = v_field_2470;
                  V v_t_2480;
                  switch (heff_tag_of(v_i_2477)) {
                  case TAG_At: {
                    V v_s_2479 = heff_dup(heff_field(v_i_2477, 1));
                    v_t_2480 = v_s_2479;
                    break;
                  }
                  default: heff_nomatch(v_i_2477);
                  }
                  v_t_2482 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_i_2477}), v_t_2480});
                } else {
                  heff_drop_cell(v_ru_24h1_243_24EWord, 1);
                  heff_drop_cell(v_ru_24args_241_24Cons, 2);
                  V v_t_2481 = v_field_2470;
                  v_t_2482 = v_t_2481;
                }
              }
            }
            V v_f_2483 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2482}), v_sp_242});
            return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2483}});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2467, 0ULL, 2);
            heff_drop(v_a_2466);
            V v_t_2486 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1), NTAG(TAG_Nothing)});
            V v_t_2487 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2486, heff_dup(v_sp_242)})});
            return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_t_2487, v_sp_242})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_args2_2467)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_args_241)}});
        }
      }
      case TAG_AbandonWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2488 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2489 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2488));
        V v_t_2490 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2491 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2489, v_t_2490}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2491}});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2443, 0ULL, 1);
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2493 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2494 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2493));
        V v_t_2495 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2496 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2494, v_t_2495}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2496}});
      }
      default: return ((HeffT2){{heff_nomatch(v_h11_2443)}});
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_243_24EApp = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2499 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24100 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2499));
      V v_t_24101 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24102 = heff_tag_at_n(v_ru_24h1_243_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24100, v_t_24101}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24102}});
    }
    case TAG_EProject: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24104 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24105 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24104));
      V v_t_24106 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24105, v_t_24106}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24107}});
    }
    case TAG_ENamed: {
      V v_ru_24h1_243_24ENamed = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24110 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24111 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24110));
      V v_t_24112 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24113 = heff_tag_at_n(v_ru_24h1_243_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24112}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24113}});
    }
    case TAG_EPi: {
      V v_ru_24h1_243_24EPi = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24116 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24117 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24116));
      V v_t_24118 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24119 = heff_tag_at_n(v_ru_24h1_243_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24117, v_t_24118}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24119}});
    }
    case TAG_ELam: {
      V v_ru_24h1_243_24ELam = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24122 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24123 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24122));
      V v_t_24124 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24125 = heff_tag_at_n(v_ru_24h1_243_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24123, v_t_24124}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24125}});
    }
    case TAG_EAnn: {
      V v_ru_24h1_243_24EAnn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24128 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24129 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24128));
      V v_t_24130 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24131 = heff_tag_at_n(v_ru_24h1_243_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24129, v_t_24130}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24131}});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_243, 0ULL, 4);
      heff_drop(v_tsp_244);
      V v_t_24136 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24137 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24136));
      V v_t_24138 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24139 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24138}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24139}});
    }
    case TAG_ESig: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24141 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24142 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24141));
      V v_t_24143 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24142, v_t_24143}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24144}});
    }
    case TAG_ESum: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24146 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24147 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24146));
      V v_t_24148 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24147, v_t_24148}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24149}});
    }
    case TAG_EStruct: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24151 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24152 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24151));
      V v_t_24153 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24154 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24152, v_t_24153}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24154}});
    }
    case TAG_EUpdate: {
      V v_ru_24h1_243_24EUpdate = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24157 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24158 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24157));
      V v_t_24159 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24160 = heff_tag_at_n(v_ru_24h1_243_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24158, v_t_24159}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24160}});
    }
    case TAG_EMatch: {
      V v_ru_24h1_243_24EMatch = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24163 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24164 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24163));
      V v_t_24165 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24166 = heff_tag_at_n(v_ru_24h1_243_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24164, v_t_24165}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24166}});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_243_24ELetIn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24169 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24170 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24169));
      V v_t_24171 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24172 = heff_tag_at_n(v_ru_24h1_243_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24170, v_t_24171}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24172}});
    }
    case TAG_EDo: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24174 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24175 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24174));
      V v_t_24176 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24177 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24175, v_t_24176}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24177}});
    }
    case TAG_ELocal: {
      V v_ru_24h1_243_24ELocal = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24180 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24181 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24180));
      V v_t_24182 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24183 = heff_tag_at_n(v_ru_24h1_243_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24181, v_t_24182}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24183}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24185 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24186 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24185));
      V v_t_24187 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24188 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24186, v_t_24187}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24188}});
    }
    default: return ((HeffT2){{heff_nomatch(v_h1_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_h_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    HeffT2 v_t_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_243));
    V v_t_2418;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_c_248 = v_field_246;
        V v_t_2411;
        switch (heff_tag_of(v_c_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_c_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_c_248);
        }
        v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_248}), v_t_2411});
      } else {
        if ((v_tag_245 == ((int64_t)1ULL))) {
          V v_i_2413 = v_field_246;
          V v_t_2416;
          switch (heff_tag_of(v_i_2413)) {
          case TAG_At: {
            V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
            v_t_2416 = v_s_2415;
            break;
          }
          default: heff_nomatch(v_i_2413);
          }
          v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2413}), v_t_2416});
        } else {
          V v_t_2417 = v_field_246;
          v_t_2418 = v_t_2417;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_xsp_242, v_t_2418});
  }
  case TAG_PiImplicit: {
    V v_x_2419 = heff_field(v_x2_240, 0);
    V v_xsp_2420 = heff_field(v_x2_240, 1);
    V v_bsp_2421 = heff_field(v_x2_240, 2);
    V v_t_2422 = heff_field(v_x2_240, 3);
    V v_d_2423 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    HeffT2 v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2422));
    V v_t_2438;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_c_2428 = v_field_2426;
        V v_t_2431;
        switch (heff_tag_of(v_c_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_dup(heff_field(v_c_2428, 1));
          v_t_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_c_2428);
        }
        v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2428}), v_t_2431});
      } else {
        if ((v_tag_2425 == ((int64_t)1ULL))) {
          V v_i_2433 = v_field_2426;
          V v_t_2436;
          switch (heff_tag_of(v_i_2433)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_i_2433);
          }
          v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2433}), v_t_2436});
        } else {
          V v_t_2437 = v_field_2426;
          v_t_2438 = v_t_2437;
        }
      }
    }
    V v_t_2455;
    switch (heff_tag_of(v_d_2423)) {
    case TAG_Nothing: {
      v_t_2455 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2439 = heff_field(v_d_2423, 0);
      V v_ru_24d_2423_24Just = heff_take_reuse_n(v_d_2423, 1ULL, 1);
      HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_2439));
      V v_t_2454;
      {
        V v_field_2442 = v_t_2440.f[1];
        int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
        if ((v_tag_2441 == ((int64_t)0ULL))) {
          V v_c_2444 = v_field_2442;
          v_t_2454 = v_c_2444;
        } else {
          if ((v_tag_2441 == ((int64_t)1ULL))) {
            V v_i_2446 = v_field_2442;
            V v_t_2449;
            switch (heff_tag_of(v_i_2446)) {
            case TAG_At: {
              V v_s_2448 = heff_dup(heff_field(v_i_2446, 1));
              v_t_2449 = v_s_2448;
              break;
            }
            default: heff_nomatch(v_i_2446);
            }
            v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2446}), v_t_2449});
          } else {
            V v_t_2450 = v_field_2442;
            V v_t_2453;
            switch (heff_tag_of(v_t_2450)) {
            case TAG_At: {
              V v_s_2452 = heff_dup(heff_field(v_t_2450, 1));
              v_t_2453 = v_s_2452;
              break;
            }
            default: heff_nomatch(v_t_2450);
            }
            v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2450}), v_t_2453});
          }
        }
      }
      v_t_2455 = heff_tag_at_n(v_ru_24d_2423_24Just, TAG_Just, 1, (V[]){v_t_2454});
      break;
    }
    default: heff_nomatch(v_d_2423);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2419, v_xsp_2420, v_bsp_2421, v_t_2438, v_t_2455});
  }
  case TAG_PiInstance: {
    V v_x_2456 = heff_field(v_x2_240, 0);
    V v_xsp_2457 = heff_field(v_x2_240, 1);
    V v_bsp_2458 = heff_field(v_x2_240, 2);
    V v_t_2459 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    HeffT2 v_t_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2459));
    V v_t_2474;
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_c_2464 = v_field_2462;
        V v_t_2467;
        switch (heff_tag_of(v_c_2464)) {
        case TAG_At: {
          V v_s_2466 = heff_dup(heff_field(v_c_2464, 1));
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_c_2464);
        }
        v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2464}), v_t_2467});
      } else {
        if ((v_tag_2461 == ((int64_t)1ULL))) {
          V v_i_2469 = v_field_2462;
          V v_t_2472;
          switch (heff_tag_of(v_i_2469)) {
          case TAG_At: {
            V v_s_2471 = heff_dup(heff_field(v_i_2469, 1));
            v_t_2472 = v_s_2471;
            break;
          }
          default: heff_nomatch(v_i_2469);
          }
          v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2469}), v_t_2472});
        } else {
          V v_t_2473 = v_field_2462;
          v_t_2474 = v_t_2473;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2456, v_xsp_2457, v_bsp_2458, v_t_2474});
  }
  case TAG_PiAnon: {
    V v_t_2475 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    HeffT2 v_t_2476 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2475));
    V v_t_2490;
    {
      V v_field_2478 = v_t_2476.f[1];
      int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
      if ((v_tag_2477 == ((int64_t)0ULL))) {
        V v_c_2480 = v_field_2478;
        V v_t_2483;
        switch (heff_tag_of(v_c_2480)) {
        case TAG_At: {
          V v_s_2482 = heff_dup(heff_field(v_c_2480, 1));
          v_t_2483 = v_s_2482;
          break;
        }
        default: heff_nomatch(v_c_2480);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2480}), v_t_2483});
      } else {
        if ((v_tag_2477 == ((int64_t)1ULL))) {
          V v_i_2485 = v_field_2478;
          V v_t_2488;
          switch (heff_tag_of(v_i_2485)) {
          case TAG_At: {
            V v_s_2487 = heff_dup(heff_field(v_i_2485, 1));
            v_t_2488 = v_s_2487;
            break;
          }
          default: heff_nomatch(v_i_2485);
          }
          v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2485}), v_t_2488});
        } else {
          V v_t_2489 = v_field_2478;
          v_t_2490 = v_t_2489;
        }
      }
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2490});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3, 36, "a `do` block ends with an expression");

HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_243}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_244}});
    }
    case TAG_EImplicitVar: {
      V v_x_245 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_245}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_246}});
    }
    case TAG_ETag: {
      V v_t_247 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_248 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_247, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_248, v_sp_242})}});
    }
    case TAG_EInt: {
      V v_i_249 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_249}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2410}});
    }
    case TAG_EFloat: {
      double v_x_2411 = heff_tflat_f64(v_x21_241, 0);
      heff_take_na(v_x21_241, 0ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_nf(TAG_IFloat, 1, 1u, (V[]){heff_word_f64(v_x_2411)}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2412}});
    }
    case TAG_EString: {
      V v_x_2413 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2413}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2414}});
    }
    case TAG_EBinary: {
      V v_segs_2415 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_segs_2415; V a_2 = v_sp_242; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24s1911731356x1292550214_24cpr(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    }
    case TAG_ERune: {
      V v_c_2416 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2416}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2417}});
    }
    case TAG_EWord: {
      V v_w_2418 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_w_2418, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_x21_241, 0);
      V v_args_2420 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(v_h_2419, v_args_2420, v_sp_242));
    }
    case TAG_EProject: {
      heff_take_n(v_x21_241, 0ULL, 1);
      V v_t_2422 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str0), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_242})}});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_2425 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str1), NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2425, v_sp_242})}});
    }
    case TAG_EPi: {
      V v_b_2426 = heff_field(v_x21_241, 0);
      V v_cod_2427 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_2428 = (g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(v_b_2426));
      HeffT2 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_cod_2427));
      V v_t_2443;
      {
        V v_field_2431 = v_t_2429.f[1];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          V v_c_2433 = v_field_2431;
          V v_t_2436;
          switch (heff_tag_of(v_c_2433)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_c_2433);
          }
          v_t_2443 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
        } else {
          if ((v_tag_2430 == ((int64_t)1ULL))) {
            V v_i_2438 = v_field_2431;
            V v_t_2441;
            switch (heff_tag_of(v_i_2438)) {
            case TAG_At: {
              V v_s_2440 = heff_dup(heff_field(v_i_2438, 1));
              v_t_2441 = v_s_2440;
              break;
            }
            default: heff_nomatch(v_i_2438);
            }
            v_t_2443 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2438}), v_t_2441});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2442 = v_field_2431;
            v_t_2443 = v_t_2442;
          }
        }
      }
      V v_f_2444 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2428, v_t_2443}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2444}});
    }
    case TAG_ELam: {
      V v_x211_2445 = heff_field(v_x21_241, 0);
      V v_body_2446 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x211_2445)) {
      case TAG_LamName: {
        V v_x_2447 = heff_field(v_x211_2445, 0);
        V v_xsp_2448 = heff_field(v_x211_2445, 1);
        heff_take_n(v_x211_2445, 3ULL, 2);
        HeffT2 v_t_2449 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2446));
        V v_t_2463;
        {
          V v_field_2451 = v_t_2449.f[1];
          int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
          if ((v_tag_2450 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2453 = v_field_2451;
            v_t_2463 = v_c_2453;
          } else {
            if ((v_tag_2450 == ((int64_t)1ULL))) {
              V v_i_2455 = v_field_2451;
              V v_t_2458;
              switch (heff_tag_of(v_i_2455)) {
              case TAG_At: {
                V v_s_2457 = heff_dup(heff_field(v_i_2455, 1));
                v_t_2458 = v_s_2457;
                break;
              }
              default: heff_nomatch(v_i_2455);
              }
              v_t_2463 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2455}), v_t_2458});
            } else {
              V v_t_2459 = v_field_2451;
              V v_t_2462;
              switch (heff_tag_of(v_t_2459)) {
              case TAG_At: {
                V v_s_2461 = heff_dup(heff_field(v_t_2459, 1));
                v_t_2462 = v_s_2461;
                break;
              }
              default: heff_nomatch(v_t_2459);
              }
              v_t_2463 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2459}), v_t_2462});
            }
          }
        }
        V v_f_2464 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2447, v_xsp_2448, v_t_2463}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2464}});
      }
      case TAG_LamImplicit: {
        V v_x_2465 = heff_field(v_x211_2445, 0);
        V v_xsp_2466 = heff_field(v_x211_2445, 1);
        heff_take_n(v_x211_2445, 3ULL, 2);
        HeffT2 v_t_2467 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2446));
        V v_t_2481;
        {
          V v_field_2469 = v_t_2467.f[1];
          int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
          if ((v_tag_2468 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_c_2471 = v_field_2469;
            v_t_2481 = v_c_2471;
          } else {
            if ((v_tag_2468 == ((int64_t)1ULL))) {
              V v_i_2473 = v_field_2469;
              V v_t_2476;
              switch (heff_tag_of(v_i_2473)) {
              case TAG_At: {
                V v_s_2475 = heff_dup(heff_field(v_i_2473, 1));
                v_t_2476 = v_s_2475;
                break;
              }
              default: heff_nomatch(v_i_2473);
              }
              v_t_2481 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2473}), v_t_2476});
            } else {
              V v_t_2477 = v_field_2469;
              V v_t_2480;
              switch (heff_tag_of(v_t_2477)) {
              case TAG_At: {
                V v_s_2479 = heff_dup(heff_field(v_t_2477, 1));
                v_t_2480 = v_s_2479;
                break;
              }
              default: heff_nomatch(v_t_2477);
              }
              v_t_2481 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2477}), v_t_2480});
            }
          }
        }
        V v_f_2482 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2465, v_xsp_2466, v_t_2481}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2482}});
      }
      case TAG_LamAnn: {
        V v_x_2483 = heff_field(v_x211_2445, 0);
        V v_xsp_2484 = heff_field(v_x211_2445, 1);
        V v_t_2485 = heff_field(v_x211_2445, 2);
        heff_take_n(v_x211_2445, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_241_24ELam, 2);
        HeffT2 v_t_2486 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2485));
        V v_t_24100;
        {
          V v_field_2488 = v_t_2486.f[1];
          int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
          if ((v_tag_2487 == ((int64_t)0ULL))) {
            V v_c_2490 = v_field_2488;
            V v_t_2493;
            switch (heff_tag_of(v_c_2490)) {
            case TAG_At: {
              V v_s_2492 = heff_dup(heff_field(v_c_2490, 1));
              v_t_2493 = v_s_2492;
              break;
            }
            default: heff_nomatch(v_c_2490);
            }
            v_t_24100 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2490}), v_t_2493});
          } else {
            if ((v_tag_2487 == ((int64_t)1ULL))) {
              V v_i_2495 = v_field_2488;
              V v_t_2498;
              switch (heff_tag_of(v_i_2495)) {
              case TAG_At: {
                V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
                v_t_2498 = v_s_2497;
                break;
              }
              default: heff_nomatch(v_i_2495);
              }
              v_t_24100 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2495}), v_t_2498});
            } else {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_t_2499 = v_field_2488;
              v_t_24100 = v_t_2499;
            }
          }
        }
        V v_t_24101 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2446));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(v_x_2483, v_xsp_2484, v_t_24100, v_t_24101, v_sp_242));
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2445)}});
      }
    }
    case TAG_EAnn: {
      V v_a_24102 = heff_field(v_x21_241, 0);
      V v_t_24103 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_24104 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_24102));
      V v_t_24118;
      {
        V v_field_24106 = v_t_24104.f[1];
        int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
        if ((v_tag_24105 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24108 = v_field_24106;
          v_t_24118 = v_c_24108;
        } else {
          if ((v_tag_24105 == ((int64_t)1ULL))) {
            V v_i_24110 = v_field_24106;
            V v_t_24113;
            switch (heff_tag_of(v_i_24110)) {
            case TAG_At: {
              V v_s_24112 = heff_dup(heff_field(v_i_24110, 1));
              v_t_24113 = v_s_24112;
              break;
            }
            default: heff_nomatch(v_i_24110);
            }
            v_t_24118 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24110}), v_t_24113});
          } else {
            V v_t_24114 = v_field_24106;
            V v_t_24117;
            switch (heff_tag_of(v_t_24114)) {
            case TAG_At: {
              V v_s_24116 = heff_dup(heff_field(v_t_24114, 1));
              v_t_24117 = v_s_24116;
              break;
            }
            default: heff_nomatch(v_t_24114);
            }
            v_t_24118 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24114}), v_t_24117});
          }
        }
      }
      HeffT2 v_t_24119 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_24103));
      V v_t_24133;
      {
        V v_field_24121 = v_t_24119.f[1];
        int64_t v_tag_24120 = ((int64_t)v_t_24119.f[0]);
        if ((v_tag_24120 == ((int64_t)0ULL))) {
          V v_c_24123 = v_field_24121;
          V v_t_24126;
          switch (heff_tag_of(v_c_24123)) {
          case TAG_At: {
            V v_s_24125 = heff_dup(heff_field(v_c_24123, 1));
            v_t_24126 = v_s_24125;
            break;
          }
          default: heff_nomatch(v_c_24123);
          }
          v_t_24133 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24123}), v_t_24126});
        } else {
          if ((v_tag_24120 == ((int64_t)1ULL))) {
            V v_i_24128 = v_field_24121;
            V v_t_24131;
            switch (heff_tag_of(v_i_24128)) {
            case TAG_At: {
              V v_s_24130 = heff_dup(heff_field(v_i_24128, 1));
              v_t_24131 = v_s_24130;
              break;
            }
            default: heff_nomatch(v_i_24128);
            }
            v_t_24133 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24128}), v_t_24131});
          } else {
            heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
            V v_t_24132 = v_field_24121;
            v_t_24133 = v_t_24132;
          }
        }
      }
      V v_f_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_24118, v_t_24133}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24134}});
    }
    case TAG_ESpec: {
      V v_a_24135 = heff_field(v_x21_241, 0);
      V v_x_24136 = heff_field(v_x21_241, 1);
      V v_fsp_24137 = heff_field(v_x21_241, 2);
      V v_v_24138 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24ESpec = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_24139 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24135));
      V v_t_24140 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24139));
      HeffT2 v_t_24141 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_24138));
      V v_t_24155;
      {
        V v_field_24143 = v_t_24141.f[1];
        int64_t v_tag_24142 = ((int64_t)v_t_24141.f[0]);
        if ((v_tag_24142 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24145 = v_field_24143;
          v_t_24155 = v_c_24145;
        } else {
          if ((v_tag_24142 == ((int64_t)1ULL))) {
            V v_i_24147 = v_field_24143;
            V v_t_24150;
            switch (heff_tag_of(v_i_24147)) {
            case TAG_At: {
              V v_s_24149 = heff_dup(heff_field(v_i_24147, 1));
              v_t_24150 = v_s_24149;
              break;
            }
            default: heff_nomatch(v_i_24147);
            }
            v_t_24155 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24147}), v_t_24150});
          } else {
            V v_t_24151 = v_field_24143;
            V v_t_24154;
            switch (heff_tag_of(v_t_24151)) {
            case TAG_At: {
              V v_s_24153 = heff_dup(heff_field(v_t_24151, 1));
              v_t_24154 = v_s_24153;
              break;
            }
            default: heff_nomatch(v_t_24151);
            }
            v_t_24155 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24151}), v_t_24154});
          }
        }
      }
      V v_f_24156 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24140, v_x_24136, v_fsp_24137, v_t_24155}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24156}});
    }
    case TAG_ESig: {
      V v_fs_24157 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24158 = (g_list_2emap_24s205414595x1692305030(v_fs_24157));
      V v_f_24159 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSig, 1, (V[]){v_t_24158}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_24159}});
    }
    case TAG_ESum: {
      V v_vs_24160 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24161 = (g_list_2emap_24s1258450377x973220636(v_vs_24160));
      V v_f_24162 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TSum, 1, (V[]){v_t_24161}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_24162}});
    }
    case TAG_EStruct: {
      V v_fs_24163 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24164 = (g_list_2emap_24s961097229x1129443801(v_fs_24163));
      V v_f_24165 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CStruct, 1, (V[]){v_t_24164}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24165}});
    }
    case TAG_EUpdate: {
      V v_a_24166 = heff_field(v_x21_241, 0);
      V v_fs_24167 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24168 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24166));
      V v_t_24169 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24168));
      V v_t_24170 = (g_list_2emap_24s137457135x961689574(v_fs_24167));
      V v_f_24171 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IUpdate, 2, (V[]){v_t_24169, v_t_24170}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24171}});
    }
    case TAG_EMatch: {
      V v_s_24172 = heff_field(v_x21_241, 0);
      V v_alts_24173 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_t_24174 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_s_24172));
      V v_t_24175 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24174));
      V v_t_24176 = (g_list_2emap_24s1230969749x2018313496(v_alts_24173));
      V v_f_24177 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_24175, v_t_24176}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24177}});
    }
    case TAG_ELetIn: {
      V v_rhs_24178 = heff_field(v_x21_241, 0);
      V v_a_24179 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24180 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_24178));
      V v_t_24181 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24180));
      V v_t_24201;
      switch (heff_tag_of(v_a_24179)) {
      case TAG_At: {
        V v_x21_24182 = heff_field(v_a_24179, 0);
        V v_sp_24183 = heff_field(v_a_24179, 1);
        heff_take_n(v_a_24179, 3ULL, 2);
        switch (heff_tag_of(v_x21_24182)) {
        case TAG_MkAlt: {
          V v_p_24184 = heff_field(v_x21_24182, 0);
          V v_b_24185 = heff_field(v_x21_24182, 1);
          heff_take_n(v_x21_24182, 3ULL, 2);
          HeffT2 v_t_24186 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_b_24185));
          V v_t_24200;
          {
            V v_field_24188 = v_t_24186.f[1];
            int64_t v_tag_24187 = ((int64_t)v_t_24186.f[0]);
            if ((v_tag_24187 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24At, 2);
              V v_c_24190 = v_field_24188;
              v_t_24200 = v_c_24190;
            } else {
              if ((v_tag_24187 == ((int64_t)1ULL))) {
                V v_i_24192 = v_field_24188;
                V v_t_24195;
                switch (heff_tag_of(v_i_24192)) {
                case TAG_At: {
                  V v_s_24194 = heff_dup(heff_field(v_i_24192, 1));
                  v_t_24195 = v_s_24194;
                  break;
                }
                default: heff_nomatch(v_i_24192);
                }
                v_t_24200 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24192}), v_t_24195});
              } else {
                V v_t_24196 = v_field_24188;
                V v_t_24199;
                switch (heff_tag_of(v_t_24196)) {
                case TAG_At: {
                  V v_s_24198 = heff_dup(heff_field(v_t_24196, 1));
                  v_t_24199 = v_s_24198;
                  break;
                }
                default: heff_nomatch(v_t_24196);
                }
                v_t_24200 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24196}), v_t_24199});
              }
            }
          }
          v_t_24201 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24184, v_t_24200}), v_sp_24183});
          break;
        }
        default: heff_nomatch(v_x21_24182);
        }
        break;
      }
      default: heff_nomatch(v_a_24179);
      }
      V v_f_24202 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24181, v_t_24201}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24202}});
    }
    case TAG_EDo: {
      V v_stmts_24203 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EDo = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24204 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_24203));
      switch (heff_tag_of(v_t_24204)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x21_241_24EDo, 1);
        V v_t_24205 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str2), NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24205, v_sp_242})}});
      }
      case TAG_Cons: {
        V v_last_24206 = heff_field(v_t_24204, 0);
        V v_init_24207 = heff_field(v_t_24204, 1);
        heff_take_n(v_t_24204, 3ULL, 2);
        V v_init_24208 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_init_24207));
        V v_t_24218;
        switch (heff_tag_of(v_last_24206)) {
        case TAG_At: {
          V v_x31_24209 = heff_field(v_last_24206, 0);
          heff_take_n(v_last_24206, 1ULL, 2);
          switch (heff_tag_of(v_x31_24209)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24209, 0ULL, 3);
            heff_drop_cell(v_ru_24x21_241_24EDo, 1);
            heff_drop(v_init_24208);
            v_t_24218 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24209, 0ULL, 2);
            heff_drop_cell(v_ru_24x21_241_24EDo, 1);
            heff_drop(v_init_24208);
            v_t_24218 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24216 = heff_field(v_x31_24209, 0);
            heff_take_n(v_x31_24209, 1ULL, 1);
            V v_t_24217 = ({ V a_0 = heff_dup(v_sp_242); V a_1 = v_init_24208; V a_2 = v_e_24216; V r_ = (g_heff_2esyntax_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24208); r_; });
            v_t_24218 = heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_Just, 1, (V[]){v_t_24217});
            break;
          }
          default: heff_nomatch(v_x31_24209);
          }
          break;
        }
        default: heff_nomatch(v_last_24206);
        }
        switch (heff_tag_of(v_t_24218)) {
        case TAG_Nothing: {
          V v_t_24219 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr_str3), NTAG(TAG_Nothing)});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24219, v_sp_242})}});
        }
        case TAG_Just: {
          V v_e_27_24220 = heff_field(v_t_24218, 0);
          heff_take_n(v_t_24218, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V t_0 = v_e_27_24220;
          v_x2_240 = t_0;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_t_24218)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24204)}});
      }
    }
    case TAG_ELocal: {
      V v_body_24221 = heff_field(v_x21_241, 0);
      V v_ds_24222 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      HeffT2 v_t_24223 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_24221));
      V v_t_24237;
      {
        V v_field_24225 = v_t_24223.f[1];
        int64_t v_tag_24224 = ((int64_t)v_t_24223.f[0]);
        if ((v_tag_24224 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_24227 = v_field_24225;
          v_t_24237 = v_c_24227;
        } else {
          if ((v_tag_24224 == ((int64_t)1ULL))) {
            V v_i_24229 = v_field_24225;
            V v_t_24232;
            switch (heff_tag_of(v_i_24229)) {
            case TAG_At: {
              V v_s_24231 = heff_dup(heff_field(v_i_24229, 1));
              v_t_24232 = v_s_24231;
              break;
            }
            default: heff_nomatch(v_i_24229);
            }
            v_t_24237 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24229}), v_t_24232});
          } else {
            V v_t_24233 = v_field_24225;
            V v_t_24236;
            switch (heff_tag_of(v_t_24233)) {
            case TAG_At: {
              V v_s_24235 = heff_dup(heff_field(v_t_24233, 1));
              v_t_24236 = v_s_24235;
              break;
            }
            default: heff_nomatch(v_t_24233);
            }
            v_t_24237 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24233}), v_t_24236});
          }
        }
      }
      V v_t_24238 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2epresyntax_2eclassifier_get(), 1)), v_ds_24222));
      V v_f_24239 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_24237, v_t_24238}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24239}});
    }
    case TAG_EInvalid: {
      V v_why_24240 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      V v_t_24241 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), v_why_24240, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24241, v_sp_242})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_field_243});
    } else {
      if ((v_tag_242 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_243});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){v_field_243});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ExplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_245));
      V v_t_2420;
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_c_2410 = v_field_248;
          V v_t_2413;
          switch (heff_tag_of(v_c_2410)) {
          case TAG_At: {
            V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
            v_t_2413 = v_s_2412;
            break;
          }
          default: heff_nomatch(v_c_2410);
          }
          v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
        } else {
          if ((v_tag_247 == ((int64_t)1ULL))) {
            V v_i_2415 = v_field_248;
            V v_t_2418;
            switch (heff_tag_of(v_i_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_i_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_i_2415);
            }
            v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2415}), v_t_2418});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2419 = v_field_248;
            v_t_2420 = v_t_2419;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_243, v_xsp_244, v_t_2420}), v_sp_242});
    }
    case TAG_ImplicitParam: {
      V v_x_2421 = heff_field(v_x21_241, 0);
      V v_xsp_2422 = heff_field(v_x21_241, 1);
      V v_t_2423 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ImplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT2 v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2423));
      V v_t_2438;
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_c_2428 = v_field_2426;
          V v_t_2431;
          switch (heff_tag_of(v_c_2428)) {
          case TAG_At: {
            V v_s_2430 = heff_dup(heff_field(v_c_2428, 1));
            v_t_2431 = v_s_2430;
            break;
          }
          default: heff_nomatch(v_c_2428);
          }
          v_t_2438 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2428}), v_t_2431});
        } else {
          if ((v_tag_2425 == ((int64_t)1ULL))) {
            V v_i_2433 = v_field_2426;
            V v_t_2436;
            switch (heff_tag_of(v_i_2433)) {
            case TAG_At: {
              V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
              v_t_2436 = v_s_2435;
              break;
            }
            default: heff_nomatch(v_i_2433);
            }
            v_t_2438 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2433}), v_t_2436});
          } else {
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            V v_t_2437 = v_field_2426;
            v_t_2438 = v_t_2437;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2421, v_xsp_2422, v_t_2438}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf_24s1361640751x1753612669(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_t_243, 0);
      V v_sp_245 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_sp_242, v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_240, 0);
    V v_sp_248 = heff_field(v_x2_240, 1);
    V v_sp2_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = heff_field(v_x2_240, 3);
    V v_d_2411 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      V v_sp_2413 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2420;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_d_2411, 0);
      V v_ru_24d_2411_24Just = heff_take_reuse_n(v_d_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_n_2416 = heff_field(v_x_2415, 0);
        V v_sp_2417 = heff_field(v_x_2415, 1);
        V v_ru_24x_2415_24At = heff_take_reuse_n(v_x_2415, 3ULL, 2);
        V v_t_2418 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2415_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_2417});
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      v_t_2420 = heff_tag_at_n(v_ru_24d_2411_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_247, v_sp_248, v_sp2_249, v_t_2414, v_t_2420});
  }
  case TAG_PiInstance: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_sp2_2423 = heff_field(v_x2_240, 2);
    V v_t_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_t_2424, 0);
      V v_sp_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2426, v_n_2425));
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2421, v_sp_2422, v_sp2_2423, v_t_2427});
  }
  case TAG_PiAnon: {
    V v_t_2428 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_t_2428, 0);
      V v_sp_2430 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_IVar: {
    return v_n_240;
  }
  case TAG_IInt: {
    return v_n_240;
  }
  case TAG_IFloat: {
    return v_n_240;
  }
  case TAG_IString: {
    return v_n_240;
  }
  case TAG_IBytes: {
    return v_n_240;
  }
  case TAG_IPrim: {
    return v_n_240;
  }
  case TAG_IRune: {
    return v_n_240;
  }
  case TAG_IApp: {
    V v_h_248 = heff_field(v_n_240, 0);
    V v_args_249 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IApp = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_h_248)) {
    case TAG_At: {
      V v_n_2410 = heff_field(v_h_248, 0);
      V v_sp_2411 = heff_field(v_h_248, 1);
      V v_ru_24h_248_24At = heff_take_reuse_n(v_h_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2410));
      v_t_2413 = heff_tag_at_n(v_ru_24h_248_24At, TAG_At, 2, (V[]){v_t_2412, v_sp_2411});
      break;
    }
    default: heff_nomatch(v_h_248);
    }
    V v_t_2414 = (g_list_2emap_24s1150457979x1978067071(v_args_249));
    return heff_tag_at_n(v_ru_24n_240_24IApp, TAG_IApp, 2, (V[]){v_t_2413, v_t_2414});
  }
  case TAG_IAnn: {
    V v_c_2415 = heff_field(v_n_240, 0);
    V v_t_2416 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IAnn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_c_2415)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_c_2415, 0);
      V v_sp_2418 = heff_field(v_c_2415, 1);
      V v_ru_24c_2415_24At = heff_take_reuse_n(v_c_2415, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24c_2415_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_c_2415);
    }
    V v_t_2423;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_At: {
      V v_n_2421 = heff_field(v_t_2416, 0);
      V v_sp_2422 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 3ULL, 2);
      v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2422, v_n_2421));
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnn, TAG_IAnn, 2, (V[]){v_t_2420, v_t_2423});
  }
  case TAG_ISpec: {
    V v_a_2424 = heff_field(v_n_240, 0);
    V v_x_2425 = heff_field(v_n_240, 1);
    V v_sp_2426 = heff_field(v_n_240, 2);
    V v_v_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ISpec = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2431;
    switch (heff_tag_of(v_a_2424)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_a_2424, 0);
      V v_sp_2429 = heff_field(v_a_2424, 1);
      V v_ru_24a_2424_24At = heff_take_reuse_n(v_a_2424, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2428));
      v_t_2431 = heff_tag_at_n(v_ru_24a_2424_24At, TAG_At, 2, (V[]){v_t_2430, v_sp_2429});
      break;
    }
    default: heff_nomatch(v_a_2424);
    }
    V v_t_2435;
    switch (heff_tag_of(v_v_2427)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_v_2427, 0);
      V v_sp_2433 = heff_field(v_v_2427, 1);
      V v_ru_24v_2427_24At = heff_take_reuse_n(v_v_2427, 3ULL, 2);
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2432));
      v_t_2435 = heff_tag_at_n(v_ru_24v_2427_24At, TAG_At, 2, (V[]){v_t_2434, v_sp_2433});
      break;
    }
    default: heff_nomatch(v_v_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24ISpec, TAG_ISpec, 4, (V[]){v_t_2431, v_x_2425, v_sp_2426, v_t_2435});
  }
  case TAG_IUpdate: {
    V v_a_2436 = heff_field(v_n_240, 0);
    V v_fs_2437 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IUpdate = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2441;
    switch (heff_tag_of(v_a_2436)) {
    case TAG_At: {
      V v_n_2438 = heff_field(v_a_2436, 0);
      V v_sp_2439 = heff_field(v_a_2436, 1);
      V v_ru_24a_2436_24At = heff_take_reuse_n(v_a_2436, 3ULL, 2);
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2438));
      v_t_2441 = heff_tag_at_n(v_ru_24a_2436_24At, TAG_At, 2, (V[]){v_t_2440, v_sp_2439});
      break;
    }
    default: heff_nomatch(v_a_2436);
    }
    V v_t_2442 = (g_list_2emap_24s366989016x166432442(v_fs_2437));
    return heff_tag_at_n(v_ru_24n_240_24IUpdate, TAG_IUpdate, 2, (V[]){v_t_2441, v_t_2442});
  }
  case TAG_IAnnLam: {
    V v_x_2443 = heff_field(v_n_240, 0);
    V v_sp_2444 = heff_field(v_n_240, 1);
    V v_t_2445 = heff_field(v_n_240, 2);
    V v_b_2446 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24IAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2449;
    switch (heff_tag_of(v_t_2445)) {
    case TAG_At: {
      V v_n_2447 = heff_field(v_t_2445, 0);
      V v_sp_2448 = heff_field(v_t_2445, 1);
      heff_take_n(v_t_2445, 3ULL, 2);
      v_t_2449 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2448, v_n_2447));
      break;
    }
    default: heff_nomatch(v_t_2445);
    }
    V v_t_2453;
    switch (heff_tag_of(v_b_2446)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_b_2446, 0);
      V v_sp_2451 = heff_field(v_b_2446, 1);
      V v_ru_24b_2446_24At = heff_take_reuse_n(v_b_2446, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24b_2446_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_b_2446);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_x_2443, v_sp_2444, v_t_2449, v_t_2453});
  }
  case TAG_IInvalid: {
    return v_n_240;
  }
  case TAG_INominal: {
    return v_n_240;
  }
  case TAG_ILitEq: {
    V v_x_2458 = heff_field(v_n_240, 0);
    V v_sp_2459 = heff_field(v_n_240, 1);
    V v_eq_2460 = heff_field(v_n_240, 2);
    V v_lit_2461 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ILitEq = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2465;
    switch (heff_tag_of(v_lit_2461)) {
    case TAG_At: {
      V v_n_2462 = heff_field(v_lit_2461, 0);
      V v_sp_2463 = heff_field(v_lit_2461, 1);
      V v_ru_24lit_2461_24At = heff_take_reuse_n(v_lit_2461, 3ULL, 2);
      V v_t_2464 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2462));
      v_t_2465 = heff_tag_at_n(v_ru_24lit_2461_24At, TAG_At, 2, (V[]){v_t_2464, v_sp_2463});
      break;
    }
    default: heff_nomatch(v_lit_2461);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILitEq, TAG_ILitEq, 4, (V[]){v_x_2458, v_sp_2459, v_eq_2460, v_t_2465});
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_245 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_fs_246})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TSum, 1, (V[]){v_vs_248})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2411 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2415 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2417 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2425 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2426 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_i_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_i_2426, 0);
      V v_sp_2428 = heff_field(v_i_2426, 1);
      heff_take_n(v_i_2426, 3ULL, 2);
      v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_i_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2429}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2430 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_c_2430)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_c_2430, 0);
      V v_sp_2432 = heff_field(v_c_2430, 1);
      heff_take_n(v_c_2430, 3ULL, 2);
      v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
      break;
    }
    default: heff_nomatch(v_c_2430);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2433}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2436 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(a[0], a[1]);
}