// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CTag 56892
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_LamName 56383
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TInf 28962
#define LBL_bind 9519364
#define LBL_bound 295286168
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving__bound[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving, LBL_bound};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24dps_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo;
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo;
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24cpr(V, V, V);
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo;
HeffT7 g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;
V g_list_2emap_24s126994153x1029399760(V);
V g_list_2emap_24s126994153x1029399760_entry(V self, V *a);
extern Clo g_list_2emap_24s126994153x1029399760_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s529174x2075875906(V);
V g_list_2emap_24s529174x2075875906_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eboolOf_str0, 12, "builtin.Bool");
Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eboolOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eboolOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_c1_241 = heff_dup(heff_field(v_c_240, 0));
    switch (heff_tag_of(v_c1_241)) {
    case TAG_EVar: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENotationVar: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_c1_241, 0);
      V v_ru_24c1_241_24ETag = heff_take_reuse_n(v_c1_241, 1ULL, 1);
      switch (heff_tag_of(v_c_240)) {
      case TAG_At: {
        V v_sp_2410 = heff_field(v_c_240, 1);
        V v_ru_24c_240_24At = heff_take_reuse_n(v_c_240, 2ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24c_240_24At, TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24c1_241_24ETag, TAG_ETag, 1, 1ULL, (V[]){v_t_248}), heff_dup(v_sp_2410)});
        V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eboolOf_str0)}), heff_dup(v_sp_2410)});
        V v_t_2413 = ({ V rr_ = heff_rec_reuse_na(v_sp_2410, 3ULL, 2, shape_start__end, 15u, 0u); rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2411, v_t_2412}), v_t_2413});
      }
      default: return heff_nomatch(v_c_240);
      }
    }
    case TAG_EInt: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EFloat: {
      heff_take_nf(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EString: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ERune: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EWord: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EApp: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EProject: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EPi: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ELam: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_c1_241, 0ULL, 4);
      return v_c_240;
    }
    case TAG_ESig: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ESum: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EDo: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EFor: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EBreak: {
      return v_c_240;
    }
    case TAG_EContinue: {
      return v_c_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENest: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ETry: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EWith: {
      heff_take_n(v_c1_241, 0ULL, 4);
      return v_c_240;
    }
    case TAG_EWithBound: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    default: return heff_nomatch(v_c1_241);
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eboolOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtAcc_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2estmtAcc(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2esyntax_2epresyntax_2estmtAcc_24cpr(v_f_240, v_st_241, v_x3_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, heff_tag_n(TAG_At, 2, (V[]){v_field_245, v_field_246})});
  }
}
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtAcc(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s84992124x1543220283_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT3 v_t_247 = ({ V a_0 = v_st_240; V a_1 = v_x_245; HeffT3 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s280627497x741826998_24cpr(a_0, a_1)); heff_drop(v_st_240); r_; });
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      V v_st_2411 = v_field_248;
      V v_y_2412 = heff_tag_n(TAG_At, 2, (V[]){v_field_249, v_field_2410});
      V v_cell_2413 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_2412, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2413);
      V t_0 = v_st_2411;
      V t_1 = v_xs_246;
      V t_2 = v_u_2414;
      v_st_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      switch (heff_tag_of(v_x111_244)) {
      case TAG_StmtBind: {
        heff_take_n(v_x111_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLet: {
        heff_take_n(v_x111_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtExpr: {
        heff_take_n(v_x111_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLetMut: {
        V v_x_2412 = heff_field(v_x111_244, 0);
        heff_take_n(v_x111_244, 1ULL, 3);
        V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
        V v_u_2416 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2415);
        V t_0 = v_rest_243;
        V t_1 = v_u_2416;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x111_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_244);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1633619940x1094058992_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_st_247 = v_st_240;
    V v_x3_248 = v_x_245;
    V v_x1_2447;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_At: {
      V v_x31_249 = heff_field(v_x3_248, 0);
      V v_sp_2410 = heff_field(v_x3_248, 1);
      V v_ru_24x3_248_24At = heff_take_reuse_n(v_x3_248, 3ULL, 2);
      switch (heff_tag_of(v_x31_249)) {
      case TAG_SetField: {
        V v_x_2411 = heff_field(v_x31_249, 0);
        V v_xsp_2412 = heff_field(v_x31_249, 1);
        V v_e_2413 = heff_field(v_x31_249, 2);
        V v_ru_24x31_249_24SetField = heff_take_reuse_n(v_x31_249, 7ULL, 3);
        V v_x_2428;
        if ((heff_dup(v_st_247) == NTAG(TAG_True))) {
          heff_drop(v_st_247);
          v_x_2428 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_247);
          switch (heff_tag_of(v_e_2413)) {
          case TAG_At: {
            V v_a_2414 = heff_dup(heff_field(v_e_2413, 0));
            switch (heff_tag_of(v_a_2414)) {
            case TAG_ELam: {
              heff_take_n(v_a_2414, 0ULL, 2);
              switch (heff_tag_of(v_e_2413)) {
              case TAG_At: {
                v_x_2428 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2413);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2414, 0ULL, 1);
              switch (heff_tag_of(v_e_2413)) {
              case TAG_At: {
                v_x_2428 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2413);
              }
              break;
            }
            default: {
              heff_drop(v_a_2414);
              HeffT2 v_t_2423 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2413)));
              {
                V v_field_2424 = v_t_2423.f[0];
                V v_field_2425 = v_t_2423.f[1];
                V v_a_2426 = v_field_2424;
                V v_a_2427 = v_field_2425;
                heff_drop(v_a_2427);
                v_x_2428 = v_a_2426;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2413);
          }
        }
        V v_t_2429 = heff_tag_re_n(v_ru_24x3_248_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_249_24SetField, TAG_SetField, 3, 7ULL, (V[]){v_x_2411, v_xsp_2412, v_e_2413}), v_sp_2410});
        v_x1_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_t_2429});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2430 = heff_field(v_x31_249, 0);
        V v_ru_24x31_249_24BadFieldSet = heff_take_reuse_n(v_x31_249, 1ULL, 1);
        V v_x_2445;
        if ((heff_dup(v_st_247) == NTAG(TAG_True))) {
          heff_drop(v_st_247);
          v_x_2445 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_247);
          switch (heff_tag_of(v_e_2430)) {
          case TAG_At: {
            V v_a_2431 = heff_dup(heff_field(v_e_2430, 0));
            switch (heff_tag_of(v_a_2431)) {
            case TAG_ELam: {
              heff_take_n(v_a_2431, 0ULL, 2);
              switch (heff_tag_of(v_e_2430)) {
              case TAG_At: {
                v_x_2445 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_e_2430);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2431, 0ULL, 1);
              switch (heff_tag_of(v_e_2430)) {
              case TAG_At: {
                v_x_2445 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_e_2430);
              }
              break;
            }
            default: {
              heff_drop(v_a_2431);
              HeffT2 v_t_2440 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_e_2430)));
              {
                V v_field_2441 = v_t_2440.f[0];
                V v_field_2442 = v_t_2440.f[1];
                V v_a_2443 = v_field_2441;
                V v_a_2444 = v_field_2442;
                heff_drop(v_a_2444);
                v_x_2445 = v_a_2443;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_e_2430);
          }
        }
        V v_t_2446 = heff_tag_re_n(v_ru_24x3_248_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_249_24BadFieldSet, TAG_BadFieldSet, 1, 1ULL, (V[]){v_e_2430}), v_sp_2410});
        v_x1_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2445, v_t_2446});
        break;
      }
      default: heff_nomatch(v_x31_249);
      }
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    switch (heff_tag_of(v_x1_2447)) {
    case TAG_MkPair: {
      V v_st_2448 = heff_field(v_x1_2447, 0);
      V v_y_2449 = heff_field(v_x1_2447, 1);
      heff_take_n(v_x1_2447, 3ULL, 2);
      V v_cell_2450 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_2449, heff_hole()});
      V v_u_2451 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2450);
      V t_0 = v_st_2448;
      V t_1 = v_xs_246;
      V t_2 = v_u_2451;
      v_st_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2447)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str1, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str2, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str3, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str4, 6, "MkUnit");
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(V v_cx_240, V v_sp_241, V v_c_242, V v_body_243, V v_rest_244, V v_end_245) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_c_242)) {
  case TAG_At: {
    V v_e1_246 = heff_dup(heff_field(v_c_242, 0));
    switch (heff_tag_of(v_e1_246)) {
    case TAG_ELam: {
      heff_take_n(v_e1_246, 0ULL, 2);
      switch (heff_tag_of(v_c_242)) {
      case TAG_At: {
        v_t_2421 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_243)));
        break;
      }
      default: heff_nomatch(v_c_242);
      }
      break;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_246, 0ULL, 1);
      switch (heff_tag_of(v_c_242)) {
      case TAG_At: {
        v_t_2421 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_c_242);
      }
      break;
    }
    default: {
      heff_drop(v_e1_246);
      HeffT2 v_t_2415 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_242)));
      {
        V v_field_2416 = v_t_2415.f[0];
        V v_field_2417 = v_t_2415.f[1];
        V v_x_2418 = v_field_2416;
        V v_y_2419 = v_field_2417;
        heff_drop(v_y_2419);
        V v_t_2420 = v_x_2418;
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop(v_t_2420);
          v_t_2421 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2420);
          v_t_2421 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_243)));
        }
      }
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  V v_t_2422 = heff_dup(heff_rfield(v_cx_240, 1));
  V v_t_2426;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Nil: {
    V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str0)}), heff_dup(v_sp_241)});
    v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Cons: {
    v_t_2426 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_t_2422));
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V v_t_2427 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
  V v_t_2428 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str1), v_t_2427)});
  V v_t_2429 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2428, heff_dup(v_sp_241)}), v_t_2426));
  V v_t_2430 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V a_0 = heff_dup(v_cx_240); V a_1 = heff_dup(v_sp_241); V a_2 = v_t_2421; V a_3 = v_t_2429; V a_4 = v_t_2430; V a_5 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_lam0, 1, 4, (V[]){v_cx_240, v_c_242, v_body_243, v_sp_241}); V a_6 = v_rest_244; V a_7 = v_end_245; V r_ = (g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2421); r_; });
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_lam0(V self, V *args) {
  V v_exitJ_2431 = args[0];
  V v_cx_240 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_body_243 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_cx_2432 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(heff_dup(v_cx_240), heff_dup(v_c_242), heff_dup(v_body_243)));
  V v_t_2433 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_2432, 1)), NTAG(TAG_False)});
  HeffT2 v_t_2434 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_2432), v_t_2433}), NTAG(TAG_Nil), heff_dup(v_c_242)));
  {
    V v_field_2435 = v_t_2434.f[0];
    V v_field_2436 = v_t_2434.f[1];
    V v_x_2437 = v_field_2435;
    V v_y_2438 = v_field_2436;
    heff_clo_take(self, 4);
    HeffT7 v_t_2439 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_24cpr(heff_dup(v_cx_240), v_c_242, heff_dup(v_body_243)));
    {
      V v_field_2440 = v_t_2439.f[0];
      V v_field_2441 = v_t_2439.f[1];
      V v_field_2443 = v_t_2439.f[3];
      V v_field_2444 = v_t_2439.f[4];
      V v_field_2445 = v_t_2439.f[5];
      V v_field_2446 = v_t_2439.f[6];
      heff_drop(v_t_2439.f[2]);
      V v_t_2447 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2448 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str2), v_t_2447)});
      V v_t_2449 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2448, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2450 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2449, heff_dup(v_exitJ_2431)})});
      V v_cx_2451 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){v_field_2440, v_field_2441, v_t_2450, v_field_2443, v_field_2444, v_field_2445, v_field_2446});
      V v_t_2452 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2453 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str3), v_t_2452)});
      V v_t_2454 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2453, heff_dup(v_sp_241)}), heff_take_field(v_cx_240, 1), NTAG(TAG_True), heff_get_n(v_cx_240, 4, 7)});
      V v_t_2459;
      switch (heff_tag_of(v_body_243)) {
      case TAG_Nil: {
        v_t_2459 = (g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(v_t_2454, heff_dup(v_cx_2451), heff_get_n(v_cx_2451, 3, 7)));
        break;
      }
      case TAG_Cons: {
        V v_s_2455 = heff_field(v_body_243, 0);
        V v_x32_2456 = heff_field(v_body_243, 1);
        heff_take_n(v_body_243, 3ULL, 2);
        switch (heff_tag_of(v_x32_2456)) {
        case TAG_Nil: {
          v_t_2459 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2451, v_s_2455, v_x32_2456, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2454})));
          break;
        }
        case TAG_Cons: {
          v_t_2459 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2451, v_s_2455, v_x32_2456, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2454})));
          break;
        }
        default: heff_nomatch(v_x32_2456);
        }
        break;
      }
      default: heff_nomatch(v_body_243);
      }
      V v_vars_2460 = heff_take_field(v_exitJ_2431, 1);
      V v_t_2461 = heff_take_field(v_exitJ_2431, 2);
      V v_t_2465;
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop(v_t_2461);
        switch (heff_tag_of(v_vars_2460)) {
        case TAG_Nil: {
          V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str4)}), heff_dup(v_sp_241)});
          v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          v_t_2465 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_2460));
          break;
        }
        default: heff_nomatch(v_vars_2460);
        }
      } else {
        heff_drop(v_t_2461);
        v_t_2465 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_2460));
      }
      V v_t_2466 = (g_heff_2esyntax_2epresyntax_2eapp(heff_get_n(v_exitJ_2431, 0, 4), v_t_2465));
      V v_t_2467 = (g_heff_2esyntax_2epresyntax_2eifOf(v_sp_241, v_y_2438, v_t_2459, v_t_2466));
      return ({ V a_0 = v_cx_2432; V a_1 = v_x_2437; V a_2 = v_t_2467; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2437); r_; });
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str2, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str3, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str4, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str5, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str6, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str7, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V v_cx_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 7);
      return heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str0)}), v_sp_243});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_242, 0ULL, 2);
      heff_drop_rec(v_cx_240, 7);
      return heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str1)}), v_sp_243});
    }
    case TAG_StmtExpr: {
      V v_e_249 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_249));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_sp_243, 2);
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop_cell(v_ru_24x31_242_24StmtExpr, 1);
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(v_cx_240, v_e_249, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_2410);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_240, 4)))) {
          V v_t_2411 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2411}), NTAG(TAG_Nil), v_e_249));
          {
            V v_field_2413 = v_t_2412.f[0];
            V v_field_2414 = v_t_2412.f[1];
            V v_x_2415 = v_field_2413;
            V v_y_2416 = v_field_2414;
            V v_t_2417 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
            V v_t_2418 = heff_tag_at_n(v_ru_24x31_242_24StmtExpr, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str2), v_t_2417)});
            V v_v_2419 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_243)});
            V v_t_2420 = heff_dup(heff_rfield(v_cx_240, 6));
            V v_v_2424;
            switch (heff_tag_of(v_t_2420)) {
            case TAG_Nothing: {
              v_v_2424 = v_v_2419;
              break;
            }
            case TAG_Just: {
              V v_names_2421 = heff_field(v_t_2420, 0);
              V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 1ULL, 1);
              V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_names_2421, NTAG(TAG_Nil)});
              V v_t_2423 = heff_tag_at_n(v_ru_24t_2420_24Just, TAG_ETuple, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_2419, v_t_2422})});
              v_v_2424 = heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_sp_243)});
              break;
            }
            default: heff_nomatch(v_t_2420);
            }
            V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
            V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2425}), heff_dup(v_sp_243)});
            V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2424, NTAG(TAG_Nil)});
            V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, v_t_2427));
            V v_rest_2429 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), heff_dup(v_sp_243), heff_dup(heff_rfield(v_cx_240, 4)), v_t_2428));
            V v_t_2432;
            switch (heff_tag_of(v_rest_2429)) {
            case TAG_At: {
              V v_s_2431 = heff_dup(heff_field(v_rest_2429, 1));
              v_t_2432 = v_s_2431;
              break;
            }
            default: heff_nomatch(v_rest_2429);
            }
            V v_t_2433 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
            V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2433}), heff_dup(heff_rfield(v_cx_240, 3))});
            V v_t_2435 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
            V v_t_2436 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str3), v_t_2435), heff_dup(v_sp_243)});
            V v_t_2437 = ({ V rv_1 = heff_get_n(v_t_2432, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2436, v_rest_2429}), v_t_2437});
            V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
            V v_t_2440 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2434, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2416, v_t_2439})));
            return ({ V a_0 = v_cx_240; V a_1 = v_x_2415; V a_2 = v_t_2440; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
          }
        } else {
          V v_t_2441 = heff_dup(heff_rfield(v_cx_240, 6));
          switch (heff_tag_of(v_t_2441)) {
          case TAG_Nothing: {
            heff_drop_rec(v_sp_243, 2);
            heff_drop_cell(v_ru_24x3_241_24At, 2);
            heff_drop_cell(v_ru_24x31_242_24StmtExpr, 1);
            V v_t_2442 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2443 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2442}), NTAG(TAG_Nil), v_e_249));
            {
              V v_field_2444 = v_t_2443.f[0];
              V v_field_2445 = v_t_2443.f[1];
              V v_x_2446 = v_field_2444;
              V v_y_2447 = v_field_2445;
              return ({ V a_0 = v_cx_240; V a_1 = v_x_2446; V a_2 = v_y_2447; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2446); r_; });
            }
          }
          case TAG_Just: {
            V v_ru_24t_2441_24Just = heff_take_reuse_n(v_t_2441, 0ULL, 1);
            V v_t_2449 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
            HeffT2 v_t_2450 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2449}), NTAG(TAG_Nil), v_e_249));
            {
              V v_field_2451 = v_t_2450.f[0];
              V v_field_2452 = v_t_2450.f[1];
              V v_x_2453 = v_field_2451;
              V v_y_2454 = v_field_2452;
              V v_t_2455 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
              V v_t_2456 = heff_tag_at_n(v_ru_24x31_242_24StmtExpr, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str4), v_t_2455)});
              V v_v_2457 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){v_t_2456, heff_dup(v_sp_243)});
              V v_t_2458 = heff_dup(heff_rfield(v_cx_240, 6));
              V v_t_2462;
              switch (heff_tag_of(v_t_2458)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24t_2441_24Just, 1);
                v_t_2462 = v_v_2457;
                break;
              }
              case TAG_Just: {
                V v_names_2459 = heff_field(v_t_2458, 0);
                heff_take_n(v_t_2458, 1ULL, 1);
                V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_names_2459, NTAG(TAG_Nil)});
                V v_t_2461 = heff_tag_at_n(v_ru_24t_2441_24Just, TAG_ETuple, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_v_2457, v_t_2460})});
                v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){v_t_2461, heff_dup(v_sp_243)});
                break;
              }
              default: heff_nomatch(v_t_2458);
              }
              V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
              V v_t_2464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2463}), heff_dup(v_sp_243)});
              V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
              V v_rest_2466 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2464, v_t_2465));
              V v_t_2469;
              switch (heff_tag_of(v_rest_2466)) {
              case TAG_At: {
                V v_s_2468 = heff_dup(heff_field(v_rest_2466, 1));
                v_t_2469 = v_s_2468;
                break;
              }
              default: heff_nomatch(v_rest_2466);
              }
              V v_t_2470 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
              V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2470}), heff_dup(heff_rfield(v_cx_240, 3))});
              V v_t_2472 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
              V v_t_2473 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str5), v_t_2472), heff_dup(v_sp_243)});
              V v_t_2474 = ({ V rv_1 = heff_get_n(v_t_2469, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2473, v_rest_2466}), v_t_2474});
              V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, NTAG(TAG_Nil)});
              V v_t_2477 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2471, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2454, v_t_2476})));
              return ({ V a_0 = v_cx_240; V a_1 = v_x_2453; V a_2 = v_t_2477; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2453); r_; });
            }
          }
          default: return heff_nomatch(v_t_2441);
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 7);
      return heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str6)}), v_sp_243});
    }
    case TAG_StmtLetElse: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 7);
      return heff_tag_re_n(v_ru_24x3_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str7)}), v_sp_243});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str1, 4, "Cons");
Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elistOfChk_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elistOfChk(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str0), heff_dup(v_sp_241), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_xs_244, heff_dup(v_sp_241)));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str1), heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_246})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elistOfChk(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1, 22, "`Array` takes one type");

HeffT3 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V v_h_240, V v_args_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_243 = heff_dup(heff_field(v_h_240, 0));
    switch (heff_tag_of(v_h1_243)) {
    case TAG_ETag: {
      V v_t_245 = heff_field(v_h1_243, 0);
      heff_take_n(v_h1_243, 1ULL, 1);
      switch (heff_tag_of(v_h_240)) {
      case TAG_At: {
        V v_tsp_247 = heff_field(v_h_240, 1);
        heff_take_n(v_h_240, 2ULL, 2);
        V v_t_248 = (g_list_2emap_24s1844509821x2028168277(v_args_241));
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_CTag, 3, (V[]){v_t_245, v_tsp_247, v_t_248}), v_sp_242}});
      }
      default: return ((HeffT3){{heff_nomatch(v_h_240)}});
      }
    }
    case TAG_EWord: {
      V v_h11_249 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24EWord = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      switch (heff_tag_of(v_h11_249)) {
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_240, 2);
        switch (heff_tag_of(v_args_241)) {
        case TAG_Nil: {
          V v_t_2410 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0), NTAG(TAG_Nothing)});
          V v_t_2411 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_242)})});
          return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_t_2411, v_sp_242}});
        }
        case TAG_Cons: {
          V v_a_2412 = heff_field(v_args_241, 0);
          V v_args2_2413 = heff_field(v_args_241, 1);
          V v_ru_24args_241_24Cons = heff_take_reuse_n(v_args_241, 3ULL, 2);
          switch (heff_tag_of(v_args2_2413)) {
          case TAG_Nil: {
            HeffT3 v_t_2414 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_2412));
            {
              V v_field_2416 = v_t_2414.f[1];
              V v_field_2417 = v_t_2414.f[2];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              V v_t_2427;
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                V v_c_2418 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_field_2416, v_field_2417});
                V v_t_2421;
                switch (heff_tag_of(v_c_2418)) {
                case TAG_At: {
                  V v_s_2420 = heff_dup(heff_field(v_c_2418, 1));
                  v_t_2421 = v_s_2420;
                  break;
                }
                default: heff_nomatch(v_c_2418);
                }
                v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TChk, 1, (V[]){v_c_2418}), v_t_2421});
              } else {
                if ((v_tag_2415 == ((int64_t)1ULL))) {
                  V v_i_2422 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_field_2416, v_field_2417});
                  V v_t_2425;
                  switch (heff_tag_of(v_i_2422)) {
                  case TAG_At: {
                    V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
                    v_t_2425 = v_s_2424;
                    break;
                  }
                  default: heff_nomatch(v_i_2422);
                  }
                  v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
                } else {
                  heff_drop_cell(v_ru_24h1_243_24EWord, 1);
                  V v_t_2426 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_field_2416, v_field_2417});
                  v_t_2427 = v_t_2426;
                }
              }
              return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_TArray, 1, (V[]){v_t_2427}), v_sp_242}});
            }
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2413, 0ULL, 2);
            heff_drop(v_a_2412);
            V v_t_2430 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1), NTAG(TAG_Nothing)});
            V v_t_2431 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_t_2430, heff_dup(v_sp_242)})});
            return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_t_2431, v_sp_242}});
          }
          default: return ((HeffT3){{heff_nomatch(v_args2_2413)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_args_241)}});
        }
      }
      default: {
        heff_drop(v_h11_249);
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2433 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2432));
        V v_t_2434 = (g_list_2emap_24s529174x2075875906(v_args_241));
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_IApp, 2, (V[]){v_t_2433, v_t_2434}), v_sp_242}});
      }
      }
    }
    default: {
      heff_drop(v_h1_243);
      V v_t_2435 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2436 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2435));
      V v_t_2437 = (g_list_2emap_24s529174x2075875906(v_args_241));
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, v_t_2437}), v_sp_242}});
    }
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_h_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_IVar: {
    return v_n_240;
  }
  case TAG_INotationVar: {
    return v_n_240;
  }
  case TAG_IInt: {
    return v_n_240;
  }
  case TAG_IFloat: {
    return v_n_240;
  }
  case TAG_IString: {
    return v_n_240;
  }
  case TAG_IBytes: {
    return v_n_240;
  }
  case TAG_IPrim: {
    return v_n_240;
  }
  case TAG_IRune: {
    return v_n_240;
  }
  case TAG_IApp: {
    V v_h_2411 = heff_field(v_n_240, 0);
    V v_args_2412 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IApp = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_h_2411)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_h_2411, 0);
      V v_sp_2414 = heff_field(v_h_2411, 1);
      V v_ru_24h_2411_24At = heff_take_reuse_n(v_h_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2413));
      v_t_2416 = heff_tag_re_n(v_ru_24h_2411_24At, TAG_At, 2, 2ULL, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_h_2411);
    }
    V v_t_2417 = (g_list_2emap_24s126994153x1029399760(v_args_2412));
    return heff_tag_at_n(v_ru_24n_240_24IApp, TAG_IApp, 2, (V[]){v_t_2416, v_t_2417});
  }
  case TAG_IAnn: {
    V v_c_2418 = heff_field(v_n_240, 0);
    V v_t_2419 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IAnn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_c_2418)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_c_2418, 0);
      V v_sp_2421 = heff_field(v_c_2418, 1);
      V v_ru_24c_2418_24At = heff_take_reuse_n(v_c_2418, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_re_n(v_ru_24c_2418_24At, TAG_At, 2, 2ULL, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_c_2418);
    }
    V v_t_2426;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_At: {
      V v_n_2424 = heff_field(v_t_2419, 0);
      V v_sp_2425 = heff_field(v_t_2419, 1);
      V v_ru_24t_2419_24At = heff_take_reuse_n(v_t_2419, 3ULL, 2);
      v_t_2426 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2419_24At, v_sp_2425, v_n_2424));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnn, TAG_IAnn, 2, (V[]){v_t_2423, v_t_2426});
  }
  case TAG_ISpec: {
    V v_a_2427 = heff_field(v_n_240, 0);
    V v_x_2428 = heff_field(v_n_240, 1);
    V v_sp_2429 = heff_field(v_n_240, 2);
    V v_v_2430 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ISpec = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2434;
    switch (heff_tag_of(v_a_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_a_2427, 0);
      V v_sp_2432 = heff_field(v_a_2427, 1);
      V v_ru_24a_2427_24At = heff_take_reuse_n(v_a_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2431));
      v_t_2434 = heff_tag_re_n(v_ru_24a_2427_24At, TAG_At, 2, 2ULL, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_a_2427);
    }
    V v_t_2438;
    switch (heff_tag_of(v_v_2430)) {
    case TAG_At: {
      V v_n_2435 = heff_field(v_v_2430, 0);
      V v_sp_2436 = heff_field(v_v_2430, 1);
      V v_ru_24v_2430_24At = heff_take_reuse_n(v_v_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2435));
      v_t_2438 = heff_tag_re_n(v_ru_24v_2430_24At, TAG_At, 2, 2ULL, (V[]){v_t_2437, v_sp_2436});
      break;
    }
    default: heff_nomatch(v_v_2430);
    }
    return heff_tag_re_n(v_ru_24n_240_24ISpec, TAG_ISpec, 4, 6ULL, (V[]){v_t_2434, v_x_2428, v_sp_2429, v_t_2438});
  }
  case TAG_IUpdate: {
    V v_a_2439 = heff_field(v_n_240, 0);
    V v_fs_2440 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IUpdate = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_a_2439)) {
    case TAG_At: {
      V v_n_2441 = heff_field(v_a_2439, 0);
      V v_sp_2442 = heff_field(v_a_2439, 1);
      V v_ru_24a_2439_24At = heff_take_reuse_n(v_a_2439, 3ULL, 2);
      V v_t_2443 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2441));
      v_t_2444 = heff_tag_re_n(v_ru_24a_2439_24At, TAG_At, 2, 2ULL, (V[]){v_t_2443, v_sp_2442});
      break;
    }
    default: heff_nomatch(v_a_2439);
    }
    V v_t_2445 = (g_list_2emap_24s366989016x166432442(v_fs_2440));
    return heff_tag_at_n(v_ru_24n_240_24IUpdate, TAG_IUpdate, 2, (V[]){v_t_2444, v_t_2445});
  }
  case TAG_IAnnLam: {
    V v_x_2446 = heff_field(v_n_240, 0);
    V v_sp_2447 = heff_field(v_n_240, 1);
    V v_t_2448 = heff_field(v_n_240, 2);
    V v_b_2449 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24IAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2452;
    switch (heff_tag_of(v_t_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_t_2448, 0);
      V v_sp_2451 = heff_field(v_t_2448, 1);
      V v_ru_24t_2448_24At = heff_take_reuse_n(v_t_2448, 3ULL, 2);
      v_t_2452 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2448_24At, v_sp_2451, v_n_2450));
      break;
    }
    default: heff_nomatch(v_t_2448);
    }
    V v_t_2456;
    switch (heff_tag_of(v_b_2449)) {
    case TAG_At: {
      V v_n_2453 = heff_field(v_b_2449, 0);
      V v_sp_2454 = heff_field(v_b_2449, 1);
      V v_ru_24b_2449_24At = heff_take_reuse_n(v_b_2449, 3ULL, 2);
      V v_t_2455 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2453));
      v_t_2456 = heff_tag_re_n(v_ru_24b_2449_24At, TAG_At, 2, 2ULL, (V[]){v_t_2455, v_sp_2454});
      break;
    }
    default: heff_nomatch(v_b_2449);
    }
    return heff_tag_re_n(v_ru_24n_240_24IAnnLam, TAG_IAnnLam, 4, 3ULL, (V[]){v_x_2446, v_sp_2447, v_t_2452, v_t_2456});
  }
  case TAG_IInvalid: {
    return v_n_240;
  }
  case TAG_INominal: {
    return v_n_240;
  }
  case TAG_ILitEq: {
    V v_x_2461 = heff_field(v_n_240, 0);
    V v_sp_2462 = heff_field(v_n_240, 1);
    V v_eq_2463 = heff_field(v_n_240, 2);
    V v_lit_2464 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ILitEq = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2468;
    switch (heff_tag_of(v_lit_2464)) {
    case TAG_At: {
      V v_n_2465 = heff_field(v_lit_2464, 0);
      V v_sp_2466 = heff_field(v_lit_2464, 1);
      V v_ru_24lit_2464_24At = heff_take_reuse_n(v_lit_2464, 3ULL, 2);
      V v_t_2467 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2465));
      v_t_2468 = heff_tag_re_n(v_ru_24lit_2464_24At, TAG_At, 2, 2ULL, (V[]){v_t_2467, v_sp_2466});
      break;
    }
    default: heff_nomatch(v_lit_2464);
    }
    return heff_tag_re_n(v_ru_24n_240_24ILitEq, TAG_ILitEq, 4, 7ULL, (V[]){v_x_2461, v_sp_2462, v_eq_2463, v_t_2468});
  }
  case TAG_ILazy: {
    V v_c_2469 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24ILazy = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2473;
    switch (heff_tag_of(v_c_2469)) {
    case TAG_At: {
      V v_n_2470 = heff_field(v_c_2469, 0);
      V v_sp_2471 = heff_field(v_c_2469, 1);
      V v_ru_24c_2469_24At = heff_take_reuse_n(v_c_2469, 3ULL, 2);
      V v_t_2472 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2470));
      v_t_2473 = heff_tag_re_n(v_ru_24c_2469_24At, TAG_At, 2, 2ULL, (V[]){v_t_2472, v_sp_2471});
      break;
    }
    default: heff_nomatch(v_c_2469);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILazy, TAG_ILazy, 1, (V[]){v_t_2473});
  }
  case TAG_ITuple: {
    V v_cs_2474 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24ITuple = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2475 = (g_list_2emap_24s79542405x478516404(v_cs_2474));
    return heff_tag_at_n(v_ru_24n_240_24ITuple, TAG_ITuple, 1, (V[]){v_t_2475});
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(a[0]);
}