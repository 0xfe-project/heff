// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkSegment 38079
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V);
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo;
V g_heff_2esyntax_2epresyntax_2ebytesTerm(V, V);
V g_heff_2esyntax_2epresyntax_2ebytesTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebytesTerm_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo;
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo;
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etwoTo(V);
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_clo;
HeffT6 g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s126994153x1029399760(V);
V g_list_2emap_24s126994153x1029399760_entry(V self, V *a);
extern Clo g_list_2emap_24s126994153x1029399760_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s529174x2075875906(V);
V g_list_2emap_24s529174x2075875906_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2etwoTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etwoTo_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etwoTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2esyntax_2epresyntax_2etwoTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etwoTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etwoTo(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2elastOr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EApp: {
        V v_h_246 = heff_field(v_f1_244, 0);
        V v_xs_247 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_sp_249 = heff_field(v_f_240, 1);
          V v_ru_24f_240_24At = heff_take_reuse_n(v_f_240, 2ULL, 2);
          V v_t_2410 = (g_prelude_2e_2b_2b(v_xs_247, heff_dup(v_args_241)));
          V v_x1_2411 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_args_241; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
          V v_t_2414;
          switch (heff_tag_of(v_x1_2411)) {
          case TAG_At: {
            V v_s_2413 = heff_field(v_x1_2411, 1);
            heff_take_n(v_x1_2411, 2ULL, 2);
            v_t_2414 = v_s_2413;
            break;
          }
          default: heff_nomatch(v_x1_2411);
          }
          V v_t_2415 = ({ V rv_1 = heff_get_n(v_t_2414, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
          return heff_tag_at_n(v_ru_24f_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24f1_244_24EApp, TAG_EApp, 2, (V[]){v_h_246, v_t_2410}), v_t_2415});
        }
        default: return heff_nomatch(v_f_240);
        }
      }
      default: {
        heff_drop(v_f1_244);
        V v_a_2418;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2417 = heff_dup(heff_field(v_f_240, 1));
          v_a_2418 = v_s_2417;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2419 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_t_2422;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2419, 1);
          heff_take_n(v_x1_2419, 2ULL, 2);
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_t_2422, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2418, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eapp(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eboolOf_str0, 12, "builtin.Bool");
Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eboolOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eboolOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_c1_241 = heff_dup(heff_field(v_c_240, 0));
    switch (heff_tag_of(v_c1_241)) {
    case TAG_EVar: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENotationVar: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_c1_241, 0);
      V v_ru_24c1_241_24ETag = heff_take_reuse_n(v_c1_241, 1ULL, 1);
      switch (heff_tag_of(v_c_240)) {
      case TAG_At: {
        V v_sp_2410 = heff_field(v_c_240, 1);
        V v_ru_24c_240_24At = heff_take_reuse_n(v_c_240, 2ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24c_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c1_241_24ETag, TAG_ETag, 1, (V[]){v_t_248}), heff_dup(v_sp_2410)});
        V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eboolOf_str0)}), heff_dup(v_sp_2410)});
        V v_t_2413 = ({ V rr_ = heff_rec_reuse_na(v_sp_2410, 3ULL, 2, shape_start__end, 15u, 0u); rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2411, v_t_2412}), v_t_2413});
      }
      default: return heff_nomatch(v_c_240);
      }
    }
    case TAG_EInt: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EFloat: {
      heff_take_nf(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EString: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ERune: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EWord: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EApp: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EProject: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EPi: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ELam: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_c1_241, 0ULL, 4);
      return v_c_240;
    }
    case TAG_ESig: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ESum: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EDo: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EFor: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EBreak: {
      return v_c_240;
    }
    case TAG_EContinue: {
      return v_c_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENest: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ETry: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EWith: {
      heff_take_n(v_c1_241, 0ULL, 4);
      return v_c_240;
    }
    default: return heff_nomatch(v_c1_241);
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eboolOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtAcc_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2estmtAcc(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_xsp_246 = heff_field(v_x31_243, 1);
      V v_e_247 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24StmtBind = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      V v_x1_248 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_247}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x1_248, 0);
        V v_y_2410 = heff_field(v_x1_248, 1);
        V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtBind, TAG_StmtBind, 3, (V[]){v_x_245, v_xsp_246, v_y_2410}), v_sp_244});
        return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_249, v_t_2411});
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    case TAG_StmtLet: {
      V v_p_2412 = heff_field(v_x31_243, 0);
      V v_e_2413 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24StmtLet = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_x1_2414 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2413}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        V v_y_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtLet, TAG_StmtLet, 2, (V[]){v_p_2412, v_y_2416}), v_sp_244});
        return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_t_2417});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_StmtExpr: {
      V v_e_2418 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24StmtExpr = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2418}));
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x1_2419, 0);
        V v_y_2421 = heff_field(v_x1_2419, 1);
        V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
        V v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_y_2421}), v_sp_244});
        return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_t_2422});
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    case TAG_StmtLetMut: {
      V v_x_2423 = heff_field(v_x31_243, 0);
      V v_xsp_2424 = heff_field(v_x31_243, 1);
      V v_e_2425 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24StmtLetMut = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      V v_x1_2426 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2425}));
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        V v_y_2428 = heff_field(v_x1_2426, 1);
        V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
        V v_t_2429 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtLetMut, TAG_StmtLetMut, 3, (V[]){v_x_2423, v_xsp_2424, v_y_2428}), v_sp_244});
        return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_t_2429});
      }
      default: return heff_nomatch(v_x1_2426);
      }
    }
    case TAG_StmtLetElse: {
      V v_p_2430 = heff_field(v_x31_243, 0);
      V v_e_2431 = heff_field(v_x31_243, 1);
      V v_ss_2432 = heff_field(v_x31_243, 2);
      V v_ru_24x31_243_24StmtLetElse = heff_take_reuse_n(v_x31_243, 7ULL, 3);
      V v_x1_2433 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_e_2431}));
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_MkPair: {
        V v_x_2434 = heff_field(v_x1_2433, 0);
        V v_y_2435 = heff_field(v_x1_2433, 1);
        V v_ru_24x1_2433_24MkPair = heff_take_reuse_n(v_x1_2433, 3ULL, 2);
        V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_2436, v_x_2434, v_ss_2432));
        {
          V v_field_2438 = v_t_2437.f[0];
          V v_field_2439 = v_t_2437.f[1];
          V v_x_2440 = v_field_2438;
          V v_y_2441 = v_field_2439;
          V v_t_2442 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24StmtLetElse, TAG_StmtLetElse, 3, (V[]){v_p_2430, v_y_2435, v_y_2441}), v_sp_244});
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2440, v_t_2442});
        }
      }
      default: return heff_nomatch(v_x1_2433);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtAcc(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      switch (heff_tag_of(v_x111_244)) {
      case TAG_StmtBind: {
        heff_take_n(v_x111_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLet: {
        heff_take_n(v_x111_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtExpr: {
        heff_take_n(v_x111_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLetMut: {
        V v_x_2412 = heff_field(v_x111_244, 0);
        heff_take_n(v_x111_244, 1ULL, 3);
        V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
        V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
        heff_drop(v_u_2416);
        V t_0 = v_rest_243;
        V t_1 = v_cell_2415;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x111_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_244);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ejumpE_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ejumpE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EWhile: {
      V v_e11_247 = heff_field(v_e1_241, 0);
      V v_body_248 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        switch (heff_tag_of(v_e11_247)) {
        case TAG_At: {
          V v_e1_2411 = heff_dup(heff_field(v_e11_247, 0));
          switch (heff_tag_of(v_e1_2411)) {
          case TAG_ELam: {
            heff_take_n(v_e1_2411, 0ULL, 2);
            switch (heff_tag_of(v_e11_247)) {
            case TAG_At: {
              heff_take_n(v_e11_247, 0ULL, 2);
              HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_248);
            }
            default: return heff_nomatch(v_e11_247);
            }
          }
          case TAG_EReturn: {
            heff_take_n(v_e1_2411, 0ULL, 1);
            heff_drop(v_body_248);
            switch (heff_tag_of(v_e11_247)) {
            case TAG_At: {
              heff_take_n(v_e11_247, 0ULL, 2);
              return NTAG(TAG_True);
            }
            default: return heff_nomatch(v_e11_247);
            }
          }
          default: {
            heff_drop(v_e1_2411);
            HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e11_247));
            {
              V v_field_2421 = v_t_2420.f[0];
              V v_field_2422 = v_t_2420.f[1];
              V v_x_2423 = v_field_2421;
              V v_y_2424 = v_field_2422;
              heff_drop(v_y_2424);
              if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
                heff_drop(v_body_248);
                heff_drop(v_x_2423);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_x_2423);
                HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_248);
              }
            }
          }
          }
        }
        default: return heff_nomatch(v_e11_247);
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EFor: {
      V v_e12_2426 = heff_field(v_e1_241, 1);
      V v_body_2427 = heff_field(v_e1_241, 2);
      heff_take_n(v_e1_241, 6ULL, 3);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        switch (heff_tag_of(v_e12_2426)) {
        case TAG_At: {
          V v_e1_2430 = heff_dup(heff_field(v_e12_2426, 0));
          switch (heff_tag_of(v_e1_2430)) {
          case TAG_ELam: {
            heff_take_n(v_e1_2430, 0ULL, 2);
            switch (heff_tag_of(v_e12_2426)) {
            case TAG_At: {
              heff_take_n(v_e12_2426, 0ULL, 2);
              HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_2427);
            }
            default: return heff_nomatch(v_e12_2426);
            }
          }
          case TAG_EReturn: {
            heff_take_n(v_e1_2430, 0ULL, 1);
            heff_drop(v_body_2427);
            switch (heff_tag_of(v_e12_2426)) {
            case TAG_At: {
              heff_take_n(v_e12_2426, 0ULL, 2);
              return NTAG(TAG_True);
            }
            default: return heff_nomatch(v_e12_2426);
            }
          }
          default: {
            heff_drop(v_e1_2430);
            HeffT2 v_t_2439 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), v_e12_2426));
            {
              V v_field_2440 = v_t_2439.f[0];
              V v_field_2441 = v_t_2439.f[1];
              V v_x_2442 = v_field_2440;
              V v_y_2443 = v_field_2441;
              heff_drop(v_y_2443);
              if ((heff_dup(v_x_2442) == NTAG(TAG_True))) {
                heff_drop(v_body_2427);
                heff_drop(v_x_2442);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_x_2442);
                HEFF_LAST return g_list_2eany_24s2003678755x1820404042(v_body_2427);
              }
            }
          }
          }
        }
        default: return heff_nomatch(v_e12_2426);
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EBreak: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EContinue: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    default: {
      heff_drop(v_e1_241);
      HeffT2 v_t_2451 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s118724659x1190582401_24cpr(NTAG(TAG_False), v_e_240));
      {
        V v_field_2452 = v_t_2451.f[0];
        V v_field_2453 = v_t_2451.f[1];
        V v_x_2454 = v_field_2452;
        V v_y_2455 = v_field_2453;
        heff_drop(v_y_2455);
        return v_x_2454;
      }
    }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ejumpE(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str0, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str2, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str3, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str4, 6, "MkUnit");
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(V v_cx_240, V v_sp_241, V v_c_242, V v_body_243, V v_rest_244, V v_end_245) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_c_242)) {
  case TAG_At: {
    V v_e1_246 = heff_dup(heff_field(v_c_242, 0));
    switch (heff_tag_of(v_e1_246)) {
    case TAG_ELam: {
      heff_take_n(v_e1_246, 0ULL, 2);
      switch (heff_tag_of(v_c_242)) {
      case TAG_At: {
        v_t_2420 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_243)));
        break;
      }
      default: heff_nomatch(v_c_242);
      }
      break;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_246, 0ULL, 1);
      switch (heff_tag_of(v_c_242)) {
      case TAG_At: {
        v_t_2420 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_c_242);
      }
      break;
    }
    default: {
      heff_drop(v_e1_246);
      HeffT2 v_t_2415 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_c_242)));
      {
        V v_field_2416 = v_t_2415.f[0];
        V v_field_2417 = v_t_2415.f[1];
        V v_x_2418 = v_field_2416;
        V v_y_2419 = v_field_2417;
        heff_drop(v_y_2419);
        if ((heff_dup(v_x_2418) == NTAG(TAG_True))) {
          heff_drop(v_x_2418);
          v_t_2420 = NTAG(TAG_True);
        } else {
          heff_drop(v_x_2418);
          v_t_2420 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_243)));
        }
      }
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  V v_t_2421 = heff_dup(heff_rfield(v_cx_240, 1));
  V v_t_2422 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
  V v_t_2423 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str0), v_t_2422)});
  V v_t_2427;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nil: {
    V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str1)}), heff_dup(v_sp_241)});
    v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
    break;
  }
  case TAG_Cons: {
    v_t_2427 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_t_2421));
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_sp_241)}), v_t_2427));
  V v_t_2429 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V a_0 = heff_dup(v_cx_240); V a_1 = heff_dup(v_sp_241); V a_2 = v_t_2420; V a_3 = v_t_2428; V a_4 = v_t_2429; V a_5 = heff_clo_n(g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_lam0, 1, 4, (V[]){v_cx_240, v_c_242, v_body_243, v_sp_241}); V a_6 = v_rest_244; V a_7 = v_end_245; V r_ = (g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2420); r_; });
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_lam0(V self, V *args) {
  V v_exitJ_2430 = args[0];
  V v_cx_240 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_body_243 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_cx_2431 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241(heff_dup(v_cx_240), heff_dup(v_c_242), heff_dup(v_body_243)));
  V v_t_2432 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_2431, 1)), NTAG(TAG_False)});
  HeffT2 v_t_2433 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_2431), v_t_2432}), NTAG(TAG_Nil), heff_dup(v_c_242)));
  {
    V v_field_2434 = v_t_2433.f[0];
    V v_field_2435 = v_t_2433.f[1];
    V v_x_2436 = v_field_2434;
    V v_y_2437 = v_field_2435;
    HeffT6 v_t_2438 = (g_heff_2esyntax_2epresyntax_2ewhileGiving_2einner_241_24cpr(heff_dup(v_cx_240), v_c_242, heff_dup(v_body_243)));
    V v_t_2457;
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_field_2442 = v_t_2438.f[3];
      V v_field_2443 = v_t_2438.f[4];
      V v_field_2444 = v_t_2438.f[5];
      heff_drop(v_t_2438.f[2]);
      V v_t_2445 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2446 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str2), v_t_2445)});
      V v_t_2447 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2446, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2448 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2447, heff_dup(v_exitJ_2430)})});
      V v_cx_2449 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){v_field_2439, v_field_2440, v_t_2448, v_field_2442, v_field_2443, v_field_2444});
      V v_t_2450 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2451 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str3), v_t_2450)});
      V v_t_2452 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2451, heff_dup(v_sp_241)}), heff_take_field(v_cx_240, 1), NTAG(TAG_True), heff_get_n(v_cx_240, 4, 6)});
      switch (heff_tag_of(v_body_243)) {
      case TAG_Nil: {
        v_t_2457 = (g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(v_t_2452, heff_dup(v_cx_2449), heff_get_n(v_cx_2449, 3, 6)));
        break;
      }
      case TAG_Cons: {
        V v_s_2453 = heff_field(v_body_243, 0);
        V v_x32_2454 = heff_field(v_body_243, 1);
        heff_take_n(v_body_243, 3ULL, 2);
        switch (heff_tag_of(v_x32_2454)) {
        case TAG_Nil: {
          v_t_2457 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2449, v_s_2453, v_x32_2454, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2452})));
          break;
        }
        case TAG_Cons: {
          v_t_2457 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2449, v_s_2453, v_x32_2454, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2452})));
          break;
        }
        default: heff_nomatch(v_x32_2454);
        }
        break;
      }
      default: heff_nomatch(v_body_243);
      }
    }
    V v_vars_2458 = heff_take_field(v_exitJ_2430, 1);
    V v_t_2459 = heff_take_field(v_exitJ_2430, 2);
    V v_t_2463;
    if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
      heff_drop(v_t_2459);
      switch (heff_tag_of(v_vars_2458)) {
      case TAG_Nil: {
        V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_str4)}), heff_dup(v_sp_241)});
        v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2463 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_2458));
        break;
      }
      default: heff_nomatch(v_vars_2458);
      }
    } else {
      heff_drop(v_t_2459);
      v_t_2463 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_vars_2458));
    }
    V v_t_2464 = (g_heff_2esyntax_2epresyntax_2eapp(heff_get_n(v_exitJ_2430, 0, 4), v_t_2463));
    V v_t_2465 = (g_heff_2esyntax_2epresyntax_2eifOf(v_sp_241, v_y_2437, v_t_2457, v_t_2464));
    return ({ V a_0 = v_cx_2431; V a_1 = v_x_2436; V a_2 = v_t_2465; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2436); r_; });
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str2, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str3, 5, "last#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str5, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V v_cx_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str0)}), v_sp_243});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_242, 0ULL, 2);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str1)}), v_sp_243});
    }
    case TAG_StmtExpr: {
      V v_e_249 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_249));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_sp_243, 2);
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop_cell(v_ru_24x31_242_24StmtExpr, 1);
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2epresyntax_2econtrolT_24s864966742x1272108643(v_cx_240, v_e_249, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_2410);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_240, 4)))) {
          V v_t_2411 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2411}), NTAG(TAG_Nil), v_e_249));
          {
            V v_field_2413 = v_t_2412.f[0];
            V v_field_2414 = v_t_2412.f[1];
            V v_x_2415 = v_field_2413;
            V v_y_2416 = v_field_2414;
            V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
            V v_t_2418 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24StmtExpr, TAG_EVar, 1, (V[]){v_t_2417}), heff_dup(v_sp_243)});
            V v_t_2419 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
            V v_t_2420 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str2), v_t_2419)});
            V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, heff_dup(v_sp_243)}), NTAG(TAG_Nil)});
            V v_t_2422 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2418, v_t_2421));
            V v_rest_2423 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), heff_dup(v_sp_243), heff_dup(heff_rfield(v_cx_240, 4)), v_t_2422));
            V v_t_2424 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
            V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2424}), heff_dup(heff_rfield(v_cx_240, 3))});
            V v_t_2426 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
            V v_t_2427 = heff_tag_n(TAG_LamName, 2, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str3), v_t_2426), heff_dup(v_sp_243)});
            V v_t_2430;
            switch (heff_tag_of(v_rest_2423)) {
            case TAG_At: {
              V v_s_2429 = heff_dup(heff_field(v_rest_2423, 1));
              v_t_2430 = v_s_2429;
              break;
            }
            default: heff_nomatch(v_rest_2423);
            }
            V v_t_2431 = ({ V rv_1 = heff_get_n(v_t_2430, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2427, v_rest_2423}), v_t_2431});
            V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
            V v_t_2434 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2425, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2416, v_t_2433})));
            return ({ V a_0 = v_cx_240; V a_1 = v_x_2415; V a_2 = v_t_2434; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
          }
        } else {
          heff_drop_rec(v_sp_243, 2);
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop_cell(v_ru_24x31_242_24StmtExpr, 1);
          V v_t_2435 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2436 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2435}), NTAG(TAG_Nil), v_e_249));
          {
            V v_field_2437 = v_t_2436.f[0];
            V v_field_2438 = v_t_2436.f[1];
            V v_x_2439 = v_field_2437;
            V v_y_2440 = v_field_2438;
            return ({ V a_0 = v_cx_240; V a_1 = v_x_2439; V a_2 = v_y_2440; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2439); r_; });
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str4)}), v_sp_243});
    }
    case TAG_StmtLetElse: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str5)}), v_sp_243});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeBinary_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_acc_241}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_seg_244 = heff_field(v_x11_242, 0);
      HeffT2 v_t_246 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_244));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_s_249 = v_field_248;
          V t_0 = v_rest_243;
          V t_1 = heff_strAppend(v_acc_241, v_s_249);
          v_x1_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str1, 4, "Cons");
Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elistOfChk_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elistOfChk(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str0), heff_dup(v_sp_241), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_xs_244, heff_dup(v_sp_241)));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str1), heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_246})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elistOfChk(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_t_246 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str0), NTAG(TAG_Nothing)});
    V v_t_2416;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_247 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_247)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_i_247, 1);
        heff_take_n(v_i_247, 2ULL, 2);
        v_t_2416 = v_s_249;
        break;
      }
      default: heff_nomatch(v_i_247);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_c_2410, 1);
        heff_take_n(v_c_2410, 2ULL, 2);
        v_t_2416 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_field(v_t_2413, 1);
        heff_take_n(v_t_2413, 2ULL, 2);
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2417 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2416})});
    V v_t_2427;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2418 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2418)) {
      case TAG_At: {
        V v_s_2420 = heff_field(v_i_2418, 1);
        heff_take_n(v_i_2418, 2ULL, 2);
        v_t_2427 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_i_2418);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2421 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_field(v_c_2421, 1);
        heff_take_n(v_c_2421, 2ULL, 2);
        v_t_2427 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_c_2421);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2424 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_t_2424, 1);
        heff_take_n(v_t_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2427});
  }
  case TAG_IsType: {
    V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str1), NTAG(TAG_Nothing)});
    V v_t_2439;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2430 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2430)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_i_2430, 1);
        heff_take_n(v_i_2430, 2ULL, 2);
        v_t_2439 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_i_2430);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2433 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2433)) {
      case TAG_At: {
        V v_s_2435 = heff_field(v_c_2433, 1);
        heff_take_n(v_c_2433, 2ULL, 2);
        v_t_2439 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_c_2433);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2436 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_t_2436, 1);
        heff_take_n(v_t_2436, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2440 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2439})});
    V v_t_2450;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2441 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2441)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_i_2441, 1);
        heff_take_n(v_i_2441, 2ULL, 2);
        v_t_2450 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_i_2441);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2444 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2444)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_c_2444, 1);
        heff_take_n(v_c_2444, 2ULL, 2);
        v_t_2450 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_c_2444);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2447 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2447)) {
      case TAG_At: {
        V v_s_2449 = heff_field(v_t_2447, 1);
        heff_take_n(v_t_2447, 2ULL, 2);
        v_t_2450 = v_s_2449;
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_t_2450});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewatchOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4, 10, "bitsConcat");

HeffT3 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr(V v_segs_240, V v_sp_241, V v_x5_242) {
top: ;
  if ((heff_dup(v_x5_242) == NTAG(TAG_True))) {
    V v_xs_243 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str0), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_243));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_244, heff_dup(v_sp_241)));
    V v_args_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_246));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str1)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_247}), heff_dup(v_sp_241)});
    V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_241)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str2)}), heff_dup(v_sp_241)});
    V v_t_2413 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2411));
    V v_f_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_241});
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2414, MK_INT(0LL)}});
  } else {
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str3), v_segs_240, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_241)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s1064606272x14099580_24cpr_str4)}), heff_dup(v_sp_241)});
    V v_t_2420 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2418));
    V v_f_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2419, v_t_2420}), v_sp_241});
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2421, MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2, 18, "prelude.bytesSized");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4, 9, "floatBits");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5, 10, "bytesOfInt");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6, 17, "prelude.utf8Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7, 18, "prelude.utf16Bytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8, 18, "prelude.utf32Bytes");
Clo g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_x212_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      switch (heff_tag_of(v_x212_244)) {
      case TAG_SegmentInteger: {
        V v_t_248 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(8LL), heff_dup(v_sp_242)));
        int64_t v_t_249;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_249 = ((int64_t)0ULL);
        }
        int64_t v_t_2410;
        if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)2ULL);
        } else {
          heff_drop(v_signed_247);
          v_t_2410 = ((int64_t)0ULL);
        }
        V v_t_2411 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_249 + v_t_2410))});
        V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
        HeffT3 v_t_2413 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_2426;
        {
          V v_field_2415 = v_t_2413.f[1];
          V v_field_2416 = v_t_2413.f[2];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2417 = heff_tag_n(TAG_At, 2, (V[]){v_field_2415, v_field_2416});
            v_t_2426 = v_c_2417;
          } else {
            if ((v_tag_2414 == ((int64_t)1ULL))) {
              heff_drop(v_field_2416);
              V v_i_2418 = v_field_2415;
              V v_t_2421;
              switch (heff_tag_of(v_i_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_i_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_i_2418);
              }
              v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2418}), v_t_2421});
            } else {
              V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){v_field_2415, v_field_2416});
              V v_t_2425;
              switch (heff_tag_of(v_t_2422)) {
              case TAG_At: {
                V v_s_2424 = heff_dup(heff_field(v_t_2422, 1));
                v_t_2425 = v_s_2424;
                break;
              }
              default: heff_nomatch(v_t_2422);
              }
              v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2422}), v_t_2425});
            }
          }
        }
        V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
        V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_242)}), v_t_2427});
        V v_args_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2428});
        V v_t_2430 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2429));
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str0)}), heff_dup(v_sp_242)});
        V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, v_t_2430}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2432}), v_sp_242});
      }
      case TAG_SegmentBinary: {
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        switch (heff_tag_of(v_size_245)) {
        case TAG_SizeDefault: {
          heff_drop(v_sp_242);
          HeffT3 v_t_2433 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          {
            V v_field_2435 = v_t_2433.f[1];
            V v_field_2436 = v_t_2433.f[2];
            int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
            if ((v_tag_2434 == ((int64_t)0ULL))) {
              V v_c_2437 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2435, v_field_2436});
              return v_c_2437;
            } else {
              if ((v_tag_2434 == ((int64_t)1ULL))) {
                heff_drop(v_field_2436);
                V v_i_2438 = v_field_2435;
                V v_t_2441;
                switch (heff_tag_of(v_i_2438)) {
                case TAG_At: {
                  V v_s_2440 = heff_dup(heff_field(v_i_2438, 1));
                  v_t_2441 = v_s_2440;
                  break;
                }
                default: heff_nomatch(v_i_2438);
                }
                return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2438}), v_t_2441});
              } else {
                V v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2435, v_field_2436});
                V v_t_2445;
                switch (heff_tag_of(v_t_2442)) {
                case TAG_At: {
                  V v_s_2444 = heff_dup(heff_field(v_t_2442, 1));
                  v_t_2445 = v_s_2444;
                  break;
                }
                default: heff_nomatch(v_t_2442);
                }
                return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2442}), v_t_2445});
              }
            }
          }
        }
        case TAG_SizeNumber: {
          V v_t_2447 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT3 v_t_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2461;
          {
            V v_field_2450 = v_t_2448.f[1];
            V v_field_2451 = v_t_2448.f[2];
            int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
            if ((v_tag_2449 == ((int64_t)0ULL))) {
              V v_c_2452 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2450, v_field_2451});
              v_t_2461 = v_c_2452;
            } else {
              if ((v_tag_2449 == ((int64_t)1ULL))) {
                heff_drop(v_field_2451);
                V v_i_2453 = v_field_2450;
                V v_t_2456;
                switch (heff_tag_of(v_i_2453)) {
                case TAG_At: {
                  V v_s_2455 = heff_dup(heff_field(v_i_2453, 1));
                  v_t_2456 = v_s_2455;
                  break;
                }
                default: heff_nomatch(v_i_2453);
                }
                v_t_2461 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2453}), v_t_2456});
              } else {
                V v_t_2457 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2450, v_field_2451});
                V v_t_2460;
                switch (heff_tag_of(v_t_2457)) {
                case TAG_At: {
                  V v_s_2459 = heff_dup(heff_field(v_t_2457, 1));
                  v_t_2460 = v_s_2459;
                  break;
                }
                default: heff_nomatch(v_t_2457);
                }
                v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2457}), v_t_2460});
              }
            }
          }
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
          V v_args_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_t_2462});
          V v_t_2464 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2463));
          V v_t_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str1)}), heff_dup(v_sp_242)});
          V v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2465, v_t_2464}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2466}), v_sp_242});
        }
        case TAG_SizeName: {
          V v_t_2470 = (g_heff_2esyntax_2epresyntax_2ebytesTerm(v_size_245, heff_dup(v_sp_242)));
          HeffT3 v_t_2471 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
          V v_t_2484;
          {
            V v_field_2473 = v_t_2471.f[1];
            V v_field_2474 = v_t_2471.f[2];
            int64_t v_tag_2472 = ((int64_t)v_t_2471.f[0]);
            if ((v_tag_2472 == ((int64_t)0ULL))) {
              V v_c_2475 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2473, v_field_2474});
              v_t_2484 = v_c_2475;
            } else {
              if ((v_tag_2472 == ((int64_t)1ULL))) {
                heff_drop(v_field_2474);
                V v_i_2476 = v_field_2473;
                V v_t_2479;
                switch (heff_tag_of(v_i_2476)) {
                case TAG_At: {
                  V v_s_2478 = heff_dup(heff_field(v_i_2476, 1));
                  v_t_2479 = v_s_2478;
                  break;
                }
                default: heff_nomatch(v_i_2476);
                }
                v_t_2484 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2476}), v_t_2479});
              } else {
                V v_t_2480 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2473, v_field_2474});
                V v_t_2483;
                switch (heff_tag_of(v_t_2480)) {
                case TAG_At: {
                  V v_s_2482 = heff_dup(heff_field(v_t_2480, 1));
                  v_t_2483 = v_s_2482;
                  break;
                }
                default: heff_nomatch(v_t_2480);
                }
                v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2480}), v_t_2483});
              }
            }
          }
          V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
          V v_args_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, v_t_2485});
          V v_t_2487 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_2486));
          V v_t_2488 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str2)}), heff_dup(v_sp_242)});
          V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2488, v_t_2487}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2489}), v_sp_242});
        }
        default: return heff_nomatch(v_size_245);
        }
      }
      case TAG_SegmentBits: {
        heff_drop(v_size_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        HeffT3 v_t_2490 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24103;
        {
          V v_field_2492 = v_t_2490.f[1];
          V v_field_2493 = v_t_2490.f[2];
          int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
          if ((v_tag_2491 == ((int64_t)0ULL))) {
            V v_c_2494 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2492, v_field_2493});
            v_t_24103 = v_c_2494;
          } else {
            if ((v_tag_2491 == ((int64_t)1ULL))) {
              heff_drop(v_field_2493);
              V v_i_2495 = v_field_2492;
              V v_t_2498;
              switch (heff_tag_of(v_i_2495)) {
              case TAG_At: {
                V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
                v_t_2498 = v_s_2497;
                break;
              }
              default: heff_nomatch(v_i_2495);
              }
              v_t_24103 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
            } else {
              V v_t_2499 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2492, v_field_2493});
              V v_t_24102;
              switch (heff_tag_of(v_t_2499)) {
              case TAG_At: {
                V v_s_24101 = heff_dup(heff_field(v_t_2499, 1));
                v_t_24102 = v_s_24101;
                break;
              }
              default: heff_nomatch(v_t_2499);
              }
              v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2499}), v_t_24102});
            }
          }
        }
        V v_args_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
        V v_t_24105 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24104));
        V v_t_24106 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str3)}), heff_dup(v_sp_242)});
        V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24106, v_t_24105}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24107}), v_sp_242});
      }
      case TAG_SegmentFloat: {
        heff_drop(v_signed_247);
        V v_t_24108 = (g_heff_2esyntax_2epresyntax_2esizeTerm(heff_dup(v_size_245), MK_INT(64LL), heff_dup(v_sp_242)));
        int64_t v_t_24109;
        if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
          heff_drop(v_little_246);
          v_t_24109 = ((int64_t)1ULL);
        } else {
          heff_drop(v_little_246);
          v_t_24109 = ((int64_t)0ULL);
        }
        V v_t_24110 = heff_tag_n(TAG_IInt, 1, (V[]){heff_box_word((v_t_24109 + ((int64_t)0ULL)))});
        V v_t_24111 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24110, heff_dup(v_sp_242)})});
        V v_t_24112 = (g_heff_2esyntax_2epresyntax_2esizeTerm(v_size_245, MK_INT(64LL), heff_dup(v_sp_242)));
        HeffT3 v_t_24113 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_243));
        V v_t_24126;
        {
          V v_field_24115 = v_t_24113.f[1];
          V v_field_24116 = v_t_24113.f[2];
          int64_t v_tag_24114 = ((int64_t)v_t_24113.f[0]);
          if ((v_tag_24114 == ((int64_t)0ULL))) {
            V v_c_24117 = heff_tag_n(TAG_At, 2, (V[]){v_field_24115, v_field_24116});
            v_t_24126 = v_c_24117;
          } else {
            if ((v_tag_24114 == ((int64_t)1ULL))) {
              heff_drop(v_field_24116);
              V v_i_24118 = v_field_24115;
              V v_t_24121;
              switch (heff_tag_of(v_i_24118)) {
              case TAG_At: {
                V v_s_24120 = heff_dup(heff_field(v_i_24118, 1));
                v_t_24121 = v_s_24120;
                break;
              }
              default: heff_nomatch(v_i_24118);
              }
              v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24118}), v_t_24121});
            } else {
              V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){v_field_24115, v_field_24116});
              V v_t_24125;
              switch (heff_tag_of(v_t_24122)) {
              case TAG_At: {
                V v_s_24124 = heff_dup(heff_field(v_t_24122, 1));
                v_t_24125 = v_s_24124;
                break;
              }
              default: heff_nomatch(v_t_24122);
              }
              v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24122}), v_t_24125});
            }
          }
        }
        V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
        V v_args_24128 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24112, v_t_24127});
        V v_t_24129 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24128));
        V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str4)}), heff_dup(v_sp_242)});
        V v_t_24131 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24130, v_t_24129}), heff_dup(v_sp_242)});
        V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24131}), heff_dup(v_sp_242)});
        V v_t_24133 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
        V v_t_24134 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24111, heff_dup(v_sp_242)}), v_t_24133});
        V v_args_24135 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24108, v_t_24134});
        V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24135));
        V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str5)}), heff_dup(v_sp_242)});
        V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24136}), heff_dup(v_sp_242)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24138}), v_sp_242});
      }
      case TAG_SegmentUtf: {
        V v_x2121_24139 = heff_field(v_x212_244, 0);
        V v_ru_24x212_244_24SegmentUtf = heff_take_reuse_n(v_x212_244, 1ULL, 1);
        heff_drop(v_size_245);
        heff_drop(v_signed_247);
        if (heff_intEq_c_lent(v_x2121_24139, MK_INT(8LL), 2)) {
          heff_drop(v_little_246);
          heff_drop(v_x2121_24139);
          V v_t_24140 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
          V v_args_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24140, NTAG(TAG_Nil)});
          V v_t_24142 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24141));
          V v_t_24143 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str6)}), heff_dup(v_sp_242)});
          V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, v_t_24142}), heff_dup(v_sp_242)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), v_sp_242});
        } else {
          if (heff_intEq_c(v_x2121_24139, MK_INT(16LL))) {
            int64_t v_t_24145;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24145 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24145 = ((int64_t)0ULL);
            }
            V v_t_24146 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24145 + ((int64_t)0ULL)))});
            V v_t_24147 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24146, heff_dup(v_sp_242)})});
            V v_t_24148 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24149 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
            V v_args_24150 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24147, heff_dup(v_sp_242)}), v_t_24149});
            V v_t_24151 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24150));
            V v_t_24152 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str7)}), heff_dup(v_sp_242)});
            V v_t_24153 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24152, v_t_24151}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24153}), v_sp_242});
          } else {
            int64_t v_t_24154;
            if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
              heff_drop(v_little_246);
              v_t_24154 = ((int64_t)1ULL);
            } else {
              heff_drop(v_little_246);
              v_t_24154 = ((int64_t)0ULL);
            }
            V v_t_24155 = heff_tag_at_n(v_ru_24x212_244_24SegmentUtf, TAG_IInt, 1, (V[]){heff_box_word((v_t_24154 + ((int64_t)0ULL)))});
            V v_t_24156 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24155, heff_dup(v_sp_242)})});
            V v_t_24157 = (g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(v_v_243, heff_dup(v_sp_242)));
            V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24157, NTAG(TAG_Nil)});
            V v_args_24159 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24156, heff_dup(v_sp_242)}), v_t_24158});
            V v_t_24160 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), v_args_24159));
            V v_t_24161 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_str8)}), heff_dup(v_sp_242)});
            V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24161, v_t_24160}), heff_dup(v_sp_242)});
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24162}), v_sp_242});
          }
        }
      }
      default: return heff_nomatch(v_x212_244);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebytesPart_24s1720743007x1218627387(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1, 22, "`Array` takes one type");

HeffT3 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V v_h_240, V v_args_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_243 = heff_dup(heff_field(v_h_240, 0));
    switch (heff_tag_of(v_h1_243)) {
    case TAG_ETag: {
      V v_t_245 = heff_field(v_h1_243, 0);
      heff_take_n(v_h1_243, 1ULL, 1);
      switch (heff_tag_of(v_h_240)) {
      case TAG_At: {
        V v_tsp_247 = heff_field(v_h_240, 1);
        heff_take_n(v_h_240, 2ULL, 2);
        V v_t_248 = (g_list_2emap_24s1844509821x2028168277(v_args_241));
        V v_f_249 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_245, v_tsp_247, v_t_248});
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_249, v_sp_242}});
      }
      default: return ((HeffT3){{heff_nomatch(v_h_240)}});
      }
    }
    case TAG_EWord: {
      V v_h11_2410 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24EWord = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      switch (heff_tag_of(v_h11_2410)) {
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_240, 2);
        switch (heff_tag_of(v_args_241)) {
        case TAG_Nil: {
          V v_t_2411 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0), NTAG(TAG_Nothing)});
          V v_t_2412 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_242)})});
          return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_t_2412, v_sp_242}});
        }
        case TAG_Cons: {
          V v_a_2413 = heff_field(v_args_241, 0);
          V v_args2_2414 = heff_field(v_args_241, 1);
          V v_ru_24args_241_24Cons = heff_take_reuse_n(v_args_241, 3ULL, 2);
          switch (heff_tag_of(v_args2_2414)) {
          case TAG_Nil: {
            HeffT3 v_t_2415 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_2413));
            V v_t_2428;
            {
              V v_field_2417 = v_t_2415.f[1];
              V v_field_2418 = v_t_2415.f[2];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_c_2419 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_field_2417, v_field_2418});
                V v_t_2422;
                switch (heff_tag_of(v_c_2419)) {
                case TAG_At: {
                  V v_s_2421 = heff_dup(heff_field(v_c_2419, 1));
                  v_t_2422 = v_s_2421;
                  break;
                }
                default: heff_nomatch(v_c_2419);
                }
                v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TChk, 1, (V[]){v_c_2419}), v_t_2422});
              } else {
                if ((v_tag_2416 == ((int64_t)1ULL))) {
                  heff_drop(v_field_2418);
                  V v_i_2423 = v_field_2417;
                  V v_t_2426;
                  switch (heff_tag_of(v_i_2423)) {
                  case TAG_At: {
                    V v_s_2425 = heff_dup(heff_field(v_i_2423, 1));
                    v_t_2426 = v_s_2425;
                    break;
                  }
                  default: heff_nomatch(v_i_2423);
                  }
                  v_t_2428 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_i_2423}), v_t_2426});
                } else {
                  heff_drop_cell(v_ru_24h1_243_24EWord, 1);
                  V v_t_2427 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_field_2417, v_field_2418});
                  v_t_2428 = v_t_2427;
                }
              }
            }
            V v_f_2429 = heff_tag_n(TAG_TArray, 1, (V[]){v_t_2428});
            return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_f_2429, v_sp_242}});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2414, 0ULL, 2);
            heff_drop(v_a_2413);
            V v_t_2432 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1), NTAG(TAG_Nothing)});
            V v_t_2433 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_t_2432, heff_dup(v_sp_242)})});
            return ((HeffT3){{heff_word_i64(((int64_t)2ULL)), v_t_2433, v_sp_242}});
          }
          default: return ((HeffT3){{heff_nomatch(v_args2_2414)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_args_241)}});
        }
      }
      default: {
        heff_drop(v_h11_2410);
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2434));
        V v_t_2436 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2435, v_t_2436}), v_sp_242});
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2437, MK_INT(0LL)}});
      }
      }
    }
    default: {
      heff_drop(v_h1_243);
      V v_t_2438 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2439 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2438));
      V v_t_2440 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2439, v_t_2440}), v_sp_242});
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2441, MK_INT(0LL)}});
    }
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_h_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_IVar: {
    return v_n_240;
  }
  case TAG_INotationVar: {
    return v_n_240;
  }
  case TAG_IInt: {
    return v_n_240;
  }
  case TAG_IFloat: {
    return v_n_240;
  }
  case TAG_IString: {
    return v_n_240;
  }
  case TAG_IBytes: {
    return v_n_240;
  }
  case TAG_IPrim: {
    return v_n_240;
  }
  case TAG_IRune: {
    return v_n_240;
  }
  case TAG_IApp: {
    V v_h_2411 = heff_field(v_n_240, 0);
    V v_args_2412 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IApp = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_h_2411)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_h_2411, 0);
      V v_sp_2414 = heff_field(v_h_2411, 1);
      V v_ru_24h_2411_24At = heff_take_reuse_n(v_h_2411, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24h_2411_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_h_2411);
    }
    V v_t_2417 = (g_list_2emap_24s126994153x1029399760(v_args_2412));
    return heff_tag_at_n(v_ru_24n_240_24IApp, TAG_IApp, 2, (V[]){v_t_2416, v_t_2417});
  }
  case TAG_IAnn: {
    V v_c_2418 = heff_field(v_n_240, 0);
    V v_t_2419 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IAnn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_c_2418)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_c_2418, 0);
      V v_sp_2421 = heff_field(v_c_2418, 1);
      V v_ru_24c_2418_24At = heff_take_reuse_n(v_c_2418, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24c_2418_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_c_2418);
    }
    V v_t_2426;
    switch (heff_tag_of(v_t_2419)) {
    case TAG_At: {
      V v_n_2424 = heff_field(v_t_2419, 0);
      V v_sp_2425 = heff_field(v_t_2419, 1);
      V v_ru_24t_2419_24At = heff_take_reuse_n(v_t_2419, 3ULL, 2);
      v_t_2426 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2419_24At, v_sp_2425, v_n_2424));
      break;
    }
    default: heff_nomatch(v_t_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnn, TAG_IAnn, 2, (V[]){v_t_2423, v_t_2426});
  }
  case TAG_ISpec: {
    V v_a_2427 = heff_field(v_n_240, 0);
    V v_x_2428 = heff_field(v_n_240, 1);
    V v_sp_2429 = heff_field(v_n_240, 2);
    V v_v_2430 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ISpec = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2434;
    switch (heff_tag_of(v_a_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_a_2427, 0);
      V v_sp_2432 = heff_field(v_a_2427, 1);
      V v_ru_24a_2427_24At = heff_take_reuse_n(v_a_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24a_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_a_2427);
    }
    V v_t_2438;
    switch (heff_tag_of(v_v_2430)) {
    case TAG_At: {
      V v_n_2435 = heff_field(v_v_2430, 0);
      V v_sp_2436 = heff_field(v_v_2430, 1);
      V v_ru_24v_2430_24At = heff_take_reuse_n(v_v_2430, 3ULL, 2);
      V v_t_2437 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2435));
      v_t_2438 = heff_tag_at_n(v_ru_24v_2430_24At, TAG_At, 2, (V[]){v_t_2437, v_sp_2436});
      break;
    }
    default: heff_nomatch(v_v_2430);
    }
    return heff_tag_at_n(v_ru_24n_240_24ISpec, TAG_ISpec, 4, (V[]){v_t_2434, v_x_2428, v_sp_2429, v_t_2438});
  }
  case TAG_IUpdate: {
    V v_a_2439 = heff_field(v_n_240, 0);
    V v_fs_2440 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IUpdate = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_a_2439)) {
    case TAG_At: {
      V v_n_2441 = heff_field(v_a_2439, 0);
      V v_sp_2442 = heff_field(v_a_2439, 1);
      V v_ru_24a_2439_24At = heff_take_reuse_n(v_a_2439, 3ULL, 2);
      V v_t_2443 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2441));
      v_t_2444 = heff_tag_at_n(v_ru_24a_2439_24At, TAG_At, 2, (V[]){v_t_2443, v_sp_2442});
      break;
    }
    default: heff_nomatch(v_a_2439);
    }
    V v_t_2445 = (g_list_2emap_24s366989016x166432442(v_fs_2440));
    return heff_tag_at_n(v_ru_24n_240_24IUpdate, TAG_IUpdate, 2, (V[]){v_t_2444, v_t_2445});
  }
  case TAG_IAnnLam: {
    V v_x_2446 = heff_field(v_n_240, 0);
    V v_sp_2447 = heff_field(v_n_240, 1);
    V v_t_2448 = heff_field(v_n_240, 2);
    V v_b_2449 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24IAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2452;
    switch (heff_tag_of(v_t_2448)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_t_2448, 0);
      V v_sp_2451 = heff_field(v_t_2448, 1);
      V v_ru_24t_2448_24At = heff_take_reuse_n(v_t_2448, 3ULL, 2);
      v_t_2452 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2448_24At, v_sp_2451, v_n_2450));
      break;
    }
    default: heff_nomatch(v_t_2448);
    }
    V v_t_2456;
    switch (heff_tag_of(v_b_2449)) {
    case TAG_At: {
      V v_n_2453 = heff_field(v_b_2449, 0);
      V v_sp_2454 = heff_field(v_b_2449, 1);
      V v_ru_24b_2449_24At = heff_take_reuse_n(v_b_2449, 3ULL, 2);
      V v_t_2455 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2453));
      v_t_2456 = heff_tag_at_n(v_ru_24b_2449_24At, TAG_At, 2, (V[]){v_t_2455, v_sp_2454});
      break;
    }
    default: heff_nomatch(v_b_2449);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_x_2446, v_sp_2447, v_t_2452, v_t_2456});
  }
  case TAG_IInvalid: {
    return v_n_240;
  }
  case TAG_INominal: {
    return v_n_240;
  }
  case TAG_ILitEq: {
    V v_x_2461 = heff_field(v_n_240, 0);
    V v_sp_2462 = heff_field(v_n_240, 1);
    V v_eq_2463 = heff_field(v_n_240, 2);
    V v_lit_2464 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ILitEq = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2468;
    switch (heff_tag_of(v_lit_2464)) {
    case TAG_At: {
      V v_n_2465 = heff_field(v_lit_2464, 0);
      V v_sp_2466 = heff_field(v_lit_2464, 1);
      V v_ru_24lit_2464_24At = heff_take_reuse_n(v_lit_2464, 3ULL, 2);
      V v_t_2467 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2465));
      v_t_2468 = heff_tag_at_n(v_ru_24lit_2464_24At, TAG_At, 2, (V[]){v_t_2467, v_sp_2466});
      break;
    }
    default: heff_nomatch(v_lit_2464);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILitEq, TAG_ILitEq, 4, (V[]){v_x_2461, v_sp_2462, v_eq_2463, v_t_2468});
  }
  case TAG_ILazy: {
    V v_c_2469 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24ILazy = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2473;
    switch (heff_tag_of(v_c_2469)) {
    case TAG_At: {
      V v_n_2470 = heff_field(v_c_2469, 0);
      V v_sp_2471 = heff_field(v_c_2469, 1);
      V v_ru_24c_2469_24At = heff_take_reuse_n(v_c_2469, 3ULL, 2);
      V v_t_2472 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2470));
      v_t_2473 = heff_tag_at_n(v_ru_24c_2469_24At, TAG_At, 2, (V[]){v_t_2472, v_sp_2471});
      break;
    }
    default: heff_nomatch(v_c_2469);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILazy, TAG_ILazy, 1, (V[]){v_t_2473});
  }
  case TAG_ITuple: {
    V v_cs_2474 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24ITuple = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2475 = (g_list_2emap_24s79542405x478516404(v_cs_2474));
    return heff_tag_at_n(v_ru_24n_240_24ITuple, TAG_ITuple, 1, (V[]){v_t_2475});
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_245 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_list_2emap_24s1992667171x110340492(v_fs_246));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_t_247}), v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TSum, 1, (V[]){v_vs_248})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2411 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2415 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2417 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2425 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2426 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_i_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_i_2426, 0);
      V v_sp_2428 = heff_field(v_i_2426, 1);
      V v_ru_24i_2426_24At = heff_take_reuse_n(v_i_2426, 3ULL, 2);
      v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_24tok2(v_ru_24i_2426_24At, v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_i_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2429}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2430 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_c_2430)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_c_2430, 0);
      V v_sp_2432 = heff_field(v_c_2430, 1);
      heff_take_n(v_c_2430, 3ULL, 2);
      v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
      break;
    }
    default: heff_nomatch(v_c_2430);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2433}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2436 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(a[0], a[1]);
}