// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CInf 46723
#define TAG_CTag 56892
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_ExplicitParam 63083
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_PatVar 49363
#define TAG_RuneWord 42901
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TypeWord 10401
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stmts[] = {LBL_stmts};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmStmts(V);
V g_heff_2esyntax_2epresyntax_2earmStmts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmStmts_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626_clo;
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2econtrolT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2econtrolT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2econtrolT_clo;
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V, V);
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo;
V g_heff_2esyntax_2epresyntax_2edoT_get(void);
V g_heff_2esyntax_2epresyntax_2eforT(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_clo;
V g_heff_2esyntax_2epresyntax_2eforT_24tok2(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241(V);
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eit_241_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2epresyntax_2escopeJoin(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2escopeJoin_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2escopeJoin_clo;
V g_heff_2esyntax_2epresyntax_2estmtAcc(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etryScope(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_clo;
V g_heff_2esyntax_2epresyntax_2etryT_24tok2(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryT_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryT_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s126994153x1029399760(V);
V g_list_2emap_24s126994153x1029399760_entry(V self, V *a);
extern Clo g_list_2emap_24s126994153x1029399760_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s366989016x166432442(V);
V g_list_2emap_24s366989016x166432442_entry(V self, V *a);
extern Clo g_list_2emap_24s366989016x166432442_clo;
V g_list_2emap_24s529174x2075875906(V);
V g_list_2emap_24s529174x2075875906_entry(V self, V *a);
extern Clo g_list_2emap_24s529174x2075875906_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eboolOf_str0, 12, "builtin.Bool");
Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eboolOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eboolOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_c1_241 = heff_dup(heff_field(v_c_240, 0));
    switch (heff_tag_of(v_c1_241)) {
    case TAG_EVar: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ETag: {
      V v_t_245 = heff_field(v_c1_241, 0);
      V v_ru_24c1_241_24ETag = heff_take_reuse_n(v_c1_241, 1ULL, 1);
      switch (heff_tag_of(v_c_240)) {
      case TAG_At: {
        V v_sp_247 = heff_field(v_c_240, 1);
        V v_ru_24c_240_24At = heff_take_reuse_n(v_c_240, 2ULL, 2);
        V v_t_248 = heff_tag_at_n(v_ru_24c_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c1_241_24ETag, TAG_ETag, 1, (V[]){v_t_245}), heff_dup(v_sp_247)});
        V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eboolOf_str0)}), heff_dup(v_sp_247)});
        V v_t_2410 = ({ V rr_ = heff_rec_reuse_na(v_sp_247, 3ULL, 2, shape_start__end, 15u, 0u); rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_248, v_t_249}), v_t_2410});
      }
      default: return heff_nomatch(v_c_240);
      }
    }
    case TAG_EInt: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EFloat: {
      heff_take_na(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EString: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ERune: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EWord: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EApp: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EProject: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EPi: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ELam: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_c1_241, 0ULL, 4);
      return v_c_240;
    }
    case TAG_ESig: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ESum: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EDo: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EFor: {
      heff_take_n(v_c1_241, 0ULL, 3);
      return v_c_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_c1_241, 0ULL, 2);
      return v_c_240;
    }
    case TAG_EBreak: {
      return v_c_240;
    }
    case TAG_EContinue: {
      return v_c_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ENest: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_ETry: {
      heff_take_n(v_c1_241, 0ULL, 1);
      return v_c_240;
    }
    case TAG_EWith: {
      heff_take_n(v_c1_241, 0ULL, 4);
      return v_c_240;
    }
    default: return heff_nomatch(v_c1_241);
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eboolOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2estmtAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtAcc_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2estmtAcc(V v_f_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_At: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24At = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_xsp_246 = heff_field(v_x31_243, 1);
      V v_e_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_248 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_247}));
      switch (heff_tag_of(v_x1_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x1_248, 0);
        V v_y_2410 = heff_field(v_x1_248, 1);
        V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtBind, 3, (V[]){v_x_245, v_xsp_246, v_y_2410}), v_sp_244});
        return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_249, v_t_2411});
      }
      default: return heff_nomatch(v_x1_248);
      }
    }
    case TAG_StmtLet: {
      V v_p_2412 = heff_field(v_x31_243, 0);
      V v_e_2413 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24StmtLet = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_x1_2414 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2413}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        V v_y_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_p_2412, v_y_2416}), v_sp_244});
        return heff_tag_at_n(v_ru_24x31_243_24StmtLet, TAG_MkPair, 2, (V[]){v_x_2415, v_t_2417});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_StmtExpr: {
      V v_e_2418 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2418}));
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x1_2419, 0);
        V v_y_2421 = heff_field(v_x1_2419, 1);
        V v_ru_24x1_2419_24MkPair = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
        V v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_y_2421}), v_sp_244});
        return heff_tag_at_n(v_ru_24x1_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_t_2422});
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    case TAG_StmtLetMut: {
      V v_x_2423 = heff_field(v_x31_243, 0);
      V v_xsp_2424 = heff_field(v_x31_243, 1);
      V v_e_2425 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_2426 = heff_tr(heff_call(v_f_240, 2, (V[]){v_st_241, v_e_2425}));
      switch (heff_tag_of(v_x1_2426)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x1_2426, 0);
        V v_y_2428 = heff_field(v_x1_2426, 1);
        V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
        V v_t_2429 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetMut, 3, (V[]){v_x_2423, v_xsp_2424, v_y_2428}), v_sp_244});
        return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_t_2429});
      }
      default: return heff_nomatch(v_x1_2426);
      }
    }
    case TAG_StmtLetElse: {
      V v_p_2430 = heff_field(v_x31_243, 0);
      V v_e_2431 = heff_field(v_x31_243, 1);
      V v_ss_2432 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_x1_2433 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_st_241, v_e_2431}));
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_MkPair: {
        V v_x_2434 = heff_field(v_x1_2433, 0);
        V v_y_2435 = heff_field(v_x1_2433, 1);
        V v_ru_24x1_2433_24MkPair = heff_take_reuse_n(v_x1_2433, 3ULL, 2);
        V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2estmtAcc_clo), 1, (V[]){v_f_240}));
        HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2eaccList_24cpr(v_t_2436, v_x_2434, v_ss_2432));
        {
          V v_field_2438 = v_t_2437.f[0];
          V v_field_2439 = v_t_2437.f[1];
          V v_x_2440 = v_field_2438;
          V v_y_2441 = v_field_2439;
          V v_t_2442 = heff_tag_at_n(v_ru_24x3_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetElse, 3, (V[]){v_p_2430, v_y_2435, v_y_2441}), v_sp_244});
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2440, v_t_2442});
        }
      }
      default: return heff_nomatch(v_x1_2433);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2estmtAcc(a[0], a[1], a[2]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x31_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_244)) {
      case TAG_SetField: {
        V v_x_246 = heff_field(v_x31_244, 0);
        V v_xsp_247 = heff_field(v_x31_244, 1);
        V v_e_248 = heff_field(v_x31_244, 2);
        heff_take_n(v_x31_244, 7ULL, 3);
        V v_x_249;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_249 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_249 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_248)));
        }
        HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(v_x_249, v_xs_243));
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_x_2413 = v_field_2411;
          V v_y_2414 = v_field_2412;
          V v_t_2415 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_x_246, v_xsp_247, v_e_248}), v_sp_245});
          return ((HeffT2){{v_x_2413, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_y_2414})}});
        }
      }
      case TAG_BadFieldSet: {
        V v_e_2416 = heff_field(v_x31_244, 0);
        heff_take_n(v_x31_244, 1ULL, 1);
        V v_x_2417;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2417 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2417 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_e_2416)));
        }
        HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1754932173x1305177089_24cpr(v_x_2417, v_xs_243));
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_x_2421 = v_field_2419;
          V v_y_2422 = v_field_2420;
          V v_t_2423 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_e_2416}), v_sp_245});
          return ((HeffT2){{v_x_2421, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, v_y_2422})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_x111_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      switch (heff_tag_of(v_x111_244)) {
      case TAG_StmtBind: {
        heff_take_n(v_x111_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLet: {
        heff_take_n(v_x111_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtExpr: {
        heff_take_n(v_x111_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLetMut: {
        V v_x_2412 = heff_field(v_x111_244, 0);
        heff_take_n(v_x111_244, 1ULL, 3);
        V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
        V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
        heff_drop(v_u_2416);
        V t_0 = v_rest_243;
        V t_1 = v_cell_2415;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_x111_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V t_0 = v_rest_243;
        V t_1 = v_d_241;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x111_244);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclaredMuts_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2earmStmts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmStmts_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2earmStmts(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      V v_ru_24e1_241_24EVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_246;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_245 = heff_dup(heff_field(v_e_240, 1));
        v_t_246 = v_s_245;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EVar, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_246});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_241_24EImplicitVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_e_240, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EImplicitVar, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2411});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
    }
    case TAG_ETag: {
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_e_240, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2416});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    }
    case TAG_EInt: {
      V v_ru_24e1_241_24EInt = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2421;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2420 = heff_dup(heff_field(v_e_240, 1));
        v_t_2421 = v_s_2420;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInt, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2421});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    }
    case TAG_EFloat: {
      V v_ru_24e1_241_24EFloat = heff_take_reuse_na(v_e1_241, 0ULL, 1);
      V v_t_2426;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_e_240, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EFloat, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2426});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    }
    case TAG_EString: {
      V v_ru_24e1_241_24EString = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2430 = heff_dup(heff_field(v_e_240, 1));
        v_t_2431 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EString, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2431});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
    }
    case TAG_EBinary: {
      V v_ru_24e1_241_24EBinary = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2436;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2435 = heff_dup(heff_field(v_e_240, 1));
        v_t_2436 = v_s_2435;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EBinary, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2436});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
    }
    case TAG_ERune: {
      V v_ru_24e1_241_24ERune = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2441;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2440 = heff_dup(heff_field(v_e_240, 1));
        v_t_2441 = v_s_2440;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ERune, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2441});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
    }
    case TAG_EWord: {
      V v_ru_24e1_241_24EWord = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2446;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2445 = heff_dup(heff_field(v_e_240, 1));
        v_t_2446 = v_s_2445;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EWord, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2446});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
    }
    case TAG_EApp: {
      V v_ru_24e1_241_24EApp = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_2452;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2451 = heff_dup(heff_field(v_e_240, 1));
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2453 = heff_tag_at_n(v_ru_24e1_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2452});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    }
    case TAG_EProject: {
      V v_ru_24e1_241_24EProject = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_e_240, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EProject, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2457});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
    }
    case TAG_ENamed: {
      V v_ru_24e1_241_24ENamed = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_2463;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2462 = heff_dup(heff_field(v_e_240, 1));
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2464 = heff_tag_at_n(v_ru_24e1_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2463});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
    }
    case TAG_EPi: {
      V v_ru_24e1_241_24EPi = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_2469;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_e_240, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2470 = heff_tag_at_n(v_ru_24e1_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2469});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    }
    case TAG_ELam: {
      V v_ru_24e1_241_24ELam = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_2475;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2474 = heff_dup(heff_field(v_e_240, 1));
        v_t_2475 = v_s_2474;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2476 = heff_tag_at_n(v_ru_24e1_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2475});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
    }
    case TAG_EAnn: {
      V v_ru_24e1_241_24EAnn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_2481;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2480 = heff_dup(heff_field(v_e_240, 1));
        v_t_2481 = v_s_2480;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2482 = heff_tag_at_n(v_ru_24e1_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2481});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2482, NTAG(TAG_Nil)});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      V v_t_2489;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2488 = heff_dup(heff_field(v_e_240, 1));
        v_t_2489 = v_s_2488;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2489});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2490, NTAG(TAG_Nil)});
    }
    case TAG_ESig: {
      V v_ru_24e1_241_24ESig = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2494;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2493 = heff_dup(heff_field(v_e_240, 1));
        v_t_2494 = v_s_2493;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_2495 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESig, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2494});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
    }
    case TAG_ESum: {
      V v_ru_24e1_241_24ESum = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_2499;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2498 = heff_dup(heff_field(v_e_240, 1));
        v_t_2499 = v_s_2498;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24100 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESum, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_2499});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24100, NTAG(TAG_Nil)});
    }
    case TAG_EStruct: {
      V v_ru_24e1_241_24EStruct = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_24104;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24103 = heff_dup(heff_field(v_e_240, 1));
        v_t_24104 = v_s_24103;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EStruct, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24104});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24105, NTAG(TAG_Nil)});
    }
    case TAG_EUpdate: {
      V v_ru_24e1_241_24EUpdate = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_24110;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24109 = heff_dup(heff_field(v_e_240, 1));
        v_t_24110 = v_s_24109;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24111 = heff_tag_at_n(v_ru_24e1_241_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24110});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24111, NTAG(TAG_Nil)});
    }
    case TAG_EMatch: {
      V v_ru_24e1_241_24EMatch = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_24116;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24115 = heff_dup(heff_field(v_e_240, 1));
        v_t_24116 = v_s_24115;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24117 = heff_tag_at_n(v_ru_24e1_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24116});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, NTAG(TAG_Nil)});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_241_24ELetIn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_24122;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24121 = heff_dup(heff_field(v_e_240, 1));
        v_t_24122 = v_s_24121;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24123 = heff_tag_at_n(v_ru_24e1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24122});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
    }
    case TAG_EDo: {
      V v_ss_24124 = heff_field(v_e1_241, 0);
      heff_take_n(v_e1_241, 1ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        heff_take_n(v_e_240, 0ULL, 2);
        return v_ss_24124;
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_ELocal: {
      V v_ru_24e1_241_24ELocal = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_24131;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24130 = heff_dup(heff_field(v_e_240, 1));
        v_t_24131 = v_s_24130;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24132 = heff_tag_at_n(v_ru_24e1_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24131});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24132, NTAG(TAG_Nil)});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_241_24EInvalid = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_24136;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24135 = heff_dup(heff_field(v_e_240, 1));
        v_t_24136 = v_s_24135;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24137 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInvalid, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24136});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24137, NTAG(TAG_Nil)});
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      V v_t_24143;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24142 = heff_dup(heff_field(v_e_240, 1));
        v_t_24143 = v_s_24142;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24143});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24144, NTAG(TAG_Nil)});
    }
    case TAG_EWhile: {
      V v_ru_24e1_241_24EWhile = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_24149;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24148 = heff_dup(heff_field(v_e_240, 1));
        v_t_24149 = v_s_24148;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24150 = heff_tag_at_n(v_ru_24e1_241_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24149});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24150, NTAG(TAG_Nil)});
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      V v_t_24156;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24155 = heff_dup(heff_field(v_e_240, 1));
        v_t_24156 = v_s_24155;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24157 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24156});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24157, NTAG(TAG_Nil)});
    }
    case TAG_EIfThen: {
      V v_ru_24e1_241_24EIfThen = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      V v_t_24162;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24161 = heff_dup(heff_field(v_e_240, 1));
        v_t_24162 = v_s_24161;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24163 = heff_tag_at_n(v_ru_24e1_241_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24162});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24163, NTAG(TAG_Nil)});
    }
    case TAG_EBreak: {
      V v_t_24166;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24165 = heff_dup(heff_field(v_e_240, 1));
        v_t_24166 = v_s_24165;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24167 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24166});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24167, NTAG(TAG_Nil)});
    }
    case TAG_EContinue: {
      V v_t_24170;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24169 = heff_dup(heff_field(v_e_240, 1));
        v_t_24170 = v_s_24169;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24171 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24170});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24171, NTAG(TAG_Nil)});
    }
    case TAG_EReturn: {
      V v_ru_24e1_241_24EReturn = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_24175;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24174 = heff_dup(heff_field(v_e_240, 1));
        v_t_24175 = v_s_24174;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24176 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EReturn, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24175});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24176, NTAG(TAG_Nil)});
    }
    case TAG_ENest: {
      V v_ru_24e1_241_24ENest = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_24180;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24179 = heff_dup(heff_field(v_e_240, 1));
        v_t_24180 = v_s_24179;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24181 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ENest, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24180});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24181, NTAG(TAG_Nil)});
    }
    case TAG_ELazy: {
      V v_ru_24e1_241_24ELazy = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_24185;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24184 = heff_dup(heff_field(v_e_240, 1));
        v_t_24185 = v_s_24184;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24186 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ELazy, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24185});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24186, NTAG(TAG_Nil)});
    }
    case TAG_ETuple: {
      V v_ru_24e1_241_24ETuple = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_24190;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24189 = heff_dup(heff_field(v_e_240, 1));
        v_t_24190 = v_s_24189;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24191 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETuple, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24190});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24191, NTAG(TAG_Nil)});
    }
    case TAG_ETry: {
      V v_ru_24e1_241_24ETry = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      V v_t_24195;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24194 = heff_dup(heff_field(v_e_240, 1));
        v_t_24195 = v_s_24194;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24196 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETry, TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24195});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24196, NTAG(TAG_Nil)});
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      V v_t_24203;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24202 = heff_dup(heff_field(v_e_240, 1));
        v_t_24203 = v_s_24202;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      V v_t_24204 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_e_240}), v_t_24203});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24204, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2earmStmts_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2earmStmts(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_str2, 4, "next");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_str3, 4, "coll");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_str5, 4, "next");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_str6, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_entry, 8, 0};

V g_heff_2esyntax_2epresyntax_2eforT(V v_t_240, V v_cx_241, V v_sp_242, V v_p_243, V v_coll_244, V v_body_245, V v_rest_246, V v_end_247) {
top: ;
  V v_t_248 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
  HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_248}), NTAG(TAG_Nil), v_coll_244));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_x_2412 = v_field_2410;
    V v_y_2413 = v_field_2411;
    V v_sp_2416;
    switch (heff_tag_of(v_y_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_y_2413, 1));
      v_sp_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_y_2413);
    }
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_str0)}), heff_dup(v_sp_2416)});
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_str1)}), v_sp_2416});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    V v_t_2420 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2417, v_t_2419));
    V v_t_2423;
    switch (heff_tag_of(v_y_2413)) {
    case TAG_At: {
      V v_s_2422 = heff_dup(heff_field(v_y_2413, 1));
      v_t_2423 = v_s_2422;
      break;
    }
    default: heff_nomatch(v_y_2413);
    }
    V v_v_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_2413, v_t_2420}), v_t_2423});
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2eforT_2eit_241(heff_dup(v_sp_242)));
    V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_str2)}), heff_dup(v_sp_242)});
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
    V v_v_2428 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2425, v_t_2427));
    V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 2, 3);
    V v_body_2430;
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      v_body_2430 = (g_heff_2esyntax_2epresyntax_2eforT_2egiven_249(v_t_240, heff_dup(v_cx_241), heff_dup(v_sp_242), v_body_245, v_p_243, v_rest_246, v_end_247));
    } else {
      heff_drop(v_t_2429);
      v_body_2430 = (g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247(heff_dup(v_sp_242), heff_dup(v_cx_241), v_t_240, v_rest_246, v_end_247, v_p_243, v_body_245));
    }
    V v_t_2433;
    switch (heff_tag_of(v_body_2430)) {
    case TAG_At: {
      V v_s_2432 = heff_dup(heff_field(v_body_2430, 1));
      v_t_2433 = v_s_2432;
      break;
    }
    default: heff_nomatch(v_body_2430);
    }
    V v_t_2434 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_2433, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2435 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
    V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_str3), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_str4), v_t_2435));
    V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_2436}), heff_dup(v_sp_242)});
    V v_t_2438 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_str5), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_str6), v_t_2438));
    V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_2439}), heff_dup(v_sp_242)});
    V v_t_2443;
    switch (heff_tag_of(v_body_2430)) {
    case TAG_At: {
      V v_s_2442 = heff_dup(heff_field(v_body_2430, 1));
      v_t_2443 = v_s_2442;
      break;
    }
    default: heff_nomatch(v_body_2430);
    }
    V v_t_2444 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_242, 0)); V rr_ = heff_rec_reuse_nf(v_t_2443, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2440, v_body_2430}), v_t_2444});
    V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2428, v_t_2445}), heff_dup(v_t_2434)});
    V v_t_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_242, 0)), heff_dup(heff_rfield(v_t_2434, 1))});
    V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2437, v_t_2446}), v_t_2447});
    V v_t_2449 = ({ V rv_1 = heff_get_n(v_t_2434, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_242, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2424, v_t_2448}), v_t_2449});
    return ({ V a_0 = v_cx_241; V a_1 = v_x_2412; V a_2 = v_t_2450; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2eforT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2esyntax_2epresyntax_2edoT_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2edoT_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edoT_lam0, 3, 0};

static V g_heff_2esyntax_2epresyntax_2edoT_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2edoT_st;
static V g_heff_2esyntax_2epresyntax_2edoT_init(void) {
  return heff_rec_n(1, shape_stmts, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoT_lam0_clo)});
}
V g_heff_2esyntax_2epresyntax_2edoT_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2edoT_st)) return g_heff_2esyntax_2epresyntax_2edoT_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2edoT_val, &g_heff_2esyntax_2epresyntax_2edoT_st, g_heff_2esyntax_2epresyntax_2edoT_init);
}
V g_heff_2esyntax_2epresyntax_2edoT_lam0(V self, V *args) {
  V v_cx_240 = args[0];
  V v_ss_241 = args[1];
  V v_end_242 = args[2];
  return ({ V a_0 = heff_dup(g_heff_2esyntax_2epresyntax_2edoT_get()); V a_1 = v_cx_240; V a_2 = v_ss_241; V a_3 = v_end_242; V r_ = (g_heff_2esyntax_2epresyntax_2estmtsF(a_0, a_1, a_2, a_3)); heff_drop(v_ss_241); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str0, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str2, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str4, 4, "last");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str5, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str6, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str7, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V v_cx_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str0)}), v_sp_243});
    }
    case TAG_StmtLet: {
      heff_take_n(v_x31_242, 0ULL, 2);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str1)}), v_sp_243});
    }
    case TAG_StmtExpr: {
      V v_e_249 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_249));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop_rec(v_sp_243, 2);
        heff_drop_cell(v_ru_24x3_241_24At, 2);
        heff_drop_cell(v_ru_24x31_242_24StmtExpr, 1);
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2epresyntax_2econtrolT(heff_dup(g_heff_2esyntax_2epresyntax_2edoT_get()), v_cx_240, v_e_249, NTAG(TAG_Nil), NTAG(TAG_EndValue)));
      } else {
        heff_drop(v_t_2410);
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_cx_240, 4)))) {
          V v_t_2411 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2411}), NTAG(TAG_Nil), v_e_249));
          {
            V v_field_2413 = v_t_2412.f[0];
            V v_field_2414 = v_t_2412.f[1];
            V v_x_2415 = v_field_2413;
            V v_y_2416 = v_field_2414;
            V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 3);
            V v_t_2418 = heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2417}), heff_dup(v_sp_243)});
            V v_t_2419 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
            V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str3), v_t_2419));
            V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_242_24StmtExpr, TAG_EVar, 1, (V[]){v_t_2420}), heff_dup(v_sp_243)});
            V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
            V v_t_2423 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2418, v_t_2422));
            V v_rest_2424 = (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), heff_dup(v_sp_243), heff_dup(heff_rfield(v_cx_240, 4)), v_t_2423));
            V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
            V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2425}), heff_dup(heff_rfield(v_cx_240, 3))});
            V v_t_2427 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
            V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str5), v_t_2427));
            V v_t_2429 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_t_2428, heff_dup(v_sp_243)}), heff_dup(v_rest_2424)});
            V v_t_2432;
            switch (heff_tag_of(v_rest_2424)) {
            case TAG_At: {
              V v_s_2431 = heff_field(v_rest_2424, 1);
              heff_take_n(v_rest_2424, 2ULL, 2);
              v_t_2432 = v_s_2431;
              break;
            }
            default: heff_nomatch(v_rest_2424);
            }
            V v_t_2433 = ({ V rv_1 = heff_get_n(v_t_2432, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, v_t_2433}), NTAG(TAG_Nil)});
            V v_t_2435 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2416, v_t_2434})));
            return ({ V a_0 = v_cx_240; V a_1 = v_x_2415; V a_2 = v_t_2435; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
          }
        } else {
          heff_drop_rec(v_sp_243, 2);
          heff_drop_cell(v_ru_24x3_241_24At, 2);
          heff_drop_cell(v_ru_24x31_242_24StmtExpr, 1);
          V v_t_2436 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
          HeffT2 v_t_2437 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2436}), NTAG(TAG_Nil), v_e_249));
          {
            V v_field_2438 = v_t_2437.f[0];
            V v_field_2439 = v_t_2437.f[1];
            V v_x_2440 = v_field_2438;
            V v_y_2441 = v_field_2439;
            return ({ V a_0 = v_cx_240; V a_1 = v_x_2440; V a_2 = v_y_2441; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2440); r_; });
          }
        }
      }
    }
    case TAG_StmtLetMut: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str6)}), v_sp_243});
    }
    case TAG_StmtLetElse: {
      heff_take_n(v_x31_242, 0ULL, 3);
      heff_drop_rec(v_cx_240, 6);
      return heff_tag_at_n(v_ru_24x3_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_str7)}), v_sp_243});
    }
    default: return heff_nomatch(v_x31_242);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elistOfChk_str1, 4, "Cons");
Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elistOfChk_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elistOfChk(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str0), heff_dup(v_sp_241), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_xs_244, heff_dup(v_sp_241)));
    V v_t_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elistOfChk_str1), heff_dup(v_sp_241), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_246})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elistOfChk(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ExplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_ImplicitParam: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      V v_xsp_2419 = heff_field(v_x21_242, 1);
      V v_t_2420 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ImplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2420}));
      V v_t_2431;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_IsInferable: {
        V v_i_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_i_2422)) {
        case TAG_At: {
          V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
          v_t_2425 = v_s_2424;
          break;
        }
        default: heff_nomatch(v_i_2422);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2426 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_c_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_c_2426);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
        break;
      }
      case TAG_IsType: {
        V v_t_2430 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2431 = v_t_2430;
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2418, v_xsp_2419, v_t_2431}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626(V v_lit_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop(v_lit_240);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IBytes, 1, (V[]){v_s_245}), heff_dup(v_sp_246)});
        V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_247}), heff_dup(v_sp_246)});
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        V v_a_2410 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_246), v_t_249));
        V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_lit_240}), heff_dup(v_sp_246)});
        V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2411, v_a_2410}), heff_dup(v_sp_246)});
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2412}), v_sp_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_2414 = heff_field(v_x2_241, 0);
    V v_rest_2415 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2414)) {
    case TAG_At: {
      V v_seg_2416 = heff_field(v_x21_2414, 0);
      V v_sp_2417 = heff_field(v_x21_2414, 1);
      V v_ru_24x21_2414_24At = heff_take_reuse_n(v_x21_2414, 3ULL, 2);
      HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2416));
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2416);
          heff_drop_cell(v_ru_24x21_2414_24At, 2);
          V v_s_2421 = v_field_2420;
          V v_t_2427;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2421, v_sp_2417})});
            break;
          }
          case TAG_Just: {
            V v_x11_2422 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2422)) {
            case TAG_MkPair: {
              V v_s0_2423 = heff_field(v_x11_2422, 0);
              V v_sp0_2424 = heff_field(v_x11_2422, 1);
              V v_ru_24x11_2422_24MkPair = heff_take_reuse_n(v_x11_2422, 3ULL, 2);
              V v_t_2425 = ({ V rv_1 = heff_get_n(v_sp_2417, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2426 = heff_tag_at_n(v_ru_24x11_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2423, v_s_2421), v_t_2425});
              v_t_2427 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2426});
              break;
            }
            default: heff_nomatch(v_x11_2422);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = v_t_2427;
          V t_3 = v_acc_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2420);
          V v_t_2428 = (g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(heff_tag_at_n(v_ru_24x21_2414_24At, TAG_At, 2, (V[]){v_seg_2416, v_sp_2417})));
          V v_t_2439;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2439 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2429 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2429)) {
            case TAG_MkPair: {
              V v_s_2430 = heff_field(v_x21_2429, 0);
              V v_sp_2431 = heff_field(v_x21_2429, 1);
              V v_ru_24x21_2429_24MkPair = heff_take_reuse_n(v_x21_2429, 3ULL, 2);
              V v_t_2432 = heff_tag_at_n(v_ru_24x21_2429_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IBytes, 1, (V[]){v_s_2430}), heff_dup(v_sp_2431)});
              V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2432}), heff_dup(v_sp_2431)});
              V v_t_2434 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
              V v_a_2435 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2431), v_t_2434));
              V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){heff_dup(v_lit_240)}), heff_dup(v_sp_2431)});
              V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, v_a_2435}), heff_dup(v_sp_2431)});
              V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2437}), v_sp_2431});
              v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2429);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2439});
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_2414);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1654483724x1393507626(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1, 22, "`Array` takes one type");

HeffT2 g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr(V v_h_240, V v_args_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_243 = heff_dup(heff_field(v_h_240, 0));
    switch (heff_tag_of(v_h1_243)) {
    case TAG_EVar: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_247 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_246));
      V v_t_248 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_248}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_249}});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2411));
      V v_t_2413 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2412, v_t_2413}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2414}});
    }
    case TAG_ETag: {
      V v_t_2415 = heff_field(v_h1_243, 0);
      heff_take_n(v_h1_243, 1ULL, 1);
      switch (heff_tag_of(v_h_240)) {
      case TAG_At: {
        V v_tsp_2417 = heff_field(v_h_240, 1);
        V v_ru_24h_240_24At = heff_take_reuse_n(v_h_240, 2ULL, 2);
        V v_t_2418 = (g_list_2emap_24s1844509821x2028168277(v_args_241));
        V v_f_2419 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_2415, v_tsp_2417, v_t_2418}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
      }
      default: return ((HeffT2){{heff_nomatch(v_h_240)}});
      }
    }
    case TAG_EInt: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_2421 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2421));
      V v_t_2423 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2422, v_t_2423}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2424}});
    }
    case TAG_EFloat: {
      heff_take_na(v_h1_243, 0ULL, 1);
      V v_t_2426 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2427 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2426));
      V v_t_2428 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2427, v_t_2428}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2429}});
    }
    case TAG_EString: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_2431 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2432 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2431));
      V v_t_2433 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2433}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2434}});
    }
    case TAG_EBinary: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_2436 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2437 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2436));
      V v_t_2438 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2437, v_t_2438}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2439}});
    }
    case TAG_ERune: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_2441 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2442 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2441));
      V v_t_2443 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2442, v_t_2443}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2444}});
    }
    case TAG_EWord: {
      V v_h11_2445 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24EWord = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      switch (heff_tag_of(v_h11_2445)) {
      case TAG_TypeWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2446 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2447 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2446));
        V v_t_2448 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2447, v_t_2448}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2449}});
      }
      case TAG_IntWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2450 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2451 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2450));
        V v_t_2452 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2451, v_t_2452}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2453}});
      }
      case TAG_FloatWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2454 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2455 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2454));
        V v_t_2456 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2455, v_t_2456}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2457}});
      }
      case TAG_StringWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2458 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2459 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2458));
        V v_t_2460 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2459, v_t_2460}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2461}});
      }
      case TAG_RuneWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2462 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2463 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2462));
        V v_t_2464 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2463, v_t_2464}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2465}});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_240, 2);
        switch (heff_tag_of(v_args_241)) {
        case TAG_Nil: {
          V v_t_2466 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str0), NTAG(TAG_Nothing)});
          V v_t_2467 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2466, heff_dup(v_sp_242)})});
          return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_n(TAG_At, 2, (V[]){v_t_2467, v_sp_242})}});
        }
        case TAG_Cons: {
          V v_a_2468 = heff_field(v_args_241, 0);
          V v_args2_2469 = heff_field(v_args_241, 1);
          V v_ru_24args_241_24Cons = heff_take_reuse_n(v_args_241, 3ULL, 2);
          switch (heff_tag_of(v_args2_2469)) {
          case TAG_Nil: {
            HeffT2 v_t_2470 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_a_2468));
            V v_t_2482;
            {
              V v_field_2472 = v_t_2470.f[1];
              int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
              if ((v_tag_2471 == ((int64_t)0ULL))) {
                V v_c_2473 = v_field_2472;
                V v_t_2476;
                switch (heff_tag_of(v_c_2473)) {
                case TAG_At: {
                  V v_s_2475 = heff_dup(heff_field(v_c_2473, 1));
                  v_t_2476 = v_s_2475;
                  break;
                }
                default: heff_nomatch(v_c_2473);
                }
                v_t_2482 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TChk, 1, (V[]){v_c_2473}), v_t_2476});
              } else {
                if ((v_tag_2471 == ((int64_t)1ULL))) {
                  V v_i_2477 = v_field_2472;
                  V v_t_2480;
                  switch (heff_tag_of(v_i_2477)) {
                  case TAG_At: {
                    V v_s_2479 = heff_dup(heff_field(v_i_2477, 1));
                    v_t_2480 = v_s_2479;
                    break;
                  }
                  default: heff_nomatch(v_i_2477);
                  }
                  v_t_2482 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_i_2477}), v_t_2480});
                } else {
                  heff_drop_cell(v_ru_24h1_243_24EWord, 1);
                  heff_drop_cell(v_ru_24args_241_24Cons, 2);
                  V v_t_2481 = v_field_2472;
                  v_t_2482 = v_t_2481;
                }
              }
            }
            V v_f_2483 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2482}), v_sp_242});
            return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_f_2483}});
          }
          case TAG_Cons: {
            heff_take_n(v_args2_2469, 0ULL, 2);
            heff_drop(v_a_2468);
            V v_t_2486 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_24cpr_str1), NTAG(TAG_Nothing)});
            V v_t_2487 = heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2486, heff_dup(v_sp_242)})});
            return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){v_t_2487, v_sp_242})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_args2_2469)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_args_241)}});
        }
      }
      case TAG_AbandonWord: {
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2488 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2489 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2488));
        V v_t_2490 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2491 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2489, v_t_2490}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2491}});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2445, 0ULL, 1);
        heff_drop_cell(v_ru_24h1_243_24EWord, 1);
        V v_t_2493 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2494 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2493));
        V v_t_2495 = (g_list_2emap_24s529174x2075875906(v_args_241));
        V v_f_2496 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2494, v_t_2495}), v_sp_242});
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2496}});
      }
      default: return ((HeffT2){{heff_nomatch(v_h11_2445)}});
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_243_24EApp = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_2499 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24100 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2499));
      V v_t_24101 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24102 = heff_tag_at_n(v_ru_24h1_243_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24100, v_t_24101}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24102}});
    }
    case TAG_EProject: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24104 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24105 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24104));
      V v_t_24106 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24105, v_t_24106}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24107}});
    }
    case TAG_ENamed: {
      V v_ru_24h1_243_24ENamed = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24110 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24111 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24110));
      V v_t_24112 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24113 = heff_tag_at_n(v_ru_24h1_243_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24112}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24113}});
    }
    case TAG_EPi: {
      V v_ru_24h1_243_24EPi = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24116 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24117 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24116));
      V v_t_24118 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24119 = heff_tag_at_n(v_ru_24h1_243_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24117, v_t_24118}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24119}});
    }
    case TAG_ELam: {
      V v_ru_24h1_243_24ELam = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24122 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24123 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24122));
      V v_t_24124 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24125 = heff_tag_at_n(v_ru_24h1_243_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24123, v_t_24124}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24125}});
    }
    case TAG_EAnn: {
      V v_ru_24h1_243_24EAnn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24128 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24129 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24128));
      V v_t_24130 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24131 = heff_tag_at_n(v_ru_24h1_243_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24129, v_t_24130}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24131}});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_243, 0ULL, 4);
      V v_t_24136 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24137 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24136));
      V v_t_24138 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24139 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24137, v_t_24138}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24139}});
    }
    case TAG_ESig: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24141 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24142 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24141));
      V v_t_24143 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24142, v_t_24143}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24144}});
    }
    case TAG_ESum: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24146 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24147 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24146));
      V v_t_24148 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24147, v_t_24148}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24149}});
    }
    case TAG_EStruct: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24151 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24152 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24151));
      V v_t_24153 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24154 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24152, v_t_24153}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24154}});
    }
    case TAG_EUpdate: {
      V v_ru_24h1_243_24EUpdate = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24157 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24158 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24157));
      V v_t_24159 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24160 = heff_tag_at_n(v_ru_24h1_243_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24158, v_t_24159}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24160}});
    }
    case TAG_EMatch: {
      V v_ru_24h1_243_24EMatch = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24163 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24164 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24163));
      V v_t_24165 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24166 = heff_tag_at_n(v_ru_24h1_243_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24164, v_t_24165}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24166}});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_243_24ELetIn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24169 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24170 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24169));
      V v_t_24171 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24172 = heff_tag_at_n(v_ru_24h1_243_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24170, v_t_24171}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24172}});
    }
    case TAG_EDo: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24174 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24175 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24174));
      V v_t_24176 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24177 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24175, v_t_24176}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24177}});
    }
    case TAG_ELocal: {
      V v_ru_24h1_243_24ELocal = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24180 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24181 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24180));
      V v_t_24182 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24183 = heff_tag_at_n(v_ru_24h1_243_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24181, v_t_24182}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24183}});
    }
    case TAG_EInvalid: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24185 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24186 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24185));
      V v_t_24187 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24188 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24186, v_t_24187}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24188}});
    }
    case TAG_EAssign: {
      heff_take_n(v_h1_243, 0ULL, 3);
      V v_t_24192 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24193 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24192));
      V v_t_24194 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24195 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24193, v_t_24194}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24195}});
    }
    case TAG_EWhile: {
      V v_ru_24h1_243_24EWhile = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24198 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24199 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24198));
      V v_t_24200 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24201 = heff_tag_at_n(v_ru_24h1_243_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24199, v_t_24200}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24201}});
    }
    case TAG_EFor: {
      heff_take_n(v_h1_243, 0ULL, 3);
      V v_t_24205 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24206 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24205));
      V v_t_24207 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24208 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24206, v_t_24207}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24208}});
    }
    case TAG_EIfThen: {
      V v_ru_24h1_243_24EIfThen = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      V v_t_24211 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24212 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24211));
      V v_t_24213 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24214 = heff_tag_at_n(v_ru_24h1_243_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24212, v_t_24213}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24214}});
    }
    case TAG_EBreak: {
      V v_t_24215 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24216 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24215));
      V v_t_24217 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24218 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24216, v_t_24217}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24218}});
    }
    case TAG_EContinue: {
      V v_t_24219 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24220 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24219));
      V v_t_24221 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24222 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24220, v_t_24221}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24222}});
    }
    case TAG_EReturn: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24224 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24225 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24224));
      V v_t_24226 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24227 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24225, v_t_24226}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24227}});
    }
    case TAG_ENest: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24229 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24230 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24229));
      V v_t_24231 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24232 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24230, v_t_24231}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24232}});
    }
    case TAG_ELazy: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24234 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24235 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24234));
      V v_t_24236 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24237 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24235, v_t_24236}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24237}});
    }
    case TAG_ETuple: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24239 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24240 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24239));
      V v_t_24241 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24240, v_t_24241}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24242}});
    }
    case TAG_ETry: {
      heff_take_n(v_h1_243, 0ULL, 1);
      V v_t_24244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24245 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24244));
      V v_t_24246 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24245, v_t_24246}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24247}});
    }
    case TAG_EWith: {
      heff_take_n(v_h1_243, 0ULL, 4);
      V v_t_24252 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24253 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_24252));
      V v_t_24254 = (g_list_2emap_24s529174x2075875906(v_args_241));
      V v_f_24255 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24253, v_t_24254}), v_sp_242});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_24255}});
    }
    default: return ((HeffT2){{heff_nomatch(v_h1_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_h_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_IVar: {
    return v_n_240;
  }
  case TAG_IInt: {
    return v_n_240;
  }
  case TAG_IFloat: {
    return v_n_240;
  }
  case TAG_IString: {
    return v_n_240;
  }
  case TAG_IBytes: {
    return v_n_240;
  }
  case TAG_IPrim: {
    return v_n_240;
  }
  case TAG_IRune: {
    return v_n_240;
  }
  case TAG_IApp: {
    V v_h_248 = heff_field(v_n_240, 0);
    V v_args_249 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IApp = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2413;
    switch (heff_tag_of(v_h_248)) {
    case TAG_At: {
      V v_n_2410 = heff_field(v_h_248, 0);
      V v_sp_2411 = heff_field(v_h_248, 1);
      V v_ru_24h_248_24At = heff_take_reuse_n(v_h_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2410));
      v_t_2413 = heff_tag_at_n(v_ru_24h_248_24At, TAG_At, 2, (V[]){v_t_2412, v_sp_2411});
      break;
    }
    default: heff_nomatch(v_h_248);
    }
    V v_t_2414 = (g_list_2emap_24s126994153x1029399760(v_args_249));
    return heff_tag_at_n(v_ru_24n_240_24IApp, TAG_IApp, 2, (V[]){v_t_2413, v_t_2414});
  }
  case TAG_IAnn: {
    V v_c_2415 = heff_field(v_n_240, 0);
    V v_t_2416 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IAnn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_c_2415)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_c_2415, 0);
      V v_sp_2418 = heff_field(v_c_2415, 1);
      V v_ru_24c_2415_24At = heff_take_reuse_n(v_c_2415, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24c_2415_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_c_2415);
    }
    V v_t_2423;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_At: {
      V v_n_2421 = heff_field(v_t_2416, 0);
      V v_sp_2422 = heff_field(v_t_2416, 1);
      V v_ru_24t_2416_24At = heff_take_reuse_n(v_t_2416, 3ULL, 2);
      v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2416_24At, v_sp_2422, v_n_2421));
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnn, TAG_IAnn, 2, (V[]){v_t_2420, v_t_2423});
  }
  case TAG_ISpec: {
    V v_a_2424 = heff_field(v_n_240, 0);
    V v_x_2425 = heff_field(v_n_240, 1);
    V v_sp_2426 = heff_field(v_n_240, 2);
    V v_v_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ISpec = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2431;
    switch (heff_tag_of(v_a_2424)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_a_2424, 0);
      V v_sp_2429 = heff_field(v_a_2424, 1);
      V v_ru_24a_2424_24At = heff_take_reuse_n(v_a_2424, 3ULL, 2);
      V v_t_2430 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2428));
      v_t_2431 = heff_tag_at_n(v_ru_24a_2424_24At, TAG_At, 2, (V[]){v_t_2430, v_sp_2429});
      break;
    }
    default: heff_nomatch(v_a_2424);
    }
    V v_t_2435;
    switch (heff_tag_of(v_v_2427)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_v_2427, 0);
      V v_sp_2433 = heff_field(v_v_2427, 1);
      V v_ru_24v_2427_24At = heff_take_reuse_n(v_v_2427, 3ULL, 2);
      V v_t_2434 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2432));
      v_t_2435 = heff_tag_at_n(v_ru_24v_2427_24At, TAG_At, 2, (V[]){v_t_2434, v_sp_2433});
      break;
    }
    default: heff_nomatch(v_v_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24ISpec, TAG_ISpec, 4, (V[]){v_t_2431, v_x_2425, v_sp_2426, v_t_2435});
  }
  case TAG_IUpdate: {
    V v_a_2436 = heff_field(v_n_240, 0);
    V v_fs_2437 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IUpdate = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2441;
    switch (heff_tag_of(v_a_2436)) {
    case TAG_At: {
      V v_n_2438 = heff_field(v_a_2436, 0);
      V v_sp_2439 = heff_field(v_a_2436, 1);
      V v_ru_24a_2436_24At = heff_take_reuse_n(v_a_2436, 3ULL, 2);
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2438));
      v_t_2441 = heff_tag_at_n(v_ru_24a_2436_24At, TAG_At, 2, (V[]){v_t_2440, v_sp_2439});
      break;
    }
    default: heff_nomatch(v_a_2436);
    }
    V v_t_2442 = (g_list_2emap_24s366989016x166432442(v_fs_2437));
    return heff_tag_at_n(v_ru_24n_240_24IUpdate, TAG_IUpdate, 2, (V[]){v_t_2441, v_t_2442});
  }
  case TAG_IAnnLam: {
    V v_x_2443 = heff_field(v_n_240, 0);
    V v_sp_2444 = heff_field(v_n_240, 1);
    V v_t_2445 = heff_field(v_n_240, 2);
    V v_b_2446 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24IAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2449;
    switch (heff_tag_of(v_t_2445)) {
    case TAG_At: {
      V v_n_2447 = heff_field(v_t_2445, 0);
      V v_sp_2448 = heff_field(v_t_2445, 1);
      V v_ru_24t_2445_24At = heff_take_reuse_n(v_t_2445, 3ULL, 2);
      v_t_2449 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24t_2445_24At, v_sp_2448, v_n_2447));
      break;
    }
    default: heff_nomatch(v_t_2445);
    }
    V v_t_2453;
    switch (heff_tag_of(v_b_2446)) {
    case TAG_At: {
      V v_n_2450 = heff_field(v_b_2446, 0);
      V v_sp_2451 = heff_field(v_b_2446, 1);
      V v_ru_24b_2446_24At = heff_take_reuse_n(v_b_2446, 3ULL, 2);
      V v_t_2452 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2450));
      v_t_2453 = heff_tag_at_n(v_ru_24b_2446_24At, TAG_At, 2, (V[]){v_t_2452, v_sp_2451});
      break;
    }
    default: heff_nomatch(v_b_2446);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_x_2443, v_sp_2444, v_t_2449, v_t_2453});
  }
  case TAG_IInvalid: {
    return v_n_240;
  }
  case TAG_INominal: {
    return v_n_240;
  }
  case TAG_ILitEq: {
    V v_x_2458 = heff_field(v_n_240, 0);
    V v_sp_2459 = heff_field(v_n_240, 1);
    V v_eq_2460 = heff_field(v_n_240, 2);
    V v_lit_2461 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ILitEq = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2465;
    switch (heff_tag_of(v_lit_2461)) {
    case TAG_At: {
      V v_n_2462 = heff_field(v_lit_2461, 0);
      V v_sp_2463 = heff_field(v_lit_2461, 1);
      V v_ru_24lit_2461_24At = heff_take_reuse_n(v_lit_2461, 3ULL, 2);
      V v_t_2464 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2462));
      v_t_2465 = heff_tag_at_n(v_ru_24lit_2461_24At, TAG_At, 2, (V[]){v_t_2464, v_sp_2463});
      break;
    }
    default: heff_nomatch(v_lit_2461);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILitEq, TAG_ILitEq, 4, (V[]){v_x_2458, v_sp_2459, v_eq_2460, v_t_2465});
  }
  case TAG_ILazy: {
    V v_c_2466 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24ILazy = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2470;
    switch (heff_tag_of(v_c_2466)) {
    case TAG_At: {
      V v_n_2467 = heff_field(v_c_2466, 0);
      V v_sp_2468 = heff_field(v_c_2466, 1);
      V v_ru_24c_2466_24At = heff_take_reuse_n(v_c_2466, 3ULL, 2);
      V v_t_2469 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2467));
      v_t_2470 = heff_tag_at_n(v_ru_24c_2466_24At, TAG_At, 2, (V[]){v_t_2469, v_sp_2468});
      break;
    }
    default: heff_nomatch(v_c_2466);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILazy, TAG_ILazy, 1, (V[]){v_t_2470});
  }
  case TAG_ITuple: {
    V v_cs_2471 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24ITuple = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2472 = (g_list_2emap_24s79542405x478516404(v_cs_2471));
    return heff_tag_at_n(v_ru_24n_240_24ITuple, TAG_ITuple, 1, (V[]){v_t_2472});
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24tok2_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24tok2_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24tok2_str2, 4, "next");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24tok2_str3, 4, "coll");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24tok2_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24tok2_str5, 4, "next");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24tok2_str6, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_24tok2_entry, 9, 0};

V g_heff_2esyntax_2epresyntax_2eforT_24tok2(V v_tok_240, V v_t_241, V v_cx_242, V v_sp_243, V v_p_244, V v_coll_245, V v_body_246, V v_rest_247, V v_end_248) {
top: ;
  V v_t_249 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_242, 1)), NTAG(TAG_False)});
  HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_242), v_t_249}), NTAG(TAG_Nil), v_coll_245));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    V v_x_2413 = v_field_2411;
    V v_y_2414 = v_field_2412;
    V v_sp_2417;
    switch (heff_tag_of(v_y_2414)) {
    case TAG_At: {
      V v_s_2416 = heff_dup(heff_field(v_y_2414, 1));
      v_sp_2417 = v_s_2416;
      break;
    }
    default: heff_nomatch(v_y_2414);
    }
    V v_t_2418 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24tok2_str0)}), heff_dup(v_sp_2417)});
    V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24tok2_str1)}), v_sp_2417});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2418, v_t_2420));
    V v_t_2424;
    switch (heff_tag_of(v_y_2414)) {
    case TAG_At: {
      V v_s_2423 = heff_dup(heff_field(v_y_2414, 1));
      v_t_2424 = v_s_2423;
      break;
    }
    default: heff_nomatch(v_y_2414);
    }
    V v_v_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_2414, v_t_2421}), v_t_2424});
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2eforT_2eit_241(heff_dup(v_sp_243)));
    V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24tok2_str2)}), heff_dup(v_sp_243)});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_v_2429 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, v_t_2428));
    V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_cx_242, 0)), 2, 3);
    V v_body_2431;
    if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
      heff_drop(v_t_2430);
      v_body_2431 = (g_heff_2esyntax_2epresyntax_2eforT_2egiven_249(v_t_241, heff_dup(v_cx_242), heff_dup(v_sp_243), v_body_246, v_p_244, v_rest_247, v_end_248));
    } else {
      heff_drop(v_t_2430);
      v_body_2431 = (g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247(heff_dup(v_sp_243), heff_dup(v_cx_242), v_t_241, v_rest_247, v_end_248, v_p_244, v_body_246));
    }
    V v_t_2434;
    switch (heff_tag_of(v_body_2431)) {
    case TAG_At: {
      V v_s_2433 = heff_dup(heff_field(v_body_2431, 1));
      v_t_2434 = v_s_2433;
      break;
    }
    default: heff_nomatch(v_body_2431);
    }
    V v_t_2435 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_2434, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2436 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
    V v_t_2437 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24tok2_str3), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24tok2_str4), v_t_2436));
    V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_2437}), heff_dup(v_sp_243)});
    V v_t_2439 = heff_intShow(heff_dup(heff_rfield(v_sp_243, 0)));
    V v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24tok2_str5), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24tok2_str6), v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_2440}), heff_dup(v_sp_243)});
    V v_t_2444;
    switch (heff_tag_of(v_body_2431)) {
    case TAG_At: {
      V v_s_2443 = heff_dup(heff_field(v_body_2431, 1));
      v_t_2444 = v_s_2443;
      break;
    }
    default: heff_nomatch(v_body_2431);
    }
    V v_t_2445 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_243, 0)); V rr_ = heff_rec_reuse_nf(v_t_2444, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2441, v_body_2431}), v_t_2445});
    V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2429, v_t_2446}), heff_dup(v_t_2435)});
    V v_t_2448 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(heff_rfield(v_t_2435, 1))});
    V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2438, v_t_2447}), v_t_2448});
    V v_t_2450 = ({ V rv_1 = heff_get_n(v_t_2435, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2425, v_t_2449}), v_t_2450});
    return ({ V a_0 = v_cx_242; V a_1 = v_x_2413; V a_2 = v_t_2451; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2eforT_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryT_24tok2_str0, 89, "nothing after this `try` runs: neither its statements nor its `catch` arm reach their end");
Clo g_heff_2esyntax_2epresyntax_2etryT_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryT_24tok2_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2etryT_24tok2(V v_tok_240, V v_t_241, V v_cx_242, V v_sp_243, V v_tr_244, V v_rest_245, V v_end_246) {
top: ;
  V v_scope_247 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2etryScope_clo), 4, (V[]){heff_dup(v_t_241), heff_dup(v_cx_242), heff_dup(v_sp_243), heff_dup(v_tr_244)}));
  V v_t_248 = heff_tag_at_n(v_tok_240, TAG_At, 2, (V[]){heff_tag_n(TAG_ETry, 1, (V[]){v_tr_244}), heff_dup(v_sp_243)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_248}), heff_dup(v_sp_243)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2410));
  V v_falls_2428;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nil: {
    v_falls_2428 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 2);
    switch (heff_tag_of(v_x_2412)) {
    case TAG_At: {
      V v_it11_2414 = heff_field(v_x_2412, 0);
      heff_take_n(v_x_2412, 1ULL, 2);
      switch (heff_tag_of(v_it11_2414)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2421 = heff_field(v_it11_2414, 0);
        heff_take_n(v_it11_2414, 1ULL, 1);
        v_falls_2428 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2421));
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        v_falls_2428 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it11_2414);
      }
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  switch (heff_tag_of(v_rest_245)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_cx_242);
    heff_drop(v_sp_243);
    heff_drop(v_falls_2428);
    return heff_tail(v_scope_247, 1, (V[]){v_end_246});
  }
  case TAG_Cons: {
    V v_s_2429 = heff_field(v_rest_245, 0);
    V v_rest_2430 = heff_field(v_rest_245, 1);
    V v_ru_24rest_245_24Cons = heff_take_reuse_n(v_rest_245, 3ULL, 2);
    if ((heff_dup(v_falls_2428) == NTAG(TAG_True))) {
      heff_drop(v_falls_2428);
      return (g_heff_2esyntax_2epresyntax_2escopeJoin(v_t_241, v_cx_242, v_sp_243, v_scope_247, heff_tag_at_n(v_ru_24rest_245_24Cons, TAG_Cons, 2, (V[]){v_s_2429, v_rest_2430}), v_end_246));
    } else {
      heff_drop(v_t_241);
      heff_drop(v_cx_242);
      heff_drop(v_sp_243);
      heff_drop(v_end_246);
      heff_drop(v_scope_247);
      heff_drop(v_falls_2428);
      heff_drop(v_rest_2430);
      heff_drop_cell(v_ru_24rest_245_24Cons, 2);
      V v_t_2433;
      switch (heff_tag_of(v_s_2429)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_s_2429, 1);
        heff_take_n(v_s_2429, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_s_2429);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryT_24tok2_str0)}), v_t_2433});
    }
  }
  default: return heff_nomatch(v_rest_245);
  }
}
V g_heff_2esyntax_2epresyntax_2etryT_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etryT_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}