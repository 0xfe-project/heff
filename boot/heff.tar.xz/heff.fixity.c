// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Looser 37443
#define TAG_Same 22203
#define TAG_Tighter 5275
#define TAG_Undeclared 16066
#define TAG_Unrelated 586
#define LBL_above 293969847
#define LBL_assoc 294479919
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_looser 850054335
#define LBL_ops 319788
#define LBL_tighter 1059982480
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2efixity_2eappendF(V, V);
V g_heff_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2efixity_2eappendF_clo;
V g_heff_2efixity_2eemptyFixities_get(void);
V g_heff_2efixity_2efindG(V, V);
V g_heff_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2efixity_2efindG_clo;
V g_heff_2efixity_2enubByE(V);
V g_heff_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByE_clo;
V g_heff_2efixity_2enubByG(V);
V g_heff_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2efixity_2enubByG_clo;
V g_heff_2efixity_2erelate(V, V, V);
V g_heff_2efixity_2erelate_entry(V self, V *a);
extern Clo g_heff_2efixity_2erelate_clo;
V g_heff_2efixity_2ereserved_get(void);
V g_heff_2efixity_2etighterGo(V, V, V, V);
V g_heff_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2efixity_2etighterGo_clo;
V g_prelude_2eany(V, V);
V g_prelude_2eany_entry(V self, V *a);
extern Clo g_prelude_2eany_clo;
V g_prelude_2efilter(V, V);
V g_prelude_2efilter_entry(V self, V *a);
extern Clo g_prelude_2efilter_clo;
V g_prelude_2emap_24s1083963057x1681851055(V);
V g_prelude_2emap_24s1083963057x1681851055_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1083963057x1681851055_clo;

static V g_heff_2efixity_2eemptyFixities_val;
static int g_heff_2efixity_2eemptyFixities_st;
static V g_heff_2efixity_2eemptyFixities_init(void) {
  return heff_rec(2, shape_groups__above, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2efixity_2eemptyFixities_get(void) {
  if (g_heff_2efixity_2eemptyFixities_st == 2) return g_heff_2efixity_2eemptyFixities_val;
  if (g_heff_2efixity_2eemptyFixities_st == 1) heff_fail("defined by itself");
  g_heff_2efixity_2eemptyFixities_st = 1;
  g_heff_2efixity_2eemptyFixities_val = heff_tr(g_heff_2efixity_2eemptyFixities_init());
  g_heff_2efixity_2eemptyFixities_st = 2;
  return g_heff_2efixity_2eemptyFixities_val;
}
V g_heff_2efixity_2enubByG_lam0(V self, V *args);
Clo g_heff_2efixity_2enubByG_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efixity_2enubByG_entry, 1, 0};

V g_heff_2efixity_2enubByG(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_g_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_prelude_2efilter(heff_clo(g_heff_2efixity_2enubByG_lam0, 1, 1, (V[]){heff_dup(v_g_241)}), v_rest_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_g_241, (g_heff_2efixity_2enubByG(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2efixity_2enubByG_entry(V self, V *a) {
  (void)self;
  return g_heff_2efixity_2enubByG(a[0]);
}
V g_heff_2efixity_2enubByG_lam0(V self, V *args) {
  V v_h_243 = args[0];
  V v_g_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(heff_get(v_g_241, LBL_id), heff_get(v_h_243, LBL_id));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2efixity_2enubByE_lam0(V self, V *args);
Clo g_heff_2efixity_2enubByE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efixity_2enubByE_entry, 1, 0};

V g_heff_2efixity_2enubByE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = (g_prelude_2efilter(heff_clo(g_heff_2efixity_2enubByE_lam0, 1, 1, (V[]){heff_dup(v_p_241)}), v_rest_242));
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_241, (g_heff_2efixity_2enubByE(v_t_246))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2efixity_2enubByE_entry(V self, V *a) {
  (void)self;
  return g_heff_2efixity_2enubByE(a[0]);
}
V g_heff_2efixity_2enubByE_lam0(V self, V *args) {
  V v_q_243 = args[0];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_strEq(heff_get(heff_dup(v_p_241), LBL_tighter), heff_get(heff_dup(v_q_243), LBL_tighter));
  V v_x1_245;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_x1_245 = heff_strEq(heff_get(v_p_241, LBL_looser), heff_get(v_q_243, LBL_looser));
    break;
  }
  case TAG_False: {
    heff_drop(v_q_243);
    heff_drop(v_p_241);
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
Clo g_heff_2efixity_2eappendF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efixity_2eappendF_entry, 2, 0};

V g_heff_2efixity_2eappendF(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2efixity_2eappendF(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2efixity_2eappendF_entry(V self, V *a) {
  (void)self;
  return g_heff_2efixity_2eappendF(a[0], a[1]);
}
Clo g_heff_2efixity_2efindG_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efixity_2efindG_entry, 2, 0};

V g_heff_2efixity_2efindG(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_g_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_g_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_g_242)});
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_rest_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2efixity_2efindG_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2efixity_2efindG(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2efixity_2etighterGo_lam0(V self, V *args);
V g_heff_2efixity_2etighterGo_lam1(V self, V *args);
Clo g_heff_2efixity_2etighterGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efixity_2etighterGo_entry, 4, 0};

V g_heff_2efixity_2etighterGo(V v_f_240, V v_to_241, V v_x3_242, V v_seen_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_to_241);
    heff_drop(v_seen_243);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_head_244 = heff_field(v_x3_242, 0);
    V v_tail_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_head_244)}));
    V v_t_247 = (g_prelude_2eany(v_t_246, v_seen_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_head_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_to_241;
      V t_2 = v_tail_245;
      V t_3 = v_seen_243;
      v_f_240 = t_0;
      v_to_241 = t_1;
      v_x3_242 = t_2;
      v_seen_243 = t_3;
      goto top;
    }
    case TAG_False: {
      V v_t_249 = (g_prelude_2efilter(heff_clo(g_heff_2efixity_2etighterGo_lam0, 1, 1, (V[]){heff_dup(v_head_244)}), heff_get(heff_dup(v_f_240), LBL_above)));
      V v_xs_2410 = (g_prelude_2emap_24s1083963057x1681851055(v_t_249));
      V v_t_2411 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_to_241)}));
      V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = v_xs_2410; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_f_240);
        heff_drop(v_to_241);
        heff_drop(v_seen_243);
        heff_drop(v_head_244);
        heff_drop(v_tail_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_2414 = (g_prelude_2efilter(heff_clo(g_heff_2efixity_2etighterGo_lam1, 1, 1, (V[]){heff_dup(v_head_244)}), heff_get(heff_dup(v_f_240), LBL_above)));
        V v_t_2415 = (g_prelude_2emap_24s1083963057x1681851055(v_t_2414));
        V v_t_2416 = (g_heff_2efixity_2eappendF(v_tail_245, v_t_2415));
        V t_0 = v_f_240;
        V t_1 = v_to_241;
        V t_2 = v_t_2416;
        V t_3 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_head_244, v_seen_243});
        v_f_240 = t_0;
        v_to_241 = t_1;
        v_x3_242 = t_2;
        v_seen_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2efixity_2etighterGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2efixity_2etighterGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2efixity_2etighterGo_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_head_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_248, LBL_tighter), v_head_244);
}
V g_heff_2efixity_2etighterGo_lam1(V self, V *args) {
  V v_p_2413 = args[0];
  V v_head_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get(v_p_2413, LBL_tighter), v_head_244);
}
V g_heff_2efixity_2erelate_lam0(V self, V *args);
V g_heff_2efixity_2erelate_lam1(V self, V *args);
Clo g_heff_2efixity_2erelate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efixity_2erelate_entry, 3, 0};

V g_heff_2efixity_2erelate(V v_f_240, V v_op_241, V v_op_27_242) {
top: ;
  V v_t_245 = ({ V a_0 = heff_clo(g_heff_2efixity_2erelate_lam0, 1, 1, (V[]){heff_dup(v_op_241)}); V b_1 = heff_get(heff_dup(v_f_240), LBL_groups); V r_ = (g_heff_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_f_240);
    heff_drop(v_op_27_242);
    return heff_tag(TAG_Undeclared, 1, (V[]){v_op_241});
  }
  case TAG_Just: {
    V v_g_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop(v_op_241);
    V v_t_249 = ({ V a_0 = heff_clo(g_heff_2efixity_2erelate_lam1, 1, 1, (V[]){heff_dup(v_op_27_242)}); V b_1 = heff_get(heff_dup(v_f_240), LBL_groups); V r_ = (g_heff_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      heff_drop(v_f_240);
      heff_drop(v_g_246);
      return heff_tag_at(v_ru_24t_245_24Just, TAG_Undeclared, 1, (V[]){v_op_27_242});
    }
    case TAG_Just: {
      V v_g_27_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      heff_drop(v_op_27_242);
      V v_t_2411 = heff_strEq(heff_get(heff_dup(v_g_246), LBL_id), heff_get(heff_dup(v_g_27_2410), LBL_id));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop(v_f_240);
        heff_drop(v_g_27_2410);
        return heff_tag_at(v_ru_24t_245_24Just, TAG_Same, 1, (V[]){heff_get(v_g_246, LBL_assoc)});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_g_246), LBL_id), NTAG(TAG_Nil)});
        V v_t_2413 = (g_heff_2efixity_2etighterGo(heff_dup(v_f_240), heff_get(heff_dup(v_g_27_2410), LBL_id), v_t_2412, NTAG(TAG_Nil)));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_f_240);
          heff_drop(v_g_246);
          heff_drop(v_g_27_2410);
          return NTAG(TAG_Tighter);
        }
        case TAG_False: {
          V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){heff_get(v_g_27_2410, LBL_id), NTAG(TAG_Nil)});
          V v_t_2415 = (g_heff_2efixity_2etighterGo(v_f_240, heff_get(v_g_246, LBL_id), v_t_2414, NTAG(TAG_Nil)));
          switch (heff_tag_of(v_t_2415)) {
          case TAG_True: {
            return NTAG(TAG_Looser);
          }
          case TAG_False: {
            return NTAG(TAG_Unrelated);
          }
          default: return heff_nomatch(v_t_2415);
          }
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2efixity_2erelate_entry(V self, V *a) {
  (void)self;
  return g_heff_2efixity_2erelate(a[0], a[1], a[2]);
}
V g_heff_2efixity_2erelate_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_op_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_op_241}));
  return ({ V a_0 = v_t_244; V b_1 = heff_get(v_g_243, LBL_ops); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2efixity_2erelate_lam1(V self, V *args) {
  V v_g_247 = args[0];
  V v_op_27_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){v_op_27_242}));
  return ({ V a_0 = v_t_248; V b_1 = heff_get(v_g_247, LBL_ops); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efixity_2ereserved_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efixity_2ereserved_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efixity_2ereserved_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {61, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efixity_2ereserved_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efixity_2ereserved_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efixity_2ereserved_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efixity_2ereserved_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efixity_2ereserved_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {126}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efixity_2ereserved_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efixity_2ereserved_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {45, 62}};

static V g_heff_2efixity_2ereserved_val;
static int g_heff_2efixity_2ereserved_st;
static V g_heff_2efixity_2ereserved_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str8), v_t_243})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2efixity_2ereserved_str9), v_t_244});
}
V g_heff_2efixity_2ereserved_get(void) {
  if (g_heff_2efixity_2ereserved_st == 2) return g_heff_2efixity_2ereserved_val;
  if (g_heff_2efixity_2ereserved_st == 1) heff_fail("defined by itself");
  g_heff_2efixity_2ereserved_st = 1;
  g_heff_2efixity_2ereserved_val = heff_tr(g_heff_2efixity_2ereserved_init());
  g_heff_2efixity_2ereserved_st = 2;
  return g_heff_2efixity_2ereserved_val;
}