// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_bs 9912
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_fixed 298804110
#define LBL_fresh 299054408
#define LBL_go 10063
#define LBL_goes 9673821
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_p 330
#define LBL_params 951713969
#define LBL_producers 572620898
#define LBL_rest 9992347
#define LBL_supply 1056026650
#define LBL_underLam 296337946
#define LBL_x 338
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_params__at__arms__goes__fixed[] = {LBL_params, LBL_at, LBL_arms, LBL_goes, LBL_fixed};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
V g_heff_2ecompile_2efuse_2eatEnds(V, V);
V g_heff_2ecompile_2efuse_2eatEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eatEnds_clo;
V g_heff_2ecompile_2efuse_2ebindsOf(V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_clo;
V g_heff_2ecompile_2efuse_2ebindsOf_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_24dps_clo;
V g_heff_2ecompile_2efuse_2econsumerCall(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2econsumerCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerCall_clo;
V g_heff_2ecompile_2efuse_2econsumerOf(V, V);
V g_heff_2ecompile_2efuse_2econsumerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerOf_clo;
V g_heff_2ecompile_2efuse_2econsumerWith(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2econsumerWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerWith_clo;
V g_heff_2ecompile_2efuse_2eelemF(V, V);
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eelemF_clo;
V g_heff_2ecompile_2efuse_2eendAt(V, V);
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eendAt_clo;
V g_heff_2ecompile_2efuse_2efixedGo(V, V, V);
V g_heff_2ecompile_2efuse_2efixedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efixedGo_clo;
V g_heff_2ecompile_2efuse_2efuseKnown(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseKnown_clo;
V g_heff_2ecompile_2efuse_2egoesOf(V);
V g_heff_2ecompile_2efuse_2egoesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_clo;
V g_heff_2ecompile_2efuse_2einsertAt(V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_clo;
V g_heff_2ecompile_2efuse_2einsertAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo;
V g_heff_2ecompile_2efuse_2eonceIn(V, V);
V g_heff_2ecompile_2efuse_2eonceIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eonceIn_clo;
V g_heff_2ecompile_2efuse_2eplugArgs(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugArgs_clo;
V g_heff_2ecompile_2efuse_2eplugGo(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugGo_clo;
V g_heff_2ecompile_2efuse_2eproducerOf(V, V);
V g_heff_2ecompile_2efuse_2eproducerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eproducerOf_clo;
V g_heff_2ecompile_2efuse_2eremoveAt(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_clo;
V g_heff_2ecompile_2efuse_2esameGo(V, V);
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esameGo_clo;
V g_heff_2ecompile_2efuse_2eselfArgs(V, V, V);
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfArgs_clo;
V g_heff_2ecompile_2efuse_2eselfOut(V, V);
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_clo;
V g_heff_2ecompile_2efuse_2eselfOut_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2eselfOut_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_24dps_clo;
V g_heff_2ecompile_2efuse_2etraverseF(V, V);
V g_heff_2ecompile_2efuse_2etraverseF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etraverseF_clo;
V g_heff_2ecompile_2efuse_2evarAt(V, V, V);
V g_heff_2ecompile_2efuse_2evarAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2evarAt_clo;
V g_heff_2ecompile_2efuse_2ewithMade(V, V, V, V);
V g_heff_2ecompile_2efuse_2ewithMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ewithMade_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2eall_24s1373454977x2143028054(V);
V g_list_2eall_24s1373454977x2143028054_entry(V self, V *a);
extern Clo g_list_2eall_24s1373454977x2143028054_clo;
V g_list_2eany_24s1375915522x445000623(V);
V g_list_2eany_24s1375915522x445000623_entry(V self, V *a);
extern Clo g_list_2eany_24s1375915522x445000623_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1229912102x1467950109(V, V);
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2efuse_2eelemF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eelemF_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eelemF(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2eelemF(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2einsertAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einsertAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2einsertAt(V v_i_240, V v_y_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244})});
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2efuse_2einsertAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_y_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einsertAt(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2efuse_2eonceIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eonceIn_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eonceIn(V v_x_240, V v_e_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_241), NTAG(TAG_Nil)});
  V v_t_243 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_241), NTAG(TAG_Nil)});
  V v_t_245 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_240), v_t_244));
  V v_t_246 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_243, v_t_245}), 0, 2);
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_t_246), MK_INT(1LL)) && ({ V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_241), NTAG(TAG_Nil)}); int c_ = ({ V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), heff_dup(v_t_248))); int c_ = ({ V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_241), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2411 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_240), heff_dup(v_t_2410))); int c_ = ({ V v_x1_2412 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_249), heff_dup(v_t_2411)}), 1, 2); int c_ = !(heff_dup(v_x1_2412) == NTAG(TAG_True)); heff_drop(v_x1_2412); c_; }); heff_drop(v_t_2411); c_; }); heff_drop(v_t_2410); c_; }); heff_drop(v_t_249); c_; }); heff_drop(v_t_248); c_; })));
  heff_drop(v_x_240);
  heff_drop(v_e_241);
  heff_drop(v_t_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2efuse_2eonceIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eonceIn(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2esameGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esameGo_entry, 2, 0};

V g_heff_2ecompile_2efuse_2esameGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_x1_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x1_240)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_x1_240, 0);
      V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
      switch (heff_tag_of(v_x21_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_244);
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_245 = heff_field(v_x21_242, 0);
        if (heff_intEq_c(heff_dup(v_a_244), heff_dup(v_b_245))) {
          V t_0 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_a_244});
          V t_1 = v_rest_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_a_244);
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_x21_242);
      }
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2esameGo(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_str0, 5, "$self");
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_str1, 5, "$self");
V g_heff_2ecompile_2efuse_2eselfOut_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfOut_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfOut_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eselfOut(V v_me_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_244, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2efuse_2eselfOut_24dps(v_me_240, v_b_245, heff_dup(v_cell_246), MK_INT(1LL)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  case TAG_EApp: {
    V v_e1_248 = heff_field(v_e_241, 0);
    V v_as_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_248)) {
    case TAG_EVar: {
      V v_t_2411 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2413 = (g_list_2emap(v_t_2412, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2411, v_t_2413});
    }
    case TAG_EGlobal: {
      V v_g_2414 = heff_field(v_e1_248, 0);
      heff_take_n(v_e1_248, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_g_2414), heff_dup(heff_rfield(v_me_240, 0)))) {
        V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_249));
        if (heff_intEq_c(v_t_2416, heff_dup(heff_rfield(v_me_240, 1)))) {
          V v_t_2418 = (g_heff_2ecompile_2efuse_2evarAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(heff_rfield(v_me_240, 3)), v_as_249));
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24e_241_24EApp, 2);
            heff_drop(v_g_2414);
            heff_drop(v_t_2418);
            V v_t_2419 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_as_249)));
            V v_t_2420 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_as_249));
            return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_str0), v_t_2419, v_t_2420});
          } else {
            heff_drop(v_t_2418);
            V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
            V v_t_2422 = (g_list_2emap(v_t_2421, v_as_249));
            return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_t_2422});
          }
        } else {
          V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
          V v_t_2424 = (g_list_2emap(v_t_2423, v_as_249));
          return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_t_2424});
        }
      } else {
        V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
        V v_t_2426 = (g_list_2emap(v_t_2425, v_as_249));
        return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_t_2426});
      }
    }
    case TAG_ELam: {
      V v_t_2429 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2431 = (g_list_2emap(v_t_2430, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2429, v_t_2431});
    }
    case TAG_EApp: {
      V v_t_2434 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2435 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2436 = (g_list_2emap(v_t_2435, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2434, v_t_2436});
    }
    case TAG_ELet: {
      V v_t_2440 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2442 = (g_list_2emap(v_t_2441, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2440, v_t_2442});
    }
    case TAG_ERecord: {
      V v_t_2445 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2447 = (g_list_2emap(v_t_2446, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2445, v_t_2447});
    }
    case TAG_EProj: {
      V v_t_2452 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2454 = (g_list_2emap(v_t_2453, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2452, v_t_2454});
    }
    case TAG_ETag: {
      V v_t_2458 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2459 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2460 = (g_list_2emap(v_t_2459, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2458, v_t_2460});
    }
    case TAG_EMatch: {
      V v_t_2463 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2465 = (g_list_2emap(v_t_2464, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2463, v_t_2465});
    }
    case TAG_EPrim: {
      V v_t_2467 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2469 = (g_list_2emap(v_t_2468, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2467, v_t_2469});
    }
    case TAG_EPrimCall: {
      V v_t_2472 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2474 = (g_list_2emap(v_t_2473, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2472, v_t_2474});
    }
    case TAG_ECall: {
      V v_t_2477 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2479 = (g_list_2emap(v_t_2478, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2477, v_t_2479});
    }
    case TAG_EInt: {
      V v_t_2481 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2482 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2483 = (g_list_2emap(v_t_2482, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2481, v_t_2483});
    }
    case TAG_EFloat: {
      V v_t_2485 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2487 = (g_list_2emap(v_t_2486, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2485, v_t_2487});
    }
    case TAG_EStr: {
      V v_t_2489 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2490 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2491 = (g_list_2emap(v_t_2490, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2489, v_t_2491});
    }
    case TAG_EBytes: {
      V v_t_2493 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2494 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2495 = (g_list_2emap(v_t_2494, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2493, v_t_2495});
    }
    case TAG_EFixed: {
      V v_t_2498 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24100 = (g_list_2emap(v_t_2499, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2498, v_t_24100});
    }
    case TAG_EFloat32: {
      V v_t_24102 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_24103 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24104 = (g_list_2emap(v_t_24103, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_24102, v_t_24104});
    }
    case TAG_EAbandon: {
      V v_t_24105 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_24106 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24107 = (g_list_2emap(v_t_24106, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_24105, v_t_24107});
    }
    case TAG_EFix: {
      V v_t_24110 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_248));
      V v_t_24111 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24112 = (g_list_2emap(v_t_24111, v_as_249));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_24110, v_t_24112});
    }
    default: return heff_nomatch(v_e1_248);
    }
  }
  case TAG_ELet: {
    V v_x_24113 = heff_field(v_e_241, 0);
    V v_a_24114 = heff_field(v_e_241, 1);
    V v_b_24115 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_24116 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_a_24114));
    V v_cell_24117 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_24113, v_t_24116, heff_hole()});
    V v_u_24118 = (g_heff_2ecompile_2efuse_2eselfOut_24dps(v_me_240, v_b_24115, heff_dup(v_cell_24117), MK_INT(2LL)));
    heff_drop(v_u_24118);
    return v_cell_24117;
  }
  case TAG_ERecord: {
    V v_fs_24119 = heff_field(v_e_241, 0);
    V v_ts_24120 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_24129 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_lam0, 1, 1, (V[]){v_me_240}), v_fs_24119));
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_24129, v_ts_24120});
  }
  case TAG_EProj: {
    V v_e1_24130 = heff_field(v_e_241, 0);
    V v_l_24131 = heff_field(v_e_241, 1);
    V v_sh_24132 = heff_field(v_e_241, 2);
    V v_t_24133 = heff_field(v_e_241, 3);
    V v_ru_24e_241_24EProj = heff_take_reuse_n(v_e_241, 15ULL, 4);
    V v_t_24134 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_e1_24130));
    return heff_tag_at_n(v_ru_24e_241_24EProj, TAG_EProj, 4, (V[]){v_t_24134, v_l_24131, v_sh_24132, v_t_24133});
  }
  case TAG_ETag: {
    V v_t_24135 = heff_field(v_e_241, 0);
    V v_as_24136 = heff_field(v_e_241, 1);
    V v_ts_24137 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_24138 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24139 = (g_list_2emap(v_t_24138, v_as_24136));
    return heff_tag_at_n(v_ru_24e_241_24ETag, TAG_ETag, 3, (V[]){v_t_24135, v_t_24139, v_ts_24137});
  }
  case TAG_EMatch: {
    V v_s_24140 = heff_field(v_e_241, 0);
    V v_arms_24141 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_24142 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_s_24140));
    V v_f_24143 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24149 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_lam1, 1, 1, (V[]){v_f_24143}), v_arms_24141));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_24142, v_t_24149});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    V v_p_24151 = heff_field(v_e_241, 0);
    V v_as_24152 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_24153 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24154 = (g_list_2emap(v_t_24153, v_as_24152));
    return heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_24151, v_t_24154});
  }
  case TAG_ECall: {
    V v_g_24155 = heff_field(v_e_241, 0);
    V v_as_24156 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_24155), heff_dup(heff_rfield(v_me_240, 0)))) {
      V v_t_24158 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_24156));
      if (heff_intEq_c(v_t_24158, heff_dup(heff_rfield(v_me_240, 1)))) {
        V v_t_24160 = (g_heff_2ecompile_2efuse_2evarAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(heff_rfield(v_me_240, 3)), v_as_24156));
        if ((heff_dup(v_t_24160) == NTAG(TAG_True))) {
          heff_drop(v_g_24155);
          heff_drop_cell(v_ru_24e_241_24ECall, 2);
          heff_drop(v_t_24160);
          V v_t_24161 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_as_24156)));
          V v_t_24162 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_as_24156));
          return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_str1), v_t_24161, v_t_24162});
        } else {
          heff_drop(v_t_24160);
          V v_t_24163 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
          V v_t_24164 = (g_list_2emap(v_t_24163, v_as_24156));
          return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_24155, v_t_24164});
        }
      } else {
        V v_t_24165 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
        V v_t_24166 = (g_list_2emap(v_t_24165, v_as_24156));
        return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_24155, v_t_24166});
      }
    } else {
      V v_t_24167 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24168 = (g_list_2emap(v_t_24167, v_as_24156));
      return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_24155, v_t_24168});
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop_rec(v_me_240, 4);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eselfOut(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eselfOut_lam0(V self, V *args) {
  V v_p_24121 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24124;
  switch (heff_tag_of(v_p_24121)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_dup(heff_field(v_p_24121, 0));
    v_t_24124 = v_x_24122;
    break;
  }
  default: heff_nomatch(v_p_24121);
  }
  V v_t_24127;
  switch (heff_tag_of(v_p_24121)) {
  case TAG_MkPair: {
    V v_y_24126 = heff_field(v_p_24121, 1);
    heff_take_n(v_p_24121, 2ULL, 2);
    v_t_24127 = v_y_24126;
    break;
  }
  default: heff_nomatch(v_p_24121);
  }
  V v_t_24128 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_t_24127));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24124, v_t_24128});
}
V g_heff_2ecompile_2efuse_2eselfOut_lam1(V self, V *args) {
  V v_x2_24144 = args[0];
  V v_f_24143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24144)) {
  case TAG_MkArm: {
    V v_t_24145 = heff_field(v_x2_24144, 0);
    V v_vs_24146 = heff_field(v_x2_24144, 1);
    V v_b_24147 = heff_field(v_x2_24144, 2);
    V v_ru_24x2_24144_24MkArm = heff_take_reuse_n(v_x2_24144, 7ULL, 3);
    V v_t_24148 = heff_tr(heff_call(v_f_24143, 1, (V[]){v_b_24147}));
    return heff_tag_at_n(v_ru_24x2_24144_24MkArm, TAG_MkArm, 3, (V[]){v_t_24145, v_vs_24146, v_t_24148});
  }
  default: return heff_nomatch(v_x2_24144);
  }
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam3(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam5(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam6(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam7(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam8(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam9(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam10(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam11(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam12(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam13(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam14(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam15(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam16(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam17(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam18(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam19(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam20(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam21(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam22(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam23(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam24(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam25(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam26(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfArgs_entry, 3, 0};

V g_heff_2ecompile_2efuse_2eselfArgs(V v_g_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_n_241;
    V t_2 = v_b_246;
    v_g_240 = t_0;
    v_n_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_as_248 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      V v_f_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam0, 2, 1, (V[]){v_f_2410}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    }
    case TAG_EGlobal: {
      V v_h_2415 = heff_field(v_x31_247, 0);
      heff_take_n(v_x31_247, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_g_240), v_h_2415)) {
        V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_248));
        if (heff_intEq_c(v_t_2417, heff_dup(v_n_241))) {
          heff_drop(v_g_240);
          heff_drop(v_n_241);
          return heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_as_248, NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x3_242_24EApp, 2);
          V v_f_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
          V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_248));
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam1, 2, 1, (V[]){v_f_2419}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
        }
      } else {
        heff_drop_cell(v_ru_24x3_242_24EApp, 2);
        V v_f_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
        V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_248));
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam2, 2, 1, (V[]){v_f_2424}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2425; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
      }
    }
    case TAG_ELam: {
      V v_f_2431 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam3, 2, 1, (V[]){v_f_2431}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2432; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
    }
    case TAG_EApp: {
      V v_f_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam4, 2, 1, (V[]){v_f_2438}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2439; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2439); r_; });
    }
    case TAG_ELet: {
      V v_f_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam5, 2, 1, (V[]){v_f_2446}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2447; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2447); r_; });
    }
    case TAG_ERecord: {
      V v_f_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2454 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam6, 2, 1, (V[]){v_f_2453}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2454; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2454); r_; });
    }
    case TAG_EProj: {
      V v_f_2462 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam7, 2, 1, (V[]){v_f_2462}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2463; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
    }
    case TAG_ETag: {
      V v_f_2470 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam8, 2, 1, (V[]){v_f_2470}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2471; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2471); r_; });
    }
    case TAG_EMatch: {
      V v_f_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam9, 2, 1, (V[]){v_f_2477}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2478; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2478); r_; });
    }
    case TAG_EPrim: {
      V v_f_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2484 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam10, 2, 1, (V[]){v_f_2483}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2484; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2484); r_; });
    }
    case TAG_EPrimCall: {
      V v_f_2490 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2491 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam11, 2, 1, (V[]){v_f_2490}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2491; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2491); r_; });
    }
    case TAG_ECall: {
      V v_f_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam12, 2, 1, (V[]){v_f_2497}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2498; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2498); r_; });
    }
    case TAG_EInt: {
      V v_f_24103 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam13, 2, 1, (V[]){v_f_24103}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24104; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24104); r_; });
    }
    case TAG_EFloat: {
      V v_f_24109 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24110 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam14, 2, 1, (V[]){v_f_24109}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24110; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24110); r_; });
    }
    case TAG_EStr: {
      V v_f_24115 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24116 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam15, 2, 1, (V[]){v_f_24115}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24116; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24116); r_; });
    }
    case TAG_EBytes: {
      V v_f_24121 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24122 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam16, 2, 1, (V[]){v_f_24121}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24122; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24122); r_; });
    }
    case TAG_EFixed: {
      V v_f_24128 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24129 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam17, 2, 1, (V[]){v_f_24128}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24129; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24129); r_; });
    }
    case TAG_EFloat32: {
      V v_f_24134 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24135 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam18, 2, 1, (V[]){v_f_24134}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24135; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24135); r_; });
    }
    case TAG_EAbandon: {
      V v_f_24139 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24140 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam19, 2, 1, (V[]){v_f_24139}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24140; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24140); r_; });
    }
    case TAG_EFix: {
      V v_f_24146 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24147 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_as_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam20, 2, 1, (V[]){v_f_24146}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24147; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24147); r_; });
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    V v_a_24152 = heff_field(v_x3_242, 1);
    V v_b_24153 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_24154 = (g_heff_2ecompile_2efuse_2eselfArgs(heff_dup(v_g_240), heff_dup(v_n_241), v_a_24152));
    V v_t_24155 = (g_heff_2ecompile_2efuse_2eselfArgs(v_g_240, v_n_241, v_b_24153));
    return (g_prelude_2e_2b_2b(v_t_24154, v_t_24155));
  }
  case TAG_ERecord: {
    V v_fs_24156 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 2);
    V v_t_24158 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_24156));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam21, 2, 2, (V[]){v_g_240, v_n_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24158; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24158); r_; });
  }
  case TAG_EProj: {
    V v_e_24165 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 4);
    V t_0 = v_g_240;
    V t_1 = v_n_241;
    V t_2 = v_e_24165;
    v_g_240 = t_0;
    v_n_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_24170 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 3);
    V v_f_24172 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
    V v_t_24173 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_24170));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam22, 2, 1, (V[]){v_f_24172}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24173; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24173); r_; });
  }
  case TAG_EMatch: {
    V v_s_24177 = heff_field(v_x3_242, 0);
    V v_arms_24178 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_24179 = (g_heff_2ecompile_2efuse_2eselfArgs(heff_dup(v_g_240), heff_dup(v_n_241), v_s_24177));
    V v_t_24180 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24178));
    V v_t_24188 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam23, 2, 2, (V[]){v_g_240, v_n_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24180; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24180); r_; });
    return (g_prelude_2e_2b_2b(v_t_24179, v_t_24188));
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_24191 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_f_24192 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
    V v_t_24193 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_24191));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam24, 2, 1, (V[]){v_f_24192}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24193; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24193); r_; });
  }
  case TAG_ECall: {
    V v_h_24197 = heff_field(v_x3_242, 0);
    V v_as_24198 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ECall = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_240), v_h_24197)) {
      V v_t_24200 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_24198));
      if (heff_intEq_c(v_t_24200, heff_dup(v_n_241))) {
        heff_drop(v_g_240);
        heff_drop(v_n_241);
        return heff_tag_at_n(v_ru_24x3_242_24ECall, TAG_Cons, 2, (V[]){v_as_24198, NTAG(TAG_Nil)});
      } else {
        heff_drop_cell(v_ru_24x3_242_24ECall, 2);
        V v_f_24202 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
        V v_t_24203 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_24198));
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam25, 2, 1, (V[]){v_f_24202}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24203; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24203); r_; });
      }
    } else {
      heff_drop_cell(v_ru_24x3_242_24ECall, 2);
      V v_f_24207 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24208 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_24198));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam26, 2, 1, (V[]){v_f_24207}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24208; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24208); r_; });
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eselfArgs(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_f_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tr(heff_call(v_f_2410, 1, (V[]){v_x_2413}));
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_2412));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam1(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_x_2422 = args[1];
  V v_f_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_tr(heff_call(v_f_2419, 1, (V[]){v_x_2422}));
  return (g_prelude_2e_2b_2b(v_t_2423, v_acc_2421));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam2(V self, V *args) {
  V v_acc_2426 = args[0];
  V v_x_2427 = args[1];
  V v_f_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_tr(heff_call(v_f_2424, 1, (V[]){v_x_2427}));
  return (g_prelude_2e_2b_2b(v_t_2428, v_acc_2426));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam3(V self, V *args) {
  V v_acc_2433 = args[0];
  V v_x_2434 = args[1];
  V v_f_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tr(heff_call(v_f_2431, 1, (V[]){v_x_2434}));
  return (g_prelude_2e_2b_2b(v_t_2435, v_acc_2433));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam4(V self, V *args) {
  V v_acc_2440 = args[0];
  V v_x_2441 = args[1];
  V v_f_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tr(heff_call(v_f_2438, 1, (V[]){v_x_2441}));
  return (g_prelude_2e_2b_2b(v_t_2442, v_acc_2440));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam5(V self, V *args) {
  V v_acc_2448 = args[0];
  V v_x_2449 = args[1];
  V v_f_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = heff_tr(heff_call(v_f_2446, 1, (V[]){v_x_2449}));
  return (g_prelude_2e_2b_2b(v_t_2450, v_acc_2448));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam6(V self, V *args) {
  V v_acc_2455 = args[0];
  V v_x_2456 = args[1];
  V v_f_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tr(heff_call(v_f_2453, 1, (V[]){v_x_2456}));
  return (g_prelude_2e_2b_2b(v_t_2457, v_acc_2455));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam7(V self, V *args) {
  V v_acc_2464 = args[0];
  V v_x_2465 = args[1];
  V v_f_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_tr(heff_call(v_f_2462, 1, (V[]){v_x_2465}));
  return (g_prelude_2e_2b_2b(v_t_2466, v_acc_2464));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam8(V self, V *args) {
  V v_acc_2472 = args[0];
  V v_x_2473 = args[1];
  V v_f_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474 = heff_tr(heff_call(v_f_2470, 1, (V[]){v_x_2473}));
  return (g_prelude_2e_2b_2b(v_t_2474, v_acc_2472));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam9(V self, V *args) {
  V v_acc_2479 = args[0];
  V v_x_2480 = args[1];
  V v_f_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2481 = heff_tr(heff_call(v_f_2477, 1, (V[]){v_x_2480}));
  return (g_prelude_2e_2b_2b(v_t_2481, v_acc_2479));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam10(V self, V *args) {
  V v_acc_2485 = args[0];
  V v_x_2486 = args[1];
  V v_f_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2487 = heff_tr(heff_call(v_f_2483, 1, (V[]){v_x_2486}));
  return (g_prelude_2e_2b_2b(v_t_2487, v_acc_2485));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam11(V self, V *args) {
  V v_acc_2492 = args[0];
  V v_x_2493 = args[1];
  V v_f_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2494 = heff_tr(heff_call(v_f_2490, 1, (V[]){v_x_2493}));
  return (g_prelude_2e_2b_2b(v_t_2494, v_acc_2492));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam12(V self, V *args) {
  V v_acc_2499 = args[0];
  V v_x_24100 = args[1];
  V v_f_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24101 = heff_tr(heff_call(v_f_2497, 1, (V[]){v_x_24100}));
  return (g_prelude_2e_2b_2b(v_t_24101, v_acc_2499));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam13(V self, V *args) {
  V v_acc_24105 = args[0];
  V v_x_24106 = args[1];
  V v_f_24103 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24107 = heff_tr(heff_call(v_f_24103, 1, (V[]){v_x_24106}));
  return (g_prelude_2e_2b_2b(v_t_24107, v_acc_24105));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam14(V self, V *args) {
  V v_acc_24111 = args[0];
  V v_x_24112 = args[1];
  V v_f_24109 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24113 = heff_tr(heff_call(v_f_24109, 1, (V[]){v_x_24112}));
  return (g_prelude_2e_2b_2b(v_t_24113, v_acc_24111));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam15(V self, V *args) {
  V v_acc_24117 = args[0];
  V v_x_24118 = args[1];
  V v_f_24115 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24119 = heff_tr(heff_call(v_f_24115, 1, (V[]){v_x_24118}));
  return (g_prelude_2e_2b_2b(v_t_24119, v_acc_24117));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam16(V self, V *args) {
  V v_acc_24123 = args[0];
  V v_x_24124 = args[1];
  V v_f_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24125 = heff_tr(heff_call(v_f_24121, 1, (V[]){v_x_24124}));
  return (g_prelude_2e_2b_2b(v_t_24125, v_acc_24123));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam17(V self, V *args) {
  V v_acc_24130 = args[0];
  V v_x_24131 = args[1];
  V v_f_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24132 = heff_tr(heff_call(v_f_24128, 1, (V[]){v_x_24131}));
  return (g_prelude_2e_2b_2b(v_t_24132, v_acc_24130));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam18(V self, V *args) {
  V v_acc_24136 = args[0];
  V v_x_24137 = args[1];
  V v_f_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24138 = heff_tr(heff_call(v_f_24134, 1, (V[]){v_x_24137}));
  return (g_prelude_2e_2b_2b(v_t_24138, v_acc_24136));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam19(V self, V *args) {
  V v_acc_24141 = args[0];
  V v_x_24142 = args[1];
  V v_f_24139 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24143 = heff_tr(heff_call(v_f_24139, 1, (V[]){v_x_24142}));
  return (g_prelude_2e_2b_2b(v_t_24143, v_acc_24141));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam20(V self, V *args) {
  V v_acc_24148 = args[0];
  V v_x_24149 = args[1];
  V v_f_24146 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24150 = heff_tr(heff_call(v_f_24146, 1, (V[]){v_x_24149}));
  return (g_prelude_2e_2b_2b(v_t_24150, v_acc_24148));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam21(V self, V *args) {
  V v_acc_24159 = args[0];
  V v_x_24160 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24163;
  switch (heff_tag_of(v_x_24160)) {
  case TAG_MkPair: {
    V v_y_24162 = heff_field(v_x_24160, 1);
    heff_take_n(v_x_24160, 2ULL, 2);
    v_t_24163 = v_y_24162;
    break;
  }
  default: heff_nomatch(v_x_24160);
  }
  V v_t_24164 = (g_heff_2ecompile_2efuse_2eselfArgs(v_g_240, v_n_241, v_t_24163));
  return (g_prelude_2e_2b_2b(v_t_24164, v_acc_24159));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam22(V self, V *args) {
  V v_acc_24174 = args[0];
  V v_x_24175 = args[1];
  V v_f_24172 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24176 = heff_tr(heff_call(v_f_24172, 1, (V[]){v_x_24175}));
  return (g_prelude_2e_2b_2b(v_t_24176, v_acc_24174));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam23(V self, V *args) {
  V v_acc_24181 = args[0];
  V v_x_24182 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24186;
  switch (heff_tag_of(v_x_24182)) {
  case TAG_MkArm: {
    V v_b_24185 = heff_field(v_x_24182, 2);
    heff_take_n(v_x_24182, 4ULL, 3);
    v_t_24186 = v_b_24185;
    break;
  }
  default: heff_nomatch(v_x_24182);
  }
  V v_t_24187 = (g_heff_2ecompile_2efuse_2eselfArgs(v_g_240, v_n_241, v_t_24186));
  return (g_prelude_2e_2b_2b(v_t_24187, v_acc_24181));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam24(V self, V *args) {
  V v_acc_24194 = args[0];
  V v_x_24195 = args[1];
  V v_f_24192 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24196 = heff_tr(heff_call(v_f_24192, 1, (V[]){v_x_24195}));
  return (g_prelude_2e_2b_2b(v_t_24196, v_acc_24194));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam25(V self, V *args) {
  V v_acc_24204 = args[0];
  V v_x_24205 = args[1];
  V v_f_24202 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24206 = heff_tr(heff_call(v_f_24202, 1, (V[]){v_x_24205}));
  return (g_prelude_2e_2b_2b(v_t_24206, v_acc_24204));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam26(V self, V *args) {
  V v_acc_24209 = args[0];
  V v_x_24210 = args[1];
  V v_f_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24211 = heff_tr(heff_call(v_f_24207, 1, (V[]){v_x_24210}));
  return (g_prelude_2e_2b_2b(v_t_24211, v_acc_24209));
}
V g_heff_2ecompile_2efuse_2econsumerWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2econsumerWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econsumerWith_entry, 5, 0};

V g_heff_2ecompile_2efuse_2econsumerWith(V v_key_240, V v_ps_241, V v_at_242, V v_arms_243, V v_ks_244) {
top: ;
  V v_t_245 = (g_list_2eall_24s1373454977x2143028054(v_ks_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = (g_list_2eany_24s1375915522x445000623(v_ks_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_arms_243), v_ks_244));
      V v_t_248 = (g_heff_2ecompile_2efuse_2egoesOf(v_t_247));
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_243)));
      V v_t_2418 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2econsumerWith_lam0, 2, 2, (V[]){heff_dup(v_ps_241), v_key_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
      V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_ps_241); V r_ = (g_heff_2ecompile_2efuse_2efixedGo(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(5, shape_params__at__arms__goes__fixed, (V[]){v_ps_241, v_at_242, v_arms_243, v_t_248, v_t_2419})});
    } else {
      heff_drop(v_key_240);
      heff_drop(v_ps_241);
      heff_drop(v_at_242);
      heff_drop(v_arms_243);
      heff_drop(v_ks_244);
      heff_drop(v_t_246);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop(v_key_240);
    heff_drop(v_ps_241);
    heff_drop(v_at_242);
    heff_drop(v_arms_243);
    heff_drop(v_ks_244);
    heff_drop(v_t_245);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2efuse_2econsumerWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2econsumerWith(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2efuse_2econsumerWith_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_ps_241 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ps_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ps_241); r_; });
  V v_t_2416;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkArm: {
    V v_b_2415 = heff_field(v_x_2411, 2);
    heff_take_n(v_x_2411, 4ULL, 3);
    v_t_2416 = v_b_2415;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V v_t_2417 = (g_heff_2ecompile_2efuse_2eselfArgs(v_key_240, v_t_2412, v_t_2416));
  return (g_prelude_2e_2b_2b(v_t_2417, v_acc_2410));
}
Clo g_heff_2ecompile_2efuse_2ewithMade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ewithMade_entry, 4, 0};

V g_heff_2ecompile_2efuse_2ewithMade(V v_cp_240, V v_k_241, V v_x3_242, V v_s_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_cp_240, v_k_241, heff_take_field(v_s_243, 3)));
    return ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_nf(v_s_243, 55ULL, 6, shape_supply__consumers__producers__made__fresh__left, 3903u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  case TAG_Just: {
    V v_d_245 = heff_field(v_x3_242, 0);
    V v_x3_246 = (g_heff_2ecompile_2efuse_2econsumerOf(heff_dup(heff_rfield(v_d_245, 0)), heff_rfield(v_d_245, 2)));
    V v_t_248;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      v_t_248 = heff_dup(heff_rfield(v_s_243, 1));
      break;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x3_246, 0);
      heff_take_n(v_x3_246, 1ULL, 1);
      v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_d_245, 0)), v_x_247, heff_dup(heff_rfield(v_s_243, 1))));
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    V v_x3_249 = (g_heff_2ecompile_2efuse_2eproducerOf(heff_dup(heff_rfield(v_d_245, 0)), heff_rfield(v_d_245, 2)));
    V v_t_2411;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      v_t_2411 = heff_dup(heff_rfield(v_s_243, 2));
      break;
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x3_249, 0);
      heff_take_n(v_x3_249, 1ULL, 1);
      v_t_2411 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_d_245, 0)), v_x_2410, heff_dup(heff_rfield(v_s_243, 2))));
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(v_cp_240, v_k_241, heff_take_field(v_s_243, 3)));
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_d_245), heff_take_field(v_s_243, 4)});
    V v_t_2414 = heff_intSub(heff_take_field(v_s_243, 5), MK_INT(1LL));
    return ({ V rv_1 = v_t_248; V rv_2 = v_t_2411; V rv_3 = v_t_2412; V rv_4 = v_t_2413; V rv_5 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_s_243, 1ULL, 6, shape_supply__consumers__producers__made__fresh__left, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2ewithMade_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2ewithMade(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2efuse_2ebindsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ebindsOf_entry, 3, 0};

V g_heff_2ecompile_2efuse_2ebindsOf(V v_x1_240, V v_x2_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_b_242;
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_b_242;
    }
    case TAG_Cons: {
      V v_h_245 = heff_field(v_x2_241, 0);
      V v_hs_246 = heff_field(v_x2_241, 1);
      V v_t_2441;
      switch (heff_tag_of(v_h_245)) {
      case TAG_EVar: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2441 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2441 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_h_245);
      }
      if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
        heff_drop(v_t_2441);
        V v_e_2442 = (g_heff_2ecompile_2efuse_2ebindsOf(v_vs_244, v_hs_246, v_b_242));
        V v_t_2443 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_243), heff_dup(v_h_245), NTAG(TAG_Tip), NTAG(TAG_Tip)});
        V v_t_2444 = ({ V a_0 = v_t_2443; V r_ = (g_map_2esize(a_0)); heff_drop_tag(v_t_2443, 5); r_; });
        if (heff_intEq_c(v_t_2444, MK_INT(0LL))) {
          return v_e_2442;
        } else {
          V v_t_2446 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_243), heff_dup(v_h_245), NTAG(TAG_Tip), NTAG(TAG_Tip)});
          return ({ V a_0 = v_t_2446; V a_1 = v_e_2442; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop_tag(v_t_2446, 5); r_; });
        }
      } else {
        heff_drop(v_t_2441);
        V v_cell_2447 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_v_243), heff_dup(v_h_245), heff_hole()});
        V v_u_2448 = (g_heff_2ecompile_2efuse_2ebindsOf_24dps(v_vs_244, v_hs_246, v_b_242, heff_dup(v_cell_2447)));
        heff_drop(v_u_2448);
        return v_cell_2447;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2ebindsOf(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2ebindsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2ebindsOf_24dps(V v_x1_240, V v_x2_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(2LL), v_b_242);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x1_240, 0);
    V v_vs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_setField(v_d_243, MK_INT(2LL), v_b_242);
    }
    case TAG_Cons: {
      V v_h_246 = heff_field(v_x2_241, 0);
      V v_hs_247 = heff_field(v_x2_241, 1);
      V v_t_2442;
      switch (heff_tag_of(v_h_246)) {
      case TAG_EVar: {
        v_t_2442 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2442 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2442 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2442 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2442 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2442 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2442 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_h_246);
      }
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop(v_t_2442);
        V v_e_2443 = (g_heff_2ecompile_2efuse_2ebindsOf(v_vs_245, v_hs_247, v_b_242));
        V v_t_2444 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_244), heff_dup(v_h_246), NTAG(TAG_Tip), NTAG(TAG_Tip)});
        V v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_map_2esize(a_0)); heff_drop_tag(v_t_2444, 5); r_; });
        if (heff_intEq_c(v_t_2445, MK_INT(0LL))) {
          return heff_setField(v_d_243, MK_INT(2LL), v_e_2443);
        } else {
          V v_t_2447 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_244), heff_dup(v_h_246), NTAG(TAG_Tip), NTAG(TAG_Tip)});
          V v_t_2448 = ({ V a_0 = v_t_2447; V a_1 = v_e_2443; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop_tag(v_t_2447, 5); r_; });
          return heff_setField(v_d_243, MK_INT(2LL), v_t_2448);
        }
      } else {
        heff_drop(v_t_2442);
        V v_cell_2449 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_v_244), heff_dup(v_h_246), heff_hole()});
        V v_u_2450 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2449));
        heff_drop(v_u_2450);
        V t_0 = v_vs_245;
        V t_1 = v_hs_247;
        V t_2 = v_b_242;
        V t_3 = v_cell_2449;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_b_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2ebindsOf_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efuse_2eatEnds_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eatEnds_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eatEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eatEnds_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eatEnds(V v_fu_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = heff_tr(g_heff_2ecompile_2efuse_2eatEnds(v_fu_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eatEnds_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_241, 0);
    V v_arms_2426 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eatEnds_clo), 1, (V[]){v_fu_240}));
    V v_t_2428 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2426)));
    V v_m_2429 = (g_heff_2ecompile_2efuse_2etraverseF(v_t_2427, v_t_2428));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eatEnds_lam1, 1, 3, (V[]){v_m_2429, v_arms_2426, v_s_2425});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuse_2eatEnds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eatEnds(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eatEnds_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2efuse_2eatEnds_lam1(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_arms_2426 = heff_env(self)[1];
  V v_s_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2426, v_x_2432));
    V v_x_2435 = heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2425, v_t_2434});
    return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
Clo g_heff_2ecompile_2efuse_2econsumerCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econsumerCall_entry, 7, 0};

V g_heff_2ecompile_2efuse_2econsumerCall(V v_sg_240, V v_k_241, V v_pl_242, V v_g_243, V v_as_244, V v_x6_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    V v_m_247 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_as_244));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_246}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        heff_drop(v_g_243);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2411 = heff_field(v_x_249, 0);
        V v_ru_24x_249_24Just = heff_take_reuse_n(v_x_249, 1ULL, 1);
        V v_t_2412 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_243}), v_x_2411});
        v_t_2413 = heff_tag_at_n(v_ru_24x_249_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_s_2410});
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  case TAG_Just: {
    V v_cs_2414 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2415 = (g_heff_2ecompile_2efuse_2evarAt(heff_get_n(v_cs_2414, 1, 5), heff_dup(heff_rfield(v_pl_242, 0)), v_as_244));
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_k_241);
      heff_drop_cell(v_ru_24x6_245_24Just, 1);
      heff_drop(v_t_2415);
      V v_p_2416 = heff_take_field(v_pl_242, 1);
      V v_t_2417 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_243), heff_rfield(v_z_246, 1)));
      V v_t_2418 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_p_2416), heff_rfield(v_z_246, 2)));
      return ({ V a_0 = v_sg_240; V a_1 = v_g_243; V a_2 = v_as_244; V a_3 = v_p_2416; V a_4 = heff_get_n(v_pl_242, 2, 3); V a_5 = v_t_2417; V a_6 = v_t_2418; V a_7 = v_z_246; V r_ = (g_heff_2ecompile_2efuse_2efuseKnown(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2417); heff_drop(v_t_2418); r_; });
    } else {
      heff_drop(v_t_2415);
      V v_m_2419 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_as_244));
      V v_x2_2420 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_z_246}));
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_MkPair: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_s_2422 = heff_field(v_x2_2420, 1);
        V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
        V v_t_2425;
        switch (heff_tag_of(v_x_2421)) {
        case TAG_Nothing: {
          heff_drop(v_g_243);
          heff_drop_cell(v_ru_24x6_245_24Just, 1);
          v_t_2425 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2423 = heff_field(v_x_2421, 0);
          V v_ru_24x_2421_24Just = heff_take_reuse_n(v_x_2421, 1ULL, 1);
          V v_t_2424 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x_2421_24Just, TAG_EGlobal, 1, (V[]){v_g_243}), v_x_2423});
          v_t_2425 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_Just, 1, (V[]){v_t_2424});
          break;
        }
        default: heff_nomatch(v_x_2421);
        }
        return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_s_2422});
      }
      default: return heff_nomatch(v_x2_2420);
      }
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2efuse_2econsumerCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2econsumerCall(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2efuse_2eplugGo_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam1(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam1, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam2(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam2, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam3(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam3, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam5(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam5, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam6(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam6, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam7(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam7, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam8(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam8, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam9(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam9, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam10(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam10, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam11(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam11, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam12(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam12, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam13(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam13, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam14(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam14, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam15(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam15, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam16(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam16, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam17(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam17, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam18(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam18, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam19(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam19, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam20(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam20, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam21(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam21, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam22(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam22, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam23(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam24(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam25(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam25, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam26(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam26, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam27(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam27, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam28(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam29(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam30(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam30, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam31(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam31, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam32(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam33(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam34(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam34, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam35(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam35, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam36(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam36, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam37(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam37, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam38(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam38, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam39(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam39, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam40(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam40, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam41(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam41, 1, 0};
Clo g_heff_2ecompile_2efuse_2eplugGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_entry, 4, 0};

V g_heff_2ecompile_2efuse_2eplugGo(V v_sg_240, V v_k_241, V v_pl_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam0_clo);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam1_clo);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam2_clo);
  }
  case TAG_EApp: {
    V v_x41_2411 = heff_field(v_x4_243, 0);
    V v_as_2412 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_2411)) {
    case TAG_EVar: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam3_clo);
    }
    case TAG_EGlobal: {
      V v_g_2415 = heff_field(v_x41_2411, 0);
      heff_take_n(v_x41_2411, 1ULL, 1);
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam4, 1, 5, (V[]){v_g_2415, v_sg_240, v_k_241, v_pl_242, v_as_2412});
    }
    case TAG_ELam: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam5_clo);
    }
    case TAG_EApp: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam6_clo);
    }
    case TAG_ELet: {
      heff_take_n(v_x41_2411, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam7_clo);
    }
    case TAG_ERecord: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam8_clo);
    }
    case TAG_EProj: {
      heff_take_n(v_x41_2411, 0ULL, 4);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam9_clo);
    }
    case TAG_ETag: {
      heff_take_n(v_x41_2411, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam10_clo);
    }
    case TAG_EMatch: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam11_clo);
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam12_clo);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam13_clo);
    }
    case TAG_ECall: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam14_clo);
    }
    case TAG_EInt: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam15_clo);
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam16_clo);
    }
    case TAG_EStr: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam17_clo);
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam18_clo);
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam19_clo);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam20_clo);
    }
    case TAG_EAbandon: {
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam21_clo);
    }
    case TAG_EFix: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_as_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam22_clo);
    }
    default: return heff_nomatch(v_x41_2411);
    }
  }
  case TAG_ELet: {
    V v_y_2468 = heff_field(v_x4_243, 0);
    V v_a_2469 = heff_field(v_x4_243, 1);
    V v_b_2470 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_x_2471 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2469), NTAG(TAG_Nil)});
    V v_t_2473 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_2471), MK_INT(0LL), v_t_2472));
    V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2469), NTAG(TAG_Nil)});
    V v_t_2475 = (g_heff_2ecompile_2eir_2elamW(v_x_2471, v_t_2474));
    V v_x_2476 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2473, v_t_2475}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_2476)) {
      heff_drop(v_sg_240);
      V v_m_2478 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_a_2469}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam23, 1, 3, (V[]){v_m_2478, v_y_2468, v_b_2470});
    } else {
      V v_t_2485 = (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, heff_dup(v_a_2469)));
      if ((heff_dup(v_t_2485) == NTAG(TAG_True))) {
        heff_drop(v_t_2485);
        V v_m_2486 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_b_2470}));
        return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam24, 1, 3, (V[]){v_m_2486, v_y_2468, v_a_2469});
      } else {
        heff_drop_rec(v_k_241, 1);
        heff_drop_rec(v_pl_242, 3);
        heff_drop(v_y_2468);
        heff_drop(v_a_2469);
        heff_drop(v_b_2470);
        heff_drop(v_t_2485);
        return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam25_clo);
      }
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam26_clo);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 4);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam27_clo);
  }
  case TAG_ETag: {
    V v_t_24102 = heff_field(v_x4_243, 0);
    V v_as_24103 = heff_field(v_x4_243, 1);
    V v_ts_24104 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_m_24105 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_as_24103));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam28, 1, 3, (V[]){v_m_24105, v_t_24102, v_ts_24104});
  }
  case TAG_EMatch: {
    V v_s_24112 = heff_field(v_x4_243, 0);
    V v_arms_24113 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EMatch = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_sg_240);
    V v_x_24114 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_24115 = heff_tag_at_n(v_ru_24x4_243_24EMatch, TAG_Cons, 2, (V[]){heff_dup(v_s_24112), NTAG(TAG_Nil)});
    V v_t_24116 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_24114), MK_INT(0LL), v_t_24115));
    V v_t_24117 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_s_24112), NTAG(TAG_Nil)});
    V v_t_24118 = (g_heff_2ecompile_2eir_2elamW(v_x_24114, v_t_24117));
    V v_x_24119 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24116, v_t_24118}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_24119)) {
      V v_m_24121 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_s_24112}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam29, 1, 2, (V[]){v_m_24121, v_arms_24113});
    } else {
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_s_24112);
      heff_drop(v_arms_24113);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam30_clo);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam31_clo);
  }
  case TAG_EPrimCall: {
    V v_q_24131 = heff_field(v_x4_243, 0);
    V v_as_24132 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_m_24133 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_as_24132));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam32, 1, 2, (V[]){v_m_24133, v_q_24131});
  }
  case TAG_ECall: {
    V v_g_24140 = heff_field(v_x4_243, 0);
    V v_as_24141 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam33, 1, 5, (V[]){v_g_24140, v_sg_240, v_k_241, v_pl_242, v_as_24141});
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam34_clo);
  }
  case TAG_EFloat: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam35_clo);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam36_clo);
  }
  case TAG_EBytes: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam37_clo);
  }
  case TAG_EFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam38_clo);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam39_clo);
  }
  case TAG_EAbandon: {
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam40_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam41_clo);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eplugGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2eplugGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_245});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam1(V self, V *args) {
  V v_s_247 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_247});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2410});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2414});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam4(V self, V *args) {
  V v_s_2416 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_pl_242 = heff_env(self)[3];
  V v_as_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2415), heff_rfield(v_s_2416, 1)));
  return (g_heff_2ecompile_2efuse_2econsumerCall(v_sg_240, v_k_241, v_pl_242, v_g_2415, v_as_2412, v_t_2417, v_s_2416));
}
V g_heff_2ecompile_2efuse_2eplugGo_lam5(V self, V *args) {
  V v_s_2420 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2420});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam6(V self, V *args) {
  V v_s_2423 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2423});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam7(V self, V *args) {
  V v_s_2427 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2427});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam8(V self, V *args) {
  V v_s_2430 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2430});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam9(V self, V *args) {
  V v_s_2435 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2435});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam10(V self, V *args) {
  V v_s_2439 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2439});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam11(V self, V *args) {
  V v_s_2442 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2442});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam12(V self, V *args) {
  V v_s_2444 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2444});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam13(V self, V *args) {
  V v_s_2447 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2447});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam14(V self, V *args) {
  V v_s_2450 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2450});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam15(V self, V *args) {
  V v_s_2452 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2452});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam16(V self, V *args) {
  V v_s_2454 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2454});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam17(V self, V *args) {
  V v_s_2456 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2456});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam18(V self, V *args) {
  V v_s_2458 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2458});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam19(V self, V *args) {
  V v_s_2461 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2461});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam20(V self, V *args) {
  V v_s_2463 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2463});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam21(V self, V *args) {
  V v_s_2464 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2464});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam22(V self, V *args) {
  V v_s_2467 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2467});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam23(V self, V *args) {
  V v_s_2479 = args[0];
  V v_m_2478 = heff_env(self)[0];
  V v_y_2468 = heff_env(self)[1];
  V v_b_2470 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2480 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_s_2479}));
  switch (heff_tag_of(v_x2_2480)) {
  case TAG_MkPair: {
    V v_x_2481 = heff_field(v_x2_2480, 0);
    V v_s_2482 = heff_field(v_x2_2480, 1);
    V v_ru_24x2_2480_24MkPair = heff_take_reuse_n(v_x2_2480, 3ULL, 2);
    V v_t_2484;
    switch (heff_tag_of(v_x_2481)) {
    case TAG_Nothing: {
      heff_drop(v_y_2468);
      heff_drop(v_b_2470);
      v_t_2484 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2483 = heff_field(v_x_2481, 0);
      V v_ru_24x_2481_24Just = heff_take_reuse_n(v_x_2481, 1ULL, 1);
      v_t_2484 = heff_tag_at_n(v_ru_24x_2481_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2468, v_x_2483, v_b_2470})});
      break;
    }
    default: heff_nomatch(v_x_2481);
    }
    return heff_tag_at_n(v_ru_24x2_2480_24MkPair, TAG_MkPair, 2, (V[]){v_t_2484, v_s_2482});
  }
  default: return heff_nomatch(v_x2_2480);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam24(V self, V *args) {
  V v_s_2487 = args[0];
  V v_m_2486 = heff_env(self)[0];
  V v_y_2468 = heff_env(self)[1];
  V v_a_2469 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2488 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_s_2487}));
  switch (heff_tag_of(v_x2_2488)) {
  case TAG_MkPair: {
    V v_x_2489 = heff_field(v_x2_2488, 0);
    V v_s_2490 = heff_field(v_x2_2488, 1);
    V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
    V v_t_2492;
    switch (heff_tag_of(v_x_2489)) {
    case TAG_Nothing: {
      heff_drop(v_y_2468);
      heff_drop(v_a_2469);
      v_t_2492 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2491 = heff_field(v_x_2489, 0);
      V v_ru_24x_2489_24Just = heff_take_reuse_n(v_x_2489, 1ULL, 1);
      v_t_2492 = heff_tag_at_n(v_ru_24x_2489_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2468, v_a_2469, v_x_2491})});
      break;
    }
    default: heff_nomatch(v_x_2489);
    }
    return heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_MkPair, 2, (V[]){v_t_2492, v_s_2490});
  }
  default: return heff_nomatch(v_x2_2488);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam25(V self, V *args) {
  V v_s_2493 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2493});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam26(V self, V *args) {
  V v_s_2496 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2496});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam27(V self, V *args) {
  V v_s_24101 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24101});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam28(V self, V *args) {
  V v_s_24106 = args[0];
  V v_m_24105 = heff_env(self)[0];
  V v_t_24102 = heff_env(self)[1];
  V v_ts_24104 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24107 = heff_tr(heff_call(v_m_24105, 1, (V[]){v_s_24106}));
  switch (heff_tag_of(v_x2_24107)) {
  case TAG_MkPair: {
    V v_x_24108 = heff_field(v_x2_24107, 0);
    V v_s_24109 = heff_field(v_x2_24107, 1);
    V v_ru_24x2_24107_24MkPair = heff_take_reuse_n(v_x2_24107, 3ULL, 2);
    V v_t_24111;
    switch (heff_tag_of(v_x_24108)) {
    case TAG_Nothing: {
      heff_drop(v_t_24102);
      heff_drop(v_ts_24104);
      v_t_24111 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_24110 = heff_field(v_x_24108, 0);
      V v_ru_24x_24108_24Just = heff_take_reuse_n(v_x_24108, 1ULL, 1);
      v_t_24111 = heff_tag_at_n(v_ru_24x_24108_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24102, v_x_24110, v_ts_24104})});
      break;
    }
    default: heff_nomatch(v_x_24108);
    }
    return heff_tag_at_n(v_ru_24x2_24107_24MkPair, TAG_MkPair, 2, (V[]){v_t_24111, v_s_24109});
  }
  default: return heff_nomatch(v_x2_24107);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam29(V self, V *args) {
  V v_s_24122 = args[0];
  V v_m_24121 = heff_env(self)[0];
  V v_arms_24113 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24123 = heff_tr(heff_call(v_m_24121, 1, (V[]){v_s_24122}));
  switch (heff_tag_of(v_x2_24123)) {
  case TAG_MkPair: {
    V v_x_24124 = heff_field(v_x2_24123, 0);
    V v_s_24125 = heff_field(v_x2_24123, 1);
    V v_ru_24x2_24123_24MkPair = heff_take_reuse_n(v_x2_24123, 3ULL, 2);
    V v_t_24127;
    switch (heff_tag_of(v_x_24124)) {
    case TAG_Nothing: {
      heff_drop(v_arms_24113);
      v_t_24127 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_24126 = heff_field(v_x_24124, 0);
      V v_ru_24x_24124_24Just = heff_take_reuse_n(v_x_24124, 1ULL, 1);
      v_t_24127 = heff_tag_at_n(v_ru_24x_24124_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24126, v_arms_24113})});
      break;
    }
    default: heff_nomatch(v_x_24124);
    }
    return heff_tag_at_n(v_ru_24x2_24123_24MkPair, TAG_MkPair, 2, (V[]){v_t_24127, v_s_24125});
  }
  default: return heff_nomatch(v_x2_24123);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam30(V self, V *args) {
  V v_s_24128 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24128});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam31(V self, V *args) {
  V v_s_24130 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24130});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam32(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_q_24131 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_t_24139;
    switch (heff_tag_of(v_x_24136)) {
    case TAG_Nothing: {
      heff_drop(v_q_24131);
      v_t_24139 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_24138 = heff_field(v_x_24136, 0);
      V v_ru_24x_24136_24Just = heff_take_reuse_n(v_x_24136, 1ULL, 1);
      v_t_24139 = heff_tag_at_n(v_ru_24x_24136_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_q_24131, v_x_24138})});
      break;
    }
    default: heff_nomatch(v_x_24136);
    }
    return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){v_t_24139, v_s_24137});
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam33(V self, V *args) {
  V v_s_24142 = args[0];
  V v_g_24140 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_pl_242 = heff_env(self)[3];
  V v_as_24141 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24143 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_24140), heff_rfield(v_s_24142, 1)));
  return (g_heff_2ecompile_2efuse_2econsumerCall(v_sg_240, v_k_241, v_pl_242, v_g_24140, v_as_24141, v_t_24143, v_s_24142));
}
V g_heff_2ecompile_2efuse_2eplugGo_lam34(V self, V *args) {
  V v_s_24145 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24145});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam35(V self, V *args) {
  V v_s_24147 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24147});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam36(V self, V *args) {
  V v_s_24149 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24149});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam37(V self, V *args) {
  V v_s_24151 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24151});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam38(V self, V *args) {
  V v_s_24154 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24154});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam39(V self, V *args) {
  V v_s_24156 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24156});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam40(V self, V *args) {
  V v_s_24157 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24157});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam41(V self, V *args) {
  V v_s_24160 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24160});
}