// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_bs 9912
#define LBL_c 317
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_cvars 296399145
#define LBL_fresh 299054408
#define LBL_go 10063
#define LBL_goes 9673821
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_p 330
#define LBL_params 951713969
#define LBL_producers 572620898
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_underLam 296337946
#define LBL_x 338
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_go[] = {LBL_go};
static uint32_t shape_params__body__tags[] = {LBL_params, LBL_body, LBL_tags};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
V g_heff_2ecompile_2efuse_2earmGiven_24tok3(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmGiven_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmGiven_24tok3_clo;
V g_heff_2ecompile_2efuse_2ebindsOf(V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_clo;
V g_heff_2ecompile_2efuse_2ebindsOf_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_24dps_clo;
HeffT2 g_heff_2ecompile_2efuse_2ecallOf_24cpr(V, V, V);
V g_heff_2ecompile_2efuse_2econdCalls(V, V);
V g_heff_2ecompile_2efuse_2econdCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econdCalls_clo;
V g_heff_2ecompile_2efuse_2econsumerCall(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2econsumerCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerCall_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2efuse_2efreshF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2efuseKnown(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseKnown_clo;
V g_heff_2ecompile_2efuse_2efuseNew(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseNew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseNew_clo;
V g_heff_2ecompile_2efuse_2efuseOn_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseOn_24tok2_clo;
V g_heff_2ecompile_2efuse_2eglobalCall(V);
V g_heff_2ecompile_2efuse_2eglobalCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eglobalCall_clo;
HeffT3 g_heff_2ecompile_2efuse_2eglobalCall_24cpr(V);
V g_heff_2ecompile_2efuse_2egoesOf(V);
V g_heff_2ecompile_2efuse_2egoesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_clo;
V g_heff_2ecompile_2efuse_2egoesOf_24dps(V, V);
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo;
V g_heff_2ecompile_2efuse_2einitF(V);
V g_heff_2ecompile_2efuse_2einitF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_clo;
V g_heff_2ecompile_2efuse_2einitF_24dps(V, V);
V g_heff_2ecompile_2efuse_2einitF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_24dps_clo;
V g_heff_2ecompile_2efuse_2einsertAt(V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_clo;
V g_heff_2ecompile_2efuse_2einsertAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo;
V g_heff_2ecompile_2efuse_2eisSelf(V, V, V);
V g_heff_2ecompile_2efuse_2eisSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eisSelf_clo;
V g_heff_2ecompile_2efuse_2eisVar(V, V);
V g_heff_2ecompile_2efuse_2eisVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eisVar_clo;
V g_heff_2ecompile_2efuse_2emakeFused(V, V, V, V);
V g_heff_2ecompile_2efuse_2emakeFused_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emakeFused_clo;
V g_heff_2ecompile_2efuse_2enthF(V, V);
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2enthF_clo;
HeffT2 g_heff_2ecompile_2efuse_2enthF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2eplugArgs(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugArgs_clo;
V g_heff_2ecompile_2efuse_2eplugGo(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugGo_clo;
V g_heff_2ecompile_2efuse_2eplugK(V);
V g_heff_2ecompile_2efuse_2eplugK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugK_clo;
HeffT1 g_heff_2ecompile_2efuse_2eplugK_24cpr(V);
HeffT2 g_heff_2ecompile_2efuse_2eproducerOf_24cpr(V, V);
V g_heff_2ecompile_2efuse_2erecall(V, V, V, V);
V g_heff_2ecompile_2efuse_2erecall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2erecall_clo;
V g_heff_2ecompile_2efuse_2eremoveAt(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt_24dps(V, V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_24dps_clo;
V g_heff_2ecompile_2efuse_2esameGo(V, V);
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esameGo_clo;
V g_heff_2ecompile_2efuse_2eselfArgs(V, V, V);
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfArgs_clo;
V g_heff_2ecompile_2efuse_2eselfOut(V, V);
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_clo;
V g_heff_2ecompile_2efuse_2esetAt(V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_clo;
V g_heff_2ecompile_2efuse_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s78130935x581779089(V, V, V);
V g_list_2eany_24s78130935x581779089_entry(V self, V *a);
extern Clo g_list_2eany_24s78130935x581779089_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s636448764x233713460(V, V);
V g_list_2efoldl_24s636448764x233713460_entry(V self, V *a);
extern Clo g_list_2efoldl_24s636448764x233713460_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1229912102x1467950109(V, V);
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2emaybe(V, V, V);
V g_prelude_2emaybe_entry(V self, V *a);
extern Clo g_prelude_2emaybe_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;

HeffT2 g_heff_2ecompile_2efuse_2enthF_24cpr(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2efuse_2eremoveAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry, 3, 0};

V g_heff_2ecompile_2efuse_2eremoveAt_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_xs_244);
    } else {
      V v_cell_245 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_245);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_u_246;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2eremoveAt_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2efuse_2esetAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esetAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2esetAt(V v_i_240, V v_y_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_y_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      return heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 2ULL, (V[]){v_y_241, v_xs_244});
    } else {
      V v_cell_245 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2efuse_2esetAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_y_241, v_xs_244, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2esetAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2esetAt(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2efuse_2einsertAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einsertAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2einsertAt(V v_i_240, V v_y_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244})});
    } else {
      V v_cell_245 = heff_tag_re_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2efuse_2einsertAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_y_241, v_xs_244, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einsertAt(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2efuse_2einitF_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einitF_24dps_entry, 2, 0};

V g_heff_2ecompile_2efuse_2einitF_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
      V t_0 = v_x12_243;
      V t_1 = v_u_247;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2einitF_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2einitF_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2eisVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eisVar_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eisVar(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_242, 0));
    return v_ret_24bool;
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eisVar_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2eisVar(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2efuse_2ecallOf_24cpr(V v_g_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_args_248 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      V v_h_2410 = heff_field(v_x31_247, 0);
      if ((heff_strEq_c_lent(v_g_240, v_h_2410, 0) && ({ V v_t_2481 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_248)); int c_ = heff_intEq_c_lent(v_t_2481, v_n_241, 0); heff_drop(v_t_2481); c_; }))) {
        heff_drop(v_n_241);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_args_248)}});
      } else {
        heff_drop(v_n_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ELam: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
    }
  }
  case TAG_ELet: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    V v_h_2465 = heff_field(v_x3_242, 0);
    V v_args_2466 = heff_field(v_x3_242, 1);
    if ((heff_strEq_c_lent(v_g_240, v_h_2465, 0) && ({ V v_t_2482 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2466)); int c_ = heff_intEq_c_lent(v_t_2482, v_n_241, 0); heff_drop(v_t_2482); c_; }))) {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_args_2466)}});
    } else {
      heff_drop(v_n_241);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2efuse_2eglobalCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eglobalCall_entry, 1, 0};

V g_heff_2ecompile_2efuse_2eglobalCall(V v_x1_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2ecompile_2efuse_2eglobalCall_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244})});
    } else {
      heff_drop(v_field_243);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2efuse_2eglobalCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuse_2eglobalCall(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2efuse_2esameGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esameGo_entry, 2, 0};

V g_heff_2ecompile_2efuse_2esameGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_x1_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x1_240)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_x1_240, 0);
      V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
      switch (heff_tag_of(v_x21_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_244);
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_245 = heff_field(v_x21_242, 0);
        if (heff_intEq_c_lent(v_a_244, v_b_245, 0)) {
          V t_0 = heff_tag_re_n(v_ru_24x1_240_24Just, TAG_Just, 1, 1ULL, (V[]){v_a_244});
          V t_1 = v_rest_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_a_244);
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_x21_242);
      }
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2esameGo(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2econdCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econdCalls_entry, 2, 0};

V g_heff_2ecompile_2efuse_2econdCalls(V v_go_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_go_240);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_CFalse: {
    heff_drop(v_go_240);
    return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_CRel: {
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_field(v_x2_241, 2);
    V v_x1_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){heff_dup(v_a_243)}));
    V v_x2_246 = heff_tr(heff_call(v_go_240, 1, (V[]){heff_dup(v_b_244)}));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nothing: {
      heff_drop(v_x2_246);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_247 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24Just = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nothing: {
        heff_drop(v_a_247);
        heff_drop_cell(v_ru_24x1_245_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_248 = heff_field(v_x2_246, 0);
        heff_take_n(v_x2_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_245_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_247, v_b_248)});
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  case TAG_CTest: {
    V v_e_249 = heff_field(v_x2_241, 0);
    return heff_tail(v_go_240, 1, (V[]){heff_dup(v_e_249)});
  }
  case TAG_CNot: {
    V v_c_2410 = heff_field(v_x2_241, 0);
    V t_0 = v_go_240;
    V t_1 = v_c_2410;
    v_go_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2411 = heff_field(v_x2_241, 0);
    V v_b_2412 = heff_field(v_x2_241, 1);
    V v_c_2413 = heff_field(v_x2_241, 2);
    V v_x1_2414 = heff_tr(g_heff_2ecompile_2efuse_2econdCalls(heff_dup(v_go_240), v_a_2411));
    V v_t_2415 = heff_tr(g_heff_2ecompile_2efuse_2econdCalls(heff_dup(v_go_240), v_b_2412));
    V v_t_2416 = heff_tr(g_heff_2ecompile_2efuse_2econdCalls(v_go_240, v_c_2413));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      heff_drop(v_t_2416);
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    case TAG_Just: {
      V v_a_2418 = heff_field(v_t_2415, 0);
      V v_ru_24t_2415_24Just = heff_take_reuse_n(v_t_2415, 1ULL, 1);
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        heff_drop(v_a_2418);
        heff_drop_cell(v_ru_24t_2415_24Just, 1);
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nothing: {
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          heff_take_n(v_x1_2414, 0ULL, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x1_2414);
        }
      }
      case TAG_Just: {
        V v_b_2420 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        if (heff_intEq_c_lent(v_a_2418, v_b_2420, 2)) {
          switch (heff_tag_of(v_x1_2414)) {
          case TAG_Nothing: {
            heff_drop(v_a_2418);
            heff_drop_cell(v_ru_24t_2415_24Just, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_a_2421 = heff_field(v_x1_2414, 0);
            heff_take_n(v_x1_2414, 1ULL, 1);
            return heff_tag_at_n(v_ru_24t_2415_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2421, v_a_2418)});
          }
          default: return heff_nomatch(v_x1_2414);
          }
        } else {
          heff_drop(v_a_2418);
          heff_drop_cell(v_ru_24t_2415_24Just, 1);
          switch (heff_tag_of(v_x1_2414)) {
          case TAG_Nothing: {
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            heff_take_n(v_x1_2414, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_x1_2414);
          }
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2econdCalls_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2econdCalls(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_str0, 5, "$self");
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_str1, 5, "$self");
V g_heff_2ecompile_2efuse_2eselfOut_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfOut_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfOut_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eselfOut(V v_me_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EApp: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EGlobal: {
      V v_g_244 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EGlobal = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_EApp: {
        V v_args_246 = heff_field(v_e_241, 1);
        V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 2ULL, 2);
        V v_t_247 = heff_tr(g_heff_2ecompile_2efuse_2eisSelf(heff_dup(v_me_240), v_g_244, v_args_246));
        if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
          heff_drop(v_g_244);
          heff_drop_cell(v_ru_24e1_242_24EGlobal, 1);
          heff_drop_cell(v_ru_24e_241_24EApp, 2);
          heff_drop(v_t_247);
          V v_t_248 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_args_246)));
          V v_t_249 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_args_246));
          return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_str0), v_t_248, v_t_249});
        } else {
          heff_drop(v_t_247);
          V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
          V v_t_2411 = (g_list_2emap(v_t_2410, v_args_246));
          return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_re_n(v_ru_24e1_242_24EGlobal, TAG_EGlobal, 1, 1ULL, (V[]){v_g_244}), v_t_2411});
        }
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e1_242);
      HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_lam0, 2, 1, (V[]){v_me_240}), v_e_241);
    }
    }
  }
  case TAG_ECall: {
    V v_g_2414 = heff_field(v_e_241, 0);
    V v_args_2415 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2416 = heff_tr(g_heff_2ecompile_2efuse_2eisSelf(heff_dup(v_me_240), v_g_2414, v_args_2415));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_g_2414);
      heff_drop_cell(v_ru_24e_241_24ECall, 2);
      heff_drop(v_t_2416);
      V v_t_2417 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_args_2415)));
      V v_t_2418 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_args_2415));
      return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_str1), v_t_2417, v_t_2418});
    } else {
      heff_drop(v_t_2416);
      V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2420 = (g_list_2emap(v_t_2419, v_args_2415));
      return heff_tag_re_n(v_ru_24e_241_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2414, v_t_2420});
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_lam1, 2, 1, (V[]){v_me_240}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eselfOut(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eselfOut_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_2413 = args[1];
  V v_me_240 = heff_env(self)[0];
  heff_drop(v_x_2412);
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_p_2413));
}
V g_heff_2ecompile_2efuse_2eselfOut_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_p_2422 = args[1];
  V v_me_240 = heff_env(self)[0];
  heff_drop(v_x_2421);
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_p_2422));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam3(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfArgs_entry, 3, 0};

V g_heff_2ecompile_2efuse_2eselfArgs(V v_g_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EApp: {
    V v_e1_243 = heff_dup(heff_field(v_e_242, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EGlobal: {
      V v_h_245 = heff_field(v_e1_243, 0);
      heff_take_n(v_e1_243, 1ULL, 1);
      switch (heff_tag_of(v_e_242)) {
      case TAG_EApp: {
        V v_args_247 = heff_field(v_e_242, 1);
        V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 2ULL, 2);
        if ((heff_strEq_c_lent(v_g_240, v_h_245, 0) && ({ V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_247)); int c_ = heff_intEq_c_lent(v_t_2432, v_n_241, 0); heff_drop(v_t_2432); c_; }))) {
          heff_drop(v_g_240);
          heff_drop(v_n_241);
          heff_drop(v_h_245);
          return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_Cons, 2, (V[]){v_args_247, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_h_245);
          heff_drop_cell(v_ru_24e_242_24EApp, 2);
          V v_f_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
          V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_247));
          return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam0, 2, 1, (V[]){v_f_248}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
        }
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    default: {
      heff_drop(v_e1_243);
      V v_f_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_xs_2414 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, NTAG(TAG_Nil)));
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam1, 2, 1, (V[]){v_f_2413}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
    }
    }
  }
  case TAG_ECall: {
    V v_h_2419 = heff_field(v_e_242, 0);
    V v_args_2420 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    if ((heff_strEq_c_lent(v_g_240, v_h_2419, 0) && ({ V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2420)); int c_ = heff_intEq_c_lent(v_t_2433, v_n_241, 0); heff_drop(v_t_2433); c_; }))) {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      heff_drop(v_h_2419);
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_Cons, 2, (V[]){v_args_2420, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_h_2419);
      heff_drop_cell(v_ru_24e_242_24ECall, 2);
      V v_f_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2420));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam2, 2, 1, (V[]){v_f_2421}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2422; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    }
  }
  default: {
    V v_f_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
    V v_xs_2427 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_242, NTAG(TAG_Nil)));
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam3, 2, 1, (V[]){v_f_2426}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2428; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
  }
  }
}
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eselfArgs(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_f_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tr(heff_call(v_f_248, 1, (V[]){v_x_2411}));
  return (g_prelude_2e_2b_2b(v_t_2412, v_acc_2410));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam1(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_x_2417 = args[1];
  V v_f_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_tr(heff_call(v_f_2413, 1, (V[]){v_x_2417}));
  return (g_prelude_2e_2b_2b(v_t_2418, v_acc_2416));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam2(V self, V *args) {
  V v_acc_2423 = args[0];
  V v_x_2424 = args[1];
  V v_f_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_tr(heff_call(v_f_2421, 1, (V[]){v_x_2424}));
  return (g_prelude_2e_2b_2b(v_t_2425, v_acc_2423));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam3(V self, V *args) {
  V v_acc_2429 = args[0];
  V v_x_2430 = args[1];
  V v_f_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431 = heff_tr(heff_call(v_f_2426, 1, (V[]){v_x_2430}));
  return (g_prelude_2e_2b_2b(v_t_2431, v_acc_2429));
}
Clo g_heff_2ecompile_2efuse_2egoesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2egoesOf_entry, 1, 0};

V g_heff_2ecompile_2efuse_2egoesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x11_241, 0);
      V v_x112_244 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x112_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_243);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_Just: {
        V v_x1121_245 = heff_field(v_x112_244, 0);
        heff_take_n(v_x112_244, 1ULL, 1);
        if ((heff_dup(v_x1121_245) == NTAG(TAG_True))) {
          heff_drop(v_x1121_245);
          V v_t_249;
          switch (heff_tag_of(v_a_243)) {
          case TAG_MkArm: {
            V v_t_246 = heff_field(v_a_243, 0);
            heff_take_n(v_a_243, 1ULL, 3);
            v_t_249 = v_t_246;
            break;
          }
          default: heff_nomatch(v_a_243);
          }
          V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
          V v_u_2411 = (g_heff_2ecompile_2efuse_2egoesOf_24dps(v_rest_242, v_cell_2410));
          heff_drop(v_u_2411);
          return v_cell_2410;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_a_243);
          heff_drop(v_x1121_245);
          V t_0 = v_rest_242;
          v_x1_240 = t_0;
          goto top;
        }
      }
      default: return heff_nomatch(v_x112_244);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2egoesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2egoesOf(a[0]);
}

HeffT2 g_heff_2ecompile_2efuse_2eproducerOf_24cpr(V v_key_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    V v_qs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_qs_244));
    V v_t_247 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_245), NTAG(TAG_Nil)));
    V v_t_248 = ({ V a_0 = v_key_240; V a_1 = v_t_246; V a_2 = v_t_247; V r_ = (g_list_2eany_24s78130935x581779089(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_xs_249 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_245), NTAG(TAG_Nil)));
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
      V v_t_2411 = (g_list_2efoldl_24s636448764x233713460(NTAG(TAG_Nil), v_t_2410));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(3, shape_params__body__tags, (V[]){heff_dup(v_qs_244), heff_dup(v_b_245), v_t_2411})}});
    } else {
      heff_drop(v_t_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2ecompile_2efuse_2efreshF_24cpr(V v_e_240, V v_s_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2eordmap_2eempty_get()), heff_take_field(v_s_241, 0), v_e_240));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_e_245 = v_field_243;
    V v_n_246 = v_field_244;
    V v_f_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_nf(v_s_241, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return ((HeffT2){{v_e_245, v_f_247}});
  }
}
Clo g_heff_2ecompile_2efuse_2ebindsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ebindsOf_entry, 3, 0};

V g_heff_2ecompile_2efuse_2ebindsOf(V v_x1_240, V v_x2_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_b_242;
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_b_242;
    }
    case TAG_Cons: {
      V v_h_245 = heff_field(v_x2_241, 0);
      V v_hs_246 = heff_field(v_x2_241, 1);
      V v_t_2446;
      switch (heff_tag_of(v_h_245)) {
      case TAG_EVar: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_h_245);
      }
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_e_2447 = (g_heff_2ecompile_2efuse_2ebindsOf(v_vs_244, v_hs_246, v_b_242));
        return ({ V b_0 = MK_INT(1LL); V a_1 = v_v_243; V a_2 = heff_dup(v_h_245); V a_3 = v_e_2447; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_t_2446);
        V v_cell_2448 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_v_243), heff_dup(v_h_245), heff_hole()});
        V v_u_2449 = (g_heff_2ecompile_2efuse_2ebindsOf_24dps(v_vs_244, v_hs_246, v_b_242, v_cell_2448));
        heff_drop(v_u_2449);
        return v_cell_2448;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2ebindsOf(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2ebindsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2ebindsOf_24dps(V v_x1_240, V v_x2_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_b_242);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x1_240, 0);
    V v_vs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_b_242);
    }
    case TAG_Cons: {
      V v_h_246 = heff_field(v_x2_241, 0);
      V v_hs_247 = heff_field(v_x2_241, 1);
      V v_t_2447;
      switch (heff_tag_of(v_h_246)) {
      case TAG_EVar: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_h_246);
      }
      if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
        heff_drop(v_t_2447);
        V v_e_2448 = (g_heff_2ecompile_2efuse_2ebindsOf(v_vs_245, v_hs_247, v_b_242));
        V v_t_2449 = ({ V b_0 = MK_INT(1LL); V a_1 = v_v_244; V a_2 = heff_dup(v_h_246); V a_3 = v_e_2448; V r_ = (g_heff_2ecompile_2eir_2esubstGo_24s1873075900x715445567(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
        return heff_setField(heff_dup(v_d_243), MK_INT(2LL), v_t_2449);
      } else {
        heff_drop(v_t_2447);
        V v_cell_2450 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_v_244), heff_dup(v_h_246), heff_hole()});
        V v_u_2451 = heff_setFieldPeek(v_d_243, MK_INT(2LL), v_cell_2450);
        V t_0 = v_vs_245;
        V t_1 = v_hs_247;
        V t_2 = v_b_242;
        V t_3 = v_u_2451;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_b_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2efuse_2ebindsOf_24dps(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseNew_str0, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseNew_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseNew_str2, 0, "");
Clo g_heff_2ecompile_2efuse_2efuseNew_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseNew_entry, 8, 0};

V g_heff_2ecompile_2efuse_2efuseNew(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243, V v_args_244, V v_bs_245, V v_left_246, V v_z_247) {
top: ;
  if (heff_intLe_c(v_left_246, MK_INT(0LL))) {
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_ps_243);
    heff_drop(v_args_244);
    heff_drop(v_bs_245);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
  } else {
    V v_m_248 = (g_heff_2ecompile_2efuse_2emakeFused(heff_dup(v_c_240), heff_dup(v_cs_241), heff_dup(v_p_242), v_ps_243));
    V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_247}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
      V v_cp_2412 = heff_strAppend(heff_strAppend(v_c_240, ((V)&g_heff_2ecompile_2efuse_2efuseNew_str0)), v_p_242);
      V v_k_2414;
      switch (heff_tag_of(v_x_2410)) {
      case TAG_Nothing: {
        v_k_2414 = ((V)&g_heff_2ecompile_2efuse_2efuseNew_str1);
        break;
      }
      case TAG_Just: {
        V v_x_2413 = heff_dup(heff_field(v_x_2410, 0));
        v_k_2414 = heff_get_n(v_x_2413, 0, 3);
        break;
      }
      default: heff_nomatch(v_x_2410);
      }
      V v_x3_2415 = heff_dup(v_x_2410);
      V v_s_2416 = v_s_2411;
      V v_s_2432;
      switch (heff_tag_of(v_x3_2415)) {
      case TAG_Nothing: {
        V v_t_2417 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_2416, 3), v_cp_2412, v_k_2414));
        v_s_2432 = ({ V rv_3 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_s_2416, 55ULL, 6, shape_supply__consumers__producers__made__fresh__left, 3903u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
        break;
      }
      case TAG_Just: {
        V v_d_2418 = heff_field(v_x3_2415, 0);
        heff_take_n(v_x3_2415, 1ULL, 1);
        HeffT2 v_t_2419 = (g_heff_2ecompile_2efuse_2econsumerOf_24cpr(heff_dup(heff_rfield(v_d_2418, 0)), heff_rfield(v_d_2418, 2)));
        {
          V v_field_2421 = v_t_2419.f[1];
          int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
          V v_t_2423;
          if ((v_tag_2420 == ((int64_t)0ULL))) {
            V v_x_2422 = v_field_2421;
            v_t_2423 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_s_2416, 1)), heff_dup(heff_rfield(v_d_2418, 0)), v_x_2422));
          } else {
            heff_drop(v_field_2421);
            v_t_2423 = heff_dup(heff_rfield(v_s_2416, 1));
          }
          HeffT2 v_t_2424 = (g_heff_2ecompile_2efuse_2eproducerOf_24cpr(heff_dup(heff_rfield(v_d_2418, 0)), heff_rfield(v_d_2418, 2)));
          {
            V v_field_2426 = v_t_2424.f[1];
            int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
            V v_t_2428;
            if ((v_tag_2425 == ((int64_t)0ULL))) {
              V v_x_2427 = v_field_2426;
              v_t_2428 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_s_2416, 2)), heff_dup(heff_rfield(v_d_2418, 0)), v_x_2427));
            } else {
              heff_drop(v_field_2426);
              v_t_2428 = heff_dup(heff_rfield(v_s_2416, 2));
            }
            V v_t_2429 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_2416, 3), v_cp_2412, v_k_2414));
            V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2418, heff_take_field(v_s_2416, 4)});
            V v_t_2431 = heff_intSub(heff_take_field(v_s_2416, 5), MK_INT(1LL));
            v_s_2432 = ({ V rv_1 = v_t_2423; V rv_2 = v_t_2428; V rv_3 = v_t_2429; V rv_4 = v_t_2430; V rv_5 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_s_2416, 1ULL, 6, shape_supply__consumers__producers__made__fresh__left, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
          }
        }
        break;
      }
      default: heff_nomatch(v_x3_2415);
      }
      V v_x_2437;
      switch (heff_tag_of(v_x_2410)) {
      case TAG_Nothing: {
        heff_drop_rec(v_cs_241, 5);
        heff_drop(v_args_244);
        heff_drop(v_bs_245);
        v_x_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2433 = heff_field(v_x_2410, 0);
        V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
        V v_k_2434 = heff_get_n(v_x_2433, 0, 3);
        if (heff_strEq_c_lent(v_k_2434, ((V)&g_heff_2ecompile_2efuse_2efuseNew_str2), 2)) {
          heff_drop_rec(v_cs_241, 5);
          heff_drop(v_args_244);
          heff_drop(v_bs_245);
          heff_drop_cell(v_ru_24x_2410_24Just, 1);
          heff_drop(v_k_2434);
          v_x_2437 = NTAG(TAG_Nothing);
        } else {
          V v_t_2435 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_bs_245, heff_get_n(v_cs_241, 1, 5), v_args_244));
          V v_t_2436 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_k_2434}), v_t_2435});
          v_x_2437 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Just, 1, (V[]){v_t_2436});
        }
        break;
      }
      default: heff_nomatch(v_x_2410);
      }
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2437, v_s_2432});
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
}
V g_heff_2ecompile_2efuse_2efuseNew_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2efuseNew(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugArgs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugArgs_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2eplugArgs_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugArgs_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugArgs_lam3(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugArgs_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugArgs_lam3, 1, 0};
Clo g_heff_2ecompile_2efuse_2eplugArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugArgs_entry, 4, 0};

V g_heff_2ecompile_2efuse_2eplugArgs(V v_sg_240, V v_k_241, V v_pl_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugArgs_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x_247 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
    V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(v_x_247, MK_INT(0LL), v_t_248));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
    V v_t_2411 = ({ V a_0 = v_x_247; V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_247); r_; });
    V v_x_2412 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_249, v_t_2411}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_2412)) {
      heff_drop(v_sg_240);
      V v_m_2413 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_a_245}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugArgs_lam1, 1, 2, (V[]){v_m_2413, v_rest_246});
    } else {
      V v_t_2420 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), heff_dup(v_a_245)));
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_m_2421 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_rest_246));
        return heff_clo_n(g_heff_2ecompile_2efuse_2eplugArgs_lam2, 1, 2, (V[]){v_m_2421, v_a_245});
      } else {
        heff_drop(v_sg_240);
        heff_drop_rec(v_k_241, 1);
        heff_drop_rec(v_pl_242, 3);
        heff_drop(v_a_245);
        heff_drop(v_rest_246);
        heff_drop(v_t_2420);
        return ((V)&g_heff_2ecompile_2efuse_2eplugArgs_lam3_clo);
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2eplugArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eplugArgs(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_244});
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam1(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2419;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      heff_drop(v_rest_246);
      v_t_2419 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2418 = heff_field(v_x_2416, 0);
      V v_ru_24x_2416_24Just = heff_take_reuse_n(v_x_2416, 1ULL, 1);
      v_t_2419 = heff_tag_at_n(v_ru_24x_2416_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2418, v_rest_246})});
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    return heff_tag_re_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2419, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam2(V self, V *args) {
  V v_s_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  V v_a_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2422}));
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_s_2425 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2427;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_Nothing: {
      heff_drop(v_a_245);
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_args_2426 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24Just = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2424_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_args_2426})});
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    return heff_tag_re_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2427, v_s_2425});
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam3(V self, V *args) {
  V v_s_2428 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2428});
}
Clo g_heff_2ecompile_2efuse_2econsumerCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econsumerCall_entry, 7, 0};

V g_heff_2ecompile_2efuse_2econsumerCall(V v_sg_240, V v_k_241, V v_pl_242, V v_g_243, V v_args_244, V v_x6_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    V v_m_247 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_244));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_246}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        heff_drop(v_g_243);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2411 = heff_field(v_x_249, 0);
        V v_ru_24x_249_24Just = heff_take_reuse_n(v_x_249, 1ULL, 1);
        V v_t_2412 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_243}), v_x_2411});
        v_t_2413 = heff_tag_at_n(v_ru_24x_249_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      return heff_tag_re_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2413, v_s_2410});
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  case TAG_Just: {
    V v_cs_2414 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(heff_rfield(v_pl_242, 0))}));
    V v_t_2416 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_2414, 1, 5), v_args_244));
    V v_t_2417 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_2415; V a_2 = v_t_2416; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_k_241);
      heff_drop(v_t_2417);
      V v_p_2418 = heff_take_field(v_pl_242, 1);
      V v_t_2419 = (g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(v_ru_24x6_245_24Just, heff_rfield(v_z_246, 1), v_g_243));
      V v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_z_246, 2), v_p_2418));
      return ({ V a_0 = v_sg_240; V a_1 = v_g_243; V a_2 = v_args_244; V a_3 = v_p_2418; V a_4 = heff_get_n(v_pl_242, 2, 3); V a_5 = v_t_2419; V a_6 = v_t_2420; V a_7 = v_z_246; V r_ = (g_heff_2ecompile_2efuse_2efuseKnown(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2419); heff_drop(v_t_2420); r_; });
    } else {
      heff_drop(v_t_2417);
      V v_m_2421 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_244));
      V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_z_246}));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        V v_t_2427;
        switch (heff_tag_of(v_x_2423)) {
        case TAG_Nothing: {
          heff_drop(v_g_243);
          heff_drop_cell(v_ru_24x6_245_24Just, 1);
          v_t_2427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2425 = heff_field(v_x_2423, 0);
          V v_ru_24x_2423_24Just = heff_take_reuse_n(v_x_2423, 1ULL, 1);
          V v_t_2426 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x_2423_24Just, TAG_EGlobal, 1, (V[]){v_g_243}), v_x_2425});
          v_t_2427 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_Just, 1, (V[]){v_t_2426});
          break;
        }
        default: heff_nomatch(v_x_2423);
        }
        return heff_tag_re_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2427, v_s_2424});
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2efuse_2econsumerCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2econsumerCall(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2efuse_2eplugGo_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam1(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam1, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam3(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam4(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam4, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam5(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam6(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam7(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam7, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam8(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam9(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam10(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam10, 1, 0};
Clo g_heff_2ecompile_2efuse_2eplugGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_entry, 4, 0};

V g_heff_2ecompile_2efuse_2eplugGo(V v_sg_240, V v_k_241, V v_pl_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EApp: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_args_245 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EGlobal: {
      V v_g_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam0, 1, 5, (V[]){v_g_246, v_sg_240, v_k_241, v_pl_242, v_args_245});
    }
    default: {
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_x41_244);
      heff_drop(v_args_245);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam1_clo);
    }
    }
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_x4_243, 0);
    V v_a_2411 = heff_field(v_x4_243, 1);
    V v_b_2412 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_x_2413 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2411), NTAG(TAG_Nil)});
    V v_t_2415 = (g_heff_2ecompile_2eir_2ecountW(v_x_2413, MK_INT(0LL), v_t_2414));
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2411), NTAG(TAG_Nil)});
    V v_t_2417 = ({ V a_0 = v_x_2413; V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2413); r_; });
    V v_x_2418 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2415, v_t_2417}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_2418)) {
      heff_drop(v_sg_240);
      V v_m_2419 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_a_2411}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam2, 1, 3, (V[]){v_m_2419, v_y_2410, v_b_2412});
    } else {
      V v_t_2426 = (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, heff_dup(v_a_2411)));
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_m_2427 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_b_2412}));
        return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam3, 1, 3, (V[]){v_m_2427, v_y_2410, v_a_2411});
      } else {
        heff_drop_rec(v_k_241, 1);
        heff_drop_rec(v_pl_242, 3);
        heff_drop(v_y_2410);
        heff_drop(v_a_2411);
        heff_drop(v_b_2412);
        heff_drop(v_t_2426);
        return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam4_clo);
      }
    }
  }
  case TAG_ETag: {
    V v_t_2435 = heff_field(v_x4_243, 0);
    V v_args_2436 = heff_field(v_x4_243, 1);
    V v_ts_2437 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_m_2438 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_2436));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam5, 1, 3, (V[]){v_m_2438, v_t_2435, v_ts_2437});
  }
  case TAG_EMatch: {
    V v_s_2445 = heff_field(v_x4_243, 0);
    V v_arms_2446 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EMatch = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_sg_240);
    V v_x_2447 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_2448 = heff_tag_at_n(v_ru_24x4_243_24EMatch, TAG_Cons, 2, (V[]){heff_dup(v_s_2445), NTAG(TAG_Nil)});
    V v_t_2449 = (g_heff_2ecompile_2eir_2ecountW(v_x_2447, MK_INT(0LL), v_t_2448));
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_s_2445), NTAG(TAG_Nil)});
    V v_t_2451 = ({ V a_0 = v_x_2447; V a_1 = v_t_2450; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2447); r_; });
    V v_x_2452 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2449, v_t_2451}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_2452)) {
      V v_m_2453 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_s_2445}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam6, 1, 2, (V[]){v_m_2453, v_arms_2446});
    } else {
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_s_2445);
      heff_drop(v_arms_2446);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam7_clo);
    }
  }
  case TAG_EPrimCall: {
    V v_q_2461 = heff_field(v_x4_243, 0);
    V v_args_2462 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_m_2463 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_2462));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam8, 1, 2, (V[]){v_m_2463, v_q_2461});
  }
  case TAG_ECall: {
    V v_g_2470 = heff_field(v_x4_243, 0);
    V v_args_2471 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam9, 1, 5, (V[]){v_g_2470, v_sg_240, v_k_241, v_pl_242, v_args_2471});
  }
  default: {
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    heff_drop(v_x4_243);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam10_clo);
  }
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eplugGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2eplugGo_lam0(V self, V *args) {
  V v_s_247 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_pl_242 = heff_env(self)[3];
  V v_args_245 = heff_env(self)[4];
  V v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_s_247, 1), v_g_246));
  heff_clo_take(self, 5);
  return (g_heff_2ecompile_2efuse_2econsumerCall(v_sg_240, v_k_241, v_pl_242, v_g_246, v_args_245, v_t_248, v_s_247));
}
V g_heff_2ecompile_2efuse_2eplugGo_lam1(V self, V *args) {
  V v_s_249 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_249});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam2(V self, V *args) {
  V v_s_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_y_2410 = heff_env(self)[1];
  V v_b_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_s_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_s_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_2422)) {
    case TAG_Nothing: {
      heff_drop(v_y_2410);
      heff_drop(v_b_2412);
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2424 = heff_field(v_x_2422, 0);
      V v_ru_24x_2422_24Just = heff_take_reuse_n(v_x_2422, 1ULL, 1);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2422_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2410, v_x_2424, v_b_2412})});
      break;
    }
    default: heff_nomatch(v_x_2422);
    }
    return heff_tag_re_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2425, v_s_2423});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam3(V self, V *args) {
  V v_s_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_y_2410 = heff_env(self)[1];
  V v_a_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_s_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_t_2433;
    switch (heff_tag_of(v_x_2430)) {
    case TAG_Nothing: {
      heff_drop(v_y_2410);
      heff_drop(v_a_2411);
      v_t_2433 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_x_2430, 0);
      V v_ru_24x_2430_24Just = heff_take_reuse_n(v_x_2430, 1ULL, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24x_2430_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2410, v_a_2411, v_x_2432})});
      break;
    }
    default: heff_nomatch(v_x_2430);
    }
    return heff_tag_re_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2433, v_s_2431});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam4(V self, V *args) {
  V v_s_2434 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2434});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam5(V self, V *args) {
  V v_s_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  V v_t_2435 = heff_env(self)[1];
  V v_ts_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2440 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_s_2439}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_s_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_x_2441)) {
    case TAG_Nothing: {
      heff_drop(v_t_2435);
      heff_drop(v_ts_2437);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2443 = heff_field(v_x_2441, 0);
      V v_ru_24x_2441_24Just = heff_take_reuse_n(v_x_2441, 1ULL, 1);
      v_t_2444 = heff_tag_at_n(v_ru_24x_2441_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2435, v_x_2443, v_ts_2437})});
      break;
    }
    default: heff_nomatch(v_x_2441);
    }
    return heff_tag_re_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2444, v_s_2442});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam6(V self, V *args) {
  V v_s_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_arms_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_s_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_s_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    V v_t_2459;
    switch (heff_tag_of(v_x_2456)) {
    case TAG_Nothing: {
      heff_drop(v_arms_2446);
      v_t_2459 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2458 = heff_field(v_x_2456, 0);
      V v_ru_24x_2456_24Just = heff_take_reuse_n(v_x_2456, 1ULL, 1);
      v_t_2459 = heff_tag_at_n(v_ru_24x_2456_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2458, v_arms_2446})});
      break;
    }
    default: heff_nomatch(v_x_2456);
    }
    return heff_tag_re_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2459, v_s_2457});
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam7(V self, V *args) {
  V v_s_2460 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2460});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam8(V self, V *args) {
  V v_s_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_q_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_s_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_s_2467 = heff_field(v_x2_2465, 1);
    V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
    V v_t_2469;
    switch (heff_tag_of(v_x_2466)) {
    case TAG_Nothing: {
      heff_drop(v_q_2461);
      v_t_2469 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2468 = heff_field(v_x_2466, 0);
      V v_ru_24x_2466_24Just = heff_take_reuse_n(v_x_2466, 1ULL, 1);
      v_t_2469 = heff_tag_at_n(v_ru_24x_2466_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_q_2461, v_x_2468})});
      break;
    }
    default: heff_nomatch(v_x_2466);
    }
    return heff_tag_re_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2469, v_s_2467});
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam9(V self, V *args) {
  V v_s_2472 = args[0];
  V v_g_2470 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_pl_242 = heff_env(self)[3];
  V v_args_2471 = heff_env(self)[4];
  V v_t_2473 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_s_2472, 1), v_g_2470));
  heff_clo_take(self, 5);
  return (g_heff_2ecompile_2efuse_2econsumerCall(v_sg_240, v_k_241, v_pl_242, v_g_2470, v_args_2471, v_t_2473, v_s_2472));
}
V g_heff_2ecompile_2efuse_2eplugGo_lam10(V self, V *args) {
  V v_s_2474 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2474});
}
V g_heff_2ecompile_2efuse_2eplugK_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2ecompile_2efuse_2eplugK_24cpr(V v_sg_240) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2ecompile_2efuse_2eplugK_24cpr_lam0, 2, 1, (V[]){v_sg_240})}});
}
V g_heff_2ecompile_2efuse_2eplugK_24cpr_lam0(V self, V *args) {
  V v_pl_241 = args[0];
  V v_e_242 = args[1];
  V v_sg_240 = heff_env(self)[0];
  V v_t_243 = (g_heff_2ecompile_2efuse_2eplugK(heff_dup(v_sg_240)));
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2efuse_2eplugGo(v_sg_240, v_t_243, v_pl_241, v_e_242));
}
Clo g_heff_2ecompile_2efuse_2eplugK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugK_entry, 1, 0};

V g_heff_2ecompile_2efuse_2eplugK(V v_sg_240) {
top: ;
  HeffT1 v_t_241 = (g_heff_2ecompile_2efuse_2eplugK_24cpr(v_sg_240));
  {
    V v_field_242 = v_t_241.f[0];
    return heff_rec_n(1, shape_go, (V[]){v_field_242});
  }
}
V g_heff_2ecompile_2efuse_2eplugK_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eplugK(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2efuse_2earmGiven_24tok3_str0, 0, "");
Clo g_heff_2ecompile_2efuse_2earmGiven_24tok3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2earmGiven_24tok3_entry, 7, 0};

V g_heff_2ecompile_2efuse_2earmGiven_24tok3(V v_tok_240, V v_fu_241, V v_t_242, V v_hs_243, V v_ts_244, V v_e_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_e_245)) {
  case TAG_ELam: {
    V v_vs_247 = heff_field(v_e_245, 0);
    V v_b_248 = heff_field(v_e_245, 1);
    V v_ru_24e_245_24ELam = heff_take_reuse_n(v_e_245, 3ULL, 2);
    V v_x_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_247));
    V v_y_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_hs_243));
    if (!heff_intEq_c_lent(v_x_249, v_y_2410, 0)) {
      heff_drop(v_vs_247);
      heff_drop(v_b_248);
      heff_drop(v_x_249);
      heff_drop(v_y_2410);
      V v_t_2411 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_241, 2), heff_tag_at_n(v_tok_240, TAG_ETag, 3, (V[]){v_t_242, v_hs_243, v_ts_244}), heff_take_field(v_fu_241, 8)));
      V v_t_2412 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_get_n(v_fu_241, 0, 9)});
      V v_x_2413 = heff_tag_at_n(v_ru_24e_245_24ELam, TAG_EApp, 2, (V[]){v_t_2412, v_t_2411});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_z_246});
    } else {
      heff_drop_cell(v_tok_240, 3);
      heff_drop(v_ts_244);
      heff_drop(v_x_249);
      heff_drop(v_y_2410);
      V v_t_2414 = ({ V a_0 = v_t_242; V a_1 = heff_rfield(v_fu_241, 4); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_t_242); r_; });
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_x1_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
        V v_t_2418;
        switch (heff_tag_of(v_x1_2415)) {
        case TAG_Nil: {
          v_t_2418 = ((V)&g_heff_2ecompile_2efuse_2earmGiven_24tok3_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2416 = heff_field(v_x1_2415, 0);
          heff_take_n(v_x1_2415, 1ULL, 2);
          v_t_2418 = v_x_2416;
          break;
        }
        default: heff_nomatch(v_x1_2415);
        }
        V v_x1_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_hs_243)));
        V v_t_2422;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_Nil: {
          v_t_2422 = heff_tag_n(TAG_EInt, 1, (V[]){MK_INT(0LL)});
          break;
        }
        case TAG_Cons: {
          V v_x_2420 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 2);
          v_t_2422 = v_x_2420;
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        V v_m_2423 = (g_heff_2ecompile_2efuse_2erecall(v_fu_241, v_t_2418, v_t_2422, v_b_248));
        V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_z_246}));
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_s_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          V v_t_2427 = (g_heff_2ecompile_2efuse_2einitF(v_vs_247));
          V v_t_2428 = (g_heff_2ecompile_2efuse_2einitF(v_hs_243));
          V v_x_2429 = ({ V a_0 = v_t_2427; V a_1 = v_t_2428; V a_2 = v_x_2425; V r_ = (g_heff_2ecompile_2efuse_2ebindsOf(a_0, a_1, a_2)); heff_drop(v_t_2427); heff_drop(v_t_2428); r_; });
          return heff_tag_at_n(v_ru_24e_245_24ELam, TAG_MkPair, 2, (V[]){v_x_2429, v_s_2426});
        }
        default: return heff_nomatch(v_x2_2424);
        }
      } else {
        heff_drop_rec(v_fu_241, 9);
        heff_drop(v_t_2414);
        V v_x_2430 = ({ V a_0 = v_vs_247; V a_1 = v_hs_243; V a_2 = v_b_248; V r_ = (g_heff_2ecompile_2efuse_2ebindsOf(a_0, a_1, a_2)); heff_drop(v_vs_247); heff_drop(v_hs_243); r_; });
        return heff_tag_at_n(v_ru_24e_245_24ELam, TAG_MkPair, 2, (V[]){v_x_2430, v_z_246});
      }
    }
  }
  default: {
    heff_drop(v_e_245);
    V v_t_2431 = (g_heff_2ecompile_2efuse_2einsertAt(heff_take_field(v_fu_241, 2), heff_tag_at_n(v_tok_240, TAG_ETag, 3, (V[]){v_t_242, v_hs_243, v_ts_244}), heff_take_field(v_fu_241, 8)));
    V v_t_2432 = heff_tag_n(TAG_EGlobal, 1, (V[]){heff_get_n(v_fu_241, 0, 9)});
    V v_x_2433 = heff_tag_n(TAG_EApp, 2, (V[]){v_t_2432, v_t_2431});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2433, v_z_246});
  }
  }
}
V g_heff_2ecompile_2efuse_2earmGiven_24tok3_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2earmGiven_24tok3(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2efuse_2efuseOn_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseOn_24tok2_entry, 6, 0};

V g_heff_2ecompile_2efuse_2efuseOn_24tok2(V v_tok_240, V v_sg_241, V v_c_242, V v_args_243, V v_x4_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nothing: {
    heff_drop(v_sg_241);
    heff_drop(v_c_242);
    heff_drop(v_args_243);
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_245});
  }
  case TAG_Just: {
    V v_e_246 = heff_field(v_x4_244, 0);
    HeffT3 v_t_247 = (g_heff_2ecompile_2efuse_2eglobalCall_24cpr(v_e_246));
    {
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop_cell(v_tok_240, 2);
        V v_p_2411 = v_field_249;
        V v_bs_2412 = v_field_2410;
        V v_t_2413 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_z_245, 1), v_c_242));
        V v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_z_245, 2), v_p_2411));
        return ({ V a_0 = v_sg_241; V a_1 = v_c_242; V a_2 = v_args_243; V a_3 = v_p_2411; V a_4 = v_bs_2412; V a_5 = v_t_2413; V a_6 = v_t_2414; V a_7 = v_z_245; V r_ = (g_heff_2ecompile_2efuse_2efuseKnown(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2413); heff_drop(v_t_2414); r_; });
      } else {
        heff_drop(v_sg_241);
        heff_drop(v_c_242);
        heff_drop(v_args_243);
        heff_drop(v_field_249);
        heff_drop(v_field_2410);
        return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_245});
      }
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2ecompile_2efuse_2efuseOn_24tok2_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2efuse_2efuseOn_24tok2(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}