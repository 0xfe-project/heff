// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_Tip 31527
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_bs 9912
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_fresh 299054408
#define LBL_go 10063
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_p 330
#define LBL_producers 572620898
#define LBL_rest 9992347
#define LBL_supply 1056026650
#define LBL_underLam 296337946
#define LBL_x 338
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
V g_heff_2ecompile_2efuse_2eatEnds(V, V);
V g_heff_2ecompile_2efuse_2eatEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eatEnds_clo;
V g_heff_2ecompile_2efuse_2ebindsOf(V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_clo;
V g_heff_2ecompile_2efuse_2ebindsOf_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ebindsOf_24dps_clo;
HeffT2 g_heff_2ecompile_2efuse_2ecallOf_24cpr(V, V, V);
V g_heff_2ecompile_2efuse_2econsumerCall(V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2econsumerCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerCall_clo;
HeffT2 g_heff_2ecompile_2efuse_2econsumerOf_24cpr(V, V);
V g_heff_2ecompile_2efuse_2eelemF(V, V);
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eelemF_clo;
V g_heff_2ecompile_2efuse_2eendAt(V, V);
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eendAt_clo;
HeffT2 g_heff_2ecompile_2efuse_2efreshF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2efuseKnown(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseKnown_clo;
V g_heff_2ecompile_2efuse_2efuseKnown_24tok2(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseKnown_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseKnown_24tok2_clo;
V g_heff_2ecompile_2efuse_2einsertAt(V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_clo;
V g_heff_2ecompile_2efuse_2einsertAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2einsertAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einsertAt_24dps_clo;
V g_heff_2ecompile_2efuse_2eisVar(V, V);
V g_heff_2ecompile_2efuse_2eisVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eisVar_clo;
HeffT2 g_heff_2ecompile_2efuse_2elastF_24cpr(V);
V g_heff_2ecompile_2efuse_2enthF(V, V);
V g_heff_2ecompile_2efuse_2enthF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2enthF_clo;
HeffT2 g_heff_2ecompile_2efuse_2enthF_24cpr(V, V);
V g_heff_2ecompile_2efuse_2eonceIn(V, V);
V g_heff_2ecompile_2efuse_2eonceIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eonceIn_clo;
V g_heff_2ecompile_2efuse_2eplugArgs(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugArgs_clo;
V g_heff_2ecompile_2efuse_2eplugGo(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugGo_clo;
HeffT2 g_heff_2ecompile_2efuse_2eproducerOf_24cpr(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_clo;
V g_heff_2ecompile_2efuse_2esameGo(V, V);
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esameGo_clo;
V g_heff_2ecompile_2efuse_2eselfArgs(V, V, V);
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfArgs_clo;
V g_heff_2ecompile_2efuse_2eselfOut(V, V);
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_clo;
V g_heff_2ecompile_2efuse_2eselfOut_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2eselfOut_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_24dps_clo;
V g_heff_2ecompile_2efuse_2ewithMade(V, V, V, V);
V g_heff_2ecompile_2efuse_2ewithMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ewithMade_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1229912102x1467950109(V, V);
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2emaybe(V, V, V);
V g_prelude_2emaybe_entry(V self, V *a);
extern Clo g_prelude_2emaybe_clo;
V g_prelude_2etraverse_24s545943161x1483966866(V, V);
V g_prelude_2etraverse_24s545943161x1483966866_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s545943161x1483966866_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2efuse_2eelemF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eelemF_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eelemF(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2eelemF(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_heff_2ecompile_2efuse_2enthF_24cpr(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2efuse_2einsertAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einsertAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2einsertAt(V v_i_240, V v_y_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244})});
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2efuse_2einsertAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_y_241, v_xs_244, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2einsertAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einsertAt(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2efuse_2elastF_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_241}});
    }
    case TAG_Cons: {
      heff_drop(v_x_241);
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2efuse_2eonceIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eonceIn_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eonceIn(V v_x_240, V v_e_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_241), NTAG(TAG_Nil)});
  V v_t_243 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_241), NTAG(TAG_Nil)});
  V v_t_245 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_244));
  V v_t_246 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_243, v_t_245}), 0, 2);
  if (heff_intEq_c(v_t_246, MK_INT(1LL))) {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_241), NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_247));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_241, NTAG(TAG_Nil)});
    V v_t_2410 = (g_heff_2ecompile_2eir_2elamW(v_x_240, v_t_249));
    V v_x1_2411 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_248, v_t_2410}), 1, 2);
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
    heff_drop(v_x1_2411);
    return v_ret_24bool;
  } else {
    heff_drop(v_e_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2efuse_2eonceIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2efuse_2eonceIn(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2efuse_2ecallOf_24cpr(V v_g_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_args_248 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      heff_take_n(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EGlobal: {
      V v_h_2410 = heff_field(v_x31_247, 0);
      heff_take_n(v_x31_247, 1ULL, 1);
      if ((heff_strEq_c_lent(v_g_240, v_h_2410, 0) && ({ V v_t_2481 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_248)); int c_ = heff_intEq_c_lent(v_t_2481, v_n_241, 0); heff_drop(v_t_2481); c_; }))) {
        heff_drop(v_n_241);
        heff_drop(v_h_2410);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_args_248}});
      } else {
        heff_drop(v_n_241);
        heff_drop(v_args_248);
        heff_drop(v_h_2410);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EApp: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ELet: {
      heff_take_n(v_x31_247, 0ULL, 3);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ERecord: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EProj: {
      heff_take_n(v_x31_247, 0ULL, 4);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ETag: {
      heff_take_n(v_x31_247, 0ULL, 3);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EMatch: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ECall: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EInt: {
      heff_take_n(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EStr: {
      heff_take_n(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EAbandon: {
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EBool: {
      heff_take_n(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_ESet: {
      heff_take_n(v_x31_247, 0ULL, 3);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EValues: {
      heff_take_n(v_x31_247, 0ULL, 1);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_EFix: {
      heff_take_n(v_x31_247, 0ULL, 2);
      heff_drop(v_n_241);
      heff_drop(v_args_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
    }
  }
  case TAG_ELet: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_x3_242, 0ULL, 4);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    V v_h_2465 = heff_field(v_x3_242, 0);
    V v_args_2466 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    if ((heff_strEq_c_lent(v_g_240, v_h_2465, 0) && ({ V v_t_2482 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2466)); int c_ = heff_intEq_c_lent(v_t_2482, v_n_241, 0); heff_drop(v_t_2482); c_; }))) {
      heff_drop(v_n_241);
      heff_drop(v_h_2465);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_args_2466}});
    } else {
      heff_drop(v_n_241);
      heff_drop(v_h_2465);
      heff_drop(v_args_2466);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_n_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2efuse_2esameGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esameGo_entry, 2, 0};

V g_heff_2ecompile_2efuse_2esameGo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_x1_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x1_240)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_x1_240, 0);
      V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
      switch (heff_tag_of(v_x21_242)) {
      case TAG_Nothing: {
        heff_drop(v_a_244);
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_b_245 = heff_field(v_x21_242, 0);
        if (heff_intEq_c_lent(v_a_244, v_b_245, 0)) {
          V t_0 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Just, 1, (V[]){v_a_244});
          V t_1 = v_rest_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_a_244);
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_x21_242);
      }
    }
    default: return heff_nomatch(v_x1_240);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2esameGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2esameGo(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_str0, 5, "$self");
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_str1, 5, "$self");
V g_heff_2ecompile_2efuse_2eselfOut_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfOut_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfOut_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eselfOut(V v_me_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_244, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2efuse_2eselfOut_24dps(v_me_240, v_b_245, heff_dup(v_cell_246), MK_INT(1LL)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  case TAG_EApp: {
    V v_x21_248 = heff_field(v_x2_241, 0);
    V v_args_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_EVar: {
      V v_t_2411 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2413 = (g_list_2emap(v_t_2412, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2411, v_t_2413});
    }
    case TAG_EGlobal: {
      V v_g_2414 = heff_field(v_x21_248, 0);
      heff_take_n(v_x21_248, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_g_2414), heff_dup(heff_rfield(v_me_240, 0)))) {
        V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_249));
        if (heff_intEq_c(v_t_2415, heff_dup(heff_rfield(v_me_240, 1)))) {
          V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(heff_rfield(v_me_240, 3))}));
          V v_t_2417 = (g_heff_2ecompile_2efuse_2enthF(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_args_249)));
          V v_t_2418 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_2416; V a_2 = v_t_2417; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
          if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x2_241_24EApp, 2);
            heff_drop(v_g_2414);
            heff_drop(v_t_2418);
            V v_t_2419 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_args_249)));
            V v_t_2420 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_args_249));
            return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_str0), v_t_2419, v_t_2420});
          } else {
            heff_drop(v_t_2418);
            V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
            V v_t_2422 = (g_list_2emap(v_t_2421, v_args_249));
            return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_t_2422});
          }
        } else {
          V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
          V v_t_2424 = (g_list_2emap(v_t_2423, v_args_249));
          return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_t_2424});
        }
      } else {
        V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
        V v_t_2426 = (g_list_2emap(v_t_2425, v_args_249));
        return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2414}), v_t_2426});
      }
    }
    case TAG_ELam: {
      V v_t_2429 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2431 = (g_list_2emap(v_t_2430, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2429, v_t_2431});
    }
    case TAG_EApp: {
      V v_t_2434 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2435 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2436 = (g_list_2emap(v_t_2435, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2434, v_t_2436});
    }
    case TAG_ELet: {
      V v_t_2440 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2442 = (g_list_2emap(v_t_2441, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2440, v_t_2442});
    }
    case TAG_ERecord: {
      V v_t_2445 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2447 = (g_list_2emap(v_t_2446, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2445, v_t_2447});
    }
    case TAG_EProj: {
      V v_t_2452 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2454 = (g_list_2emap(v_t_2453, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2452, v_t_2454});
    }
    case TAG_ETag: {
      V v_t_2458 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2459 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2460 = (g_list_2emap(v_t_2459, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2458, v_t_2460});
    }
    case TAG_EMatch: {
      V v_t_2463 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2465 = (g_list_2emap(v_t_2464, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2463, v_t_2465});
    }
    case TAG_EPrim: {
      V v_t_2467 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2469 = (g_list_2emap(v_t_2468, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2467, v_t_2469});
    }
    case TAG_EPrimCall: {
      V v_t_2472 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2474 = (g_list_2emap(v_t_2473, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2472, v_t_2474});
    }
    case TAG_ECall: {
      V v_t_2477 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2479 = (g_list_2emap(v_t_2478, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2477, v_t_2479});
    }
    case TAG_EInt: {
      V v_t_2481 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2482 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2483 = (g_list_2emap(v_t_2482, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2481, v_t_2483});
    }
    case TAG_EFloat: {
      V v_t_2485 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2487 = (g_list_2emap(v_t_2486, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2485, v_t_2487});
    }
    case TAG_EStr: {
      V v_t_2489 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2490 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2491 = (g_list_2emap(v_t_2490, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2489, v_t_2491});
    }
    case TAG_EBytes: {
      V v_t_2493 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2494 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2495 = (g_list_2emap(v_t_2494, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2493, v_t_2495});
    }
    case TAG_EFixed: {
      V v_t_2498 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24100 = (g_list_2emap(v_t_2499, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2498, v_t_24100});
    }
    case TAG_EFloat32: {
      V v_t_24102 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_24103 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24104 = (g_list_2emap(v_t_24103, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_24102, v_t_24104});
    }
    case TAG_EAbandon: {
      V v_t_24105 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_24106 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24107 = (g_list_2emap(v_t_24106, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_24105, v_t_24107});
    }
    case TAG_EBool: {
      V v_t_24109 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_24110 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24111 = (g_list_2emap(v_t_24110, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_24109, v_t_24111});
    }
    case TAG_ESet: {
      V v_t_24115 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_24116 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24117 = (g_list_2emap(v_t_24116, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_24115, v_t_24117});
    }
    case TAG_EValues: {
      V v_t_24119 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_24120 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24121 = (g_list_2emap(v_t_24120, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_24119, v_t_24121});
    }
    case TAG_EFix: {
      V v_t_24124 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_x21_248));
      V v_t_24125 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24126 = (g_list_2emap(v_t_24125, v_args_249));
      return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_24124, v_t_24126});
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  case TAG_ELet: {
    V v_x_24127 = heff_field(v_x2_241, 0);
    V v_a_24128 = heff_field(v_x2_241, 1);
    V v_b_24129 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_24130 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_a_24128));
    V v_cell_24131 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_24127, v_t_24130, heff_hole()});
    V v_u_24132 = (g_heff_2ecompile_2efuse_2eselfOut_24dps(v_me_240, v_b_24129, heff_dup(v_cell_24131), MK_INT(2LL)));
    heff_drop(v_u_24132);
    return v_cell_24131;
  }
  case TAG_ERecord: {
    V v_fs_24133 = heff_field(v_x2_241, 0);
    V v_ts_24134 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24143 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_lam0, 1, 1, (V[]){v_me_240}), v_fs_24133));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_24143, v_ts_24134});
  }
  case TAG_EProj: {
    V v_e_24144 = heff_field(v_x2_241, 0);
    V v_l_24145 = heff_field(v_x2_241, 1);
    V v_sh_24146 = heff_field(v_x2_241, 2);
    V v_t_24147 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_24148 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_e_24144));
    return heff_tag_at_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, (V[]){v_t_24148, v_l_24145, v_sh_24146, v_t_24147});
  }
  case TAG_ETag: {
    V v_t_24149 = heff_field(v_x2_241, 0);
    V v_args_24150 = heff_field(v_x2_241, 1);
    V v_ts_24151 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_24152 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24153 = (g_list_2emap(v_t_24152, v_args_24150));
    return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, (V[]){v_t_24149, v_t_24153, v_ts_24151});
  }
  case TAG_EMatch: {
    V v_s_24154 = heff_field(v_x2_241, 0);
    V v_arms_24155 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24156 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_s_24154));
    V v_f_24157 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24163 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_lam1, 1, 1, (V[]){v_f_24157}), v_arms_24155));
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_24156, v_t_24163});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_24165 = heff_field(v_x2_241, 0);
    V v_args_24166 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24167 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24168 = (g_list_2emap(v_t_24167, v_args_24166));
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_24165, v_t_24168});
  }
  case TAG_ECall: {
    V v_g_24169 = heff_field(v_x2_241, 0);
    V v_args_24170 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_24169), heff_dup(heff_rfield(v_me_240, 0)))) {
      V v_t_24171 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_24170));
      if (heff_intEq_c(v_t_24171, heff_dup(heff_rfield(v_me_240, 1)))) {
        V v_t_24172 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(heff_rfield(v_me_240, 3))}));
        V v_t_24173 = (g_heff_2ecompile_2efuse_2enthF(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_args_24170)));
        V v_t_24174 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_24172; V a_2 = v_t_24173; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_24173); r_; });
        if ((heff_dup(v_t_24174) == NTAG(TAG_True))) {
          heff_drop(v_g_24169);
          heff_drop_cell(v_ru_24x2_241_24ECall, 2);
          heff_drop(v_t_24174);
          V v_t_24175 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_args_24170)));
          V v_t_24176 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_args_24170));
          return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_str1), v_t_24175, v_t_24176});
        } else {
          heff_drop(v_t_24174);
          V v_t_24177 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
          V v_t_24178 = (g_list_2emap(v_t_24177, v_args_24170));
          return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_24169, v_t_24178});
        }
      } else {
        V v_t_24179 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
        V v_t_24180 = (g_list_2emap(v_t_24179, v_args_24170));
        return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_24169, v_t_24180});
      }
    } else {
      V v_t_24181 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24182 = (g_list_2emap(v_t_24181, v_args_24170));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_24169, v_t_24182});
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  case TAG_EBool: {
    V v_c_24190 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EBool = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24191 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24192 = (g_heff_2ecompile_2eir_2econdMap(v_t_24191, v_c_24190));
    return heff_tag_at_n(v_ru_24x2_241_24EBool, TAG_EBool, 1, (V[]){v_t_24192});
  }
  case TAG_ESet: {
    V v_xs_24193 = heff_field(v_x2_241, 0);
    V v_a_24194 = heff_field(v_x2_241, 1);
    V v_b_24195 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ESet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_24196 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_a_24194));
    V v_cell_24197 = heff_tag_at_n(v_ru_24x2_241_24ESet, TAG_ESet, 3, (V[]){v_xs_24193, v_t_24196, heff_hole()});
    V v_u_24198 = (g_heff_2ecompile_2efuse_2eselfOut_24dps(v_me_240, v_b_24195, heff_dup(v_cell_24197), MK_INT(2LL)));
    heff_drop(v_u_24198);
    return v_cell_24197;
  }
  case TAG_EValues: {
    V v_es_24199 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EValues = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24200 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24201 = (g_list_2emap(v_t_24200, v_es_24199));
    return heff_tag_at_n(v_ru_24x2_241_24EValues, TAG_EValues, 1, (V[]){v_t_24201});
  }
  case TAG_EFix: {
    heff_drop_rec(v_me_240, 4);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eselfOut(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eselfOut_lam0(V self, V *args) {
  V v_p_24135 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24138;
  switch (heff_tag_of(v_p_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_dup(heff_field(v_p_24135, 0));
    v_t_24138 = v_x_24136;
    break;
  }
  default: heff_nomatch(v_p_24135);
  }
  V v_t_24141;
  switch (heff_tag_of(v_p_24135)) {
  case TAG_MkPair: {
    V v_y_24140 = heff_field(v_p_24135, 1);
    heff_take_n(v_p_24135, 2ULL, 2);
    v_t_24141 = v_y_24140;
    break;
  }
  default: heff_nomatch(v_p_24135);
  }
  V v_t_24142 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_t_24141));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24138, v_t_24142});
}
V g_heff_2ecompile_2efuse_2eselfOut_lam1(V self, V *args) {
  V v_x2_24158 = args[0];
  V v_f_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24158)) {
  case TAG_MkArm: {
    V v_t_24159 = heff_field(v_x2_24158, 0);
    V v_vs_24160 = heff_field(v_x2_24158, 1);
    V v_b_24161 = heff_field(v_x2_24158, 2);
    V v_ru_24x2_24158_24MkArm = heff_take_reuse_n(v_x2_24158, 7ULL, 3);
    V v_t_24162 = heff_tr(heff_call(v_f_24157, 1, (V[]){v_b_24161}));
    return heff_tag_at_n(v_ru_24x2_24158_24MkArm, TAG_MkArm, 3, (V[]){v_t_24159, v_vs_24160, v_t_24162});
  }
  default: return heff_nomatch(v_x2_24158);
  }
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam3(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam5(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam6(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam7(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam8(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam9(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam10(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam11(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam12(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam13(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam14(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam15(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam16(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam17(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam18(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam19(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam20(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam21(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam22(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam23(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam24(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam25(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam26(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam27(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam28(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfArgs_lam29(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfArgs_entry, 3, 0};

V g_heff_2ecompile_2efuse_2eselfArgs(V v_g_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_n_241;
    V t_2 = v_b_246;
    v_g_240 = t_0;
    v_n_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_args_248 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EApp = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      V v_f_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam0, 2, 1, (V[]){v_f_2410}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    }
    case TAG_EGlobal: {
      V v_h_2415 = heff_field(v_x31_247, 0);
      heff_take_n(v_x31_247, 1ULL, 1);
      if ((heff_strEq_c_lent(v_g_240, v_h_2415, 0) && ({ V v_t_24243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_248)); int c_ = heff_intEq_c_lent(v_t_24243, v_n_241, 0); heff_drop(v_t_24243); c_; }))) {
        heff_drop(v_g_240);
        heff_drop(v_n_241);
        heff_drop(v_h_2415);
        return heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_args_248, NTAG(TAG_Nil)});
      } else {
        heff_drop_cell(v_ru_24x3_242_24EApp, 2);
        heff_drop(v_h_2415);
        V v_f_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
        V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_248));
        return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam1, 2, 1, (V[]){v_f_2416}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2417; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
      }
    }
    case TAG_ELam: {
      V v_f_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam2, 2, 1, (V[]){v_f_2423}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2424; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
    }
    case TAG_EApp: {
      V v_f_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam3, 2, 1, (V[]){v_f_2430}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2431; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
    }
    case TAG_ELet: {
      V v_f_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam4, 2, 1, (V[]){v_f_2438}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2439; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2439); r_; });
    }
    case TAG_ERecord: {
      V v_f_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam5, 2, 1, (V[]){v_f_2445}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2446; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2446); r_; });
    }
    case TAG_EProj: {
      V v_f_2454 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam6, 2, 1, (V[]){v_f_2454}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2455; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2455); r_; });
    }
    case TAG_ETag: {
      V v_f_2462 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam7, 2, 1, (V[]){v_f_2462}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2463; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
    }
    case TAG_EMatch: {
      V v_f_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2470 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam8, 2, 1, (V[]){v_f_2469}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2470; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2470); r_; });
    }
    case TAG_EPrim: {
      V v_f_2475 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam9, 2, 1, (V[]){v_f_2475}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2476; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2476); r_; });
    }
    case TAG_EPrimCall: {
      V v_f_2482 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2483 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam10, 2, 1, (V[]){v_f_2482}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2483; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2483); r_; });
    }
    case TAG_ECall: {
      V v_f_2489 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam11, 2, 1, (V[]){v_f_2489}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2490; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2490); r_; });
    }
    case TAG_EInt: {
      V v_f_2495 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_2496 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam12, 2, 1, (V[]){v_f_2495}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2496; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2496); r_; });
    }
    case TAG_EFloat: {
      V v_f_24101 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24102 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam13, 2, 1, (V[]){v_f_24101}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24102; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24102); r_; });
    }
    case TAG_EStr: {
      V v_f_24107 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam14, 2, 1, (V[]){v_f_24107}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24108; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24108); r_; });
    }
    case TAG_EBytes: {
      V v_f_24113 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24114 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam15, 2, 1, (V[]){v_f_24113}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24114; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24114); r_; });
    }
    case TAG_EFixed: {
      V v_f_24120 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24121 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam16, 2, 1, (V[]){v_f_24120}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24121; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24121); r_; });
    }
    case TAG_EFloat32: {
      V v_f_24126 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24127 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam17, 2, 1, (V[]){v_f_24126}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24127; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24127); r_; });
    }
    case TAG_EAbandon: {
      V v_f_24131 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24132 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam18, 2, 1, (V[]){v_f_24131}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24132; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24132); r_; });
    }
    case TAG_EBool: {
      V v_f_24137 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24138 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam19, 2, 1, (V[]){v_f_24137}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24138; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24138); r_; });
    }
    case TAG_ESet: {
      V v_f_24145 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24146 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam20, 2, 1, (V[]){v_f_24145}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24146; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24146); r_; });
    }
    case TAG_EValues: {
      V v_f_24151 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24152 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam21, 2, 1, (V[]){v_f_24151}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24152; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24152); r_; });
    }
    case TAG_EFix: {
      V v_f_24158 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24159 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24EApp, TAG_Cons, 2, (V[]){v_x31_247, v_args_248})));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam22, 2, 1, (V[]){v_f_24158}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24159; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24159); r_; });
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    V v_a_24164 = heff_field(v_x3_242, 1);
    V v_b_24165 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_24166 = (g_heff_2ecompile_2efuse_2eselfArgs(heff_dup(v_g_240), heff_dup(v_n_241), v_a_24164));
    V v_t_24167 = (g_heff_2ecompile_2efuse_2eselfArgs(v_g_240, v_n_241, v_b_24165));
    return (g_prelude_2e_2b_2b(v_t_24166, v_t_24167));
  }
  case TAG_ERecord: {
    V v_fs_24168 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 2);
    V v_t_24170 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_24168));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam23, 2, 2, (V[]){v_g_240, v_n_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24170; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24170); r_; });
  }
  case TAG_EProj: {
    V v_e_24177 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 4);
    V t_0 = v_g_240;
    V t_1 = v_n_241;
    V t_2 = v_e_24177;
    v_g_240 = t_0;
    v_n_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_args_24182 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 3);
    V v_f_24184 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
    V v_t_24185 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_24182));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam24, 2, 1, (V[]){v_f_24184}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24185; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24185); r_; });
  }
  case TAG_EMatch: {
    V v_s_24189 = heff_field(v_x3_242, 0);
    V v_arms_24190 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24EMatch = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_24191 = (g_heff_2ecompile_2efuse_2eselfArgs(heff_dup(v_g_240), heff_dup(v_n_241), v_s_24189));
    V v_t_24192 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24190));
    V v_t_24200 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam25, 2, 2, (V[]){v_g_240, v_n_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24192; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24192); r_; });
    HEFF_LAST return g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24EMatch, v_t_24191, v_t_24200);
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_args_24203 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    V v_f_24204 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
    V v_t_24205 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_24203));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam26, 2, 1, (V[]){v_f_24204}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24205; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24205); r_; });
  }
  case TAG_ECall: {
    V v_h_24209 = heff_field(v_x3_242, 0);
    V v_args_24210 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ECall = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if ((heff_strEq_c_lent(v_g_240, v_h_24209, 0) && ({ V v_t_24244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_24210)); int c_ = heff_intEq_c_lent(v_t_24244, v_n_241, 0); heff_drop(v_t_24244); c_; }))) {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      heff_drop(v_h_24209);
      return heff_tag_at_n(v_ru_24x3_242_24ECall, TAG_Cons, 2, (V[]){v_args_24210, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_h_24209);
      heff_drop_cell(v_ru_24x3_242_24ECall, 2);
      V v_f_24211 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
      V v_t_24212 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_24210));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam27, 2, 1, (V[]){v_f_24211}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24212; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24212); r_; });
    }
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    V v_c_24223 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_f_24224 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
    V v_xs_24225 = ({ V a_0 = v_c_24223; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_24223); r_; });
    V v_t_24226 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24225));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam28, 2, 1, (V[]){v_f_24224}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24226; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24226); r_; });
  }
  case TAG_ESet: {
    V v_a_24231 = heff_field(v_x3_242, 1);
    V v_b_24232 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 6ULL, 3);
    V v_t_24233 = (g_heff_2ecompile_2efuse_2eselfArgs(heff_dup(v_g_240), heff_dup(v_n_241), v_a_24231));
    V v_t_24234 = (g_heff_2ecompile_2efuse_2eselfArgs(v_g_240, v_n_241, v_b_24232));
    return (g_prelude_2e_2b_2b(v_t_24233, v_t_24234));
  }
  case TAG_EValues: {
    V v_es_24235 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_f_24236 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfArgs_clo), 2, (V[]){v_g_240, v_n_241}));
    V v_t_24237 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_24235));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2efuse_2eselfArgs_lam29, 2, 1, (V[]){v_f_24236}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24237; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24237); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2eselfArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eselfArgs(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_f_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tr(heff_call(v_f_2410, 1, (V[]){v_x_2413}));
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_2412));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam1(V self, V *args) {
  V v_acc_2418 = args[0];
  V v_x_2419 = args[1];
  V v_f_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = heff_tr(heff_call(v_f_2416, 1, (V[]){v_x_2419}));
  return (g_prelude_2e_2b_2b(v_t_2420, v_acc_2418));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam2(V self, V *args) {
  V v_acc_2425 = args[0];
  V v_x_2426 = args[1];
  V v_f_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_call(v_f_2423, 1, (V[]){v_x_2426}));
  return (g_prelude_2e_2b_2b(v_t_2427, v_acc_2425));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam3(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_x_2433 = args[1];
  V v_f_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_tr(heff_call(v_f_2430, 1, (V[]){v_x_2433}));
  return (g_prelude_2e_2b_2b(v_t_2434, v_acc_2432));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam4(V self, V *args) {
  V v_acc_2440 = args[0];
  V v_x_2441 = args[1];
  V v_f_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tr(heff_call(v_f_2438, 1, (V[]){v_x_2441}));
  return (g_prelude_2e_2b_2b(v_t_2442, v_acc_2440));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam5(V self, V *args) {
  V v_acc_2447 = args[0];
  V v_x_2448 = args[1];
  V v_f_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tr(heff_call(v_f_2445, 1, (V[]){v_x_2448}));
  return (g_prelude_2e_2b_2b(v_t_2449, v_acc_2447));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam6(V self, V *args) {
  V v_acc_2456 = args[0];
  V v_x_2457 = args[1];
  V v_f_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tr(heff_call(v_f_2454, 1, (V[]){v_x_2457}));
  return (g_prelude_2e_2b_2b(v_t_2458, v_acc_2456));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam7(V self, V *args) {
  V v_acc_2464 = args[0];
  V v_x_2465 = args[1];
  V v_f_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_tr(heff_call(v_f_2462, 1, (V[]){v_x_2465}));
  return (g_prelude_2e_2b_2b(v_t_2466, v_acc_2464));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam8(V self, V *args) {
  V v_acc_2471 = args[0];
  V v_x_2472 = args[1];
  V v_f_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2473 = heff_tr(heff_call(v_f_2469, 1, (V[]){v_x_2472}));
  return (g_prelude_2e_2b_2b(v_t_2473, v_acc_2471));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam9(V self, V *args) {
  V v_acc_2477 = args[0];
  V v_x_2478 = args[1];
  V v_f_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479 = heff_tr(heff_call(v_f_2475, 1, (V[]){v_x_2478}));
  return (g_prelude_2e_2b_2b(v_t_2479, v_acc_2477));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam10(V self, V *args) {
  V v_acc_2484 = args[0];
  V v_x_2485 = args[1];
  V v_f_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_tr(heff_call(v_f_2482, 1, (V[]){v_x_2485}));
  return (g_prelude_2e_2b_2b(v_t_2486, v_acc_2484));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam11(V self, V *args) {
  V v_acc_2491 = args[0];
  V v_x_2492 = args[1];
  V v_f_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2493 = heff_tr(heff_call(v_f_2489, 1, (V[]){v_x_2492}));
  return (g_prelude_2e_2b_2b(v_t_2493, v_acc_2491));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam12(V self, V *args) {
  V v_acc_2497 = args[0];
  V v_x_2498 = args[1];
  V v_f_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2499 = heff_tr(heff_call(v_f_2495, 1, (V[]){v_x_2498}));
  return (g_prelude_2e_2b_2b(v_t_2499, v_acc_2497));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam13(V self, V *args) {
  V v_acc_24103 = args[0];
  V v_x_24104 = args[1];
  V v_f_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24105 = heff_tr(heff_call(v_f_24101, 1, (V[]){v_x_24104}));
  return (g_prelude_2e_2b_2b(v_t_24105, v_acc_24103));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam14(V self, V *args) {
  V v_acc_24109 = args[0];
  V v_x_24110 = args[1];
  V v_f_24107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_tr(heff_call(v_f_24107, 1, (V[]){v_x_24110}));
  return (g_prelude_2e_2b_2b(v_t_24111, v_acc_24109));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam15(V self, V *args) {
  V v_acc_24115 = args[0];
  V v_x_24116 = args[1];
  V v_f_24113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24117 = heff_tr(heff_call(v_f_24113, 1, (V[]){v_x_24116}));
  return (g_prelude_2e_2b_2b(v_t_24117, v_acc_24115));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam16(V self, V *args) {
  V v_acc_24122 = args[0];
  V v_x_24123 = args[1];
  V v_f_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24124 = heff_tr(heff_call(v_f_24120, 1, (V[]){v_x_24123}));
  return (g_prelude_2e_2b_2b(v_t_24124, v_acc_24122));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam17(V self, V *args) {
  V v_acc_24128 = args[0];
  V v_x_24129 = args[1];
  V v_f_24126 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24130 = heff_tr(heff_call(v_f_24126, 1, (V[]){v_x_24129}));
  return (g_prelude_2e_2b_2b(v_t_24130, v_acc_24128));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam18(V self, V *args) {
  V v_acc_24133 = args[0];
  V v_x_24134 = args[1];
  V v_f_24131 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24135 = heff_tr(heff_call(v_f_24131, 1, (V[]){v_x_24134}));
  return (g_prelude_2e_2b_2b(v_t_24135, v_acc_24133));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam19(V self, V *args) {
  V v_acc_24139 = args[0];
  V v_x_24140 = args[1];
  V v_f_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24141 = heff_tr(heff_call(v_f_24137, 1, (V[]){v_x_24140}));
  return (g_prelude_2e_2b_2b(v_t_24141, v_acc_24139));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam20(V self, V *args) {
  V v_acc_24147 = args[0];
  V v_x_24148 = args[1];
  V v_f_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24149 = heff_tr(heff_call(v_f_24145, 1, (V[]){v_x_24148}));
  return (g_prelude_2e_2b_2b(v_t_24149, v_acc_24147));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam21(V self, V *args) {
  V v_acc_24153 = args[0];
  V v_x_24154 = args[1];
  V v_f_24151 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24155 = heff_tr(heff_call(v_f_24151, 1, (V[]){v_x_24154}));
  return (g_prelude_2e_2b_2b(v_t_24155, v_acc_24153));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam22(V self, V *args) {
  V v_acc_24160 = args[0];
  V v_x_24161 = args[1];
  V v_f_24158 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24162 = heff_tr(heff_call(v_f_24158, 1, (V[]){v_x_24161}));
  return (g_prelude_2e_2b_2b(v_t_24162, v_acc_24160));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam23(V self, V *args) {
  V v_acc_24171 = args[0];
  V v_x_24172 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24175;
  switch (heff_tag_of(v_x_24172)) {
  case TAG_MkPair: {
    V v_y_24174 = heff_field(v_x_24172, 1);
    heff_take_n(v_x_24172, 2ULL, 2);
    v_t_24175 = v_y_24174;
    break;
  }
  default: heff_nomatch(v_x_24172);
  }
  V v_t_24176 = (g_heff_2ecompile_2efuse_2eselfArgs(v_g_240, v_n_241, v_t_24175));
  return (g_prelude_2e_2b_2b(v_t_24176, v_acc_24171));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam24(V self, V *args) {
  V v_acc_24186 = args[0];
  V v_x_24187 = args[1];
  V v_f_24184 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24188 = heff_tr(heff_call(v_f_24184, 1, (V[]){v_x_24187}));
  return (g_prelude_2e_2b_2b(v_t_24188, v_acc_24186));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam25(V self, V *args) {
  V v_acc_24193 = args[0];
  V v_x_24194 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24198;
  switch (heff_tag_of(v_x_24194)) {
  case TAG_MkArm: {
    V v_b_24197 = heff_field(v_x_24194, 2);
    heff_take_n(v_x_24194, 4ULL, 3);
    v_t_24198 = v_b_24197;
    break;
  }
  default: heff_nomatch(v_x_24194);
  }
  V v_t_24199 = (g_heff_2ecompile_2efuse_2eselfArgs(v_g_240, v_n_241, v_t_24198));
  return (g_prelude_2e_2b_2b(v_t_24199, v_acc_24193));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam26(V self, V *args) {
  V v_acc_24206 = args[0];
  V v_x_24207 = args[1];
  V v_f_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24208 = heff_tr(heff_call(v_f_24204, 1, (V[]){v_x_24207}));
  return (g_prelude_2e_2b_2b(v_t_24208, v_acc_24206));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam27(V self, V *args) {
  V v_acc_24213 = args[0];
  V v_x_24214 = args[1];
  V v_f_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24215 = heff_tr(heff_call(v_f_24211, 1, (V[]){v_x_24214}));
  return (g_prelude_2e_2b_2b(v_t_24215, v_acc_24213));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam28(V self, V *args) {
  V v_acc_24227 = args[0];
  V v_x_24228 = args[1];
  V v_f_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24229 = heff_tr(heff_call(v_f_24224, 1, (V[]){v_x_24228}));
  return (g_prelude_2e_2b_2b(v_t_24229, v_acc_24227));
}
V g_heff_2ecompile_2efuse_2eselfArgs_lam29(V self, V *args) {
  V v_acc_24238 = args[0];
  V v_x_24239 = args[1];
  V v_f_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24240 = heff_tr(heff_call(v_f_24236, 1, (V[]){v_x_24239}));
  return (g_prelude_2e_2b_2b(v_t_24240, v_acc_24238));
}

HeffT2 g_heff_2ecompile_2efuse_2efreshF_24cpr(V v_e_240, V v_s_241) {
top: ;
  V v_supply_242 = heff_take_field(v_s_241, 0);
  V v_consumers_243 = heff_take_field(v_s_241, 1);
  V v_producers_244 = heff_take_field(v_s_241, 2);
  V v_made_245 = heff_take_field(v_s_241, 3);
  V v_fresh_246 = heff_take_field(v_s_241, 4);
  V v_left_247 = heff_get_n(v_s_241, 5, 6);
  HeffT2 v_t_248 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(g_std_2emap_2eempty_get()), v_supply_242, v_e_240));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_e_2411 = v_field_249;
    V v_n_2412 = v_field_2410;
    V v_f_2413 = heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_n_2412, v_consumers_243, v_producers_244, v_made_245, v_fresh_246, v_left_247});
    return ((HeffT2){{v_e_2411, v_f_2413}});
  }
}
Clo g_heff_2ecompile_2efuse_2ewithMade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ewithMade_entry, 4, 0};

V g_heff_2ecompile_2efuse_2ewithMade(V v_cp_240, V v_k_241, V v_x3_242, V v_s_243) {
top: ;
  V v_supply_244 = heff_take_field(v_s_243, 0);
  V v_consumers_245 = heff_take_field(v_s_243, 1);
  V v_producers_246 = heff_take_field(v_s_243, 2);
  V v_made_247 = heff_take_field(v_s_243, 3);
  V v_fresh_248 = heff_take_field(v_s_243, 4);
  V v_left_249 = heff_get_n(v_s_243, 5, 6);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_made_247, v_cp_240, v_k_241));
    return heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_supply_244, v_consumers_245, v_producers_246, v_t_2410, v_fresh_248, v_left_249});
  }
  case TAG_Just: {
    V v_d_2411 = heff_field(v_x3_242, 0);
    HeffT2 v_t_2412 = (g_heff_2ecompile_2efuse_2econsumerOf_24cpr(heff_dup(heff_rfield(v_d_2411, 0)), heff_dup(heff_rfield(v_d_2411, 2))));
    V v_t_2416;
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2414;
        v_t_2416 = (g_std_2emap_2einsert_24s93785294x875597928(v_consumers_245, heff_dup(heff_rfield(v_d_2411, 0)), v_x_2415));
      } else {
        heff_drop(v_field_2414);
        v_t_2416 = v_consumers_245;
      }
    }
    HeffT2 v_t_2417 = (g_heff_2ecompile_2efuse_2eproducerOf_24cpr(heff_rfield(v_d_2411, 0), heff_dup(heff_rfield(v_d_2411, 2))));
    V v_t_2421;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_x_2420 = v_field_2419;
        v_t_2421 = (g_std_2emap_2einsert_24s93785294x875597928(v_producers_246, heff_dup(heff_rfield(v_d_2411, 0)), v_x_2420));
      } else {
        heff_drop(v_field_2419);
        v_t_2421 = v_producers_246;
      }
    }
    V v_t_2422 = (g_std_2emap_2einsert_24s93785294x875597928(v_made_247, v_cp_240, v_k_241));
    return heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_supply_244, v_t_2416, v_t_2421, v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_d_2411), v_fresh_248}), heff_intSub(v_left_249, MK_INT(1LL))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2ewithMade_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2ewithMade(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2efuse_2ebindsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ebindsOf_entry, 3, 0};

V g_heff_2ecompile_2efuse_2ebindsOf(V v_x1_240, V v_x2_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_b_242;
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return v_b_242;
    }
    case TAG_Cons: {
      V v_h_245 = heff_field(v_x2_241, 0);
      V v_hs_246 = heff_field(v_x2_241, 1);
      V v_t_2446;
      switch (heff_tag_of(v_h_245)) {
      case TAG_EVar: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_h_245);
      }
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_e_2447 = (g_heff_2ecompile_2efuse_2ebindsOf(v_vs_244, v_hs_246, v_b_242));
        V v_t_2448 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_243), heff_dup(v_h_245), NTAG(TAG_Tip), NTAG(TAG_Tip)});
        V v_t_2449 = ({ V a_0 = v_t_2448; V r_ = (g_std_2emap_2esize(a_0)); heff_drop_tag(v_t_2448, 5); r_; });
        if (heff_intEq_c(v_t_2449, MK_INT(0LL))) {
          return v_e_2447;
        } else {
          V v_t_2450 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_243), heff_dup(v_h_245), NTAG(TAG_Tip), NTAG(TAG_Tip)});
          return ({ V a_0 = v_t_2450; V a_1 = v_e_2447; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop_tag(v_t_2450, 5); r_; });
        }
      } else {
        heff_drop(v_t_2446);
        V v_cell_2451 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_v_243), heff_dup(v_h_245), heff_hole()});
        V v_u_2452 = (g_heff_2ecompile_2efuse_2ebindsOf_24dps(v_vs_244, v_hs_246, v_b_242, heff_dup(v_cell_2451)));
        heff_drop(v_u_2452);
        return v_cell_2451;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2ebindsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2ebindsOf(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2ebindsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2ebindsOf_24dps(V v_x1_240, V v_x2_241, V v_b_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(2LL), v_b_242);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x1_240, 0);
    V v_vs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_setField(v_d_243, MK_INT(2LL), v_b_242);
    }
    case TAG_Cons: {
      V v_h_246 = heff_field(v_x2_241, 0);
      V v_hs_247 = heff_field(v_x2_241, 1);
      V v_t_2447;
      switch (heff_tag_of(v_h_246)) {
      case TAG_EVar: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2447 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2447 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_h_246);
      }
      if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
        heff_drop(v_t_2447);
        V v_e_2448 = (g_heff_2ecompile_2efuse_2ebindsOf(v_vs_245, v_hs_247, v_b_242));
        V v_t_2449 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_244), heff_dup(v_h_246), NTAG(TAG_Tip), NTAG(TAG_Tip)});
        V v_t_2450 = ({ V a_0 = v_t_2449; V r_ = (g_std_2emap_2esize(a_0)); heff_drop_tag(v_t_2449, 5); r_; });
        if (heff_intEq_c(v_t_2450, MK_INT(0LL))) {
          return heff_setField(v_d_243, MK_INT(2LL), v_e_2448);
        } else {
          V v_t_2451 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), heff_dup(v_v_244), heff_dup(v_h_246), NTAG(TAG_Tip), NTAG(TAG_Tip)});
          V v_t_2452 = ({ V a_0 = v_t_2451; V a_1 = v_e_2448; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop_tag(v_t_2451, 5); r_; });
          return heff_setField(v_d_243, MK_INT(2LL), v_t_2452);
        }
      } else {
        heff_drop(v_t_2447);
        V v_cell_2453 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_v_244), heff_dup(v_h_246), heff_hole()});
        V v_u_2454 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2453));
        heff_drop(v_u_2454);
        V t_0 = v_vs_245;
        V t_1 = v_hs_247;
        V t_2 = v_b_242;
        V t_3 = v_cell_2453;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_b_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2ebindsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2ebindsOf_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efuse_2eatEnds_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eatEnds_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eatEnds_lam2(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eatEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eatEnds_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eatEnds(V v_fu_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = (g_heff_2ecompile_2efuse_2eatEnds(v_fu_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eatEnds_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_241, 0);
    V v_arms_2426 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eatEnds_clo), 1, (V[]){v_fu_240}));
    V v_t_2428 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2426)));
    V v_m_2429 = (g_prelude_2etraverse_24s545943161x1483966866(v_t_2427, v_t_2428));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eatEnds_lam1, 1, 3, (V[]){v_m_2429, v_arms_2426, v_s_2425});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2449 = heff_field(v_e_241, 0);
    V v_a_2450 = heff_field(v_e_241, 1);
    V v_b_2451 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2452 = (g_heff_2ecompile_2efuse_2eatEnds(v_fu_240, v_b_2451));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eatEnds_lam2, 1, 3, (V[]){v_m_2452, v_xs_2449, v_a_2450});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_fu_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuse_2eatEnds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eatEnds(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2eatEnds_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2efuse_2eatEnds_lam1(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_arms_2426 = heff_env(self)[1];
  V v_s_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2426, v_x_2432));
    V v_x_2435 = heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2425, v_t_2434});
    return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_x_2435, v_s_2433});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2efuse_2eatEnds_lam2(V self, V *args) {
  V v_s_2453 = args[0];
  V v_m_2452 = heff_env(self)[0];
  V v_xs_2449 = heff_env(self)[1];
  V v_a_2450 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2454 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_s_2453}));
  switch (heff_tag_of(v_x2_2454)) {
  case TAG_MkPair: {
    V v_x_2455 = heff_field(v_x2_2454, 0);
    V v_s_2456 = heff_field(v_x2_2454, 1);
    V v_ru_24x2_2454_24MkPair = heff_take_reuse_n(v_x2_2454, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2449, v_a_2450, v_x_2455}), v_s_2456});
  }
  default: return heff_nomatch(v_x2_2454);
  }
}
Clo g_heff_2ecompile_2efuse_2econsumerCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econsumerCall_entry, 7, 0};

V g_heff_2ecompile_2efuse_2econsumerCall(V v_sg_240, V v_k_241, V v_pl_242, V v_g_243, V v_args_244, V v_x6_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    V v_m_247 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_244));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_246}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nothing: {
        heff_drop(v_g_243);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2411 = heff_field(v_x_249, 0);
        V v_ru_24x_249_24Just = heff_take_reuse_n(v_x_249, 1ULL, 1);
        V v_t_2412 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_243}), v_x_2411});
        v_t_2413 = heff_tag_at_n(v_ru_24x_249_24Just, TAG_Just, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_s_2410});
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  case TAG_Just: {
    V v_cs_2414 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eisVar_clo), 1, (V[]){heff_dup(heff_rfield(v_pl_242, 0))}));
    V v_t_2416 = (g_heff_2ecompile_2efuse_2enthF(heff_get_n(v_cs_2414, 1, 5), heff_dup(v_args_244)));
    V v_t_2417 = ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_2415; V a_2 = v_t_2416; V r_ = heff_tr(g_prelude_2emaybe(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_k_241);
      heff_drop(v_t_2417);
      V v_p_2418 = heff_take_field(v_pl_242, 1);
      V v_t_2419 = (g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(v_ru_24x6_245_24Just, heff_rfield(v_z_246, 1), v_g_243));
      V v_t_2420 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_z_246, 2), v_p_2418));
      return ({ V a_0 = v_sg_240; V a_1 = v_g_243; V a_2 = v_args_244; V a_3 = v_p_2418; V a_4 = heff_get_n(v_pl_242, 2, 3); V a_5 = v_t_2419; V a_6 = v_t_2420; V a_7 = v_z_246; V r_ = (g_heff_2ecompile_2efuse_2efuseKnown(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2419); heff_drop(v_t_2420); r_; });
    } else {
      heff_drop(v_t_2417);
      V v_m_2421 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_244));
      V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_z_246}));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        V v_t_2427;
        switch (heff_tag_of(v_x_2423)) {
        case TAG_Nothing: {
          heff_drop(v_g_243);
          heff_drop_cell(v_ru_24x6_245_24Just, 1);
          v_t_2427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2425 = heff_field(v_x_2423, 0);
          V v_ru_24x_2423_24Just = heff_take_reuse_n(v_x_2423, 1ULL, 1);
          V v_t_2426 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x_2423_24Just, TAG_EGlobal, 1, (V[]){v_g_243}), v_x_2425});
          v_t_2427 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_Just, 1, (V[]){v_t_2426});
          break;
        }
        default: heff_nomatch(v_x_2423);
        }
        return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){v_t_2427, v_s_2424});
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2efuse_2econsumerCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2econsumerCall(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2efuse_2eplugGo_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam1(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam1, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam2(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam2, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam3(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam3, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam5(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam5, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam6(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam6, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam7(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam7, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam8(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam8, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam9(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam9, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam10(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam10, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam11(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam11, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam12(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam12, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam13(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam13, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam14(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam14, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam15(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam15, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam16(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam16, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam17(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam17, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam18(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam18, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam19(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam19, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam20(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam20, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam21(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam21, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam22(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam22, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam23(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam23, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam24(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam24, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam25(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam25, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam26(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam27(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam28(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam28, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam29(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam29, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam30(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam30, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam31(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam32(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam33(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam33, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam34(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam34, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam35(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam36(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugGo_lam37(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam37, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam38(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam38, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam39(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam39, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam40(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam40, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam41(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam41, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam42(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam42, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam43(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam43, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam44(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam44, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam45(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam45, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam46(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam46, 1, 0};
V g_heff_2ecompile_2efuse_2eplugGo_lam47(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugGo_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_lam47, 1, 0};
Clo g_heff_2ecompile_2efuse_2eplugGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugGo_entry, 4, 0};

V g_heff_2ecompile_2efuse_2eplugGo(V v_sg_240, V v_k_241, V v_pl_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_EVar: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam0_clo);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam1_clo);
  }
  case TAG_ELam: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam2_clo);
  }
  case TAG_EApp: {
    V v_x41_2411 = heff_field(v_x4_243, 0);
    V v_args_2412 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_2411)) {
    case TAG_EVar: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam3_clo);
    }
    case TAG_EGlobal: {
      V v_g_2415 = heff_field(v_x41_2411, 0);
      heff_take_n(v_x41_2411, 1ULL, 1);
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam4, 1, 5, (V[]){v_g_2415, v_sg_240, v_k_241, v_pl_242, v_args_2412});
    }
    case TAG_ELam: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam5_clo);
    }
    case TAG_EApp: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam6_clo);
    }
    case TAG_ELet: {
      heff_take_n(v_x41_2411, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam7_clo);
    }
    case TAG_ERecord: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam8_clo);
    }
    case TAG_EProj: {
      heff_take_n(v_x41_2411, 0ULL, 4);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam9_clo);
    }
    case TAG_ETag: {
      heff_take_n(v_x41_2411, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam10_clo);
    }
    case TAG_EMatch: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam11_clo);
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam12_clo);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam13_clo);
    }
    case TAG_ECall: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam14_clo);
    }
    case TAG_EInt: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam15_clo);
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam16_clo);
    }
    case TAG_EStr: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam17_clo);
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam18_clo);
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam19_clo);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam20_clo);
    }
    case TAG_EAbandon: {
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam21_clo);
    }
    case TAG_EBool: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam22_clo);
    }
    case TAG_ESet: {
      heff_take_n(v_x41_2411, 0ULL, 3);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam23_clo);
    }
    case TAG_EValues: {
      heff_take_n(v_x41_2411, 0ULL, 1);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam24_clo);
    }
    case TAG_EFix: {
      heff_take_n(v_x41_2411, 0ULL, 2);
      heff_drop(v_sg_240);
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_args_2412);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam25_clo);
    }
    default: return heff_nomatch(v_x41_2411);
    }
  }
  case TAG_ELet: {
    V v_y_2476 = heff_field(v_x4_243, 0);
    V v_a_2477 = heff_field(v_x4_243, 1);
    V v_b_2478 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_x_2479 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2477), NTAG(TAG_Nil)});
    V v_t_2481 = (g_heff_2ecompile_2eir_2ecountW(v_x_2479, MK_INT(0LL), v_t_2480));
    V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2477), NTAG(TAG_Nil)});
    V v_t_2483 = ({ V a_0 = v_x_2479; V a_1 = v_t_2482; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_2479); r_; });
    V v_x_2484 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2481, v_t_2483}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_2484)) {
      heff_drop(v_sg_240);
      V v_m_2485 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_a_2477}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam26, 1, 3, (V[]){v_m_2485, v_y_2476, v_b_2478});
    } else {
      V v_t_2492 = (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, heff_dup(v_a_2477)));
      if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
        heff_drop(v_t_2492);
        V v_m_2493 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_b_2478}));
        return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam27, 1, 3, (V[]){v_m_2493, v_y_2476, v_a_2477});
      } else {
        heff_drop_rec(v_k_241, 1);
        heff_drop_rec(v_pl_242, 3);
        heff_drop(v_y_2476);
        heff_drop(v_a_2477);
        heff_drop(v_b_2478);
        heff_drop(v_t_2492);
        return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam28_clo);
      }
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam29_clo);
  }
  case TAG_EProj: {
    heff_take_n(v_x4_243, 0ULL, 4);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam30_clo);
  }
  case TAG_ETag: {
    V v_t_24109 = heff_field(v_x4_243, 0);
    V v_args_24110 = heff_field(v_x4_243, 1);
    V v_ts_24111 = heff_field(v_x4_243, 2);
    heff_take_n(v_x4_243, 7ULL, 3);
    V v_m_24112 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_24110));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam31, 1, 3, (V[]){v_m_24112, v_t_24109, v_ts_24111});
  }
  case TAG_EMatch: {
    V v_s_24119 = heff_field(v_x4_243, 0);
    V v_arms_24120 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24EMatch = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    heff_drop(v_sg_240);
    V v_x_24121 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_24122 = heff_tag_at_n(v_ru_24x4_243_24EMatch, TAG_Cons, 2, (V[]){heff_dup(v_s_24119), NTAG(TAG_Nil)});
    V v_t_24123 = (g_heff_2ecompile_2eir_2ecountW(v_x_24121, MK_INT(0LL), v_t_24122));
    V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_s_24119), NTAG(TAG_Nil)});
    V v_t_24125 = ({ V a_0 = v_x_24121; V a_1 = v_t_24124; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_24121); r_; });
    V v_x_24126 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_24123, v_t_24125}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_24126)) {
      V v_m_24127 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_s_24119}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam32, 1, 2, (V[]){v_m_24127, v_arms_24120});
    } else {
      heff_drop_rec(v_k_241, 1);
      heff_drop_rec(v_pl_242, 3);
      heff_drop(v_s_24119);
      heff_drop(v_arms_24120);
      return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam33_clo);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam34_clo);
  }
  case TAG_EPrimCall: {
    V v_q_24137 = heff_field(v_x4_243, 0);
    V v_args_24138 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_m_24139 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_args_24138));
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam35, 1, 2, (V[]){v_m_24139, v_q_24137});
  }
  case TAG_ECall: {
    V v_g_24146 = heff_field(v_x4_243, 0);
    V v_args_24147 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2efuse_2eplugGo_lam36, 1, 5, (V[]){v_g_24146, v_sg_240, v_k_241, v_pl_242, v_args_24147});
  }
  case TAG_EInt: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam37_clo);
  }
  case TAG_EFloat: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam38_clo);
  }
  case TAG_EStr: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam39_clo);
  }
  case TAG_EBytes: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam40_clo);
  }
  case TAG_EFixed: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam41_clo);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam42_clo);
  }
  case TAG_EAbandon: {
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam43_clo);
  }
  case TAG_EBool: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam44_clo);
  }
  case TAG_ESet: {
    heff_take_n(v_x4_243, 0ULL, 3);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam45_clo);
  }
  case TAG_EValues: {
    heff_take_n(v_x4_243, 0ULL, 1);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam46_clo);
  }
  case TAG_EFix: {
    heff_take_n(v_x4_243, 0ULL, 2);
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugGo_lam47_clo);
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eplugGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2eplugGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_245});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam1(V self, V *args) {
  V v_s_247 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_247});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2410});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2414});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam4(V self, V *args) {
  V v_s_2416 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_pl_242 = heff_env(self)[3];
  V v_args_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_s_2416, 1), v_g_2415));
  return (g_heff_2ecompile_2efuse_2econsumerCall(v_sg_240, v_k_241, v_pl_242, v_g_2415, v_args_2412, v_t_2417, v_s_2416));
}
V g_heff_2ecompile_2efuse_2eplugGo_lam5(V self, V *args) {
  V v_s_2420 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2420});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam6(V self, V *args) {
  V v_s_2423 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2423});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam7(V self, V *args) {
  V v_s_2427 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2427});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam8(V self, V *args) {
  V v_s_2430 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2430});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam9(V self, V *args) {
  V v_s_2435 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2435});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam10(V self, V *args) {
  V v_s_2439 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2439});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam11(V self, V *args) {
  V v_s_2442 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2442});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam12(V self, V *args) {
  V v_s_2444 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2444});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam13(V self, V *args) {
  V v_s_2447 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2447});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam14(V self, V *args) {
  V v_s_2450 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2450});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam15(V self, V *args) {
  V v_s_2452 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2452});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam16(V self, V *args) {
  V v_s_2454 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2454});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam17(V self, V *args) {
  V v_s_2456 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2456});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam18(V self, V *args) {
  V v_s_2458 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2458});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam19(V self, V *args) {
  V v_s_2461 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2461});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam20(V self, V *args) {
  V v_s_2463 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2463});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam21(V self, V *args) {
  V v_s_2464 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2464});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam22(V self, V *args) {
  V v_s_2466 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2466});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam23(V self, V *args) {
  V v_s_2470 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2470});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam24(V self, V *args) {
  V v_s_2472 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2472});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam25(V self, V *args) {
  V v_s_2475 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2475});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam26(V self, V *args) {
  V v_s_2486 = args[0];
  V v_m_2485 = heff_env(self)[0];
  V v_y_2476 = heff_env(self)[1];
  V v_b_2478 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2487 = heff_tr(heff_call(v_m_2485, 1, (V[]){v_s_2486}));
  switch (heff_tag_of(v_x2_2487)) {
  case TAG_MkPair: {
    V v_x_2488 = heff_field(v_x2_2487, 0);
    V v_s_2489 = heff_field(v_x2_2487, 1);
    V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
    V v_t_2491;
    switch (heff_tag_of(v_x_2488)) {
    case TAG_Nothing: {
      heff_drop(v_y_2476);
      heff_drop(v_b_2478);
      v_t_2491 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2490 = heff_field(v_x_2488, 0);
      V v_ru_24x_2488_24Just = heff_take_reuse_n(v_x_2488, 1ULL, 1);
      v_t_2491 = heff_tag_at_n(v_ru_24x_2488_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2476, v_x_2490, v_b_2478})});
      break;
    }
    default: heff_nomatch(v_x_2488);
    }
    return heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){v_t_2491, v_s_2489});
  }
  default: return heff_nomatch(v_x2_2487);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam27(V self, V *args) {
  V v_s_2494 = args[0];
  V v_m_2493 = heff_env(self)[0];
  V v_y_2476 = heff_env(self)[1];
  V v_a_2477 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2495 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_s_2494}));
  switch (heff_tag_of(v_x2_2495)) {
  case TAG_MkPair: {
    V v_x_2496 = heff_field(v_x2_2495, 0);
    V v_s_2497 = heff_field(v_x2_2495, 1);
    V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
    V v_t_2499;
    switch (heff_tag_of(v_x_2496)) {
    case TAG_Nothing: {
      heff_drop(v_y_2476);
      heff_drop(v_a_2477);
      v_t_2499 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2498 = heff_field(v_x_2496, 0);
      V v_ru_24x_2496_24Just = heff_take_reuse_n(v_x_2496, 1ULL, 1);
      v_t_2499 = heff_tag_at_n(v_ru_24x_2496_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2476, v_a_2477, v_x_2498})});
      break;
    }
    default: heff_nomatch(v_x_2496);
    }
    return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){v_t_2499, v_s_2497});
  }
  default: return heff_nomatch(v_x2_2495);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam28(V self, V *args) {
  V v_s_24100 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24100});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam29(V self, V *args) {
  V v_s_24103 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24103});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam30(V self, V *args) {
  V v_s_24108 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24108});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam31(V self, V *args) {
  V v_s_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_t_24109 = heff_env(self)[1];
  V v_ts_24111 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_s_24113}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_s_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    V v_t_24118;
    switch (heff_tag_of(v_x_24115)) {
    case TAG_Nothing: {
      heff_drop(v_t_24109);
      heff_drop(v_ts_24111);
      v_t_24118 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_24117 = heff_field(v_x_24115, 0);
      V v_ru_24x_24115_24Just = heff_take_reuse_n(v_x_24115, 1ULL, 1);
      v_t_24118 = heff_tag_at_n(v_ru_24x_24115_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24109, v_x_24117, v_ts_24111})});
      break;
    }
    default: heff_nomatch(v_x_24115);
    }
    return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){v_t_24118, v_s_24116});
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam32(V self, V *args) {
  V v_s_24128 = args[0];
  V v_m_24127 = heff_env(self)[0];
  V v_arms_24120 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24129 = heff_tr(heff_call(v_m_24127, 1, (V[]){v_s_24128}));
  switch (heff_tag_of(v_x2_24129)) {
  case TAG_MkPair: {
    V v_x_24130 = heff_field(v_x2_24129, 0);
    V v_s_24131 = heff_field(v_x2_24129, 1);
    V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
    V v_t_24133;
    switch (heff_tag_of(v_x_24130)) {
    case TAG_Nothing: {
      heff_drop(v_arms_24120);
      v_t_24133 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_24132 = heff_field(v_x_24130, 0);
      V v_ru_24x_24130_24Just = heff_take_reuse_n(v_x_24130, 1ULL, 1);
      v_t_24133 = heff_tag_at_n(v_ru_24x_24130_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24132, v_arms_24120})});
      break;
    }
    default: heff_nomatch(v_x_24130);
    }
    return heff_tag_at_n(v_ru_24x2_24129_24MkPair, TAG_MkPair, 2, (V[]){v_t_24133, v_s_24131});
  }
  default: return heff_nomatch(v_x2_24129);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam33(V self, V *args) {
  V v_s_24134 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24134});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam34(V self, V *args) {
  V v_s_24136 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24136});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam35(V self, V *args) {
  V v_s_24140 = args[0];
  V v_m_24139 = heff_env(self)[0];
  V v_q_24137 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24141 = heff_tr(heff_call(v_m_24139, 1, (V[]){v_s_24140}));
  switch (heff_tag_of(v_x2_24141)) {
  case TAG_MkPair: {
    V v_x_24142 = heff_field(v_x2_24141, 0);
    V v_s_24143 = heff_field(v_x2_24141, 1);
    V v_ru_24x2_24141_24MkPair = heff_take_reuse_n(v_x2_24141, 3ULL, 2);
    V v_t_24145;
    switch (heff_tag_of(v_x_24142)) {
    case TAG_Nothing: {
      heff_drop(v_q_24137);
      v_t_24145 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_24144 = heff_field(v_x_24142, 0);
      V v_ru_24x_24142_24Just = heff_take_reuse_n(v_x_24142, 1ULL, 1);
      v_t_24145 = heff_tag_at_n(v_ru_24x_24142_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_q_24137, v_x_24144})});
      break;
    }
    default: heff_nomatch(v_x_24142);
    }
    return heff_tag_at_n(v_ru_24x2_24141_24MkPair, TAG_MkPair, 2, (V[]){v_t_24145, v_s_24143});
  }
  default: return heff_nomatch(v_x2_24141);
  }
}
V g_heff_2ecompile_2efuse_2eplugGo_lam36(V self, V *args) {
  V v_s_24148 = args[0];
  V v_g_24146 = heff_env(self)[0];
  V v_sg_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_pl_242 = heff_env(self)[3];
  V v_args_24147 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24149 = (g_std_2emap_2elookup_24s1930949324x2078207031(heff_rfield(v_s_24148, 1), v_g_24146));
  return (g_heff_2ecompile_2efuse_2econsumerCall(v_sg_240, v_k_241, v_pl_242, v_g_24146, v_args_24147, v_t_24149, v_s_24148));
}
V g_heff_2ecompile_2efuse_2eplugGo_lam37(V self, V *args) {
  V v_s_24151 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24151});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam38(V self, V *args) {
  V v_s_24153 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24153});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam39(V self, V *args) {
  V v_s_24155 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24155});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam40(V self, V *args) {
  V v_s_24157 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24157});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam41(V self, V *args) {
  V v_s_24160 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24160});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam42(V self, V *args) {
  V v_s_24162 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24162});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam43(V self, V *args) {
  V v_s_24163 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24163});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam44(V self, V *args) {
  V v_s_24165 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24165});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam45(V self, V *args) {
  V v_s_24169 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24169});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam46(V self, V *args) {
  V v_s_24171 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24171});
}
V g_heff_2ecompile_2efuse_2eplugGo_lam47(V self, V *args) {
  V v_s_24174 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_24174});
}