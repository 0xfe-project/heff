// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailedWith 25914
#define TAG_JArray 50516
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Measured 52135
#define TAG_Nanos 3335
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_RealPath 18882
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_SkippedWith 54656
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alias 294261354
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_count 296209705
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_fuel 9649789
#define LBL_group 299987609
#define LBL_implicit 319715269
#define LBL_input 301716452
#define LBL_json 9767343
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_ran 322201
#define LBL_renames 1324191545
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_time 10055572
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_pattern__time__count__json__fuel[] = {LBL_pattern, LBL_time, LBL_count, LBL_json, LBL_fuel};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s1412293101x300983667(V, V, V);
V g_co_2eop_24s1412293101x300983667_entry(V self, V *a);
extern Clo g_co_2eop_24s1412293101x300983667_clo;
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchProgram_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_clo;
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_clo;
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_clo;
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo;
V g_heff_2ebuild_2ebenchmarks_2eperOp(V, V);
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo;
V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo;
V g_heff_2ebuild_2ebenchmarks_2eresultLine(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo;
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321_clo;
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces(V);
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V, V);
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo;
V g_heff_2ebuild_2ebenchmarks_2etenTo(V);
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo;
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802_clo;
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V, V);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_clo;
V g_heff_2ebuild_2edriver_2ebenchesOf(V);
V g_heff_2ebuild_2edriver_2ebenchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebenchesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2ebuild_2etesting_2elastLines(V, V);
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elastLines_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eall_24s2093734251x1702493483(V, V, V, V);
V g_list_2eall_24s2093734251x1702493483_entry(V self, V *a);
extern Clo g_list_2eall_24s2093734251x1702493483_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1681408447x1763680441(V, V, V);
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2emap_24s723912745x1713553694(V);
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2elevelsOf_2ecut_240(V, V, V, V, V, V);
V g_regex_2elevelsOf_2ecut_240_entry(V self, V *a);
extern Clo g_regex_2elevelsOf_2ecut_240_clo;
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465(V);
V g_std_2efilesystem_2efromSystem_24s141698176x1512134465_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s141698176x1512134465_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str0, 2, "ns");
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit1, TAG_MkPair, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str0), MK_INT(1LL));
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str2, 2, "us");
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit3, TAG_MkPair, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str2), MK_INT(1000LL));
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str4, 3, "\302\265s");
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit5, TAG_MkPair, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str4), MK_INT(1000LL));
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str6, 2, "ms");
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit7, TAG_MkPair, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str6), MK_INT(1000000LL));
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str8, 1, "s");
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit9, TAG_MkPair, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str8), MK_INT(1000000000LL));
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str10, 1, "m");
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit11, TAG_MkPair, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str10), MK_INT(60000000000LL));
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str12, 1, "h");
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit13, TAG_MkPair, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str12), MK_INT(3600000000000LL));
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit14, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit13), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit15, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit11), ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit14));
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit16, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit9), ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit15));
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit17, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit7), ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit16));
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit18, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit5), ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit17));
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit19, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit3), ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit18));
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_lit20, TAG_Cons, 2, ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit1), ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit19));

static V g_heff_2ebuild_2ebenchmarks_2eunits_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2eunits_st;
static V g_heff_2ebuild_2ebenchmarks_2eunits_init(void) {
  return ((V)&g_heff_2ebuild_2ebenchmarks_2eunits_lit20);
}
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2eunits_st)) return g_heff_2ebuild_2ebenchmarks_2eunits_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2eunits_val, &g_heff_2ebuild_2ebenchmarks_2eunits_st, g_heff_2ebuild_2ebenchmarks_2eunits_init);
}
HEFF_TAG_LIT(g_heff_2ebuild_2ebenchmarks_2edefaultTime_lit0, TAG_Nanos, 1, MK_INT(1000000000LL));

static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2edefaultTime_st;
static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_init(void) {
  return ((V)&g_heff_2ebuild_2ebenchmarks_2edefaultTime_lit0);
}
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2edefaultTime_st)) return g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2edefaultTime_val, &g_heff_2ebuild_2ebenchmarks_2edefaultTime_st, g_heff_2ebuild_2ebenchmarks_2edefaultTime_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str1, 1, " ");
Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaces_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2espaces(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str0);
  } else {
    V v_s_241 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str1);
    return (g_heff_2ebuild_2ebenchmarks_2espaces_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_241));
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2espaces(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecapital_str0, 26, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecapital_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ecapital(V v_s_240) {
top: ;
  if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_240, 0))) && ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))))) {
    int64_t v_t_241 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)97ULL));
    int64_t v_t_242 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)96ULL));
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
    return heff_strAppend(heff_strSlice(((V)&g_heff_2ebuild_2ebenchmarks_2ecapital_str0), heff_box_word(v_t_241), heff_box_word(v_t_242)), v_t_243);
  } else {
    return v_s_240;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecapital(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0, 1, "0");
Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V v_n_240, V v_s_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, heff_strLength_lent(v_s_241, 0), 2)) {
    heff_drop(v_n_240);
    return v_s_241;
  } else {
    V t_0 = v_n_240;
    V t_1 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0), v_s_241);
    v_n_240 = t_0;
    v_s_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ezeroPadded(a[0], a[1]);
}
Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V v_total_240, V v_n_241, V v_box_24k_242) {
  int64_t v_k_242 = heff_unbox_word(v_box_24k_242);
top: ;
  if ((((int64_t)7ULL) <= v_k_242)) {
    heff_drop(v_total_240);
    heff_drop(v_n_241);
    return heff_box_word(v_k_242);
  } else {
    V v_t_243 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_box_word((v_k_242 + ((int64_t)2ULL)))));
    V v_x_244 = heff_intMul_lent(v_total_240, v_t_243, 2);
    if (heff_intLe_c(heff_intMul_lent(MK_INT(99995LL), v_n_241, 1), v_x_244)) {
      heff_drop(v_total_240);
      heff_drop(v_n_241);
      return heff_box_word(v_k_242);
    } else {
      V t_0 = v_total_240;
      V t_1 = v_n_241;
      int64_t t_2 = (v_k_242 + ((int64_t)1ULL));
      v_total_240 = t_0;
      v_n_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eplacesOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str3, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str4, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str5, 7, " ns/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str6, 6, " B/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str7, 10, " allocs/op");
Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eresultLine_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2eresultLine(V v_width_240, V v_names_241, V v_n_242, V v_ns_243, V v_allocs_244, V v_bytes_245) {
top: ;
  V v_s_2411;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_s_2411 = ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str0);
    break;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_names_241, 0);
    V v_rest_247 = heff_field(v_names_241, 1);
    V v_t_248 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_246));
    V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_248));
    V v_t_2410 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str1), v_t_249, v_rest_247));
    v_s_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str2), v_t_2410);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2412 = heff_intSub(v_width_240, heff_strLength_lent(v_s_2411, 0));
  V v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2espaces(v_t_2412));
  V v_s_2414 = heff_intShow(heff_dup(v_n_242));
  int64_t v_t_2415 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2414, 0)));
  V v_t_2416 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2415)));
  V v_t_2417 = (g_heff_2ebuild_2ebenchmarks_2eperOp(v_ns_243, heff_dup(v_n_242)));
  V v_s_2418 = heff_intShow(heff_intDiv_lent(v_bytes_245, v_n_242, 1));
  int64_t v_t_2419 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2418, 0)));
  V v_t_2420 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2419)));
  V v_s_2421 = heff_intShow(heff_intDiv(v_allocs_244, v_n_242));
  int64_t v_t_2422 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2421, 0)));
  V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2422)));
  V v_t_2424 = heff_strAppend(heff_strAppend(v_s_2411, v_t_2413), ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str3));
  V v_t_2425 = heff_strAppend(v_t_2424, heff_strAppend(v_t_2416, v_s_2414));
  V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str4)), v_t_2417);
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str5)), heff_strAppend(v_t_2420, v_s_2418));
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str6)), heff_strAppend(v_t_2423, v_s_2421));
  return heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str7));
}
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2eresultLine(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8, 10, "--- FAIL: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18, 10, "--- SKIP: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19, 1, "\012");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V v_width_240, V v_names_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Measured: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ns_244 = heff_field(v_x3_242, 1);
    V v_allocs_245 = heff_field(v_x3_242, 2);
    V v_bytes_246 = heff_field(v_x3_242, 3);
    return (g_heff_2ebuild_2ebenchmarks_2eresultLine(v_width_240, v_names_241, heff_dup(v_n_243), heff_dup(v_ns_244), heff_dup(v_allocs_245), heff_dup(v_bytes_246)));
  }
  case TAG_FailedWith: {
    V v_why_247 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2413;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0);
      break;
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_names_241, 0);
      V v_rest_249 = heff_field(v_names_241, 1);
      V v_t_2410 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_248));
      V v_t_2411 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2410));
      V v_t_2412 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1), v_t_2411, v_rest_249));
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2), v_t_2412);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2414 = ({ V a_0 = v_why_247; V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4), v_why_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_2415 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5), v_t_2414));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8), v_t_2413), ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9));
    return heff_strAppend(v_t_2419, v_t_2418);
  }
  case TAG_SkippedWith: {
    V v_why_2420 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2426;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10);
      break;
    }
    case TAG_Cons: {
      V v_n_2421 = heff_field(v_names_241, 0);
      V v_rest_2422 = heff_field(v_names_241, 1);
      V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_2421));
      V v_t_2424 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2423));
      V v_t_2425 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11), v_t_2424, v_rest_2422));
      v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12), v_t_2425);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2427 = ({ V a_0 = v_why_2420; V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14), v_why_2420, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_2428 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15), v_t_2427));
    V v_t_2431;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_xs_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2428);
    }
    V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18), v_t_2426), ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19));
    return heff_strAppend(v_t_2432, v_t_2431);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_name_243 = heff_dup(heff_rfield(v_i_241, 0));
    V v_alias_244 = heff_dup(heff_rfield(v_i_241, 1));
    if (heff_strEq_c(v_name_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0))) {
      V v_t_245 = v_alias_244;
      V v_t_247;
      switch (heff_tag_of(v_t_245)) {
      case TAG_Nothing: {
        v_t_247 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 1);
        v_t_247 = heff_strAppend(v_alias_246, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
    } else {
      heff_drop(v_alias_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str0, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str1, 8, "main.exe");
Clo g_heff_2ebuild_2ebenchmarks_2ebenchProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchProgram(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_240), v_file_241));
  V v_t_243 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_p_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_p_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str0);
    break;
  }
  case TAG_Windows: {
    v_p_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_st_245 = heff_get_n(v_paths_240, 5, 6);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_242));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_p_244));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  return ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchProgram(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0, 12, "heff:abandon");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1, 12, "it abandoned");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7, 9, "not run: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str10, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str11, 3, "it ");
Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V v_r_240) {
top: ;
  V v_err_241 = heff_take_field(v_r_240, 2);
  V v_ended_242 = heff_get_n(v_r_240, 0, 3);
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0), v_err_241, MK_INT(0LL), 5))) {
    heff_drop(v_err_241);
    heff_drop(v_ended_242);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1);
  } else {
    V v_t_243 = v_ended_242;
    V v_t_2412;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Exited: {
      V v_n_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2), heff_intShow(v_n_244));
      break;
    }
    case TAG_Signalled: {
      V v_n_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3), heff_intShow(v_n_245));
      break;
    }
    case TAG_TimedOut: {
      v_t_2412 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4);
      break;
    }
    case TAG_NotRun: {
      V v_err_246 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      V v_path_247 = heff_take_field(v_err_246, 3);
      V v_name_248 = heff_take_field(v_err_246, 1);
      V v_message_249 = heff_get_n(v_err_246, 2, 4);
      V v_t_2410 = heff_strAppend(heff_strAppend(v_path_247, ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5)), v_name_248);
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6)), v_message_249);
      v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7), v_t_2411);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2414;
    if (heff_strEq_c_lent(v_err_241, ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8), 2)) {
      heff_drop(v_err_241);
      v_t_2414 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9);
    } else {
      V v_t_2413 = ({ V a_0 = MK_INT(20LL); V a_1 = v_err_241; V r_ = (g_heff_2ebuild_2etesting_2elastLines(a_0, a_1)); heff_drop(v_err_241); r_; });
      v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str10), v_t_2413);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str11), v_t_2412), v_t_2414);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eendedWhy(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str0, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str1, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str3, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str4, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str5, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam2(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_z_241);
    return heff_tail(v_z_242, 1, (V[]){MK_INT(1LL)});
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_247;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_243, 0)))) {
      int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_s_243, 0)) - ((int64_t)1ULL));
      V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_244)));
      V v_t_246 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_243; V a_2 = MK_INT(57LL); V a_3 = v_t_245; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = (g_prelude_2eparseInt(v_s_243));
      } else {
        heff_drop(v_t_246);
        v_t_247 = NTAG(TAG_Nothing);
      }
    } else {
      v_t_247 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str0), v_s_243), ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str1));
      V v_t_249 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str2)), NTAG(TAG_MkUnit)});
      V v_t_2410 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam0, 1, 2, (V[]){v_z_241, v_z_242}));
    }
    case TAG_Just: {
      V v_n_2423 = heff_field(v_t_247, 0);
      V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
      if (heff_intLt_c_lent(MK_INT(0LL), v_n_2423, 1)) {
        heff_drop(v_z_241);
        heff_drop(v_s_243);
        heff_drop_cell(v_ru_24x1_240_24Just, 1);
        heff_drop_cell(v_ru_24t_247_24Just, 1);
        return heff_tail(v_z_242, 1, (V[]){v_n_2423});
      } else {
        heff_drop(v_n_2423);
        V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str3), v_s_243), ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str4));
        V v_t_2425 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_str5)), NTAG(TAG_MkUnit)});
        V v_t_2426 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24t_247_24Just, TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
        HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam2, 1, 2, (V[]){v_z_241, v_z_242}));
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_drop(v_x_2422);
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam0(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_z_241, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam1, 1, 1, (V[]){v_z_242})));
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam3(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_drop(v_x_2438);
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_z_241, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268_lam3, 1, 1, (V[]){v_z_242})));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str2, 18, "heff bench: --run ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str5, 0, "");
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam2(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam2, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam3(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_entry, 5, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151(V v_pattern_240, V v_time_241, V v_count_242, V v_json_243, V v_fuel_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_246 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str0);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_pattern_240, 0);
    v_t_246 = heff_dup(v_x_245);
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_False); V a_4 = MK_INT(0LL); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2elevelsOf_2ecut_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1007499915x73800978(v_t_247));
  HeffT2 v_t_249 = (g_regex_2eallRead_24cpr(v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    V v_c_2435;
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_why_2412 = v_field_2411;
      v_c_2435 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam0, 2, 2, (V[]){heff_dup(v_pattern_240), v_why_2412});
    } else {
      V v_x_2432 = v_field_2411;
      heff_drop(v_x_2432);
      v_c_2435 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam2_clo);
    }
    return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam3, 2, 6, (V[]){v_c_2435, v_time_241, v_count_242, heff_dup(v_pattern_240), v_json_243, v_fuel_244});
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_pattern_240 = heff_env(self)[0];
  V v_why_2412 = heff_env(self)[1];
  V v_t_2416;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_pattern_240, 0);
    heff_take_n(v_pattern_240, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str2), v_t_2416), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str3));
  V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_why_2412), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str4));
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam1, 1, 2, (V[]){v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam2(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_pattern_240 = heff_env(self)[0];
  V v_k_2437 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_json_243 = heff_env(self)[3];
  V v_fuel_244 = heff_env(self)[4];
  V v_t_2442;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_2442 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2441 = heff_field(v_pattern_240, 0);
    heff_take_n(v_pattern_240, 1ULL, 1);
    v_t_2442 = v_x_2441;
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V f_ = v_k_2437;
  args[0] = heff_rec_n(5, shape_pattern__time__count__json__fuel, (V[]){v_t_2442, v_x_2439, v_x_2440, v_json_243, v_fuel_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_count_242 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  V v_pattern_240 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  V v_json_243 = heff_env(self)[4];
  V v_fuel_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s377693266x1376113268(v_count_242, v_hd_2436, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam6, 1, 5, (V[]){v_pattern_240, v_k_2437, v_x_2439, v_json_243, v_fuel_244})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_time_241 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  V v_count_242 = heff_env(self)[2];
  V v_pattern_240 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  V v_json_243 = heff_env(self)[5];
  V v_fuel_244 = heff_env(self)[6];
  heff_drop(v_x_2438);
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s791331729x27119802(v_time_241, heff_dup(v_hd_2436), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam5, 1, 6, (V[]){v_count_242, v_hd_2436, v_pattern_240, v_k_2437, v_json_243, v_fuel_244})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam3(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_time_241 = heff_env(self)[1];
  V v_count_242 = heff_env(self)[2];
  V v_pattern_240 = heff_env(self)[3];
  V v_json_243 = heff_env(self)[4];
  V v_fuel_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1242053233x324287151_lam4, 1, 7, (V[]){v_time_241, v_hd_2436, v_count_242, v_pattern_240, v_k_2437, v_json_243, v_fuel_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str1, 71, "heff bench: no bench/ here: bench at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str2, 71, "heff bench: no bench/ here: bench at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str3, 5, "bench");
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099(V v_given_240, V v_z_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_243 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str0)));
    V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_246 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam0_clo)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    HEFF_LAST return g_co_2eop_24s1896221640x2141527803(v_t_2411, heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam1, 1, 3, (V[]){v_z_241, v_z_242, v_path_243}));
  }
  case TAG_Cons: {
    V v_t_2454 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    V v_t_2455 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_t_2454, NTAG(TAG_Nil)));
    return heff_tail(v_t_2455, 2, (V[]){v_z_241, v_z_242});
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam0(V self, V *args) {
  V v_r_245 = args[0];
  return v_r_245;
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_drop(v_x_2427);
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_z_241, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam3, 1, 1, (V[]){v_z_242})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_drop(v_x_2443);
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_241, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam5, 1, 1, (V[]){v_z_242})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam6(V self, V *args) {
  V v_n_2445 = args[0];
  V v_path_243 = heff_env(self)[0];
  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2445));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_243, v_t_2446));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 0ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_path_243);
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str1), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam2, 1, 2, (V[]){v_z_241, v_z_242})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      V v_ru_24y_2428_24Left = heff_take_reuse_n(v_y_2428, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_path_243);
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str2), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_at_n(v_ru_24x_2412_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2428_24Left, TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam4, 1, 2, (V[]){v_z_241, v_z_242})));
    }
    case TAG_Right: {
      V v_x_2444 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      heff_clo_take(self, 3);
      V v_x_2447 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_lam6, 1, 1, (V[]){v_path_243}), v_x_2444));
      V v_x_2448 = (g_list_2emap_24s219049803x1458391381(v_x_2447));
      heff_drop(v_x_2448);
      V v_t_2449 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s654685409x1297724099_str3)});
      V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
      V v_t_2451 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_t_2450, NTAG(TAG_Nil)));
      V f_ = v_t_2451;
      heff_room[0] = v_z_241;
      heff_room[1] = v_z_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str1, 25, "heff bench: no benchmarks");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str2, 33, "heff bench: no benchmarks match '");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str3, 1, "'");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str4, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_entry, 4, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  V v_ran_244 = heff_take_field(v_acc_241, 0);
  V v_failed_245 = heff_get_n(v_acc_241, 1, 2);
  if ((heff_intEq_c_lent(v_ran_244, MK_INT(0LL), 2) && heff_intEq_c_lent(v_failed_245, MK_INT(0LL), 2))) {
    heff_drop(v_ran_244);
    heff_drop(v_failed_245);
    V v_t_247;
    if (heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 0)), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str0))) {
      heff_drop_rec(v_opts_240, 5);
      v_t_247 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str1);
    } else {
      V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str2), heff_get_n(v_opts_240, 0, 5));
      v_t_247 = heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str3));
    }
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_str4)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_lam0, 1, 2, (V[]){v_p_242, v_p_243})));
  } else {
    heff_drop_rec(v_opts_240, 5);
    heff_drop(v_ran_244);
    if (heff_intLt_c(MK_INT(0LL), v_failed_245)) {
      V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_p_242, v_p_243));
    } else {
      heff_drop(v_p_242);
      return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_p_242, v_p_243));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str3, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str4, 2, "ns");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str5, 6, "allocs");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str6, 5, "bytes");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str7, 9, "ns_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str8, 13, "allocs_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str9, 12, "bytes_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str10, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str11, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str12, 4, "file");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str13, 4, "name");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str14, 5, "names");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str17, 1, "\012");
Clo g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_entry, 7, 0};

V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329(V v_opts_240, V v_f_241, V v_width_242, V v_names_243, V v_o_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_get_n(v_opts_240, 3, 5);
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_width_242);
    heff_drop(v_t_247);
    V v_f_248 = v_f_241;
    V v_names_249 = v_names_243;
    V v_o_2410 = v_o_244;
    V v_t_2416;
    switch (heff_tag_of(v_names_249)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str0);
      break;
    }
    case TAG_Cons: {
      V v_n_2411 = heff_dup(heff_field(v_names_249, 0));
      V v_rest_2412 = heff_dup(heff_field(v_names_249, 1));
      V v_t_2413 = ({ V a_0 = v_n_2411; V r_ = (g_heff_2ebuild_2ebenchmarks_2espaced(a_0)); heff_drop(v_n_2411); r_; });
      V v_t_2414 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2413));
      V v_t_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str1); V a_1 = v_t_2414; V a_2 = v_rest_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(a_0, a_1, a_2)); heff_drop(v_rest_2412); r_; });
      v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str2), v_t_2415);
      break;
    }
    default: heff_nomatch(v_names_249);
    }
    V v_t_2417 = (g_list_2emap_24s723912745x1713553694(v_names_249));
    V v_x1_2418 = v_o_2410;
    V v_t_2439;
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Measured: {
      V v_n_2419 = heff_field(v_x1_2418, 0);
      V v_ns_2420 = heff_field(v_x1_2418, 1);
      V v_allocs_2421 = heff_field(v_x1_2418, 2);
      V v_bytes_2422 = heff_field(v_x1_2418, 3);
      heff_take_n(v_x1_2418, 15ULL, 4);
      V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str3), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_n_2419)})});
      V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str4), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_ns_2420)})});
      V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str5), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_allocs_2421)})});
      V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str6), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_bytes_2422)})});
      double v_t_2427 = (heff_from_int_f64(v_ns_2420) / heff_from_int_f64(heff_dup(v_n_2419)));
      V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str7), heff_tag_nf(TAG_JFloat, 1, 1u, (V[]){heff_word_f64(v_t_2427)})});
      V v_t_2429 = heff_tag_n(TAG_JInt, 1, (V[]){heff_intDiv_lent(v_bytes_2422, v_n_2419, 1)});
      V v_t_2430 = heff_tag_n(TAG_JInt, 1, (V[]){heff_intDiv(v_allocs_2421, v_n_2419)});
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str8), v_t_2430}), NTAG(TAG_Nil)});
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str9), v_t_2429}), v_t_2431});
      V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2433})});
      v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2434});
      break;
    }
    case TAG_FailedWith: {
      V v_why_2435 = heff_field(v_x1_2418, 0);
      V v_ru_24x1_2418_24FailedWith = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
      V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str10), heff_tag_at_n(v_ru_24x1_2418_24FailedWith, TAG_JString, 1, (V[]){v_why_2435})});
      v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      break;
    }
    case TAG_SkippedWith: {
      V v_why_2437 = heff_field(v_x1_2418, 0);
      V v_ru_24x1_2418_24SkippedWith = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
      V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str11), heff_tag_at_n(v_ru_24x1_2418_24SkippedWith, TAG_JString, 1, (V[]){v_why_2437})});
      v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x1_2418);
    }
    V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str12), heff_tag_n(TAG_JString, 1, (V[]){v_f_248})});
    V v_t_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str13), heff_tag_n(TAG_JString, 1, (V[]){v_t_2416})});
    V v_t_2442 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str14), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2417})});
    V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_t_2439})});
    V v_j_2444 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2443})});
    V v_str_2445 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str15); V a_1 = v_j_2444; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_j_2444, 1); r_; });
    V v_t_2446 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2445, ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str16)), NTAG(TAG_MkUnit)});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_z_245, v_z_246));
  } else {
    heff_drop(v_f_241);
    heff_drop(v_t_247);
    V v_str_2452 = ({ V a_0 = v_width_242; V a_1 = v_names_243; V a_2 = v_o_244; V r_ = (g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a_0, a_1, a_2)); heff_drop(v_names_243); heff_drop(v_o_244); r_; });
    V v_t_2453 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2452, ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_str17)), NTAG(TAG_MkUnit)});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_z_245, v_z_246));
  }
}
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1766227382x652886329(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str2, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str3, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str4, 11, "Benchmarks\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str5, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str6, 11, "benchMain [");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str7, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str8, 12, ": benchmarks");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str9, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str10, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str11, 19, "-DHEFF_COUNT_ALLOCS");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str12, 10, "heff bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str13, 4, "list");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str15, 36, "its benchmarks could not be listed: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str16, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str17, 51, "it does not import bench, which runs its benchmarks");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str18, 34, "its file is not among those loaded");
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam2(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam2, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam9(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam9, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam11(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam12(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam12, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam13(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam10(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam8(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam17(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam16(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam15(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam14(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam19(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam18(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam20(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam21(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_entry, 7, 0};

V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717(V v_opts_240, V v_f_241, V v_l_242, V v_c_243, V v_k_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_list_2efind_24s4435330x644005164_24cpr(heff_dup(v_c_243), heff_rfield(v_l_242, 0)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_src_2410 = v_field_249;
      V v_l_2411 = heff_dup(v_l_242);
      V v_c_2412 = v_c_243;
      V v_src_2413 = v_src_2410;
      V v_implicit_2414 = heff_take_field(v_src_2413, 6);
      V v_source_2415 = heff_take_field(v_src_2413, 4);
      V v_renames_2416 = heff_get_n(v_src_2413, 5, 8);
      V v_t_2417 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_2414, v_source_2415));
      HeffT4 v_t_2418 = ({ V a_0 = v_renames_2416; V a_1 = v_t_2417; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(a_0, a_1)); heff_drop(v_renames_2416); r_; });
      {
        V v_field_2419 = v_t_2418.f[0];
        heff_drop(v_t_2418.f[1]);
        heff_drop(v_t_2418.f[2]);
        heff_drop(v_t_2418.f[3]);
        HeffT2 v_t_2423 = ({ V a_0 = v_field_2419; HeffT2 r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(a_0)); heff_drop(v_field_2419); r_; });
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_q_2426 = v_field_2425;
            V v_q_2427 = v_q_2426;
            V v_bs_2428 = (g_heff_2ebuild_2edriver_2ebenchesOf(heff_dup(v_c_2412)));
            V v_x2_2429 = (g_list_2emap_24s467798769x1763085075(v_bs_2428));
            V v_t_2432;
            switch (heff_tag_of(v_x2_2429)) {
            case TAG_Nil: {
              v_t_2432 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str0);
              break;
            }
            case TAG_Cons: {
              V v_x_2430 = heff_field(v_x2_2429, 0);
              V v_xs_2431 = heff_field(v_x2_2429, 1);
              heff_take_n(v_x2_2429, 3ULL, 2);
              v_t_2432 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str1); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2429);
            }
            V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str2), heff_dup(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get())), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str3));
            V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, heff_dup(v_q_2427)), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str4));
            V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, heff_dup(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get())), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str5));
            V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, v_q_2427), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str6));
            V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, v_t_2432), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str7));
            V v_sources_2438 = ({ V b_0 = heff_get_n(v_c_2412, 0, 14); V a_1 = v_t_2437; V a_2 = heff_take_field(v_l_2411, 0); V r_ = (g_list_2emap_24s1681408447x1763680441(b_0, a_1, a_2)); heff_drop(b_0); r_; });
            V v_withMain_2439 = ({ V rv_0 = v_sources_2438; V rr_ = heff_rec_reuse_nf(v_l_2411, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_t_2440 = heff_strAppend(heff_dup(v_f_241), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str8));
            V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2440, MK_INT(2LL), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam0_clo)})});
            V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
            return (g_co_2eop_24s535099379x685970669(v_t_2443, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam1, 1, 7, (V[]){v_z_245, v_l_242, v_f_241, v_opts_240, v_k_244, v_withMain_2439, v_z_246})));
          } else {
            heff_drop_rec(v_l_242, 5);
            heff_drop_rec(v_l_2411, 5);
            heff_drop_rec(v_c_2412, 14);
            heff_drop(v_field_2425);
            V v_why_24117 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str17);
            V v_c_24118 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(v_opts_240, v_f_241, v_why_24117));
            return heff_tail(v_c_24118, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam20, 1, 3, (V[]){v_k_244, v_z_245, v_z_246})});
          }
        }
      }
    } else {
      heff_drop_rec(v_l_242, 5);
      heff_drop(v_c_243);
      heff_drop(v_field_249);
      V v_c_24120 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(v_opts_240, v_f_241, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str18)));
      return heff_tail(v_c_24120, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam21, 1, 3, (V[]){v_k_244, v_z_245, v_z_246})});
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam0(V self, V *args) {
  V v_t_2441 = args[0];
  return v_t_2441;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam2(V self, V *args) {
  V v_t_2445 = args[0];
  return v_t_2445;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam6(V self, V *args) {
  V v_x_2460 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_2454 = heff_env(self)[1];
  V v_k_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = v_x_2460;
  heff_room[1] = v_hd_2454;
  heff_room[2] = v_k_2455;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam5(V self, V *args) {
  V v_x_2458 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_why_2453 = heff_env(self)[2];
  V v_hd_2454 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_k_2455 = heff_env(self)[5];
  heff_drop(v_x_2458);
  heff_clo_take(self, 6);
  V v_t_2459 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(v_opts_240, v_f_241, v_why_2453));
  V f_ = v_t_2459;
  heff_room[0] = heff_dup(v_hd_2454);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam6, 1, 3, (V[]){v_k_244, v_hd_2454, v_k_2455});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam4(V self, V *args) {
  V v_why_2453 = args[0];
  V v_hd_2454 = args[1];
  V v_k_2455 = args[2];
  V v_x_2444 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2456 = heff_tag_n(TAG_End, 2, (V[]){v_x_2444, NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(v_hd_2454), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam5, 1, 6, (V[]){v_opts_240, v_f_241, v_why_2453, v_hd_2454, v_k_244, v_k_2455})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam9(V self, V *args) {
  V v_r_2469 = args[0];
  return v_r_2469;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam11(V self, V *args) {
  V v_x_2482 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_k_2462 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = v_x_2482;
  heff_room[1] = v_hd_2461;
  heff_room[2] = v_k_2462;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam12(V self, V *args) {
  V v_r_2486 = args[0];
  return v_r_2486;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam13(V self, V *args) {
  V v_x_2493 = args[0];
  V v_opts_2474 = heff_env(self)[0];
  V v_f_2475 = heff_env(self)[1];
  V v_p_2481 = heff_env(self)[2];
  V v_p_2483 = heff_env(self)[3];
  V v_prog_2480 = heff_env(self)[4];
  HeffT2 v_t_2494 = (g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(v_x_2493));
  {
    V v_field_2496 = v_t_2494.f[1];
    int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
    if ((v_tag_2495 == ((int64_t)0ULL))) {
      heff_clo_take(self, 5);
      heff_drop(v_prog_2480);
      V v_why_2497 = v_field_2496;
      V v_t_2498 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(v_opts_2474, v_f_2475, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str15), v_why_2497)));
      V f_ = v_t_2498;
      heff_room[0] = v_p_2481;
      heff_room[1] = v_p_2483;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_bs_2499 = v_field_2496;
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ebenchmarks_2erunListed_24s760044976x407352321(v_opts_2474, v_f_2475, v_prog_2480, v_bs_2499, v_p_2481, v_p_2483));
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam10(V self, V *args) {
  V v_x_2473 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_l_242 = heff_env(self)[2];
  V v_hd_2461 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_k_2462 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_opts_2474 = v_opts_240;
  V v_f_2475 = heff_dup(v_f_241);
  V v_st_2476 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
  V v_given_2477 = (g_heff_2ebuild_2ebenchmarks_2ebenchProgram(heff_get_n(v_l_242, 2, 5), v_f_241));
  V v_prog_2480;
  switch (heff_tag_of(v_x_2473)) {
  case TAG_Left: {
    heff_take_n(v_x_2473, 0ULL, 1);
    heff_drop(v_st_2476);
    v_prog_2480 = v_given_2477;
    break;
  }
  case TAG_Right: {
    V v_real_2479 = heff_field(v_x_2473, 0);
    heff_take_n(v_x_2473, 1ULL, 1);
    heff_drop(v_given_2477);
    v_prog_2480 = ({ V a_0 = v_st_2476; V a_1 = v_real_2479; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2476); heff_drop(v_real_2479); r_; });
    break;
  }
  default: heff_nomatch(v_x_2473);
  }
  V v_p_2481 = heff_dup(v_hd_2461);
  V v_p_2483 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam11, 1, 3, (V[]){v_k_244, v_hd_2461, v_k_2462});
  V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_opts_2474, 0)), NTAG(TAG_Nil)});
  V v_t_2485 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){heff_dup(v_prog_2480), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str13), v_t_2484}), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str14), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2485, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam12_clo)})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  return (g_co_2eop_24s535099379x685970669(v_t_2492, heff_dup(v_p_2481), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam13, 1, 5, (V[]){v_opts_2474, v_f_2475, v_p_2481, v_p_2483, v_prog_2480})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam8(V self, V *args) {
  V v_x_2465 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_2461 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_k_2462 = heff_env(self)[5];
  heff_drop(v_x_2465);
  V v_s_2466 = (g_heff_2ebuild_2ebenchmarks_2ebenchProgram(heff_dup(heff_rfield(v_l_242, 2)), heff_dup(v_f_241)));
  V v_path_2467 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2466));
  V v_t_2468 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2467; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2467); r_; });
  V v_p_231000_2470 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2468, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam9_clo)});
  V v_t_2471 = heff_tr(heff_call(((V)&g_co_2eop_24s1412293101x300983667_clo), 1, (V[]){v_p_231000_2470}));
  V v_t_2472 = heff_tr(g_std_2efilesystem_2efromSystem_24s141698176x1512134465(v_t_2471));
  heff_clo_take(self, 6);
  V f_ = v_t_2472;
  heff_room[0] = heff_dup(v_hd_2461);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam10, 1, 6, (V[]){v_opts_240, v_f_241, v_l_242, v_hd_2461, v_k_244, v_k_2462});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam7(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_x_2444 = heff_env(self)[0];
  V v_l_242 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2463 = heff_tag_n(TAG_End, 2, (V[]){v_x_2444, NTAG(TAG_MkUnit)});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(v_hd_2461), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam8, 1, 6, (V[]){v_l_242, v_f_241, v_hd_2461, v_opts_240, v_k_244, v_k_2462})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam17(V self, V *args) {
  V v_x_24111 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_24102 = heff_env(self)[1];
  V v_k_24103 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = v_x_24111;
  heff_room[1] = v_hd_24102;
  heff_room[2] = v_k_24103;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam16(V self, V *args) {
  V v_x_24109 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_why_24101 = heff_env(self)[2];
  V v_hd_24102 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_k_24103 = heff_env(self)[5];
  heff_drop(v_x_24109);
  heff_clo_take(self, 6);
  V v_t_24110 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(v_opts_240, v_f_241, v_why_24101));
  V f_ = v_t_24110;
  heff_room[0] = heff_dup(v_hd_24102);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam17, 1, 3, (V[]){v_k_244, v_hd_24102, v_k_24103});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam15(V self, V *args) {
  V v_x_24106 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_hd_24102 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_why_24101 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_k_24103 = heff_env(self)[6];
  heff_drop(v_x_24106);
  heff_clo_take(self, 7);
  V v_t_24107 = heff_tag_n(TAG_End, 2, (V[]){v_x_2444, NTAG(TAG_MkUnit)});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24108}), heff_dup(v_hd_24102), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam16, 1, 6, (V[]){v_opts_240, v_f_241, v_why_24101, v_hd_24102, v_k_244, v_k_24103})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam14(V self, V *args) {
  V v_why_24101 = args[0];
  V v_hd_24102 = args[1];
  V v_k_24103 = args[2];
  V v_x_2448 = heff_env(self)[0];
  V v_x_2444 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24104 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24105}), heff_dup(v_hd_24102), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam15, 1, 7, (V[]){v_x_2444, v_hd_24102, v_opts_240, v_f_241, v_why_24101, v_k_244, v_k_24103})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam19(V self, V *args) {
  V v_x_24116 = args[0];
  V v_next_24100 = heff_env(self)[0];
  V v_hd_24112 = heff_env(self)[1];
  V v_k_24113 = heff_env(self)[2];
  heff_drop(v_x_24116);
  heff_clo_take(self, 3);
  V f_ = v_next_24100;
  heff_room[0] = v_hd_24112;
  heff_room[1] = v_k_24113;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam18(V self, V *args) {
  V v_hd_24112 = args[0];
  V v_k_24113 = args[1];
  V v_x_2448 = heff_env(self)[0];
  V v_next_24100 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24114 = heff_tag_n(TAG_End, 2, (V[]){v_x_2448, NTAG(TAG_MkUnit)});
  V v_t_24115 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24115}), heff_dup(v_hd_24112), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam19, 1, 3, (V[]){v_next_24100, v_hd_24112, v_k_24113})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam3(V self, V *args) {
  V v_x_2448 = args[0];
  V v_l_242 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_x_2444 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_withMain_2439 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_t_2449 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(heff_rfield(v_l_242, 2)), heff_dup(v_f_241)));
  V v_t_2450 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(heff_rfield(v_l_242, 2)), heff_dup(v_f_241)));
  V v_t_2451 = (g_heff_2ebuild_2ebenchmarks_2ebenchProgram(heff_dup(heff_rfield(v_l_242, 2)), heff_dup(v_f_241)));
  V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
  heff_clo_take(self, 8);
  V v_next_24100 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998(((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str10), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str11), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam4, 3, 4, (V[]){heff_dup(v_x_2444), heff_dup(v_opts_240), heff_dup(v_f_241), heff_dup(v_k_244)}), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str12), v_t_2452, heff_dup(v_x_2444), v_t_2450, v_t_2451, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam7, 2, 5, (V[]){heff_dup(v_x_2444), v_l_242, heff_dup(v_f_241), heff_dup(v_opts_240), heff_dup(v_k_244)})));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s386347315x276354228(heff_dup(heff_rfield(v_opts_240, 4)), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam14, 3, 5, (V[]){heff_dup(v_x_2448), v_x_2444, v_opts_240, heff_dup(v_f_241), v_k_244}), v_withMain_2439, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get())}), heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str16)), v_f_241, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam18, 2, 2, (V[]){v_x_2448, v_next_24100}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam1(V self, V *args) {
  V v_x_2444 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_l_242 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_opts_240 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_withMain_2439 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2444), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_str9), MK_INT(0LL), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam2_clo)})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s535099379x685970669(v_t_2447, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam3, 1, 8, (V[]){v_l_242, v_f_241, v_x_2444, v_opts_240, v_k_244, v_withMain_2439, v_z_245, v_z_246})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam20(V self, V *args) {
  V v_x_24119 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = v_x_24119;
  heff_room[1] = v_z_245;
  heff_room[2] = v_z_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717_lam21(V self, V *args) {
  V v_x_24121 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = v_x_24121;
  heff_room[1] = v_z_245;
  heff_room[2] = v_z_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str1, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str2, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str3, 13, ": not checked");
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam9(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam8(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_entry, 7, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428(V v_lit_240, V v_lit_241, V v_lit_242, V v_opts_243, V v_f_244, V v_z_245, V v_z_246) {
top: ;
  V v_ran_247 = heff_take_field(v_lit_242, 0);
  V v_failed_248 = heff_get_n(v_lit_242, 1, 2);
  V v_c_249 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_tail(v_c_249, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam0, 1, 8, (V[]){v_f_244, v_z_245, v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_246, v_opts_243})});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam4(V self, V *args) {
  V v_a_2431 = args[0];
  V v_z_2432 = args[1];
  V v_z_2433 = args[2];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_ran_247 = heff_env(self)[2];
  V v_failed_248 = heff_env(self)[3];
  V v_ran_2434 = heff_take_field(v_a_2431, 0);
  V v_failed_2435 = heff_take_field(v_a_2431, 1);
  heff_clo_take(self, 4);
  V v_opts_2436 = v_lit_240;
  V v_x2_2437 = v_lit_241;
  V v_acc_2438 = ({ V rv_0 = heff_intAdd(v_ran_247, v_ran_2434); V rv_1 = heff_intAdd(v_failed_248, v_failed_2435); V rr_ = heff_rec_reuse_nf(v_a_2431, 0ULL, 2, shape_ran__failed, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_Nil: {
    return (g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s460610217x1918748399(v_opts_2436, v_acc_2438, v_z_2432, v_z_2433));
  }
  case TAG_Cons: {
    V v_f_2439 = heff_field(v_x2_2437, 0);
    V v_rest_2440 = heff_field(v_x2_2437, 1);
    heff_take_n(v_x2_2437, 3ULL, 2);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428(heff_dup(v_opts_2436), v_rest_2440, v_acc_2438, v_opts_2436, v_f_2439, v_z_2432, v_z_2433));
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_ran_247 = heff_env(self)[0];
  V v_failed_248 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_ran_2454 = heff_take_field(v_x_2453, 0);
  V v_failed_2455 = heff_take_field(v_x_2453, 1);
  heff_clo_take(self, 6);
  V v_t_2456 = ({ V rv_0 = heff_intAdd(v_ran_247, v_ran_2454); V rv_1 = heff_intAdd(v_failed_248, v_failed_2455); V rr_ = heff_rec_reuse_nf(v_x_2453, 0ULL, 2, shape_ran__failed, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_t_2456; V a_3 = v_z_245; V a_4 = v_z_246; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_241); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_cs_2417 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  V v_opts_243 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_ran_247 = heff_env(self)[5];
  V v_failed_248 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_z_246 = heff_env(self)[9];
  heff_drop(v_x_2443);
  heff_clo_take(self, 10);
  V v_t_2444 = heff_get_n(v_x_2414, 1, 5);
  V v_t_2451;
  switch (heff_tag_of(v_t_2444)) {
  case TAG_Nil: {
    HeffT2 v_t_2445 = ({ V a_0 = v_cs_2417; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_cs_2417); r_; });
    {
      V v_field_2447 = v_t_2445.f[1];
      int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
      if ((v_tag_2446 == ((int64_t)0ULL))) {
        V v_x_2448 = v_field_2447;
        v_t_2451 = v_x_2448;
      } else {
        heff_drop(v_field_2447);
        v_t_2451 = heff_strAppend(heff_dup(v_f_244), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str1));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2449 = heff_field(v_t_2444, 0);
    heff_take_n(v_t_2444, 1ULL, 2);
    heff_drop(v_cs_2417);
    v_t_2451 = v_why_2449;
    break;
  }
  default: heff_nomatch(v_t_2444);
  }
  V v_t_2452 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(v_opts_243, v_f_244, v_t_2451));
  V f_ = v_t_2452;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam7, 1, 6, (V[]){v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_cs_2417 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_opts_243 = heff_env(self)[4];
  V v_ran_247 = heff_env(self)[5];
  V v_failed_248 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_z_246 = heff_env(self)[9];
  heff_drop(v_x_2441);
  V v_t_2442 = (g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067(v_cs_2417));
  heff_clo_take(self, 10);
  V f_ = v_t_2442;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam6, 1, 10, (V[]){v_x_2414, v_cs_2417, v_f_244, v_opts_243, v_z_245, v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam9(V self, V *args) {
  V v_x_2467 = args[0];
  V v_ran_247 = heff_env(self)[0];
  V v_failed_248 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_ran_2468 = heff_take_field(v_x_2467, 0);
  V v_failed_2469 = heff_take_field(v_x_2467, 1);
  heff_clo_take(self, 6);
  V v_t_2470 = ({ V rv_0 = heff_intAdd(v_ran_247, v_ran_2468); V rv_1 = heff_intAdd(v_failed_248, v_failed_2469); V rr_ = heff_rec_reuse_nf(v_x_2467, 0ULL, 2, shape_ran__failed, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_t_2470; V a_3 = v_z_245; V a_4 = v_z_246; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_241); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam8(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_cs_2417 = heff_env(self)[1];
  V v_f_244 = heff_env(self)[2];
  V v_opts_243 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_ran_247 = heff_env(self)[5];
  V v_failed_248 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_z_246 = heff_env(self)[9];
  heff_drop(v_x_2457);
  heff_clo_take(self, 10);
  V v_t_2458 = heff_get_n(v_x_2414, 1, 5);
  V v_t_2465;
  switch (heff_tag_of(v_t_2458)) {
  case TAG_Nil: {
    HeffT2 v_t_2459 = ({ V a_0 = v_cs_2417; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(a_0)); heff_drop(v_cs_2417); r_; });
    {
      V v_field_2461 = v_t_2459.f[1];
      int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
      if ((v_tag_2460 == ((int64_t)0ULL))) {
        V v_x_2462 = v_field_2461;
        v_t_2465 = v_x_2462;
      } else {
        heff_drop(v_field_2461);
        v_t_2465 = heff_strAppend(heff_dup(v_f_244), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str3));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2463 = heff_field(v_t_2458, 0);
    heff_take_n(v_t_2458, 1ULL, 2);
    heff_drop(v_cs_2417);
    v_t_2465 = v_why_2463;
    break;
  }
  default: heff_nomatch(v_t_2458);
  }
  V v_t_2466 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s425893047x1715789248(v_opts_243, v_f_244, v_t_2465));
  V f_ = v_t_2466;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam9, 1, 6, (V[]){v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_ran_247 = heff_env(self)[1];
  V v_failed_248 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_opts_243 = heff_env(self)[7];
  V v_f_244 = heff_env(self)[8];
  V v_cs_2417 = heff_get_n(v_x_2416, 0, 2);
  HeffT2 v_t_2418 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2417));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_c_2421 = v_field_2420;
      V v_t_2422 = heff_dup(heff_rfield(v_x_2414, 1));
      V v_t_2426;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nil: {
        V v_x1_2423 = (g_list_2eany_24s1740858080x874135214(v_cs_2417));
        v_t_2426 = heff_bool(!(heff_dup(v_x1_2423) == NTAG(TAG_True)));
        heff_drop(v_x1_2423);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2422, 0ULL, 2);
        v_t_2426 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_cs_2417);
        heff_drop(v_t_2426);
        V v_x1_2427 = (g_heff_2ebuild_2edriver_2ebenchesOf(heff_dup(v_c_2421)));
        switch (heff_tag_of(v_x1_2427)) {
        case TAG_Nil: {
          heff_clo_take(self, 9);
          heff_drop_rec(v_x_2414, 5);
          heff_drop(v_opts_243);
          heff_drop(v_f_244);
          heff_drop(v_c_2421);
          V v_t_2428 = heff_rec_n(2, shape_ran__failed, (V[]){heff_intAdd(v_ran_247, MK_INT(0LL)), heff_intAdd(v_failed_248, MK_INT(0LL))});
          return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_t_2428; V a_3 = v_z_245; V a_4 = v_z_246; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1816312510x856403898(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_241); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2427, 0ULL, 2);
          heff_clo_take(self, 9);
          return (g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s544823243x1976308717(v_opts_243, v_f_244, v_x_2414, v_c_2421, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam4, 3, 4, (V[]){v_lit_240, v_lit_241, v_ran_247, v_failed_248}), v_z_245, v_z_246));
        }
        default: return heff_nomatch(v_x1_2427);
        }
      } else {
        heff_drop(v_c_2421);
        heff_drop(v_t_2426);
        heff_clo_take(self, 9);
        return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str0), heff_dup(heff_rfield(v_x_2414, 1)), MK_INT(0LL), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam5, 1, 10, (V[]){v_cs_2417, v_z_245, v_x_2414, v_f_244, v_opts_243, v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_246})));
      }
    } else {
      heff_drop(v_field_2420);
      heff_clo_take(self, 9);
      return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_str2), heff_dup(heff_rfield(v_x_2414, 1)), MK_INT(0LL), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam8, 1, 10, (V[]){v_x_2414, v_cs_2417, v_f_244, v_opts_243, v_z_245, v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_246})));
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_ran_247 = heff_env(self)[2];
  V v_failed_248 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_opts_243 = heff_env(self)[7];
  V v_f_244 = heff_env(self)[8];
  V v_t_2413 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2412, heff_dup(heff_rfield(v_x_2411, 4))));
  heff_clo_take(self, 9);
  V v_x_2414 = (g_list_2efoldl_24s571074576x1179600767(v_x_2411, v_t_2413));
  V v_t_2415 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_x_2414)));
  V f_ = v_t_2415;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam3, 1, 9, (V[]){v_x_2414, v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_245, v_z_246, v_opts_243, v_f_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_ran_247 = heff_env(self)[1];
  V v_failed_248 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  V v_opts_243 = heff_env(self)[6];
  V v_f_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam2, 1, 9, (V[]){v_x_2411, v_z_245, v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_246, v_opts_243, v_f_244})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_ran_247 = heff_env(self)[2];
  V v_failed_248 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_opts_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2410, heff_dup(v_f_244), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s670758019x1851878428_lam1, 1, 8, (V[]){v_z_245, v_ran_247, v_failed_248, v_lit_240, v_lit_241, v_z_246, v_opts_243, v_f_244})));
}