// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailedWith 25914
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Measured 52135
#define TAG_Nanos 3335
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_SkippedWith 54656
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Times 15230
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alias 294261354
#define LBL_bind 9519364
#define LBL_count 296209705
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_failed 665164648
#define LBL_json 9767343
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_pattern 1588251091
#define LBL_ran 322201
#define LBL_style 311138763
#define LBL_time 10055572
static uint32_t shape_pattern__time__count__json[] = {LBL_pattern, LBL_time, LBL_count, LBL_json};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1069191919x261979480(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1069191919x261979480_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1069191919x261979480_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchProgram_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_clo;
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647(V);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_clo;
V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V, V);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo;
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo;
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo;
V g_heff_2ebuild_2ebenchmarks_2eperOp(V, V);
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo;
V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo;
V g_heff_2ebuild_2ebenchmarks_2eresultLine(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces(V);
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V, V);
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo;
V g_heff_2ebuild_2ebenchmarks_2etenTo(V);
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo;
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V, V);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo;
V g_heff_2ebuild_2etesting_2elastLines(V, V);
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elastLines_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528_clo;
V g_json_2ewriteInto(V, V);
V g_json_2ewriteInto_entry(V self, V *a);
extern Clo g_json_2ewriteInto_clo;
V g_list_2eall_24s2093734251x1702493483(V, V, V, V);
V g_list_2eall_24s2093734251x1702493483_entry(V self, V *a);
extern Clo g_list_2eall_24s2093734251x1702493483_clo;
HeffT2 g_list_2efind_24s1136367117x833793205_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str0, 1, "h");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str1, 1, "m");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str2, 1, "s");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str3, 2, "ms");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str4, 3, "\302\265s");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str5, 2, "us");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str6, 2, "ns");

static V g_heff_2ebuild_2ebenchmarks_2eunits_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2eunits_st;
static V g_heff_2ebuild_2ebenchmarks_2eunits_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str0), MK_INT(3600000000000LL)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str1), MK_INT(60000000000LL)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str2), MK_INT(1000000000LL)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str3), MK_INT(1000000LL)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str4), MK_INT(1000LL)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str5), MK_INT(1000LL)}), v_t_244});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str6), MK_INT(1LL)}), v_t_245});
}
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2eunits_st)) return g_heff_2ebuild_2ebenchmarks_2eunits_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2eunits_val, &g_heff_2ebuild_2ebenchmarks_2eunits_st, g_heff_2ebuild_2ebenchmarks_2eunits_init);
}

static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2edefaultTime_st;
static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_init(void) {
  return heff_tag_n(TAG_Nanos, 1, (V[]){MK_INT(1000000000LL)});
}
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2edefaultTime_st)) return g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2edefaultTime_val, &g_heff_2ebuild_2ebenchmarks_2edefaultTime_st, g_heff_2ebuild_2ebenchmarks_2edefaultTime_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str1, 1, " ");
Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaces_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2espaces(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str0);
  } else {
    V v_s_241 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str1);
    return (g_heff_2ebuild_2ebenchmarks_2espaces_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_241));
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2espaces(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecapital_str0, 26, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecapital_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ecapital(V v_s_240) {
top: ;
  if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_240, 0))) && ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))))) {
    int64_t v_t_241 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)97ULL));
    int64_t v_t_242 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)96ULL));
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
    return heff_strAppend(heff_strSlice(((V)&g_heff_2ebuild_2ebenchmarks_2ecapital_str0), heff_box_word(v_t_241), heff_box_word(v_t_242)), v_t_243);
  } else {
    return v_s_240;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecapital(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0, 1, "0");
Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V v_n_240, V v_s_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), heff_strLength_lent(v_s_241, 0))) {
    heff_drop(v_n_240);
    return v_s_241;
  } else {
    V t_0 = v_n_240;
    V t_1 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0), v_s_241);
    v_n_240 = t_0;
    v_s_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ezeroPadded(a[0], a[1]);
}
Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V v_total_240, V v_n_241, V v_box_24k_242) {
  int64_t v_k_242 = heff_unbox_word(v_box_24k_242);
top: ;
  if ((((int64_t)7ULL) <= v_k_242)) {
    heff_drop(v_total_240);
    heff_drop(v_n_241);
    return heff_box_word(v_k_242);
  } else {
    V v_t_243 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_box_word((v_k_242 + ((int64_t)2ULL)))));
    V v_x_244 = heff_intMul(heff_dup(v_total_240), v_t_243);
    if (heff_intLe_c(heff_intMul(MK_INT(99995LL), heff_dup(v_n_241)), v_x_244)) {
      heff_drop(v_total_240);
      heff_drop(v_n_241);
      return heff_box_word(v_k_242);
    } else {
      V t_0 = v_total_240;
      V t_1 = v_n_241;
      int64_t t_2 = (v_k_242 + ((int64_t)1ULL));
      v_total_240 = t_0;
      v_n_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eplacesOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str3, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str4, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str5, 7, " ns/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str6, 6, " B/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str7, 10, " allocs/op");
Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eresultLine_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2eresultLine(V v_width_240, V v_names_241, V v_n_242, V v_ns_243, V v_allocs_244, V v_bytes_245) {
top: ;
  V v_s_2411;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_s_2411 = ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str0);
    break;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_names_241, 0);
    V v_rest_247 = heff_field(v_names_241, 1);
    V v_t_248 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_246));
    V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_248));
    V v_t_2410 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str1), v_t_249, v_rest_247));
    v_s_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str2), v_t_2410);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2412 = heff_intSub(v_width_240, heff_strLength_lent(v_s_2411, 0));
  V v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2espaces(v_t_2412));
  V v_t_2414 = heff_strAppend(heff_strAppend(v_s_2411, v_t_2413), ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str3));
  V v_s_2415 = heff_intShow(heff_dup(v_n_242));
  int64_t v_t_2416 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2415, 0)));
  V v_t_2417 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2416)));
  V v_t_2418 = heff_strAppend(v_t_2414, heff_strAppend(v_t_2417, v_s_2415));
  V v_t_2419 = (g_heff_2ebuild_2ebenchmarks_2eperOp(v_ns_243, heff_dup(v_n_242)));
  V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str4)), v_t_2419);
  V v_s_2421 = heff_intShow(heff_intDiv(v_bytes_245, heff_dup(v_n_242)));
  int64_t v_t_2422 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2421, 0)));
  V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2422)));
  V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str5)), heff_strAppend(v_t_2423, v_s_2421));
  V v_s_2425 = heff_intShow(heff_intDiv(v_allocs_244, v_n_242));
  int64_t v_t_2426 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2425, 0)));
  V v_t_2427 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2426)));
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str6)), heff_strAppend(v_t_2427, v_s_2425));
  return heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str7));
}
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2eresultLine(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3, 10, "--- FAIL: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13, 10, "--- SKIP: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19, 1, "\012");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V v_width_240, V v_names_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Measured: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ns_244 = heff_field(v_x3_242, 1);
    V v_allocs_245 = heff_field(v_x3_242, 2);
    V v_bytes_246 = heff_field(v_x3_242, 3);
    return (g_heff_2ebuild_2ebenchmarks_2eresultLine(v_width_240, v_names_241, heff_dup(v_n_243), heff_dup(v_ns_244), heff_dup(v_allocs_245), heff_dup(v_bytes_246)));
  }
  case TAG_FailedWith: {
    V v_why_247 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2413;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0);
      break;
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_names_241, 0);
      V v_rest_249 = heff_field(v_names_241, 1);
      V v_t_2410 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_248));
      V v_t_2411 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2410));
      V v_t_2412 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1), v_t_2411, v_rest_249));
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2), v_t_2412);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3), v_t_2413), ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4));
    V v_t_2415 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5); V a_1 = v_why_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6), v_why_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_2416 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7), v_t_2415));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return heff_strAppend(v_t_2414, v_t_2419);
  }
  case TAG_SkippedWith: {
    V v_why_2420 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2426;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10);
      break;
    }
    case TAG_Cons: {
      V v_n_2421 = heff_field(v_names_241, 0);
      V v_rest_2422 = heff_field(v_names_241, 1);
      V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_2421));
      V v_t_2424 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2423));
      V v_t_2425 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11), v_t_2424, v_rest_2422));
      v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12), v_t_2425);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13), v_t_2426), ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14));
    V v_t_2428 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15); V a_1 = v_why_2420; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16), v_why_2420, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_2429 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17), v_t_2428));
    V v_t_2432;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      v_t_2432 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    return heff_strAppend(v_t_2427, v_t_2432);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_name_243 = heff_dup(heff_rfield(v_i_241, 0));
    V v_alias_244 = heff_dup(heff_rfield(v_i_241, 1));
    if (heff_strEq_c(v_name_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0))) {
      V v_f_246;
      switch (heff_tag_of(v_alias_244)) {
      case TAG_Nothing: {
        v_f_246 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_245 = heff_field(v_alias_244, 0);
        heff_take_n(v_alias_244, 1ULL, 1);
        v_f_246 = heff_strAppend(v_alias_245, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_alias_244);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_alias_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str0, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str1, 8, "main.exe");
Clo g_heff_2ebuild_2ebenchmarks_2ebenchProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchProgram(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_240), v_file_241));
  V v_t_243 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_p_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_p_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str0);
    break;
  }
  case TAG_Windows: {
    v_p_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_st_245 = heff_get_n(v_paths_240, 5, 6);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_242));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_p_244));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  return ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchProgram(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0, 12, "heff:abandon");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1, 12, "it abandoned");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9, 3, "it ");
Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V v_r_240) {
top: ;
  V v_err_241 = heff_take_field(v_r_240, 2);
  V v_ended_242 = heff_get_n(v_r_240, 0, 3);
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0), v_err_241, MK_INT(0LL), 5))) {
    heff_drop(v_err_241);
    heff_drop(v_ended_242);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1);
  } else {
    V v_t_245;
    switch (heff_tag_of(v_ended_242)) {
    case TAG_Exited: {
      V v_n_243 = heff_field(v_ended_242, 0);
      heff_take_n(v_ended_242, 1ULL, 1);
      v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2), heff_intShow(v_n_243));
      break;
    }
    case TAG_Signalled: {
      V v_n_244 = heff_field(v_ended_242, 0);
      heff_take_n(v_ended_242, 1ULL, 1);
      v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3), heff_intShow(v_n_244));
      break;
    }
    case TAG_TimedOut: {
      v_t_245 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4);
      break;
    }
    case TAG_NotRun: {
      v_t_245 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5);
      break;
    }
    default: heff_nomatch(v_ended_242);
    }
    V v_t_247;
    if (heff_strEq_c_lent(v_err_241, ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6), 2)) {
      heff_drop(v_err_241);
      v_t_247 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7);
    } else {
      V v_t_246 = ({ V a_0 = MK_INT(20LL); V a_1 = v_err_241; V r_ = (g_heff_2ebuild_2etesting_2elastLines(a_0, a_1)); heff_drop(v_err_241); r_; });
      v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8), v_t_246);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9), v_t_245), v_t_247);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eendedWhy(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str2, 18, "heff bench: --run ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str5, 1, "x");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str7, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str8, 19, "heff bench: --time ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str9, 57, ": not a duration (1s, 1.5s, 500ms, 2m) nor a count (100x)");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str11, 0, "");
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam2(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam2, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam5(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam5, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam8(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam9(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam11(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam10(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam3(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_entry, 4, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702(V v_pattern_240, V v_time_241, V v_count_242, V v_json_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_pattern_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_t_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
  HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
  V v_c_2430;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_why_2411 = v_field_2410;
      v_c_2430 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam0, 2, 2, (V[]){heff_dup(v_pattern_240), v_why_2411});
    } else {
      V v_x_2427 = v_field_2410;
      heff_drop(v_x_2427);
      v_c_2430 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam2_clo);
    }
  }
  return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam3, 2, 5, (V[]){v_c_2430, v_time_241, v_count_242, heff_dup(v_pattern_240), v_json_243});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(2LL), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_pattern_240 = heff_env(self)[0];
  V v_why_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415;
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_pattern_240, 0);
    heff_take_n(v_pattern_240, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str2), v_t_2415), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str3));
  V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, v_why_2411), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str4));
  V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2417, NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  args[0] = v_t_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam1, 1, 2, (V[]){v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam2(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam5(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam8(V self, V *args) {
  V v_x_2485 = args[0];
  V v_k_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2485);
  V f_ = v_k_2464;
  args[0] = heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam7(V self, V *args) {
  V v_x_2476 = args[0];
  V v_malg_2466 = heff_env(self)[0];
  V v_bind_2465 = heff_env(self)[1];
  V v_k_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2476);
  V v_t_2477 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(v_malg_2466, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = v_bind_2465;
  heff_room[0] = v_t_2484;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam8, 1, 1, (V[]){v_k_2464});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam6(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k_2464 = args[1];
  V v_s_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2465 = heff_take_field(v_hd_2463, 1);
  V v_malg_2466 = heff_get_n(v_hd_2463, 2, 3);
  V v_t_2467 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str8), v_s_2437), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str9));
  V v_t_2468 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2467, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str10)), NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tr(heff_call(heff_dup(v_malg_2466), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})}));
  V f_ = heff_dup(v_bind_2465);
  args[0] = v_t_2475;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam7, 1, 3, (V[]){v_malg_2466, v_bind_2465, v_k_2464});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam9(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k_2488 = args[1];
  V v_t_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2487);
  V f_ = v_k_2488;
  args[0] = v_t_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam11(V self, V *args) {
  V v_x_2492 = args[0];
  V v_pattern_240 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  V v_x_2490 = heff_env(self)[2];
  V v_json_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2494;
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_2494 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str11);
    break;
  }
  case TAG_Just: {
    V v_x_2493 = heff_field(v_pattern_240, 0);
    heff_take_n(v_pattern_240, 1ULL, 1);
    v_t_2494 = v_x_2493;
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V f_ = v_k_2432;
  args[0] = heff_rec_n(4, shape_pattern__time__count__json, (V[]){v_t_2494, v_x_2490, v_x_2492, v_json_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam10(V self, V *args) {
  V v_x_2490 = args[0];
  V v_count_242 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_pattern_240 = heff_env(self)[2];
  V v_k_2432 = heff_env(self)[3];
  V v_json_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2491 = (g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647(v_count_242));
  V f_ = v_c_2491;
  heff_room[0] = v_hd_2431;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam11, 1, 4, (V[]){v_pattern_240, v_k_2432, v_x_2490, v_json_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_time_241 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_count_242 = heff_env(self)[2];
  V v_pattern_240 = heff_env(self)[3];
  V v_k_2432 = heff_env(self)[4];
  V v_json_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2433);
  V v_x1_2434 = v_time_241;
  V v_c_2489;
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nothing: {
    v_c_2489 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam5_clo);
    break;
  }
  case TAG_Just: {
    V v_s_2437 = heff_field(v_x1_2434, 0);
    V v_ru_24x1_2434_24Just = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
    V v_s_2438 = heff_dup(v_s_2437);
    int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_s_2438, 0)) - ((int64_t)1ULL));
    V v_t_2440 = heff_strSlice(heff_dup(v_s_2438), heff_box_word(v_t_2439), heff_strLength_lent(v_s_2438, 0));
    V v_t_2462;
    if (heff_strEq_c(v_t_2440, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str5))) {
      int64_t v_t_2441 = (heff_unbox_word(heff_strLength_lent(v_s_2438, 0)) - ((int64_t)1ULL));
      V v_s_2442 = heff_strSlice(v_s_2438, MK_INT(0LL), heff_box_word(v_t_2441));
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_2442, 0)))) {
        int64_t v_t_2443 = (heff_unbox_word(heff_strLength_lent(v_s_2442, 0)) - ((int64_t)1ULL));
        V v_t_2444 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_2443)));
        V v_t_2445 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_2442; V a_2 = MK_INT(57LL); V a_3 = v_t_2444; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_2444); r_; });
        if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
          heff_drop(v_t_2445);
          HeffT2 v_t_2446 = ({ V a_0 = v_s_2442; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_2442); r_; });
          {
            V v_field_2448 = v_t_2446.f[1];
            int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
            if ((v_tag_2447 == ((int64_t)0ULL))) {
              V v_n_2449 = v_field_2448;
              if (heff_intLt_c_lent(MK_INT(0LL), v_n_2449, 1)) {
                v_t_2462 = heff_tag_at_n(v_ru_24x1_2434_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Times, 1, (V[]){v_n_2449})});
              } else {
                heff_drop_cell(v_ru_24x1_2434_24Just, 1);
                heff_drop(v_n_2449);
                v_t_2462 = NTAG(TAG_Nothing);
              }
            } else {
              heff_drop_cell(v_ru_24x1_2434_24Just, 1);
              heff_drop(v_field_2448);
              v_t_2462 = NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop_cell(v_ru_24x1_2434_24Just, 1);
          heff_drop(v_s_2442);
          heff_drop(v_t_2445);
          v_t_2462 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_cell(v_ru_24x1_2434_24Just, 1);
        heff_drop(v_s_2442);
        v_t_2462 = NTAG(TAG_Nothing);
      }
    } else {
      V v_s_2450 = heff_dup(v_s_2438);
      HeffT2 v_t_2451 = ({ V a_0 = v_s_2438; V b_1 = heff_dup(g_heff_2ebuild_2ebenchmarks_2eunits_get()); HeffT2 r_ = (g_list_2efind_24s1136367117x833793205_24cpr(a_0, b_1)); heff_drop(v_s_2438); heff_drop(b_1); r_; });
      {
        V v_field_2453 = v_t_2451.f[1];
        int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
        if ((v_tag_2452 == ((int64_t)0ULL))) {
          V v_x21_2454 = v_field_2453;
          switch (heff_tag_of(v_x21_2454)) {
          case TAG_MkPair: {
            V v_u_2455 = heff_field(v_x21_2454, 0);
            V v_unit_2456 = heff_field(v_x21_2454, 1);
            heff_take_n(v_x21_2454, 3ULL, 2);
            int64_t v_t_2457 = (heff_unbox_word(heff_strLength_lent(v_s_2450, 0)) - heff_unbox_word(heff_strLength(v_u_2455)));
            V v_s_2458 = heff_strSlice(v_s_2450, MK_INT(0LL), heff_box_word(v_t_2457));
            V v_t_2459 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str6); V a_1 = v_s_2458; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_str7), v_s_2458, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2458); r_; });
            V v_t_2460 = ({ V a_0 = v_unit_2456; V a_1 = v_t_2459; V r_ = heff_tr(g_heff_2ebuild_2ebenchmarks_2edecimalParts(a_0, a_1)); heff_drop(v_t_2459); r_; });
            switch (heff_tag_of(v_t_2460)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24x1_2434_24Just, 1);
              v_t_2462 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_n_2461 = heff_field(v_t_2460, 0);
              V v_ru_24t_2460_24Just = heff_take_reuse_n(v_t_2460, 1ULL, 1);
              if (heff_intLt_c_lent(MK_INT(0LL), v_n_2461, 1)) {
                v_t_2462 = heff_tag_at_n(v_ru_24x1_2434_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24t_2460_24Just, TAG_Nanos, 1, (V[]){v_n_2461})});
              } else {
                heff_drop_cell(v_ru_24x1_2434_24Just, 1);
                heff_drop(v_n_2461);
                heff_drop_cell(v_ru_24t_2460_24Just, 1);
                v_t_2462 = NTAG(TAG_Nothing);
              }
              break;
            }
            default: heff_nomatch(v_t_2460);
            }
            break;
          }
          default: heff_nomatch(v_x21_2454);
          }
        } else {
          heff_drop_cell(v_ru_24x1_2434_24Just, 1);
          heff_drop(v_s_2450);
          heff_drop(v_field_2453);
          v_t_2462 = NTAG(TAG_Nothing);
        }
      }
    }
    switch (heff_tag_of(v_t_2462)) {
    case TAG_Nothing: {
      v_c_2489 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam6, 2, 1, (V[]){v_s_2437});
      break;
    }
    case TAG_Just: {
      V v_t_2486 = heff_field(v_t_2462, 0);
      heff_take_n(v_t_2462, 1ULL, 1);
      heff_drop(v_s_2437);
      v_c_2489 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam9, 2, 1, (V[]){v_t_2486});
      break;
    }
    default: heff_nomatch(v_t_2462);
    }
    break;
  }
  default: heff_nomatch(v_x1_2434);
  }
  V f_ = v_c_2489;
  heff_room[0] = heff_dup(v_hd_2431);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam10, 1, 5, (V[]){v_count_242, v_hd_2431, v_pattern_240, v_k_2432, v_json_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam3(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_time_241 = heff_env(self)[1];
  V v_count_242 = heff_env(self)[2];
  V v_pattern_240 = heff_env(self)[3];
  V v_json_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2430;
  args[0] = heff_dup(v_hd_2431);
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s888035328x945568702_lam4, 1, 6, (V[]){v_time_241, v_hd_2431, v_count_242, v_pattern_240, v_k_2432, v_json_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_str1, 71, "heff bench: no bench/ here: bench at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_str2, 5, "bench");
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam8(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam5(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_str0)));
    V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_244 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam0_clo)});
    V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    V v_c_2428 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2410}), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam1, 3, 1, (V[]){v_path_241})));
    return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam5, 2, 1, (V[]){v_c_2428});
  }
  case TAG_Cons: {
    V v_t_2457 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(v_t_2457, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam3(V self, V *args) {
  V v_n_2419 = args[0];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2419));
  return (g_std_2epath_2ejoin(v_path_241, v_t_2420));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_z_2417 = args[1];
  V v_z_2418 = args[2];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2417);
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam3, 1, 1, (V[]){v_path_241}), v_x_2416));
  V v_x_2422 = (g_list_2emap_24s219049803x1458391381(v_x_2421));
  V f_ = v_z_2418;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2424));
  return (g_std_2epath_2ejoin(v_path_241, v_t_2425));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_2412 = args[1];
  V v_z_2413 = args[2];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    V v_err_2414 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Left = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2411_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2414})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2415, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam2, 3, 1, (V[]){v_path_241}), v_z_2412, v_z_2413));
  }
  case TAG_Right: {
    V v_x_2423 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop(v_z_2412);
    V v_x_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam4, 1, 1, (V[]){v_path_241}), v_x_2423));
    V v_x_2427 = (g_list_2emap_24s219049803x1458391381(v_x_2426));
    V f_ = v_z_2413;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2427});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  heff_room[0] = v_t_2449;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam8, 1, 1, (V[]){v_k_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2429 = heff_env(self)[0];
  V v_k_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 0ULL, 1);
    V v_t_2433 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_str1), NTAG(TAG_MkUnit)});
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2431_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2429, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})}));
    V f_ = heff_dup(heff_rfield(v_hd_2429, 1));
    heff_room[0] = v_t_2440;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam7, 1, 2, (V[]){v_hd_2429, v_k_2430});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2431, 0ULL, 1);
    V v_t_2452 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_str2)});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
    V v_t_2454 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s938117866x1808092528(v_t_2453, NTAG(TAG_Nil)));
    V f_ = v_t_2454;
    heff_room[0] = v_hd_2429;
    heff_room[1] = v_k_2430;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2428;
  args[0] = heff_dup(v_hd_2429);
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1963446977x63838568_lam6, 1, 2, (V[]){v_hd_2429, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str1, 25, "heff bench: no benchmarks");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str2, 33, "heff bench: no benchmarks match '");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str3, 1, "'");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str4, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_entry, 4, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  V v_ran_244 = heff_take_field(v_acc_241, 0);
  V v_failed_245 = heff_get_n(v_acc_241, 1, 2);
  if ((heff_intEq_c_lent(v_ran_244, MK_INT(0LL), 2) && heff_intEq_c_lent(v_failed_245, MK_INT(0LL), 2))) {
    heff_drop(v_ran_244);
    heff_drop(v_failed_245);
    V v_t_247;
    if (heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 0)), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str0))) {
      heff_drop_rec(v_opts_240, 4);
      v_t_247 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str1);
    } else {
      V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str2), heff_get_n(v_opts_240, 0, 4));
      v_t_247 = heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str3));
    }
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_str4)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
    return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_lam0, 1, 2, (V[]){v_p_242, v_p_243})});
  } else {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_ran_244);
    if (heff_intLt_c(MK_INT(0LL), v_failed_245)) {
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_242, v_p_243));
    } else {
      heff_drop_rec(v_p_242, 3);
      return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_242, v_p_243));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str0, 4, "file");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str1, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str4, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str8, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str11, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(V v_opts_240, V v_f_241, V v_why_242) {
top: ;
  V v_t_243 = heff_get_n(v_opts_240, 3, 4);
  V v_c_2430;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str0), heff_tag_n(TAG_JString, 1, (V[]){v_f_241})});
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str1), heff_tag_n(TAG_JString, 1, (V[]){v_why_242})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    V v_str_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str2); V a_1 = v_t_247; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_247, 1); r_; });
    V v_t_249 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_248, ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str3)), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    v_c_2430 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})}));
  } else {
    heff_drop(v_t_243);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str4), v_f_241), ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str5));
    V v_t_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str6); V a_1 = v_why_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str7), v_why_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_why_242); r_; });
    V v_x2_2418 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str8), v_t_2417));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str10); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_str_2422 = heff_strAppend(v_t_2416, v_t_2421);
    V v_t_2423 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2422, ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_str11)), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    v_c_2430 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
  }
  return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_lam0, 2, 1, (V[]){v_c_2430});
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  V f_ = v_k_2432;
  args[0] = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(1LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_lam0(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_lam1, 1, 1, (V[]){v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431_entry, 5, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431(V v_opts_240, V v_x2_241, V v_acc_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532(v_opts_240, v_acc_242, v_z_243, v_z_244));
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1069191919x261979480(heff_dup(v_opts_240), heff_dup(v_rest_246), v_acc_242, v_opts_240, heff_dup(v_f_245), v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s1653706414x382954431(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}