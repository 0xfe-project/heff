// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailedWith 25914
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Measured 52135
#define TAG_Nanos 3335
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_RealPath 18882
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_SkippedWith 54656
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Times 15230
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alias 294261354
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_count 296209705
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_json 9767343
#define LBL_keep 9783372
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_ran 322201
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_time 10055572
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void);
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchText(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchText_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_clo;
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646(V);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_clo;
V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V, V);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo;
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void);
HeffT2 g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr(V, V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo;
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo;
V g_heff_2ebuild_2ebenchmarks_2eperOp(V, V);
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo;
V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo;
V g_heff_2ebuild_2ebenchmarks_2eresultLine(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo;
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_clo;
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_clo;
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_clo;
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces(V);
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V, V);
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo;
V g_heff_2ebuild_2ebenchmarks_2etenTo(V);
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo;
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041(V);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_clo;
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V, V);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eall_24s443219008x474491297(V, V, V, V);
V g_list_2eall_24s443219008x474491297_entry(V self, V *a);
extern Clo g_list_2eall_24s443219008x474491297_clo;
HeffT2 g_list_2efind_24s1973550603x1701528639_24cpr(V, V);
V g_list_2efoldl_24f470245410x241064089(V, V, V);
V g_list_2efoldl_24f470245410x241064089_entry(V self, V *a);
extern Clo g_list_2efoldl_24f470245410x241064089_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str0, 1, "h");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str1, 1, "m");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str2, 1, "s");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str3, 2, "ms");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str4, 3, "\302\265s");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str5, 2, "us");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str6, 2, "ns");

static V g_heff_2ebuild_2ebenchmarks_2eunits_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2eunits_st;
static V g_heff_2ebuild_2ebenchmarks_2eunits_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str0), MK_INT(3600000000000LL)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str1), MK_INT(60000000000LL)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str2), MK_INT(1000000000LL)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str3), MK_INT(1000000LL)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str4), MK_INT(1000LL)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str5), MK_INT(1000LL)}), v_t_244});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str6), MK_INT(1LL)}), v_t_245});
}
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2eunits_st)) return g_heff_2ebuild_2ebenchmarks_2eunits_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2eunits_val, &g_heff_2ebuild_2ebenchmarks_2eunits_st, g_heff_2ebuild_2ebenchmarks_2eunits_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr_str1, 1, ".");

HeffT2 g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_u_243 = heff_field(v_x21_242, 0);
      V v_unit_244 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - heff_unbox_word(heff_strLength(v_u_243)));
      V v_s_246 = heff_strSlice_lent(v_s_240, MK_INT(0LL), heff_box_word(v_t_245), 6);
      V v_t_247 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr_str0); V a_1 = v_s_246; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr_str1), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_246); r_; });
      V v_t_248 = ({ V a_0 = v_unit_244; V a_1 = v_t_247; V r_ = heff_tr(g_heff_2ebuild_2ebenchmarks_2edecimalParts(a_0, a_1)); heff_drop(v_t_247); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_n_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 1);
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_249, 1)) {
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Nanos, 1, (V[]){v_n_249})}});
        } else {
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          heff_drop(v_n_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2edefaultTime_st;
static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_init(void) {
  return heff_tag_n(TAG_Nanos, 1, (V[]){MK_INT(1000000000LL)});
}
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2edefaultTime_st)) return g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2edefaultTime_val, &g_heff_2ebuild_2ebenchmarks_2edefaultTime_st, g_heff_2ebuild_2ebenchmarks_2edefaultTime_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str1, 1, " ");
Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaces_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2espaces(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str0);
  } else {
    V v_s_242 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str1);
    return (g_heff_2ebuild_2ebenchmarks_2espaces_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_242));
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2espaces(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecapital_str0, 26, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecapital_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ecapital(V v_s_240) {
top: ;
  if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_240, 0)))) {
    if ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))) {
        int64_t v_t_244 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)97ULL));
        int64_t v_t_245 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)96ULL));
        V v_t_246 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
        return heff_strAppend(heff_strSlice(((V)&g_heff_2ebuild_2ebenchmarks_2ecapital_str0), heff_box_word(v_t_244), heff_box_word(v_t_245)), v_t_246);
      } else {
        return v_s_240;
      }
    } else {
      return v_s_240;
    }
  } else {
    return v_s_240;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecapital(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0, 1, "0");
Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V v_n_240, V v_s_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), heff_strLength_lent(v_s_241, 0))) {
    heff_drop(v_n_240);
    return v_s_241;
  } else {
    V t_0 = v_n_240;
    V t_1 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0), v_s_241);
    v_n_240 = t_0;
    v_s_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ezeroPadded(a[0], a[1]);
}
Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V v_total_240, V v_n_241, V v_box_24k_242) {
  int64_t v_k_242 = heff_unbox_word(v_box_24k_242);
top: ;
  if ((((int64_t)7ULL) <= v_k_242)) {
    heff_drop(v_total_240);
    heff_drop(v_n_241);
    return heff_box_word(v_k_242);
  } else {
    V v_t_244 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_box_word((v_k_242 + ((int64_t)2ULL)))));
    V v_x_245 = heff_intMul(heff_dup(v_total_240), v_t_244);
    if (heff_intLe_c(heff_intMul(MK_INT(99995LL), heff_dup(v_n_241)), v_x_245)) {
      heff_drop(v_total_240);
      heff_drop(v_n_241);
      return heff_box_word(v_k_242);
    } else {
      V t_0 = v_total_240;
      V t_1 = v_n_241;
      int64_t t_2 = (v_k_242 + ((int64_t)1ULL));
      v_total_240 = t_0;
      v_n_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eplacesOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str3, 10, " allocs/op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str4, 6, " B/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str5, 7, " ns/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str6, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str7, 1, "\011");
Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eresultLine_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2eresultLine(V v_width_240, V v_names_241, V v_n_242, V v_ns_243, V v_allocs_244, V v_bytes_245) {
top: ;
  V v_s_2411;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_s_2411 = ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str0);
    break;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_names_241, 0);
    V v_rest_247 = heff_field(v_names_241, 1);
    V v_t_248 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_246));
    V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_248));
    V v_t_2410 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str1), v_t_249, v_rest_247));
    v_s_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str2), v_t_2410);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2412 = heff_intSub(v_width_240, heff_strLength_lent(v_s_2411, 0));
  V v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2espaces(v_t_2412));
  V v_s_2414 = heff_intShow(heff_dup(v_n_242));
  int64_t v_t_2415 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2414, 0)));
  V v_t_2416 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2415)));
  V v_t_2417 = (g_heff_2ebuild_2ebenchmarks_2eperOp(v_ns_243, heff_dup(v_n_242)));
  V v_s_2418 = heff_intShow(heff_intDiv(v_bytes_245, heff_dup(v_n_242)));
  int64_t v_t_2419 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2418, 0)));
  V v_t_2420 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2419)));
  V v_s_2421 = heff_intShow(heff_intDiv(v_allocs_244, v_n_242));
  int64_t v_t_2422 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2421, 0)));
  V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2422)));
  V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, v_s_2421), ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str3));
  V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2420, v_s_2418), heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str4), v_t_2424));
  V v_t_2426 = heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str5), v_t_2425));
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2416, v_s_2414), heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str6), v_t_2426));
  return heff_strAppend(heff_strAppend(v_s_2411, v_t_2413), heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str7), v_t_2427));
}
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2eresultLine(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9, 10, "--- FAIL: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19, 10, "--- SKIP: ");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V v_width_240, V v_names_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Measured: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ns_244 = heff_field(v_x3_242, 1);
    V v_allocs_245 = heff_field(v_x3_242, 2);
    V v_bytes_246 = heff_field(v_x3_242, 3);
    return (g_heff_2ebuild_2ebenchmarks_2eresultLine(v_width_240, v_names_241, heff_dup(v_n_243), heff_dup(v_ns_244), heff_dup(v_allocs_245), heff_dup(v_bytes_246)));
  }
  case TAG_FailedWith: {
    V v_why_247 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2413;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0);
      break;
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_names_241, 0);
      V v_rest_249 = heff_field(v_names_241, 1);
      V v_t_2410 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_248));
      V v_t_2411 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2410));
      V v_t_2412 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1), v_t_2411, v_rest_249));
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2), v_t_2412);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3); V a_1 = v_why_247; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4), v_why_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_2415 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5), v_t_2414));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8), v_t_2418));
    return heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9), v_t_2419);
  }
  case TAG_SkippedWith: {
    V v_why_2420 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2426;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10);
      break;
    }
    case TAG_Cons: {
      V v_n_2421 = heff_field(v_names_241, 0);
      V v_rest_2422 = heff_field(v_names_241, 1);
      V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_2421));
      V v_t_2424 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2423));
      V v_t_2425 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11), v_t_2424, v_rest_2422));
      v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12), v_t_2425);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2427 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13); V a_1 = v_why_2420; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14), v_why_2420, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x2_2428 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15), v_t_2427));
    V v_t_2431;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_xs_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2428);
    }
    V v_t_2432 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18), v_t_2431));
    return heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19), v_t_2432);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str1, 2, "ns");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str2, 6, "allocs");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str3, 5, "bytes");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str4, 9, "ns_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str5, 13, "allocs_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str6, 12, "bytes_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str7, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str8, 7, "skipped");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Measured: {
    V v_n_241 = heff_field(v_x1_240, 0);
    V v_ns_242 = heff_field(v_x1_240, 1);
    V v_allocs_243 = heff_field(v_x1_240, 2);
    V v_bytes_244 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str0), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_n_241)})});
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str1), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_ns_242)})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str2), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_allocs_243)})});
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str3), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_bytes_244)})});
    double v_t_249 = (heff_from_int_f64(v_ns_242) / heff_from_int_f64(heff_dup(v_n_241)));
    V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str4), heff_tag_nf(TAG_JFloat, 1, 1u, (V[]){heff_word_f64(v_t_249)})});
    V v_t_2411 = heff_tag_n(TAG_JInt, 1, (V[]){heff_intDiv(v_bytes_244, heff_dup(v_n_241))});
    V v_t_2412 = heff_tag_n(TAG_JInt, 1, (V[]){heff_intDiv(v_allocs_243, v_n_241)});
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str5), v_t_2412}), NTAG(TAG_Nil)});
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str6), v_t_2411}), v_t_2413});
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2415})});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2416});
  }
  case TAG_FailedWith: {
    V v_why_2417 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FailedWith = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str7), heff_tag_at_n(v_ru_24x1_240_24FailedWith, TAG_JString, 1, (V[]){v_why_2417})});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  }
  case TAG_SkippedWith: {
    V v_why_2419 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SkippedWith = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_str8), heff_tag_at_n(v_ru_24x1_240_24SkippedWith, TAG_JString, 1, (V[]){v_why_2419})});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eoutcomeFields(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_i_241, 0)), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0))) {
      heff_drop(v_rest_242);
      V v_t_244 = heff_get_n(v_i_241, 1, 3);
      V v_f_246;
      switch (heff_tag_of(v_t_244)) {
      case TAG_Nothing: {
        v_f_246 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_245 = heff_field(v_t_244, 0);
        heff_take_n(v_t_244, 1ULL, 1);
        v_f_246 = heff_strAppend(v_alias_245, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_t_244);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop_rec(v_i_241, 3);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str2, 11, "benchMain [");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str3, 2, "]\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str4, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str5, 11, "Benchmarks\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str6, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchText_str7, 2, "\012\012");
Clo g_heff_2ebuild_2ebenchmarks_2ebenchText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchText_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchText(V v_q_240, V v_bs_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s467798769x1763085075(v_bs_241));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str2), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str3)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str4), heff_strAppend(heff_dup(v_q_240), v_t_246));
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str5), heff_strAppend(heff_dup(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get()), v_t_247));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str6), heff_strAppend(v_q_240, v_t_248));
  return heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchText_str7), heff_strAppend(heff_dup(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get()), v_t_249));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0, 12, "heff:abandon");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1, 12, "it abandoned");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9, 3, "it ");
Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V v_r_240) {
top: ;
  V v_t_241 = heff_strFind(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0), heff_dup(heff_rfield(v_r_240, 2)), MK_INT(0LL));
  if (heff_intLe_c(MK_INT(0LL), v_t_241)) {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1);
  } else {
    V v_t_243 = heff_take_field(v_r_240, 0);
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_Exited: {
      V v_n_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2), heff_intShow(v_n_244));
      break;
    }
    case TAG_Signalled: {
      V v_n_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3), heff_intShow(v_n_245));
      break;
    }
    case TAG_TimedOut: {
      v_t_246 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4);
      break;
    }
    case TAG_NotRun: {
      v_t_246 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 2)), ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6))) {
      heff_drop_rec(v_r_240, 3);
      v_t_249 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7);
    } else {
      V v_t_248 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_240, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
      v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8), v_t_248);
    }
    return heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9), heff_strAppend(v_t_246, v_t_249));
  }
}
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eendedWhy(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str4, 45, "what it said of how it went could not be read");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan(V v_r_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_r_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Exited: {
    V v_n_242 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24Exited = heff_take_reuse_n(v_t_241, 1ULL, 1);
    if (heff_intEq_c(v_n_242, MK_INT(0LL))) {
      V v_t_244 = heff_get_n(v_r_240, 1, 3);
      V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str0); V a_1 = v_t_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str1), v_t_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_t_244); r_; });
      V v_x1_246 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str2); V a_2 = v_t_245; V r_ = (g_list_2efoldl_24f470245410x241064089(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_t_249 = v_x_247;
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      V v_t_2410 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2411 = ({ V a_0 = v_t_249; V a_1 = v_t_2410; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_why_2415 = v_field_2413;
          heff_drop(v_why_2415);
          return heff_tag_at_n(v_ru_24t_241_24Exited, TAG_FailedWith, 1, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_str4)});
        } else {
          heff_drop_cell(v_ru_24t_241_24Exited, 1);
          V v_j_2416 = v_field_2413;
          HEFF_LAST return g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(v_j_2416);
        }
      }
    } else {
      V v_t_2417 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
      return heff_tag_at_n(v_ru_24t_241_24Exited, TAG_FailedWith, 1, (V[]){v_t_2417});
    }
  }
  case TAG_Signalled: {
    V v_ru_24t_241_24Signalled = heff_take_reuse_n(v_t_241, 0ULL, 1);
    V v_t_2419 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return heff_tag_at_n(v_ru_24t_241_24Signalled, TAG_FailedWith, 1, (V[]){v_t_2419});
  }
  case TAG_TimedOut: {
    V v_t_2420 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return heff_tag_n(TAG_FailedWith, 1, (V[]){v_t_2420});
  }
  case TAG_NotRun: {
    V v_t_2421 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return heff_tag_n(TAG_FailedWith, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_str0, 19, "heff bench: --time ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_str1, 57, ": not a duration (1s, 1.5s, 500ms, 2m) nor a count (100x)");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_str2, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam2(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam0_clo);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr(v_s_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_s_243);
        V v_t_248 = v_field_246;
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam1, 2, 1, (V[]){v_t_248});
      } else {
        heff_drop(v_field_246);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam2, 2, 1, (V[]){v_s_243});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_2412;
  args[0] = heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_2411, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam4, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_s_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_str0), heff_strAppend(v_s_243, ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_str1)));
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_str2)), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_lam3, 1, 2, (V[]){v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str0, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str1, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str3, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str4, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str5, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam5(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam0_clo);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_248;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_243, 0)))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_s_243, 0)) - ((int64_t)1ULL));
      V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_245)));
      V v_t_247 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_243; V a_2 = MK_INT(57LL); V a_3 = v_t_246; V r_ = (g_list_2eall_24s443219008x474491297(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = (g_prelude_2eparseInt(v_s_243));
      } else {
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_Nothing);
      }
    } else {
      v_t_248 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam1, 2, 1, (V[]){v_s_243});
    }
    case TAG_Just: {
      V v_n_2428 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      if (heff_intLt_c_lent(MK_INT(0LL), v_n_2428, 1)) {
        heff_drop(v_s_243);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam4, 2, 1, (V[]){v_n_2428});
      } else {
        heff_drop(v_n_2428);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam5, 2, 1, (V[]){v_s_243});
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_2410;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V v_t_2420 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_hd_249, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam3, 1, 1, (V[]){v_k_2410})));
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_s_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str0), heff_strAppend(v_s_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str1)));
  V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str2)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam2, 1, 2, (V[]){v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_n_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = v_n_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_2433;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_hd_2432 = heff_env(self)[0];
  V v_k_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2442);
  V v_t_2443 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_hd_2432, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam7, 1, 1, (V[]){v_k_2433})));
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_s_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str3), heff_strAppend(v_s_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str4)));
  V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_str5)), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), heff_dup(v_hd_2432), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_lam6, 1, 2, (V[]){v_hd_2432, v_k_2433})));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_str1, 71, "heff bench: no bench/ here: bench at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_str2, 5, "bench");
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam1(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam1, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam0, 2, 0};
Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam0_clo);
  }
  case TAG_Cons: {
    V v_t_2433 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2433, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam1(V self, V *args) {
  V v_ns_243 = args[0];
  return v_ns_243;
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2426);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_hd_241, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam4, 1, 1, (V[]){v_k_242})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_str1), NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam3, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2410, 0ULL, 1);
    V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_str2)});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2430 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2429, NTAG(TAG_Nil)));
    V f_ = v_t_2430;
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDirectory, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_str0), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1011886338x1728235888_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str1, 25, "heff bench: no benchmarks");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str2, 1, "'");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str3, 33, "heff bench: no benchmarks match '");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str4, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_entry, 4, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580(V v_opts_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  if (heff_intEq_c(heff_dup(heff_rfield(v_acc_241, 0)), MK_INT(0LL))) {
    if (heff_intEq_c(heff_dup(heff_rfield(v_acc_241, 1)), MK_INT(0LL))) {
      heff_drop_rec(v_acc_241, 2);
      V v_t_248;
      if (heff_strEq_c(heff_dup(heff_rfield(v_opts_240, 0)), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str0))) {
        heff_drop_rec(v_opts_240, 4);
        v_t_248 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str1);
      } else {
        V v_t_247 = heff_strAppend(heff_get_n(v_opts_240, 0, 4), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str2));
        v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str3), v_t_247);
      }
      V v_t_249 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_str4)), NTAG(TAG_MkUnit)});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_lam0, 1, 2, (V[]){v_p_242, v_p_243})));
    } else {
      heff_drop_rec(v_opts_240, 4);
      if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_acc_241, 1, 2))) {
        V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_p_242, v_p_243));
      } else {
        heff_drop(v_p_242);
        return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
      }
    }
  } else {
    heff_drop_rec(v_opts_240, 4);
    if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_acc_241, 1, 2))) {
      V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_p_242, v_p_243));
    } else {
      heff_drop(v_p_242);
      return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_p_242, v_p_243));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str0, 4, "file");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str1, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str5, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str9, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str10, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(V v_opts_240, V v_f_241, V v_why_242) {
top: ;
  V v_t_243 = heff_get_n(v_opts_240, 3, 4);
  V v_c_2430;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str0), heff_tag_n(TAG_JString, 1, (V[]){v_f_241})});
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str1), heff_tag_n(TAG_JString, 1, (V[]){v_why_242})});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})});
    V v_str_248 = ({ V a_0 = v_t_247; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_247, 1); r_; });
    V v_t_249 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_248, ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str2)), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    v_c_2430 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})}));
  } else {
    heff_drop(v_t_243);
    V v_t_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str3); V a_1 = v_why_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str4), v_why_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_why_242); r_; });
    V v_x2_2417 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str5), v_t_2416));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str7); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str8), v_t_2420));
    V v_str_2422 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str9), v_t_2421);
    V v_t_2423 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2422, ((V)&g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_str10)), NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    v_c_2430 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
  }
  return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_lam0, 2, 1, (V[]){v_c_2430});
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  V f_ = v_k_2432;
  args[0] = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(1LL)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_lam0(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_lam1, 1, 1, (V[]){v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_str1, 1, "\012");
Clo g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_entry, 5, 0};

V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533(V v_opts_240, V v_f_241, V v_width_242, V v_names_243, V v_o_244) {
top: ;
  V v_t_245 = heff_get_n(v_opts_240, 3, 4);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_width_242);
    heff_drop(v_t_245);
    V v_str_246 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(v_f_241, v_names_243, v_o_244));
    V v_t_247 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_str0)), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  } else {
    heff_drop(v_f_241);
    heff_drop(v_t_245);
    V v_str_2414 = ({ V a_0 = v_width_242; V a_1 = v_names_243; V a_2 = v_o_244; V r_ = (g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a_0, a_1, a_2)); heff_drop(v_names_243); heff_drop(v_o_244); r_; });
    V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2414, ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_str1)), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  }
}
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str1, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str2, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str3, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str4, 0, "");
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_entry, 9, 0};

V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398(V v_opts_240, V v_f_241, V v_prog_242, V v_width_243, V v_names_244, V v_left_245, V v_acc_246, V v_p_247, V v_p_248) {
top: ;
  if (heff_intLe_c_lent(v_left_245, MK_INT(0LL), 2)) {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop(v_p_247);
    return heff_tail(v_p_248, 1, (V[]){v_acc_246});
  } else {
    V v_t_2410 = heff_dup(heff_rfield(v_opts_240, 1));
    V v_t_2415;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nanos: {
      V v_ns_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_ns_2411), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str0), heff_dup(v_names_244)})});
      v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str1), v_t_2412});
      break;
    }
    case TAG_Times: {
      V v_n_2413 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_n_2413), heff_dup(v_names_244)});
      v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str3), v_t_2414})});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2416 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){heff_dup(v_prog_242), v_t_2415, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_str4), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2416, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam0_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s495635622x733177935(v_t_2424, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam1, 1, 9, (V[]){v_opts_240, v_f_241, v_width_243, v_names_244, v_p_247, v_acc_246, v_prog_242, v_left_245, v_p_248})));
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam0(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_acc_246 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_prog_242 = heff_env(self)[4];
  V v_width_243 = heff_env(self)[5];
  V v_names_244 = heff_env(self)[6];
  V v_left_245 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  V v_p_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2428);
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Measured: {
    heff_take_n(v_x_2426, 0ULL, 4);
    V v_t_2433 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2434 = ({ V rv_0 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_acc_246, 2ULL, 2, shape_ran__failed, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398(v_opts_240, v_f_241, v_prog_242, v_width_243, v_names_244, heff_intSub(v_left_245, MK_INT(1LL)), v_t_2434, v_p_247, v_p_248));
  }
  case TAG_FailedWith: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop(v_p_247);
    V v_t_2436 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2443;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_Measured: {
      heff_take_n(v_x_2426, 0ULL, 4);
      v_t_2443 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2426, 0ULL, 1);
      v_t_2443 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2426, 0ULL, 1);
      v_t_2443 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2444 = heff_intAdd(heff_get_n(v_acc_246, 1, 2), v_t_2443);
    V f_ = v_p_248;
    args[0] = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2436, v_t_2444});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_SkippedWith: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop(v_p_247);
    V v_t_2446 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2453;
    switch (heff_tag_of(v_x_2426)) {
    case TAG_Measured: {
      heff_take_n(v_x_2426, 0ULL, 4);
      v_t_2453 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2426, 0ULL, 1);
      v_t_2453 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2426, 0ULL, 1);
      v_t_2453 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2426);
    }
    V v_t_2454 = heff_intAdd(heff_get_n(v_acc_246, 1, 2), v_t_2453);
    V f_ = v_p_248;
    args[0] = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2446, v_t_2454});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2426);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_width_243 = heff_env(self)[2];
  V v_names_244 = heff_env(self)[3];
  V v_p_247 = heff_env(self)[4];
  V v_acc_246 = heff_env(self)[5];
  V v_prog_242 = heff_env(self)[6];
  V v_left_245 = heff_env(self)[7];
  V v_p_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2426 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan(v_x_2425));
  V v_c_2427 = heff_tr(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s1871233962x1569653533(heff_dup(v_opts_240), heff_dup(v_f_241), heff_dup(v_width_243), heff_dup(v_names_244), heff_dup(v_x_2426)));
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_p_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398_lam2, 1, 10, (V[]){v_x_2426, v_acc_246, v_opts_240, v_f_241, v_prog_242, v_width_243, v_names_244, v_left_245, v_p_247, v_p_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_entry, 8, 0};

V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994(V v_opts_240, V v_f_241, V v_prog_242, V v_width_243, V v_x5_244, V v_acc_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_p_246);
    return heff_tail(v_p_247, 1, (V[]){v_acc_245});
  }
  case TAG_Cons: {
    V v_names_248 = heff_field(v_x5_244, 0);
    V v_rest_249 = heff_field(v_x5_244, 1);
    return (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s468031919x927962398(heff_dup(v_opts_240), heff_dup(v_f_241), heff_dup(v_prog_242), heff_dup(v_width_243), heff_dup(v_names_248), heff_dup(heff_rfield(v_opts_240, 2)), v_acc_245, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_lam0, 1, 7, (V[]){v_opts_240, v_f_241, v_prog_242, v_width_243, heff_dup(v_rest_249), v_p_246, v_p_247})));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_prog_242 = heff_env(self)[2];
  V v_width_243 = heff_env(self)[3];
  V v_rest_249 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_prog_242; V a_3 = v_width_243; V a_4 = v_rest_249; V a_5 = v_x_2410; V a_6 = v_p_246; V a_7 = v_p_247; V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_rest_249); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str0, 12, ": benchmarks");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str2, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str3, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str5, 19, "-DHEFF_COUNT_ALLOCS");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str6, 10, "heff bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str7, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str8, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str9, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str10, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str11, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str12, 34, "its file is not among those loaded");
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam1(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam1, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam3(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam3, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam8(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam13(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam12(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam11(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam16(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam16, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam18(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam17(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam15(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam14(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam10(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam9(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam19(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_entry, 9, 0};

V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818(V v_rep_240, V v_prog_241, V v_opts_242, V v_f_243, V v_l_244, V v_c_245, V v_k_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_list_2efind_24s1973550603x1701528639_24cpr(heff_dup(v_c_245), heff_dup(heff_rfield(v_l_244, 0))));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_src_2413 = v_field_2411;
      HeffT2 v_t_2414 = (g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr(heff_dup(v_l_244), v_c_245, v_src_2413));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop(v_rep_240);
          heff_drop(v_prog_241);
          heff_drop_rec(v_l_244, 5);
          V v_why_2418 = v_field_2416;
          V v_c_2419 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(v_opts_242, v_f_243, v_why_2418));
          return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam0, 1, 3, (V[]){v_k_246, v_z_247, v_z_248})});
        } else {
          V v_withMain_2421 = v_field_2416;
          V v_t_2423 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(heff_dup(v_f_243), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str0)), MK_INT(2LL), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam1_clo)});
          V v_t_2424 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2423}));
          return (g_co_2eop_24s495635622x733177935(v_t_2424, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam2, 1, 9, (V[]){v_prog_241, v_z_247, v_l_244, v_f_243, v_rep_240, v_opts_242, v_k_246, v_withMain_2421, v_z_248})));
        }
      }
    } else {
      heff_drop(v_rep_240);
      heff_drop(v_prog_241);
      heff_drop_rec(v_l_244, 5);
      heff_drop(v_c_245);
      heff_drop(v_field_2411);
      V v_c_2489 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(v_opts_242, v_f_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str12)));
      return heff_tail(v_c_2489, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam19, 1, 3, (V[]){v_k_246, v_z_247, v_z_248})});
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2420;
  heff_room[1] = v_z_247;
  heff_room[2] = v_z_248;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam1(V self, V *args) {
  V v_t_2422 = args[0];
  return v_t_2422;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam3(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_2441 = heff_env(self)[1];
  V v_z_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2450;
  heff_room[1] = v_z_2441;
  heff_room[2] = v_z_2442;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam7(V self, V *args) {
  V v_x_2448 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_why_2440 = heff_env(self)[2];
  V v_z_2441 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_z_2442 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2448);
  V v_c_2449 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(v_opts_242, v_f_243, v_why_2440));
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_z_2441);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam8, 1, 3, (V[]){v_k_246, v_z_2441, v_z_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_2441 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_why_2440 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_z_2442 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_End, 2, (V[]){v_x_2425, NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2446}));
  return (g_co_2eop_24s495635622x733177935(v_t_2447, heff_dup(v_z_2441), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam7, 1, 6, (V[]){v_opts_242, v_f_243, v_why_2440, v_z_2441, v_k_246, v_z_2442})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam5(V self, V *args) {
  V v_why_2440 = args[0];
  V v_z_2441 = args[1];
  V v_z_2442 = args[2];
  V v_x_2428 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2443 = heff_tag_n(TAG_End, 2, (V[]){v_x_2428, NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2443}));
  return (g_co_2eop_24s495635622x733177935(v_t_2444, heff_dup(v_z_2441), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam6, 1, 8, (V[]){v_x_2425, v_prog_241, v_z_2441, v_opts_242, v_f_243, v_why_2440, v_k_246, v_z_2442})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam13(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_2457 = heff_env(self)[1];
  V v_z_2458 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2463;
  heff_room[1] = v_z_2457;
  heff_room[2] = v_z_2458;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam12(V self, V *args) {
  V v_x_2461 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_why_2456 = heff_env(self)[2];
  V v_z_2457 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_z_2458 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2461);
  V v_c_2462 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(v_opts_242, v_f_243, v_why_2456));
  V f_ = v_c_2462;
  heff_room[0] = heff_dup(v_z_2457);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam13, 1, 3, (V[]){v_k_246, v_z_2457, v_z_2458});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam11(V self, V *args) {
  V v_why_2456 = args[0];
  V v_z_2457 = args[1];
  V v_z_2458 = args[2];
  V v_x_2425 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2459 = heff_tag_n(TAG_End, 2, (V[]){v_x_2425, NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2459}));
  return (g_co_2eop_24s495635622x733177935(v_t_2460, heff_dup(v_z_2457), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam12, 1, 6, (V[]){v_opts_242, v_f_243, v_why_2456, v_z_2457, v_k_246, v_z_2458})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam16(V self, V *args) {
  V v_r_2472 = args[0];
  return v_r_2472;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam18(V self, V *args) {
  V v_x_2488 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_hd_2464 = heff_env(self)[1];
  V v_k_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2488;
  heff_room[1] = v_hd_2464;
  heff_room[2] = v_k_2465;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam17(V self, V *args) {
  V v_x_2479 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_hd_2464 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_k_2465 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_paths_2480 = heff_get_n(v_l_244, 2, 5);
  V v_d_2481 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_2480), heff_dup(v_f_243)));
  V v_t_2482 = heff_dup(heff_rfield(v_paths_2480, 5));
  V v_t_2483;
  switch (heff_tag_of(v_t_2482)) {
  case TAG_Posix: {
    v_t_2483 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str10);
    break;
  }
  case TAG_Windows: {
    v_t_2483 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str11);
    break;
  }
  default: heff_nomatch(v_t_2482);
  }
  V v_given_2484 = ({ V b_0 = heff_get_n(v_paths_2480, 5, 6); V a_1 = v_d_2481; V a_2 = v_t_2483; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2487;
  switch (heff_tag_of(v_x_2479)) {
  case TAG_Left: {
    heff_take_n(v_x_2479, 0ULL, 1);
    v_t_2487 = v_given_2484;
    break;
  }
  case TAG_Right: {
    V v_real_2486 = heff_field(v_x_2479, 0);
    heff_take_n(v_x_2479, 1ULL, 1);
    heff_drop(v_given_2484);
    v_t_2487 = v_real_2486;
    break;
  }
  default: heff_nomatch(v_x_2479);
  }
  return (g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580(v_opts_242, v_f_243, v_t_2487, heff_dup(v_hd_2464), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam18, 1, 3, (V[]){v_k_246, v_hd_2464, v_k_2465})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam15(V self, V *args) {
  V v_x_2466 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_hd_2464 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_k_2465 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2466);
  V v_paths_2467 = heff_dup(heff_rfield(v_l_244, 2));
  V v_d_2468 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_2467), heff_dup(v_f_243)));
  V v_t_2469 = heff_dup(heff_rfield(v_paths_2467, 5));
  V v_t_2470;
  switch (heff_tag_of(v_t_2469)) {
  case TAG_Posix: {
    v_t_2470 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str8);
    break;
  }
  case TAG_Windows: {
    v_t_2470 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str9);
    break;
  }
  default: heff_nomatch(v_t_2469);
  }
  V v_path_2471 = ({ V b_0 = heff_get_n(v_paths_2467, 5, 6); V a_1 = v_d_2468; V a_2 = v_t_2470; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_RealPath, 2, (V[]){v_path_2471, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam16_clo)})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2478}), heff_dup(v_hd_2464), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam17, 1, 6, (V[]){v_l_244, v_f_243, v_opts_242, v_hd_2464, v_k_246, v_k_2465})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam14(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_t_2437 = heff_env(self)[0];
  V v_l_244 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_co_2eop_24s495635622x733177935(v_t_2437, heff_dup(v_hd_2464), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam15, 1, 6, (V[]){v_l_244, v_f_243, v_hd_2464, v_opts_242, v_k_246, v_k_2465})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam10(V self, V *args) {
  V v_x_2453 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_t_2430 = heff_env(self)[6];
  V v_t_2435 = heff_env(self)[7];
  V v_t_2437 = heff_env(self)[8];
  V v_hd_2451 = heff_env(self)[9];
  V v_k_2452 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2453);
  V v_t_2454 = heff_get_n(heff_dup(heff_rfield(v_l_244, 2)), 5, 6);
  V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str5), NTAG(TAG_Nil)});
  return ({ V a_0 = heff_dup(v_prog_241); V a_1 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam11, 3, 5, (V[]){heff_dup(v_x_2425), v_prog_241, heff_dup(v_opts_242), heff_dup(v_f_243), heff_dup(v_k_246)}); V a_2 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str6); V a_3 = v_t_2454; V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str7), v_t_2455}); V a_5 = v_x_2425; V a_6 = v_t_2430; V a_7 = v_t_2435; V a_8 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam14, 2, 5, (V[]){v_t_2437, v_l_244, v_f_243, v_opts_242, v_k_246}); V a_9 = v_hd_2451; V a_10 = v_k_2452; V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1562757682x2079928498(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_t_2454); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam9(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_t_2439 = heff_env(self)[0];
  V v_l_244 = heff_env(self)[1];
  V v_prog_241 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_f_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_t_2430 = heff_env(self)[7];
  V v_t_2435 = heff_env(self)[8];
  V v_t_2437 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_co_2eop_24s495635622x733177935(v_t_2439, heff_dup(v_hd_2451), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam10, 1, 11, (V[]){v_l_244, v_prog_241, v_x_2425, v_opts_242, v_f_243, v_k_246, v_t_2430, v_t_2435, v_t_2437, v_hd_2451, v_k_2452})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_withMain_2421 = heff_env(self)[7];
  V v_z_247 = heff_env(self)[8];
  V v_z_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2429 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(heff_rfield(v_l_244, 2)), heff_dup(v_f_243)));
  V v_t_2430 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(heff_rfield(v_l_244, 2)), heff_dup(v_f_243)));
  V v_paths_2431 = heff_dup(heff_rfield(v_l_244, 2));
  V v_d_2432 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_2431), heff_dup(v_f_243)));
  V v_t_2433 = heff_dup(heff_rfield(v_paths_2431, 5));
  V v_t_2434;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_Posix: {
    v_t_2434 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str2);
    break;
  }
  case TAG_Windows: {
    v_t_2434 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str3);
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  V v_t_2435 = ({ V b_0 = heff_get_n(v_paths_2431, 5, 6); V a_1 = v_d_2432; V a_2 = v_t_2434; V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2436 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2436}));
  V v_t_2438 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2428), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2438}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1249337277x1272056090(v_rep_240, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam5, 3, 6, (V[]){v_x_2428, heff_dup(v_prog_241), heff_dup(v_x_2425), heff_dup(v_opts_242), heff_dup(v_f_243), heff_dup(v_k_246)}), v_withMain_2421, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get())}), heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str4)), heff_dup(v_f_243), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam9, 2, 10, (V[]){v_t_2439, v_l_244, v_prog_241, v_x_2425, v_opts_242, v_f_243, v_k_246, v_t_2430, v_t_2435, v_t_2437}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_l_244 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_withMain_2421 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2427 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2425), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam3_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2427, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam4, 1, 10, (V[]){v_l_244, v_f_243, v_x_2425, v_prog_241, v_rep_240, v_opts_242, v_k_246, v_withMain_2421, v_z_247, v_z_248})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_lam19(V self, V *args) {
  V v_x_2490 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2490;
  heff_room[1] = v_z_247;
  heff_room[2] = v_z_248;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}