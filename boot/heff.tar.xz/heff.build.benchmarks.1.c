// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailedWith 25914
#define TAG_JArray 50516
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Measured 52135
#define TAG_Nanos 3335
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_SkippedWith 54656
#define TAG_TimedOut 6056
#define TAG_Times 15230
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_alias 294261354
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_count 296209705
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_json 9767343
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_ran 322201
#define LBL_style 311138763
#define LBL_time 10055572
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchProgram_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158(V, V);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_clo;
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo;
V g_heff_2ebuild_2ebenchmarks_2eperOp(V, V);
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo;
V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo;
V g_heff_2ebuild_2ebenchmarks_2eresultLine(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo;
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_clo;
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_clo;
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces(V);
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V, V);
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo;
V g_heff_2ebuild_2ebenchmarks_2etenTo(V);
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo;
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V, V);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo;
V g_heff_2ebuild_2etesting_2elastLines(V, V);
V g_heff_2ebuild_2etesting_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2elastLines_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(V, V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_clo;
V g_json_2eskipSpace(V, V);
V g_json_2eskipSpace_entry(V self, V *a);
extern Clo g_json_2eskipSpace_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
V g_json_2esteps_2evalueAt_240(V, V, V);
V g_json_2esteps_2evalueAt_240_entry(V self, V *a);
extern Clo g_json_2esteps_2evalueAt_240_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eall_24s2093734251x1702493483(V, V, V, V);
V g_list_2eall_24s2093734251x1702493483_entry(V self, V *a);
extern Clo g_list_2eall_24s2093734251x1702493483_clo;
V g_list_2efoldl_24f1221993074x1235215335(V, V, V);
V g_list_2efoldl_24f1221993074x1235215335_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1221993074x1235215335_clo;
V g_list_2efoldl_24s141260856x1366916752(V, V, V, V, V);
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141260856x1366916752_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s723912745x1713553694(V);
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str0, 1, "h");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str1, 1, "m");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str2, 1, "s");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str3, 2, "ms");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str4, 3, "\302\265s");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str5, 2, "us");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eunits_str6, 2, "ns");

static V g_heff_2ebuild_2ebenchmarks_2eunits_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2eunits_st;
static V g_heff_2ebuild_2ebenchmarks_2eunits_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str0), MK_INT(3600000000000LL)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str1), MK_INT(60000000000LL)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str2), MK_INT(1000000000LL)}), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str3), MK_INT(1000000LL)}), v_t_242});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str4), MK_INT(1000LL)}), v_t_243});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str5), MK_INT(1000LL)}), v_t_244});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eunits_str6), MK_INT(1LL)}), v_t_245});
}
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2eunits_st)) return g_heff_2ebuild_2ebenchmarks_2eunits_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2eunits_val, &g_heff_2ebuild_2ebenchmarks_2eunits_st, g_heff_2ebuild_2ebenchmarks_2eunits_init);
}

static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2edefaultTime_st;
static V g_heff_2ebuild_2ebenchmarks_2edefaultTime_init(void) {
  return heff_tag_n(TAG_Nanos, 1, (V[]){MK_INT(1000000000LL)});
}
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2edefaultTime_st)) return g_heff_2ebuild_2ebenchmarks_2edefaultTime_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2edefaultTime_val, &g_heff_2ebuild_2ebenchmarks_2edefaultTime_st, g_heff_2ebuild_2ebenchmarks_2edefaultTime_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_str1, 1, " ");
Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaces_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2espaces(V v_n_240) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str0);
  } else {
    V v_s_241 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_str1);
    return (g_heff_2ebuild_2ebenchmarks_2espaces_24acc(heff_intSub(v_n_240, MK_INT(1LL)), v_s_241));
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2espaces(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecapital_str0, 26, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecapital_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ecapital(V v_s_240) {
top: ;
  if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_240, 0))) && ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))))) {
    int64_t v_t_241 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)97ULL));
    int64_t v_t_242 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) - ((int64_t)96ULL));
    V v_t_243 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength(v_s_240));
    return heff_strAppend(heff_strSlice(((V)&g_heff_2ebuild_2ebenchmarks_2ecapital_str0), heff_box_word(v_t_241), heff_box_word(v_t_242)), v_t_243);
  } else {
    return v_s_240;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecapital(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0, 1, "0");
Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V v_n_240, V v_s_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), heff_strLength_lent(v_s_241, 0))) {
    heff_drop(v_n_240);
    return v_s_241;
  } else {
    V t_0 = v_n_240;
    V t_1 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ezeroPadded_str0), v_s_241);
    v_n_240 = t_0;
    v_s_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ezeroPadded(a[0], a[1]);
}
Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V v_total_240, V v_n_241, V v_box_24k_242) {
  int64_t v_k_242 = heff_unbox_word(v_box_24k_242);
top: ;
  if ((((int64_t)7ULL) <= v_k_242)) {
    heff_drop(v_total_240);
    heff_drop(v_n_241);
    return heff_box_word(v_k_242);
  } else {
    V v_t_243 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_box_word((v_k_242 + ((int64_t)2ULL)))));
    V v_x_244 = heff_intMul(heff_dup(v_total_240), v_t_243);
    if (heff_intLe_c(heff_intMul(MK_INT(99995LL), heff_dup(v_n_241)), v_x_244)) {
      heff_drop(v_total_240);
      heff_drop(v_n_241);
      return heff_box_word(v_k_242);
    } else {
      V t_0 = v_total_240;
      V t_1 = v_n_241;
      int64_t t_2 = (v_k_242 + ((int64_t)1ULL));
      v_total_240 = t_0;
      v_n_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eplacesOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str3, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str4, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str5, 7, " ns/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str6, 6, " B/op\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eresultLine_str7, 10, " allocs/op");
Clo g_heff_2ebuild_2ebenchmarks_2eresultLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eresultLine_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2eresultLine(V v_width_240, V v_names_241, V v_n_242, V v_ns_243, V v_allocs_244, V v_bytes_245) {
top: ;
  V v_s_2411;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_s_2411 = ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str0);
    break;
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_names_241, 0);
    V v_rest_247 = heff_field(v_names_241, 1);
    V v_t_248 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_246));
    V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_248));
    V v_t_2410 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str1), v_t_249, v_rest_247));
    v_s_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str2), v_t_2410);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2412 = heff_intSub(v_width_240, heff_strLength_lent(v_s_2411, 0));
  V v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2espaces(v_t_2412));
  V v_t_2414 = heff_strAppend(heff_strAppend(v_s_2411, v_t_2413), ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str3));
  V v_s_2415 = heff_intShow(heff_dup(v_n_242));
  int64_t v_t_2416 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2415, 0)));
  V v_t_2417 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2416)));
  V v_t_2418 = heff_strAppend(v_t_2414, heff_strAppend(v_t_2417, v_s_2415));
  V v_t_2419 = (g_heff_2ebuild_2ebenchmarks_2eperOp(v_ns_243, heff_dup(v_n_242)));
  V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str4)), v_t_2419);
  V v_s_2421 = heff_intShow(heff_intDiv(v_bytes_245, heff_dup(v_n_242)));
  int64_t v_t_2422 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2421, 0)));
  V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2422)));
  V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str5)), heff_strAppend(v_t_2423, v_s_2421));
  V v_s_2425 = heff_intShow(heff_intDiv(v_allocs_244, v_n_242));
  int64_t v_t_2426 = (((int64_t)8ULL) - heff_unbox_word(heff_strLength_lent(v_s_2425, 0)));
  V v_t_2427 = (g_heff_2ebuild_2ebenchmarks_2espaces(heff_box_word(v_t_2426)));
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str6)), heff_strAppend(v_t_2427, v_s_2425));
  return heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ebenchmarks_2eresultLine_str7));
}
V g_heff_2ebuild_2ebenchmarks_2eresultLine_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2eresultLine(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3, 10, "--- FAIL: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13, 10, "--- SKIP: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17, 4, "    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19, 1, "\012");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V v_width_240, V v_names_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Measured: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ns_244 = heff_field(v_x3_242, 1);
    V v_allocs_245 = heff_field(v_x3_242, 2);
    V v_bytes_246 = heff_field(v_x3_242, 3);
    return (g_heff_2ebuild_2ebenchmarks_2eresultLine(v_width_240, v_names_241, heff_dup(v_n_243), heff_dup(v_ns_244), heff_dup(v_allocs_245), heff_dup(v_bytes_246)));
  }
  case TAG_FailedWith: {
    V v_why_247 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2413;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str0);
      break;
    }
    case TAG_Cons: {
      V v_n_248 = heff_field(v_names_241, 0);
      V v_rest_249 = heff_field(v_names_241, 1);
      V v_t_2410 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_248));
      V v_t_2411 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2410));
      V v_t_2412 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str1), v_t_2411, v_rest_249));
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str2), v_t_2412);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str3), v_t_2413), ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str4));
    V v_t_2415 = ({ V a_0 = v_why_247; V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str5); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str6), v_why_247, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_2416 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str7), v_t_2415));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str9); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return heff_strAppend(v_t_2414, v_t_2419);
  }
  case TAG_SkippedWith: {
    V v_why_2420 = heff_field(v_x3_242, 0);
    heff_drop(v_width_240);
    V v_t_2426;
    switch (heff_tag_of(v_names_241)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str10);
      break;
    }
    case TAG_Cons: {
      V v_n_2421 = heff_field(v_names_241, 0);
      V v_rest_2422 = heff_field(v_names_241, 1);
      V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2espaced(v_n_2421));
      V v_t_2424 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2423));
      V v_t_2425 = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str11), v_t_2424, v_rest_2422));
      v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str12), v_t_2425);
      break;
    }
    default: heff_nomatch(v_names_241);
    }
    V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str13), v_t_2426), ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str14));
    V v_t_2428 = ({ V a_0 = v_why_2420; V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str15); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str16), v_why_2420, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_x2_2429 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str17), v_t_2428));
    V v_t_2432;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      v_t_2432 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      v_t_2432 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeText_str19); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    return heff_strAppend(v_t_2427, v_t_2432);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2, 1, ".");

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_name_243 = heff_dup(heff_rfield(v_i_241, 0));
    V v_alias_244 = heff_dup(heff_rfield(v_i_241, 1));
    if (heff_strEq_c(v_name_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str0))) {
      V v_f_246;
      switch (heff_tag_of(v_alias_244)) {
      case TAG_Nothing: {
        v_f_246 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str1);
        break;
      }
      case TAG_Just: {
        V v_alias_245 = heff_field(v_alias_244, 0);
        heff_take_n(v_alias_244, 1ULL, 1);
        v_f_246 = heff_strAppend(v_alias_245, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr_str2));
        break;
      }
      default: heff_nomatch(v_alias_244);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_246}});
    } else {
      heff_drop(v_alias_244);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str0, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str1, 8, "main.exe");
Clo g_heff_2ebuild_2ebenchmarks_2ebenchProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchProgram(V v_paths_240, V v_file_241) {
top: ;
  V v_d_242 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_240), v_file_241));
  V v_t_243 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_p_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Posix: {
    v_p_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str0);
    break;
  }
  case TAG_Windows: {
    v_p_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchProgram_str1);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_st_245 = heff_get_n(v_paths_240, 5, 6);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_242));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_p_244));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  return ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchProgram(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0, 12, "heff:abandon");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1, 12, "it abandoned");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7, 9, "not run: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str10, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eendedWhy_str11, 3, "it ");
Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V v_r_240) {
top: ;
  V v_err_241 = heff_take_field(v_r_240, 2);
  V v_ended_242 = heff_get_n(v_r_240, 0, 3);
  if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str0), v_err_241, MK_INT(0LL), 5))) {
    heff_drop(v_err_241);
    heff_drop(v_ended_242);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str1);
  } else {
    V v_t_2411;
    switch (heff_tag_of(v_ended_242)) {
    case TAG_Exited: {
      V v_n_243 = heff_field(v_ended_242, 0);
      heff_take_n(v_ended_242, 1ULL, 1);
      v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str2), heff_intShow(v_n_243));
      break;
    }
    case TAG_Signalled: {
      V v_n_244 = heff_field(v_ended_242, 0);
      heff_take_n(v_ended_242, 1ULL, 1);
      v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str3), heff_intShow(v_n_244));
      break;
    }
    case TAG_TimedOut: {
      v_t_2411 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str4);
      break;
    }
    case TAG_NotRun: {
      V v_err_245 = heff_field(v_ended_242, 0);
      heff_take_n(v_ended_242, 1ULL, 1);
      V v_path_246 = heff_take_field(v_err_245, 3);
      V v_name_247 = heff_take_field(v_err_245, 1);
      V v_message_248 = heff_get_n(v_err_245, 2, 4);
      V v_t_249 = heff_strAppend(heff_strAppend(v_path_246, ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str5)), v_name_247);
      V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str6)), v_message_248);
      v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str7), v_t_2410);
      break;
    }
    default: heff_nomatch(v_ended_242);
    }
    V v_t_2413;
    if (heff_strEq_c_lent(v_err_241, ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str8), 2)) {
      heff_drop(v_err_241);
      v_t_2413 = ((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str9);
    } else {
      V v_t_2412 = ({ V a_0 = MK_INT(20LL); V a_1 = v_err_241; V r_ = (g_heff_2ebuild_2etesting_2elastLines(a_0, a_1)); heff_drop(v_err_241); r_; });
      v_t_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str10), v_t_2412);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eendedWhy_str11), v_t_2411), v_t_2413);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eendedWhy(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str0, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str1, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str3, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str4, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str5, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam5(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158(V v_e_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    return ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam0_clo);
  }
  case TAG_Just: {
    V v_s_244 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_t_248;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_244, 0)))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
      V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_245)));
      V v_t_247 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_244; V a_2 = MK_INT(57LL); V a_3 = v_t_246; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        v_t_248 = (g_prelude_2eparseInt(v_s_244));
      } else {
        heff_drop(v_t_247);
        v_t_248 = NTAG(TAG_Nothing);
      }
    } else {
      v_t_248 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam1, 2, 2, (V[]){v_s_244, v_e_240});
    }
    case TAG_Just: {
      V v_n_2428 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      if (heff_intLt_c_lent(MK_INT(0LL), v_n_2428, 1)) {
        heff_drop(v_e_240);
        heff_drop(v_s_244);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam4, 2, 1, (V[]){v_n_2428});
      } else {
        heff_drop(v_n_2428);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam5, 2, 2, (V[]){v_s_244, v_e_240});
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158(a[0], a[1]);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  V f_ = v_k_2410;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V v_t_2420 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_hd_249, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam3, 1, 1, (V[]){v_k_2410})));
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_s_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str0), v_s_244), ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str1));
  V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str2)), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam2, 1, 3, (V[]){v_e_240, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_n_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = v_n_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2449);
  V f_ = v_k_2432;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2431 = heff_env(self)[1];
  V v_k_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_hd_2431, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam7, 1, 1, (V[]){v_k_2432})));
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_s_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str3), v_s_244), ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str4));
  V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2433, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_str5)), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_hd_2431), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s704430666x1723338158_lam6, 1, 3, (V[]){v_e_240, v_hd_2431, v_k_2432})));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_str0, 5, "bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_str1, 71, "heff bench: no bench/ here: bench at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_str2, 5, "bench");
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam2(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318(V v_e_240, V v_given_241) {
top: ;
  switch (heff_tag_of(v_given_241)) {
  case TAG_Nil: {
    V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_str0)));
    V v_c_243 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_242));
    V v_t_244 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_249 = heff_tr(heff_call(v_c_243, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam0_clo)}));
    return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam2, 2, 2, (V[]){v_c_249, v_e_240});
  }
  case TAG_Cons: {
    V v_t_2436 = (g_list_2emap_24s1420651609x666245096(v_given_241));
    return (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2436, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318(a[0], a[1]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_246 = (g_list_2emap_24s219049803x1458391381(v_x_245));
  return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam1, 2, 1, (V[]){v_x_246});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_2410, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam5, 1, 1, (V[]){v_k_2411})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 0ULL, 1);
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_str1), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam4, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2412, 0ULL, 1);
    V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_str2)});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    V v_t_2433 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2432, NTAG(TAG_Nil)));
    V f_ = v_t_2433;
    heff_room[0] = v_hd_2410;
    heff_room[1] = v_k_2411;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFiles_24s1919884071x1680362318_lam3, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str1, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str2, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str3, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str9, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str10, 4, "file");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str11, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str12, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str13, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str14, 4, "name");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str15, 5, "names");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str16, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str17, 2, "ns");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str18, 6, "allocs");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str19, 5, "bytes");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str20, 9, "ns_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str21, 13, "allocs_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str22, 12, "bytes_per_op");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str23, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str24, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str26, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str27, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_entry, 10, 0};

V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183(V v_e_240, V v_opts_241, V v_f_242, V v_prog_243, V v_width_244, V v_names_245, V v_left_246, V v_acc_247, V v_p_248, V v_p_249) {
top: ;
  if (heff_intLe_c_lent(v_left_246, MK_INT(0LL), 2)) {
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_f_242);
    heff_drop(v_prog_243);
    heff_drop(v_width_244);
    heff_drop(v_names_245);
    heff_drop(v_left_246);
    heff_drop(v_p_248);
    return heff_tail(v_p_249, 1, (V[]){v_acc_247});
  } else {
    V v_t_2410 = heff_dup(heff_rfield(v_opts_241, 1));
    V v_t_2415;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nanos: {
      V v_ns_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_ns_2411), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str0), heff_dup(v_names_245)})});
      v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str1), v_t_2412});
      break;
    }
    case TAG_Times: {
      V v_n_2413 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_n_2413), heff_dup(v_names_245)});
      v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str3), v_t_2414})});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2416 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){heff_dup(v_prog_243), v_t_2415, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str4), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2416, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam0_clo)})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2424, heff_dup(v_p_248), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam1, 1, 10, (V[]){v_e_240, v_opts_241, v_f_242, v_width_244, v_names_245, v_p_248, v_acc_247, v_prog_243, v_left_246, v_p_249})));
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam0(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam2(V self, V *args) {
  V v_x_24110 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_acc_247 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_prog_243 = heff_env(self)[5];
  V v_width_244 = heff_env(self)[6];
  V v_names_245 = heff_env(self)[7];
  V v_left_246 = heff_env(self)[8];
  V v_p_248 = heff_env(self)[9];
  V v_p_249 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_24110);
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Measured: {
    heff_take_n(v_x_2448, 0ULL, 4);
    V v_t_24115 = heff_intAdd(heff_take_field(v_acc_247, 0), MK_INT(1LL));
    V v_t_24116 = ({ V rv_0 = v_t_24115; V rr_ = heff_rec_reuse_nf(v_acc_247, 2ULL, 2, shape_ran__failed, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183(v_e_240, v_opts_241, v_f_242, v_prog_243, v_width_244, v_names_245, heff_intSub(v_left_246, MK_INT(1LL)), v_t_24116, v_p_248, v_p_249));
  }
  case TAG_FailedWith: {
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_f_242);
    heff_drop(v_prog_243);
    heff_drop(v_width_244);
    heff_drop(v_names_245);
    heff_drop(v_left_246);
    heff_drop(v_p_248);
    V v_t_24118 = heff_intAdd(heff_take_field(v_acc_247, 0), MK_INT(1LL));
    V v_t_24125;
    switch (heff_tag_of(v_x_2448)) {
    case TAG_Measured: {
      heff_take_n(v_x_2448, 0ULL, 4);
      v_t_24125 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2448, 0ULL, 1);
      v_t_24125 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2448, 0ULL, 1);
      v_t_24125 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2448);
    }
    V v_t_24126 = heff_intAdd(heff_get_n(v_acc_247, 1, 2), v_t_24125);
    V f_ = v_p_249;
    args[0] = heff_rec_n(2, shape_ran__failed, (V[]){v_t_24118, v_t_24126});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_SkippedWith: {
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_f_242);
    heff_drop(v_prog_243);
    heff_drop(v_width_244);
    heff_drop(v_names_245);
    heff_drop(v_left_246);
    heff_drop(v_p_248);
    V v_t_24128 = heff_intAdd(heff_take_field(v_acc_247, 0), MK_INT(1LL));
    V v_t_24135;
    switch (heff_tag_of(v_x_2448)) {
    case TAG_Measured: {
      heff_take_n(v_x_2448, 0ULL, 4);
      v_t_24135 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2448, 0ULL, 1);
      v_t_24135 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2448, 0ULL, 1);
      v_t_24135 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2448);
    }
    V v_t_24136 = heff_intAdd(heff_get_n(v_acc_247, 1, 2), v_t_24135);
    V f_ = v_p_249;
    args[0] = heff_rec_n(2, shape_ran__failed, (V[]){v_t_24128, v_t_24136});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2448);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_width_244 = heff_env(self)[3];
  V v_names_245 = heff_env(self)[4];
  V v_p_248 = heff_env(self)[5];
  V v_acc_247 = heff_env(self)[6];
  V v_prog_243 = heff_env(self)[7];
  V v_left_246 = heff_env(self)[8];
  V v_p_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_r_2426 = v_x_2425;
  V v_t_2427 = heff_dup(heff_rfield(v_r_2426, 0));
  V v_x_2448;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Exited: {
    V v_n_2428 = heff_field(v_t_2427, 0);
    V v_ru_24t_2427_24Exited = heff_take_reuse_n(v_t_2427, 1ULL, 1);
    if (!heff_intEq_c_lent(v_n_2428, MK_INT(0LL), 2)) {
      heff_drop(v_n_2428);
      V v_t_2429 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2426));
      v_x_2448 = heff_tag_at_n(v_ru_24t_2427_24Exited, TAG_FailedWith, 1, (V[]){v_t_2429});
    } else {
      heff_drop(v_n_2428);
      V v_t_2430 = heff_get_n(v_r_2426, 1, 3);
      V v_t_2431 = ({ V a_0 = v_t_2430; V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str5); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str6), v_t_2430, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_t_2430); heff_drop(b_1); r_; });
      V v_x1_2432 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str7); V a_2 = v_t_2431; V r_ = (g_list_2efoldl_24f1221993074x1235215335(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_s_2435;
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_Nil: {
        v_s_2435 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str8);
        break;
      }
      case TAG_Cons: {
        V v_x_2433 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 2);
        v_s_2435 = v_x_2433;
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      V v_t_2436 = (g_json_2eskipSpace(v_s_2435, MK_INT(0LL)));
      V v_t_2437 = (g_json_2esteps_2evalueAt_240(heff_dup(v_s_2435), v_t_2436, NTAG(TAG_Nil)));
      HeffT2 v_t_2438 = (g_json_2esteps_24cpr(v_s_2435, v_t_2437));
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          V v_why_2441 = v_field_2440;
          heff_drop(v_why_2441);
          v_x_2448 = heff_tag_at_n(v_ru_24t_2427_24Exited, TAG_FailedWith, 1, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str9)});
        } else {
          heff_drop_cell(v_ru_24t_2427_24Exited, 1);
          V v_j_2442 = v_field_2440;
          v_x_2448 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(v_j_2442));
        }
      }
    }
    break;
  }
  case TAG_Signalled: {
    V v_ru_24t_2427_24Signalled = heff_take_reuse_n(v_t_2427, 0ULL, 1);
    V v_t_2444 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2426));
    v_x_2448 = heff_tag_at_n(v_ru_24t_2427_24Signalled, TAG_FailedWith, 1, (V[]){v_t_2444});
    break;
  }
  case TAG_TimedOut: {
    V v_t_2445 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2426));
    v_x_2448 = heff_tag_n(TAG_FailedWith, 1, (V[]){v_t_2445});
    break;
  }
  case TAG_NotRun: {
    V v_ru_24t_2427_24NotRun = heff_take_reuse_n(v_t_2427, 0ULL, 1);
    V v_t_2447 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_2426));
    v_x_2448 = heff_tag_at_n(v_ru_24t_2427_24NotRun, TAG_FailedWith, 1, (V[]){v_t_2447});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V v_e_2449 = heff_dup(v_e_240);
  V v_opts_2450 = heff_dup(v_opts_241);
  V v_f_2451 = heff_dup(v_f_242);
  V v_width_2452 = heff_dup(v_width_244);
  V v_names_2453 = heff_dup(v_names_245);
  V v_o_2454 = heff_dup(v_x_2448);
  V v_t_2455 = heff_get_n(v_opts_2450, 3, 4);
  V v_c_24109;
  if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
    heff_drop(v_width_2452);
    heff_drop(v_t_2455);
    V v_f_2456 = v_f_2451;
    V v_names_2457 = v_names_2453;
    V v_o_2458 = v_o_2454;
    V v_t_2459 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str10), heff_tag_n(TAG_JString, 1, (V[]){v_f_2456})});
    V v_t_2465;
    switch (heff_tag_of(v_names_2457)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str11);
      break;
    }
    case TAG_Cons: {
      V v_n_2460 = heff_dup(heff_field(v_names_2457, 0));
      V v_rest_2461 = heff_dup(heff_field(v_names_2457, 1));
      V v_t_2462 = ({ V a_0 = v_n_2460; V r_ = (g_heff_2ebuild_2ebenchmarks_2espaced(a_0)); heff_drop(v_n_2460); r_; });
      V v_t_2463 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_2462));
      V v_t_2464 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str12); V a_1 = v_t_2463; V a_2 = v_rest_2461; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(a_0, a_1, a_2)); heff_drop(v_rest_2461); r_; });
      v_t_2465 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str13), v_t_2464);
      break;
    }
    default: heff_nomatch(v_names_2457);
    }
    V v_t_2466 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str14), heff_tag_n(TAG_JString, 1, (V[]){v_t_2465})});
    V v_t_2467 = (g_list_2emap_24s723912745x1713553694(v_names_2457));
    V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str15), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2467})});
    V v_x1_2469 = v_o_2458;
    V v_t_2490;
    switch (heff_tag_of(v_x1_2469)) {
    case TAG_Measured: {
      V v_n_2470 = heff_field(v_x1_2469, 0);
      V v_ns_2471 = heff_field(v_x1_2469, 1);
      V v_allocs_2472 = heff_field(v_x1_2469, 2);
      V v_bytes_2473 = heff_field(v_x1_2469, 3);
      heff_take_n(v_x1_2469, 15ULL, 4);
      V v_t_2474 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str16), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_n_2470)})});
      V v_t_2475 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str17), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_ns_2471)})});
      V v_t_2476 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str18), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_allocs_2472)})});
      V v_t_2477 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str19), heff_tag_n(TAG_JInt, 1, (V[]){heff_dup(v_bytes_2473)})});
      double v_t_2478 = (heff_from_int_f64(v_ns_2471) / heff_from_int_f64(heff_dup(v_n_2470)));
      V v_t_2479 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str20), heff_tag_nf(TAG_JFloat, 1, 1u, (V[]){heff_word_f64(v_t_2478)})});
      V v_t_2480 = heff_tag_n(TAG_JInt, 1, (V[]){heff_intDiv(v_bytes_2473, heff_dup(v_n_2470))});
      V v_t_2481 = heff_tag_n(TAG_JInt, 1, (V[]){heff_intDiv(v_allocs_2472, v_n_2470)});
      V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str21), v_t_2481}), NTAG(TAG_Nil)});
      V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str22), v_t_2480}), v_t_2482});
      V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2477, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, v_t_2483})});
      V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_t_2484})});
      v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, v_t_2485});
      break;
    }
    case TAG_FailedWith: {
      V v_why_2486 = heff_field(v_x1_2469, 0);
      V v_ru_24x1_2469_24FailedWith = heff_take_reuse_n(v_x1_2469, 1ULL, 1);
      V v_t_2487 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str23), heff_tag_at_n(v_ru_24x1_2469_24FailedWith, TAG_JString, 1, (V[]){v_why_2486})});
      v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2487, NTAG(TAG_Nil)});
      break;
    }
    case TAG_SkippedWith: {
      V v_why_2488 = heff_field(v_x1_2469, 0);
      V v_ru_24x1_2469_24SkippedWith = heff_take_reuse_n(v_x1_2469, 1ULL, 1);
      V v_t_2489 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str24), heff_tag_at_n(v_ru_24x1_2469_24SkippedWith, TAG_JString, 1, (V[]){v_why_2488})});
      v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x1_2469);
    }
    V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, v_t_2490})});
    V v_j_2492 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_t_2491})});
    V v_str_2493 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str25); V a_1 = v_j_2492; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_j_2492, 1); r_; });
    V v_t_2494 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2493, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str26)), NTAG(TAG_MkUnit)});
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})});
    v_c_24109 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_2449, heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})}));
  } else {
    heff_drop(v_f_2451);
    heff_drop(v_t_2455);
    V v_str_24101 = ({ V a_0 = v_width_2452; V a_1 = v_names_2453; V a_2 = v_o_2454; V r_ = (g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a_0, a_1, a_2)); heff_drop(v_names_2453); heff_drop(v_o_2454); r_; });
    V v_t_24102 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24101, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_str27)), NTAG(TAG_MkUnit)});
    V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
    V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
    V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
    V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
    V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
    v_c_24109 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_2449, heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})}));
  }
  V f_ = v_c_24109;
  heff_room[0] = heff_dup(v_p_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183_lam2, 1, 11, (V[]){v_x_2448, v_acc_247, v_e_240, v_opts_241, v_f_242, v_prog_243, v_width_244, v_names_245, v_left_246, v_p_248, v_p_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_entry, 9, 0};

V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868(V v_e_240, V v_opts_241, V v_f_242, V v_prog_243, V v_width_244, V v_x5_245, V v_acc_246, V v_p_247, V v_p_248) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_f_242);
    heff_drop(v_prog_243);
    heff_drop(v_width_244);
    heff_drop(v_p_247);
    return heff_tail(v_p_248, 1, (V[]){v_acc_246});
  }
  case TAG_Cons: {
    V v_names_249 = heff_field(v_x5_245, 0);
    V v_rest_2410 = heff_field(v_x5_245, 1);
    return (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s376508598x845187183(heff_dup(v_e_240), heff_dup(v_opts_241), heff_dup(v_f_242), heff_dup(v_prog_243), heff_dup(v_width_244), heff_dup(v_names_249), heff_dup(heff_rfield(v_opts_241, 2)), v_acc_246, heff_dup(v_p_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_lam0, 1, 8, (V[]){v_e_240, v_opts_241, v_f_242, v_prog_243, v_width_244, heff_dup(v_rest_2410), v_p_247, v_p_248})));
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_prog_243 = heff_env(self)[3];
  V v_width_244 = heff_env(self)[4];
  V v_rest_2410 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_p_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return ({ V a_0 = v_e_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_prog_243; V a_4 = v_width_244; V a_5 = v_rest_2410; V a_6 = v_x_2411; V a_7 = v_p_247; V a_8 = v_p_248; V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_rest_2410); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str0, 5, "pkg: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str3, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str5, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str6, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str7, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam3(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam3, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_entry, 7, 0};

V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988(V v_e_240, V v_opts_241, V v_f_242, V v_prog_243, V v_bs_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_bs_244)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_opts_241, 4);
    heff_drop(v_f_242);
    heff_drop(v_prog_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  }
  case TAG_Cons: {
    V v_t_249 = heff_dup(heff_rfield(v_opts_241, 3));
    V v_t_2420;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      v_t_2420 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam0_clo);
    } else {
      heff_drop(v_t_249);
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str0), heff_dup(v_f_242)), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str1));
      V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      v_t_2420 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
    }
    return heff_tail(v_t_2420, 2, (V[]){heff_dup(v_p_245), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam1, 1, 7, (V[]){v_bs_244, v_e_240, v_opts_241, v_f_242, v_prog_243, v_p_245, v_p_246})});
  }
  default: return heff_nomatch(v_bs_244);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V f_ = v_p_246;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424 = heff_get_n(v_opts_241, 3, 4);
  V v_t_2436;
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_f_242);
    heff_drop(v_e_240);
    heff_drop(v_t_2424);
    v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam3_clo);
  } else {
    heff_drop(v_t_2424);
    V v_t_2427;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2423, 1)))) {
      v_t_2427 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str5);
    } else {
      v_t_2427 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str6);
    }
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, v_f_242), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str7));
    V v_t_2429 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2428, NTAG(TAG_MkUnit)});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    v_t_2436 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})}));
  }
  V f_ = v_t_2436;
  heff_room[0] = v_p_245;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam4, 1, 2, (V[]){v_p_246, v_x_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_bs_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_prog_243 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2421);
  V v_t_2422 = (g_list_2efoldl_24s141260856x1366916752(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str2), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str3), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_str4), MK_INT(0LL), v_bs_244));
  return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_opts_241); V a_2 = heff_dup(v_f_242); V a_3 = v_prog_243; V a_4 = v_t_2422; V a_5 = v_bs_244; V a_6 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V a_7 = heff_dup(v_p_245); V a_8 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1434816705x2038355988_lam2, 1, 5, (V[]){v_opts_241, v_f_242, v_e_240, v_p_245, v_p_246}); V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s1589927976x2002159868(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop_tag(v_bs_244, 2); r_; });
}