// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_args 9498020
#define LBL_cmt 308164
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_group 299987609
#define LBL_hash 9690581
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_tok 324554
#define LBL_version 583465758
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332(V, V);
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_clo;
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162(V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_clo;
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2_clo;
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242(V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_clo;
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4_clo;
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844(V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_clo;
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_get(void);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535(V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_clo;
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0(V, V, V, V);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091(V, V, V, V, V, V, V);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_clo;
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2enewerTagged(V, V, V);
V g_heff_2ebuild_2efetch_2enewerTagged_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewerTagged_clo;
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328(V, V, V);
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_clo;
V g_heff_2ebuild_2efetch_2erevSaid(V);
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2erevSaid_clo;
HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V);
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789(V, V, V);
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_clo;
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0_clo;
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139(V, V, V);
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_entry(V self, V *a);
extern Clo g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
HeffT3 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT3 g_heff_2ebuild_2eproject_2espanGo_24cpr(V, V);
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eany_24s1435008228x557204311(V, V);
V g_list_2eany_24s1435008228x557204311_entry(V self, V *a);
extern Clo g_list_2eany_24s1435008228x557204311_clo;
V g_list_2eany_24s944501138x775098345(V, V);
V g_list_2eany_24s944501138x775098345_entry(V self, V *a);
extern Clo g_list_2eany_24s944501138x775098345_clo;
V g_list_2efoldl_24s1788498486x1573409871(V, V, V);
V g_list_2efoldl_24s1788498486x1573409871_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1788498486x1573409871_clo;
V g_list_2ekeepIf_24s1943838498x1969994910(V, V);
V g_list_2ekeepIf_24s1943838498x1969994910_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1943838498x1969994910_clo;
V g_list_2ekeepIf_24s25507577x707942422(V, V, V);
V g_list_2ekeepIf_24s25507577x707942422_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s25507577x707942422_clo;
V g_list_2ekeepIf_24s537296923x1092827761(V, V);
V g_list_2ekeepIf_24s537296923x1092827761_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s537296923x1092827761_clo;
V g_list_2emap_24s1193924222x1531824795(V, V, V);
V g_list_2emap_24s1193924222x1531824795_entry(V self, V *a);
extern Clo g_list_2emap_24s1193924222x1531824795_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_prelude_2ewords_2ewordsFrom_240(V, V, V, V);
V g_prelude_2ewords_2ewordsFrom_240_entry(V self, V *a);
extern Clo g_prelude_2ewords_2ewordsFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2efetch_2enewerTagged_str0, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewerTagged_str1, 11, "refs/tags/v");
Clo g_heff_2ebuild_2efetch_2enewerTagged_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewerTagged_entry, 3, 0};

V g_heff_2ebuild_2efetch_2enewerTagged(V v_path_240, V v_best_241, V v_line_242) {
top: ;
  V v_it_243 = ({ V a_0 = v_line_242; V b_1 = ((V)&g_heff_2ebuild_2efetch_2enewerTagged_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2enewerTagged_str1), v_line_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nil: {
    heff_drop(v_path_240);
    return v_best_241;
  }
  case TAG_Cons: {
    V v_it2_245 = heff_field(v_it_243, 1);
    V v_ru_24it_243_24Cons = heff_take_reuse_n(v_it_243, 2ULL, 2);
    switch (heff_tag_of(v_it2_245)) {
    case TAG_Nil: {
      heff_drop(v_path_240);
      heff_drop_cell(v_ru_24it_243_24Cons, 2);
      return v_best_241;
    }
    case TAG_Cons: {
      V v_v_246 = heff_field(v_it2_245, 0);
      V v_it22_247 = heff_field(v_it2_245, 1);
      V v_ru_24it2_245_24Cons = heff_take_reuse_n(v_it2_245, 3ULL, 2);
      switch (heff_tag_of(v_it22_247)) {
      case TAG_Nil: {
        V v_t_248 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
        V v_t_2410 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_249), MK_INT(-1LL)));
        V v_t_2411 = heff_strSlice(heff_dup(v_v_246), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
        HeffT5 v_t_2412 = ({ V a_0 = v_t_2411; HeffT5 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2411); r_; });
        {
          V v_field_2414 = v_t_2412.f[1];
          V v_field_2415 = v_t_2412.f[2];
          V v_field_2416 = v_t_2412.f[3];
          V v_field_2417 = v_t_2412.f[4];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_t_2418 = heff_tag_at_n(v_ru_24it_243_24Cons, TAG_Cons, 2, (V[]){v_field_2415, heff_tag_at_n(v_ru_24it2_245_24Cons, TAG_Cons, 2, (V[]){v_field_2416, v_field_2417})});
            V v_x_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_2414, v_t_2418});
            heff_drop_tag(v_x_2419, 2);
            V v_t_2420 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
            int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
            V v_t_2422 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2421), MK_INT(-1LL)));
            V v_t_2423 = heff_strSlice(heff_dup(v_v_246), v_t_2420, heff_intAdd(v_t_2422, MK_INT(1LL)));
            HeffT2 v_t_2424 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(v_path_240, v_t_2423));
            {
              V v_field_2426 = v_t_2424.f[1];
              int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
              if ((v_tag_2425 == ((int64_t)0ULL))) {
                heff_drop(v_v_246);
                V v_x_2427 = v_field_2426;
                heff_drop(v_x_2427);
                return v_best_241;
              } else {
                heff_drop(v_field_2426);
                switch (heff_tag_of(v_best_241)) {
                case TAG_Nothing: {
                  V v_t_2428 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2429 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2430 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2429), MK_INT(-1LL)));
                  V v_t_2431 = heff_strSlice(v_v_246, v_t_2428, heff_intAdd(v_t_2430, MK_INT(1LL)));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
                }
                case TAG_Just: {
                  V v_b_2432 = heff_dup(heff_field(v_best_241, 0));
                  V v_t_2433 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                  V v_t_2435 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2434), MK_INT(-1LL)));
                  V v_t_2436 = heff_strSlice(heff_dup(v_v_246), v_t_2433, heff_intAdd(v_t_2435, MK_INT(1LL)));
                  V v_t_2437 = ({ V a_0 = v_t_2436; V a_1 = v_b_2432; V r_ = (g_heff_2ebuild_2eproject_2enewer(a_0, a_1)); heff_drop(v_t_2436); heff_drop(v_b_2432); r_; });
                  if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
                    heff_drop_tag(v_best_241, 1);
                    heff_drop(v_t_2437);
                    V v_t_2438 = (g_prelude_2eskipSpaces(v_v_246, MK_INT(0LL), MK_INT(1LL)));
                    int64_t v_t_2439 = (heff_unbox_word(heff_strLength_lent(v_v_246, 0)) - ((int64_t)1ULL));
                    V v_t_2440 = (g_prelude_2eskipSpaces(v_v_246, heff_box_word(v_t_2439), MK_INT(-1LL)));
                    V v_t_2441 = heff_strSlice(v_v_246, v_t_2438, heff_intAdd(v_t_2440, MK_INT(1LL)));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
                  } else {
                    heff_drop(v_v_246);
                    heff_drop(v_t_2437);
                    return v_best_241;
                  }
                }
                default: return heff_nomatch(v_best_241);
                }
              }
            }
          } else {
            heff_drop(v_path_240);
            heff_drop_cell(v_ru_24it_243_24Cons, 2);
            heff_drop(v_v_246);
            heff_drop_cell(v_ru_24it2_245_24Cons, 2);
            heff_drop(v_field_2414);
            heff_drop(v_field_2415);
            heff_drop(v_field_2416);
            heff_drop(v_field_2417);
            return v_best_241;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_247, 0ULL, 2);
        heff_drop(v_path_240);
        heff_drop_cell(v_ru_24it_243_24Cons, 2);
        heff_drop(v_v_246);
        heff_drop_cell(v_ru_24it2_245_24Cons, 2);
        return v_best_241;
      }
      default: return heff_nomatch(v_it22_247);
      }
    }
    default: return heff_nomatch(v_it2_245);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ebuild_2efetch_2enewerTagged_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2efetch_2enewerTagged(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str0, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str1, 28, "commit on the default branch");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str2, 7, "commit ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str3, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str4, 7, "branch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2erevSaid_str5, 7, "branch ");
Clo g_heff_2ebuild_2efetch_2erevSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2erevSaid_entry, 1, 0};

V g_heff_2ebuild_2efetch_2erevSaid(V v_rev_240) {
top: ;
  if (heff_strEq_c_lent(v_rev_240, ((V)&g_heff_2ebuild_2efetch_2erevSaid_str0), 2)) {
    heff_drop(v_rev_240);
    return ((V)&g_heff_2ebuild_2efetch_2erevSaid_str1);
  } else {
    if ((((int64_t)7ULL) <= heff_unbox_word(heff_strLength_lent(v_rev_240, 0)))) {
      if ((heff_unbox_word(heff_strLength_lent(v_rev_240, 0)) <= ((int64_t)40ULL))) {
        V v_t_241 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_rev_240, 0)));
        V v_t_242 = ({ V a_0 = v_rev_240; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_241; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_241); r_; });
        if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str2), v_rev_240);
        } else {
          heff_drop(v_t_242);
          return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str3), v_rev_240);
        }
      } else {
        return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str4), v_rev_240);
      }
    } else {
      return heff_strAppend(((V)&g_heff_2ebuild_2efetch_2erevSaid_str5), v_rev_240);
    }
  }
}
V g_heff_2ebuild_2efetch_2erevSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2erevSaid(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2especOf_24cpr_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2efetch_2especOf_24cpr_str1, 1, "@");

HeffT2 g_heff_2ebuild_2efetch_2especOf_24cpr(V v_spec_240) {
top: ;
  V v_it_241 = ({ V a_0 = v_spec_240; V b_1 = ((V)&g_heff_2ebuild_2efetch_2especOf_24cpr_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2especOf_24cpr_str1), v_spec_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_path_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_path_242);
      return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_spec_240);
        return ((HeffT2){{v_path_242, heff_tag_n(TAG_Just, 1, (V[]){v_v_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it22_245, 0ULL, 2);
        heff_drop(v_path_242);
        heff_drop(v_v_244);
        return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str2, 1, "1");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str3, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str4, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str5, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str6, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str7, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str8, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str9, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str14, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str17, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str18, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str19, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str20, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str21, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str22, 3, "): ");
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_entry, 3, 0};

V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139(V v_path_240, V v_v_241, V v_dir_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_dir_242, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str0), v_t_243), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str1), heff_dup(v_v_241)), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str3), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str5), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str7), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str8), v_t_249});
  return heff_clo_n(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam0, 2, 3, (V[]){v_t_2410, v_path_240, v_v_241});
}
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam1(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  V v_ended_2422 = heff_take_field(v_x_2421, 0);
  V v_err_2423 = heff_get_n(v_x_2421, 2, 3);
  V v_t_2424 = heff_dup(v_ended_2422);
  V v_t_2428;
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Exited: {
    V v_n_2425 = heff_field(v_t_2424, 0);
    heff_take_n(v_t_2424, 1ULL, 1);
    v_t_2428 = heff_bool(heff_intEq_c_lent(v_n_2425, MK_INT(0LL), 2));
    heff_drop(v_n_2425);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2424, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2424);
  }
  V v_x_2450;
  heff_clo_take(self, 3);
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_path_240);
    heff_drop(v_v_241);
    heff_drop(v_ended_2422);
    heff_drop(v_err_2423);
    heff_drop(v_t_2428);
    v_x_2450 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2428);
    V v_t_2429 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
    V v_t_2430 = v_ended_2422;
    V v_t_2439;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Exited: {
      heff_take_n(v_t_2430, 0ULL, 1);
      v_t_2439 = ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str11);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2430, 0ULL, 1);
      v_t_2439 = ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str12);
      break;
    }
    case TAG_TimedOut: {
      v_t_2439 = ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str13);
      break;
    }
    case TAG_NotRun: {
      V v_err_2433 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      V v_path_2434 = heff_take_field(v_err_2433, 3);
      V v_name_2435 = heff_take_field(v_err_2433, 1);
      V v_message_2436 = heff_get_n(v_err_2433, 2, 4);
      V v_t_2437 = heff_strAppend(heff_strAppend(v_path_2434, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str14)), v_name_2435);
      V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str15)), v_message_2436);
      v_t_2439 = heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str16));
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    V v_s_2440 = heff_strAppend(v_t_2439, v_err_2423);
    V v_t_2441 = (g_prelude_2eskipSpaces(v_s_2440, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_s_2440, 0)) - ((int64_t)1ULL));
    V v_t_2443 = (g_prelude_2eskipSpaces(v_s_2440, heff_box_word(v_t_2442), MK_INT(-1LL)));
    V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str17), v_path_240), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str18));
    V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2444, heff_dup(v_v_241)), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str19));
    V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, v_v_241), ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str20));
    V v_t_2447 = heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str21), v_t_2429));
    V v_t_2448 = heff_strSlice(v_s_2440, v_t_2441, heff_intAdd(v_t_2443, MK_INT(1LL)));
    V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str22)), v_t_2448);
    v_x_2450 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2449});
  }
  V f_ = v_k_2412;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str9), v_t_2410, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_str10), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam1_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s535099379x685970669(v_t_2420, v_hd_2411, heff_clo_n(g_heff_2ebuild_2efetch_2etagCloned_24s1040327853x145103139_lam2, 1, 3, (V[]){v_path_240, v_v_241, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str1, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str2, 32, "--date=format-local:%Y%m%d%H%M%S");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str3, 15, "--format=%cd %H");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str4, 3, "log");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str5, 2, "-1");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str6, 2, "TZ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str7, 4, "UTC0");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str8, 3, "git");
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_entry, 2, 0};

V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332(V v_dir_240, V v_rev_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_dir_240));
  V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_242); r_; });
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str0), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_rev_241, ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str1)), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str3), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str5), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str6), ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str7)}), NTAG(TAG_Nil)});
  V v_t_249 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_str8), v_t_247, v_t_243, v_t_248, NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2411 = heff_tag_n(TAG_Run, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam1, 2, 1, (V[]){v_a_2411});
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332(a[0], a[1]);
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_ended_2420 = heff_take_field(v_x_2419, 0);
  V v_out_2421 = heff_get_n(v_x_2419, 1, 3);
  V v_t_2422 = v_ended_2420;
  V v_x_2433;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Exited: {
    V v_n_2423 = heff_field(v_t_2422, 0);
    V v_ru_24t_2422_24Exited = heff_take_reuse_n(v_t_2422, 1ULL, 1);
    if (heff_intEq_c(v_n_2423, MK_INT(0LL))) {
      V v_x1_2424 = ({ V a_0 = v_out_2421; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_prelude_2ewords_2ewordsFrom_240(a_0, a_1, a_2, a_3)); heff_drop(v_out_2421); r_; });
      switch (heff_tag_of(v_x1_2424)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24t_2422_24Exited, 1);
        v_x_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_time_2425 = heff_field(v_x1_2424, 0);
        V v_x12_2426 = heff_field(v_x1_2424, 1);
        V v_ru_24x1_2424_24Cons = heff_take_reuse_n(v_x1_2424, 3ULL, 2);
        switch (heff_tag_of(v_x12_2426)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24t_2422_24Exited, 1);
          heff_drop(v_time_2425);
          heff_drop_cell(v_ru_24x1_2424_24Cons, 2);
          v_x_2433 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_hash_2427 = heff_field(v_x12_2426, 0);
          V v_x122_2428 = heff_field(v_x12_2426, 1);
          heff_take_n(v_x12_2426, 3ULL, 2);
          switch (heff_tag_of(v_x122_2428)) {
          case TAG_Nil: {
            v_x_2433 = heff_tag_at_n(v_ru_24t_2422_24Exited, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_2424_24Cons, TAG_MkPair, 2, (V[]){v_time_2425, v_hash_2427})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x122_2428, 0ULL, 2);
            heff_drop_cell(v_ru_24t_2422_24Exited, 1);
            heff_drop(v_time_2425);
            heff_drop_cell(v_ru_24x1_2424_24Cons, 2);
            heff_drop(v_hash_2427);
            v_x_2433 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x122_2428);
          }
          break;
        }
        default: heff_nomatch(v_x12_2426);
        }
        break;
      }
      default: heff_nomatch(v_x1_2424);
      }
    } else {
      heff_drop(v_out_2421);
      heff_drop_cell(v_ru_24t_2422_24Exited, 1);
      v_x_2433 = NTAG(TAG_Nothing);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2422, 0ULL, 1);
    heff_drop(v_out_2421);
    v_x_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_TimedOut: {
    heff_drop(v_out_2421);
    v_x_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2422, 0ULL, 1);
    heff_drop(v_out_2421);
    v_x_2433 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  heff_clo_take(self, 1);
  V f_ = v_k_2413;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_a_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), v_hd_2412, heff_clo_n(g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332_lam2, 1, 1, (V[]){v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str0, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str2, 9, " (commit ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str4, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str5, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str6, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str7, 13, "--no-checkout");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str8, 18, "--filter=blob:none");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str9, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str10, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str11, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str16, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str17, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str19, 9, "^{commit}");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str20, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str21, 8, "--detach");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str22, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str23, 8, "checkout");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str24, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str25, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str26, 4, "HEAD");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str30, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str31, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str32, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str33, 14, "no such commit");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str34, 17, "the commit is of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str35, 6, ", not ");
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam3, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_entry, 5, 0};

V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745(V v_path_240, V v_v_241, V v_time_242, V v_hash_243, V v_dir_244) {
top: ;
  V v_t_245 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str0), heff_dup(v_path_240)), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str1));
  V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, v_v_241), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str2));
  V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, heff_dup(v_hash_243)), ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str3));
  V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str4), v_t_245));
  V v_x_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str5));
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam0, 2, 5, (V[]){v_path_240, v_dir_244, v_x_2410, v_hash_243, v_time_242});
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam1(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam3(V self, V *args) {
  V v_r_2456 = args[0];
  return v_r_2456;
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam5(V self, V *args) {
  V v_x_2467 = args[0];
  V v_ended_2464 = heff_env(self)[0];
  V v_err_2465 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  V v_t_2468 = heff_dup(v_ended_2464);
  V v_t_2472;
  switch (heff_tag_of(v_t_2468)) {
  case TAG_Exited: {
    V v_n_2469 = heff_field(v_t_2468, 0);
    heff_take_n(v_t_2468, 1ULL, 1);
    v_t_2472 = heff_bool(!heff_intEq_c_lent(v_n_2469, MK_INT(0LL), 2));
    heff_drop(v_n_2469);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2468, 0ULL, 1);
    v_t_2472 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2472 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2468, 0ULL, 1);
    v_t_2472 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2468);
  }
  V v_x_2493;
  heff_clo_take(self, 5);
  if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
    heff_drop(v_x_2467);
    heff_drop(v_time_242);
    heff_drop(v_t_2472);
    V v_t_2473 = v_ended_2464;
    V v_t_2482;
    switch (heff_tag_of(v_t_2473)) {
    case TAG_Exited: {
      heff_take_n(v_t_2473, 0ULL, 1);
      v_t_2482 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str27);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2473, 0ULL, 1);
      v_t_2482 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str28);
      break;
    }
    case TAG_TimedOut: {
      v_t_2482 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str29);
      break;
    }
    case TAG_NotRun: {
      V v_err_2476 = heff_field(v_t_2473, 0);
      heff_take_n(v_t_2473, 1ULL, 1);
      V v_path_2477 = heff_take_field(v_err_2476, 3);
      V v_name_2478 = heff_take_field(v_err_2476, 1);
      V v_message_2479 = heff_get_n(v_err_2476, 2, 4);
      V v_t_2480 = heff_strAppend(heff_strAppend(v_path_2477, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str30)), v_name_2478);
      V v_t_2481 = heff_strAppend(heff_strAppend(v_t_2480, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str31)), v_message_2479);
      v_t_2482 = heff_strAppend(v_t_2481, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str32));
      break;
    }
    default: heff_nomatch(v_t_2473);
    }
    V v_s_2483 = heff_strAppend(v_t_2482, v_err_2465);
    V v_t_2484 = (g_prelude_2eskipSpaces(v_s_2483, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2485 = (heff_unbox_word(heff_strLength_lent(v_s_2483, 0)) - ((int64_t)1ULL));
    V v_t_2486 = (g_prelude_2eskipSpaces(v_s_2483, heff_box_word(v_t_2485), MK_INT(-1LL)));
    V v_t_2487 = heff_strSlice(v_s_2483, v_t_2484, heff_intAdd(v_t_2486, MK_INT(1LL)));
    v_x_2493 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2487)});
  } else {
    heff_drop(v_ended_2464);
    heff_drop(v_err_2465);
    heff_drop(v_t_2472);
    switch (heff_tag_of(v_x_2467)) {
    case TAG_Nothing: {
      heff_drop(v_time_242);
      v_x_2493 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str33))});
      break;
    }
    case TAG_Just: {
      V v_it1_2488 = heff_field(v_x_2467, 0);
      V v_ru_24x_2467_24Just = heff_take_reuse_n(v_x_2467, 1ULL, 1);
      switch (heff_tag_of(v_it1_2488)) {
      case TAG_MkPair: {
        V v_t_2489 = heff_field(v_it1_2488, 0);
        heff_take_n(v_it1_2488, 1ULL, 2);
        if (heff_strEq_c_lent(v_t_2489, v_time_242, 0)) {
          heff_drop(v_x_2410);
          heff_drop(v_time_242);
          heff_drop_cell(v_ru_24x_2467_24Just, 1);
          heff_drop(v_t_2489);
          v_x_2493 = NTAG(TAG_Nothing);
        } else {
          V v_t_2491 = heff_strAppend(heff_strAppend(v_x_2410, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str34)), v_t_2489);
          V v_t_2492 = heff_strAppend(heff_strAppend(v_t_2491, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str35)), v_time_242);
          v_x_2493 = heff_tag_at_n(v_ru_24x_2467_24Just, TAG_Just, 1, (V[]){v_t_2492});
        }
        break;
      }
      default: heff_nomatch(v_it1_2488);
      }
      break;
    }
    default: heff_nomatch(v_x_2467);
    }
  }
  V f_ = v_k_2412;
  args[0] = v_x_2493;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam4(V self, V *args) {
  V v_x_2463 = args[0];
  V v_dir_244 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_time_242 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  V v_ended_2464 = heff_take_field(v_x_2463, 0);
  V v_err_2465 = heff_get_n(v_x_2463, 2, 3);
  heff_clo_take(self, 5);
  V v_t_2466 = (g_heff_2ebuild_2efetch_2ecommitAt_24s1210455017x164551332(v_dir_244, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str26)));
  V f_ = v_t_2466;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam5, 1, 5, (V[]){v_ended_2464, v_err_2465, v_x_2410, v_time_242, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  V v_dir_244 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_time_242 = heff_env(self)[5];
  V v_ended_2427 = heff_take_field(v_x_2426, 0);
  V v_err_2428 = heff_get_n(v_x_2426, 2, 3);
  V v_t_2429 = heff_dup(v_ended_2427);
  V v_t_2433;
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Exited: {
    V v_n_2430 = heff_field(v_t_2429, 0);
    heff_take_n(v_t_2429, 1ULL, 1);
    v_t_2433 = heff_bool(!heff_intEq_c_lent(v_n_2430, MK_INT(0LL), 2));
    heff_drop(v_n_2430);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2429, 0ULL, 1);
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2429, 0ULL, 1);
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2429);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_clo_take(self, 6);
    heff_drop(v_dir_244);
    heff_drop(v_hash_243);
    heff_drop(v_hd_2411);
    heff_drop(v_time_242);
    heff_drop(v_t_2433);
    V v_t_2434 = v_ended_2427;
    V v_t_2443;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_Exited: {
      heff_take_n(v_t_2434, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str13);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2434, 0ULL, 1);
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str14);
      break;
    }
    case TAG_TimedOut: {
      v_t_2443 = ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str15);
      break;
    }
    case TAG_NotRun: {
      V v_err_2437 = heff_field(v_t_2434, 0);
      heff_take_n(v_t_2434, 1ULL, 1);
      V v_path_2438 = heff_take_field(v_err_2437, 3);
      V v_name_2439 = heff_take_field(v_err_2437, 1);
      V v_message_2440 = heff_get_n(v_err_2437, 2, 4);
      V v_t_2441 = heff_strAppend(heff_strAppend(v_path_2438, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str16)), v_name_2439);
      V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str17)), v_message_2440);
      v_t_2443 = heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str18));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    V v_s_2444 = heff_strAppend(v_t_2443, v_err_2428);
    V v_t_2445 = (g_prelude_2eskipSpaces(v_s_2444, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2446 = (heff_unbox_word(heff_strLength_lent(v_s_2444, 0)) - ((int64_t)1ULL));
    V v_t_2447 = (g_prelude_2eskipSpaces(v_s_2444, heff_box_word(v_t_2446), MK_INT(-1LL)));
    V v_t_2448 = heff_strSlice(v_s_2444, v_t_2445, heff_intAdd(v_t_2447, MK_INT(1LL)));
    V v_x_2449 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_2410, v_t_2448)});
    V f_ = v_k_2412;
    args[0] = v_x_2449;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_ended_2427);
    heff_drop(v_err_2428);
    heff_drop(v_t_2433);
    V v_t_2450 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_244)));
    V v_t_2451 = ({ V a_0 = v_t_2450; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2450); r_; });
    heff_clo_take(self, 6);
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_hash_243, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str19)), NTAG(TAG_Nil)});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str20), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str21), v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str22), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str23), v_t_2453})});
    V v_t_2455 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str24), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str25), v_t_2454}), v_t_2451, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2457 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2455, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam3_clo)});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam4, 1, 5, (V[]){v_dir_244, v_hd_2411, v_x_2410, v_time_242, v_k_2412})));
  }
}
V g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_240 = heff_env(self)[0];
  V v_dir_244 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hash_243 = heff_env(self)[3];
  V v_time_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_dir_244), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str6), v_t_2413), v_t_2414});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str8), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str10), v_t_2416})});
  V v_t_2418 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str11), v_t_2417, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_str12), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2418, ((V)&g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam1_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s535099379x685970669(v_t_2425, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitCloned_24s272511505x795930745_lam2, 1, 6, (V[]){v_x_2410, v_k_2412, v_dir_244, v_hash_243, v_hd_2411, v_time_242})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_str0, 5, ".hash");
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_entry, 3, 0};

V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_x_243 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), heff_dup(v_v_242)));
  return heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam0, 2, 4, (V[]){v_x_243, v_ps_240, v_path_241, v_v_242});
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam1(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 6);
    return (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4(v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245, heff_tag_re_n(v_ru_24x_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2416})));
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      V v_err_2418 = heff_field(v_y_2417, 0);
      V v_ru_24y_2417_24Left = heff_take_reuse_n(v_y_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2415_24Right, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4(v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245, heff_tag_re_n(v_ru_24y_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2418})));
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 6);
      return (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_2ek_24l4(v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245, heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Right, 1, (V[]){v_x_2419})));
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_str0))));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam1_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242_lam2, 1, 6, (V[]){v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str0, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str4, 1, "-");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str5, 23, ": its commit is another");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str6, 24, ": its tag has been moved");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str9, 20, ", and heff.sum says ");
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_entry, 6, 0};

V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844(V v_ps_240, V v_root_241, V v_sums_242, V v_by_243, V v_path_244, V v_v_245) {
top: ;
  V v_require_246 = heff_take_field(v_root_241, 2);
  V v_replace_247 = heff_get_n(v_root_241, 3, 4);
  V v_t_248 = (g_list_2ekeepIf_24s1943838498x1969994910(v_path_244, v_require_246));
  V v_t_2414;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_replace_247);
    v_t_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 2);
    V v_t_2411 = (g_list_2ekeepIf_24s537296923x1092827761(v_r_249, v_replace_247));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nil: {
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2412, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nothing: {
    V v_c_2415 = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242(heff_dup(v_ps_240), heff_dup(v_path_244), heff_dup(v_v_245)));
    return heff_clo_n(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_lam0, 2, 6, (V[]){v_c_2415, v_by_243, v_path_244, v_v_245, v_sums_242, v_ps_240});
  }
  case TAG_Just: {
    V v_d_2443 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    heff_drop(v_sums_242);
    heff_drop(v_by_243);
    heff_drop(v_v_245);
    V v_d_2444 = heff_dup(heff_rfield(v_ps_240, 0));
    V v_st_2445 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2445), v_d_2444));
    V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2445), v_d_2443));
    V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
    V v_t_2449 = ({ V a_0 = v_st_2445; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2445); heff_drop(v_t_2448); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(v_ps_240, v_t_2449, v_path_244));
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_by_243 = heff_env(self)[0];
  V v_path_244 = heff_env(self)[1];
  V v_v_245 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  V v_hd_2416 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_sums_242);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_2416);
    V v_t_2420 = heff_strAppend(heff_strAppend(v_by_243, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str0)), v_path_244);
    V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str1)), v_v_245);
    V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str2)), v_why_2419);
    V f_ = v_k_2417;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2422});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2423 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_by_243);
    V v_t_2424 = (g_list_2ekeepIf_24s25507577x707942422(v_path_244, v_v_245, v_sums_242));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop(v_h_2423);
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      V v_t_2425 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
      V v_t_2426 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(v_ps_240, v_t_2425, v_path_244));
      V f_ = v_t_2426;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      V v_s_2427 = heff_field(v_t_2424, 0);
      V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 1ULL, 2);
      V v_want_2429 = heff_get_n(v_s_2427, 2, 3);
      if (heff_strEq_c_lent(v_h_2423, v_want_2429, 0)) {
        heff_drop(v_h_2423);
        heff_drop_cell(v_ru_24x_2418_24Right, 1);
        heff_drop_cell(v_ru_24t_2424_24Cons, 2);
        heff_drop(v_want_2429);
        V v_t_2430 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_244), v_v_245));
        V v_t_2431 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(v_ps_240, v_t_2430, v_path_244));
        V f_ = v_t_2431;
        heff_room[0] = v_hd_2416;
        heff_room[1] = v_k_2417;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_hd_2416);
        V v_t_2432 = ({ V a_0 = v_v_245; V b_1 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str3); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str4), v_v_245, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
        HeffT3 v_t_2433 = ({ V a_0 = v_t_2432; HeffT3 r_ = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(a_0)); heff_drop(v_t_2432); r_; });
        {
          V v_field_2435 = v_t_2433.f[1];
          V v_field_2436 = v_t_2433.f[2];
          int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
          V v_t_2438;
          if ((v_tag_2434 == ((int64_t)0ULL))) {
            V v_x_2437 = heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_MkPair, 2, (V[]){v_field_2435, v_field_2436});
            heff_drop_tag(v_x_2437, 2);
            v_t_2438 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str5);
          } else {
            heff_drop_cell(v_ru_24t_2424_24Cons, 2);
            heff_drop(v_field_2435);
            heff_drop(v_field_2436);
            v_t_2438 = ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str6);
          }
          V v_t_2439 = heff_strAppend(heff_strAppend(v_path_244, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str7)), v_v_245);
          V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str8)), v_h_2423);
          V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_str9)), v_want_2429);
          V v_x_2442 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_t_2441, v_t_2438)});
          V f_ = v_k_2417;
          args[0] = v_x_2442;
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_by_243 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_sums_242 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2efetchedPkg_24s518184716x2139248844_lam1, 1, 7, (V[]){v_by_243, v_path_244, v_v_245, v_k_2417, v_sums_242, v_ps_240, v_hd_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_str0, 5, ".hash");
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam0, 2, 0};
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam3, 1, 0};
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_entry, 3, 0};

V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789(V v_ps_240, V v_root_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_root_241);
    return ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789(heff_dup(v_ps_240), heff_dup(v_root_241), v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_x_245, v_root_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam3(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_x_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_x_245; V a_1 = v_root_241; V a_2 = v_x_2410; V a_3 = v_k_249; V b_4 = heff_tag_re_n(v_ru_24x_2422_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2423}); V r_ = (g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  }
  case TAG_Right: {
    V v_y_2424 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Right = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    switch (heff_tag_of(v_y_2424)) {
    case TAG_Left: {
      V v_err_2425 = heff_field(v_y_2424, 0);
      V v_ru_24y_2424_24Left = heff_take_reuse_n(v_y_2424, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2422_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_x_245; V a_1 = v_root_241; V a_2 = v_x_2410; V a_3 = v_k_249; V b_4 = heff_tag_re_n(v_ru_24y_2424_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2425}); V r_ = (g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    case TAG_Right: {
      V v_x_2426 = heff_field(v_y_2424, 0);
      heff_take_n(v_y_2424, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_x_245; V a_1 = v_root_241; V a_2 = v_x_2410; V a_3 = v_k_249; V b_4 = heff_tag_at_n(v_ru_24x_2422_24Right, TAG_Right, 1, (V[]){v_x_2426}); V r_ = (g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    default: return heff_nomatch(v_y_2424);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2ebuild_2eload_2ecachedDir(v_ps_240, heff_dup(heff_rfield(v_x_245, 0)), heff_dup(heff_rfield(v_x_245, 1))));
  V v_s_2412 = heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_str0));
  V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2412));
  V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2413; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2413); r_; });
  V v_a_2416 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam3_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2421, v_hd_248, heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam4, 1, 4, (V[]){v_x_245, v_root_241, v_x_2410, v_k_249})));
}
V g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2esumsOf_24s804116002x1514869789_lam2, 1, 5, (V[]){v_ps_240, v_x_245, v_hd_248, v_root_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_str1, 10, "package.hf");
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam3(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam3, 1, 0};
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam0(V self, V *args);

static V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_val;
static HEFF_ONCE g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_st;
static V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_init(void) {
  V v_c_240 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam0, 2, 1, (V[]){v_c_240});
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_st)) return g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_val;
  return heff_global(&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_val, &g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_st, g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_init);
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam3(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 3);
    return ({ V a_0 = v_hd_241; V a_1 = v_k_242; V a_2 = v_x_245; V b_3 = heff_tag_re_n(v_ru_24x_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2416}); V r_ = (g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      V v_err_2418 = heff_field(v_y_2417, 0);
      V v_ru_24y_2417_24Left = heff_take_reuse_n(v_y_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2415_24Right, 1);
      heff_clo_take(self, 3);
      return ({ V a_0 = v_hd_241; V a_1 = v_k_242; V a_2 = v_x_245; V b_3 = heff_tag_re_n(v_ru_24y_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2418}); V r_ = (g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 3);
      return ({ V a_0 = v_hd_241; V a_1 = v_k_242; V a_2 = v_x_245; V b_3 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Right, 1, (V[]){v_x_2419}); V r_ = (g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_2ek_24l0(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_str1)));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam3_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam4, 1, 3, (V[]){v_hd_241, v_k_242, v_x_245})));
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_t_244 = (g_heff_2ebuild_2eload_2epathsFor_24s1915612435x232390091(v_x_243, ((V)&g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_str0)));
  heff_clo_take(self, 2);
  V f_ = v_t_244;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_240;
  args[0] = heff_dup(v_hd_241);
  args[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetAll_24s109394334x431986471_lam1, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str4, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str5, 3, "git");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str13, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str14, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str15, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str17, 1, "\012");
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam2(V self, V *args); static Clo g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam2, 1, 0};
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_entry, 3, 0};

V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328(V v_path_240, V v_p_241, V v_p_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str0), heff_dup(v_path_240)), MK_INT(0LL), ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam0_clo)});
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  HEFF_LAST return g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam1, 1, 3, (V[]){v_path_240, v_p_241, v_p_242}));
}
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam2(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ended_2420 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_err_2421 = heff_env(self)[2];
  V v_out_2422 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  heff_drop(v_x_2425);
  V v_t_2426 = heff_dup(v_ended_2420);
  V v_t_2430;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Exited: {
    V v_n_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_t_2430 = heff_bool(!heff_intEq_c_lent(v_n_2427, MK_INT(0LL), 2));
    heff_drop(v_n_2427);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2426, 0ULL, 1);
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  V v_x_2452;
  heff_clo_take(self, 5);
  if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
    heff_drop(v_out_2422);
    heff_drop(v_t_2430);
    V v_t_2431 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_240));
    V v_t_2432 = v_ended_2420;
    V v_t_2441;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Exited: {
      heff_take_n(v_t_2432, 0ULL, 1);
      v_t_2441 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str7);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2432, 0ULL, 1);
      v_t_2441 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str8);
      break;
    }
    case TAG_TimedOut: {
      v_t_2441 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str9);
      break;
    }
    case TAG_NotRun: {
      V v_err_2435 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 1);
      V v_path_2436 = heff_take_field(v_err_2435, 3);
      V v_name_2437 = heff_take_field(v_err_2435, 1);
      V v_message_2438 = heff_get_n(v_err_2435, 2, 4);
      V v_t_2439 = heff_strAppend(heff_strAppend(v_path_2436, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str10)), v_name_2437);
      V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str11)), v_message_2438);
      v_t_2441 = heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str12));
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_s_2442 = heff_strAppend(v_t_2441, v_err_2421);
    V v_t_2443 = (g_prelude_2eskipSpaces(v_s_2442, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2444 = (heff_unbox_word(heff_strLength_lent(v_s_2442, 0)) - ((int64_t)1ULL));
    V v_t_2445 = (g_prelude_2eskipSpaces(v_s_2442, heff_box_word(v_t_2444), MK_INT(-1LL)));
    V v_t_2446 = heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str13), heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str14), v_t_2431));
    V v_t_2447 = heff_strSlice(v_s_2442, v_t_2443, heff_intAdd(v_t_2445, MK_INT(1LL)));
    V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str15)), v_t_2447);
    v_x_2452 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2448});
  } else {
    heff_drop(v_ended_2420);
    heff_drop(v_err_2421);
    heff_drop(v_t_2430);
    V v_s_2449 = v_out_2422;
    V v_t_2450 = ({ V a_0 = v_s_2449; V b_1 = ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str16); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str17), v_s_2449, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_2449); heff_drop(b_1); r_; });
    V v_t_2451 = ({ V a_0 = v_path_240; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2450; V r_ = (g_list_2efoldl_24s1788498486x1573409871(a_0, a_1, a_2)); heff_drop(v_t_2450); r_; });
    v_x_2452 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2451});
  }
  V f_ = v_p_242;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_ended_2420 = heff_take_field(v_x_2419, 0);
  V v_err_2421 = heff_take_field(v_x_2419, 2);
  V v_out_2422 = heff_get_n(v_x_2419, 1, 3);
  heff_clo_take(self, 4);
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){v_x_246, NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_p_241, heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam4, 1, 5, (V[]){v_ended_2420, v_path_240, v_err_2421, v_out_2422, v_p_242})));
}
V g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_t_247 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str1), v_t_247), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str3), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str4), v_t_249});
  V v_t_2411 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str5), v_t_2410, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_str6), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(v_t_2418, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2efetch_2enewestTag_24s432959991x878959328_lam3, 1, 4, (V[]){v_x_246, v_p_241, v_path_240, v_p_242})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_str0, 7, "commits");
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam1(V self, V *args); static Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam1, 1, 0};
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam0(V self, V *args);
Clo g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_entry, 3, 0};

V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162(V v_ps_240, V v_path_241, V v_rev_242) {
top: ;
  V v_x_243 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_str0)));
  return heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam0, 2, 4, (V[]){v_x_243, v_ps_240, v_rev_242, v_path_241});
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam1(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_rev_242 = heff_env(self)[3];
  V v_path_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 6);
    return ({ V a_0 = v_ps_240; V a_1 = v_x_243; V a_2 = v_hd_244; V a_3 = v_rev_242; V a_4 = v_path_241; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24x_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2416}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      V v_err_2418 = heff_field(v_y_2417, 0);
      V v_ru_24y_2417_24Left = heff_take_reuse_n(v_y_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2415_24Right, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_ps_240; V a_1 = v_x_243; V a_2 = v_hd_244; V a_3 = v_rev_242; V a_4 = v_path_241; V a_5 = v_k_245; V b_6 = heff_tag_re_n(v_ru_24y_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2418}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 6);
      return ({ V a_0 = v_ps_240; V a_1 = v_x_243; V a_2 = v_hd_244; V a_3 = v_rev_242; V a_4 = v_path_241; V a_5 = v_k_245; V b_6 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Right, 1, (V[]){v_x_2419}); V r_ = (g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_2ek_24l2(a_0, a_1, a_2, a_3, a_4, a_5, b_6)); heff_drop(b_6); r_; });
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rev_242 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_243)));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam1_clo)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2efetch_2ecommitVersion_24s975070924x1187795162_lam2, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_rev_242, v_path_241, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str1, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str5, 3, "src");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str6, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str8, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str10, 1, "`");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str11, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str12, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str13, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str15, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str18, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str19, 13, ", require = [");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str20, 1, "]");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str23, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str24, 13, ", replace = [");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str25, 1, "]");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str26, 11, "{ module = ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str27, 9, ", heff = ");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str28, 2, " }");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str29, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str30, 3, ".hf");
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam1(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam0(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam4(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam3(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam8(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam7(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam10(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam9(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam12(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam11(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam13(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam13, 1, 0};
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam14(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam6(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam5(V self, V *args);
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam2(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_entry, 7, 0};

V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091(V v_ps_240, V v_text_241, V v_pk_242, V v_path_243, V v_v_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_243), heff_dup(v_v_244)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_text_241);
      heff_drop_rec(v_pk_242, 4);
      heff_drop(v_v_244);
      V v_why_2410 = v_field_249;
      V v_t_2411 = heff_strAppend(heff_strAppend(v_path_243, ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str0)), v_why_2410);
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str1), v_t_2411), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str2));
      V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam0, 1, 2, (V[]){v_z_245, v_z_246})));
    } else {
      heff_drop(v_field_249);
      V v_c_2427 = (g_heff_2ebuild_2efetch_2efetched_24s317527618x663519242(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
      return heff_tail(v_c_2427, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam2, 1, 7, (V[]){v_z_245, v_z_246, v_ps_240, v_path_243, v_v_244, v_pk_242, v_text_241})});
    }
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_drop(v_x_2426);
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_drop(v_x_2419);
  V v_t_2420 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_z_245, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam1, 1, 1, (V[]){v_z_246})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam4(V self, V *args) {
  V v_x_2444 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_drop(v_x_2444);
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), v_z_245, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam4, 1, 1, (V[]){v_z_246})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam8(V self, V *args) {
  V v_x_2472 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_drop(v_x_2472);
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam7(V self, V *args) {
  V v_x_2465 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_drop(v_x_2465);
  V v_t_2466 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_z_245, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam8, 1, 1, (V[]){v_z_246})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam10(V self, V *args) {
  V v_x_2489 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_drop(v_x_2489);
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam9(V self, V *args) {
  V v_x_2482 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_drop(v_x_2482);
  V v_t_2483 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2488}), v_z_245, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam10, 1, 1, (V[]){v_z_246})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam12(V self, V *args) {
  V v_x_24109 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_drop(v_x_24109);
  heff_clo_take(self, 1);
  V f_ = v_z_246;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam11(V self, V *args) {
  V v_x_24102 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_drop(v_x_24102);
  V v_t_24103 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24108}), v_z_245, heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam12, 1, 1, (V[]){v_z_246})));
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam13(V self, V *args) {
  V v_r_24161 = args[0];
  return v_r_24161;
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam14(V self, V *args) {
  V v_x_24168 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_path_243 = heff_env(self)[2];
  V v_v_244 = heff_env(self)[3];
  switch (heff_tag_of(v_x_24168)) {
  case TAG_Left: {
    V v_x_24169 = heff_field(v_x_24168, 0);
    V v_ru_24x_24168_24Left = heff_take_reuse_n(v_x_24168, 1ULL, 1);
    heff_clo_take(self, 4);
    return (g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_2ek_24l0(v_z_245, v_z_246, v_path_243, v_v_244, heff_tag_re_n(v_ru_24x_24168_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_24169})));
  }
  case TAG_Right: {
    V v_y_24170 = heff_field(v_x_24168, 0);
    V v_ru_24x_24168_24Right = heff_take_reuse_n(v_x_24168, 1ULL, 1);
    switch (heff_tag_of(v_y_24170)) {
    case TAG_Left: {
      V v_err_24171 = heff_field(v_y_24170, 0);
      V v_ru_24y_24170_24Left = heff_take_reuse_n(v_y_24170, 1ULL, 1);
      heff_drop_cell(v_ru_24x_24168_24Right, 1);
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_2ek_24l0(v_z_245, v_z_246, v_path_243, v_v_244, heff_tag_re_n(v_ru_24y_24170_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_24171})));
    }
    case TAG_Right: {
      V v_x_24172 = heff_field(v_y_24170, 0);
      heff_take_n(v_y_24170, 1ULL, 1);
      heff_clo_take(self, 4);
      return (g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_2ek_24l0(v_z_245, v_z_246, v_path_243, v_v_244, heff_tag_at_n(v_ru_24x_24168_24Right, TAG_Right, 1, (V[]){v_x_24172})));
    }
    default: return heff_nomatch(v_y_24170);
    }
  }
  default: return heff_nomatch(v_x_24168);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  V v_text_241 = heff_env(self)[5];
  V v_v_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2448)) {
  case TAG_Left: {
    V v_why_2457 = heff_field(v_x_2448, 0);
    V v_ru_24x_2448_24Left = heff_take_reuse_n(v_x_2448, 1ULL, 1);
    heff_drop(v_x_2456);
    heff_drop(v_path_243);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_text_241);
    heff_drop(v_v_244);
    V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str6), v_why_2457), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str7));
    V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2458, NTAG(TAG_MkUnit)});
    V v_t_2460 = heff_tag_at_n(v_ru_24x_2448_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam7, 1, 2, (V[]){v_z_245, v_z_246})));
  }
  case TAG_Right: {
    V v_ru_24x_2448_24Right = heff_take_reuse_n(v_x_2448, 0ULL, 1);
    switch (heff_tag_of(v_x_2456)) {
    case TAG_Left: {
      V v_why_2474 = heff_field(v_x_2456, 0);
      V v_ru_24x_2456_24Left = heff_take_reuse_n(v_x_2456, 1ULL, 1);
      heff_drop(v_path_243);
      heff_drop_rec(v_pk_242, 4);
      heff_drop(v_text_241);
      heff_drop(v_v_244);
      V v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str8), v_why_2474), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str9));
      V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2475, NTAG(TAG_MkUnit)});
      V v_t_2477 = heff_tag_at_n(v_ru_24x_2448_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2456_24Left, TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam9, 1, 2, (V[]){v_z_245, v_z_246})));
    }
    case TAG_Right: {
      V v_name_2490 = heff_field(v_x_2456, 0);
      V v_ru_24x_2456_24Right = heff_take_reuse_n(v_x_2456, 1ULL, 1);
      V v_x1_2491 = (g_list_2eany_24s1435008228x557204311(v_path_243, heff_rfield(v_pk_242, 2)));
      V v_t_2492;
      if (!(heff_dup(v_x1_2491) == NTAG(TAG_True))) {
        heff_drop(v_x1_2491);
        v_t_2492 = (g_list_2eany_24s944501138x775098345(v_name_2490, heff_rfield(v_pk_242, 2)));
      } else {
        heff_drop(v_x1_2491);
        v_t_2492 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
        heff_drop_rec(v_pk_242, 4);
        heff_drop(v_text_241);
        heff_drop(v_v_244);
        heff_drop(v_t_2492);
        V v_t_2493 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str10), v_name_2490), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str11));
        V v_t_2494 = heff_strAppend(heff_strAppend(v_t_2493, v_path_243), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str12));
        V v_t_2495 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str13), v_t_2494), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str14));
        V v_t_2496 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2495, NTAG(TAG_MkUnit)});
        V v_t_2497 = heff_tag_at_n(v_ru_24x_2448_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2456_24Right, TAG_InL, 1, (V[]){v_t_2496})});
        V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
        V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
        V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
        V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
        return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam11, 1, 2, (V[]){v_z_245, v_z_246})));
      } else {
        heff_drop(v_t_2492);
        V v_path_24110 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str15)));
        V v_src_24111 = v_text_241;
        V v_t_24112 = (g_list_2eany_24s1435008228x557204311(v_path_243, heff_rfield(v_pk_242, 2)));
        V v_t_24114;
        if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
          heff_drop(v_name_2490);
          heff_drop(v_t_24112);
          v_t_24114 = (g_list_2emap_24s1193924222x1531824795(heff_dup(v_path_243), heff_dup(v_v_244), heff_dup(heff_rfield(v_pk_242, 2))));
        } else {
          heff_drop(v_t_24112);
          V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_2490, heff_dup(v_path_243), heff_dup(v_v_244)}), NTAG(TAG_Nil)});
          v_t_24114 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_242, 2)), v_t_24113));
        }
        V v_pk_24115 = ({ V rv_2 = v_t_24114; V rr_ = heff_rec_reuse_nf(v_pk_242, 11ULL, 4, shape_module__heff__require__replace, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_24116 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        HeffT3 v_t_24117 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_24111), v_t_24116, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
        {
          V v_field_24118 = v_t_24117.f[0];
          heff_drop(v_t_24117.f[1]);
          heff_drop(v_t_24117.f[2]);
          HeffT3 v_t_24121 = ({ V b_0 = heff_arrayFromList(v_field_24118); V a_1 = MK_INT(0LL); HeffT3 r_ = (g_heff_2ebuild_2eproject_2espanGo_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
          {
            V v_field_24123 = v_t_24121.f[1];
            V v_field_24124 = v_t_24121.f[2];
            int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
            V v_text_24153;
            if ((v_tag_24122 == ((int64_t)0ULL))) {
              V v_from_24125 = v_field_24123;
              V v_to_24126 = v_field_24124;
              V v_pk_24127 = v_pk_24115;
              V v_module_24128 = heff_take_field(v_pk_24127, 0);
              V v_heff_24129 = heff_take_field(v_pk_24127, 1);
              V v_require_24130 = heff_take_field(v_pk_24127, 2);
              V v_replace_24131 = heff_get_n(v_pk_24127, 3, 4);
              V v_t_24132 = ({ V a_0 = v_module_24128; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_module_24128); r_; });
              V v_t_24133 = ({ V a_0 = v_heff_24129; V r_ = (g_heff_2ebuild_2eproject_2equoted(a_0)); heff_drop(v_heff_24129); r_; });
              V v_items_24134 = (g_list_2emap_24s1381986540x1952410492(v_require_24130));
              V v_t_24140;
              switch (heff_tag_of(v_items_24134)) {
              case TAG_Nil: {
                v_t_24140 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str16);
                break;
              }
              case TAG_Cons: {
                V v_t_24139;
                switch (heff_tag_of(v_items_24134)) {
                case TAG_Nil: {
                  v_t_24139 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str17);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24137 = heff_field(v_items_24134, 0);
                  V v_xs_24138 = heff_field(v_items_24134, 1);
                  heff_take_n(v_items_24134, 3ULL, 2);
                  v_t_24139 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str18); V a_1 = v_x_24137; V a_2 = v_xs_24138; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24138); r_; });
                  break;
                }
                default: heff_nomatch(v_items_24134);
                }
                v_t_24140 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str19), v_t_24139), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str20));
                break;
              }
              default: heff_nomatch(v_items_24134);
              }
              V v_items_24141 = (g_list_2emap_24s404123879x745642248(v_replace_24131));
              V v_t_24147;
              switch (heff_tag_of(v_items_24141)) {
              case TAG_Nil: {
                v_t_24147 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str21);
                break;
              }
              case TAG_Cons: {
                V v_t_24146;
                switch (heff_tag_of(v_items_24141)) {
                case TAG_Nil: {
                  v_t_24146 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str22);
                  break;
                }
                case TAG_Cons: {
                  V v_x_24144 = heff_field(v_items_24141, 0);
                  V v_xs_24145 = heff_field(v_items_24141, 1);
                  heff_take_n(v_items_24141, 3ULL, 2);
                  v_t_24146 = ({ V a_0 = ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str23); V a_1 = v_x_24144; V a_2 = v_xs_24145; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24145); r_; });
                  break;
                }
                default: heff_nomatch(v_items_24141);
                }
                v_t_24147 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str24), v_t_24146), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str25));
                break;
              }
              default: heff_nomatch(v_items_24141);
              }
              V v_t_24148 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str26), v_t_24132), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str27));
              V v_t_24149 = heff_strAppend(heff_strAppend(v_t_24148, v_t_24133), v_t_24140);
              V v_t_24150 = heff_strAppend(heff_strAppend(v_t_24149, v_t_24147), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str28));
              V v_t_24151 = heff_strAppend(heff_strSlice_lent(v_src_24111, MK_INT(0LL), v_from_24125, 6), v_t_24150);
              V v_t_24152 = heff_strSlice(heff_dup(v_src_24111), v_to_24126, heff_strLength(v_src_24111));
              v_text_24153 = heff_strAppend(v_t_24151, v_t_24152);
            } else {
              heff_drop_rec(v_pk_24115, 4);
              heff_drop(v_field_24123);
              heff_drop(v_field_24124);
              v_text_24153 = v_src_24111;
            }
            V v_text_24159;
            if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str29), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str30))) {
              HeffT2 v_t_24154 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_24153)));
              {
                V v_field_24156 = v_t_24154.f[1];
                int64_t v_tag_24155 = ((int64_t)v_t_24154.f[0]);
                if ((v_tag_24155 == ((int64_t)0ULL))) {
                  V v_x_24157 = v_field_24156;
                  heff_drop(v_x_24157);
                  v_text_24159 = v_text_24153;
                } else {
                  heff_drop(v_text_24153);
                  V v_out_24158 = v_field_24156;
                  v_text_24159 = v_out_24158;
                }
              }
            } else {
              v_text_24159 = v_text_24153;
            }
            V v_t_24160 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24110; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24110); r_; });
            V v_a_24162 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_24160, v_text_24159, ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam13_clo)});
            V v_t_24163 = heff_tag_at_n(v_ru_24x_2448_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x_2456_24Right, TAG_InR, 1, (V[]){v_a_24162})});
            V v_t_24164 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24163})});
            V v_t_24165 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24164})});
            V v_t_24166 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24165})});
            V v_t_24167 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24166})});
            return (g_co_2eop_24s1896221640x2141527803(v_t_24167, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam14, 1, 4, (V[]){v_z_245, v_z_246, v_path_243, v_v_244})));
          }
        }
      }
    }
    default: return heff_nomatch(v_x_2456);
    }
  }
  default: return heff_nomatch(v_x_2448);
  }
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam5(V self, V *args) {
  V v_x_2448 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_path_243 = heff_env(self)[1];
  V v_v_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  V v_st_2449 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_a_2450 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2449), v_a_2450));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2449), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str5)));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  V v_t_2454 = ({ V a_0 = v_st_2449; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2449); heff_drop(v_t_2453); r_; });
  heff_clo_take(self, 7);
  V v_t_2455 = (g_heff_2ebuild_2eload_2eownDir_24s1788087503x1381049315(v_ps_240, v_t_2454));
  V f_ = v_t_2455;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam6, 1, 7, (V[]){v_x_2448, v_z_245, v_z_246, v_path_243, v_pk_242, v_text_241, v_v_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_243 = heff_env(self)[3];
  V v_v_244 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  V v_text_241 = heff_env(self)[6];
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    V v_why_2429 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Left = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    heff_clo_take(self, 7);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_243);
    heff_drop(v_v_244);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_text_241);
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str3), v_why_2429), ((V)&g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_str4));
    V v_t_2431 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_at_n(v_ru_24x_2428_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam3, 1, 2, (V[]){v_z_245, v_z_246})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2428, 0ULL, 1);
    V v_t_2446 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_243), heff_dup(v_v_244)));
    V v_t_2447 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1598490304x1159574546(heff_dup(v_ps_240), v_t_2446, heff_dup(v_path_243)));
    heff_clo_take(self, 7);
    V f_ = v_t_2447;
    heff_room[0] = heff_dup(v_z_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2efetch_2egetRequire_24s1037967840x93761091_lam5, 1, 7, (V[]){v_ps_240, v_path_243, v_v_244, v_z_245, v_z_246, v_pk_242, v_text_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2428);
  }
}
HEFF_LIT(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_str0, 10, "package.hf");
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam0(V self, V *args); static Clo g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam0, 1, 0};
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam2(V self, V *args);
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam1(V self, V *args);
Clo g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_entry, 1, 0};

V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535(V v_spec_240) {
top: ;
  V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_str0)));
  V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_241); r_; });
  V v_a_244 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam1, 2, 2, (V[]){v_a_244, v_spec_240});
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535(a[0]);
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_spec_240 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_x_2413 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    heff_clo_take(self, 3);
    return (g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0(v_hd_245, v_k_246, v_spec_240, heff_tag_re_n(v_ru_24x_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2413})));
  }
  case TAG_Right: {
    V v_y_2414 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2414)) {
    case TAG_Left: {
      V v_err_2415 = heff_field(v_y_2414, 0);
      V v_ru_24y_2414_24Left = heff_take_reuse_n(v_y_2414, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0(v_hd_245, v_k_246, v_spec_240, heff_tag_re_n(v_ru_24y_2414_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2415})));
    }
    case TAG_Right: {
      V v_x_2416 = heff_field(v_y_2414, 0);
      heff_take_n(v_y_2414, 1ULL, 1);
      heff_clo_take(self, 3);
      return (g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_2ek_24l0(v_hd_245, v_k_246, v_spec_240, heff_tag_at_n(v_ru_24x_2412_24Right, TAG_Right, 1, (V[]){v_x_2416})));
    }
    default: return heff_nomatch(v_y_2414);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_a_244 = heff_env(self)[0];
  V v_spec_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2411, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2efetch_2egetCmd_24s1428660948x2089732535_lam2, 1, 3, (V[]){v_hd_245, v_k_246, v_spec_240})));
}