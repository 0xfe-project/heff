// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_HE 9070
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_globals 352931696
#define LBL_gs 10067
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_order 307364712
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_self 10021907
#define LBL_used 10094724
static uint32_t shape_code__decls[] = {LBL_code, LBL_decls};
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_js__env__pre[] = {LBL_js, LBL_env, LBL_pre};
static uint32_t shape_js__pre__env[] = {LBL_js, LBL_pre, LBL_env};
static uint32_t shape_key__params[] = {LBL_key, LBL_params};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452(V, V, V);
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
V g_heff_2ecompile_2eemit_2ebindName(V, V);
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindName_clo;
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo;
V g_heff_2ecompile_2eemit_2eboolCode(V);
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eboolCode_clo;
V g_heff_2ecompile_2eemit_2ebundleAll(V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_clo;
V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo;
V g_heff_2ecompile_2eemit_2ebundleProvider(V, V);
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo;
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2ecompile_2eemit_2ecompileJsWith(V, V);
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo;
V g_heff_2ecompile_2eemit_2econdCode(V);
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdCode_clo;
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2edeclsOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_clo;
V g_heff_2ecompile_2eemit_2edeclsOf_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_24dps_clo;
V g_heff_2ecompile_2eemit_2eeagerCode(V, V);
V g_heff_2ecompile_2eemit_2eeagerCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eeagerCode_clo;
V g_heff_2ecompile_2eemit_2eescAt(V, V);
V g_heff_2ecompile_2eemit_2eescAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eescAt_clo;
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2efindProv(V, V);
V g_heff_2ecompile_2eemit_2efindProv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efindProv_clo;
V g_heff_2ecompile_2eemit_2efixedCode(V, V);
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efixedCode_clo;
V g_heff_2ecompile_2eemit_2egetterOf(V, V);
V g_heff_2ecompile_2eemit_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2egetterOf_clo;
V g_heff_2ecompile_2eemit_2eglobalJsH(V, V, V);
V g_heff_2ecompile_2eemit_2eglobalJsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eglobalJsH_clo;
V g_heff_2ecompile_2eemit_2ehandlerOf(V, V);
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo;
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2eisIdent(V);
V g_heff_2ecompile_2eemit_2eisIdent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eisIdent_clo;
V g_heff_2ecompile_2eemit_2ejsSource(V, V);
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsSource_clo;
V g_heff_2ecompile_2eemit_2ejsVer(V, V, V);
V g_heff_2ecompile_2eemit_2ejsVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsVer_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2elooped(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elooped_clo;
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_clo;
V g_heff_2ecompile_2eemit_2enamedAs(V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
V g_heff_2ecompile_2eemit_2eoperatorGo(V, V, V);
V g_heff_2ecompile_2eemit_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eoperatorGo_clo;
V g_heff_2ecompile_2eemit_2eprimBin(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimBin_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU(V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo;
V g_heff_2ecompile_2eemit_2eprimOp(V);
V g_heff_2ecompile_2eemit_2eprimOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimOp_clo;
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
V g_heff_2ecompile_2eemit_2eprovStrHelpers(V, V);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereserved_get(void);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemit_2eruntimeFor(V, V, V, V);
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_clo;
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
V g_heff_2ecompile_2eemit_2eseqsOf_24dps(V, V);
V g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_24dps_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo;
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_clo;
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
V g_heff_2ecompile_2eemit_2ewrapper(V, V, V, V);
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ewrapper_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eirtext_2ehashW(V, V, V);
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ehashW_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s651308273x925219243(V);
V g_list_2eany_24s651308273x925219243_entry(V self, V *a);
extern Clo g_list_2eany_24s651308273x925219243_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s1366476796x894764441(V, V);
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1149721393x617397893(V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2eemit_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2equoteGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244 = (g_heff_2ecompile_2eemit_2eescAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2equoteGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastDotFrom_entry, 2, 0};

V g_heff_2ecompile_2eemit_2elastDotFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(46LL))) {
      heff_drop(v_s_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elastDotFrom(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str3, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str7, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str8, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str11, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str12, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str14, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str15, 3, "op_");
Clo g_heff_2ecompile_2eemit_2espellAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2espellAt_entry, 2, 0};

V g_heff_2ecompile_2eemit_2espellAt(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    if (heff_strEq_c(heff_dup(v_k_240), ((V)&g_heff_2ecompile_2eemit_2espellAt_str0))) {
      return v_k_240;
    } else {
      V v_x1_243 = (g_heff_2ecompile_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_243)) {
      case TAG_Nothing: {
        return v_k_240;
      }
      case TAG_Just: {
        V v_ws_244 = heff_field(v_x1_243, 0);
        heff_take_n(v_x1_243, 1ULL, 1);
        heff_drop(v_k_240);
        V v_t_247;
        switch (heff_tag_of(v_ws_244)) {
        case TAG_Nil: {
          v_t_247 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_245 = heff_field(v_ws_244, 0);
          V v_xs_246 = heff_field(v_ws_244, 1);
          heff_take_n(v_ws_244, 3ULL, 2);
          v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
          break;
        }
        default: heff_nomatch(v_ws_244);
        }
        V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str3), v_t_247);
        return v_t_248;
      }
      default: return heff_nomatch(v_x1_243);
      }
    }
  }
  case TAG_Just: {
    V v_i_249 = heff_field(v_x2_241, 0);
    V v_x_2410 = heff_strSlice(heff_dup(v_k_240), heff_intAdd(heff_dup(v_i_249), MK_INT(1LL)), heff_strLength(heff_dup(v_k_240)));
    if (heff_strEq_c(heff_dup(v_x_2410), ((V)&g_heff_2ecompile_2eemit_2espellAt_str4))) {
      heff_drop(v_x_2410);
      if (heff_strEq_c(heff_dup(v_k_240), ((V)&g_heff_2ecompile_2eemit_2espellAt_str5))) {
        return v_k_240;
      } else {
        V v_x1_2413 = (g_heff_2ecompile_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_Nothing: {
          return v_k_240;
        }
        case TAG_Just: {
          V v_ws_2414 = heff_field(v_x1_2413, 0);
          heff_take_n(v_x1_2413, 1ULL, 1);
          heff_drop(v_k_240);
          V v_t_2417;
          switch (heff_tag_of(v_ws_2414)) {
          case TAG_Nil: {
            v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str6);
            break;
          }
          case TAG_Cons: {
            V v_x_2415 = heff_field(v_ws_2414, 0);
            V v_xs_2416 = heff_field(v_ws_2414, 1);
            heff_take_n(v_ws_2414, 3ULL, 2);
            v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str7); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
            break;
          }
          default: heff_nomatch(v_ws_2414);
          }
          V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str8), v_t_2417);
          return v_t_2418;
        }
        default: return heff_nomatch(v_x1_2413);
        }
      }
    } else {
      V v_x1_2419 = (g_heff_2ecompile_2eemit_2eoperatorGo(v_x_2410, MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_Nothing: {
        if (heff_strEq_c(heff_dup(v_k_240), ((V)&g_heff_2ecompile_2eemit_2espellAt_str9))) {
          return v_k_240;
        } else {
          V v_x1_2421 = (g_heff_2ecompile_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
          switch (heff_tag_of(v_x1_2421)) {
          case TAG_Nothing: {
            return v_k_240;
          }
          case TAG_Just: {
            V v_ws_2422 = heff_field(v_x1_2421, 0);
            heff_take_n(v_x1_2421, 1ULL, 1);
            heff_drop(v_k_240);
            V v_t_2425;
            switch (heff_tag_of(v_ws_2422)) {
            case TAG_Nil: {
              v_t_2425 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str10);
              break;
            }
            case TAG_Cons: {
              V v_x_2423 = heff_field(v_ws_2422, 0);
              V v_xs_2424 = heff_field(v_ws_2422, 1);
              heff_take_n(v_ws_2422, 3ULL, 2);
              v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str11); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
              break;
            }
            default: heff_nomatch(v_ws_2422);
            }
            V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str12), v_t_2425);
            return v_t_2426;
          }
          default: return heff_nomatch(v_x1_2421);
          }
        }
      }
      case TAG_Just: {
        V v_ws_2427 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2430;
        switch (heff_tag_of(v_ws_2427)) {
        case TAG_Nil: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str13);
          break;
        }
        case TAG_Cons: {
          V v_x_2428 = heff_field(v_ws_2427, 0);
          V v_xs_2429 = heff_field(v_ws_2427, 1);
          heff_take_n(v_ws_2427, 3ULL, 2);
          v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str14); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
          break;
        }
        default: heff_nomatch(v_ws_2427);
        }
        V v_w_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str15), v_t_2430);
        V v_t_2432 = heff_strSlice(v_k_240, MK_INT(0LL), heff_intAdd(heff_dup(v_i_249), MK_INT(1LL)));
        return heff_strAppend(v_t_2432, v_w_2431);
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2espellAt(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str0, 10, "Uint8Array");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str1, 11, "TextEncoder");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str2, 11, "TextDecoder");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str3, 15, "structuredClone");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str4, 3, "URL");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str5, 12, "setImmediate");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str6, 14, "queueMicrotask");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str7, 6, "RegExp");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str8, 6, "Buffer");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str9, 4, "Date");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str10, 6, "Symbol");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str11, 3, "Map");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str12, 3, "Set");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str13, 7, "Promise");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str14, 5, "Array");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str15, 7, "console");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str16, 10, "globalThis");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str17, 5, "fetch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str18, 7, "process");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str19, 4, "JSON");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str20, 10, "setTimeout");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str21, 5, "Error");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str22, 4, "Math");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str23, 6, "Number");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str24, 6, "Object");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str25, 6, "BigInt");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str26, 6, "String");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str27, 8, "document");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str28, 6, "window");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str29, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str30, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str31, 4, "eval");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str32, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str33, 5, "await");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str34, 9, "arguments");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str35, 9, "protected");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str36, 6, "public");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str37, 7, "package");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str38, 7, "private");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str39, 10, "implements");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str40, 9, "interface");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str41, 3, "let");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str42, 6, "static");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str43, 4, "with");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str44, 5, "yield");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str45, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str46, 5, "while");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str47, 6, "typeof");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str48, 3, "var");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str49, 4, "true");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str50, 3, "try");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str51, 4, "this");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str52, 5, "throw");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str53, 5, "super");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str54, 6, "switch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str55, 4, "null");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str56, 6, "return");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str57, 10, "instanceof");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str58, 3, "new");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str59, 6, "import");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str60, 2, "in");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str61, 8, "function");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str62, 2, "if");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str63, 7, "finally");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str64, 3, "for");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str65, 7, "extends");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str66, 5, "false");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str67, 4, "enum");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str68, 6, "export");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str69, 2, "do");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str70, 4, "else");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str71, 7, "default");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str72, 6, "delete");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str73, 8, "continue");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str74, 8, "debugger");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str75, 5, "class");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str76, 5, "const");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str77, 4, "case");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str78, 5, "catch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str79, 5, "break");

static V g_heff_2ecompile_2eemit_2ereserved_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2ereserved_st;
static V g_heff_2ecompile_2eemit_2ereserved_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str12), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str14), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str16), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str18), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str20), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str22), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str24), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str26), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str28), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str30), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str32), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str33), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str34), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str35), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str36), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str38), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str39), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str40), v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str41), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str42), v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str43), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str44), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str45), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str46), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str47), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str48), v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str49), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str50), v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str51), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str52), v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str53), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str54), v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str55), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str56), v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str57), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str58), v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str59), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str60), v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str61), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str62), v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str63), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str64), v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str65), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str66), v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str67), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str68), v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str69), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str70), v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str71), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str72), v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str73), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str74), v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str75), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str76), v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str77), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str78), v_t_2438})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str79), v_t_2439});
}
V g_heff_2ecompile_2eemit_2ereserved_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2ereserved_st)) return g_heff_2ecompile_2eemit_2ereserved_val;
  return heff_global(&g_heff_2ecompile_2eemit_2ereserved_val, &g_heff_2ecompile_2eemit_2ereserved_st, g_heff_2ecompile_2eemit_2ereserved_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2esafeRes_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2esafeRes_str1, 1, "_");
Clo g_heff_2ecompile_2eemit_2esafeRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esafeRes_entry, 1, 0};

V g_heff_2ecompile_2eemit_2esafeRes(V v_s_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_s_240)}));
  V v_t_242 = ({ V a_0 = v_t_241; V b_1 = heff_dup(g_heff_2ecompile_2eemit_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esafeRes_str0), v_s_240);
  } else {
    heff_drop(v_t_242);
    if (heff_intLe_c(MK_INT(48LL), heff_strByteAt(heff_dup(v_s_240), MK_INT(0LL)))) {
      if (heff_intLe_c(heff_strByteAt(heff_dup(v_s_240), MK_INT(0LL)), MK_INT(57LL))) {
        return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esafeRes_str1), v_s_240);
      } else {
        return v_s_240;
      }
    } else {
      return v_s_240;
    }
  }
}
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esafeRes(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ebindName_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebindName_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ebindName_str2, 1, "x");
Clo g_heff_2ecompile_2eemit_2ebindName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebindName_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebindName(V v_env_240, V v_x_241) {
top: ;
  V v_x0_242 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_241), MK_INT(0LL)));
  V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x0_242)), MK_INT(1LL));
  V v_t_244 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x0_242), v_t_243));
  V v_t_245 = ({ V a_0 = v_x0_242; V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_s_246 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_245, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ebindName_str0)));
  V v_t_248;
  if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_heff_2ecompile_2eemit_2ebindName_str1))) {
    heff_drop(v_s_246);
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2ebindName_str2);
  } else {
    v_t_248 = v_s_246;
  }
  V v_t_249 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_248));
  return (g_heff_2ecompile_2eemit_2ebindFrom(v_env_240, v_x_241, v_t_249, MK_INT(0LL)));
}
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebindName(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str0, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str13, 1, " ");
Clo g_heff_2ecompile_2eemit_2eprimBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimBin_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimBin(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_244 = heff_bool((heff_strEq_c(heff_dup(v_op_240), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str0)) || heff_strEq_c(heff_dup(v_op_240), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str1))));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_247;
    if (heff_intLt_c(heff_dup(heff_rfield(v_a_241, 1)), MK_INT(2LL))) {
      V v_t_246 = heff_strAppend(heff_get_n(v_a_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str2));
      v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str3), v_t_246);
    } else {
      v_t_247 = heff_get_n(v_a_241, 0, 2);
    }
    V v_t_2410;
    if (heff_intLt_c(heff_dup(heff_rfield(v_b_242, 1)), MK_INT(3LL))) {
      V v_t_249 = heff_strAppend(heff_get_n(v_b_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str4));
      v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str5), v_t_249);
    } else {
      v_t_2410 = heff_get_n(v_b_242, 0, 2);
    }
    V v_t_2411 = heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str6), v_t_2410));
    V v_t_2412 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str7), v_t_2411));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2412, MK_INT(2LL)});
  } else {
    heff_drop(v_t_244);
    V v_t_2415;
    if (heff_intLt_c(heff_dup(heff_rfield(v_a_241, 1)), MK_INT(1LL))) {
      V v_t_2414 = heff_strAppend(heff_get_n(v_a_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str8));
      v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str9), v_t_2414);
    } else {
      v_t_2415 = heff_get_n(v_a_241, 0, 2);
    }
    V v_t_2418;
    if (heff_intLt_c(heff_dup(heff_rfield(v_b_242, 1)), MK_INT(2LL))) {
      V v_t_2417 = heff_strAppend(heff_get_n(v_b_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str10));
      v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str11), v_t_2417);
    } else {
      v_t_2418 = heff_get_n(v_b_242, 0, 2);
    }
    V v_t_2419 = heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str12), v_t_2418));
    V v_t_2420 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str13), v_t_2419));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2420, MK_INT(1LL)});
  }
}
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimBin(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str1, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str2, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str3, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str4, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str5, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str6, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str7, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str8, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str9, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str10, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str11, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str12, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str13, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str14, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str15, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str16, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str17, 2, "<=");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str18, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str19, 1, "+");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str20, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str21, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str22, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str23, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str24, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str25, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str26, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str27, 3, "===");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str28, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str29, 1, "<");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str30, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimOp_str31, 2, "<=");
Clo g_heff_2ecompile_2eemit_2eprimOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimOp_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eprimOp(V v_x1_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str0))) {
    heff_drop(v_x1_240);
    V v_t_242 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str1)}));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_242});
  } else {
    if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str2))) {
      heff_drop(v_x1_240);
      V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str3)}));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str4))) {
        heff_drop(v_x1_240);
        V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str5)}));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
      } else {
        if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str6))) {
          heff_drop(v_x1_240);
          V v_t_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str7)}));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
        } else {
          if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str8))) {
            heff_drop(v_x1_240);
            V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str9)}));
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
          } else {
            if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str10))) {
              heff_drop(v_x1_240);
              V v_t_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str11)}));
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
            } else {
              if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str12))) {
                heff_drop(v_x1_240);
                V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str13)}));
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
              } else {
                if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str14))) {
                  heff_drop(v_x1_240);
                  V v_t_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str15)}));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
                } else {
                  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str16))) {
                    heff_drop(v_x1_240);
                    V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str17)}));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2418});
                  } else {
                    if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str18))) {
                      heff_drop(v_x1_240);
                      V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str19)}));
                      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
                    } else {
                      if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str20))) {
                        heff_drop(v_x1_240);
                        V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str21)}));
                        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
                      } else {
                        if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str22))) {
                          heff_drop(v_x1_240);
                          V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str23)}));
                          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2424});
                        } else {
                          if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str24))) {
                            heff_drop(v_x1_240);
                            V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str25)}));
                            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2426});
                          } else {
                            if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str26))) {
                              heff_drop(v_x1_240);
                              V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str27)}));
                              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2428});
                            } else {
                              if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str28))) {
                                heff_drop(v_x1_240);
                                V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str29)}));
                                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
                              } else {
                                if (heff_strEq_c(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_str30))) {
                                  V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str31)}));
                                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
                                } else {
                                  return NTAG(TAG_Nothing);
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimOp(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellPrim_str0, 4, "hole");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellPrim_str1, 8, "setField");
Clo g_heff_2ecompile_2eemit_2ecellPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecellPrim_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecellPrim(V v_x1_240, V v_x2_241) {
top: ;
  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2ecellPrim_str0))) {
    heff_drop(v_x1_240);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  } else {
    if (heff_strEq_c(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2ecellPrim_str1))) {
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x22_247 = heff_field(v_x2_241, 1);
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_x221_248 = heff_field(v_x22_247, 0);
          V v_x222_249 = heff_field(v_x22_247, 1);
          switch (heff_tag_of(v_x221_248)) {
          case TAG_SVar: {
            return NTAG(TAG_False);
          }
          case TAG_SGlobal: {
            return NTAG(TAG_False);
          }
          case TAG_SInt: {
            switch (heff_tag_of(v_x222_249)) {
            case TAG_Nil: {
              return NTAG(TAG_False);
            }
            case TAG_Cons: {
              V v_x2222_2414 = heff_field(v_x222_249, 1);
              switch (heff_tag_of(v_x2222_2414)) {
              case TAG_Nil: {
                return NTAG(TAG_True);
              }
              case TAG_Cons: {
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_x2222_2414);
              }
            }
            default: return heff_nomatch(v_x222_249);
            }
          }
          case TAG_SFloat: {
            return NTAG(TAG_False);
          }
          case TAG_SStr: {
            return NTAG(TAG_False);
          }
          case TAG_SBytes: {
            return NTAG(TAG_False);
          }
          case TAG_SFixed: {
            return NTAG(TAG_False);
          }
          case TAG_SFloat32: {
            return NTAG(TAG_False);
          }
          case TAG_SPrimFn: {
            return NTAG(TAG_False);
          }
          case TAG_SLam: {
            return NTAG(TAG_False);
          }
          case TAG_STag: {
            return NTAG(TAG_False);
          }
          case TAG_SRec: {
            return NTAG(TAG_False);
          }
          case TAG_SProj: {
            return NTAG(TAG_False);
          }
          case TAG_SPrim: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x221_248);
          }
        }
        default: return heff_nomatch(v_x22_247);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    } else {
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ecellPrim(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemit_2eseqsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eseqsOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eseqsOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_JTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_JFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_JRel: {
    return NTAG(TAG_Nil);
  }
  case TAG_JNot: {
    V v_q_242 = heff_field(v_p_240, 0);
    V t_0 = v_q_242;
    v_p_240 = t_0;
    goto top;
  }
  case TAG_JIf: {
    V v_c_243 = heff_field(v_p_240, 0);
    V v_t_244 = heff_field(v_p_240, 1);
    V v_e_245 = heff_field(v_p_240, 2);
    V v_t_246 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_243));
    V v_t_247 = (g_heff_2ecompile_2eemit_2eseqsOf(v_t_244));
    V v_t_248 = (g_heff_2ecompile_2eemit_2eseqsOf(v_e_245));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
    return (g_prelude_2e_2b_2b(v_t_246, v_t_249));
  }
  case TAG_JSeq: {
    V v_x_2410 = heff_field(v_p_240, 0);
    V v_q_2412 = heff_field(v_p_240, 2);
    V v_cell_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2410), heff_hole()});
    V v_u_2414 = (g_heff_2ecompile_2eemit_2eseqsOf_24dps(v_q_2412, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eseqsOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2eseqsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eseqsOf_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_JTrue: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JFalse: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JRel: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JNot: {
    V v_q_243 = heff_field(v_p_240, 0);
    V t_0 = v_q_243;
    V t_1 = v_d_241;
    v_p_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_JIf: {
    V v_c_244 = heff_field(v_p_240, 0);
    V v_t_245 = heff_field(v_p_240, 1);
    V v_e_246 = heff_field(v_p_240, 2);
    V v_t_247 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_244));
    V v_t_248 = (g_heff_2ecompile_2eemit_2eseqsOf(v_t_245));
    V v_t_249 = (g_heff_2ecompile_2eemit_2eseqsOf(v_e_246));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_247, v_t_2410));
    return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
  }
  case TAG_JSeq: {
    V v_x_2412 = heff_field(v_p_240, 0);
    V v_q_2414 = heff_field(v_p_240, 2);
    V v_cell_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), heff_hole()});
    V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_q_2414;
    V t_1 = v_cell_2415;
    v_p_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eseqsOf_24dps(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str0, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str1, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str4, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str7, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str8, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str10, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str13, 10, " \? $T : $F");
Clo g_heff_2ecompile_2eemit_2eboolCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eboolCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eboolCode(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_JTrue: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eboolCode_str0), MK_INT(3LL)});
  }
  case TAG_JFalse: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eboolCode_str1), MK_INT(3LL)});
  }
  case TAG_JRel: {
    V v_c_242 = (g_heff_2ecompile_2eemit_2econdCode(v_c_240));
    V v_t_245;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_242, 1)), MK_INT(1LL))) {
      V v_t_244 = heff_strAppend(heff_get_n(v_c_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str2));
      v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str3), v_t_244);
    } else {
      v_t_245 = heff_get_n(v_c_242, 0, 2);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str4)), MK_INT(0LL)});
  }
  case TAG_JNot: {
    V v_c_247 = (g_heff_2ecompile_2eemit_2econdCode(v_c_240));
    V v_t_2410;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_247, 1)), MK_INT(1LL))) {
      V v_t_249 = heff_strAppend(heff_get_n(v_c_247, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str5));
      v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str6), v_t_249);
    } else {
      v_t_2410 = heff_get_n(v_c_247, 0, 2);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str7)), MK_INT(0LL)});
  }
  case TAG_JIf: {
    V v_c_2414 = (g_heff_2ecompile_2eemit_2econdCode(v_c_240));
    V v_t_2417;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2414, 1)), MK_INT(1LL))) {
      V v_t_2416 = heff_strAppend(heff_get_n(v_c_2414, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str8));
      v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str9), v_t_2416);
    } else {
      v_t_2417 = heff_get_n(v_c_2414, 0, 2);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str10)), MK_INT(0LL)});
  }
  case TAG_JSeq: {
    V v_c_2421 = (g_heff_2ecompile_2eemit_2econdCode(v_c_240));
    V v_t_2424;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2421, 1)), MK_INT(1LL))) {
      V v_t_2423 = heff_strAppend(heff_get_n(v_c_2421, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eboolCode_str11));
      v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str12), v_t_2423);
    } else {
      v_t_2424 = heff_get_n(v_c_2421, 0, 2);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str13)), MK_INT(0LL)});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eboolCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str1, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str2, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str3, 1, "-");
Clo g_heff_2ecompile_2eemit_2efixedCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2efixedCode_entry, 2, 0};

V g_heff_2ecompile_2eemit_2efixedCode(V v_w_240, V v_n_241) {
top: ;
  V v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if (heff_intEq_c(v_t_242, MK_INT(64LL))) {
    V v_s_244 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_244), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str0))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_244, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str1)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_244, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str2)), MK_INT(3LL)});
    }
  } else {
    V v_s_246 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_246), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str3))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_246, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_246, MK_INT(3LL)});
    }
  }
}
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2efixedCode(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str3, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str4, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str5, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str6, 6, "const ");
Clo g_heff_2ecompile_2eemit_2edeclsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edeclsOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2edeclsOf(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_js_240);
    heff_drop(v_ind_241);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_246 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(heff_intShow(heff_dup(v_i_243)), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str3));
    V v_t_2411 = heff_strAppend(heff_dup(v_js_240), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str4), v_t_2410));
    V v_t_2412 = heff_strAppend(v_v_244, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str5), v_t_2411));
    V v_t_2413 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str6), v_t_2412));
    V v_cell_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_heff_2ecompile_2eemit_2edeclsOf_24dps(v_js_240, v_ind_241, v_rest_245, heff_intAdd(v_i_243, MK_INT(1LL)), heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2edeclsOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str3, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str4, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str5, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str6, 6, "const ");
Clo g_heff_2ecompile_2eemit_2edeclsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry, 5, 0};

V g_heff_2ecompile_2eemit_2edeclsOf_24dps(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_js_240);
    heff_drop(v_ind_241);
    heff_drop(v_i_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_v_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str0)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(heff_intShow(heff_dup(v_i_243)), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str3));
    V v_t_2412 = heff_strAppend(heff_dup(v_js_240), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str4), v_t_2411));
    V v_t_2413 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str5), v_t_2412));
    V v_t_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str6), v_t_2413));
    V v_cell_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_js_240;
    V t_1 = v_ind_241;
    V t_2 = v_rest_246;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_cell_2415;
    v_js_240 = t_0;
    v_ind_241 = t_1;
    v_x3_242 = t_2;
    v_i_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2edeclsOf_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str5, 6, "const ");
Clo g_heff_2ecompile_2eemit_2enamedAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamedAs_entry, 3, 0};

V g_heff_2ecompile_2eemit_2enamedAs(V v_ind_240, V v_c_241, V v_nb_242) {
top: ;
  V v_x2_243 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2enamedAs_str0)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(heff_get_n(v_c_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2enamedAs_str3));
  V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_nb_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2enamedAs_str4), v_t_247));
  V v_t_249 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2enamedAs_str5), v_t_248));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__pre__env, (V[]){heff_dup(heff_rfield(v_nb_242, 0)), v_t_2410, heff_get_n(v_nb_242, 1, 2)});
}
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamedAs(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str0, 0, "");
Clo g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry, 5, 0};

V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(V v_lit_240, V v_lit_241, V v_env_242, V v_ind_243, V v_base_244) {
top: ;
  if (heff_strEq_c(heff_dup(v_lit_240), ((V)&g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str0))) {
    V v_t_246 = (g_heff_2ecompile_2eemit_2ebindName(v_env_242, v_base_244));
    return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_243, heff_rec_n(2, shape_code__prec, (V[]){v_lit_240, v_lit_241}), v_t_246));
  } else {
    V v_t_247 = (g_heff_2ecompile_2eemit_2eatomGo(heff_dup(v_lit_240), MK_INT(0LL)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_lit_241);
      heff_drop(v_ind_243);
      heff_drop(v_base_244);
      heff_drop(v_t_247);
      return heff_rec_n(3, shape_js__pre__env, (V[]){v_lit_240, NTAG(TAG_Nil), v_env_242});
    } else {
      heff_drop(v_t_247);
      V v_t_248 = (g_heff_2ecompile_2eemit_2ebindName(v_env_242, v_base_244));
      return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_243, heff_rec_n(2, shape_code__prec, (V[]){v_lit_240, v_lit_241}), v_t_248));
    }
  }
}
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str1, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str8, 5, "$c = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str9, 6, "const ");
Clo g_heff_2ecompile_2eemit_2ewrapper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ewrapper_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ewrapper(V v_curried_240, V v_key_241, V v_i_242, V v_js_243) {
top: ;
  V v_t_247;
  if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_242, 1)))) {
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(v_key_241, v_curried_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
  } else {
    heff_drop(v_key_241);
    v_t_247 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_x2_248 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ecompile_2eemit_2ewrapper_str0), ((V)&g_heff_2ecompile_2eemit_2ewrapper_str1), heff_dup(v_js_243)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_js_243)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_js_243, 0);
      V v_xs_2413 = heff_field(v_js_243, 1);
      heff_take_n(v_js_243, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str5); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_js_243);
    }
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str6), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2ewrapper_str7)));
    V v_t_2416 = heff_strAppend(heff_dup(heff_rfield(v_i_242, 0)), v_t_2415);
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str8), heff_strAppend(v_t_2411, v_t_2416));
    V v_t_2418 = heff_strAppend(heff_get_n(v_i_242, 0, 4), v_t_2417);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str9), v_t_2418), NTAG(TAG_Nil)});
  } else {
    heff_drop_rec(v_i_242, 4);
    heff_drop(v_js_243);
    heff_drop(v_t_247);
    return NTAG(TAG_Nil);
  }
}
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2ewrapper(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry, 3, 0};

V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V v_env_240, V v_ind_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_244, NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    V v_t_247 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_OApply: {
    V v_t_2410 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_OPrim: {
    V v_t_2413 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2413, NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    V v_t_2414 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2414, NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_2415 = heff_field(v_o_242, 0);
    V v_jc_2416 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(v_env_240, v_ind_241, heff_dup(v_c_2415)));
    V v_t_2417 = (g_heff_2ecompile_2eemit_2eboolCode(heff_dup(v_jc_2416)));
    V v_t_2418 = ({ V a_0 = v_jc_2416; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_jc_2416); r_; });
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2417, v_t_2418});
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str5, 6, "const ");
Clo g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry, 4, 0};

V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(V v_env_240, V v_ind_241, V v_v_242, V v_b_243) {
top: ;
  V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_242));
  V v_t_249 = heff_strAppend(heff_get_n(v_t_248, 0, 2), ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str3));
  V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_b_243, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str4), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str5), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__env__pre, (V[]){heff_dup(heff_rfield(v_b_243, 0)), heff_get_n(v_b_243, 1, 2), v_t_2412});
}
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13, 1, "s");
Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry, 3, 0};

V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V v_env_240, V v_ind_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_v_242, 0);
    V v_ru_24v_242_24SVar = heff_take_reuse_n(v_v_242, 1ULL, 1);
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_243), heff_rfield(v_env_240, 1)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0)));
      return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V b_2 = heff_tag_at_n(v_ru_24v_242_24SVar, TAG_SVar, 1, (V[]){v_x_243}); V a_3 = v_t_245; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
    }
    case TAG_Just: {
      V v_js_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop(v_ind_241);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24v_242_24SVar, 1);
      return heff_rec_n(3, shape_js__env__pre, (V[]){v_js_246, v_env_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_SGlobal: {
    V v_t_248 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SInt: {
    V v_t_2410 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SFloat: {
    V v_t_2412 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2412; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SStr: {
    V v_t_2414 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2414; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SBytes: {
    V v_t_2416 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2416; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SFixed: {
    V v_t_2419 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2419; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  case TAG_SFloat32: {
    V v_t_2421 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2421; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SPrimFn: {
    V v_t_2423 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2423; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SLam: {
    V v_t_2426 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2426; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  case TAG_STag: {
    V v_t_2430 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2430; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 3); r_; });
  }
  case TAG_SRec: {
    V v_t_2433 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2433; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  case TAG_SProj: {
    V v_t_2438 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2438; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 4); r_; });
  }
  case TAG_SPrim: {
    V v_t_2441 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2441; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  default: return heff_nomatch(v_v_242);
  }
}
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry, 3, 0};

V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    V v_p_245 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = heff_dup(v_ss_243); V b_3 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_t_244)}); V r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    V v_t_246 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(heff_take_field(v_p_245, 1), v_ind_241, v_t_244));
    return (g_prelude_2e_2b_2b(heff_get_n(v_p_245, 0, 2), v_t_246));
  }
  case TAG_TReturn: {
    V v_o_247 = heff_field(v_x4_242, 0);
    HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, heff_dup(v_o_247));
  }
  case TAG_TLoop: {
    V v_as_248 = heff_field(v_x4_242, 0);
    HEFF_LAST return g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452(v_env_240, v_ind_241, heff_dup(v_as_248));
  }
  case TAG_TIf: {
    V v_c_249 = heff_field(v_x4_242, 0);
    V v_t_2410 = heff_field(v_x4_242, 1);
    V v_f_2411 = heff_field(v_x4_242, 2);
    V v_t_2412 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), heff_dup(v_c_249)));
    return (g_heff_2ecompile_2eemit_2eifLines(v_ind_241, v_t_2412, heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_t_2410)}), heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1, 1, 2, (V[]){v_env_240, heff_dup(v_f_2411)})));
  }
  case TAG_TCase: {
    V v_v_2415 = heff_field(v_x4_242, 0);
    V v_arms_2416 = heff_field(v_x4_242, 1);
    V v_t_2417 = (g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(v_env_240, heff_dup(v_ind_241), heff_dup(v_v_2415)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(v_ind_241, heff_dup(v_arms_2416), v_t_2417);
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0(V self, V *args) {
  V v_i_2413 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_t_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_i_2413; V a_2 = v_t_2410; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1(V self, V *args) {
  V v_i_2414 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_f_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_i_2414; V a_2 = v_f_2411; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_f_2411); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str3, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str4, 6, ") => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str5, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str6, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str7, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str10, 10, "    const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str12, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str13, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str14, 3, "  }");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str15, 12, "  for (;;) {");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str16, 0, "");
Clo g_heff_2ecompile_2eemit_2elooped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elooped_entry, 4, 0};

V g_heff_2ecompile_2eemit_2elooped(V v_key_240, V v_i_241, V v_t_242, V v_r_243) {
top: ;
  V v_x2_244 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str0), heff_dup(heff_rfield(v_r_243, 0))));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2elooped_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str3), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemit_2elooped_str4)));
  V v_t_249 = heff_strAppend(heff_get_n(v_i_241, 0, 4), v_t_248);
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str5), v_t_249), NTAG(TAG_Nil)});
  V v_t_2411 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str6), heff_dup(heff_rfield(v_r_243, 0))));
  V v_x2_2412 = (g_list_2ezipWith_24s1149721393x617397893(((V)&g_heff_2ecompile_2eemit_2elooped_str7), heff_dup(heff_rfield(v_r_243, 0)), v_t_2411));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2elooped_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str9); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str10), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2elooped_str11)));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str12), heff_take_field(v_r_243, 0)));
  V v_s_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__params, (V[]){v_key_240, v_t_2418})});
  V v_env_2420 = heff_get_n(v_r_243, 1, 2);
  V v_t_2421 = ({ V rv_3 = v_s_2419; V rr_ = heff_rec_reuse_nf(v_env_2420, 23ULL, 5, shape_gs__names__used__self__inl, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2422 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_t_2421, MK_INT(2LL), v_t_242));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str13), NTAG(TAG_Nil)});
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str14), v_t_2423})));
  V v_t_2425 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str15), v_t_2417}), v_t_2424));
  return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str16), v_t_2410}), v_t_2425));
}
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2elooped(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str0, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str1, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str2, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str3, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str4, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str5, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str6, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str7, 3, ")()");
Clo g_heff_2ecompile_2eemit_2eeagerCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eeagerCode_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eeagerCode(V v_env_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_TSeq: {
    V v_t_244 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str1)));
  }
  case TAG_TReturn: {
    V v_o_245 = heff_field(v_t_241, 0);
    V v_t_246 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, MK_INT(0LL), v_o_245));
    return heff_get_n(v_t_246, 0, 2);
  }
  case TAG_TLoop: {
    V v_t_248 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str2), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str3)));
  }
  case TAG_TIf: {
    V v_t_2412 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str4), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str5)));
  }
  case TAG_TCase: {
    V v_t_2415 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str6), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str7)));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eemit_2eeagerCode_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eeagerCode(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str3, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str6, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str7, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str8, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str9, 7, "const $");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str12, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str13, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str14, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str15, 7, "const $");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str16, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str17, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str19, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str23, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str25, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str26, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str27, 5, "$c = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str28, 7, "const $");
Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimHelperU_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimHelperU(V v_uses_240, V v_p_241, V v_u_242) {
top: ;
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str0), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str1)));
  V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(v_t_243, v_uses_240));
  V v_t_2423;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str2), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str3)));
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(v_t_245, v_uses_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      V v_t_248 = heff_dup(heff_rfield(v_u_242, 0));
      V v_t_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        V v_xs_2410 = heff_field(v_t_248, 1);
        heff_take_n(v_t_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2412 = heff_strAppend(heff_dup(heff_rfield(v_u_242, 1)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str6));
      V v_t_2413 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str7), v_t_2412));
      V v_t_2414 = heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str8), v_t_2413));
      v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str9), v_t_2414), NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    V v_t_2416 = heff_dup(heff_rfield(v_u_242, 0));
    V v_t_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_t_2416, 0);
      V v_xs_2418 = heff_field(v_t_2416, 1);
      heff_take_n(v_t_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str11); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_u_242, 1)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str12));
    V v_t_2421 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str13), v_t_2420));
    V v_t_2422 = heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str14), v_t_2421));
    v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str15), v_t_2422), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str16), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str17)));
  V v_x3_2425 = (g_map_2elookup_24s659669741x1036301430(v_t_2424, v_uses_240));
  V v_t_2427;
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_Nothing: {
    v_t_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2425, 0ULL, 1);
    v_t_2427 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2425);
  }
  V v_t_2440;
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_t_2427);
    V v_x2_2428 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str18), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str19), heff_dup(heff_rfield(v_u_242, 0))));
    V v_t_2431;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_xs_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str21); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2428);
    }
    V v_t_2432 = heff_get_n(v_u_242, 0, 2);
    V v_t_2435;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nil: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_t_2432, 0);
      V v_xs_2434 = heff_field(v_t_2432, 1);
      heff_take_n(v_t_2432, 3ULL, 2);
      v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str23); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str24), heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str25)));
    V v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str26), heff_strAppend(heff_dup(v_p_241), v_t_2436));
    V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str27), heff_strAppend(v_t_2431, v_t_2437));
    V v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str28), heff_strAppend(v_p_241, v_t_2438));
    v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
  } else {
    heff_drop(v_p_241);
    heff_drop_rec(v_u_242, 2);
    heff_drop(v_t_2427);
    v_t_2440 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2423, v_t_2440));
}
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprimHelperU(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsVer_str0, 2, "js");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsVer_str1, 1, "-");
V g_heff_2ecompile_2eemit_2ejsVer_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ejsVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsVer_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ejsVer(V v_p_240, V v_key_241, V v_b_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
  V v_t_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_xs_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_key_241), v_t_244});
  V v_m_246 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop_tag(v_xs_245, 2); r_; });
  V v_t_247 = ({ V a_0 = v_m_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_246); r_; });
  V v_t_248 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_247));
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2ejsVer_lam0, 2, 1, (V[]){v_p_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_242}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_key_241}), v_t_2412});
  V v_items_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsVer_str0)}), v_t_2413});
  V v_t_2415 = (g_heff_2ecompile_2eirtext_2ehashW(MK_INT(5381LL), MK_INT(7919LL), v_items_2414));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_MkPair: {
    V v_a_2416 = heff_field(v_t_2415, 0);
    V v_b_2417 = heff_field(v_t_2415, 1);
    heff_take_n(v_t_2415, 3ULL, 2);
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ejsVer_str1), heff_intShow(v_b_2417));
    return heff_strAppend(heff_intShow(v_a_2416), v_t_2418);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecompile_2eemit_2ejsVer_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ejsVer(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ejsVer_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemit_2eglobalJsH(v_p_240, v_x_2410, v_acc_249));
}
Clo g_heff_2ecompile_2eemit_2ebundleAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleAll_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleAll(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eemit_2ebundleAll_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), v_rest_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleAll(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprovStrHelpers_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprovStrHelpers_str1, 1, "\012");
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovStrHelpers_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprovStrHelpers(V v_have_240, V v_provs_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
  V v_text_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_text_245 = ((V)&g_heff_2ecompile_2eemit_2eprovStrHelpers_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_text_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprovStrHelpers_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0, 1, 1, (V[]){v_text_245}), heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get())));
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
  HEFF_LAST return g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemit_2eprovStrHelpers_lam1, 1, 1, (V[]){heff_dup(v_have_240)}), v_t_2412);
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprovStrHelpers(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0(V self, V *args) {
  V v_h_246 = args[0];
  V v_text_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_h_246)) {
  case TAG_MkPair: {
    V v_k_247 = heff_field(v_h_246, 0);
    V v_line_248 = heff_field(v_h_246, 1);
    heff_take_n(v_h_246, 3ULL, 2);
    V v_x3_249 = (g_prelude_2eindexFrom(v_k_247, v_text_245, MK_INT(0LL)));
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      heff_drop(v_line_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_line_248});
    }
    default: return heff_nomatch(v_x3_249);
    }
  }
  default: return heff_nomatch(v_h_246);
  }
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam1(V self, V *args) {
  V v_l_2413 = args[0];
  V v_have_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2414 = ({ V a_0 = v_l_2413; V a_1 = v_have_240; V r_ = (g_list_2eany_24s2065989517x1307020881(a_0, a_1)); heff_drop(v_have_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2414) == NTAG(TAG_True)));
  heff_drop(v_x1_2414);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2eemit_2efindProv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2efindProv_entry, 2, 0};

V g_heff_2ecompile_2eemit_2efindProv(V v_md_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_md_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(v_md_240))) {
      heff_drop(v_md_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    } else {
      V t_0 = v_md_240;
      V t_1 = v_rest_243;
      v_md_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2efindProv_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2efindProv(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str1, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str2, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str3, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str5, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str6, 11, "$run(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str8, 5, "})();");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str10, 8, "(() => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str11, 13, "\"use strict\";");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str12, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str14, 1, "\012");
Clo g_heff_2ecompile_2eemit_2erunSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2erunSource_entry, 4, 0};

V g_heff_2ecompile_2eemit_2erunSource(V v_provs_240, V v_eff_241, V v_key_242, V v_m_243) {
top: ;
  V v_xs_244 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_provs_240));
  V v_t_245 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str0), NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2eany_24s651308273x925219243(heff_rfield(v_m_243, 0)));
  V v_t_248 = ({ V a_0 = v_t_247; V a_1 = heff_rfield(v_m_243, 0); V a_2 = heff_dup(v_provs_240); V a_3 = heff_dup(v_eff_241); V r_ = (g_heff_2ecompile_2eemit_2eruntimeFor(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_rfield(v_m_243, 1)));
  V v_t_2413;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str1);
    break;
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_2410, 1)))) {
      v_t_2413 = heff_strAppend(heff_get_n(v_i_2410, 0, 4), ((V)&g_heff_2ecompile_2eemit_2erunSource_str2));
    } else {
      V v_t_2412 = heff_take_field(v_i_2410, 2);
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        v_t_2413 = heff_strAppend(heff_get_n(v_i_2410, 0, 4), ((V)&g_heff_2ecompile_2eemit_2erunSource_str3));
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = heff_get_n(v_i_2410, 0, 4);
      }
    }
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2414 = ({ V a_0 = v_provs_240; V a_1 = v_eff_241; V r_ = (g_heff_2ecompile_2eemit_2ehandlerOf(a_0, a_1)); heff_drop(v_provs_240); heff_drop(v_eff_241); r_; });
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str4), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2erunSource_str5)));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str6), heff_strAppend(v_t_2413, v_t_2415));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str7), v_t_2417})});
  V v_t_2419 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str8), v_t_246}), heff_get_n(v_m_243, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str9), v_t_2418})));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str11), v_t_2419})});
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_245, v_t_2420));
  V v_x2_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str12), v_t_2421});
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2erunSource_str13);
  }
  case TAG_Cons: {
    V v_x_2423 = heff_field(v_x2_2422, 0);
    V v_xs_2424 = heff_field(v_x2_2422, 1);
    heff_take_n(v_x2_2422, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str14); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2erunSource(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str1, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str2, 1, "\"");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str3, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str4, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str5, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str6, 17, "() { return $ext(");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str7, 5, "); },");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str8, 6, "  get ");
Clo g_heff_2ecompile_2eemit_2egetterOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2egetterOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2egetterOf(V v_gs_240, V v_o_241) {
top: ;
  V v_x_242 = heff_take_field(v_o_241, 0);
  V v_t_243 = (g_heff_2ecompile_2eemit_2eisIdent(heff_dup(v_x_242)));
  V v_t_245;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_245 = v_x_242;
  } else {
    heff_drop(v_t_243);
    V v_t_244 = (g_heff_2ecompile_2eemit_2equoteGo(v_x_242, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2egetterOf_str0)));
    v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str1), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2egetterOf_str2)));
  }
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_get_n(v_o_241, 1, 2), v_gs_240));
  V v_t_2410;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2egetterOf_str3);
    break;
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_247, 1)))) {
      v_t_2410 = heff_strAppend(heff_get_n(v_i_247, 0, 4), ((V)&g_heff_2ecompile_2eemit_2egetterOf_str4));
    } else {
      V v_t_249 = heff_take_field(v_i_247, 2);
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        v_t_2410 = heff_strAppend(heff_get_n(v_i_247, 0, 4), ((V)&g_heff_2ecompile_2eemit_2egetterOf_str5));
      } else {
        heff_drop(v_t_249);
        v_t_2410 = heff_get_n(v_i_247, 0, 4);
      }
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2egetterOf_str7)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str8), heff_strAppend(v_t_245, v_t_2411));
}
V g_heff_2ecompile_2eemit_2egetterOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2egetterOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str0, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str1, 16, "export default {");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str5, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str7, 1, "\012");
V g_heff_2ecompile_2eemit_2ejsSource_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2ejsSource_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ejsSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsSource_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ejsSource(V v_exports_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str0), NTAG(TAG_Nil)});
  V v_t_243 = (g_list_2eany_24s651308273x925219243(heff_rfield(v_m_241, 0)));
  V v_t_244;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_244 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_243);
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
  }
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str1), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eextStr_get()), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str2), v_t_245})});
  V v_t_247 = (g_prelude_2e_2b_2b(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str3), v_t_246})));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str4), NTAG(TAG_Nil)});
  V v_t_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemit_2ejsSource_lam0, 1, 1, (V[]){heff_dup(v_m_241)}), v_exports_240));
  V v_t_2414 = (g_prelude_2e_2b_2b_24f58476578x2140998212(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str5), v_t_248}), heff_clo_n(g_heff_2ecompile_2eemit_2ejsSource_lam1, 1, 1, (V[]){heff_dup(v_m_241)}), v_t_2412));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_247, v_t_2414));
  V v_t_2416 = (g_prelude_2e_2b_2b(heff_get_n(v_m_241, 0, 2), v_t_2415));
  V v_x2_2417 = (g_prelude_2e_2b_2b(v_t_242, v_t_2416));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2ejsSource_str6);
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ejsSource_str7); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ejsSource(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2ejsSource_lam0(V self, V *args) {
  V v_o_249 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2410 = ({ V a_0 = heff_get_n(v_o_249, 1, 2); V b_1 = heff_get_n(v_m_241, 1, 2); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_2410, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2ecompile_2eemit_2ejsSource_lam1(V self, V *args) {
  V v_o_2413 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_m_241, 1, 2); V a_1 = v_o_2413; V r_ = (g_heff_2ecompile_2eemit_2egetterOf(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2ecompile_2eemit_2ecompileJs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecompileJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileJs_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecompileJs(V v_g_240, V v_exports0_241) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_exports0_241)) {
  case TAG_Nil: {
    V v_t_246 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2ecompileJs_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
    v_t_249 = (g_list_2emap_24s129316455x2072694707(v_t_246));
    break;
  }
  case TAG_Cons: {
    v_t_249 = v_exports0_241;
    break;
  }
  default: heff_nomatch(v_exports0_241);
  }
  HEFF_LAST return g_heff_2ecompile_2eemit_2ecompileJsWith(v_g_240, v_t_249);
}
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecompileJs(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2ecompileJs_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}