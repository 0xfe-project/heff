// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_F32 16337
#define TAG_HE 9070
#define TAG_HS 9084
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_JFalse 28308
#define TAG_JIf 20915
#define TAG_JNot 63532
#define TAG_JRel 1532
#define TAG_JSeq 2498
#define TAG_JTrue 54122
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_globals 352931696
#define LBL_gs 10067
#define LBL_inl 313953
#define LBL_js 10160
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_order 307364712
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_self 10021907
#define LBL_used 10094724
static uint32_t shape_code__decls[] = {LBL_code, LBL_decls};
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_gs__names__used__self__inl[] = {LBL_gs, LBL_names, LBL_used, LBL_self, LBL_inl};
static uint32_t shape_js__env__pre[] = {LBL_js, LBL_env, LBL_pre};
static uint32_t shape_js__pre__env[] = {LBL_js, LBL_pre, LBL_env};
static uint32_t shape_key__params[] = {LBL_key, LBL_params};
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452(V, V, V);
V g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(V, V, V);
V g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089_clo;
V g_heff_2ecompile_2eemit_2eboolCode(V);
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eboolCode_clo;
V g_heff_2ecompile_2eemit_2ebundleAll(V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_clo;
V g_heff_2ecompile_2eemit_2ebundleAll_24dps(V, V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_24dps_clo;
V g_heff_2ecompile_2eemit_2ebundleProvider(V, V);
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo;
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_clo;
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2(V, V, V, V);
V g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519_24tok2_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecellPrim(V, V);
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecellPrim_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2ecompile_2eemit_2ecompileJsWith(V, V);
V g_heff_2ecompile_2eemit_2ecompileJsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJsWith_clo;
HeffT2 g_heff_2ecompile_2eemit_2econdCode_24cpr(V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(V, V, V);
V g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496_clo;
V g_heff_2ecompile_2eemit_2edeclsOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_clo;
V g_heff_2ecompile_2eemit_2edeclsOf_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_24dps_clo;
V g_heff_2ecompile_2eemit_2eeagerCode(V, V);
V g_heff_2ecompile_2eemit_2eeagerCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eeagerCode_clo;
V g_heff_2ecompile_2eemit_2eescAt(V, V);
V g_heff_2ecompile_2eemit_2eescAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eescAt_clo;
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2efixedCode(V, V);
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efixedCode_clo;
V g_heff_2ecompile_2eemit_2egetterOf(V, V);
V g_heff_2ecompile_2eemit_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2egetterOf_clo;
V g_heff_2ecompile_2eemit_2eglobalJsH(V, V, V);
V g_heff_2ecompile_2eemit_2eglobalJsH_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eglobalJsH_clo;
V g_heff_2ecompile_2eemit_2ehandlerOf(V, V);
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo;
V g_heff_2ecompile_2eemit_2eifLines(V, V, V, V);
V g_heff_2ecompile_2eemit_2eifLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eifLines_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2ejsSource(V, V);
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsSource_clo;
V g_heff_2ecompile_2eemit_2ejsVer(V, V, V);
V g_heff_2ecompile_2eemit_2ejsVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsVer_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2elooped(V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elooped_clo;
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_clo;
V g_heff_2ecompile_2eemit_2enamedAs(V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(V, V, V);
V g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547_clo;
HeffT2 g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimBin_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU(V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo;
HeffT2 g_heff_2ecompile_2eemit_2eprimUnary_24cpr(V);
V g_heff_2ecompile_2eemit_2epropName(V);
V g_heff_2ecompile_2eemit_2epropName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2epropName_clo;
V g_heff_2ecompile_2eemit_2eprovStrHelpers(V, V);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereserved_get(void);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemit_2eruntimeFor(V, V, V, V);
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeFrom(V);
V g_heff_2ecompile_2eemit_2esafeFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeFrom_clo;
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_clo;
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
V g_heff_2ecompile_2eemit_2eseqsOf_24dps(V, V);
V g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_24dps_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V, V, V);
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo;
HeffT2 g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V, V, V);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(V, V, V);
V g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046_clo;
V g_heff_2ecompile_2eemit_2ewrapper(V, V, V, V);
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ewrapper_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s331724893x1262243254(V);
V g_list_2eany_24s331724893x1262243254_entry(V self, V *a);
extern Clo g_list_2eany_24s331724893x1262243254_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f675617784x1820039874(V, V);
V g_list_2efoldl_24f675617784x1820039874_entry(V self, V *a);
extern Clo g_list_2efoldl_24f675617784x1820039874_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s129316455x2072694707(V);
V g_list_2emap_24s129316455x2072694707_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_clo;
V g_list_2emap_24s1366476796x894764441(V, V);
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_clo;
V g_list_2emap_24s319754340x1392149466(V, V, V, V);
V g_list_2emap_24s319754340x1392149466_entry(V self, V *a);
extern Clo g_list_2emap_24s319754340x1392149466_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith_24s1149721393x617397893(V, V, V);
V g_list_2ezipWith_24s1149721393x617397893_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1149721393x617397893_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(V, V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eemit_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2equoteGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2equoteGo(V v_s_240, V v_box_24i_241, V v_acc_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return v_acc_242;
  } else {
    V v_t_243 = (g_heff_2ecompile_2eemit_2eescAt(v_s_240, heff_box_word(v_i_241)));
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_strAppend(v_acc_242, v_t_243);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2equoteGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastDotFrom_entry, 2, 0};

V g_heff_2ecompile_2eemit_2elastDotFrom(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < ((int64_t)0ULL))) {
    return NTAG(TAG_Nothing);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_box_word(v_i_241)});
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2elastDotFrom(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str3, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str7, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str8, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str11, 3, "op_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str14, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemit_2espellAt_str15, 3, "op_");
Clo g_heff_2ecompile_2eemit_2espellAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2espellAt_entry, 2, 0};

V g_heff_2ecompile_2eemit_2espellAt(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    if (heff_strEq_c_lent(v_k_240, ((V)&g_heff_2ecompile_2eemit_2espellAt_str0), 2)) {
      return v_k_240;
    } else {
      HeffT2 v_t_242 = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(v_k_240, MK_INT(0LL), NTAG(TAG_Nil)));
      {
        V v_field_244 = v_t_242.f[1];
        int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
        if ((v_tag_243 == ((int64_t)0ULL))) {
          heff_drop(v_k_240);
          V v_ws_245 = v_field_244;
          V v_t_248;
          switch (heff_tag_of(v_ws_245)) {
          case TAG_Nil: {
            v_t_248 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str1);
            break;
          }
          case TAG_Cons: {
            V v_x_246 = heff_field(v_ws_245, 0);
            V v_xs_247 = heff_field(v_ws_245, 1);
            heff_take_n(v_ws_245, 3ULL, 2);
            v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
            break;
          }
          default: heff_nomatch(v_ws_245);
          }
          V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str3), v_t_248);
          return v_t_249;
        } else {
          heff_drop(v_field_244);
          return v_k_240;
        }
      }
    }
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_x2_241, 0);
    V v_x_2411 = heff_strSlice(heff_dup(v_k_240), heff_intAdd(heff_dup(v_i_2410), MK_INT(1LL)), heff_strLength_lent(v_k_240, 0));
    if (heff_strEq_c_lent(v_x_2411, ((V)&g_heff_2ecompile_2eemit_2espellAt_str4), 2)) {
      heff_drop(v_x_2411);
      if (heff_strEq_c_lent(v_k_240, ((V)&g_heff_2ecompile_2eemit_2espellAt_str5), 2)) {
        return v_k_240;
      } else {
        HeffT2 v_t_2412 = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(v_k_240, MK_INT(0LL), NTAG(TAG_Nil)));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            heff_drop(v_k_240);
            V v_ws_2415 = v_field_2414;
            V v_t_2418;
            switch (heff_tag_of(v_ws_2415)) {
            case TAG_Nil: {
              v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str6);
              break;
            }
            case TAG_Cons: {
              V v_x_2416 = heff_field(v_ws_2415, 0);
              V v_xs_2417 = heff_field(v_ws_2415, 1);
              heff_take_n(v_ws_2415, 3ULL, 2);
              v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str7); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
              break;
            }
            default: heff_nomatch(v_ws_2415);
            }
            V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str8), v_t_2418);
            return v_t_2419;
          } else {
            heff_drop(v_field_2414);
            return v_k_240;
          }
        }
      }
    } else {
      HeffT2 v_t_2420 = ({ V a_0 = v_x_2411; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); HeffT2 r_ = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_ws_2423 = v_field_2422;
          V v_t_2426;
          switch (heff_tag_of(v_ws_2423)) {
          case TAG_Nil: {
            v_t_2426 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str9);
            break;
          }
          case TAG_Cons: {
            V v_x_2424 = heff_field(v_ws_2423, 0);
            V v_xs_2425 = heff_field(v_ws_2423, 1);
            heff_take_n(v_ws_2423, 3ULL, 2);
            v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str10); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
            break;
          }
          default: heff_nomatch(v_ws_2423);
          }
          V v_w_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str11), v_t_2426);
          V v_t_2428 = heff_strSlice(v_k_240, MK_INT(0LL), heff_intAdd(heff_dup(v_i_2410), MK_INT(1LL)));
          return heff_strAppend(v_t_2428, v_w_2427);
        } else {
          heff_drop(v_field_2422);
          if (heff_strEq_c_lent(v_k_240, ((V)&g_heff_2ecompile_2eemit_2espellAt_str12), 2)) {
            return v_k_240;
          } else {
            HeffT2 v_t_2429 = (g_heff_2ecompile_2eemit_2eoperatorGo_24cpr(v_k_240, MK_INT(0LL), NTAG(TAG_Nil)));
            {
              V v_field_2431 = v_t_2429.f[1];
              int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
              if ((v_tag_2430 == ((int64_t)0ULL))) {
                heff_drop(v_k_240);
                V v_ws_2432 = v_field_2431;
                V v_t_2435;
                switch (heff_tag_of(v_ws_2432)) {
                case TAG_Nil: {
                  v_t_2435 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str13);
                  break;
                }
                case TAG_Cons: {
                  V v_x_2433 = heff_field(v_ws_2432, 0);
                  V v_xs_2434 = heff_field(v_ws_2432, 1);
                  heff_take_n(v_ws_2432, 3ULL, 2);
                  v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str14); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
                  break;
                }
                default: heff_nomatch(v_ws_2432);
                }
                V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str15), v_t_2435);
                return v_t_2436;
              } else {
                heff_drop(v_field_2431);
                return v_k_240;
              }
            }
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2espellAt(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str0, 10, "Uint8Array");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str1, 11, "TextEncoder");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str2, 11, "TextDecoder");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str3, 15, "structuredClone");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str4, 3, "URL");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str5, 12, "setImmediate");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str6, 14, "queueMicrotask");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str7, 6, "RegExp");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str8, 6, "Buffer");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str9, 4, "Date");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str10, 6, "Symbol");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str11, 3, "Map");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str12, 3, "Set");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str13, 7, "Promise");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str14, 5, "Array");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str15, 7, "console");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str16, 10, "globalThis");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str17, 5, "fetch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str18, 7, "process");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str19, 4, "JSON");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str20, 10, "setTimeout");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str21, 5, "Error");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str22, 4, "Math");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str23, 6, "Number");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str24, 6, "Object");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str25, 6, "BigInt");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str26, 6, "String");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str27, 8, "document");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str28, 6, "window");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str29, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str30, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str31, 4, "eval");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str32, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str33, 5, "await");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str34, 9, "arguments");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str35, 9, "protected");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str36, 6, "public");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str37, 7, "package");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str38, 7, "private");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str39, 10, "implements");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str40, 9, "interface");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str41, 3, "let");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str42, 6, "static");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str43, 4, "with");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str44, 5, "yield");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str45, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str46, 5, "while");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str47, 6, "typeof");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str48, 3, "var");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str49, 4, "true");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str50, 3, "try");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str51, 4, "this");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str52, 5, "throw");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str53, 5, "super");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str54, 6, "switch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str55, 4, "null");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str56, 6, "return");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str57, 10, "instanceof");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str58, 3, "new");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str59, 6, "import");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str60, 2, "in");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str61, 8, "function");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str62, 2, "if");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str63, 7, "finally");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str64, 3, "for");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str65, 7, "extends");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str66, 5, "false");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str67, 4, "enum");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str68, 6, "export");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str69, 2, "do");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str70, 4, "else");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str71, 7, "default");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str72, 6, "delete");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str73, 8, "continue");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str74, 8, "debugger");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str75, 5, "class");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str76, 5, "const");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str77, 4, "case");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str78, 5, "catch");
HEFF_LIT(g_heff_2ecompile_2eemit_2ereserved_str79, 5, "break");

static V g_heff_2ecompile_2eemit_2ereserved_val;
static HEFF_ONCE g_heff_2ecompile_2eemit_2ereserved_st;
static V g_heff_2ecompile_2eemit_2ereserved_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str12), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str14), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str16), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str18), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str20), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str22), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str24), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str26), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str28), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str30), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str32), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str33), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str34), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str35), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str36), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str38), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str39), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str40), v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str41), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str42), v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str43), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str44), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str45), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str46), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str47), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str48), v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str49), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str50), v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str51), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str52), v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str53), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str54), v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str55), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str56), v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str57), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str58), v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str59), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str60), v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str61), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str62), v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str63), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str64), v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str65), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str66), v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str67), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str68), v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str69), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str70), v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str71), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str72), v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str73), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str74), v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str75), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str76), v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str77), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str78), v_t_2438})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str79), v_t_2439});
}
V g_heff_2ecompile_2eemit_2ereserved_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemit_2ereserved_st)) return g_heff_2ecompile_2eemit_2ereserved_val;
  return heff_global(&g_heff_2ecompile_2eemit_2ereserved_val, &g_heff_2ecompile_2eemit_2ereserved_st, g_heff_2ecompile_2eemit_2ereserved_init);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str0, 1, "*");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str6, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimBin_str13, 1, " ");
Clo g_heff_2ecompile_2eemit_2eprimBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimBin_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimBin(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_prec_243 = heff_take_field(v_b_242, 1);
  V v_code_244 = heff_get_n(v_b_242, 0, 2);
  V v_prec_245 = heff_take_field(v_a_241, 1);
  V v_code_246 = heff_get_n(v_a_241, 0, 2);
  if ((heff_strEq_c_lent(v_op_240, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str0), 2) || heff_strEq_c_lent(v_op_240, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str1), 2))) {
    V v_t_247;
    if (heff_intLt_c(v_prec_245, MK_INT(2LL))) {
      v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str2), heff_strAppend(v_code_246, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str3)));
    } else {
      v_t_247 = v_code_246;
    }
    V v_t_248;
    if (heff_intLt_c(v_prec_243, MK_INT(3LL))) {
      v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str4), heff_strAppend(v_code_244, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str5)));
    } else {
      v_t_248 = v_code_244;
    }
    V v_t_249 = heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str6), v_t_248));
    V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str7), v_t_249));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2410, MK_INT(2LL)});
  } else {
    V v_t_2411;
    if (heff_intLt_c(v_prec_245, MK_INT(1LL))) {
      v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str8), heff_strAppend(v_code_246, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str9)));
    } else {
      v_t_2411 = v_code_246;
    }
    V v_t_2412;
    if (heff_intLt_c(v_prec_243, MK_INT(2LL))) {
      v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str10), heff_strAppend(v_code_244, ((V)&g_heff_2ecompile_2eemit_2eprimBin_str11)));
    } else {
      v_t_2412 = v_code_244;
    }
    V v_t_2413 = heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str12), v_t_2412));
    V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str13), v_t_2413));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2414, MK_INT(1LL)});
  }
}
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimBin(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str3, 11, ".toString()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str4, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str7, 7, "BigInt(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str8, 8, ".length)");
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0, 1, 0};
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1, 1, 0};

HeffT2 g_heff_2ecompile_2eemit_2eprimUnary_24cpr(V v_x1_240) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str0), 2)) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0_clo)}});
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str4), 2)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1_clo)}});
    } else {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_prec_242 = heff_take_field(v_a_241, 1);
  V v_code_243 = heff_get_n(v_a_241, 0, 2);
  V v_t_244;
  if (heff_intLt_c(v_prec_242, MK_INT(3LL))) {
    v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str1), heff_strAppend(v_code_243, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str2)));
  } else {
    v_t_244 = v_code_243;
  }
  return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str3)), MK_INT(3LL)});
}
V g_heff_2ecompile_2eemit_2eprimUnary_24cpr_lam1(V self, V *args) {
  V v_a_245 = args[0];
  V v_prec_246 = heff_take_field(v_a_245, 1);
  V v_code_247 = heff_get_n(v_a_245, 0, 2);
  V v_t_248;
  if (heff_intLt_c(v_prec_246, MK_INT(3LL))) {
    v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str5), heff_strAppend(v_code_247, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str6)));
  } else {
    v_t_248 = v_code_247;
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str7), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_24cpr_str8)));
  return heff_rec_n(2, shape_code__prec, (V[]){v_t_249, MK_INT(3LL)});
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellPrim_str0, 4, "hole");
HEFF_LIT(g_heff_2ecompile_2eemit_2ecellPrim_str1, 8, "setField");
Clo g_heff_2ecompile_2eemit_2ecellPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecellPrim_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecellPrim(V v_x1_240, V v_x2_241) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2ecellPrim_str0), 2)) {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2ecellPrim_str1), 2)) {
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_x22_245 = heff_field(v_x2_241, 1);
        switch (heff_tag_of(v_x22_245)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_x221_246 = heff_field(v_x22_245, 0);
          V v_x222_247 = heff_field(v_x22_245, 1);
          switch (heff_tag_of(v_x221_246)) {
          case TAG_SVar: {
            return NTAG(TAG_False);
          }
          case TAG_SGlobal: {
            return NTAG(TAG_False);
          }
          case TAG_SInt: {
            switch (heff_tag_of(v_x222_247)) {
            case TAG_Nil: {
              return NTAG(TAG_False);
            }
            case TAG_Cons: {
              V v_x2222_2412 = heff_field(v_x222_247, 1);
              switch (heff_tag_of(v_x2222_2412)) {
              case TAG_Nil: {
                return NTAG(TAG_True);
              }
              case TAG_Cons: {
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_x2222_2412);
              }
            }
            default: return heff_nomatch(v_x222_247);
            }
          }
          case TAG_SFloat: {
            return NTAG(TAG_False);
          }
          case TAG_SStr: {
            return NTAG(TAG_False);
          }
          case TAG_SBytes: {
            return NTAG(TAG_False);
          }
          case TAG_SFixed: {
            return NTAG(TAG_False);
          }
          case TAG_SFloat32: {
            return NTAG(TAG_False);
          }
          case TAG_SPrimFn: {
            return NTAG(TAG_False);
          }
          case TAG_SLam: {
            return NTAG(TAG_False);
          }
          case TAG_STag: {
            return NTAG(TAG_False);
          }
          case TAG_SRec: {
            return NTAG(TAG_False);
          }
          case TAG_SProj: {
            return NTAG(TAG_False);
          }
          case TAG_SPrim: {
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x221_246);
          }
        }
        default: return heff_nomatch(v_x22_245);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    } else {
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ecompile_2eemit_2ecellPrim_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ecellPrim(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemit_2eseqsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eseqsOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eseqsOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_JTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_JFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_JRel: {
    return NTAG(TAG_Nil);
  }
  case TAG_JNot: {
    V v_q_242 = heff_field(v_p_240, 0);
    V t_0 = v_q_242;
    v_p_240 = t_0;
    goto top;
  }
  case TAG_JIf: {
    V v_c_243 = heff_field(v_p_240, 0);
    V v_t_244 = heff_field(v_p_240, 1);
    V v_e_245 = heff_field(v_p_240, 2);
    V v_t_246 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_243));
    V v_t_247 = (g_heff_2ecompile_2eemit_2eseqsOf(v_t_244));
    V v_t_248 = (g_heff_2ecompile_2eemit_2eseqsOf(v_e_245));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
    return (g_prelude_2e_2b_2b(v_t_246, v_t_249));
  }
  case TAG_JSeq: {
    V v_x_2410 = heff_field(v_p_240, 0);
    V v_q_2412 = heff_field(v_p_240, 2);
    V v_cell_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2410), heff_hole()});
    V v_u_2414 = (g_heff_2ecompile_2eemit_2eseqsOf_24dps(v_q_2412, heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eseqsOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eemit_2eseqsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eseqsOf_24dps(V v_p_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_JTrue: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JFalse: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JRel: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_JNot: {
    V v_q_243 = heff_field(v_p_240, 0);
    V t_0 = v_q_243;
    V t_1 = v_d_241;
    v_p_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  case TAG_JIf: {
    V v_c_244 = heff_field(v_p_240, 0);
    V v_t_245 = heff_field(v_p_240, 1);
    V v_e_246 = heff_field(v_p_240, 2);
    V v_t_247 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_244));
    V v_t_248 = (g_heff_2ecompile_2eemit_2eseqsOf(v_t_245));
    V v_t_249 = (g_heff_2ecompile_2eemit_2eseqsOf(v_e_246));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_248, v_t_249));
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_247, v_t_2410));
    return heff_setField(v_d_241, MK_INT(1LL), v_t_2411);
  }
  case TAG_JSeq: {
    V v_x_2412 = heff_field(v_p_240, 0);
    V v_q_2414 = heff_field(v_p_240, 2);
    V v_cell_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), heff_hole()});
    V v_u_2416 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_q_2414;
    V t_1 = v_cell_2415;
    v_p_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2eseqsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eseqsOf_24dps(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str0, 2, "$T");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str1, 2, "$F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str2, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str4, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str5, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str6, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str7, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str8, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str10, 10, " \? $T : $F");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str11, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemit_2eboolCode_str13, 10, " \? $T : $F");
Clo g_heff_2ecompile_2eemit_2eboolCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eboolCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eboolCode(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_JTrue: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eboolCode_str0), MK_INT(3LL)});
  }
  case TAG_JFalse: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eboolCode_str1), MK_INT(3LL)});
  }
  case TAG_JRel: {
    HeffT2 v_t_242 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    V v_t_245;
    {
      V v_field_243 = v_t_242.f[0];
      V v_field_244 = v_t_242.f[1];
      if (heff_intLt_c(v_field_244, MK_INT(1LL))) {
        v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str2), heff_strAppend(v_field_243, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str3)));
      } else {
        v_t_245 = v_field_243;
      }
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str4)), MK_INT(0LL)});
  }
  case TAG_JNot: {
    HeffT2 v_t_247 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    V v_t_2410;
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      if (heff_intLt_c(v_field_249, MK_INT(1LL))) {
        v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str5), heff_strAppend(v_field_248, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str6)));
      } else {
        v_t_2410 = v_field_248;
      }
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str7)), MK_INT(0LL)});
  }
  case TAG_JIf: {
    HeffT2 v_t_2414 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    V v_t_2417;
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_field_2416 = v_t_2414.f[1];
      if (heff_intLt_c(v_field_2416, MK_INT(1LL))) {
        v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str8), heff_strAppend(v_field_2415, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str9)));
      } else {
        v_t_2417 = v_field_2415;
      }
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str10)), MK_INT(0LL)});
  }
  case TAG_JSeq: {
    HeffT2 v_t_2421 = (g_heff_2ecompile_2eemit_2econdCode_24cpr(v_c_240));
    V v_t_2424;
    {
      V v_field_2422 = v_t_2421.f[0];
      V v_field_2423 = v_t_2421.f[1];
      if (heff_intLt_c(v_field_2423, MK_INT(1LL))) {
        v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eboolCode_str11), heff_strAppend(v_field_2422, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str12)));
      } else {
        v_t_2424 = v_field_2422;
      }
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2eboolCode_str13)), MK_INT(0LL)});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ecompile_2eemit_2eboolCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eboolCode(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str1, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str2, 1, "n");
HEFF_LIT(g_heff_2ecompile_2eemit_2efixedCode_str3, 1, "-");
Clo g_heff_2ecompile_2eemit_2efixedCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2efixedCode_entry, 2, 0};

V g_heff_2ecompile_2eemit_2efixedCode(V v_w_240, V v_n_241) {
top: ;
  int64_t v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_I16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_I32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_I64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_U8: {
    v_t_242 = ((int64_t)8ULL);
    break;
  }
  case TAG_U16: {
    v_t_242 = ((int64_t)16ULL);
    break;
  }
  case TAG_U32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  case TAG_U64: {
    v_t_242 = ((int64_t)64ULL);
    break;
  }
  case TAG_F32: {
    v_t_242 = ((int64_t)32ULL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if ((v_t_242 == ((int64_t)64ULL))) {
    V v_s_243 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice_lent(v_s_243, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str0))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_243, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str1)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_243, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str2)), MK_INT(3LL)});
    }
  } else {
    V v_s_244 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice_lent(v_s_244, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str3))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_244, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_244, MK_INT(3LL)});
    }
  }
}
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2efixedCode(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str3, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str4, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str5, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_str6, 6, "const ");
Clo g_heff_2ecompile_2eemit_2edeclsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edeclsOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2edeclsOf(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_js_240);
    heff_drop(v_ind_241);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_246 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(heff_intShow(heff_dup(v_i_243)), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str3));
    V v_t_2411 = heff_strAppend(heff_dup(v_js_240), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str4), v_t_2410));
    V v_t_2412 = heff_strAppend(v_v_244, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str5), v_t_2411));
    V v_t_2413 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str6), v_t_2412));
    V v_cell_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_heff_2ecompile_2eemit_2edeclsOf_24dps(v_js_240, v_ind_241, v_rest_245, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL))), heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2edeclsOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str3, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str4, 3, ".a[");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str5, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2edeclsOf_24dps_str6, 6, "const ");
Clo g_heff_2ecompile_2eemit_2edeclsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry, 5, 0};

V g_heff_2ecompile_2eemit_2edeclsOf_24dps(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_js_240);
    heff_drop(v_ind_241);
    heff_drop(v_i_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_v_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str0)));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(heff_intShow(heff_dup(v_i_243)), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str3));
    V v_t_2412 = heff_strAppend(heff_dup(v_js_240), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str4), v_t_2411));
    V v_t_2413 = heff_strAppend(v_v_245, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str5), v_t_2412));
    V v_t_2414 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_24dps_str6), v_t_2413));
    V v_cell_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_js_240;
    V t_1 = v_ind_241;
    V t_2 = v_rest_246;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_cell_2415;
    v_js_240 = t_0;
    v_ind_241 = t_1;
    v_x3_242 = t_2;
    v_i_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2edeclsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2edeclsOf_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamedAs_str5, 6, "const ");
Clo g_heff_2ecompile_2eemit_2enamedAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamedAs_entry, 3, 0};

V g_heff_2ecompile_2eemit_2enamedAs(V v_ind_240, V v_c_241, V v_nb_242) {
top: ;
  V v_js_243 = heff_take_field(v_nb_242, 0);
  V v_env_244 = heff_get_n(v_nb_242, 1, 2);
  V v_x2_245 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2enamedAs_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = heff_strAppend(heff_get_n(v_c_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2enamedAs_str3));
  V v_t_2410 = heff_strAppend(heff_dup(v_js_243), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2enamedAs_str4), v_t_249));
  V v_t_2411 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2enamedAs_str5), v_t_2410));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__pre__env, (V[]){v_js_243, v_t_2412, v_env_244});
}
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamedAs(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str2, 0, "");
Clo g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry, 5, 0};

V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(V v_lit_240, V v_lit_241, V v_env_242, V v_ind_243, V v_base_244) {
top: ;
  if (!heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str0), 2)) {
    V v_t_245 = (g_heff_2ecompile_2eemit_2eatomGo(v_lit_240, MK_INT(0LL)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_lit_241);
      heff_drop(v_ind_243);
      heff_drop(v_base_244);
      heff_drop(v_t_245);
      return heff_rec_n(3, shape_js__pre__env, (V[]){v_lit_240, NTAG(TAG_Nil), v_env_242});
    } else {
      heff_drop(v_t_245);
      V v_x0_246 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_base_244), MK_INT(0LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_x0_246, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_246, heff_box_word(v_t_247)));
      V v_t_249 = ({ V a_0 = v_x0_246; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str1); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
      V v_t_2411 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2410));
      V v_t_2412 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_242, v_base_244, v_t_2411, MK_INT(0LL)));
      return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_243, heff_rec_n(2, shape_code__prec, (V[]){v_lit_240, v_lit_241}), v_t_2412));
    }
  } else {
    V v_x0_2413 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_base_244), MK_INT(0LL)));
    int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_x0_2413, 0)) - ((int64_t)1ULL));
    V v_t_2415 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2413, heff_box_word(v_t_2414)));
    V v_t_2416 = ({ V a_0 = v_x0_2413; V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2417 = ({ V a_0 = v_t_2416; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_str2); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2417));
    V v_t_2419 = (g_heff_2ecompile_2eemit_2ebindFrom(v_env_242, v_base_244, v_t_2418, MK_INT(0LL)));
    return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_243, heff_rec_n(2, shape_code__prec, (V[]){v_lit_240, v_lit_241}), v_t_2419));
  }
}
V g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamed_24s355296954x961524319(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str0, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str1, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str6, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str7, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str8, 5, "$c = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2ewrapper_str9, 6, "const ");
Clo g_heff_2ecompile_2eemit_2ewrapper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ewrapper_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ewrapper(V v_curried_240, V v_key_241, V v_i_242, V v_js_243) {
top: ;
  V v_arity_244 = heff_take_field(v_i_242, 1);
  V v_js_245 = heff_get_n(v_i_242, 0, 4);
  if (heff_intLe_c(MK_INT(2LL), v_arity_244)) {
    HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_curried_240, v_key_241));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_248;
        heff_drop(v_x_249);
        V v_x2_2410 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ecompile_2eemit_2ewrapper_str0), ((V)&g_heff_2ecompile_2eemit_2ewrapper_str1), heff_dup(v_js_243)));
        V v_t_2413;
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str2);
          break;
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        V v_t_2416;
        switch (heff_tag_of(v_js_243)) {
        case TAG_Nil: {
          v_t_2416 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_js_243, 0);
          V v_xs_2415 = heff_field(v_js_243, 1);
          heff_take_n(v_js_243, 3ULL, 2);
          v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str5); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
          break;
        }
        default: heff_nomatch(v_js_243);
        }
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str6), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2ewrapper_str7)));
        V v_t_2418 = heff_strAppend(v_t_2413, heff_strAppend(heff_dup(v_js_245), v_t_2417));
        V v_t_2419 = heff_strAppend(v_js_245, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str8), v_t_2418));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str9), v_t_2419), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_js_243);
        heff_drop(v_js_245);
        heff_drop(v_field_248);
        return NTAG(TAG_Nil);
      }
    }
  } else {
    heff_drop(v_js_243);
    heff_drop(v_js_245);
    return NTAG(TAG_Nil);
  }
}
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2ewrapper(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry, 3, 0};

V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(V v_env_240, V v_ind_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_t_244 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_244, NTAG(TAG_Nil)});
  }
  case TAG_OCall: {
    V v_t_247 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_OApply: {
    V v_t_2410 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_OPrim: {
    V v_t_2413 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2413, NTAG(TAG_Nil)});
  }
  case TAG_OAbandon: {
    V v_t_2414 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, v_ind_241, v_o_242));
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2414, NTAG(TAG_Nil)});
  }
  case TAG_OBool: {
    V v_c_2415 = heff_field(v_o_242, 0);
    V v_jc_2416 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(v_env_240, v_ind_241, heff_dup(v_c_2415)));
    V v_t_2417 = (g_heff_2ecompile_2eemit_2eboolCode(heff_dup(v_jc_2416)));
    V v_t_2418 = ({ V a_0 = v_jc_2416; V r_ = (g_heff_2ecompile_2eemit_2eseqsOf(a_0)); heff_drop(v_jc_2416); r_; });
    return heff_rec_n(2, shape_code__decls, (V[]){v_t_2417, v_t_2418});
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2estepOf_24s203957202x990700875(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str0, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str4, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str5, 6, "const ");
Clo g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry, 4, 0};

V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(V v_env_240, V v_ind_241, V v_v_242, V v_b_243) {
top: ;
  V v_js_244 = heff_take_field(v_b_243, 0);
  V v_env_245 = heff_get_n(v_b_243, 1, 2);
  V v_x2_246 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_tr(g_heff_2ecompile_2eemit_2evalGo_24s644616452x34300046(v_env_240, v_ind_241, v_v_242));
  V v_t_2411 = heff_strAppend(heff_get_n(v_t_2410, 0, 2), ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str3));
  V v_t_2412 = heff_strAppend(heff_dup(v_js_244), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str4), v_t_2411));
  V v_t_2413 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str5), v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__env__pre, (V[]){v_js_244, v_env_245, v_t_2414});
}
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str14, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str15, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str17, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str18, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str20, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str21, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str23, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str24, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str26, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str27, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str29, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str30, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str31, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str32, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str33, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str35, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str36, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str37, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str38, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str39, 1, "s");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str41, 1, "s");
Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry, 3, 0};

V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V v_env_240, V v_ind_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_v_242, 0);
    V v_ru_24v_242_24SVar = heff_take_reuse_n(v_v_242, 1ULL, 1);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_env_240, 1), v_x_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_ind_241);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24v_242_24SVar, 1);
        V v_js_247 = v_field_246;
        return heff_rec_n(3, shape_js__env__pre, (V[]){v_js_247, v_env_240, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_field_246);
        V v_x0_248 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0), MK_INT(0LL)));
        int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_x0_248, 0)) - ((int64_t)1ULL));
        V v_t_2410 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_248, heff_box_word(v_t_249)));
        V v_t_2411 = ({ V a_0 = v_x0_248; V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2410); r_; });
        V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
        V v_t_2413 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2412));
        V v_t_2414 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2), v_t_2413, MK_INT(0LL)));
        return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V b_2 = heff_tag_at_n(v_ru_24v_242_24SVar, TAG_SVar, 1, (V[]){v_x_243}); V a_3 = v_t_2414; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
      }
    }
  }
  case TAG_SGlobal: {
    V v_x0_2416 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3), MK_INT(0LL)));
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_x0_2416, 0)) - ((int64_t)1ULL));
    V v_t_2418 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2416, heff_box_word(v_t_2417)));
    V v_t_2419 = ({ V a_0 = v_x0_2416; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2420));
    V v_t_2422 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5), v_t_2421, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2422; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SInt: {
    V v_x0_2424 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6), MK_INT(0LL)));
    int64_t v_t_2425 = (heff_unbox_word(heff_strLength_lent(v_x0_2424, 0)) - ((int64_t)1ULL));
    V v_t_2426 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2424, heff_box_word(v_t_2425)));
    V v_t_2427 = ({ V a_0 = v_x0_2424; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2426); r_; });
    V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
    V v_t_2429 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2428));
    V v_t_2430 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8), v_t_2429, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2430; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SFloat: {
    V v_x0_2432 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9), MK_INT(0LL)));
    int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_x0_2432, 0)) - ((int64_t)1ULL));
    V v_t_2434 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2432, heff_box_word(v_t_2433)));
    V v_t_2435 = ({ V a_0 = v_x0_2432; V a_1 = v_t_2434; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2434); r_; });
    V v_t_2436 = ({ V a_0 = v_t_2435; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2435); r_; });
    V v_t_2437 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2436));
    V v_t_2438 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11), v_t_2437, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2438; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SStr: {
    V v_x0_2440 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12), MK_INT(0LL)));
    int64_t v_t_2441 = (heff_unbox_word(heff_strLength_lent(v_x0_2440, 0)) - ((int64_t)1ULL));
    V v_t_2442 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2440, heff_box_word(v_t_2441)));
    V v_t_2443 = ({ V a_0 = v_x0_2440; V a_1 = v_t_2442; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2442); r_; });
    V v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2443); r_; });
    V v_t_2445 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2444));
    V v_t_2446 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str14), v_t_2445, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2446; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SBytes: {
    V v_x0_2448 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str15), MK_INT(0LL)));
    int64_t v_t_2449 = (heff_unbox_word(heff_strLength_lent(v_x0_2448, 0)) - ((int64_t)1ULL));
    V v_t_2450 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2448, heff_box_word(v_t_2449)));
    V v_t_2451 = ({ V a_0 = v_x0_2448; V a_1 = v_t_2450; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2450); r_; });
    V v_t_2452 = ({ V a_0 = v_t_2451; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str16); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2451); r_; });
    V v_t_2453 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2452));
    V v_t_2454 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str17), v_t_2453, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2454; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SFixed: {
    V v_x0_2457 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str18), MK_INT(0LL)));
    int64_t v_t_2458 = (heff_unbox_word(heff_strLength_lent(v_x0_2457, 0)) - ((int64_t)1ULL));
    V v_t_2459 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2457, heff_box_word(v_t_2458)));
    V v_t_2460 = ({ V a_0 = v_x0_2457; V a_1 = v_t_2459; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2459); r_; });
    V v_t_2461 = ({ V a_0 = v_t_2460; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str19); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2460); r_; });
    V v_t_2462 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2461));
    V v_t_2463 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str20), v_t_2462, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2463; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  case TAG_SFloat32: {
    V v_x0_2465 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str21), MK_INT(0LL)));
    int64_t v_t_2466 = (heff_unbox_word(heff_strLength_lent(v_x0_2465, 0)) - ((int64_t)1ULL));
    V v_t_2467 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2465, heff_box_word(v_t_2466)));
    V v_t_2468 = ({ V a_0 = v_x0_2465; V a_1 = v_t_2467; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2467); r_; });
    V v_t_2469 = ({ V a_0 = v_t_2468; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str22); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2468); r_; });
    V v_t_2470 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2469));
    V v_t_2471 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str23), v_t_2470, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2471; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SPrimFn: {
    V v_x0_2473 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str24), MK_INT(0LL)));
    int64_t v_t_2474 = (heff_unbox_word(heff_strLength_lent(v_x0_2473, 0)) - ((int64_t)1ULL));
    V v_t_2475 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2473, heff_box_word(v_t_2474)));
    V v_t_2476 = ({ V a_0 = v_x0_2473; V a_1 = v_t_2475; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2475); r_; });
    V v_t_2477 = ({ V a_0 = v_t_2476; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str25); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2476); r_; });
    V v_t_2478 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2477));
    V v_t_2479 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str26), v_t_2478, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2479; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 1); r_; });
  }
  case TAG_SLam: {
    V v_x0_2482 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str27), MK_INT(0LL)));
    int64_t v_t_2483 = (heff_unbox_word(heff_strLength_lent(v_x0_2482, 0)) - ((int64_t)1ULL));
    V v_t_2484 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2482, heff_box_word(v_t_2483)));
    V v_t_2485 = ({ V a_0 = v_x0_2482; V a_1 = v_t_2484; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2484); r_; });
    V v_t_2486 = ({ V a_0 = v_t_2485; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str28); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2485); r_; });
    V v_t_2487 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2486));
    V v_t_2488 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str29), v_t_2487, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2488; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  case TAG_STag: {
    V v_x0_2492 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str30), MK_INT(0LL)));
    int64_t v_t_2493 = (heff_unbox_word(heff_strLength_lent(v_x0_2492, 0)) - ((int64_t)1ULL));
    V v_t_2494 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_2492, heff_box_word(v_t_2493)));
    V v_t_2495 = ({ V a_0 = v_x0_2492; V a_1 = v_t_2494; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2494); r_; });
    V v_t_2496 = ({ V a_0 = v_t_2495; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str31); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2495); r_; });
    V v_t_2497 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2496));
    V v_t_2498 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str32), v_t_2497, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_2498; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 3); r_; });
  }
  case TAG_SRec: {
    V v_x0_24101 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str33), MK_INT(0LL)));
    int64_t v_t_24102 = (heff_unbox_word(heff_strLength_lent(v_x0_24101, 0)) - ((int64_t)1ULL));
    V v_t_24103 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_24101, heff_box_word(v_t_24102)));
    V v_t_24104 = ({ V a_0 = v_x0_24101; V a_1 = v_t_24103; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_24103); r_; });
    V v_t_24105 = ({ V a_0 = v_t_24104; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str34); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_24104); r_; });
    V v_t_24106 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_24105));
    V v_t_24107 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str35), v_t_24106, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_24107; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  case TAG_SProj: {
    V v_x0_24112 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str36), MK_INT(0LL)));
    int64_t v_t_24113 = (heff_unbox_word(heff_strLength_lent(v_x0_24112, 0)) - ((int64_t)1ULL));
    V v_t_24114 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_24112, heff_box_word(v_t_24113)));
    V v_t_24115 = ({ V a_0 = v_x0_24112; V a_1 = v_t_24114; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_24114); r_; });
    V v_t_24116 = ({ V a_0 = v_t_24115; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str37); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_24115); r_; });
    V v_t_24117 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_24116));
    V v_t_24118 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str38), v_t_24117, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_24118; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 4); r_; });
  }
  case TAG_SPrim: {
    V v_x0_24121 = (g_heff_2ecompile_2eir_2ebaseGo(((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str39), MK_INT(0LL)));
    int64_t v_t_24122 = (heff_unbox_word(heff_strLength_lent(v_x0_24121, 0)) - ((int64_t)1ULL));
    V v_t_24123 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_x0_24121, heff_box_word(v_t_24122)));
    V v_t_24124 = ({ V a_0 = v_x0_24121; V a_1 = v_t_24123; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_24123); r_; });
    V v_t_24125 = ({ V a_0 = v_t_24124; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str40); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_24124); r_; });
    V v_t_24126 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_24125));
    V v_t_24127 = (g_heff_2ecompile_2eemit_2ebindFrom(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str41), v_t_24126, MK_INT(0LL)));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_v_242; V a_3 = v_t_24127; V r_ = (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a_0, a_1, a_2, a_3)); heff_drop_tag(v_v_242, 2); r_; });
  }
  default: return heff_nomatch(v_v_242);
  }
}
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry, 3, 0};

V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(V v_env_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    HeffT2 v_t_245 = ({ V a_0 = v_env_240; V a_1 = heff_dup(v_ind_241); V a_2 = heff_dup(v_ss_243); V b_3 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_t_244)}); HeffT2 r_ = (g_heff_2ecompile_2eemit_2estmtsGo_24s1604305023x1277732611_24cpr(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_t_248 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(v_field_247, v_ind_241, v_t_244));
      return (g_prelude_2e_2b_2b(v_field_246, v_t_248));
    }
  }
  case TAG_TReturn: {
    V v_o_249 = heff_field(v_x4_242, 0);
    HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, heff_dup(v_o_249));
  }
  case TAG_TLoop: {
    V v_args_2410 = heff_field(v_x4_242, 0);
    HEFF_LAST return g_heff_2ecompile_2eemit_2eagain_24s287065317x1057950452(v_env_240, v_ind_241, heff_dup(v_args_2410));
  }
  case TAG_TIf: {
    V v_c_2411 = heff_field(v_x4_242, 0);
    V v_t_2412 = heff_field(v_x4_242, 1);
    V v_f_2413 = heff_field(v_x4_242, 2);
    V v_t_2414 = (g_heff_2ecompile_2eemit_2econdGo_24s850061013x835591496(heff_dup(v_env_240), heff_dup(v_ind_241), heff_dup(v_c_2411)));
    return (g_heff_2ecompile_2eemit_2eifLines(v_ind_241, v_t_2414, heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_t_2412)}), heff_clo_n(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1, 1, 2, (V[]){v_env_240, heff_dup(v_f_2413)})));
  }
  case TAG_TCase: {
    V v_v_2417 = heff_field(v_x4_242, 0);
    V v_arms_2418 = heff_field(v_x4_242, 1);
    V v_t_2419 = (g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(v_env_240, heff_dup(v_ind_241), heff_dup(v_v_2417)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2ecaseTail_24s10626343x1185680519(v_ind_241, heff_dup(v_arms_2418), v_t_2419);
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam0(V self, V *args) {
  V v_i_2415 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_t_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_i_2415; V a_2 = v_t_2412; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
}
V g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605_lam1(V self, V *args) {
  V v_i_2416 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_f_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_env_240; V a_1 = v_i_2416; V a_2 = v_f_2413; V r_ = (g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(a_0, a_1, a_2)); heff_drop(v_f_2413); r_; });
}
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str3, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str4, 6, ") => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str5, 6, "const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str6, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str7, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str10, 10, "    const ");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str11, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str12, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str13, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str14, 3, "  }");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str15, 12, "  for (;;) {");
HEFF_LIT(g_heff_2ecompile_2eemit_2elooped_str16, 0, "");
Clo g_heff_2ecompile_2eemit_2elooped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elooped_entry, 4, 0};

V g_heff_2ecompile_2eemit_2elooped(V v_key_240, V v_i_241, V v_t_242, V v_r_243) {
top: ;
  V v_js_244 = heff_take_field(v_r_243, 0);
  V v_env_245 = heff_get_n(v_r_243, 1, 2);
  V v_x2_246 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str0), heff_dup(v_js_244)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemit_2elooped_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str3), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2elooped_str4)));
  V v_t_2411 = heff_strAppend(heff_get_n(v_i_241, 0, 4), v_t_2410);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str5), v_t_2411), NTAG(TAG_Nil)});
  V v_t_2413 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str6), heff_dup(v_js_244)));
  V v_x2_2414 = (g_list_2ezipWith_24s1149721393x617397893(((V)&g_heff_2ecompile_2eemit_2elooped_str7), heff_dup(v_js_244), v_t_2413));
  V v_t_2417;
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2elooped_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_xs_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str9); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2414);
  }
  V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str10), heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemit_2elooped_str11)));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  V v_t_2420 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ecompile_2eemit_2elooped_str12), v_js_244));
  V v_s_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__params, (V[]){v_key_240, v_t_2420})});
  V v_env_2422 = v_env_245;
  V v_gs_2423 = heff_take_field(v_env_2422, 0);
  V v_names_2424 = heff_take_field(v_env_2422, 1);
  V v_used_2425 = heff_take_field(v_env_2422, 2);
  V v_inl_2426 = heff_get_n(v_env_2422, 4, 5);
  V v_t_2427 = heff_tr(g_heff_2ecompile_2eemit_2etailGo_24s1994632507x1925799605(heff_rec_n(5, shape_gs__names__used__self__inl, (V[]){v_gs_2423, v_names_2424, v_used_2425, v_s_2421, v_inl_2426}), MK_INT(2LL), v_t_242));
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str13), NTAG(TAG_Nil)});
  V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str14), v_t_2428})));
  V v_t_2430 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str15), v_t_2419}), v_t_2429));
  return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str16), v_t_2412}), v_t_2430));
}
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2elooped(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str0, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str1, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str2, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str3, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str4, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str5, 3, ")()");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str6, 7, "(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eeagerCode_str7, 3, ")()");
Clo g_heff_2ecompile_2eemit_2eeagerCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eeagerCode_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eeagerCode(V v_env_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_TSeq: {
    V v_t_244 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str0), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str1)));
  }
  case TAG_TReturn: {
    V v_o_245 = heff_field(v_t_241, 0);
    V v_t_246 = heff_tr(g_heff_2ecompile_2eemit_2eopGo_24s1663239385x1662806547(v_env_240, MK_INT(0LL), v_o_245));
    return heff_get_n(v_t_246, 0, 2);
  }
  case TAG_TLoop: {
    V v_t_248 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str2), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str3)));
  }
  case TAG_TIf: {
    V v_t_2412 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str4), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str5)));
  }
  case TAG_TCase: {
    V v_t_2415 = (g_heff_2ecompile_2eemit_2eblockOf_24s637978521x233618089(v_env_240, MK_INT(0LL), v_t_241));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eeagerCode_str6), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2eeagerCode_str7)));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eemit_2eeagerCode_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemit_2eeagerCode(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str3, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str4, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str6, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str7, 7, "const $");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str8, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str9, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str11, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str12, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str13, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str14, 4, " = (");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str15, 7, "const $");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str16, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str17, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str18, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str19, 5, ") => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str23, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str25, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str26, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str27, 5, "$c = ");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprimHelperU_str28, 7, "const $");
Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimHelperU_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimHelperU(V v_uses_240, V v_p_241, V v_u_242) {
top: ;
  V v_params_243 = heff_take_field(v_u_242, 0);
  V v_body_244 = heff_get_n(v_u_242, 1, 2);
  V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str0), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str1)));
  HeffT2 v_t_246 = ({ V a_0 = v_uses_240; V a_1 = v_t_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_2427;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      heff_drop(v_x_249);
      V v_t_2412;
      switch (heff_tag_of(v_params_243)) {
      case TAG_Nil: {
        v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2410 = heff_dup(heff_field(v_params_243, 0));
        V v_xs_2411 = heff_dup(heff_field(v_params_243, 1));
        v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str3); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
        break;
      }
      default: heff_nomatch(v_params_243);
      }
      V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str4), heff_strAppend(v_body_244, ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str5)));
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str6), heff_strAppend(v_t_2412, v_t_2413));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str7), heff_strAppend(heff_dup(v_p_241), v_t_2414));
      v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_field_248);
      V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str8), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str9)));
      HeffT2 v_t_2417 = ({ V a_0 = v_uses_240; V a_1 = v_t_2416; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_2416); r_; });
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_x_2420 = v_field_2419;
          heff_drop(v_x_2420);
          V v_t_2423;
          switch (heff_tag_of(v_params_243)) {
          case TAG_Nil: {
            v_t_2423 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str10);
            break;
          }
          case TAG_Cons: {
            V v_x_2421 = heff_dup(heff_field(v_params_243, 0));
            V v_xs_2422 = heff_dup(heff_field(v_params_243, 1));
            v_t_2423 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str11); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
            break;
          }
          default: heff_nomatch(v_params_243);
          }
          V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str12), heff_strAppend(v_body_244, ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str13)));
          V v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str14), heff_strAppend(v_t_2423, v_t_2424));
          V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str15), heff_strAppend(heff_dup(v_p_241), v_t_2425));
          v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_body_244);
          heff_drop(v_field_2419);
          v_t_2427 = NTAG(TAG_Nil);
        }
      }
    }
  }
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str16), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str17)));
  HeffT2 v_t_2429 = ({ V a_0 = v_uses_240; V a_1 = v_t_2428; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_2428); r_; });
  V v_t_2444;
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_x_2432 = v_field_2431;
      heff_drop(v_x_2432);
      V v_x2_2433 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str18), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str19), heff_dup(v_params_243)));
      V v_t_2436;
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Nil: {
        v_t_2436 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str20);
        break;
      }
      case TAG_Cons: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_xs_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        v_t_2436 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str21); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2433);
      }
      V v_t_2439;
      switch (heff_tag_of(v_params_243)) {
      case TAG_Nil: {
        v_t_2439 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str22);
        break;
      }
      case TAG_Cons: {
        V v_x_2437 = heff_field(v_params_243, 0);
        V v_xs_2438 = heff_field(v_params_243, 1);
        heff_take_n(v_params_243, 3ULL, 2);
        v_t_2439 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str23); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
        break;
      }
      default: heff_nomatch(v_params_243);
      }
      V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str24), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str25)));
      V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str26), heff_strAppend(heff_dup(v_p_241), v_t_2440));
      V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str27), heff_strAppend(v_t_2436, v_t_2441));
      V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str28), heff_strAppend(v_p_241, v_t_2442));
      v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_p_241);
      heff_drop(v_params_243);
      heff_drop(v_field_2431);
      v_t_2444 = NTAG(TAG_Nil);
    }
  }
  return (g_prelude_2e_2b_2b(v_t_2427, v_t_2444));
}
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprimHelperU(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsVer_str0, 2, "js");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsVer_str1, 1, "-");
V g_heff_2ecompile_2eemit_2ejsVer_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ejsVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsVer_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ejsVer(V v_p_240, V v_key_241, V v_b_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
  V v_t_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_xs_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_key_241), v_t_244});
  V v_m_246 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_245; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop_tag(v_xs_245, 2); r_; });
  V v_t_247 = ({ V a_0 = v_m_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_246); r_; });
  V v_t_248 = (g_list_2efoldl_24f675617784x1820039874(NTAG(TAG_Nil), v_t_247));
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2ejsVer_lam0, 2, 1, (V[]){v_p_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HE, 1, (V[]){v_b_242}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_key_241}), v_t_2412});
  V v_items_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsVer_str0)}), v_t_2413});
  HeffT2 v_t_2415 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2414));
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_a_2418 = v_field_2416;
    V v_b_2419 = v_field_2417;
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ejsVer_str1), heff_intShow(v_b_2419));
    return heff_strAppend(heff_intShow(v_a_2418), v_t_2420);
  }
}
V g_heff_2ecompile_2eemit_2ejsVer_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ejsVer(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ejsVer_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemit_2eglobalJsH(v_p_240, v_x_2410, v_acc_249));
}
Clo g_heff_2ecompile_2eemit_2ebundleAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleAll_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleAll(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2eemit_2ebundleAll_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_rest_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleAll(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eemit_2eprovStrHelpers_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2eprovStrHelpers_str1, 1, "\012");
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovStrHelpers_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprovStrHelpers(V v_have_240, V v_provs_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s720989758x1967438448(v_provs_241));
  V v_text_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_text_245 = ((V)&g_heff_2ecompile_2eemit_2eprovStrHelpers_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_text_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprovStrHelpers_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = ({ V a_0 = MK_INT(0LL); V a_1 = v_text_245; V b_2 = MK_INT(0LL); V a_3 = heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get()); V r_ = (g_list_2emap_24s319754340x1392149466(a_0, a_1, b_2, a_3)); heff_drop(v_text_245); heff_drop(b_2); r_; });
  V v_t_247 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_246));
  HEFF_LAST return g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0, 1, 1, (V[]){heff_dup(v_have_240)}), v_t_247);
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2eprovStrHelpers(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0(V self, V *args) {
  V v_l_248 = args[0];
  V v_have_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_l_248; V a_1 = v_have_240; V r_ = (g_list_2eany_24s1477604419x1568736711(a_0, a_1)); heff_drop(v_l_248); heff_drop(v_have_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str1, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str2, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str3, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str5, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str6, 11, "$run(() => ");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str8, 5, "})();");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str10, 8, "(() => {");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str11, 13, "\"use strict\";");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str12, 1, "\012");
HEFF_LIT(g_heff_2ecompile_2eemit_2erunSource_str13, 42, "// Generated from Hippogriff; do not edit.");
Clo g_heff_2ecompile_2eemit_2erunSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2erunSource_entry, 4, 0};

V g_heff_2ecompile_2eemit_2erunSource(V v_provs_240, V v_eff_241, V v_key_242, V v_m_243) {
top: ;
  V v_lines_244 = heff_take_field(v_m_243, 0);
  V v_globals_245 = heff_get_n(v_m_243, 1, 2);
  V v_xs_246 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_provs_240));
  V v_t_247 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_246));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str0), NTAG(TAG_Nil)});
  V v_t_249 = (g_list_2eany_24s331724893x1262243254(v_lines_244));
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_lines_244; V a_2 = heff_dup(v_provs_240); V a_3 = heff_dup(v_eff_241); V r_ = (g_heff_2ecompile_2eemit_2eruntimeFor(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_globals_245; V b_1 = heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()); HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, b_1)); heff_drop(v_globals_245); heff_drop(b_1); r_; });
  V v_t_2418;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_i_2414 = v_field_2413;
      V v_arity_2415 = heff_take_field(v_i_2414, 1);
      V v_js_2416 = heff_take_field(v_i_2414, 0);
      V v_lazy_2417 = heff_get_n(v_i_2414, 2, 4);
      if (heff_intLe_c(MK_INT(2LL), v_arity_2415)) {
        heff_drop(v_lazy_2417);
        v_t_2418 = heff_strAppend(v_js_2416, ((V)&g_heff_2ecompile_2eemit_2erunSource_str1));
      } else {
        if ((heff_dup(v_lazy_2417) == NTAG(TAG_True))) {
          heff_drop(v_lazy_2417);
          v_t_2418 = heff_strAppend(v_js_2416, ((V)&g_heff_2ecompile_2eemit_2erunSource_str2));
        } else {
          heff_drop(v_lazy_2417);
          v_t_2418 = v_js_2416;
        }
      }
    } else {
      heff_drop(v_field_2413);
      v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str3);
    }
  }
  V v_t_2419 = ({ V a_0 = v_provs_240; V a_1 = v_eff_241; V r_ = (g_heff_2ecompile_2eemit_2ehandlerOf(a_0, a_1)); heff_drop(v_provs_240); heff_drop(v_eff_241); r_; });
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str4), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2erunSource_str5)));
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str6), heff_strAppend(v_t_2418, v_t_2420));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str7), v_t_2422})});
  V v_t_2424 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str8), v_t_248}), v_lines_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str9), v_t_2423})));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str11), v_t_2424})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str12); V a_1 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str13); V a_2 = v_t_247; V a_3 = v_t_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f806474x1139060582(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); heff_drop_tag(v_t_2425, 2); r_; });
}
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemit_2erunSource(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str0, 2, "$c");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str1, 2, "()");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str2, 9, "undefined");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str3, 17, "() { return $ext(");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str4, 5, "); },");
HEFF_LIT(g_heff_2ecompile_2eemit_2egetterOf_str5, 6, "  get ");
Clo g_heff_2ecompile_2eemit_2egetterOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2egetterOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2egetterOf(V v_gs_240, V v_o_241) {
top: ;
  V v_name_242 = heff_take_field(v_o_241, 0);
  V v_key_243 = heff_get_n(v_o_241, 1, 2);
  V v_t_244 = (g_heff_2ecompile_2eemit_2epropName(v_name_242));
  HeffT2 v_t_245 = ({ V a_0 = v_gs_240; V a_1 = v_key_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_key_243); r_; });
  V v_t_2412;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_i_248 = v_field_247;
      V v_arity_249 = heff_take_field(v_i_248, 1);
      V v_js_2410 = heff_take_field(v_i_248, 0);
      V v_lazy_2411 = heff_get_n(v_i_248, 2, 4);
      if (heff_intLe_c(MK_INT(2LL), v_arity_249)) {
        heff_drop(v_lazy_2411);
        v_t_2412 = heff_strAppend(v_js_2410, ((V)&g_heff_2ecompile_2eemit_2egetterOf_str0));
      } else {
        if ((heff_dup(v_lazy_2411) == NTAG(TAG_True))) {
          heff_drop(v_lazy_2411);
          v_t_2412 = heff_strAppend(v_js_2410, ((V)&g_heff_2ecompile_2eemit_2egetterOf_str1));
        } else {
          heff_drop(v_lazy_2411);
          v_t_2412 = v_js_2410;
        }
      }
    } else {
      heff_drop(v_field_247);
      v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2egetterOf_str2);
    }
  }
  V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2egetterOf_str4)));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str5), heff_strAppend(v_t_244, v_t_2413));
}
V g_heff_2ecompile_2eemit_2egetterOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemit_2egetterOf(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str0, 42, "// Generated from Hippogriff; do not edit.");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str1, 16, "export default {");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str5, 2, "};");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemit_2ejsSource_str7, 1, "\012");
V g_heff_2ecompile_2eemit_2ejsSource_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2ejsSource_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ejsSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsSource_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ejsSource(V v_exports_240, V v_m_241) {
top: ;
  V v_lines_242 = heff_take_field(v_m_241, 0);
  V v_globals_243 = heff_get_n(v_m_241, 1, 2);
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str0), NTAG(TAG_Nil)});
  V v_t_245 = (g_list_2eany_24s331724893x1262243254(v_lines_242));
  V v_t_246;
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    v_t_246 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_245);
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
  }
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str1), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eextStr_get()), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str2), v_t_247})});
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str3), v_t_248})));
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str4), NTAG(TAG_Nil)});
  V v_t_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemit_2ejsSource_lam0, 1, 1, (V[]){heff_dup(v_globals_243)}), v_exports_240));
  V v_t_2418 = (g_prelude_2e_2b_2b_24f58476578x2140998212(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str5), v_t_2410}), heff_clo_n(g_heff_2ecompile_2eemit_2ejsSource_lam1, 1, 1, (V[]){v_globals_243}), v_t_2416));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_249, v_t_2418));
  V v_t_2420 = (g_prelude_2e_2b_2b(v_lines_242, v_t_2419));
  V v_x2_2421 = (g_prelude_2e_2b_2b(v_t_244, v_t_2420));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2ejsSource_str6);
  }
  case TAG_Cons: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_xs_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ejsSource_str7); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ejsSource(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2ejsSource_lam0(V self, V *args) {
  V v_o_2411 = args[0];
  V v_globals_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = ({ V a_0 = v_globals_243; V b_1 = heff_get_n(v_o_2411, 1, 2); HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, b_1)); heff_drop(v_globals_243); heff_drop(b_1); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2413 == ((int64_t)0ULL)) && ({ V v_x_2415 = heff_dup(v_field_2414); int c_ = 1; heff_drop(v_x_2415); c_; })));
    heff_drop(v_field_2414);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eemit_2ejsSource_lam1(V self, V *args) {
  V v_o_2417 = args[0];
  V v_globals_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_globals_243; V a_1 = v_o_2417; V r_ = (g_heff_2ecompile_2eemit_2egetterOf(a_0, a_1)); heff_drop(v_globals_243); r_; });
}
V g_heff_2ecompile_2eemit_2ecompileJs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecompileJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileJs_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecompileJs(V v_g_240, V v_exports0_241) {
top: ;
  V v_t_2411;
  switch (heff_tag_of(v_exports0_241)) {
  case TAG_Nil: {
    V v_t_248 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2ecompileJs_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
    v_t_2411 = (g_list_2emap_24s129316455x2072694707(v_t_248));
    break;
  }
  case TAG_Cons: {
    v_t_2411 = v_exports0_241;
    break;
  }
  default: heff_nomatch(v_exports0_241);
  }
  HEFF_LAST return g_heff_2ecompile_2eemit_2ecompileJsWith(v_g_240, v_t_2411);
}
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecompileJs(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2ecompileJs_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_247 = v_field_246;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_243, v_e_247}), v_acc_242});
    } else {
      heff_drop(v_k_243);
      heff_drop(v_field_246);
      return v_acc_242;
    }
  }
}