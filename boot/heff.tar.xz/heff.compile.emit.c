// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Leaf 13717
#define TAG_MkArm 55352
#define TAG_MkArmJs 44527
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PSeq 50192
#define TAG_PTrue 25538
#define TAG_Plus 9189
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_gs 10067
#define LBL_js 10160
#define LBL_key 315609
#define LBL_lazy 9809979
#define LBL_lines 304335641
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_order 307364712
#define LBL_params 951713969
#define LBL_pre 320797
#define LBL_prec 9944807
#define LBL_sapp 10018197
#define LBL_self 10021907
#define LBL_source 1050636102
#define LBL_text 10052084
#define LBL_trmc 10064219
#define LBL_underLam 296337946
#define LBL_used 10094724
static uint32_t shape_code__prec[] = {LBL_code, LBL_prec};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_gs__names__used__self[] = {LBL_gs, LBL_names, LBL_used, LBL_self};
static uint32_t shape_js__arity__lazy__bounce[] = {LBL_js, LBL_arity, LBL_lazy, LBL_bounce};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_js__env__pre[] = {LBL_js, LBL_env, LBL_pre};
static uint32_t shape_js__pre__env[] = {LBL_js, LBL_pre, LBL_env};
static uint32_t shape_key__params__trmc__sapp[] = {LBL_key, LBL_params, LBL_trmc, LBL_sapp};
static uint32_t shape_lines__globals[] = {LBL_lines, LBL_globals};
static uint32_t shape_params__body[] = {LBL_params, LBL_body};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205(V, V, V, V);
V g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_clo;
V g_heff_2ecompile_2eemit_2eappendEnd(V, V, V);
V g_heff_2ecompile_2eemit_2eappendEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eappendEnd_clo;
V g_heff_2ecompile_2eemit_2eappendSelf(V, V, V);
V g_heff_2ecompile_2eemit_2eappendSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eappendSelf_clo;
V g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_clo;
V g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076(V, V, V);
V g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_clo;
V g_heff_2ecompile_2eemit_2earmNamed(V, V);
V g_heff_2ecompile_2eemit_2earmNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2earmNamed_clo;
V g_heff_2ecompile_2eemit_2eatomGo(V, V);
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eatomGo_clo;
V g_heff_2ecompile_2eemit_2ebindFrom(V, V, V, V);
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindFrom_clo;
V g_heff_2ecompile_2eemit_2ebindName(V, V);
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebindName_clo;
V g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(V, V, V);
V g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_clo;
V g_heff_2ecompile_2eemit_2ebodyBounces(V, V);
V g_heff_2ecompile_2eemit_2ebodyBounces_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyBounces_clo;
V g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(V, V, V);
V g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_clo;
V g_heff_2ecompile_2eemit_2ebounceDepth_get(void);
V g_heff_2ecompile_2eemit_2ebounceGive(V, V, V);
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGive_clo;
V g_heff_2ecompile_2eemit_2ebounceGo(V, V);
V g_heff_2ecompile_2eemit_2ebounceGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebounceGo_clo;
V g_heff_2ecompile_2eemit_2ebundleAll(V, V);
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleAll_clo;
V g_heff_2ecompile_2eemit_2ebundleProvider(V, V);
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo;
V g_heff_2ecompile_2eemit_2ecallName(V, V);
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecallName_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_heff_2ecompile_2eemit_2ecompileExports(V, V);
V g_heff_2ecompile_2eemit_2ecompileExports_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileExports_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2ecompile_2eemit_2ecompileLowered(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileLowered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileLowered_clo;
V g_heff_2ecompile_2eemit_2econdCode(V);
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdCode_clo;
V g_heff_2ecompile_2eemit_2econdIf(V, V, V);
V g_heff_2ecompile_2eemit_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdIf_clo;
V g_heff_2ecompile_2eemit_2econdShaped(V);
V g_heff_2ecompile_2eemit_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econdShaped_clo;
V g_heff_2ecompile_2eemit_2econsLast(V, V, V);
V g_heff_2ecompile_2eemit_2econsLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econsLast_clo;
V g_heff_2ecompile_2eemit_2econsSelf(V, V, V);
V g_heff_2ecompile_2eemit_2econsSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2econsSelf_clo;
V g_heff_2ecompile_2eemit_2edeclsOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edeclsOf_clo;
V g_heff_2ecompile_2eemit_2edefBody(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2edefBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edefBody_clo;
V g_heff_2ecompile_2eemit_2edefFun(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2edefFun_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2edefFun_clo;
V g_heff_2ecompile_2eemit_2eemitCode(V, V, V, V);
V g_heff_2ecompile_2eemit_2eemitCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitCode_clo;
V g_heff_2ecompile_2eemit_2eemitWithShorts(V, V, V);
V g_heff_2ecompile_2eemit_2eemitWithShorts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eemitWithShorts_clo;
V g_heff_2ecompile_2eemit_2eescAt(V, V);
V g_heff_2ecompile_2eemit_2eescAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eescAt_clo;
V g_heff_2ecompile_2eemit_2eexportNameOf(V);
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo;
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(V, V, V);
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_clo;
V g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_clo;
V g_heff_2ecompile_2eemit_2eextStr_get(void);
V g_heff_2ecompile_2eemit_2efindProv(V, V);
V g_heff_2ecompile_2eemit_2efindProv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efindProv_clo;
V g_heff_2ecompile_2eemit_2efixedCode(V, V);
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2efixedCode_clo;
V g_heff_2ecompile_2eemit_2egetterOf(V, V);
V g_heff_2ecompile_2eemit_2egetterOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2egetterOf_clo;
V g_heff_2ecompile_2eemit_2ehandlerOf(V, V);
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo;
V g_heff_2ecompile_2eemit_2ehostLineOf(V);
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo;
V g_heff_2ecompile_2eemit_2eimportLinesOf(V);
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo;
V g_heff_2ecompile_2eemit_2einfoOne(V, V, V, V);
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2einfoOne_clo;
V g_heff_2ecompile_2eemit_2eisIdent(V);
V g_heff_2ecompile_2eemit_2eisIdent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eisIdent_clo;
V g_heff_2ecompile_2eemit_2eisUnitArgs(V);
V g_heff_2ecompile_2eemit_2eisUnitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eisUnitArgs_clo;
V g_heff_2ecompile_2eemit_2eisWordCode(V);
V g_heff_2ecompile_2eemit_2eisWordCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eisWordCode_clo;
V g_heff_2ecompile_2eemit_2ejsNameOf(V, V);
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo;
V g_heff_2ecompile_2eemit_2ejsPick(V, V, V);
V g_heff_2ecompile_2eemit_2ejsPick_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsPick_clo;
V g_heff_2ecompile_2eemit_2ejsSource(V, V);
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ejsSource_clo;
V g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_clo;
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(V, V, V, V);
V g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_clo;
V g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(V, V, V, V);
V g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_clo;
V g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784_clo;
V g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734(V, V, V, V);
V g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_clo;
V g_heff_2ecompile_2eemit_2elazyOf(V, V, V, V);
V g_heff_2ecompile_2eemit_2elazyOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elazyOf_clo;
V g_heff_2ecompile_2eemit_2eletDeclarations(V, V);
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo;
V g_heff_2ecompile_2eemit_2elooped(V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elooped_clo;
V g_heff_2ecompile_2eemit_2enamed(V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_clo;
V g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249_clo;
V g_heff_2ecompile_2eemit_2enamedAs(V, V, V);
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enamedAs_clo;
V g_heff_2ecompile_2eemit_2enodeHead_get(void);
V g_heff_2ecompile_2eemit_2enodeRun(V);
V g_heff_2ecompile_2eemit_2enodeRun_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enodeRun_clo;
V g_heff_2ecompile_2eemit_2enubGo(V, V);
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2enubGo_clo;
V g_heff_2ecompile_2eemit_2eoperatorGo(V, V, V);
V g_heff_2ecompile_2eemit_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eoperatorGo_clo;
V g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(V, V, V);
V g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_clo;
V g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_clo;
V g_heff_2ecompile_2eemit_2eprimBin(V, V, V);
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimBin_clo;
V g_heff_2ecompile_2eemit_2eprimCall(V, V);
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimCall_clo;
V g_heff_2ecompile_2eemit_2eprimHelperU(V, V, V);
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo;
V g_heff_2ecompile_2eemit_2eprimHelpers(V);
V g_heff_2ecompile_2eemit_2eprimHelpers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimHelpers_clo;
V g_heff_2ecompile_2eemit_2eprimOp(V);
V g_heff_2ecompile_2eemit_2eprimOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimOp_clo;
V g_heff_2ecompile_2eemit_2eprimRel(V);
V g_heff_2ecompile_2eemit_2eprimRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimRel_clo;
V g_heff_2ecompile_2eemit_2eprimTest(V, V, V);
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimTest_clo;
V g_heff_2ecompile_2eemit_2eprimUnary(V);
V g_heff_2ecompile_2eemit_2eprimUnary_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUnary_clo;
V g_heff_2ecompile_2eemit_2eprimUses(V, V);
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprimUses_clo;
V g_heff_2ecompile_2eemit_2eprovIndexGo(V, V, V);
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo;
V g_heff_2ecompile_2eemit_2eprovStrHelpers(V, V);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo;
V g_heff_2ecompile_2eemit_2eprovsForGo(V, V);
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo;
V g_heff_2ecompile_2eemit_2equoteGo(V, V, V);
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2equoteGo_clo;
V g_heff_2ecompile_2eemit_2ereserved_get(void);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V, V, V);
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo;
V g_heff_2ecompile_2eemit_2erunSource(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2erunSource_clo;
V g_heff_2ecompile_2eemit_2erunStr_get(void);
V g_heff_2ecompile_2eemit_2eruntime(V);
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntime_clo;
V g_heff_2ecompile_2eemit_2eruntimeFor(V, V, V, V);
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeRes(V);
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeRes_clo;
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(V, V, V, V);
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_clo;
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V, V, V);
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo;
V g_heff_2ecompile_2eemit_2eseqsOf(V);
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eseqsOf_clo;
V g_heff_2ecompile_2eemit_2esharedGo(V, V, V);
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esharedGo_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(V, V, V);
V g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_clo;
V g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508(V, V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_clo;
V g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483(V, V, V, V);
V g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_clo;
V g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200(V, V, V);
V g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_clo;
V g_heff_2ecompile_2eemit_2estmtsReturnCond(V, V);
V g_heff_2ecompile_2eemit_2estmtsReturnCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2estmtsReturnCond_clo;
V g_heff_2ecompile_2eemit_2estrHelpers_get(void);
V g_heff_2ecompile_2eemit_2esumStr_get(void);
V g_heff_2ecompile_2eemit_2etailApp(V);
V g_heff_2ecompile_2eemit_2etailApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailApp_clo;
V g_heff_2ecompile_2eemit_2etailGlobals(V);
V g_heff_2ecompile_2eemit_2etailGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailGlobals_clo;
V g_heff_2ecompile_2eemit_2etailSelf(V, V, V);
V g_heff_2ecompile_2eemit_2etailSelf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2etailSelf_clo;
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void);
V g_heff_2ecompile_2eemit_2euncurryGo(V, V);
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2euncurryGo_clo;
V g_heff_2ecompile_2eemit_2eunsnocGo(V, V);
V g_heff_2ecompile_2eemit_2eunsnocGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eunsnocGo_clo;
V g_heff_2ecompile_2eemit_2evalueRefs(V);
V g_heff_2ecompile_2eemit_2evalueRefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2evalueRefs_clo;
V g_heff_2ecompile_2eemit_2ewordOf(V);
V g_heff_2ecompile_2eemit_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ewordOf_clo;
V g_heff_2ecompile_2eemit_2eworldStr_get(void);
V g_heff_2ecompile_2eemit_2ewrapper(V, V, V, V);
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ewrapper_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2elower_2eentryKey_get(void);
V g_heff_2ecompile_2elower_2elowerErased(V, V);
V g_heff_2ecompile_2elower_2elowerErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerErased_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2eelab_2eeffect_2edropLastD(V);
V g_heff_2eelab_2eeffect_2edropLastD_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2edropLastD_clo;
V g_heff_2eelab_2eeffect_2elastOr(V, V);
V g_heff_2eelab_2eeffect_2elastOr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2elastOr_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1859615565x1399458702(V);
V g_list_2eany_24s1859615565x1399458702_entry(V self, V *a);
extern Clo g_list_2eany_24s1859615565x1399458702_clo;
V g_list_2eany_24s651308273x925219243(V);
V g_list_2eany_24s651308273x925219243_entry(V self, V *a);
extern Clo g_list_2eany_24s651308273x925219243_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s413688307x112671032(V, V, V, V);
V g_list_2efilter_24s413688307x112671032_entry(V self, V *a);
extern Clo g_list_2efilter_24s413688307x112671032_clo;
V g_list_2efilter_24s926921591x156811372(V, V, V, V);
V g_list_2efilter_24s926921591x156811372_entry(V self, V *a);
extern Clo g_list_2efilter_24s926921591x156811372_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1278324331x1671175048(V, V);
V g_list_2efoldl_24s1278324331x1671175048_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1278324331x1671175048_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1430359702x555202731(V, V);
V g_list_2efoldl_24s1430359702x555202731_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1430359702x555202731_clo;
V g_list_2efoldl_24s153144783x1331291624(V, V);
V g_list_2efoldl_24s153144783x1331291624_entry(V self, V *a);
extern Clo g_list_2efoldl_24s153144783x1331291624_clo;
V g_list_2efoldl_24s175567250x489918591(V, V);
V g_list_2efoldl_24s175567250x489918591_entry(V self, V *a);
extern Clo g_list_2efoldl_24s175567250x489918591_clo;
V g_list_2efoldl_24s1787334480x145092089(V, V);
V g_list_2efoldl_24s1787334480x145092089_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1787334480x145092089_clo;
V g_list_2efoldl_24s1994057367x1686730046(V, V);
V g_list_2efoldl_24s1994057367x1686730046_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1994057367x1686730046_clo;
V g_list_2efoldl_24s426392081x749835614(V, V);
V g_list_2efoldl_24s426392081x749835614_entry(V self, V *a);
extern Clo g_list_2efoldl_24s426392081x749835614_clo;
V g_list_2efoldl_24s554524976x621147349(V, V);
V g_list_2efoldl_24s554524976x621147349_entry(V self, V *a);
extern Clo g_list_2efoldl_24s554524976x621147349_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s776813750x121415612(V, V);
V g_list_2efoldl_24s776813750x121415612_entry(V self, V *a);
extern Clo g_list_2efoldl_24s776813750x121415612_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1438389342x1293406880(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1438389342x1293406880_entry(V self, V *a);
extern Clo g_list_2emap_24s1438389342x1293406880_clo;
V g_list_2emap_24s1654555371x977048649(V, V, V, V, V, V);
V g_list_2emap_24s1654555371x977048649_entry(V self, V *a);
extern Clo g_list_2emap_24s1654555371x977048649_clo;
V g_list_2emap_24s1917746138x1825516092(V);
V g_list_2emap_24s1917746138x1825516092_entry(V self, V *a);
extern Clo g_list_2emap_24s1917746138x1825516092_clo;
V g_list_2emap_24s357242026x384251201(V);
V g_list_2emap_24s357242026x384251201_entry(V self, V *a);
extern Clo g_list_2emap_24s357242026x384251201_clo;
V g_list_2emap_24s374365348x2042978339(V, V);
V g_list_2emap_24s374365348x2042978339_entry(V self, V *a);
extern Clo g_list_2emap_24s374365348x2042978339_clo;
V g_list_2emap_24s499977176x606563528(V, V, V);
V g_list_2emap_24s499977176x606563528_entry(V self, V *a);
extern Clo g_list_2emap_24s499977176x606563528_clo;
V g_list_2emap_24s565104239x2094869705(V);
V g_list_2emap_24s565104239x2094869705_entry(V self, V *a);
extern Clo g_list_2emap_24s565104239x2094869705_clo;
V g_list_2emap_24s634984521x2042558081(V);
V g_list_2emap_24s634984521x2042558081_entry(V self, V *a);
extern Clo g_list_2emap_24s634984521x2042558081_clo;
V g_list_2emap_24s732475005x1616712052(V);
V g_list_2emap_24s732475005x1616712052_entry(V self, V *a);
extern Clo g_list_2emap_24s732475005x1616712052_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1610853704x1401907306(V, V, V);
V g_list_2ezipWith_24s1610853704x1401907306_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1610853704x1401907306_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2emaybe_24s1822328499x1781525065(V, V);
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a);
extern Clo g_prelude_2emaybe_24s1822328499x1781525065_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecatMaybesL_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2ecompile_2eemit_2ecatMaybesL(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecatMaybesL(a[0]);
}
Clo g_heff_2ecompile_2eemit_2enubGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enubGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2enubGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_list_2eany(v_t_244, v_seen_240));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), (g_heff_2ecompile_2eemit_2enubGo(heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_xs_243))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2enubGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enubGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2eunsnocGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eunsnocGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eunsnocGo(V v_x1_240, V v_y_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_y_241});
  }
  case TAG_Cons: {
    V v_z_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2eemit_2eunsnocGo(v_rest_243, v_z_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_ini_245 = heff_field(v_x2_244, 0);
      V v_lst_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_y_241, v_ini_245}), v_lst_246});
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eunsnocGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eunsnocGo(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eescAt_str0, 2, (92, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eescAt_str1, 2, (92, 92));
HEFF_STRA(g_heff_2ecompile_2eemit_2eescAt_str2, 2, (92, 110));
HEFF_STRA(g_heff_2ecompile_2eemit_2eescAt_str3, 2, (92, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2eescAt_str4, 2, (92, 116));
Clo g_heff_2ecompile_2eemit_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eescAt_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eescAt(V v_s_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2ecompile_2eemit_2eescAt_str0);
  } else {
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return ((V)&g_heff_2ecompile_2eemit_2eescAt_str1);
    } else {
      if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL))) {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return ((V)&g_heff_2ecompile_2eemit_2eescAt_str2);
      } else {
        if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL))) {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          return ((V)&g_heff_2ecompile_2eemit_2eescAt_str3);
        } else {
          if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL))) {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            return ((V)&g_heff_2ecompile_2eemit_2eescAt_str4);
          } else {
            return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eescAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2equoteGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244 = heff_strAppend(v_acc_242, (g_heff_2ecompile_2eemit_2eescAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2equoteGo(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str0, 4, (112, 108, 117, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str1, 5, (109, 105, 110, 117, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str2, 5, (116, 105, 109, 101, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str3, 5, (115, 108, 97, 115, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str4, 7, (112, 101, 114, 99, 101, 110, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str5, 2, (101, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str6, 2, (108, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str7, 2, (103, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str8, 3, (97, 109, 112));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str9, 3, (98, 97, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str10, 4, (98, 97, 110, 103));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str11, 5, (99, 97, 114, 101, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str12, 1, (113));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str13, 2, (97, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str14, 4, (104, 97, 115, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str15, 6, (100, 111, 108, 108, 97, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str16, 5, (116, 105, 108, 100, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str17, 5, (99, 111, 108, 111, 110));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str18, 3, (100, 111, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewordOf_str19, 9, (98, 97, 99, 107, 115, 108, 97, 115, 104));
Clo g_heff_2ecompile_2eemit_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ewordOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ewordOf(V v_c_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(43LL))) {
    heff_drop(v_c_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str0)});
  } else {
    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(45LL))) {
      heff_drop(v_c_240);
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str1)});
    } else {
      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(42LL))) {
        heff_drop(v_c_240);
        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str2)});
      } else {
        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
          heff_drop(v_c_240);
          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str3)});
        } else {
          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(37LL))) {
            heff_drop(v_c_240);
            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str4)});
          } else {
            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(61LL))) {
              heff_drop(v_c_240);
              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str5)});
            } else {
              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(60LL))) {
                heff_drop(v_c_240);
                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str6)});
              } else {
                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(62LL))) {
                  heff_drop(v_c_240);
                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str7)});
                } else {
                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(38LL))) {
                    heff_drop(v_c_240);
                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str8)});
                  } else {
                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(124LL))) {
                      heff_drop(v_c_240);
                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str9)});
                    } else {
                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(33LL))) {
                        heff_drop(v_c_240);
                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str10)});
                      } else {
                        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(94LL))) {
                          heff_drop(v_c_240);
                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str11)});
                        } else {
                          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(63LL))) {
                            heff_drop(v_c_240);
                            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str12)});
                          } else {
                            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(64LL))) {
                              heff_drop(v_c_240);
                              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str13)});
                            } else {
                              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(35LL))) {
                                heff_drop(v_c_240);
                                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str14)});
                              } else {
                                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(36LL))) {
                                  heff_drop(v_c_240);
                                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str15)});
                                } else {
                                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(126LL))) {
                                    heff_drop(v_c_240);
                                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str16)});
                                  } else {
                                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(58LL))) {
                                      heff_drop(v_c_240);
                                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str17)});
                                    } else {
                                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL))) {
                                        heff_drop(v_c_240);
                                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str18)});
                                      } else {
                                        if (heff_intEq_c(v_c_240, MK_INT(92LL))) {
                                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2ewordOf_str19)});
                                        } else {
                                          return NTAG(TAG_Nothing);
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ewordOf(a[0]);
}
Clo g_heff_2ecompile_2eemit_2eoperatorGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eoperatorGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241))) {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return heff_tag_n(TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242))});
  } else {
    V v_t_244 = (g_heff_2ecompile_2eemit_2ewordOf(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_w_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_245, v_acc_242});
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
}
V g_heff_2ecompile_2eemit_2eoperatorGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eoperatorGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastDotFrom_entry, 2, 0};

V g_heff_2ecompile_2eemit_2elastDotFrom(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(46LL))) {
      heff_drop(v_s_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elastDotFrom(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str2, 1, (95));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str3, 3, (111, 112, 95));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str7, 1, (95));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str8, 3, (111, 112, 95));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str11, 1, (95));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str12, 3, (111, 112, 95));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str13, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str14, 1, (95));
HEFF_STRA(g_heff_2ecompile_2eemit_2espellAt_str15, 3, (111, 112, 95));
Clo g_heff_2ecompile_2eemit_2espellAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2espellAt_entry, 2, 0};

V g_heff_2ecompile_2eemit_2espellAt(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_x2_248;
    if (heff_strEq_c(heff_dup(v_k_240), ((V)&g_heff_2ecompile_2eemit_2espellAt_str0))) {
      v_x2_248 = NTAG(TAG_Nothing);
    } else {
      V v_x1_243 = (g_heff_2ecompile_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_243)) {
      case TAG_Nothing: {
        v_x2_248 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_ws_244 = heff_field(v_x1_243, 0);
        V v_ru_24x1_243_24Just = heff_take_reuse_n(v_x1_243, 1ULL, 1);
        V v_t_247;
        switch (heff_tag_of(v_ws_244)) {
        case TAG_Nil: {
          v_t_247 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_245 = heff_field(v_ws_244, 0);
          V v_xs_246 = heff_field(v_ws_244, 1);
          heff_take_n(v_ws_244, 3ULL, 2);
          v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
          break;
        }
        default: heff_nomatch(v_ws_244);
        }
        v_x2_248 = heff_tag_at_n(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str3), v_t_247)});
        break;
      }
      default: heff_nomatch(v_x1_243);
      }
    }
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      return v_k_240;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      heff_drop(v_k_240);
      return v_x_249;
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x_2411 = heff_strSlice(heff_dup(v_k_240), heff_intAdd(heff_dup(v_i_2410), MK_INT(1LL)), heff_strLength(heff_dup(v_k_240)));
    if (heff_strEq_c(heff_dup(v_x_2411), ((V)&g_heff_2ecompile_2eemit_2espellAt_str4))) {
      heff_drop(v_i_2410);
      heff_drop(v_x_2411);
      V v_x2_2419;
      if (heff_strEq_c(heff_dup(v_k_240), ((V)&g_heff_2ecompile_2eemit_2espellAt_str5))) {
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        v_x2_2419 = NTAG(TAG_Nothing);
      } else {
        V v_x1_2414 = (g_heff_2ecompile_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          v_x2_2419 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_ws_2415 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_ws_2415)) {
          case TAG_Nil: {
            v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str6);
            break;
          }
          case TAG_Cons: {
            V v_x_2416 = heff_field(v_ws_2415, 0);
            V v_xs_2417 = heff_field(v_ws_2415, 1);
            heff_take_n(v_ws_2415, 3ULL, 2);
            v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str7); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
            break;
          }
          default: heff_nomatch(v_ws_2415);
          }
          v_x2_2419 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str8), v_t_2418)});
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
      }
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nothing: {
        return v_k_240;
      }
      case TAG_Just: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        heff_drop(v_k_240);
        return v_x_2420;
      }
      default: return heff_nomatch(v_x2_2419);
      }
    } else {
      V v_x1_2421 = (g_heff_2ecompile_2eemit_2eoperatorGo(v_x_2411, MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_Nothing: {
        heff_drop(v_i_2410);
        V v_x2_2428;
        if (heff_strEq_c(heff_dup(v_k_240), ((V)&g_heff_2ecompile_2eemit_2espellAt_str9))) {
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          v_x2_2428 = NTAG(TAG_Nothing);
        } else {
          V v_x1_2423 = (g_heff_2ecompile_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
          switch (heff_tag_of(v_x1_2423)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            v_x2_2428 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_ws_2424 = heff_field(v_x1_2423, 0);
            heff_take_n(v_x1_2423, 1ULL, 1);
            V v_t_2427;
            switch (heff_tag_of(v_ws_2424)) {
            case TAG_Nil: {
              v_t_2427 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str10);
              break;
            }
            case TAG_Cons: {
              V v_x_2425 = heff_field(v_ws_2424, 0);
              V v_xs_2426 = heff_field(v_ws_2424, 1);
              heff_take_n(v_ws_2424, 3ULL, 2);
              v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str11); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
              break;
            }
            default: heff_nomatch(v_ws_2424);
            }
            v_x2_2428 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str12), v_t_2427)});
            break;
          }
          default: heff_nomatch(v_x1_2423);
          }
        }
        switch (heff_tag_of(v_x2_2428)) {
        case TAG_Nothing: {
          return v_k_240;
        }
        case TAG_Just: {
          V v_x_2429 = heff_field(v_x2_2428, 0);
          heff_take_n(v_x2_2428, 1ULL, 1);
          heff_drop(v_k_240);
          return v_x_2429;
        }
        default: return heff_nomatch(v_x2_2428);
        }
      }
      case TAG_Just: {
        V v_ws_2430 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        V v_t_2433;
        switch (heff_tag_of(v_ws_2430)) {
        case TAG_Nil: {
          v_t_2433 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str13);
          break;
        }
        case TAG_Cons: {
          V v_x_2431 = heff_field(v_ws_2430, 0);
          V v_xs_2432 = heff_field(v_ws_2430, 1);
          heff_take_n(v_ws_2430, 3ULL, 2);
          v_t_2433 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2espellAt_str14); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
          break;
        }
        default: heff_nomatch(v_ws_2430);
        }
        V v_w_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2espellAt_str15), v_t_2433);
        V v_t_2435 = heff_strSlice(v_k_240, MK_INT(0LL), heff_intAdd(v_i_2410, MK_INT(1LL)));
        return heff_strAppend(v_t_2435, v_w_2434);
      }
      default: return heff_nomatch(v_x1_2421);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2espellAt(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str0, 11, (84, 101, 120, 116, 68, 101, 99, 111, 100, 101, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str1, 3, (85, 82, 76));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str2, 11, (84, 101, 120, 116, 69, 110, 99, 111, 100, 101, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str3, 14, (113, 117, 101, 117, 101, 77, 105, 99, 114, 111, 116, 97, 115, 107));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str4, 15, (115, 116, 114, 117, 99, 116, 117, 114, 101, 100, 67, 108, 111, 110, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str5, 6, (66, 117, 102, 102, 101, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str6, 12, (115, 101, 116, 73, 109, 109, 101, 100, 105, 97, 116, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str7, 6, (83, 121, 109, 98, 111, 108));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str8, 6, (82, 101, 103, 69, 120, 112));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str9, 3, (83, 101, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str10, 4, (68, 97, 116, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str11, 5, (65, 114, 114, 97, 121));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str12, 3, (77, 97, 112));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str13, 10, (103, 108, 111, 98, 97, 108, 84, 104, 105, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str14, 7, (80, 114, 111, 109, 105, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str15, 7, (112, 114, 111, 99, 101, 115, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str16, 7, (99, 111, 110, 115, 111, 108, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str17, 10, (115, 101, 116, 84, 105, 109, 101, 111, 117, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str18, 5, (102, 101, 116, 99, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str19, 4, (77, 97, 116, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str20, 4, (74, 83, 79, 78));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str21, 6, (79, 98, 106, 101, 99, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str22, 5, (69, 114, 114, 111, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str23, 6, (83, 116, 114, 105, 110, 103));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str24, 6, (78, 117, 109, 98, 101, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str25, 6, (119, 105, 110, 100, 111, 119));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str26, 6, (66, 105, 103, 73, 110, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str27, 8, (73, 110, 102, 105, 110, 105, 116, 121));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str28, 8, (100, 111, 99, 117, 109, 101, 110, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str29, 9, (117, 110, 100, 101, 102, 105, 110, 101, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str30, 3, (78, 97, 78));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str31, 9, (97, 114, 103, 117, 109, 101, 110, 116, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str32, 4, (101, 118, 97, 108));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str33, 6, (112, 117, 98, 108, 105, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str34, 5, (97, 119, 97, 105, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str35, 7, (112, 114, 105, 118, 97, 116, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str36, 9, (112, 114, 111, 116, 101, 99, 116, 101, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str37, 9, (105, 110, 116, 101, 114, 102, 97, 99, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str38, 7, (112, 97, 99, 107, 97, 103, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str39, 6, (115, 116, 97, 116, 105, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str40, 10, (105, 109, 112, 108, 101, 109, 101, 110, 116, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str41, 5, (121, 105, 101, 108, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str42, 3, (108, 101, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str43, 5, (119, 104, 105, 108, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str44, 4, (119, 105, 116, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str45, 3, (118, 97, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str46, 4, (118, 111, 105, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str47, 3, (116, 114, 121));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str48, 6, (116, 121, 112, 101, 111, 102));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str49, 5, (116, 104, 114, 111, 119));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str50, 4, (116, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str51, 6, (115, 119, 105, 116, 99, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str52, 4, (116, 104, 105, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str53, 6, (114, 101, 116, 117, 114, 110));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str54, 5, (115, 117, 112, 101, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str55, 3, (110, 101, 119));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str56, 4, (110, 117, 108, 108));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str57, 2, (105, 110));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str58, 10, (105, 110, 115, 116, 97, 110, 99, 101, 111, 102));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str59, 2, (105, 102));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str60, 6, (105, 109, 112, 111, 114, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str61, 3, (102, 111, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str62, 8, (102, 117, 110, 99, 116, 105, 111, 110));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str63, 5, (102, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str64, 7, (102, 105, 110, 97, 108, 108, 121));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str65, 6, (101, 120, 112, 111, 114, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str66, 7, (101, 120, 116, 101, 110, 100, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str67, 4, (101, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str68, 4, (101, 110, 117, 109));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str69, 6, (100, 101, 108, 101, 116, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str70, 2, (100, 111));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str71, 8, (100, 101, 98, 117, 103, 103, 101, 114));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str72, 7, (100, 101, 102, 97, 117, 108, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str73, 5, (99, 111, 110, 115, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str74, 8, (99, 111, 110, 116, 105, 110, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str75, 5, (99, 97, 116, 99, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str76, 5, (99, 108, 97, 115, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str77, 5, (98, 114, 101, 97, 107));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereserved_str78, 4, (99, 97, 115, 101));

static V g_heff_2ecompile_2eemit_2ereserved_val;
static int g_heff_2ecompile_2eemit_2ereserved_st;
static V g_heff_2ecompile_2eemit_2ereserved_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str12), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str14), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str16), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str18), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str20), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str22), v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str23), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str24), v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str26), v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str28), v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str29), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str30), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str31), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str32), v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str33), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str34), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str35), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str36), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str38), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str39), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str40), v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str41), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str42), v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str43), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str44), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str45), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str46), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str47), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str48), v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str49), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str50), v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str51), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str52), v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str53), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str54), v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str55), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str56), v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str57), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str58), v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str59), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str60), v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str61), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str62), v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str63), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str64), v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str65), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str66), v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str67), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str68), v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str69), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str70), v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str71), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str72), v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str73), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str74), v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str75), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str76), v_t_2437})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str77), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ereserved_str78), v_t_2438})});
}
V g_heff_2ecompile_2eemit_2ereserved_get(void) {
  if (g_heff_2ecompile_2eemit_2ereserved_st == 2) return g_heff_2ecompile_2eemit_2ereserved_val;
  if (g_heff_2ecompile_2eemit_2ereserved_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2ereserved_st = 1;
  g_heff_2ecompile_2eemit_2ereserved_val = heff_tr(g_heff_2ecompile_2eemit_2ereserved_init());
  g_heff_2ecompile_2eemit_2ereserved_st = 2;
  return g_heff_2ecompile_2eemit_2ereserved_val;
}
Clo g_heff_2ecompile_2eemit_2eisWordCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eisWordCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eisWordCode(V v_c_240) {
top: ;
  V v_t_242;
  if (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240))) {
    v_t_242 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
  } else {
    v_t_242 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    if (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240))) {
      if (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL))) {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      } else {
        if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
          if (heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))) {
            heff_drop(v_c_240);
            return NTAG(TAG_True);
          } else {
            return heff_intEq(v_c_240, MK_INT(95LL));
          }
        } else {
          return heff_intEq(v_c_240, MK_INT(95LL));
        }
      }
    } else {
      if (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240))) {
        if (heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))) {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        } else {
          return heff_intEq(v_c_240, MK_INT(95LL));
        }
      } else {
        return heff_intEq(v_c_240, MK_INT(95LL));
      }
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemit_2eisWordCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eisWordCode(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2esafeChars_str0, 1, (95));
Clo g_heff_2ecompile_2eemit_2esafeChars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esafeChars_entry, 3, 0};

V g_heff_2ecompile_2eemit_2esafeChars(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241))) {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244 = (g_heff_2ecompile_2eemit_2eisWordCode(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241))));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = heff_strSlice(heff_dup(v_x_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      break;
    }
    case TAG_False: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2esafeChars_str0);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_x_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_acc_242, v_t_245);
    v_x_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esafeChars(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2esafeRes_str0, 1, (95));
HEFF_STRA(g_heff_2ecompile_2eemit_2esafeRes_str1, 1, (95));
Clo g_heff_2ecompile_2eemit_2esafeRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esafeRes_entry, 1, 0};

V g_heff_2ecompile_2eemit_2esafeRes(V v_s_240) {
top: ;
  V v_t_241 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_s_240)}));
  V v_t_242 = ({ V a_0 = v_t_241; V b_1 = heff_dup(g_heff_2ecompile_2eemit_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esafeRes_str0), v_s_240);
  }
  case TAG_False: {
    if (heff_intLe_c(MK_INT(48LL), heff_strCharCode(heff_dup(v_s_240), MK_INT(0LL)))) {
      if (heff_intLe_c(heff_strCharCode(heff_dup(v_s_240), MK_INT(0LL)), MK_INT(57LL))) {
        return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esafeRes_str1), v_s_240);
      } else {
        return v_s_240;
      }
    } else {
      return v_s_240;
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemit_2esafeRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esafeRes(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eisIdent_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eisIdent_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eisIdent_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eisIdent_str3, 1, (120));
Clo g_heff_2ecompile_2eemit_2eisIdent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eisIdent_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eisIdent(V v_x_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x_240), ((V)&g_heff_2ecompile_2eemit_2eisIdent_str0))) {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  } else {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_x_240)), MK_INT(1LL));
    V v_t_243 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x_240), v_t_242));
    V v_t_244 = (g_heff_2ecompile_2eemit_2espellAt(heff_dup(v_x_240), v_t_243));
    V v_s_245 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_244, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eisIdent_str1)));
    V v_t_247;
    if (heff_strEq_c(heff_dup(v_s_245), ((V)&g_heff_2ecompile_2eemit_2eisIdent_str2))) {
      heff_drop(v_s_245);
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eisIdent_str3);
    } else {
      v_t_247 = v_s_245;
    }
    V v_t_248 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_247));
    return heff_strEq(v_t_248, v_x_240);
  }
}
V g_heff_2ecompile_2eemit_2eisIdent_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eisIdent(a[0]);
}
Clo g_heff_2ecompile_2eemit_2evalueRefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2evalueRefs_entry, 1, 0};

V g_heff_2ecompile_2eemit_2evalueRefs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_e_240, 0);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_g_242), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_e_240, 1);
    V t_0 = v_b_244;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_as_246 = heff_field(v_e_240, 1);
    V v_t_247 = (g_heff_2ecompile_2eemit_2evalueRefs(v_f_245));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_246)));
    V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1278324331x1671175048(a_0, a_1)); heff_drop(v_t_248); r_; });
    return (g_prelude_2e_2b_2b(v_t_247, v_t_249));
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_e_240, 1);
    V v_b_2412 = heff_field(v_e_240, 2);
    V v_t_2413 = (g_heff_2ecompile_2eemit_2evalueRefs(v_a_2411));
    V v_t_2414 = (g_heff_2ecompile_2eemit_2evalueRefs(v_b_2412));
    return (g_prelude_2e_2b_2b(v_t_2413, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_e_240, 0);
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2415)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1994057367x1686730046(a_0, a_1)); heff_drop(v_t_2416); r_; });
  }
  case TAG_EProj: {
    V v_e2_2417 = heff_field(v_e_240, 0);
    V t_0 = v_e2_2417;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_e_240, 1);
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2421)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s1278324331x1671175048(a_0, a_1)); heff_drop(v_t_2422); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_e_240, 0);
    V v_arms_2424 = heff_field(v_e_240, 1);
    V v_t_2425 = (g_heff_2ecompile_2eemit_2evalueRefs(v_s_2423));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2424)));
    V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s153144783x1331291624(a_0, a_1)); heff_drop(v_t_2426); r_; });
    return (g_prelude_2e_2b_2b(v_t_2425, v_t_2427));
  }
  case TAG_EPrim: {
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2430 = heff_field(v_e_240, 1);
    V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2430)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2431; V r_ = (g_list_2efoldl_24s1278324331x1671175048(a_0, a_1)); heff_drop(v_t_2431); r_; });
  }
  case TAG_ECall: {
    V v_as_2433 = heff_field(v_e_240, 1);
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2433)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2434; V r_ = (g_list_2efoldl_24s1278324331x1671175048(a_0, a_1)); heff_drop(v_t_2434); r_; });
  }
  case TAG_EInt: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eemit_2evalueRefs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2evalueRefs(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemit_2etailApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2etailApp_entry, 1, 0};

V g_heff_2ecompile_2eemit_2etailApp(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_True);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2417 = heff_field(v_e_240, 1);
    HEFF_LAST return g_list_2eany_24s1859615565x1399458702(v_arms_2417);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eemit_2etailApp_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2etailApp(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eemit_2etailGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2etailGlobals_entry, 1, 0};

V g_heff_2ecompile_2eemit_2etailGlobals(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_arms_2417 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2417));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s175567250x489918591(a_0, a_1)); heff_drop(v_t_2418); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    V v_g_2422 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_Cons, 2, (V[]){v_g_2422, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eemit_2etailGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2etailGlobals(a[0]);
}
V g_heff_2ecompile_2eemit_2ebodyBounces_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ebodyBounces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebodyBounces_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebodyBounces(V v_set_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 2ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eemit_2etailApp(v_b_246));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop_rec(v_d_241, 3);
      heff_drop(v_b_246);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_248 = (g_heff_2ecompile_2eemit_2etailGlobals(v_b_246));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2ebodyBounces_lam0, 1, 2, (V[]){v_d_241, heff_dup(v_set_240)}); V a_1 = v_t_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemit_2ebodyBounces_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2ebodyBounces(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemit_2ebodyBounces_lam0(V self, V *args) {
  V v_g_249 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_set_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_g_249), heff_get_n(v_d_241, 0, 3))) {
    heff_drop(v_g_249);
    heff_drop(v_set_240);
    return NTAG(TAG_False);
  } else {
    V v_x3_2411 = ({ V a_0 = v_g_249; V a_1 = v_set_240; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_set_240); r_; });
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_2411);
    }
  }
}
V g_heff_2ecompile_2eemit_2ebounceGo_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2ebounceGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ebounceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebounceGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebounceGo(V v_defs_240, V v_set_241) {
top: ;
  V v_t_245 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2ebounceGo_lam0, 2, 1, (V[]){heff_dup(v_set_241)}), heff_dup(v_set_241), v_defs_240));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_map_2esize(a_0)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_map_2esize(v_set_241));
  if (heff_intEq_c(v_t_246, v_t_247)) {
    return v_set_241;
  } else {
    V v_t_2412 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2ebounceGo_lam1, 2, 1, (V[]){heff_dup(v_set_241)}), v_set_241, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_2412;
    v_defs_240 = t_0;
    v_set_241 = t_1;
    goto top;
  }
}
V g_heff_2ecompile_2eemit_2ebounceGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2ebounceGo(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemit_2ebounceGo_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_d_243 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_243); V r_ = (g_heff_2ecompile_2eemit_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_243, 0, 3), NTAG(TAG_MkUnit), v_m_242));
  }
  case TAG_False: {
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eemit_2ebounceGo_lam1(V self, V *args) {
  V v_m_249 = args[0];
  V v_d_2410 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_2410); V r_ = (g_heff_2ecompile_2eemit_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_2410, 0, 3), NTAG(TAG_MkUnit), v_m_249));
  }
  case TAG_False: {
    heff_drop_rec(v_d_2410, 3);
    return v_m_249;
  }
  default: return heff_nomatch(v_t_2411);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eappendEnd_str0, 9, (115, 116, 114, 65, 112, 112, 101, 110, 100));
Clo g_heff_2ecompile_2eemit_2eappendEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eappendEnd_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eappendEnd(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2421 = heff_field(v_e_242, 0);
    V v_as_2422 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_as_2422)) {
    case TAG_Nil: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_it2_2424 = heff_field(v_as_2422, 1);
      switch (heff_tag_of(v_it2_2424)) {
      case TAG_Nil: {
        heff_drop(v_key_240);
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_rr_2425 = heff_field(v_it2_2424, 0);
        V v_it22_2426 = heff_field(v_it2_2424, 1);
        switch (heff_tag_of(v_it22_2426)) {
        case TAG_Nil: {
          if (heff_strEq_c(heff_dup(v_p_2421), ((V)&g_heff_2ecompile_2eemit_2eappendEnd_str0))) {
            V t_0 = v_key_240;
            V t_1 = v_n_241;
            V t_2 = v_rr_2425;
            v_key_240 = t_0;
            v_n_241 = t_1;
            v_e_242 = t_2;
            goto top;
          } else {
            heff_drop(v_key_240);
            heff_drop(v_n_241);
            return NTAG(TAG_False);
          }
        }
        case TAG_Cons: {
          heff_drop(v_key_240);
          heff_drop(v_n_241);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it22_2426);
        }
      }
      default: return heff_nomatch(v_it2_2424);
      }
    }
    default: return heff_nomatch(v_as_2422);
    }
  }
  case TAG_ECall: {
    V v_k_2430 = heff_field(v_e_242, 0);
    V v_as_2431 = heff_field(v_e_242, 1);
    if (heff_strEq_c(heff_dup(v_k_2430), v_key_240)) {
      V v_t_2433 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2431));
      return heff_intEq(v_t_2433, v_n_241);
    } else {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2eappendEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eappendEnd(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eappendSelf_str0, 9, (115, 116, 114, 65, 112, 112, 101, 110, 100));
V g_heff_2ecompile_2eemit_2eappendSelf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eappendSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eappendSelf_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eappendSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2411;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2419 = heff_field(v_e_242, 1);
    return (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemit_2eappendSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2419));
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2426 = heff_field(v_e_242, 0);
    V v_as_2427 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_as_2427)) {
    case TAG_Nil: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_it2_2429 = heff_field(v_as_2427, 1);
      switch (heff_tag_of(v_it2_2429)) {
      case TAG_Nil: {
        heff_drop(v_key_240);
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_rr_2430 = heff_field(v_it2_2429, 0);
        V v_it22_2431 = heff_field(v_it2_2429, 1);
        switch (heff_tag_of(v_it22_2431)) {
        case TAG_Nil: {
          if (heff_strEq_c(heff_dup(v_p_2426), ((V)&g_heff_2ecompile_2eemit_2eappendSelf_str0))) {
            HEFF_LAST return g_heff_2ecompile_2eemit_2eappendEnd(v_key_240, v_n_241, v_rr_2430);
          } else {
            heff_drop(v_key_240);
            heff_drop(v_n_241);
            return NTAG(TAG_False);
          }
        }
        case TAG_Cons: {
          heff_drop(v_key_240);
          heff_drop(v_n_241);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it22_2431);
        }
      }
      default: return heff_nomatch(v_it2_2429);
      }
    }
    default: return heff_nomatch(v_as_2427);
    }
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2eappendSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eappendSelf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2ecompile_2eemit_2eappendSelf_lam0(V self, V *args) {
  V v_a_2420 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424;
  switch (heff_tag_of(v_a_2420)) {
  case TAG_MkArm: {
    V v_b_2423 = heff_field(v_a_2420, 2);
    heff_take_n(v_a_2420, 4ULL, 3);
    v_t_2424 = v_b_2423;
    break;
  }
  default: heff_nomatch(v_a_2420);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2424; V r_ = (g_heff_2ecompile_2eemit_2eappendSelf(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
}
Clo g_heff_2ecompile_2eemit_2econsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econsLast_entry, 3, 0};

V g_heff_2ecompile_2eemit_2econsLast(V v_key_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      V v_k_2424 = heff_field(v_x31_243, 0);
      V v_bs_2425 = heff_field(v_x31_243, 1);
      if (heff_strEq_c(heff_dup(v_k_2424), v_key_240)) {
        V v_t_2427 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_bs_2425));
        return heff_intEq(v_t_2427, v_n_241);
      } else {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_EInt: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2econsLast_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2econsLast(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2ecompile_2eemit_2econsSelf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2econsSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econsSelf_entry, 3, 0};

V g_heff_2ecompile_2eemit_2econsSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2411;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_as_2417 = heff_field(v_e_242, 1);
    V v_x1_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_as_2417)));
    V v_t_2421;
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Nil: {
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x1_2418, 0);
      heff_take_n(v_x1_2418, 1ULL, 2);
      v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
      break;
    }
    default: heff_nomatch(v_x1_2418);
    }
    return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2421; V r_ = (g_heff_2ecompile_2eemit_2econsLast(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EMatch: {
    V v_arms_2423 = heff_field(v_e_242, 1);
    return (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemit_2econsSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2423));
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2econsSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2econsSelf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2ecompile_2eemit_2econsSelf_lam0(V self, V *args) {
  V v_a_2424 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428;
  switch (heff_tag_of(v_a_2424)) {
  case TAG_MkArm: {
    V v_b_2427 = heff_field(v_a_2424, 2);
    heff_take_n(v_a_2424, 4ULL, 3);
    v_t_2428 = v_b_2427;
    break;
  }
  default: heff_nomatch(v_a_2424);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2428; V r_ = (g_heff_2ecompile_2eemit_2econsSelf(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
}
V g_heff_2ecompile_2eemit_2etailSelf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2etailSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2etailSelf_entry, 3, 0};

V g_heff_2ecompile_2eemit_2etailSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_246 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_ELam: {
    V v_t_249 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_EApp: {
    V v_t_2412 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ELet: {
    V v_b_2415 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2415;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2417 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_EProj: {
    V v_t_2421 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_ETag: {
    V v_t_2424 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  case TAG_EMatch: {
    V v_arms_2426 = heff_field(v_e_242, 1);
    return (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemit_2etailSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2426));
  }
  case TAG_EPrim: {
    V v_t_2433 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2436 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_ECall: {
    V v_k_2437 = heff_field(v_e_242, 0);
    V v_as_2438 = heff_field(v_e_242, 1);
    if (heff_strEq_c(heff_dup(v_k_2437), v_key_240)) {
      V v_t_2440 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2438));
      return heff_intEq(v_t_2440, v_n_241);
    } else {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
  }
  case TAG_EInt: {
    V v_t_2442 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  case TAG_EFloat: {
    V v_t_2444 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  case TAG_EStr: {
    V v_t_2446 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_EFixed: {
    V v_t_2449 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2449)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2449);
    }
  }
  case TAG_EFloat32: {
    V v_t_2451 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2451)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_EAbandon: {
    V v_t_2452 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2452)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2452);
    }
  }
  case TAG_EFix: {
    V v_t_2455 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2455)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2455);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2etailSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2etailSelf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2ecompile_2eemit_2etailSelf_lam0(V self, V *args) {
  V v_a_2427 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431;
  switch (heff_tag_of(v_a_2427)) {
  case TAG_MkArm: {
    V v_b_2430 = heff_field(v_a_2427, 2);
    heff_take_n(v_a_2427, 4ULL, 3);
    v_t_2431 = v_b_2430;
    break;
  }
  default: heff_nomatch(v_a_2427);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2431; V r_ = (g_heff_2ecompile_2eemit_2etailSelf(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
}
Clo g_heff_2ecompile_2eemit_2ebindFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebindFrom_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ebindFrom(V v_env_240, V v_x_241, V v_base_242, V v_i_243) {
top: ;
  V v_k_245;
  if (heff_intEq_c(heff_dup(v_i_243), MK_INT(0LL))) {
    v_k_245 = heff_dup(v_base_242);
  } else {
    v_k_245 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
  }
  V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(v_k_245, heff_rfield(v_env_240, 2)));
  V v_t_248;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_246);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    V t_0 = v_env_240;
    V t_1 = v_x_241;
    V t_2 = v_base_242;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    v_env_240 = t_0;
    v_x_241 = t_1;
    v_base_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_False: {
    V v_t_2410;
    if (heff_intEq_c(heff_dup(v_i_243), MK_INT(0LL))) {
      v_t_2410 = heff_dup(v_base_242);
    } else {
      v_t_2410 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
    }
    V v_v_2412;
    if (heff_intEq_c(heff_dup(v_i_243), MK_INT(0LL))) {
      heff_drop(v_i_243);
      v_v_2412 = v_base_242;
    } else {
      v_v_2412 = heff_strAppend(v_base_242, heff_intShow(v_i_243));
    }
    V v_t_2413 = (g_map_2einsert_24s1341440536x470972936(v_x_241, heff_dup(v_v_2412), heff_take_field(v_env_240, 1)));
    V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_v_2412, NTAG(TAG_MkUnit), heff_take_field(v_env_240, 2)));
    V v_t_2415 = ({ V rv_1 = v_t_2413; V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_n(v_env_240, 9ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_rec_n(2, shape_js__env, (V[]){v_t_2410, v_t_2415});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ecompile_2eemit_2ebindFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebindFrom(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ebindName_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebindName_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebindName_str2, 1, (120));
Clo g_heff_2ecompile_2eemit_2ebindName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebindName_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebindName(V v_env_240, V v_x_241) {
top: ;
  V v_x0_242 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_241), MK_INT(0LL)));
  V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x0_242)), MK_INT(1LL));
  V v_t_244 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x0_242), v_t_243));
  V v_t_245 = (g_heff_2ecompile_2eemit_2espellAt(v_x0_242, v_t_244));
  V v_s_246 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_245, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ebindName_str0)));
  V v_t_248;
  if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_heff_2ecompile_2eemit_2ebindName_str1))) {
    heff_drop(v_s_246);
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2ebindName_str2);
  } else {
    v_t_248 = v_s_246;
  }
  V v_t_249 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_248));
  return (g_heff_2ecompile_2eemit_2ebindFrom(v_env_240, v_x_241, v_t_249, MK_INT(0LL)));
}
V g_heff_2ecompile_2eemit_2ebindName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebindName(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str0, 1, (42));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str1, 1, (47));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str2, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str3, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str4, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str5, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str6, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str7, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str8, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str9, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str10, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str11, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str12, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimBin_str13, 1, (32));
Clo g_heff_2ecompile_2eemit_2eprimBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimBin_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimBin(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_244;
  if (heff_strEq_c(heff_dup(v_op_240), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str0))) {
    v_t_244 = NTAG(TAG_True);
  } else {
    v_t_244 = heff_strEq(heff_dup(v_op_240), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str1));
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_246;
    if (heff_intLt_c(heff_dup(heff_rfield(v_a_241, 1)), MK_INT(2LL))) {
      v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str2), heff_strAppend(heff_get_n(v_a_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str3)));
    } else {
      v_t_246 = heff_get_n(v_a_241, 0, 2);
    }
    V v_t_248;
    if (heff_intLt_c(heff_dup(heff_rfield(v_b_242, 1)), MK_INT(3LL))) {
      v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str4), heff_strAppend(heff_get_n(v_b_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str5)));
    } else {
      v_t_248 = heff_get_n(v_b_242, 0, 2);
    }
    V v_t_249 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str6), heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str7), v_t_248))));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_249, MK_INT(2LL)});
  }
  case TAG_False: {
    V v_t_2411;
    if (heff_intLt_c(heff_dup(heff_rfield(v_a_241, 1)), MK_INT(1LL))) {
      v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str8), heff_strAppend(heff_get_n(v_a_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str9)));
    } else {
      v_t_2411 = heff_get_n(v_a_241, 0, 2);
    }
    V v_t_2413;
    if (heff_intLt_c(heff_dup(heff_rfield(v_b_242, 1)), MK_INT(2LL))) {
      v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str10), heff_strAppend(heff_get_n(v_b_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimBin_str11)));
    } else {
      v_t_2413 = heff_get_n(v_b_242, 0, 2);
    }
    V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str12), heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimBin_str13), v_t_2413))));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2414, MK_INT(1LL)});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eemit_2eprimBin_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimBin(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimTest_str0, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimTest_str1, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimTest_str2, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimTest_str3, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimTest_str4, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimTest_str5, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimTest_str6, 10, (32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
Clo g_heff_2ecompile_2eemit_2eprimTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimTest_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimTest(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_244;
  if (heff_intLt_c(heff_dup(heff_rfield(v_a_241, 1)), MK_INT(2LL))) {
    v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str0), heff_strAppend(heff_get_n(v_a_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str1)));
  } else {
    v_t_244 = heff_get_n(v_a_241, 0, 2);
  }
  V v_t_246;
  if (heff_intLt_c(heff_dup(heff_rfield(v_b_242, 1)), MK_INT(2LL))) {
    v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str2), heff_strAppend(heff_get_n(v_b_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimTest_str3)));
  } else {
    v_t_246 = heff_get_n(v_b_242, 0, 2);
  }
  V v_t_247 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str4), heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimTest_str5), heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2eemit_2eprimTest_str6))))));
  return heff_rec_n(2, shape_code__prec, (V[]){v_t_247, MK_INT(0LL)});
}
V g_heff_2ecompile_2eemit_2eprimTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimTest(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str0, 6, (105, 110, 116, 65, 100, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str1, 1, (43));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str2, 6, (105, 110, 116, 83, 117, 98));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str3, 1, (45));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str4, 6, (105, 110, 116, 77, 117, 108));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str5, 1, (42));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str6, 9, (115, 116, 114, 65, 112, 112, 101, 110, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str7, 1, (43));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str8, 5, (105, 110, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str9, 3, (61, 61, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str10, 5, (115, 116, 114, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str11, 3, (61, 61, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str12, 5, (105, 110, 116, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str13, 1, (60));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str14, 5, (115, 116, 114, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str15, 1, (60));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str16, 5, (105, 110, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str17, 2, (60, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str18, 8, (102, 108, 111, 97, 116, 65, 100, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str19, 1, (43));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str20, 8, (102, 108, 111, 97, 116, 83, 117, 98));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str21, 1, (45));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str22, 8, (102, 108, 111, 97, 116, 77, 117, 108));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str23, 1, (42));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str24, 8, (102, 108, 111, 97, 116, 68, 105, 118));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str25, 1, (47));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str26, 7, (102, 108, 111, 97, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str27, 3, (61, 61, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str28, 7, (102, 108, 111, 97, 116, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str29, 1, (60));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str30, 7, (102, 108, 111, 97, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimOp_str31, 2, (60, 61));
Clo g_heff_2ecompile_2eemit_2eprimOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimOp_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eprimOp(V v_x1_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str0))) {
    heff_drop(v_x1_240);
    V v_t_242 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str1)}));
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_242});
  } else {
    if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str2))) {
      heff_drop(v_x1_240);
      V v_t_244 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str3)}));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    } else {
      if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str4))) {
        heff_drop(v_x1_240);
        V v_t_246 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str5)}));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
      } else {
        if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str6))) {
          heff_drop(v_x1_240);
          V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str7)}));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
        } else {
          if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str8))) {
            heff_drop(v_x1_240);
            V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str9)}));
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
          } else {
            if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str10))) {
              heff_drop(v_x1_240);
              V v_t_2412 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str11)}));
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
            } else {
              if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str12))) {
                heff_drop(v_x1_240);
                V v_t_2414 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str13)}));
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
              } else {
                if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str14))) {
                  heff_drop(v_x1_240);
                  V v_t_2416 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str15)}));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
                } else {
                  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str16))) {
                    heff_drop(v_x1_240);
                    V v_t_2418 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str17)}));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2418});
                  } else {
                    if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str18))) {
                      heff_drop(v_x1_240);
                      V v_t_2420 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str19)}));
                      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
                    } else {
                      if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str20))) {
                        heff_drop(v_x1_240);
                        V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str21)}));
                        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
                      } else {
                        if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str22))) {
                          heff_drop(v_x1_240);
                          V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str23)}));
                          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2424});
                        } else {
                          if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str24))) {
                            heff_drop(v_x1_240);
                            V v_t_2426 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str25)}));
                            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2426});
                          } else {
                            if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str26))) {
                              heff_drop(v_x1_240);
                              V v_t_2428 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str27)}));
                              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2428});
                            } else {
                              if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimOp_str28))) {
                                heff_drop(v_x1_240);
                                V v_t_2430 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str29)}));
                                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
                              } else {
                                if (heff_strEq_c(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimOp_str30))) {
                                  V v_t_2432 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimOp_str31)}));
                                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
                                } else {
                                  return NTAG(TAG_Nothing);
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimOp(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str0, 7, (105, 110, 116, 83, 104, 111, 119));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str1, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str2, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str3, 11, (46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str4, 9, (115, 116, 114, 76, 101, 110, 103, 116, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str5, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str6, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str7, 7, (66, 105, 103, 73, 110, 116, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUnary_str8, 8, (46, 108, 101, 110, 103, 116, 104, 41));
V g_heff_2ecompile_2eemit_2eprimUnary_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_lam0, 1, 0};
V g_heff_2ecompile_2eemit_2eprimUnary_lam1(V self, V *args); static Clo g_heff_2ecompile_2eemit_2eprimUnary_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_lam1, 1, 0};
Clo g_heff_2ecompile_2eemit_2eprimUnary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUnary_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eprimUnary(V v_x1_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str0))) {
    heff_drop(v_x1_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimUnary_lam0_clo)});
  } else {
    if (heff_strEq_c(v_x1_240, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str4))) {
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimUnary_lam1_clo)});
    } else {
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimUnary_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimUnary(a[0]);
}
V g_heff_2ecompile_2eemit_2eprimUnary_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_t_244;
  if (heff_intLt_c(heff_dup(heff_rfield(v_a_242, 1)), MK_INT(3LL))) {
    v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_str1), heff_strAppend(heff_get_n(v_a_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str2)));
  } else {
    v_t_244 = heff_get_n(v_a_242, 0, 2);
  }
  V v_code_245 = heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str3));
  return heff_rec_n(2, shape_code__prec, (V[]){v_code_245, MK_INT(3LL)});
}
V g_heff_2ecompile_2eemit_2eprimUnary_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_t_249;
  if (heff_intLt_c(heff_dup(heff_rfield(v_a_247, 1)), MK_INT(3LL))) {
    v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_str5), heff_strAppend(heff_get_n(v_a_247, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str6)));
  } else {
    v_t_249 = heff_get_n(v_a_247, 0, 2);
  }
  V v_code_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUnary_str7), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2eprimUnary_str8)));
  return heff_rec_n(2, shape_code__prec, (V[]){v_code_2410, MK_INT(3LL)});
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str1, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str2, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str3, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str4, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str6, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str7, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str8, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str9, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str11, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str12, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str13, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str14, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str16, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str17, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str18, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimCall_str19, 1, (41));
Clo g_heff_2ecompile_2eemit_2eprimCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimCall_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimCall(V v_p_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    V v_x2_242 = (g_list_2emap_24s357242026x384251201(v_as_241));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    V v_code_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str2), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str3), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str4)))));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_246, MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_a_247 = heff_dup(heff_field(v_as_241, 0));
    V v_it2_248 = heff_dup(heff_field(v_as_241, 1));
    switch (heff_tag_of(v_it2_248)) {
    case TAG_Nil: {
      V v_t_249 = (g_heff_2ecompile_2eemit_2eprimUnary(heff_dup(v_p_240)));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop(v_a_247);
        V v_x2_2410 = (g_list_2emap_24s357242026x384251201(v_as_241));
        V v_t_2413;
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          v_t_2413 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str6); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        V v_code_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str7), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str8), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str9)))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2414, MK_INT(3LL)});
      }
      case TAG_Just: {
        V v_f_2415 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop_tag(v_as_241, 2);
        return heff_tail(v_f_2415, 1, (V[]){v_a_247});
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_Cons: {
      V v_b_2416 = heff_field(v_it2_248, 0);
      V v_it22_2417 = heff_field(v_it2_248, 1);
      heff_take_n(v_it2_248, 3ULL, 2);
      switch (heff_tag_of(v_it22_2417)) {
      case TAG_Nil: {
        V v_t_2418 = (g_heff_2ecompile_2eemit_2eprimOp(heff_dup(v_p_240)));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop(v_a_247);
          heff_drop(v_b_2416);
          V v_x2_2419 = (g_list_2emap_24s357242026x384251201(v_as_241));
          V v_t_2422;
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_Nil: {
            v_t_2422 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str10);
            break;
          }
          case TAG_Cons: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_xs_2421 = heff_field(v_x2_2419, 1);
            heff_take_n(v_x2_2419, 3ULL, 2);
            v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str11); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2419);
          }
          V v_code_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str12), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str13), heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str14)))));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2423, MK_INT(3LL)});
        }
        case TAG_Just: {
          V v_f_2424 = heff_field(v_t_2418, 0);
          heff_take_n(v_t_2418, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop_tag(v_as_241, 2);
          return heff_tail(v_f_2424, 2, (V[]){v_a_247, v_b_2416});
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2417, 0ULL, 2);
        heff_drop(v_a_247);
        heff_drop(v_b_2416);
        V v_x2_2427 = (g_list_2emap_24s357242026x384251201(v_as_241));
        V v_t_2430;
        switch (heff_tag_of(v_x2_2427)) {
        case TAG_Nil: {
          v_t_2430 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str15);
          break;
        }
        case TAG_Cons: {
          V v_x_2428 = heff_field(v_x2_2427, 0);
          V v_xs_2429 = heff_field(v_x2_2427, 1);
          heff_take_n(v_x2_2427, 3ULL, 2);
          v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimCall_str16); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2427);
        }
        V v_code_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str17), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimCall_str18), heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemit_2eprimCall_str19)))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_code_2431, MK_INT(3LL)});
      }
      default: return heff_nomatch(v_it22_2417);
      }
    }
    default: return heff_nomatch(v_it2_248);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimCall(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdIf_entry, 3, 0};

V g_heff_2ecompile_2eemit_2econdIf(V v_c_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_PRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_c_240;
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PSeq: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag_n(TAG_PNot, 1, (V[]){v_c_240});
      }
      case TAG_PFalse: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PSeq: {
        return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PSeq: {
      return heff_tag_n(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PNot: {
    V v_c1_2428 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    V t_0 = v_c1_2428;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2429 = heff_field(v_c_240, 0);
    V v_b_2430 = heff_field(v_c_240, 1);
    V v_c3_2431 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PIf = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_t_2440;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_PFalse: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_PRel: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PSeq: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      V v_t_2449;
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_2449 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_2449 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_PSeq: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      switch (heff_tag_of(v_t_2449)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24c_240_24PIf, 3);
        V v_t_2450 = (g_heff_2ecompile_2eemit_2econdIf(v_b_2430, heff_dup(v_t_241), heff_dup(v_e_242)));
        V v_t_2451 = (g_heff_2ecompile_2eemit_2econdIf(v_c3_2431, v_t_241, v_e_242));
        V t_0 = v_a_2429;
        V t_1 = v_t_2450;
        V t_2 = v_t_2451;
        v_c_240 = t_0;
        v_t_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2429, v_b_2430, v_c3_2431}), v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_t_2449);
      }
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag_n(TAG_PIf, 3, (V[]){v_a_2429, v_b_2430, v_c3_2431}), v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  case TAG_PSeq: {
    V v_x_2452 = heff_field(v_c_240, 0);
    V v_a_2453 = heff_field(v_c_240, 1);
    V v_c3_2454 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PSeq = heff_take_reuse_n(v_c_240, 7ULL, 3);
    return heff_tag_at_n(v_ru_24c_240_24PSeq, TAG_PSeq, 3, (V[]){v_x_2452, v_a_2453, (g_heff_2ecompile_2eemit_2econdIf(v_c3_2454, v_t_241, v_e_242))});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2ecompile_2eemit_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdIf(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str0, 4, (116, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str1, 5, (102, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str2, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str3, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str4, 1, (33));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str5, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str6, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str7, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str8, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str9, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str10, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str11, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str12, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str13, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str14, 4, (32, 38, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str15, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str16, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str17, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str18, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str19, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str20, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str21, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str22, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str23, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str24, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str25, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str26, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str27, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str28, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str29, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str30, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str31, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str32, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str33, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str34, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str35, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str36, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str37, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str38, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str39, 4, (32, 38, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str40, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str41, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str42, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str43, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str44, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str45, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str46, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str47, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str48, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str49, 4, (32, 38, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str50, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str51, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str52, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str53, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str54, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str55, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str56, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str57, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str58, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str59, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str60, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str61, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str62, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str63, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str64, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str65, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str66, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str67, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str68, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str69, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str70, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str71, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str72, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str73, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str74, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str75, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str76, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str77, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str78, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str79, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str80, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str81, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str82, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str83, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str84, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str85, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str86, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str87, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str88, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str89, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str90, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str91, 4, (32, 38, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str92, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str93, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str94, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str95, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str96, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str97, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str98, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str99, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str100, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str101, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str102, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str103, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str104, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str105, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str106, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str107, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str108, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str109, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str110, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str111, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str112, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str113, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str114, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str115, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str116, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str117, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str118, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str119, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str120, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str121, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str122, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str123, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str124, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str125, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str126, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str127, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str128, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str129, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str130, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str131, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str132, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str133, 4, (32, 38, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str134, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str135, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str136, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str137, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str138, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str139, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str140, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str141, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str142, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str143, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str144, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str145, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str146, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str147, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str148, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str149, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str150, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str151, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str152, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str153, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str154, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str155, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str156, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str157, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str158, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str159, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str160, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str161, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str162, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str163, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str164, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str165, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str166, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str167, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str168, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str169, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str170, 4, (32, 124, 124, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str171, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str172, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str173, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str174, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str175, 4, (32, 38, 38, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str176, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str177, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str178, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str179, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str180, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str181, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str182, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str183, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str184, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str185, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str186, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str187, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str188, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str189, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str190, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str191, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str192, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str193, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str194, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str195, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str196, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str197, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str198, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str199, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str200, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str201, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str202, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str203, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str204, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str205, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str206, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str207, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str208, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str209, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str210, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str211, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str212, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdCode_str213, 1, (41));
Clo g_heff_2ecompile_2eemit_2econdCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdCode_entry, 1, 0};

V g_heff_2ecompile_2eemit_2econdCode(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PTrue: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2econdCode_str0), MK_INT(4LL)});
  }
  case TAG_PFalse: {
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2econdCode_str1), MK_INT(4LL)});
  }
  case TAG_PRel: {
    V v_s_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 1);
    return heff_rec_n(2, shape_code__prec, (V[]){v_s_241, MK_INT(3LL)});
  }
  case TAG_PNot: {
    V v_q_242 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 1);
    V v_c_243 = (g_heff_2ecompile_2eemit_2econdCode(v_q_242));
    V v_t_245;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_243, 1)), MK_INT(4LL))) {
      v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str2), heff_strAppend(heff_get_n(v_c_243, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str3)));
    } else {
      v_t_245 = heff_get_n(v_c_243, 0, 2);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str4), v_t_245), MK_INT(4LL)});
  }
  case TAG_PIf: {
    V v_c_246 = heff_field(v_p_240, 0);
    V v_t_247 = heff_field(v_p_240, 1);
    V v_it3_248 = heff_field(v_p_240, 2);
    heff_take_n(v_p_240, 7ULL, 3);
    switch (heff_tag_of(v_it3_248)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_249 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_2411;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_249, 1)), MK_INT(1LL))) {
          v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str5), heff_strAppend(heff_get_n(v_c_249, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str6)));
        } else {
          v_t_2411 = heff_get_n(v_c_249, 0, 2);
        }
        V v_c_2412 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_2414;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2412, 1)), MK_INT(1LL))) {
          v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str7), heff_strAppend(heff_get_n(v_c_2412, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str8)));
        } else {
          v_t_2414 = heff_get_n(v_c_2412, 0, 2);
        }
        V v_t_2415 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str9), v_t_2414));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2415, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_2416 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2418;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2416, 1)), MK_INT(2LL))) {
          v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str10), heff_strAppend(heff_get_n(v_c_2416, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str11)));
        } else {
          v_t_2418 = heff_get_n(v_c_2416, 0, 2);
        }
        V v_c_2419 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_2421;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2419, 1)), MK_INT(2LL))) {
          v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str12), heff_strAppend(heff_get_n(v_c_2419, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str13)));
        } else {
          v_t_2421 = heff_get_n(v_c_2419, 0, 2);
        }
        V v_t_2422 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str14), v_t_2421));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2422, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_2424 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2426;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2424, 1)), MK_INT(1LL))) {
          v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str15), heff_strAppend(heff_get_n(v_c_2424, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str16)));
        } else {
          v_t_2426 = heff_get_n(v_c_2424, 0, 2);
        }
        V v_c_2427 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_2429;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2427, 1)), MK_INT(1LL))) {
          v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str17), heff_strAppend(heff_get_n(v_c_2427, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str18)));
        } else {
          v_t_2429 = heff_get_n(v_c_2427, 0, 2);
        }
        V v_t_2430 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str19), v_t_2429));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2430, MK_INT(1LL)});
      }
      case TAG_PNot: {
        V v_c_2432 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2434;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2432, 1)), MK_INT(1LL))) {
          v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str20), heff_strAppend(heff_get_n(v_c_2432, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str21)));
        } else {
          v_t_2434 = heff_get_n(v_c_2432, 0, 2);
        }
        V v_c_2435 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_2437;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2435, 1)), MK_INT(1LL))) {
          v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str22), heff_strAppend(heff_get_n(v_c_2435, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str23)));
        } else {
          v_t_2437 = heff_get_n(v_c_2435, 0, 2);
        }
        V v_t_2438 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str24), v_t_2437));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2438, MK_INT(1LL)});
      }
      case TAG_PIf: {
        V v_c_2442 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2444;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2442, 1)), MK_INT(1LL))) {
          v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str25), heff_strAppend(heff_get_n(v_c_2442, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str26)));
        } else {
          v_t_2444 = heff_get_n(v_c_2442, 0, 2);
        }
        V v_c_2445 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_2447;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2445, 1)), MK_INT(1LL))) {
          v_t_2447 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str27), heff_strAppend(heff_get_n(v_c_2445, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str28)));
        } else {
          v_t_2447 = heff_get_n(v_c_2445, 0, 2);
        }
        V v_t_2448 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str29), v_t_2447));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2448, MK_INT(1LL)});
      }
      case TAG_PSeq: {
        V v_c_2452 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2454;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2452, 1)), MK_INT(1LL))) {
          v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str30), heff_strAppend(heff_get_n(v_c_2452, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str31)));
        } else {
          v_t_2454 = heff_get_n(v_c_2452, 0, 2);
        }
        V v_c_2455 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_2457;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2455, 1)), MK_INT(1LL))) {
          v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str32), heff_strAppend(heff_get_n(v_c_2455, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str33)));
        } else {
          v_t_2457 = heff_get_n(v_c_2455, 0, 2);
        }
        V v_t_2458 = heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str34), v_t_2457));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2458, MK_INT(1LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PFalse: {
      V v_c_2459 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
      V v_t_2461;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2459, 1)), MK_INT(2LL))) {
        v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str35), heff_strAppend(heff_get_n(v_c_2459, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str36)));
      } else {
        v_t_2461 = heff_get_n(v_c_2459, 0, 2);
      }
      V v_c_2462 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
      V v_t_2464;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2462, 1)), MK_INT(2LL))) {
        v_t_2464 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str37), heff_strAppend(heff_get_n(v_c_2462, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str38)));
      } else {
        v_t_2464 = heff_get_n(v_c_2462, 0, 2);
      }
      V v_t_2465 = heff_strAppend(v_t_2461, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str39), v_t_2464));
      return heff_rec_n(2, shape_code__prec, (V[]){v_t_2465, MK_INT(2LL)});
    }
    case TAG_PRel: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_2467 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_2469;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2467, 1)), MK_INT(1LL))) {
          v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str40), heff_strAppend(heff_get_n(v_c_2467, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str41)));
        } else {
          v_t_2469 = heff_get_n(v_c_2467, 0, 2);
        }
        V v_c_2470 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_2472;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2470, 1)), MK_INT(1LL))) {
          v_t_2472 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str42), heff_strAppend(heff_get_n(v_c_2470, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str43)));
        } else {
          v_t_2472 = heff_get_n(v_c_2470, 0, 2);
        }
        V v_t_2473 = heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str44), v_t_2472));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2473, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_2474 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2476;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2474, 1)), MK_INT(2LL))) {
          v_t_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str45), heff_strAppend(heff_get_n(v_c_2474, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str46)));
        } else {
          v_t_2476 = heff_get_n(v_c_2474, 0, 2);
        }
        V v_c_2477 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_2479;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2477, 1)), MK_INT(2LL))) {
          v_t_2479 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str47), heff_strAppend(heff_get_n(v_c_2477, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str48)));
        } else {
          v_t_2479 = heff_get_n(v_c_2477, 0, 2);
        }
        V v_t_2480 = heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str49), v_t_2479));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2480, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_2482 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_2484;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2482, 1)), MK_INT(1LL))) {
          v_t_2484 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str50), heff_strAppend(heff_get_n(v_c_2482, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str51)));
        } else {
          v_t_2484 = heff_get_n(v_c_2482, 0, 2);
        }
        V v_c_2485 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_2487;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2485, 1)), MK_INT(0LL))) {
          v_t_2487 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str52), heff_strAppend(heff_get_n(v_c_2485, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str53)));
        } else {
          v_t_2487 = heff_get_n(v_c_2485, 0, 2);
        }
        V v_c_2488 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_2490;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2488, 1)), MK_INT(0LL))) {
          v_t_2490 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str54), heff_strAppend(heff_get_n(v_c_2488, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str55)));
        } else {
          v_t_2490 = heff_get_n(v_c_2488, 0, 2);
        }
        V v_t_2491 = heff_strAppend(v_t_2484, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str56), heff_strAppend(v_t_2487, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str57), v_t_2490))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_2491, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_2493 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_2495;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2493, 1)), MK_INT(1LL))) {
          v_t_2495 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str58), heff_strAppend(heff_get_n(v_c_2493, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str59)));
        } else {
          v_t_2495 = heff_get_n(v_c_2493, 0, 2);
        }
        V v_c_2496 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_2498;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2496, 1)), MK_INT(0LL))) {
          v_t_2498 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str60), heff_strAppend(heff_get_n(v_c_2496, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str61)));
        } else {
          v_t_2498 = heff_get_n(v_c_2496, 0, 2);
        }
        V v_c_2499 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24101;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2499, 1)), MK_INT(0LL))) {
          v_t_24101 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str62), heff_strAppend(heff_get_n(v_c_2499, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str63)));
        } else {
          v_t_24101 = heff_get_n(v_c_2499, 0, 2);
        }
        V v_t_24102 = heff_strAppend(v_t_2495, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str64), heff_strAppend(v_t_2498, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str65), v_t_24101))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24102, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24106 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24108;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24106, 1)), MK_INT(1LL))) {
          v_t_24108 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str66), heff_strAppend(heff_get_n(v_c_24106, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str67)));
        } else {
          v_t_24108 = heff_get_n(v_c_24106, 0, 2);
        }
        V v_c_24109 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24111;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24109, 1)), MK_INT(0LL))) {
          v_t_24111 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str68), heff_strAppend(heff_get_n(v_c_24109, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str69)));
        } else {
          v_t_24111 = heff_get_n(v_c_24109, 0, 2);
        }
        V v_c_24112 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24114;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24112, 1)), MK_INT(0LL))) {
          v_t_24114 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str70), heff_strAppend(heff_get_n(v_c_24112, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str71)));
        } else {
          v_t_24114 = heff_get_n(v_c_24112, 0, 2);
        }
        V v_t_24115 = heff_strAppend(v_t_24108, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str72), heff_strAppend(v_t_24111, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str73), v_t_24114))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24115, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24119 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24121;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24119, 1)), MK_INT(1LL))) {
          v_t_24121 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str74), heff_strAppend(heff_get_n(v_c_24119, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str75)));
        } else {
          v_t_24121 = heff_get_n(v_c_24119, 0, 2);
        }
        V v_c_24122 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24124;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24122, 1)), MK_INT(0LL))) {
          v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str76), heff_strAppend(heff_get_n(v_c_24122, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str77)));
        } else {
          v_t_24124 = heff_get_n(v_c_24122, 0, 2);
        }
        V v_c_24125 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24127;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24125, 1)), MK_INT(0LL))) {
          v_t_24127 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str78), heff_strAppend(heff_get_n(v_c_24125, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str79)));
        } else {
          v_t_24127 = heff_get_n(v_c_24125, 0, 2);
        }
        V v_t_24128 = heff_strAppend(v_t_24121, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str80), heff_strAppend(v_t_24124, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str81), v_t_24127))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24128, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PNot: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_24130 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24132;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24130, 1)), MK_INT(1LL))) {
          v_t_24132 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str82), heff_strAppend(heff_get_n(v_c_24130, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str83)));
        } else {
          v_t_24132 = heff_get_n(v_c_24130, 0, 2);
        }
        V v_c_24133 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24135;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24133, 1)), MK_INT(1LL))) {
          v_t_24135 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str84), heff_strAppend(heff_get_n(v_c_24133, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str85)));
        } else {
          v_t_24135 = heff_get_n(v_c_24133, 0, 2);
        }
        V v_t_24136 = heff_strAppend(v_t_24132, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str86), v_t_24135));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24136, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_24137 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_24139;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24137, 1)), MK_INT(2LL))) {
          v_t_24139 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str87), heff_strAppend(heff_get_n(v_c_24137, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str88)));
        } else {
          v_t_24139 = heff_get_n(v_c_24137, 0, 2);
        }
        V v_c_24140 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24142;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24140, 1)), MK_INT(2LL))) {
          v_t_24142 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str89), heff_strAppend(heff_get_n(v_c_24140, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str90)));
        } else {
          v_t_24142 = heff_get_n(v_c_24140, 0, 2);
        }
        V v_t_24143 = heff_strAppend(v_t_24139, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str91), v_t_24142));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24143, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_24145 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24147;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24145, 1)), MK_INT(1LL))) {
          v_t_24147 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str92), heff_strAppend(heff_get_n(v_c_24145, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str93)));
        } else {
          v_t_24147 = heff_get_n(v_c_24145, 0, 2);
        }
        V v_c_24148 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24150;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24148, 1)), MK_INT(0LL))) {
          v_t_24150 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str94), heff_strAppend(heff_get_n(v_c_24148, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str95)));
        } else {
          v_t_24150 = heff_get_n(v_c_24148, 0, 2);
        }
        V v_c_24151 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24153;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24151, 1)), MK_INT(0LL))) {
          v_t_24153 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str96), heff_strAppend(heff_get_n(v_c_24151, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str97)));
        } else {
          v_t_24153 = heff_get_n(v_c_24151, 0, 2);
        }
        V v_t_24154 = heff_strAppend(v_t_24147, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str98), heff_strAppend(v_t_24150, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str99), v_t_24153))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24154, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_24156 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24158;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24156, 1)), MK_INT(1LL))) {
          v_t_24158 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str100), heff_strAppend(heff_get_n(v_c_24156, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str101)));
        } else {
          v_t_24158 = heff_get_n(v_c_24156, 0, 2);
        }
        V v_c_24159 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24161;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24159, 1)), MK_INT(0LL))) {
          v_t_24161 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str102), heff_strAppend(heff_get_n(v_c_24159, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str103)));
        } else {
          v_t_24161 = heff_get_n(v_c_24159, 0, 2);
        }
        V v_c_24162 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24164;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24162, 1)), MK_INT(0LL))) {
          v_t_24164 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str104), heff_strAppend(heff_get_n(v_c_24162, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str105)));
        } else {
          v_t_24164 = heff_get_n(v_c_24162, 0, 2);
        }
        V v_t_24165 = heff_strAppend(v_t_24158, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str106), heff_strAppend(v_t_24161, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str107), v_t_24164))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24165, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24169 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24171;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24169, 1)), MK_INT(1LL))) {
          v_t_24171 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str108), heff_strAppend(heff_get_n(v_c_24169, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str109)));
        } else {
          v_t_24171 = heff_get_n(v_c_24169, 0, 2);
        }
        V v_c_24172 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24174;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24172, 1)), MK_INT(0LL))) {
          v_t_24174 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str110), heff_strAppend(heff_get_n(v_c_24172, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str111)));
        } else {
          v_t_24174 = heff_get_n(v_c_24172, 0, 2);
        }
        V v_c_24175 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24177;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24175, 1)), MK_INT(0LL))) {
          v_t_24177 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str112), heff_strAppend(heff_get_n(v_c_24175, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str113)));
        } else {
          v_t_24177 = heff_get_n(v_c_24175, 0, 2);
        }
        V v_t_24178 = heff_strAppend(v_t_24171, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str114), heff_strAppend(v_t_24174, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str115), v_t_24177))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24178, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24182 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24184;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24182, 1)), MK_INT(1LL))) {
          v_t_24184 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str116), heff_strAppend(heff_get_n(v_c_24182, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str117)));
        } else {
          v_t_24184 = heff_get_n(v_c_24182, 0, 2);
        }
        V v_c_24185 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24187;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24185, 1)), MK_INT(0LL))) {
          v_t_24187 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str118), heff_strAppend(heff_get_n(v_c_24185, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str119)));
        } else {
          v_t_24187 = heff_get_n(v_c_24185, 0, 2);
        }
        V v_c_24188 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24190;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24188, 1)), MK_INT(0LL))) {
          v_t_24190 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str120), heff_strAppend(heff_get_n(v_c_24188, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str121)));
        } else {
          v_t_24190 = heff_get_n(v_c_24188, 0, 2);
        }
        V v_t_24191 = heff_strAppend(v_t_24184, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str122), heff_strAppend(v_t_24187, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str123), v_t_24190))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24191, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PIf: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_24195 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24197;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24195, 1)), MK_INT(1LL))) {
          v_t_24197 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str124), heff_strAppend(heff_get_n(v_c_24195, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str125)));
        } else {
          v_t_24197 = heff_get_n(v_c_24195, 0, 2);
        }
        V v_c_24198 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24200;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24198, 1)), MK_INT(1LL))) {
          v_t_24200 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str126), heff_strAppend(heff_get_n(v_c_24198, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str127)));
        } else {
          v_t_24200 = heff_get_n(v_c_24198, 0, 2);
        }
        V v_t_24201 = heff_strAppend(v_t_24197, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str128), v_t_24200));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24201, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_24202 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_24204;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24202, 1)), MK_INT(2LL))) {
          v_t_24204 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str129), heff_strAppend(heff_get_n(v_c_24202, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str130)));
        } else {
          v_t_24204 = heff_get_n(v_c_24202, 0, 2);
        }
        V v_c_24205 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24207;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24205, 1)), MK_INT(2LL))) {
          v_t_24207 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str131), heff_strAppend(heff_get_n(v_c_24205, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str132)));
        } else {
          v_t_24207 = heff_get_n(v_c_24205, 0, 2);
        }
        V v_t_24208 = heff_strAppend(v_t_24204, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str133), v_t_24207));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24208, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_24210 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24212;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24210, 1)), MK_INT(1LL))) {
          v_t_24212 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str134), heff_strAppend(heff_get_n(v_c_24210, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str135)));
        } else {
          v_t_24212 = heff_get_n(v_c_24210, 0, 2);
        }
        V v_c_24213 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24215;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24213, 1)), MK_INT(0LL))) {
          v_t_24215 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str136), heff_strAppend(heff_get_n(v_c_24213, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str137)));
        } else {
          v_t_24215 = heff_get_n(v_c_24213, 0, 2);
        }
        V v_c_24216 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24218;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24216, 1)), MK_INT(0LL))) {
          v_t_24218 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str138), heff_strAppend(heff_get_n(v_c_24216, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str139)));
        } else {
          v_t_24218 = heff_get_n(v_c_24216, 0, 2);
        }
        V v_t_24219 = heff_strAppend(v_t_24212, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str140), heff_strAppend(v_t_24215, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str141), v_t_24218))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24219, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_24221 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24223;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24221, 1)), MK_INT(1LL))) {
          v_t_24223 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str142), heff_strAppend(heff_get_n(v_c_24221, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str143)));
        } else {
          v_t_24223 = heff_get_n(v_c_24221, 0, 2);
        }
        V v_c_24224 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24226;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24224, 1)), MK_INT(0LL))) {
          v_t_24226 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str144), heff_strAppend(heff_get_n(v_c_24224, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str145)));
        } else {
          v_t_24226 = heff_get_n(v_c_24224, 0, 2);
        }
        V v_c_24227 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24229;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24227, 1)), MK_INT(0LL))) {
          v_t_24229 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str146), heff_strAppend(heff_get_n(v_c_24227, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str147)));
        } else {
          v_t_24229 = heff_get_n(v_c_24227, 0, 2);
        }
        V v_t_24230 = heff_strAppend(v_t_24223, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str148), heff_strAppend(v_t_24226, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str149), v_t_24229))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24230, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24234 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24236;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24234, 1)), MK_INT(1LL))) {
          v_t_24236 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str150), heff_strAppend(heff_get_n(v_c_24234, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str151)));
        } else {
          v_t_24236 = heff_get_n(v_c_24234, 0, 2);
        }
        V v_c_24237 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24239;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24237, 1)), MK_INT(0LL))) {
          v_t_24239 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str152), heff_strAppend(heff_get_n(v_c_24237, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str153)));
        } else {
          v_t_24239 = heff_get_n(v_c_24237, 0, 2);
        }
        V v_c_24240 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24242;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24240, 1)), MK_INT(0LL))) {
          v_t_24242 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str154), heff_strAppend(heff_get_n(v_c_24240, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str155)));
        } else {
          v_t_24242 = heff_get_n(v_c_24240, 0, 2);
        }
        V v_t_24243 = heff_strAppend(v_t_24236, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str156), heff_strAppend(v_t_24239, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str157), v_t_24242))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24243, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24247 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24249;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24247, 1)), MK_INT(1LL))) {
          v_t_24249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str158), heff_strAppend(heff_get_n(v_c_24247, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str159)));
        } else {
          v_t_24249 = heff_get_n(v_c_24247, 0, 2);
        }
        V v_c_24250 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24252;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24250, 1)), MK_INT(0LL))) {
          v_t_24252 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str160), heff_strAppend(heff_get_n(v_c_24250, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str161)));
        } else {
          v_t_24252 = heff_get_n(v_c_24250, 0, 2);
        }
        V v_c_24253 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24255;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24253, 1)), MK_INT(0LL))) {
          v_t_24255 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str162), heff_strAppend(heff_get_n(v_c_24253, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str163)));
        } else {
          v_t_24255 = heff_get_n(v_c_24253, 0, 2);
        }
        V v_t_24256 = heff_strAppend(v_t_24249, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str164), heff_strAppend(v_t_24252, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str165), v_t_24255))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24256, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PSeq: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_24260 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24262;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24260, 1)), MK_INT(1LL))) {
          v_t_24262 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str166), heff_strAppend(heff_get_n(v_c_24260, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str167)));
        } else {
          v_t_24262 = heff_get_n(v_c_24260, 0, 2);
        }
        V v_c_24263 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24265;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24263, 1)), MK_INT(1LL))) {
          v_t_24265 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str168), heff_strAppend(heff_get_n(v_c_24263, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str169)));
        } else {
          v_t_24265 = heff_get_n(v_c_24263, 0, 2);
        }
        V v_t_24266 = heff_strAppend(v_t_24262, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str170), v_t_24265));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24266, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_24267 = (g_heff_2ecompile_2eemit_2econdCode(heff_tag_n(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_24269;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24267, 1)), MK_INT(2LL))) {
          v_t_24269 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str171), heff_strAppend(heff_get_n(v_c_24267, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str172)));
        } else {
          v_t_24269 = heff_get_n(v_c_24267, 0, 2);
        }
        V v_c_24270 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24272;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24270, 1)), MK_INT(2LL))) {
          v_t_24272 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str173), heff_strAppend(heff_get_n(v_c_24270, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str174)));
        } else {
          v_t_24272 = heff_get_n(v_c_24270, 0, 2);
        }
        V v_t_24273 = heff_strAppend(v_t_24269, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str175), v_t_24272));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24273, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_24275 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24277;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24275, 1)), MK_INT(1LL))) {
          v_t_24277 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str176), heff_strAppend(heff_get_n(v_c_24275, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str177)));
        } else {
          v_t_24277 = heff_get_n(v_c_24275, 0, 2);
        }
        V v_c_24278 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24280;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24278, 1)), MK_INT(0LL))) {
          v_t_24280 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str178), heff_strAppend(heff_get_n(v_c_24278, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str179)));
        } else {
          v_t_24280 = heff_get_n(v_c_24278, 0, 2);
        }
        V v_c_24281 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24283;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24281, 1)), MK_INT(0LL))) {
          v_t_24283 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str180), heff_strAppend(heff_get_n(v_c_24281, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str181)));
        } else {
          v_t_24283 = heff_get_n(v_c_24281, 0, 2);
        }
        V v_t_24284 = heff_strAppend(v_t_24277, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str182), heff_strAppend(v_t_24280, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str183), v_t_24283))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24284, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_24286 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24288;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24286, 1)), MK_INT(1LL))) {
          v_t_24288 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str184), heff_strAppend(heff_get_n(v_c_24286, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str185)));
        } else {
          v_t_24288 = heff_get_n(v_c_24286, 0, 2);
        }
        V v_c_24289 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24291;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24289, 1)), MK_INT(0LL))) {
          v_t_24291 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str186), heff_strAppend(heff_get_n(v_c_24289, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str187)));
        } else {
          v_t_24291 = heff_get_n(v_c_24289, 0, 2);
        }
        V v_c_24292 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24294;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24292, 1)), MK_INT(0LL))) {
          v_t_24294 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str188), heff_strAppend(heff_get_n(v_c_24292, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str189)));
        } else {
          v_t_24294 = heff_get_n(v_c_24292, 0, 2);
        }
        V v_t_24295 = heff_strAppend(v_t_24288, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str190), heff_strAppend(v_t_24291, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str191), v_t_24294))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24295, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24299 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24301;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24299, 1)), MK_INT(1LL))) {
          v_t_24301 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str192), heff_strAppend(heff_get_n(v_c_24299, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str193)));
        } else {
          v_t_24301 = heff_get_n(v_c_24299, 0, 2);
        }
        V v_c_24302 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24304;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24302, 1)), MK_INT(0LL))) {
          v_t_24304 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str194), heff_strAppend(heff_get_n(v_c_24302, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str195)));
        } else {
          v_t_24304 = heff_get_n(v_c_24302, 0, 2);
        }
        V v_c_24305 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24307;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24305, 1)), MK_INT(0LL))) {
          v_t_24307 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str196), heff_strAppend(heff_get_n(v_c_24305, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str197)));
        } else {
          v_t_24307 = heff_get_n(v_c_24305, 0, 2);
        }
        V v_t_24308 = heff_strAppend(v_t_24301, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str198), heff_strAppend(v_t_24304, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str199), v_t_24307))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24308, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24312 = (g_heff_2ecompile_2eemit_2econdCode(v_c_246));
        V v_t_24314;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24312, 1)), MK_INT(1LL))) {
          v_t_24314 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str200), heff_strAppend(heff_get_n(v_c_24312, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str201)));
        } else {
          v_t_24314 = heff_get_n(v_c_24312, 0, 2);
        }
        V v_c_24315 = (g_heff_2ecompile_2eemit_2econdCode(v_t_247));
        V v_t_24317;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24315, 1)), MK_INT(0LL))) {
          v_t_24317 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str202), heff_strAppend(heff_get_n(v_c_24315, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str203)));
        } else {
          v_t_24317 = heff_get_n(v_c_24315, 0, 2);
        }
        V v_c_24318 = (g_heff_2ecompile_2eemit_2econdCode(v_it3_248));
        V v_t_24320;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_24318, 1)), MK_INT(0LL))) {
          v_t_24320 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str204), heff_strAppend(heff_get_n(v_c_24318, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str205)));
        } else {
          v_t_24320 = heff_get_n(v_c_24318, 0, 2);
        }
        V v_t_24321 = heff_strAppend(v_t_24314, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str206), heff_strAppend(v_t_24317, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str207), v_t_24320))));
        return heff_rec_n(2, shape_code__prec, (V[]){v_t_24321, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_it3_248);
    }
  }
  case TAG_PSeq: {
    V v_x_24322 = heff_field(v_p_240, 0);
    V v_a_24323 = heff_field(v_p_240, 1);
    V v_q_24324 = heff_field(v_p_240, 2);
    heff_take_n(v_p_240, 7ULL, 3);
    V v_c_24325 = (g_heff_2ecompile_2eemit_2econdCode(v_q_24324));
    V v_t_24327;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_24325, 1)), MK_INT(1LL))) {
      v_t_24327 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str208), heff_strAppend(heff_get_n(v_c_24325, 0, 2), ((V)&g_heff_2ecompile_2eemit_2econdCode_str209)));
    } else {
      v_t_24327 = heff_get_n(v_c_24325, 0, 2);
    }
    V v_t_24328 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str210), heff_strAppend(v_x_24322, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str211), heff_strAppend(v_a_24323, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2econdCode_str212), heff_strAppend(v_t_24327, ((V)&g_heff_2ecompile_2eemit_2econdCode_str213)))))));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_24328, MK_INT(4LL)});
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2econdCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdCode(a[0]);
}
Clo g_heff_2ecompile_2eemit_2eseqsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eseqsOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eseqsOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_PFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_PRel: {
    return NTAG(TAG_Nil);
  }
  case TAG_PNot: {
    V v_q_242 = heff_field(v_p_240, 0);
    V t_0 = v_q_242;
    v_p_240 = t_0;
    goto top;
  }
  case TAG_PIf: {
    V v_c_243 = heff_field(v_p_240, 0);
    V v_t_244 = heff_field(v_p_240, 1);
    V v_e_245 = heff_field(v_p_240, 2);
    V v_t_246 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_243));
    V v_t_247 = (g_heff_2ecompile_2eemit_2eseqsOf(v_t_244));
    V v_t_248 = (g_heff_2ecompile_2eemit_2eseqsOf(v_e_245));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
    return (g_prelude_2e_2b_2b(v_t_246, v_t_249));
  }
  case TAG_PSeq: {
    V v_x_2410 = heff_field(v_p_240, 0);
    V v_q_2412 = heff_field(v_p_240, 2);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2410), (g_heff_2ecompile_2eemit_2eseqsOf(v_q_2412))});
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2ecompile_2eemit_2eseqsOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eseqsOf(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eletDeclarations_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eletDeclarations_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eletDeclarations_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eletDeclarations_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eletDeclarations_str4, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eletDeclarations_str5, 4, (108, 101, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eletDeclarations_str6, 1, (59));
Clo g_heff_2ecompile_2eemit_2eletDeclarations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eletDeclarations_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eletDeclarations(V v_ind_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x2_244 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_x2_248 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_241));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str4); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str5), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2eletDeclarations_str6))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2ecompile_2eemit_2eletDeclarations_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eletDeclarations(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str0, 5, (105, 110, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str1, 3, (61, 61, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str2, 5, (115, 116, 114, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str3, 3, (61, 61, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str4, 5, (105, 110, 116, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str5, 1, (60));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str6, 5, (115, 116, 114, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str7, 1, (60));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str8, 5, (105, 110, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str9, 2, (60, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str10, 7, (102, 108, 111, 97, 116, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str11, 3, (61, 61, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str12, 7, (102, 108, 111, 97, 116, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str13, 1, (60));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str14, 7, (102, 108, 111, 97, 116, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str15, 2, (60, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str16, 6, (114, 117, 110, 101, 69, 113));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str17, 3, (61, 61, 61));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str18, 6, (114, 117, 110, 101, 76, 116));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str19, 1, (60));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str20, 6, (114, 117, 110, 101, 76, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimRel_str21, 2, (60, 61));
Clo g_heff_2ecompile_2eemit_2eprimRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimRel_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eprimRel(V v_p_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str0))) {
    heff_drop(v_p_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str1)});
  } else {
    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str2))) {
      heff_drop(v_p_240);
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str3)});
    } else {
      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str4))) {
        heff_drop(v_p_240);
        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str5)});
      } else {
        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str6))) {
          heff_drop(v_p_240);
          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str7)});
        } else {
          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str8))) {
            heff_drop(v_p_240);
            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str9)});
          } else {
            if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str10))) {
              heff_drop(v_p_240);
              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str11)});
            } else {
              if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str12))) {
                heff_drop(v_p_240);
                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str13)});
              } else {
                if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str14))) {
                  heff_drop(v_p_240);
                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str15)});
                } else {
                  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str16))) {
                    heff_drop(v_p_240);
                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str17)});
                  } else {
                    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str18))) {
                      heff_drop(v_p_240);
                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str19)});
                    } else {
                      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2eemit_2eprimRel_str20))) {
                        heff_drop(v_p_240);
                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eprimRel_str21)});
                      } else {
                        V v_t_2412 = (g_heff_2eelab_2efixed_2efixedPrimOf(v_p_240));
                        return (g_prelude_2emaybe_24s1822328499x1781525065(NTAG(TAG_Nothing), v_t_2412));
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2eemit_2eprimRel_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eprimRel(a[0]);
}
Clo g_heff_2ecompile_2eemit_2earmNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmNamed_entry, 2, 0};

V g_heff_2ecompile_2eemit_2earmNamed(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c(heff_dup(v_t2_244), heff_dup(v_t_240))) {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          heff_drop(v_t_240);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_b_246)});
        }
        case TAG_Cons: {
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_vs_245);
        }
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2earmNamed_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2earmNamed(a[0], a[1]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2econdShaped_str0, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdShaped_str1, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdShaped_str2, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2econdShaped_str3, 5, (70, 97, 108, 115, 101));
Clo g_heff_2ecompile_2eemit_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2econdShaped_entry, 1, 0};

V g_heff_2ecompile_2eemit_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2414 = heff_field(v_e_240, 0);
    V v_it2_2415 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_it2_2415)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(v_t_2414), ((V)&g_heff_2ecompile_2eemit_2econdShaped_str0))) {
        heff_drop(v_t_2414);
        return NTAG(TAG_True);
      } else {
        return heff_strEq(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2econdShaped_str1));
      }
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2415, 0ULL, 2);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it2_2415);
    }
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 2ULL, 2);
    V v_t_2421 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2420));
    V v_it_2427;
    if (heff_intEq_c(v_t_2421, MK_INT(2LL))) {
      V v_t_2423 = (g_heff_2ecompile_2eemit_2earmNamed(((V)&g_heff_2ecompile_2eemit_2econdShaped_str2), v_arms_2420));
      switch (heff_tag_of(v_t_2423)) {
      case TAG_Nothing: {
        heff_drop(v_arms_2420);
        heff_drop_cell(v_ru_24e_240_24EMatch, 2);
        v_it_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2424 = heff_field(v_t_2423, 0);
        V v_ru_24t_2423_24Just = heff_take_reuse_n(v_t_2423, 1ULL, 1);
        V v_t_2425 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2econdShaped_str3); V a_1 = v_arms_2420; V r_ = (g_heff_2ecompile_2eemit_2earmNamed(a_0, a_1)); heff_drop(v_arms_2420); r_; });
        switch (heff_tag_of(v_t_2425)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24e_240_24EMatch, 2);
          heff_drop(v_t_2424);
          heff_drop_cell(v_ru_24t_2423_24Just, 1);
          v_it_2427 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2426 = heff_field(v_t_2425, 0);
          heff_take_n(v_t_2425, 1ULL, 1);
          v_it_2427 = heff_tag_at_n(v_ru_24t_2423_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){v_t_2424, v_f_2426})});
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        break;
      }
      default: heff_nomatch(v_t_2423);
      }
    } else {
      heff_drop(v_arms_2420);
      heff_drop_cell(v_ru_24e_240_24EMatch, 2);
      v_it_2427 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2427)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_it1_2428 = heff_field(v_it_2427, 0);
      heff_take_n(v_it_2427, 1ULL, 1);
      switch (heff_tag_of(v_it1_2428)) {
      case TAG_MkPair: {
        V v_t_2429 = heff_field(v_it1_2428, 0);
        V v_f_2430 = heff_field(v_it1_2428, 1);
        heff_take_n(v_it1_2428, 3ULL, 2);
        V v_t_2431 = (g_heff_2ecompile_2eemit_2econdShaped(v_t_2429));
        switch (heff_tag_of(v_t_2431)) {
        case TAG_True: {
          V t_0 = v_f_2430;
          v_e_240 = t_0;
          goto top;
        }
        case TAG_False: {
          heff_drop(v_f_2430);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_2431);
        }
      }
      default: return heff_nomatch(v_it1_2428);
      }
    }
    default: return heff_nomatch(v_it_2427);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2433 = heff_field(v_e_240, 0);
    V v_it2_2434 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_it2_2434)) {
    case TAG_Nil: {
      heff_drop(v_p_2433);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_it22_2436 = heff_field(v_it2_2434, 1);
      heff_take_n(v_it2_2434, 2ULL, 2);
      switch (heff_tag_of(v_it22_2436)) {
      case TAG_Nil: {
        heff_drop(v_p_2433);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_it222_2438 = heff_field(v_it22_2436, 1);
        heff_take_n(v_it22_2436, 2ULL, 2);
        switch (heff_tag_of(v_it222_2438)) {
        case TAG_Nil: {
          V v_x3_2439 = (g_heff_2ecompile_2eemit_2eprimRel(v_p_2433));
          switch (heff_tag_of(v_x3_2439)) {
          case TAG_Nothing: {
            return NTAG(TAG_False);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2439, 0ULL, 1);
            return NTAG(TAG_True);
          }
          default: return heff_nomatch(v_x3_2439);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_2438, 0ULL, 2);
          heff_drop(v_p_2433);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it222_2438);
        }
      }
      default: return heff_nomatch(v_it22_2436);
      }
    }
    default: return heff_nomatch(v_it2_2434);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eemit_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2econdShaped(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ecallName_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecallName_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecallName_str2, 1, (120));
Clo g_heff_2ecompile_2eemit_2ecallName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecallName_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecallName(V v_env_240, V v_g_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get_n(v_env_240, 0, 4); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_g_241)), MK_INT(1LL));
    V v_t_244 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_g_241), v_t_243));
    V v_t_245 = (g_heff_2ecompile_2eemit_2espellAt(v_g_241, v_t_244));
    V v_s_246 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_245, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ecallName_str0)));
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_heff_2ecompile_2eemit_2ecallName_str1))) {
      heff_drop(v_s_246);
      v_t_248 = ((V)&g_heff_2ecompile_2eemit_2ecallName_str2);
    } else {
      v_t_248 = v_s_246;
    }
    return (g_heff_2ecompile_2eemit_2esafeRes(v_t_248));
  }
  case TAG_Just: {
    V v_i_249 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    heff_drop(v_g_241);
    return heff_get_n(v_i_249, 0, 4);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eemit_2ecallName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecallName(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2efixedCode_str0, 1, (45));
HEFF_STRA(g_heff_2ecompile_2eemit_2efixedCode_str1, 1, (110));
HEFF_STRA(g_heff_2ecompile_2eemit_2efixedCode_str2, 1, (110));
HEFF_STRA(g_heff_2ecompile_2eemit_2efixedCode_str3, 1, (45));
Clo g_heff_2ecompile_2eemit_2efixedCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2efixedCode_entry, 2, 0};

V g_heff_2ecompile_2eemit_2efixedCode(V v_w_240, V v_n_241) {
top: ;
  V v_t_242;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_242 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_242 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_242 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_242 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  if (heff_intEq_c(v_t_242, MK_INT(64LL))) {
    V v_s_244 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_244), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str0))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_244, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str1)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_244, ((V)&g_heff_2ecompile_2eemit_2efixedCode_str2)), MK_INT(3LL)});
    }
  } else {
    V v_s_246 = heff_intShow(v_n_241);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_246), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2efixedCode_str3))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_246, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_246, MK_INT(3LL)});
    }
  }
}
V g_heff_2ecompile_2eemit_2efixedCode_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2efixedCode(a[0], a[1]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eisUnitArgs_str0, 6, (77, 107, 85, 110, 105, 116));
Clo g_heff_2ecompile_2eemit_2eisUnitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eisUnitArgs_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eisUnitArgs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_t_2416 = heff_field(v_x11_241, 0);
      V v_x112_2417 = heff_field(v_x11_241, 1);
      switch (heff_tag_of(v_x112_2417)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Nil: {
          return heff_strEq(heff_dup(v_t_2416), ((V)&g_heff_2ecompile_2eemit_2eisUnitArgs_str0));
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x112_2417);
      }
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eisUnitArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eisUnitArgs(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2edeclsOf_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edeclsOf_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edeclsOf_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edeclsOf_str3, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edeclsOf_str4, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edeclsOf_str5, 3, (46, 97, 91));
HEFF_STRA(g_heff_2ecompile_2eemit_2edeclsOf_str6, 2, (93, 59));
Clo g_heff_2ecompile_2eemit_2edeclsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edeclsOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2edeclsOf(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_js_240);
    heff_drop(v_ind_241);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_246 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str3), heff_strAppend(v_v_244, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str4), heff_strAppend(heff_dup(v_js_240), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edeclsOf_str5), heff_strAppend(heff_intShow(heff_dup(v_i_243)), ((V)&g_heff_2ecompile_2eemit_2edeclsOf_str6))))))));
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2ecompile_2eemit_2edeclsOf(v_js_240, v_ind_241, v_rest_245, heff_intAdd(v_i_243, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2edeclsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2edeclsOf(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str1, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str3, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str5, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str7, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str8, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str12, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str13, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str14, 5, (99, 97, 115, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str15, 1, (58));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str16, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str17, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str18, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str19, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str20, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str21, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str22, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2esharedGo_str23, 1, (125));
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args);
Clo g_heff_2ecompile_2eemit_2esharedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2esharedGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2esharedGo(V v_ind_240, V v_before_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    heff_drop(v_before_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArmJs: {
      V v_it2_246 = heff_dup(heff_field(v_a_243, 1));
      V v_ls_247 = heff_dup(heff_field(v_a_243, 2));
      switch (heff_tag_of(v_it2_246)) {
      case TAG_True: {
        V v_t_2425 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), v_before_241));
        switch (heff_tag_of(v_t_2425)) {
        case TAG_True: {
          heff_drop(v_ls_247);
          V t_0 = v_ind_240;
          V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241});
          V t_2 = v_rest_244;
          v_ind_240 = t_0;
          v_before_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_False: {
          V v_t_2443 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_243), (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam1, 1, 1, (V[]){heff_dup(v_a_243)}), heff_dup(v_rest_244)))});
          V v_t_2455 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2esharedGo_lam2, 1, 1, (V[]){heff_dup(v_ind_240)}), v_t_2443));
          V v_x2_2456 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str16)));
          V v_t_2459;
          switch (heff_tag_of(v_x2_2456)) {
          case TAG_Nil: {
            v_t_2459 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str17);
            break;
          }
          case TAG_Cons: {
            V v_x_2457 = heff_field(v_x2_2456, 0);
            V v_xs_2458 = heff_field(v_x2_2456, 1);
            heff_take_n(v_x2_2456, 3ULL, 2);
            v_t_2459 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str18); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2456);
          }
          V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2459, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str19)), NTAG(TAG_Nil)});
          V v_x2_2461 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str20)));
          V v_t_2464;
          switch (heff_tag_of(v_x2_2461)) {
          case TAG_Nil: {
            v_t_2464 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str21);
            break;
          }
          case TAG_Cons: {
            V v_x_2462 = heff_field(v_x2_2461, 0);
            V v_xs_2463 = heff_field(v_x2_2461, 1);
            heff_take_n(v_x2_2461, 3ULL, 2);
            v_t_2464 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str22); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2461);
          }
          V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str23)), NTAG(TAG_Nil)});
          V v_t_2466 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_n(TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
          V v_t_2467 = (g_prelude_2e_2b_2b(v_t_2465, v_t_2466));
          V v_t_2468 = (g_prelude_2e_2b_2b(v_ls_247, v_t_2467));
          V v_t_2469 = (g_prelude_2e_2b_2b(v_t_2460, v_t_2468));
          return (g_prelude_2e_2b_2b(v_t_2455, v_t_2469));
        }
        default: return heff_nomatch(v_t_2425);
        }
      }
      case TAG_False: {
        V v_t_2470 = (g_heff_2ecompile_2eemit_2esharedGo(v_ind_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
        return (g_prelude_2e_2b_2b(v_ls_247, v_t_2470));
      }
      default: return heff_nomatch(v_it2_246);
      }
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2esharedGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2esharedGo_lam0(V self, V *args) {
  V v_b_248 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2415;
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2410 = heff_field(v_a_243, 1);
    V v_ls_2411 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    switch (heff_tag_of(v_x12_2410)) {
    case TAG_True: {
      V v_t_2414;
      switch (heff_tag_of(v_ls_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_ls_2411, 0);
        V v_xs_2413 = heff_field(v_ls_2411, 1);
        heff_take_n(v_ls_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str1); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2411);
      }
      v_x1_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_False: {
      heff_drop(v_ls_2411);
      v_x1_2415 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x12_2410);
    }
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nothing: {
    heff_drop(v_b_248);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_k_2416 = heff_field(v_x1_2415, 0);
    V v_ru_24x1_2415_24Just = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_b_248)) {
    case TAG_MkArmJs: {
      V v_x12_2418 = heff_field(v_b_248, 1);
      V v_ls_2419 = heff_field(v_b_248, 2);
      heff_take_n(v_b_248, 6ULL, 3);
      switch (heff_tag_of(v_x12_2418)) {
      case TAG_True: {
        V v_t_2422;
        switch (heff_tag_of(v_ls_2419)) {
        case TAG_Nil: {
          v_t_2422 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str2);
          break;
        }
        case TAG_Cons: {
          V v_x_2420 = heff_field(v_ls_2419, 0);
          V v_xs_2421 = heff_field(v_ls_2419, 1);
          heff_take_n(v_ls_2419, 3ULL, 2);
          v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str3); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
          break;
        }
        default: heff_nomatch(v_ls_2419);
        }
        v_t_2423 = heff_tag_at_n(v_ru_24x1_2415_24Just, TAG_Just, 1, (V[]){v_t_2422});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x1_2415_24Just, 1);
        heff_drop(v_ls_2419);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x12_2418);
      }
      break;
    }
    default: heff_nomatch(v_b_248);
    }
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nothing: {
      heff_drop(v_k_2416);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_k2_2424 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 1);
      return heff_strEq(v_k_2416, v_k2_2424);
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_lam1(V self, V *args) {
  V v_b_2426 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2433;
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2428 = heff_field(v_a_243, 1);
    V v_ls_2429 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    switch (heff_tag_of(v_x12_2428)) {
    case TAG_True: {
      V v_t_2432;
      switch (heff_tag_of(v_ls_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_ls_2429, 0);
        V v_xs_2431 = heff_field(v_ls_2429, 1);
        heff_take_n(v_ls_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str5); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2429);
      }
      v_x1_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
      break;
    }
    case TAG_False: {
      heff_drop(v_ls_2429);
      v_x1_2433 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x12_2428);
    }
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_Nothing: {
    heff_drop(v_b_2426);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_k_2434 = heff_field(v_x1_2433, 0);
    V v_ru_24x1_2433_24Just = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
    V v_t_2441;
    switch (heff_tag_of(v_b_2426)) {
    case TAG_MkArmJs: {
      V v_x12_2436 = heff_field(v_b_2426, 1);
      V v_ls_2437 = heff_field(v_b_2426, 2);
      heff_take_n(v_b_2426, 6ULL, 3);
      switch (heff_tag_of(v_x12_2436)) {
      case TAG_True: {
        V v_t_2440;
        switch (heff_tag_of(v_ls_2437)) {
        case TAG_Nil: {
          v_t_2440 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2438 = heff_field(v_ls_2437, 0);
          V v_xs_2439 = heff_field(v_ls_2437, 1);
          heff_take_n(v_ls_2437, 3ULL, 2);
          v_t_2440 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str7); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
          break;
        }
        default: heff_nomatch(v_ls_2437);
        }
        v_t_2441 = heff_tag_at_n(v_ru_24x1_2433_24Just, TAG_Just, 1, (V[]){v_t_2440});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x1_2433_24Just, 1);
        heff_drop(v_ls_2437);
        v_t_2441 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x12_2436);
      }
      break;
    }
    default: heff_nomatch(v_b_2426);
    }
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Nothing: {
      heff_drop(v_k_2434);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_k2_2442 = heff_field(v_t_2441, 0);
      heff_take_n(v_t_2441, 1ULL, 1);
      return heff_strEq(v_k_2434, v_k2_2442);
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  default: return heff_nomatch(v_x1_2433);
  }
}
V g_heff_2ecompile_2eemit_2esharedGo_lam2(V self, V *args) {
  V v_b_2444 = args[0];
  V v_ind_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2445 = (g_list_2ereplicate(heff_intAdd(v_ind_240, MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str8)));
  V v_t_2448;
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_Nil: {
    v_t_2448 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_xs_2447 = heff_field(v_x2_2445, 1);
    heff_take_n(v_x2_2445, 3ULL, 2);
    v_t_2448 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2esharedGo_str10); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2445);
  }
  V v_s_2452;
  switch (heff_tag_of(v_b_2444)) {
  case TAG_MkArmJs: {
    V v_t_2449 = heff_field(v_b_2444, 0);
    heff_take_n(v_b_2444, 1ULL, 3);
    v_s_2452 = v_t_2449;
    break;
  }
  default: heff_nomatch(v_b_2444);
  }
  V v_t_2453 = (g_heff_2ecompile_2eemit_2equoteGo(v_s_2452, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2esharedGo_str11)));
  V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str12), heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str13)));
  return heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2esharedGo_str14), heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemit_2esharedGo_str15))));
}
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str3, 10, (114, 101, 116, 117, 114, 110, 32, 36, 84, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str4, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str7, 10, (114, 101, 116, 117, 114, 110, 32, 36, 70, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str8, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str11, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str12, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str13, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str14, 11, (32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str15, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str16, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str17, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str18, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str19, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str20, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str21, 11, (32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str22, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str23, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str24, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str25, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str26, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str27, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str28, 11, (32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str29, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str30, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str31, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str32, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str33, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str34, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsReturnCond_str35, 11, (32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59));
Clo g_heff_2ecompile_2eemit_2estmtsReturnCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtsReturnCond_entry, 2, 0};

V g_heff_2ecompile_2eemit_2estmtsReturnCond(V v_ind_240, V v_c_241) {
top: ;
  switch (heff_tag_of(v_c_241)) {
  case TAG_PTrue: {
    V v_x2_242 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str0)));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str2); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str3)), NTAG(TAG_Nil)});
  }
  case TAG_PFalse: {
    V v_x2_246 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str4)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str6); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str7)), NTAG(TAG_Nil)});
  }
  case TAG_PRel: {
    V v_t_2411 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2412 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2411));
    V v_x2_2413 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str8)));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str10); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_c_2417 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2419;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2417, 1)), MK_INT(1LL))) {
      v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str11), heff_strAppend(heff_get_n(v_c_2417, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str12)));
    } else {
      v_t_2419 = heff_get_n(v_c_2417, 0, 2);
    }
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str13), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str14))));
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2412, v_t_2421);
  }
  case TAG_PNot: {
    V v_t_2423 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2424 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2423));
    V v_x2_2425 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str15)));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str17); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    V v_c_2429 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2431;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2429, 1)), MK_INT(1LL))) {
      v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str18), heff_strAppend(heff_get_n(v_c_2429, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str19)));
    } else {
      v_t_2431 = heff_get_n(v_c_2429, 0, 2);
    }
    V v_t_2432 = heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str20), heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str21))));
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2424, v_t_2433);
  }
  case TAG_PIf: {
    V v_t_2437 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2438 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2437));
    V v_x2_2439 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str22)));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str23);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str24); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    V v_c_2443 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2445;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2443, 1)), MK_INT(1LL))) {
      v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str25), heff_strAppend(heff_get_n(v_c_2443, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str26)));
    } else {
      v_t_2445 = heff_get_n(v_c_2443, 0, 2);
    }
    V v_t_2446 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str27), heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str28))));
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2438, v_t_2447);
  }
  case TAG_PSeq: {
    V v_t_2451 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_241));
    V v_t_2452 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2451));
    V v_x2_2453 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str29)));
    V v_t_2456;
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_Nil: {
      v_t_2456 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str30);
      break;
    }
    case TAG_Cons: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_xs_2455 = heff_field(v_x2_2453, 1);
      heff_take_n(v_x2_2453, 3ULL, 2);
      v_t_2456 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str31); V a_1 = v_x_2454; V a_2 = v_xs_2455; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2455); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2453);
    }
    V v_c_2457 = (g_heff_2ecompile_2eemit_2econdCode(v_c_241));
    V v_t_2459;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2457, 1)), MK_INT(1LL))) {
      v_t_2459 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str32), heff_strAppend(heff_get_n(v_c_2457, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str33)));
    } else {
      v_t_2459 = heff_get_n(v_c_2457, 0, 2);
    }
    V v_t_2460 = heff_strAppend(v_t_2456, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str34), heff_strAppend(v_t_2459, ((V)&g_heff_2ecompile_2eemit_2estmtsReturnCond_str35))));
    V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2452, v_t_2461);
  }
  default: return heff_nomatch(v_c_241);
  }
}
V g_heff_2ecompile_2eemit_2estmtsReturnCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2estmtsReturnCond(a[0], a[1]);
}

static V g_heff_2ecompile_2eemit_2ebounceDepth_val;
static int g_heff_2ecompile_2eemit_2ebounceDepth_st;
static V g_heff_2ecompile_2eemit_2ebounceDepth_init(void) {
  return MK_INT(500LL);
}
V g_heff_2ecompile_2eemit_2ebounceDepth_get(void) {
  if (g_heff_2ecompile_2eemit_2ebounceDepth_st == 2) return g_heff_2ecompile_2eemit_2ebounceDepth_val;
  if (g_heff_2ecompile_2eemit_2ebounceDepth_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2ebounceDepth_st = 1;
  g_heff_2ecompile_2eemit_2ebounceDepth_val = heff_tr(g_heff_2ecompile_2eemit_2ebounceDepth_init());
  g_heff_2ecompile_2eemit_2ebounceDepth_st = 2;
  return g_heff_2ecompile_2eemit_2ebounceDepth_val;
}
Clo g_heff_2ecompile_2eemit_2eatomGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eatomGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eatomGo(V v_c_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_c_240)), heff_dup(v_i_241))) {
    heff_drop(v_c_240);
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    V v_t_243 = (g_heff_2ecompile_2eemit_2eisWordCode(heff_strCharCode(heff_dup(v_c_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V t_0 = v_c_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_c_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_False: {
      if (heff_intEq_c(heff_strCharCode(heff_dup(v_c_240), heff_dup(v_i_241)), MK_INT(36LL))) {
        V t_0 = v_c_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_c_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_c_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
}
V g_heff_2ecompile_2eemit_2eatomGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eatomGo(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2enamedAs_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2enamedAs_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2enamedAs_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2enamedAs_str3, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2enamedAs_str4, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2enamedAs_str5, 1, (59));
Clo g_heff_2ecompile_2eemit_2enamedAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamedAs_entry, 3, 0};

V g_heff_2ecompile_2eemit_2enamedAs(V v_ind_240, V v_c_241, V v_nb_242) {
top: ;
  V v_x2_243 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2enamedAs_str0)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2enamedAs_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2enamedAs_str3), heff_strAppend(heff_dup(heff_rfield(v_nb_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2enamedAs_str4), heff_strAppend(heff_get_n(v_c_241, 0, 2), ((V)&g_heff_2ecompile_2eemit_2enamedAs_str5))))));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__pre__env, (V[]){heff_dup(heff_rfield(v_nb_242, 0)), v_t_248, heff_get_n(v_nb_242, 1, 2)});
}
V g_heff_2ecompile_2eemit_2enamedAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamedAs(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2enamed_str0, 0, (0));
Clo g_heff_2ecompile_2eemit_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamed_entry, 4, 0};

V g_heff_2ecompile_2eemit_2enamed(V v_env_240, V v_ind_241, V v_base_242, V v_c_243) {
top: ;
  V v_c_244 = heff_dup(heff_rfield(v_c_243, 0));
  if (heff_strEq_c(heff_dup(v_c_244), ((V)&g_heff_2ecompile_2eemit_2enamed_str0))) {
    heff_drop(v_c_244);
    V v_t_246 = (g_heff_2ecompile_2eemit_2ebindName(v_env_240, v_base_242));
    return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_246));
  } else {
    V v_t_247 = (g_heff_2ecompile_2eemit_2eatomGo(v_c_244, MK_INT(0LL)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_ind_241);
      heff_drop(v_base_242);
      return heff_rec_n(3, shape_js__pre__env, (V[]){heff_get_n(v_c_243, 0, 2), NTAG(TAG_Nil), v_env_240});
    }
    case TAG_False: {
      V v_t_248 = (g_heff_2ecompile_2eemit_2ebindName(v_env_240, v_base_242));
      return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_248));
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_heff_2ecompile_2eemit_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamed(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str3, 16, (114, 101, 116, 117, 114, 110, 32, 43, 43, 36, 100, 101, 112, 32, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str4, 12, (32, 63, 32, 110, 101, 119, 32, 36, 66, 110, 99, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str5, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str6, 4, (41, 32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str7, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebounceGive_str8, 2, (41, 59));
Clo g_heff_2ecompile_2eemit_2ebounceGive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebounceGive_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebounceGive(V v_ind_240, V v_f_241, V v_a_242) {
top: ;
  V v_x2_243 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str0)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str3), heff_strAppend(heff_intShow(heff_dup(g_heff_2ecompile_2eemit_2ebounceDepth_get())), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str4), heff_strAppend(heff_dup(heff_rfield(v_f_241, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str5), heff_strAppend(heff_dup(heff_rfield(v_a_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str6), heff_strAppend(heff_dup(heff_rfield(v_f_241, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebounceGive_str7), heff_strAppend(heff_dup(heff_rfield(v_a_242, 0)), ((V)&g_heff_2ecompile_2eemit_2ebounceGive_str8))))))))))));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2e_2b_2b(heff_get_n(v_a_242, 1, 3), v_t_248));
  return (g_prelude_2e_2b_2b(heff_get_n(v_f_241, 1, 3), v_t_249));
}
V g_heff_2ecompile_2eemit_2ebounceGive_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebounceGive(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249_str0, 0, (0));
Clo g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249_entry, 5, 0};

V g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249(V v_lit_240, V v_lit_241, V v_env_242, V v_ind_243, V v_base_244) {
top: ;
  if (heff_strEq_c(heff_dup(v_lit_240), ((V)&g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249_str0))) {
    V v_t_246 = (g_heff_2ecompile_2eemit_2ebindName(v_env_242, v_base_244));
    return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_243, heff_rec_n(2, shape_code__prec, (V[]){v_lit_240, v_lit_241}), v_t_246));
  } else {
    V v_t_247 = (g_heff_2ecompile_2eemit_2eatomGo(heff_dup(v_lit_240), MK_INT(0LL)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_lit_241);
      heff_drop(v_ind_243);
      heff_drop(v_base_244);
      return heff_rec_n(3, shape_js__pre__env, (V[]){v_lit_240, NTAG(TAG_Nil), v_env_242});
    }
    case TAG_False: {
      V v_t_248 = (g_heff_2ecompile_2eemit_2ebindName(v_env_242, v_base_244));
      return (g_heff_2ecompile_2eemit_2enamedAs(v_ind_243, heff_rec_n(2, shape_code__prec, (V[]){v_lit_240, v_lit_241}), v_t_248));
    }
    default: return heff_nomatch(v_t_247);
    }
  }
}
V g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str0, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str1, 5, (41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str5, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str6, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str7, 5, (36, 99, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str8, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ewrapper_str9, 2, (41, 59));
Clo g_heff_2ecompile_2eemit_2ewrapper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ewrapper_entry, 4, 0};

V g_heff_2ecompile_2eemit_2ewrapper(V v_curried_240, V v_key_241, V v_i_242, V v_js_243) {
top: ;
  V v_t_247;
  if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_242, 1)))) {
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(v_key_241, v_curried_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
  } else {
    heff_drop(v_key_241);
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_x2_248 = (g_list_2emap_24s499977176x606563528(((V)&g_heff_2ecompile_2eemit_2ewrapper_str0), ((V)&g_heff_2ecompile_2eemit_2ewrapper_str1), heff_dup(v_js_243)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2414;
    switch (heff_tag_of(v_js_243)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_js_243, 0);
      V v_xs_2413 = heff_field(v_js_243, 1);
      heff_take_n(v_js_243, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ewrapper_str5); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_js_243);
    }
    V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str6), heff_strAppend(heff_dup(heff_rfield(v_i_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str7), heff_strAppend(v_t_2411, heff_strAppend(heff_get_n(v_i_242, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ewrapper_str8), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2ewrapper_str9))))))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  }
  case TAG_False: {
    heff_drop_rec(v_i_242, 4);
    heff_drop(v_js_243);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2eemit_2ewrapper_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2ewrapper(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str1, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str2, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str5, 2, (123, 10));
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str6, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str7, 1, (125));
Clo g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  V v_x2_243 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_e_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str2)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str4); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str5), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_str7)))));
}
V g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str0, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str1, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str2, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str3, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str4, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str5, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str6, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str7, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str8, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str9, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str10, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str11, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str12, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str13, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str14, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str15, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str16, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str17, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str18, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str19, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str20, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str21, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str22, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str23, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str24, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str25, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str26, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str27, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str28, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str29, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str30, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str31, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str32, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str33, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str34, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str35, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str36, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str37, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str38, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str39, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str40, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str41, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str42, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str43, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str44, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str45, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str46, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str47, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str48, 1, (123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str49, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str50, 1, (41));
Clo g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_245 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_244, v_ind_241, v_e_242));
    V v_c_246 = heff_get_n(v_t_245, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_246), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str0))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str1), heff_strAppend(v_c_246, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str2)));
    } else {
      return v_c_246;
    }
  }
  case TAG_EGlobal: {
    V v_t_249 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2410 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_249, v_ind_241, v_e_242));
    V v_c_2411 = heff_get_n(v_t_2410, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2411), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str3))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str4), heff_strAppend(v_c_2411, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str5)));
    } else {
      return v_c_2411;
    }
  }
  case TAG_ELam: {
    V v_t_2415 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2416 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2415, v_ind_241, v_e_242));
    V v_c_2417 = heff_get_n(v_t_2416, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2417), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str6))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str7), heff_strAppend(v_c_2417, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str8)));
    } else {
      return v_c_2417;
    }
  }
  case TAG_EApp: {
    V v_f_2419 = heff_field(v_e_242, 0);
    V v_as_2420 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_f_2419, v_as_2420}));
  }
  case TAG_ELet: {
    V v_x_2421 = heff_field(v_e_242, 0);
    V v_a_2422 = heff_field(v_e_242, 1);
    V v_b_2423 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_2421, v_a_2422, v_b_2423}));
  }
  case TAG_ERecord: {
    V v_t_2425 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2426 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2425, v_ind_241, v_e_242));
    V v_c_2427 = heff_get_n(v_t_2426, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2427), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str9))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str10), heff_strAppend(v_c_2427, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str11)));
    } else {
      return v_c_2427;
    }
  }
  case TAG_EProj: {
    V v_t_2432 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2433 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2432, v_ind_241, v_e_242));
    V v_c_2434 = heff_get_n(v_t_2433, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2434), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str12))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str13), heff_strAppend(v_c_2434, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str14)));
    } else {
      return v_c_2434;
    }
  }
  case TAG_ETag: {
    V v_t_2438 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2439 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2438, v_ind_241, v_e_242));
    V v_c_2440 = heff_get_n(v_t_2439, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2440), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str15))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str16), heff_strAppend(v_c_2440, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str17)));
    } else {
      return v_c_2440;
    }
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_e_242, 0);
    V v_arms_2443 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2442, v_arms_2443}));
  }
  case TAG_EPrim: {
    V v_t_2445 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2446 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2445, v_ind_241, v_e_242));
    V v_c_2447 = heff_get_n(v_t_2446, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2447), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str18))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str19), heff_strAppend(v_c_2447, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str20)));
    } else {
      return v_c_2447;
    }
  }
  case TAG_EPrimCall: {
    V v_t_2451 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2452 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2451, v_ind_241, v_e_242));
    V v_c_2453 = heff_get_n(v_t_2452, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2453), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str21))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str22), heff_strAppend(v_c_2453, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str23)));
    } else {
      return v_c_2453;
    }
  }
  case TAG_ECall: {
    V v_g_2455 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2456 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2457 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2455), heff_rfield(v_env_240, 0)));
    switch (heff_tag_of(v_t_2457)) {
    case TAG_Nothing: {
      heff_drop(v_g_2455);
      heff_drop(v_as_2456);
      V v_t_2458 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_2459 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2458, v_ind_241, v_e_242));
      V v_c_2460 = heff_get_n(v_t_2459, 0, 2);
      if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2460), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str24))) {
        return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str25), heff_strAppend(v_c_2460, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str26)));
      } else {
        return v_c_2460;
      }
    }
    case TAG_Just: {
      V v_i_2462 = heff_field(v_t_2457, 0);
      heff_take_n(v_t_2457, 1ULL, 1);
      V v_t_2463 = heff_get_n(v_i_2462, 3, 4);
      switch (heff_tag_of(v_t_2463)) {
      case TAG_True: {
        heff_drop_tag(v_e_242, 2);
        HEFF_LAST return g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2455, v_as_2456}));
      }
      case TAG_False: {
        heff_drop(v_g_2455);
        heff_drop(v_as_2456);
        V v_t_2464 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
        V v_t_2465 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2464, v_ind_241, v_e_242));
        V v_c_2466 = heff_get_n(v_t_2465, 0, 2);
        if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2466), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str27))) {
          return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str28), heff_strAppend(v_c_2466, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str29)));
        } else {
          return v_c_2466;
        }
      }
      default: return heff_nomatch(v_t_2463);
      }
    }
    default: return heff_nomatch(v_t_2457);
    }
  }
  case TAG_EInt: {
    V v_t_2469 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2470 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2469, v_ind_241, v_e_242));
    V v_c_2471 = heff_get_n(v_t_2470, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2471), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str30))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str31), heff_strAppend(v_c_2471, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str32)));
    } else {
      return v_c_2471;
    }
  }
  case TAG_EFloat: {
    V v_t_2474 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2475 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2474, v_ind_241, v_e_242));
    V v_c_2476 = heff_get_n(v_t_2475, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2476), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str33))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str34), heff_strAppend(v_c_2476, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str35)));
    } else {
      return v_c_2476;
    }
  }
  case TAG_EStr: {
    V v_t_2479 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2480 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2479, v_ind_241, v_e_242));
    V v_c_2481 = heff_get_n(v_t_2480, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2481), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str36))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str37), heff_strAppend(v_c_2481, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str38)));
    } else {
      return v_c_2481;
    }
  }
  case TAG_EFixed: {
    V v_t_2485 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2486 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2485, v_ind_241, v_e_242));
    V v_c_2487 = heff_get_n(v_t_2486, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2487), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str39))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str40), heff_strAppend(v_c_2487, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str41)));
    } else {
      return v_c_2487;
    }
  }
  case TAG_EFloat32: {
    V v_t_2490 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2491 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2490, v_ind_241, v_e_242));
    V v_c_2492 = heff_get_n(v_t_2491, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2492), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str42))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str43), heff_strAppend(v_c_2492, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str44)));
    } else {
      return v_c_2492;
    }
  }
  case TAG_EAbandon: {
    V v_t_2494 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2495 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2494, v_ind_241, v_e_242));
    V v_c_2496 = heff_get_n(v_t_2495, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_2496), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str45))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str46), heff_strAppend(v_c_2496, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str47)));
    } else {
      return v_c_2496;
    }
  }
  case TAG_EFix: {
    V v_t_24100 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24101 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24100, v_ind_241, v_e_242));
    V v_c_24102 = heff_get_n(v_t_24101, 0, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_c_24102), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str48))) {
      return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str49), heff_strAppend(v_c_24102, ((V)&g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_str50)));
    } else {
      return v_c_24102;
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str0, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str1, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str2, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str3, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str4, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str5, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str6, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str7, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str8, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str9, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str10, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str11, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str12, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str13, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str14, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str15, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str16, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str17, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
Clo g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_entry, 5, 0};

V g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569(V v_env_240, V v_ind_241, V v_e_242, V v_p_243, V v_as_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eemit_2eprimRel(v_p_243));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_247 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_246, v_ind_241, v_e_242));
    V v_t_249;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_247, 1)), MK_INT(3LL))) {
      v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str0), heff_strAppend(heff_get_n(v_c_247, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str1)));
    } else {
      v_t_249 = heff_get_n(v_c_247, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str2))});
  }
  case TAG_Just: {
    V v_op_2410 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_as_244)) {
    case TAG_Nil: {
      heff_drop(v_op_2410);
      V v_t_2411 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_c_2412 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2411, v_ind_241, v_e_242));
      V v_t_2414;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2412, 1)), MK_INT(3LL))) {
        v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str3), heff_strAppend(heff_get_n(v_c_2412, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str4)));
      } else {
        v_t_2414 = heff_get_n(v_c_2412, 0, 2);
      }
      return heff_tag_at_n(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str5))});
    }
    case TAG_Cons: {
      V v_a_2415 = heff_field(v_as_244, 0);
      V v_it2_2416 = heff_field(v_as_244, 1);
      switch (heff_tag_of(v_it2_2416)) {
      case TAG_Nil: {
        heff_drop(v_op_2410);
        V v_t_2417 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
        V v_c_2418 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2417, v_ind_241, v_e_242));
        V v_t_2420;
        if (heff_intLt_c(heff_dup(heff_rfield(v_c_2418, 1)), MK_INT(3LL))) {
          v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str6), heff_strAppend(heff_get_n(v_c_2418, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str7)));
        } else {
          v_t_2420 = heff_get_n(v_c_2418, 0, 2);
        }
        return heff_tag_at_n(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str8))});
      }
      case TAG_Cons: {
        V v_b_2421 = heff_field(v_it2_2416, 0);
        V v_it22_2422 = heff_field(v_it2_2416, 1);
        switch (heff_tag_of(v_it22_2422)) {
        case TAG_Nil: {
          heff_drop(v_e_242);
          V v_t_2423 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
          V v_c_2424 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2423, heff_dup(v_ind_241), heff_dup(v_a_2415)));
          V v_t_2426;
          if (heff_intLt_c(heff_dup(heff_rfield(v_c_2424, 1)), MK_INT(2LL))) {
            v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str9), heff_strAppend(heff_get_n(v_c_2424, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str10)));
          } else {
            v_t_2426 = heff_get_n(v_c_2424, 0, 2);
          }
          V v_t_2427 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
          V v_c_2428 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2427, v_ind_241, heff_dup(v_b_2421)));
          V v_t_2430;
          if (heff_intLt_c(heff_dup(heff_rfield(v_c_2428, 1)), MK_INT(2LL))) {
            v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str11), heff_strAppend(heff_get_n(v_c_2428, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str12)));
          } else {
            v_t_2430 = heff_get_n(v_c_2428, 0, 2);
          }
          V v_t_2431 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str13), heff_strAppend(v_op_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str14), v_t_2430))));
          return heff_tag_at_n(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){v_t_2431});
        }
        case TAG_Cons: {
          heff_drop(v_op_2410);
          V v_t_2434 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
          V v_c_2435 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2434, v_ind_241, v_e_242));
          V v_t_2437;
          if (heff_intLt_c(heff_dup(heff_rfield(v_c_2435, 1)), MK_INT(3LL))) {
            v_t_2437 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str15), heff_strAppend(heff_get_n(v_c_2435, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str16)));
          } else {
            v_t_2437 = heff_get_n(v_c_2435, 0, 2);
          }
          return heff_tag_at_n(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){heff_strAppend(v_t_2437, ((V)&g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_str17))});
        }
        default: return heff_nomatch(v_it22_2422);
        }
      }
      default: return heff_nomatch(v_it2_2416);
      }
    }
    default: return heff_nomatch(v_as_244);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str0, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str1, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str2, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str3, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str4, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str5, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str6, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str7, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str8, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str9, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str10, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str11, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str12, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str13, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str14, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str15, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str16, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str17, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str18, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str19, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str20, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str21, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str22, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str23, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str24, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str25, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str26, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str27, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str28, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str29, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str30, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str31, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str32, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str33, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str34, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str35, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str36, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str37, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str38, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str39, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str40, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str41, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str42, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str43, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str44, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str45, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str46, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str47, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str48, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str49, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str50, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str51, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str52, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str53, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str54, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str55, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str56, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str57, 13, (46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34));
Clo g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_entry, 3, 0};

V g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_245 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_244, v_ind_241, v_e_242));
    V v_t_247;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_245, 1)), MK_INT(3LL))) {
      v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str0), heff_strAppend(heff_get_n(v_c_245, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str1)));
    } else {
      v_t_247 = heff_get_n(v_c_245, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str2))});
  }
  case TAG_EGlobal: {
    V v_t_249 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2410 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_249, v_ind_241, v_e_242));
    V v_t_2412;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2410, 1)), MK_INT(3LL))) {
      v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str3), heff_strAppend(heff_get_n(v_c_2410, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str4)));
    } else {
      v_t_2412 = heff_get_n(v_c_2410, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str5))});
  }
  case TAG_ELam: {
    V v_t_2415 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2416 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2415, v_ind_241, v_e_242));
    V v_t_2418;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2416, 1)), MK_INT(3LL))) {
      v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str6), heff_strAppend(heff_get_n(v_c_2416, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str7)));
    } else {
      v_t_2418 = heff_get_n(v_c_2416, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str8))});
  }
  case TAG_EApp: {
    V v_t_2421 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2422 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2421, v_ind_241, v_e_242));
    V v_t_2424;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2422, 1)), MK_INT(3LL))) {
      v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str9), heff_strAppend(heff_get_n(v_c_2422, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str10)));
    } else {
      v_t_2424 = heff_get_n(v_c_2422, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str11))});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_e_242, 0);
    V v_a_2426 = heff_field(v_e_242, 1);
    V v_b_2427 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2428 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2428, heff_dup(v_ind_241), v_a_2426));
    V v_a_2430 = heff_get_n(v_t_2429, 0, 2);
    V v_nb_2431 = (g_heff_2ecompile_2eemit_2ebindName(v_env_240, v_x_2425));
    return heff_tag_at_n(v_ru_24e_242_24ELet, TAG_PSeq, 3, (V[]){heff_dup(heff_rfield(v_nb_2431, 0)), v_a_2430, (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_get_n(v_nb_2431, 1, 2), v_ind_241, v_b_2427))});
  }
  case TAG_ERecord: {
    V v_t_2433 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2434 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2433, v_ind_241, v_e_242));
    V v_t_2436;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2434, 1)), MK_INT(3LL))) {
      v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str12), heff_strAppend(heff_get_n(v_c_2434, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str13)));
    } else {
      v_t_2436 = heff_get_n(v_c_2434, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str14))});
  }
  case TAG_EProj: {
    V v_t_2440 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2441 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2440, v_ind_241, v_e_242));
    V v_t_2443;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2441, 1)), MK_INT(3LL))) {
      v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str15), heff_strAppend(heff_get_n(v_c_2441, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str16)));
    } else {
      v_t_2443 = heff_get_n(v_c_2441, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str17))});
  }
  case TAG_ETag: {
    V v_t_2444 = heff_dup(heff_field(v_e_242, 0));
    V v_it2_2445 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_it2_2445)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(v_t_2444), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str18))) {
        heff_drop_rec(v_env_240, 4);
        heff_drop(v_ind_241);
        heff_drop_tag(v_e_242, 2);
        heff_drop(v_t_2444);
        return NTAG(TAG_PTrue);
      } else {
        if (heff_strEq_c(v_t_2444, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str19))) {
          heff_drop_rec(v_env_240, 4);
          heff_drop(v_ind_241);
          heff_drop_tag(v_e_242, 2);
          return NTAG(TAG_PFalse);
        } else {
          V v_t_2448 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
          V v_c_2449 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2448, v_ind_241, v_e_242));
          V v_t_2451;
          if (heff_intLt_c(heff_dup(heff_rfield(v_c_2449, 1)), MK_INT(3LL))) {
            v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str20), heff_strAppend(heff_get_n(v_c_2449, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str21)));
          } else {
            v_t_2451 = heff_get_n(v_c_2449, 0, 2);
          }
          return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str22))});
        }
      }
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2445, 0ULL, 2);
      heff_drop(v_t_2444);
      V v_t_2454 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_c_2455 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2454, v_ind_241, v_e_242));
      V v_t_2457;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2455, 1)), MK_INT(3LL))) {
        v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str23), heff_strAppend(heff_get_n(v_c_2455, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str24)));
      } else {
        v_t_2457 = heff_get_n(v_c_2455, 0, 2);
      }
      return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str25))});
    }
    default: return heff_nomatch(v_it2_2445);
    }
  }
  case TAG_EMatch: {
    V v_s_2458 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2459 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2460 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2459));
    V v_it_2466;
    if (heff_intEq_c(v_t_2460, MK_INT(2LL))) {
      V v_t_2462 = (g_heff_2ecompile_2eemit_2earmNamed(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str26), v_arms_2459));
      switch (heff_tag_of(v_t_2462)) {
      case TAG_Nothing: {
        heff_drop(v_arms_2459);
        v_it_2466 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2463 = heff_field(v_t_2462, 0);
        V v_ru_24t_2462_24Just = heff_take_reuse_n(v_t_2462, 1ULL, 1);
        V v_t_2464 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str27); V a_1 = v_arms_2459; V r_ = (g_heff_2ecompile_2eemit_2earmNamed(a_0, a_1)); heff_drop(v_arms_2459); r_; });
        switch (heff_tag_of(v_t_2464)) {
        case TAG_Nothing: {
          heff_drop(v_t_2463);
          heff_drop_cell(v_ru_24t_2462_24Just, 1);
          v_it_2466 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2465 = heff_field(v_t_2464, 0);
          heff_take_n(v_t_2464, 1ULL, 1);
          v_it_2466 = heff_tag_at_n(v_ru_24t_2462_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2463, v_f_2465})});
          break;
        }
        default: heff_nomatch(v_t_2464);
        }
        break;
      }
      default: heff_nomatch(v_t_2462);
      }
    } else {
      heff_drop(v_arms_2459);
      v_it_2466 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2466)) {
    case TAG_Nothing: {
      heff_drop(v_s_2458);
      V v_t_2467 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_c_2468 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2467, v_ind_241, v_e_242));
      V v_t_2470;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2468, 1)), MK_INT(3LL))) {
        v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str28), heff_strAppend(heff_get_n(v_c_2468, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str29)));
      } else {
        v_t_2470 = heff_get_n(v_c_2468, 0, 2);
      }
      return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2470, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str30))});
    }
    case TAG_Just: {
      V v_it1_2471 = heff_field(v_it_2466, 0);
      heff_take_n(v_it_2466, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      switch (heff_tag_of(v_it1_2471)) {
      case TAG_MkPair: {
        V v_t_2472 = heff_field(v_it1_2471, 0);
        V v_f_2473 = heff_field(v_it1_2471, 1);
        heff_take_n(v_it1_2471, 3ULL, 2);
        V v_t_2474 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2458));
        V v_t_2475 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_dup(v_env_240), heff_dup(v_ind_241), v_t_2472));
        V v_t_2476 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(v_env_240, v_ind_241, v_f_2473));
        HEFF_LAST return g_heff_2ecompile_2eemit_2econdIf(v_t_2474, v_t_2475, v_t_2476);
      }
      default: return heff_nomatch(v_it1_2471);
      }
    }
    default: return heff_nomatch(v_it_2466);
    }
  }
  case TAG_EPrim: {
    V v_t_2478 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2479 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2478, v_ind_241, v_e_242));
    V v_t_2481;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2479, 1)), MK_INT(3LL))) {
      v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str31), heff_strAppend(heff_get_n(v_c_2479, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str32)));
    } else {
      v_t_2481 = heff_get_n(v_c_2479, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str33))});
  }
  case TAG_EPrimCall: {
    V v_p_2482 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2483 = heff_dup(heff_field(v_e_242, 1));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_e_242; V a_3 = v_p_2482; V a_4 = v_as_2483; V r_ = (g_heff_2ecompile_2eemit_2epredOfPrim_24s1128989187x1161671569(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_as_2483); r_; });
  }
  case TAG_ECall: {
    V v_t_2486 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2487 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2486, v_ind_241, v_e_242));
    V v_t_2489;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2487, 1)), MK_INT(3LL))) {
      v_t_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str34), heff_strAppend(heff_get_n(v_c_2487, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str35)));
    } else {
      v_t_2489 = heff_get_n(v_c_2487, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2489, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str36))});
  }
  case TAG_EInt: {
    V v_t_2491 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2492 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2491, v_ind_241, v_e_242));
    V v_t_2494;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2492, 1)), MK_INT(3LL))) {
      v_t_2494 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str37), heff_strAppend(heff_get_n(v_c_2492, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str38)));
    } else {
      v_t_2494 = heff_get_n(v_c_2492, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2494, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str39))});
  }
  case TAG_EFloat: {
    V v_t_2496 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2497 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2496, v_ind_241, v_e_242));
    V v_t_2499;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2497, 1)), MK_INT(3LL))) {
      v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str40), heff_strAppend(heff_get_n(v_c_2497, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str41)));
    } else {
      v_t_2499 = heff_get_n(v_c_2497, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2499, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str42))});
  }
  case TAG_EStr: {
    V v_t_24101 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_24102 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24101, v_ind_241, v_e_242));
    V v_t_24104;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_24102, 1)), MK_INT(3LL))) {
      v_t_24104 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str43), heff_strAppend(heff_get_n(v_c_24102, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str44)));
    } else {
      v_t_24104 = heff_get_n(v_c_24102, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24104, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str45))});
  }
  case TAG_EFixed: {
    V v_t_24107 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_24108 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24107, v_ind_241, v_e_242));
    V v_t_24110;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_24108, 1)), MK_INT(3LL))) {
      v_t_24110 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str46), heff_strAppend(heff_get_n(v_c_24108, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str47)));
    } else {
      v_t_24110 = heff_get_n(v_c_24108, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24110, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str48))});
  }
  case TAG_EFloat32: {
    V v_t_24112 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_24113 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24112, v_ind_241, v_e_242));
    V v_t_24115;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_24113, 1)), MK_INT(3LL))) {
      v_t_24115 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str49), heff_strAppend(heff_get_n(v_c_24113, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str50)));
    } else {
      v_t_24115 = heff_get_n(v_c_24113, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24115, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str51))});
  }
  case TAG_EAbandon: {
    V v_t_24116 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_24117 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24116, v_ind_241, v_e_242));
    V v_t_24119;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_24117, 1)), MK_INT(3LL))) {
      v_t_24119 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str52), heff_strAppend(heff_get_n(v_c_24117, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str53)));
    } else {
      v_t_24119 = heff_get_n(v_c_24117, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24119, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str54))});
  }
  case TAG_EFix: {
    V v_t_24122 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_24123 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24122, v_ind_241, v_e_242));
    V v_t_24125;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_24123, 1)), MK_INT(3LL))) {
      v_t_24125 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str55), heff_strAppend(heff_get_n(v_c_24123, 0, 2), ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str56)));
    } else {
      v_t_24125 = heff_get_n(v_c_24123, 0, 2);
    }
    return heff_tag_n(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24125, ((V)&g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_str57))});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str0, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str1, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str2, 10, (32, 63, 32, 36, 84, 32, 58, 32, 36, 70));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str3, 7, (40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str4, 3, (41, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str5, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str6, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str7, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str8, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str9, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str10, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str11, 3, (32, 63, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str12, 3, (32, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str13, 7, (40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str14, 3, (41, 40, 41));
Clo g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_entry, 6, 0};

V g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430(V v_env_240, V v_ind_241, V v_e_242, V v_s_243, V v_t_244, V v_f_245) {
top: ;
  V v_t_246 = (g_heff_2ecompile_2eemit_2econdShaped(heff_dup(v_t_244)));
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_247 = (g_heff_2ecompile_2eemit_2econdShaped(heff_dup(v_f_245)));
    break;
  }
  case TAG_False: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_s_243);
    heff_drop(v_t_244);
    heff_drop(v_f_245);
    V v_c_248 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_dup(v_env_240), heff_dup(v_ind_241), heff_dup(v_e_242)));
    V v_x1_249 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_248));
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 4);
      heff_drop(v_ind_241);
      heff_drop(v_e_242);
      V v_c_2410 = (g_heff_2ecompile_2eemit_2econdCode(v_c_248));
      V v_t_2412;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2410, 1)), MK_INT(1LL))) {
        v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str0), heff_strAppend(heff_get_n(v_c_2410, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str1)));
      } else {
        v_t_2412 = heff_get_n(v_c_2410, 0, 2);
      }
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str2)), MK_INT(0LL)});
    }
    case TAG_Cons: {
      heff_take_n(v_x1_249, 0ULL, 2);
      heff_drop(v_c_248);
      V v_t_2415 = (g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, v_e_242));
      V v_code_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str3), heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str4)));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2416, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
  case TAG_False: {
    V v_c_2417 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_243));
    V v_x1_2418 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_2417));
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Nil: {
      heff_drop(v_e_242);
      V v_c_2419 = (g_heff_2ecompile_2eemit_2econdCode(v_c_2417));
      V v_t_2421;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2419, 1)), MK_INT(1LL))) {
        v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str5), heff_strAppend(heff_get_n(v_c_2419, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str6)));
      } else {
        v_t_2421 = heff_get_n(v_c_2419, 0, 2);
      }
      V v_t_2422 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
      V v_c_2423 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2422, heff_dup(v_ind_241), v_t_244));
      V v_t_2425;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2423, 1)), MK_INT(1LL))) {
        v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str7), heff_strAppend(heff_get_n(v_c_2423, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str8)));
      } else {
        v_t_2425 = heff_get_n(v_c_2423, 0, 2);
      }
      V v_t_2426 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_c_2427 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2426, v_ind_241, v_f_245));
      V v_t_2429;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2427, 1)), MK_INT(1LL))) {
        v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str9), heff_strAppend(heff_get_n(v_c_2427, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str10)));
      } else {
        v_t_2429 = heff_get_n(v_c_2427, 0, 2);
      }
      V v_t_2430 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str11), heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str12), v_t_2429))));
      return heff_rec_n(2, shape_code__prec, (V[]){v_t_2430, MK_INT(0LL)});
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2418, 0ULL, 2);
      heff_drop(v_t_244);
      heff_drop(v_f_245);
      heff_drop(v_c_2417);
      V v_t_2433 = (g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, v_e_242));
      V v_code_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str13), heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_str14)));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2434, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x1_2418);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str2, 1, (120));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str3, 9, (117, 110, 100, 101, 102, 105, 110, 101, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str4, 2, (36, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str5, 2, (40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str6, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str7, 5, (41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str8, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str10, 7, (36, 102, 111, 114, 99, 101, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str11, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str12, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str13, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str14, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str15, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str16, 4, (36, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str17, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str18, 7, (40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str19, 3, (41, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str20, 4, (36, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str21, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str22, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str23, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str24, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str25, 2, (58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str26, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str27, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str28, 2, (123, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str29, 2, (32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str30, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str31, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str32, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str33, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str34, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str35, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str36, 1, (91));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str37, 1, (93));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str38, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str39, 2, (36, 84));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str40, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str41, 2, (36, 70));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str42, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str43, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str44, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str45, 5, (123, 32, 36, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str46, 9, (44, 32, 97, 58, 32, 91, 93, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str47, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str48, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str49, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str50, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str51, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str52, 5, (123, 32, 36, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str53, 6, (44, 32, 97, 58, 32, 91));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str54, 3, (93, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str55, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str56, 5, (70, 97, 108, 115, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str57, 7, (40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str58, 3, (41, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str59, 4, (36, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str60, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str61, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str62, 2, (36, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str63, 7, (36, 102, 111, 114, 99, 101, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str64, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str65, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str66, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str67, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str68, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str69, 4, (36, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str70, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str71, 1, (45));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str72, 1, (110));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str73, 1, (110));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str74, 1, (45));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str75, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str76, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str77, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str78, 12, (77, 97, 116, 104, 46, 102, 114, 111, 117, 110, 100, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str79, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str80, 10, (36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str81, 10, (36, 97, 98, 97, 110, 100, 111, 110, 40, 41));
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam1(V self, V *args);
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam2(V self, V *args);
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam3(V self, V *args);
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam4(V self, V *args);
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam5(V self, V *args);
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam6(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ind_241);
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_x_243)), MK_INT(1LL));
    V v_t_245 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x_243), v_t_244));
    V v_t_246 = (g_heff_2ecompile_2eemit_2espellAt(heff_dup(v_x_243), v_t_245));
    V v_s_247 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_246, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str0)));
    V v_t_249;
    if (heff_strEq_c(heff_dup(v_s_247), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str1))) {
      heff_drop(v_s_247);
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str2);
    } else {
      v_t_249 = v_s_247;
    }
    V v_d_2410 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_249));
    V v_x2_2411 = ({ V a_0 = v_x_243; V b_1 = heff_get_n(v_env_240, 1, 4); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_code_2413;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nothing: {
      v_code_2413 = v_d_2410;
      break;
    }
    case TAG_Just: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      heff_take_n(v_x2_2411, 1ULL, 1);
      heff_drop(v_d_2410);
      v_code_2413 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2413, MK_INT(3LL)});
  }
  case TAG_EGlobal: {
    V v_g_2414 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ind_241);
    V v_t_2415 = ({ V a_0 = v_g_2414; V b_1 = heff_get_n(v_env_240, 0, 4); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_code_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      v_code_2419 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str3);
      break;
    }
    case TAG_Just: {
      V v_i_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_2416, 1)))) {
        v_code_2419 = heff_strAppend(heff_get_n(v_i_2416, 0, 4), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str4));
      } else {
        V v_t_2418 = heff_take_field(v_i_2416, 2);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          v_code_2419 = heff_strAppend(heff_get_n(v_i_2416, 0, 4), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str5));
          break;
        }
        case TAG_False: {
          v_code_2419 = heff_get_n(v_i_2416, 0, 4);
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2419, MK_INT(3LL)});
  }
  case TAG_ELam: {
    V v_xs_2420 = heff_field(v_e_242, 0);
    V v_b_2421 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2422 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_env_240});
    V v_rb_2423 = (g_list_2efoldl_24s1430359702x555202731(v_t_2422, v_xs_2420));
    V v_x2_2424 = (g_list_2emap_24s499977176x606563528(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str6), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str7), heff_take_field(v_rb_2423, 0)));
    V v_t_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str9); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2428 = heff_strAppend(v_t_2427, (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(heff_get_n(v_rb_2423, 1, 2), v_ind_241, v_b_2421)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_2428, MK_INT(0LL)});
  }
  case TAG_EApp: {
    V v_f_2429 = heff_field(v_e_242, 0);
    V v_as_2430 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2431 = (g_heff_2ecompile_2eemit_2eisUnitArgs(v_as_2430));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_as_2430);
      V v_t_2432 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_2433 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2432, v_ind_241, v_f_2429));
      V v_code_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str10), heff_strAppend(heff_get_n(v_t_2433, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str11)));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_2434, MK_INT(3LL)});
    }
    case TAG_False: {
      V v_t_2435 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
      V v_t_2436 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2435, heff_dup(v_ind_241), v_f_2429));
      return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam0, 2, 2, (V[]){v_env_240, v_ind_241}); V a_1 = v_t_2436; V a_2 = v_as_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_as_2430); r_; });
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  case TAG_ELet: {
    V v_x_2445 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2446 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2447 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2448 = (g_heff_2ecompile_2eemit_2etailApp(v_e_242));
    V v_b_2453;
    switch (heff_tag_of(v_t_2448)) {
    case TAG_True: {
      heff_drop_tag(v_e_242, 3);
      v_b_2453 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_t_2449 = (g_heff_2ecompile_2eemit_2etailGlobals(v_e_242));
      v_b_2453 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam1, 1, 1, (V[]){heff_dup(v_env_240)}); V a_1 = v_t_2449; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2449); r_; });
      break;
    }
    default: heff_nomatch(v_t_2448);
    }
    V v_t_2454 = (g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, heff_tag_n(TAG_ELet, 3, (V[]){v_x_2445, v_a_2446, v_b_2447})));
    V v_c_2455 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str18), heff_strAppend(v_t_2454, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str19)));
    V v_code_2456;
    switch (heff_tag_of(v_b_2453)) {
    case TAG_True: {
      v_code_2456 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str20), heff_strAppend(v_c_2455, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str21)));
      break;
    }
    case TAG_False: {
      v_code_2456 = v_c_2455;
      break;
    }
    default: heff_nomatch(v_b_2453);
    }
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2456, MK_INT(3LL)});
  }
  case TAG_ERecord: {
    V v_fs_2457 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_x2_2466 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam2, 1, 2, (V[]){v_env_240, v_ind_241}), v_fs_2457));
    V v_t_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str26);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_t_2469 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str27); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    V v_code_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str28), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str29)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2470, MK_INT(3LL)});
  }
  case TAG_EProj: {
    V v_e2_2471 = heff_field(v_e_242, 0);
    V v_l_2472 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 3);
    V v_t_2474 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_c_2475 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2474, v_ind_241, v_e2_2471));
    V v_t_2477;
    if (heff_intLt_c(heff_dup(heff_rfield(v_c_2475, 1)), MK_INT(3LL))) {
      v_t_2477 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str30), heff_strAppend(heff_get_n(v_c_2475, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str31)));
    } else {
      v_t_2477 = heff_get_n(v_c_2475, 0, 2);
    }
    V v_t_2478 = (g_heff_2ecompile_2eemit_2eisIdent(heff_dup(v_l_2472)));
    V v_t_2481;
    switch (heff_tag_of(v_t_2478)) {
    case TAG_True: {
      v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str32), v_l_2472);
      break;
    }
    case TAG_False: {
      V v_t_2479 = (g_heff_2ecompile_2eemit_2equoteGo(v_l_2472, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str33)));
      V v_t_2480 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str34), heff_strAppend(v_t_2479, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str35)));
      v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str36), heff_strAppend(v_t_2480, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str37)));
      break;
    }
    default: heff_nomatch(v_t_2478);
    }
    V v_code_2482 = heff_strAppend(v_t_2477, v_t_2481);
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_2482, MK_INT(3LL)});
  }
  case TAG_ETag: {
    V v_t_2483 = heff_field(v_e_242, 0);
    V v_it2_2484 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_it2_2484)) {
    case TAG_Nil: {
      heff_drop_rec(v_env_240, 4);
      heff_drop(v_ind_241);
      if (heff_strEq_c(heff_dup(v_t_2483), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str38))) {
        heff_drop(v_t_2483);
        return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str39), MK_INT(3LL)});
      } else {
        if (heff_strEq_c(heff_dup(v_t_2483), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str40))) {
          heff_drop(v_t_2483);
          return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str41), MK_INT(3LL)});
        } else {
          V v_t_2487 = (g_heff_2ecompile_2eemit_2equoteGo(v_t_2483, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str42)));
          V v_t_2488 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str43), heff_strAppend(v_t_2487, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str44)));
          V v_code_2489 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str45), heff_strAppend(v_t_2488, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str46)));
          return heff_rec_n(2, shape_code__prec, (V[]){v_code_2489, MK_INT(3LL)});
        }
      }
    }
    case TAG_Cons: {
      V v_t_2492 = (g_heff_2ecompile_2eemit_2equoteGo(v_t_2483, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str47)));
      V v_t_2493 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str48), heff_strAppend(v_t_2492, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str49)));
      V v_x2_2497 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam3, 1, 2, (V[]){v_env_240, v_ind_241}), v_it2_2484));
      V v_t_24100;
      switch (heff_tag_of(v_x2_2497)) {
      case TAG_Nil: {
        v_t_24100 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str50);
        break;
      }
      case TAG_Cons: {
        V v_x_2498 = heff_field(v_x2_2497, 0);
        V v_xs_2499 = heff_field(v_x2_2497, 1);
        heff_take_n(v_x2_2497, 3ULL, 2);
        v_t_24100 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str51); V a_1 = v_x_2498; V a_2 = v_xs_2499; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2499); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2497);
      }
      V v_code_24101 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str52), heff_strAppend(v_t_2493, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str53), heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str54)))));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_24101, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_it2_2484);
    }
  }
  case TAG_EMatch: {
    V v_s_24102 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_24103 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24104 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_24103));
    V v_it_24110;
    if (heff_intEq_c(v_t_24104, MK_INT(2LL))) {
      V v_t_24106 = (g_heff_2ecompile_2eemit_2earmNamed(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str55), v_arms_24103));
      switch (heff_tag_of(v_t_24106)) {
      case TAG_Nothing: {
        v_it_24110 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_24107 = heff_field(v_t_24106, 0);
        V v_ru_24t_24106_24Just = heff_take_reuse_n(v_t_24106, 1ULL, 1);
        V v_t_24108 = (g_heff_2ecompile_2eemit_2earmNamed(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str56), v_arms_24103));
        switch (heff_tag_of(v_t_24108)) {
        case TAG_Nothing: {
          heff_drop(v_t_24107);
          heff_drop_cell(v_ru_24t_24106_24Just, 1);
          v_it_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_24109 = heff_field(v_t_24108, 0);
          heff_take_n(v_t_24108, 1ULL, 1);
          v_it_24110 = heff_tag_at_n(v_ru_24t_24106_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24107, v_f_24109})});
          break;
        }
        default: heff_nomatch(v_t_24108);
        }
        break;
      }
      default: heff_nomatch(v_t_24106);
      }
    } else {
      v_it_24110 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_24110)) {
    case TAG_Nothing: {
      V v_t_24111 = (g_heff_2ecompile_2eemit_2etailApp(v_e_242));
      V v_b_24116;
      switch (heff_tag_of(v_t_24111)) {
      case TAG_True: {
        heff_drop_tag(v_e_242, 2);
        v_b_24116 = NTAG(TAG_True);
        break;
      }
      case TAG_False: {
        V v_t_24112 = (g_heff_2ecompile_2eemit_2etailGlobals(v_e_242));
        v_b_24116 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam4, 1, 1, (V[]){heff_dup(v_env_240)}); V a_1 = v_t_24112; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_24112); r_; });
        break;
      }
      default: heff_nomatch(v_t_24111);
      }
      V v_t_24117 = (g_heff_2ecompile_2eemit_2eblockF_24s965157993x832101197(v_env_240, v_ind_241, heff_tag_n(TAG_EMatch, 2, (V[]){v_s_24102, v_arms_24103})));
      V v_c_24118 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str57), heff_strAppend(v_t_24117, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str58)));
      V v_code_24119;
      switch (heff_tag_of(v_b_24116)) {
      case TAG_True: {
        v_code_24119 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str59), heff_strAppend(v_c_24118, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str60)));
        break;
      }
      case TAG_False: {
        v_code_24119 = v_c_24118;
        break;
      }
      default: heff_nomatch(v_b_24116);
      }
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_24119, MK_INT(3LL)});
    }
    case TAG_Just: {
      V v_it1_24120 = heff_field(v_it_24110, 0);
      heff_take_n(v_it_24110, 1ULL, 1);
      heff_drop(v_arms_24103);
      switch (heff_tag_of(v_it1_24120)) {
      case TAG_MkPair: {
        V v_t_24121 = heff_field(v_it1_24120, 0);
        V v_f_24122 = heff_field(v_it1_24120, 1);
        heff_take_n(v_it1_24120, 3ULL, 2);
        return (g_heff_2ecompile_2eemit_2eexprTest_24s149395014x1109166430(v_env_240, v_ind_241, v_e_242, v_s_24102, v_t_24121, v_f_24122));
      }
      default: return heff_nomatch(v_it1_24120);
      }
    }
    default: return heff_nomatch(v_it_24110);
    }
  }
  case TAG_EPrim: {
    V v_p_24123 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    V v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str61), heff_strAppend(v_p_24123, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str62)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_24124, MK_INT(3LL)});
  }
  case TAG_EPrimCall: {
    V v_p_24125 = heff_field(v_e_242, 0);
    V v_as_24126 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24129 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam5, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_24126));
    return (g_heff_2ecompile_2eemit_2eprimCall(v_p_24125, v_t_24129));
  }
  case TAG_ECall: {
    V v_g_24130 = heff_field(v_e_242, 0);
    V v_as_24131 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24132 = (g_heff_2ecompile_2eemit_2eisUnitArgs(v_as_24131));
    switch (heff_tag_of(v_t_24132)) {
    case TAG_True: {
      heff_drop(v_ind_241);
      heff_drop(v_as_24131);
      V v_t_24133 = (g_heff_2ecompile_2eemit_2ecallName(v_env_240, v_g_24130));
      V v_code_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str63), heff_strAppend(v_t_24133, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str64)));
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_24134, MK_INT(3LL)});
    }
    case TAG_False: {
      V v_t_24135 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_24130), heff_rfield(v_env_240, 0)));
      V v_b_24137;
      switch (heff_tag_of(v_t_24135)) {
      case TAG_Nothing: {
        v_b_24137 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_i_24136 = heff_field(v_t_24135, 0);
        heff_take_n(v_t_24135, 1ULL, 1);
        v_b_24137 = heff_get_n(v_i_24136, 3, 4);
        break;
      }
      default: heff_nomatch(v_t_24135);
      }
      V v_t_24138 = (g_heff_2ecompile_2eemit_2ecallName(heff_dup(v_env_240), v_g_24130));
      V v_x2_24142 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam6, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_24131));
      V v_t_24145;
      switch (heff_tag_of(v_x2_24142)) {
      case TAG_Nil: {
        v_t_24145 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str65);
        break;
      }
      case TAG_Cons: {
        V v_x_24143 = heff_field(v_x2_24142, 0);
        V v_xs_24144 = heff_field(v_x2_24142, 1);
        heff_take_n(v_x2_24142, 3ULL, 2);
        v_t_24145 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str66); V a_1 = v_x_24143; V a_2 = v_xs_24144; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24144); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24142);
      }
      V v_c_24146 = heff_strAppend(v_t_24138, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str67), heff_strAppend(v_t_24145, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str68))));
      V v_code_24147;
      switch (heff_tag_of(v_b_24137)) {
      case TAG_True: {
        v_code_24147 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str69), heff_strAppend(v_c_24146, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str70)));
        break;
      }
      case TAG_False: {
        v_code_24147 = v_c_24146;
        break;
      }
      default: heff_nomatch(v_b_24137);
      }
      return heff_rec_n(2, shape_code__prec, (V[]){v_code_24147, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_t_24132);
    }
  }
  case TAG_EInt: {
    V v_i_24148 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    V v_s_24149 = heff_intShow(v_i_24148);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_24149), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str71))) {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_24149, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str72)), MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){heff_strAppend(v_s_24149, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str73)), MK_INT(3LL)});
    }
  }
  case TAG_EFloat: {
    V v_x_24151 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    V v_s_24152 = heff_floatShow(v_x_24151);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_24152), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str74))) {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_24152, MK_INT(2LL)});
    } else {
      return heff_rec_n(2, shape_code__prec, (V[]){v_s_24152, MK_INT(3LL)});
    }
  }
  case TAG_EStr: {
    V v_s_24154 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    V v_t_24155 = (g_heff_2ecompile_2eemit_2equoteGo(v_s_24154, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str75)));
    V v_code_24156 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str76), heff_strAppend(v_t_24155, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str77)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_code_24156, MK_INT(3LL)});
  }
  case TAG_EFixed: {
    V v_w_24157 = heff_field(v_e_242, 0);
    V v_n_24158 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    return ({ V a_0 = v_w_24157; V a_1 = v_n_24158; V r_ = (g_heff_2ecompile_2eemit_2efixedCode(a_0, a_1)); heff_drop(v_w_24157); r_; });
  }
  case TAG_EFloat32: {
    V v_x_24159 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    V v_t_24160 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str78), heff_strAppend(heff_floatShow(v_x_24159), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str79)));
    return heff_rec_n(2, shape_code__prec, (V[]){v_t_24160, MK_INT(3LL)});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str80), MK_INT(3LL)});
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop_rec(v_env_240, 4);
    heff_drop(v_ind_241);
    return heff_rec_n(2, shape_code__prec, (V[]){((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str81), MK_INT(3LL)});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam0(V self, V *args) {
  V v_c_2437 = args[0];
  V v_a_2438 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440;
  if (heff_intLt_c(heff_dup(heff_rfield(v_c_2437, 1)), MK_INT(3LL))) {
    v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str12), heff_strAppend(heff_get_n(v_c_2437, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str13)));
  } else {
    v_t_2440 = heff_get_n(v_c_2437, 0, 2);
  }
  V v_t_2441 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2442 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2441, v_ind_241, v_a_2438));
  V v_c_2443 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str14), heff_strAppend(heff_get_n(v_t_2442, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str15))));
  V v_code_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str16), heff_strAppend(v_c_2443, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str17)));
  return heff_rec_n(2, shape_code__prec, (V[]){v_code_2444, MK_INT(3LL)});
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam1(V self, V *args) {
  V v_g_2450 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = ({ V a_0 = v_g_2450; V b_1 = heff_get_n(v_env_240, 0, 4); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2451)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_i_2452 = heff_field(v_t_2451, 0);
    heff_take_n(v_t_2451, 1ULL, 1);
    return heff_get_n(v_i_2452, 3, 4);
  }
  default: return heff_nomatch(v_t_2451);
  }
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam2(V self, V *args) {
  V v_p_2458 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2458)) {
  case TAG_MkPair: {
    V v_l_2459 = heff_field(v_p_2458, 0);
    V v_e2_2460 = heff_field(v_p_2458, 1);
    heff_take_n(v_p_2458, 3ULL, 2);
    V v_t_2461 = (g_heff_2ecompile_2eemit_2eisIdent(heff_dup(v_l_2459)));
    V v_t_2463;
    switch (heff_tag_of(v_t_2461)) {
    case TAG_True: {
      v_t_2463 = v_l_2459;
      break;
    }
    case TAG_False: {
      V v_t_2462 = (g_heff_2ecompile_2eemit_2equoteGo(v_l_2459, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str22)));
      v_t_2463 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str23), heff_strAppend(v_t_2462, ((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str24)));
      break;
    }
    default: heff_nomatch(v_t_2461);
    }
    V v_t_2464 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2465 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2464, v_ind_241, v_e2_2460));
    return heff_strAppend(v_t_2463, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_str25), heff_get_n(v_t_2465, 0, 2)));
  }
  default: return heff_nomatch(v_p_2458);
  }
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam3(V self, V *args) {
  V v_a_2494 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2495 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2496 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2495, v_ind_241, v_a_2494));
  return heff_get_n(v_t_2496, 0, 2);
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam4(V self, V *args) {
  V v_g_24113 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24114 = ({ V a_0 = v_g_24113; V b_1 = heff_get_n(v_env_240, 0, 4); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_24114)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_i_24115 = heff_field(v_t_24114, 0);
    heff_take_n(v_t_24114, 1ULL, 1);
    return heff_get_n(v_i_24115, 3, 4);
  }
  default: return heff_nomatch(v_t_24114);
  }
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam5(V self, V *args) {
  V v_a_24127 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24128 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  return (g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24128, v_ind_241, v_a_24127));
}
V g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276_lam6(V self, V *args) {
  V v_a_24139 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24140 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_24141 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24140, v_ind_241, v_a_24139));
  return heff_get_n(v_t_24141, 0, 2);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15, 6, (36, 102, 111, 114, 99, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16, 1, (102));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17, 1, (97));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23, 1, (102));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24, 1, (97));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str37, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str38, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str39, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str40, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str41, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str42, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str43, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str44, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str45, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str46, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str47, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str48, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str49, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str50, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str51, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str52, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str53, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str54, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str55, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str56, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str57, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str58, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str59, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str60, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str61, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str62, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str63, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str64, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str65, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str66, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str67, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str68, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str69, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str70, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str71, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str72, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str73, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str74, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str75, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str76, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str77, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str78, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str79, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str80, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str81, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str82, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str83, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str84, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str85, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str86, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str87, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str88, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str89, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str90, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str91, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str92, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str93, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str94, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str95, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str96, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str97, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str98, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str99, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str100, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str101, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str102, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str103, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str104, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str105, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str106, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str107, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str108, 1, (59));
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_249 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_248, v_ind_241, v_e_242));
    V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str3), heff_strAppend(heff_get_n(v_t_249, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str4))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    V v_x2_2412 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str5)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str7); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2416 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2417 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2416, v_ind_241, v_e_242));
    V v_t_2418 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str8), heff_strAppend(heff_get_n(v_t_2417, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str9))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_x2_2421 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str10)));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str12); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2426 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2425, v_ind_241, v_e_242));
    V v_t_2427 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str13), heff_strAppend(heff_get_n(v_t_2426, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str14))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
  }
  case TAG_EApp: {
    V v_f_2428 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2429 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2430 = (g_heff_2ecompile_2eemit_2eisUnitArgs(v_as_2429));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop_tag(v_e_242, 2);
      heff_drop(v_as_2429);
      V v_t_2431 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
      V v_ac_2432 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2431, heff_dup(v_ind_241), v_f_2428));
      V v_f_2433 = (g_heff_2ecompile_2eemit_2enamed_24s983678333x2041730249(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str15), MK_INT(3LL), v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str16)));
      V v_t_2434 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_2433, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str17), v_ac_2432));
      HEFF_LAST return g_heff_2ecompile_2eemit_2ebounceGive(v_ind_241, v_f_2433, v_t_2434);
    }
    case TAG_False: {
      V v_it_2437;
      switch (heff_tag_of(v_as_2429)) {
      case TAG_Nil: {
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2435 = heff_field(v_as_2429, 0);
        V v_rest_2436 = heff_field(v_as_2429, 1);
        heff_take_n(v_as_2429, 3ULL, 2);
        v_it_2437 = heff_tag_n(TAG_Just, 1, (V[]){(g_heff_2ecompile_2eemit_2eunsnocGo(v_rest_2436, v_x_2435))});
        break;
      }
      default: heff_nomatch(v_as_2429);
      }
      switch (heff_tag_of(v_it_2437)) {
      case TAG_Nothing: {
        heff_drop(v_f_2428);
        V v_x2_2438 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str18)));
        V v_t_2441;
        switch (heff_tag_of(v_x2_2438)) {
        case TAG_Nil: {
          v_t_2441 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str19);
          break;
        }
        case TAG_Cons: {
          V v_x_2439 = heff_field(v_x2_2438, 0);
          V v_xs_2440 = heff_field(v_x2_2438, 1);
          heff_take_n(v_x2_2438, 3ULL, 2);
          v_t_2441 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str20); V a_1 = v_x_2439; V a_2 = v_xs_2440; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2438);
        }
        V v_t_2442 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
        V v_t_2443 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2442, v_ind_241, v_e_242));
        V v_t_2444 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str21), heff_strAppend(heff_get_n(v_t_2443, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str22))));
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
      }
      case TAG_Just: {
        V v_it1_2445 = heff_field(v_it_2437, 0);
        heff_take_n(v_it_2437, 1ULL, 1);
        heff_drop_tag(v_e_242, 2);
        switch (heff_tag_of(v_it1_2445)) {
        case TAG_MkPair: {
          V v_ini_2446 = heff_field(v_it1_2445, 0);
          V v_a_2447 = heff_field(v_it1_2445, 1);
          V v_ru_24it1_2445_24MkPair = heff_take_reuse_n(v_it1_2445, 3ULL, 2);
          V v_fc_2452;
          switch (heff_tag_of(v_ini_2446)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it1_2445_24MkPair, 2);
            V v_t_2448 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
            v_fc_2452 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2448, heff_dup(v_ind_241), v_f_2428));
            break;
          }
          case TAG_Cons: {
            V v_t_2451 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
            v_fc_2452 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2451, heff_dup(v_ind_241), heff_tag_at_n(v_ru_24it1_2445_24MkPair, TAG_EApp, 2, (V[]){v_f_2428, v_ini_2446})));
            break;
          }
          default: heff_nomatch(v_ini_2446);
          }
          V v_t_2453 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
          V v_ac_2454 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2453, heff_dup(v_ind_241), v_a_2447));
          V v_f_2455 = (g_heff_2ecompile_2eemit_2enamed(v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str23), v_fc_2452));
          V v_t_2456 = (g_heff_2ecompile_2eemit_2enamed(heff_dup(heff_rfield(v_f_2455, 2)), heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str24), v_ac_2454));
          HEFF_LAST return g_heff_2ecompile_2eemit_2ebounceGive(v_ind_241, v_f_2455, v_t_2456);
        }
        default: return heff_nomatch(v_it1_2445);
        }
      }
      default: return heff_nomatch(v_it_2437);
      }
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_ELet: {
    V v_x2_2460 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str25)));
    V v_t_2463;
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_Nil: {
      v_t_2463 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str26);
      break;
    }
    case TAG_Cons: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_xs_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      v_t_2463 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str27); V a_1 = v_x_2461; V a_2 = v_xs_2462; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2462); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2460);
    }
    V v_t_2464 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2465 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2464, v_ind_241, v_e_242));
    V v_t_2466 = heff_strAppend(v_t_2463, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str28), heff_strAppend(heff_get_n(v_t_2465, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str29))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
  }
  case TAG_ERecord: {
    V v_x2_2468 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str30)));
    V v_t_2471;
    switch (heff_tag_of(v_x2_2468)) {
    case TAG_Nil: {
      v_t_2471 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2469 = heff_field(v_x2_2468, 0);
      V v_xs_2470 = heff_field(v_x2_2468, 1);
      heff_take_n(v_x2_2468, 3ULL, 2);
      v_t_2471 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str32); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2468);
    }
    V v_t_2472 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2473 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2472, v_ind_241, v_e_242));
    V v_t_2474 = heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str33), heff_strAppend(heff_get_n(v_t_2473, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str34))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
  }
  case TAG_EProj: {
    V v_x2_2478 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str35)));
    V v_t_2481;
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_Nil: {
      v_t_2481 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str36);
      break;
    }
    case TAG_Cons: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_xs_2480 = heff_field(v_x2_2478, 1);
      heff_take_n(v_x2_2478, 3ULL, 2);
      v_t_2481 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str37); V a_1 = v_x_2479; V a_2 = v_xs_2480; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2480); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2478);
    }
    V v_t_2482 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2483 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2482, v_ind_241, v_e_242));
    V v_t_2484 = heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str38), heff_strAppend(heff_get_n(v_t_2483, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str39))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
  }
  case TAG_ETag: {
    V v_x2_2487 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str40)));
    V v_t_2490;
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_Nil: {
      v_t_2490 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str41);
      break;
    }
    case TAG_Cons: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_xs_2489 = heff_field(v_x2_2487, 1);
      heff_take_n(v_x2_2487, 3ULL, 2);
      v_t_2490 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str42); V a_1 = v_x_2488; V a_2 = v_xs_2489; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2489); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2487);
    }
    V v_t_2491 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2492 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2491, v_ind_241, v_e_242));
    V v_t_2493 = heff_strAppend(v_t_2490, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str43), heff_strAppend(heff_get_n(v_t_2492, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str44))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2493, NTAG(TAG_Nil)});
  }
  case TAG_EMatch: {
    V v_x2_2496 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str45)));
    V v_t_2499;
    switch (heff_tag_of(v_x2_2496)) {
    case TAG_Nil: {
      v_t_2499 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str46);
      break;
    }
    case TAG_Cons: {
      V v_x_2497 = heff_field(v_x2_2496, 0);
      V v_xs_2498 = heff_field(v_x2_2496, 1);
      heff_take_n(v_x2_2496, 3ULL, 2);
      v_t_2499 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str47); V a_1 = v_x_2497; V a_2 = v_xs_2498; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2498); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2496);
    }
    V v_t_24100 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24101 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24100, v_ind_241, v_e_242));
    V v_t_24102 = heff_strAppend(v_t_2499, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str48), heff_strAppend(heff_get_n(v_t_24101, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str49))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24102, NTAG(TAG_Nil)});
  }
  case TAG_EPrim: {
    V v_x2_24104 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str50)));
    V v_t_24107;
    switch (heff_tag_of(v_x2_24104)) {
    case TAG_Nil: {
      v_t_24107 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str51);
      break;
    }
    case TAG_Cons: {
      V v_x_24105 = heff_field(v_x2_24104, 0);
      V v_xs_24106 = heff_field(v_x2_24104, 1);
      heff_take_n(v_x2_24104, 3ULL, 2);
      v_t_24107 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str52); V a_1 = v_x_24105; V a_2 = v_xs_24106; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24106); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24104);
    }
    V v_t_24108 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24109 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24108, v_ind_241, v_e_242));
    V v_t_24110 = heff_strAppend(v_t_24107, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str53), heff_strAppend(heff_get_n(v_t_24109, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str54))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24110, NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_x2_24113 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str55)));
    V v_t_24116;
    switch (heff_tag_of(v_x2_24113)) {
    case TAG_Nil: {
      v_t_24116 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str56);
      break;
    }
    case TAG_Cons: {
      V v_x_24114 = heff_field(v_x2_24113, 0);
      V v_xs_24115 = heff_field(v_x2_24113, 1);
      heff_take_n(v_x2_24113, 3ULL, 2);
      v_t_24116 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str57); V a_1 = v_x_24114; V a_2 = v_xs_24115; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24115); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24113);
    }
    V v_t_24117 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24118 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24117, v_ind_241, v_e_242));
    V v_t_24119 = heff_strAppend(v_t_24116, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str58), heff_strAppend(heff_get_n(v_t_24118, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str59))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24119, NTAG(TAG_Nil)});
  }
  case TAG_ECall: {
    V v_g_24120 = heff_dup(heff_field(v_e_242, 0));
    V v_as_24121 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24122 = (g_heff_2ecompile_2eemit_2eisUnitArgs(v_as_24121));
    switch (heff_tag_of(v_t_24122)) {
    case TAG_True: {
      heff_drop(v_g_24120);
      heff_drop(v_as_24121);
      V v_x2_24123 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str60)));
      V v_t_24126;
      switch (heff_tag_of(v_x2_24123)) {
      case TAG_Nil: {
        v_t_24126 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str61);
        break;
      }
      case TAG_Cons: {
        V v_x_24124 = heff_field(v_x2_24123, 0);
        V v_xs_24125 = heff_field(v_x2_24123, 1);
        heff_take_n(v_x2_24123, 3ULL, 2);
        v_t_24126 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str62); V a_1 = v_x_24124; V a_2 = v_xs_24125; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24125); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24123);
      }
      V v_t_24127 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_t_24128 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24127, v_ind_241, v_e_242));
      V v_t_24129 = heff_strAppend(v_t_24126, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str63), heff_strAppend(heff_get_n(v_t_24128, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str64))));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24129, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      heff_drop_tag(v_e_242, 2);
      V v_x2_24130 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str65)));
      V v_t_24133;
      switch (heff_tag_of(v_x2_24130)) {
      case TAG_Nil: {
        v_t_24133 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str66);
        break;
      }
      case TAG_Cons: {
        V v_x_24131 = heff_field(v_x2_24130, 0);
        V v_xs_24132 = heff_field(v_x2_24130, 1);
        heff_take_n(v_x2_24130, 3ULL, 2);
        v_t_24133 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str67); V a_1 = v_x_24131; V a_2 = v_xs_24132; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24132); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24130);
      }
      V v_t_24134 = (g_heff_2ecompile_2eemit_2ecallName(heff_dup(v_env_240), v_g_24120));
      V v_x2_24138 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_24121));
      V v_t_24141;
      switch (heff_tag_of(v_x2_24138)) {
      case TAG_Nil: {
        v_t_24141 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str68);
        break;
      }
      case TAG_Cons: {
        V v_x_24139 = heff_field(v_x2_24138, 0);
        V v_xs_24140 = heff_field(v_x2_24138, 1);
        heff_take_n(v_x2_24138, 3ULL, 2);
        v_t_24141 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str69); V a_1 = v_x_24139; V a_2 = v_xs_24140; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24140); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24138);
      }
      V v_t_24142 = heff_strAppend(v_t_24134, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str70), heff_strAppend(v_t_24141, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str71))));
      V v_t_24143 = heff_strAppend(v_t_24133, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str72), heff_strAppend(v_t_24142, ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str73))));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24143, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_24122);
    }
  }
  case TAG_EInt: {
    V v_x2_24145 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str74)));
    V v_t_24148;
    switch (heff_tag_of(v_x2_24145)) {
    case TAG_Nil: {
      v_t_24148 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str75);
      break;
    }
    case TAG_Cons: {
      V v_x_24146 = heff_field(v_x2_24145, 0);
      V v_xs_24147 = heff_field(v_x2_24145, 1);
      heff_take_n(v_x2_24145, 3ULL, 2);
      v_t_24148 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str76); V a_1 = v_x_24146; V a_2 = v_xs_24147; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24147); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24145);
    }
    V v_t_24149 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24150 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24149, v_ind_241, v_e_242));
    V v_t_24151 = heff_strAppend(v_t_24148, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str77), heff_strAppend(heff_get_n(v_t_24150, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str78))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24151, NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    V v_x2_24153 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str79)));
    V v_t_24156;
    switch (heff_tag_of(v_x2_24153)) {
    case TAG_Nil: {
      v_t_24156 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str80);
      break;
    }
    case TAG_Cons: {
      V v_x_24154 = heff_field(v_x2_24153, 0);
      V v_xs_24155 = heff_field(v_x2_24153, 1);
      heff_take_n(v_x2_24153, 3ULL, 2);
      v_t_24156 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str81); V a_1 = v_x_24154; V a_2 = v_xs_24155; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24155); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24153);
    }
    V v_t_24157 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24158 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24157, v_ind_241, v_e_242));
    V v_t_24159 = heff_strAppend(v_t_24156, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str82), heff_strAppend(heff_get_n(v_t_24158, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str83))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24159, NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    V v_x2_24161 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str84)));
    V v_t_24164;
    switch (heff_tag_of(v_x2_24161)) {
    case TAG_Nil: {
      v_t_24164 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str85);
      break;
    }
    case TAG_Cons: {
      V v_x_24162 = heff_field(v_x2_24161, 0);
      V v_xs_24163 = heff_field(v_x2_24161, 1);
      heff_take_n(v_x2_24161, 3ULL, 2);
      v_t_24164 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str86); V a_1 = v_x_24162; V a_2 = v_xs_24163; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24163); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24161);
    }
    V v_t_24165 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24166 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24165, v_ind_241, v_e_242));
    V v_t_24167 = heff_strAppend(v_t_24164, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str87), heff_strAppend(heff_get_n(v_t_24166, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str88))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24167, NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    V v_x2_24170 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str89)));
    V v_t_24173;
    switch (heff_tag_of(v_x2_24170)) {
    case TAG_Nil: {
      v_t_24173 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str90);
      break;
    }
    case TAG_Cons: {
      V v_x_24171 = heff_field(v_x2_24170, 0);
      V v_xs_24172 = heff_field(v_x2_24170, 1);
      heff_take_n(v_x2_24170, 3ULL, 2);
      v_t_24173 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str91); V a_1 = v_x_24171; V a_2 = v_xs_24172; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24172); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24170);
    }
    V v_t_24174 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24175 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24174, v_ind_241, v_e_242));
    V v_t_24176 = heff_strAppend(v_t_24173, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str92), heff_strAppend(heff_get_n(v_t_24175, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str93))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24176, NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    V v_x2_24178 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str94)));
    V v_t_24181;
    switch (heff_tag_of(v_x2_24178)) {
    case TAG_Nil: {
      v_t_24181 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str95);
      break;
    }
    case TAG_Cons: {
      V v_x_24179 = heff_field(v_x2_24178, 0);
      V v_xs_24180 = heff_field(v_x2_24178, 1);
      heff_take_n(v_x2_24178, 3ULL, 2);
      v_t_24181 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str96); V a_1 = v_x_24179; V a_2 = v_xs_24180; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24180); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24178);
    }
    V v_t_24182 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24183 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24182, v_ind_241, v_e_242));
    V v_t_24184 = heff_strAppend(v_t_24181, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str97), heff_strAppend(heff_get_n(v_t_24183, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str98))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24184, NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    V v_x2_24185 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str99)));
    V v_t_24188;
    switch (heff_tag_of(v_x2_24185)) {
    case TAG_Nil: {
      v_t_24188 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str100);
      break;
    }
    case TAG_Cons: {
      V v_x_24186 = heff_field(v_x2_24185, 0);
      V v_xs_24187 = heff_field(v_x2_24185, 1);
      heff_take_n(v_x2_24185, 3ULL, 2);
      v_t_24188 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str101); V a_1 = v_x_24186; V a_2 = v_xs_24187; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24187); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24185);
    }
    V v_t_24189 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24190 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24189, v_ind_241, v_e_242));
    V v_t_24191 = heff_strAppend(v_t_24188, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str102), heff_strAppend(heff_get_n(v_t_24190, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str103))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24191, NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_x2_24194 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str104)));
    V v_t_24197;
    switch (heff_tag_of(v_x2_24194)) {
    case TAG_Nil: {
      v_t_24197 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str105);
      break;
    }
    case TAG_Cons: {
      V v_x_24195 = heff_field(v_x2_24194, 0);
      V v_xs_24196 = heff_field(v_x2_24194, 1);
      heff_take_n(v_x2_24194, 3ULL, 2);
      v_t_24197 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str106); V a_1 = v_x_24195; V a_2 = v_xs_24196; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24196); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24194);
    }
    V v_t_24198 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_24199 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24198, v_ind_241, v_e_242));
    V v_t_24200 = heff_strAppend(v_t_24197, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str107), heff_strAppend(heff_get_n(v_t_24199, 0, 2), ((V)&g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_str108))));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_24200, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190_lam0(V self, V *args) {
  V v_a_24135 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24136 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_24137 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24136, v_ind_241, v_a_24135));
  return heff_get_n(v_t_24137, 0, 2);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str3, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str4, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str5, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str6, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str8, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str9, 28, (105, 102, 32, 40, 36, 104, 111, 108, 101, 41, 32, 123, 32, 36, 104, 111, 108, 101, 46, 97, 91, 36, 97, 116, 93, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str10, 17, (59, 32, 114, 101, 116, 117, 114, 110, 32, 36, 114, 111, 111, 116, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str11, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str12, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str13, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str14, 7, (114, 101, 116, 117, 114, 110, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str15, 1, (59));
Clo g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_entry, 4, 0};

V g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734(V v_env_240, V v_ind_241, V v_e_242, V v_rr_243) {
top: ;
  V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_249 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_248, heff_dup(v_ind_241), v_e_242));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str3), heff_strAppend(heff_dup(heff_rfield(v_rr_243, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str4), heff_strAppend(heff_get_n(v_t_249, 0, 2), ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str5))))));
  V v_x2_2411 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str6)));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str8); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str9), heff_strAppend(heff_dup(heff_rfield(v_rr_243, 0)), ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str10))));
  V v_x2_2416 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str11)));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str13); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str14), heff_strAppend(heff_get_n(v_rr_243, 0, 2), ((V)&g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_str15))));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2421})});
}
V g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str0, 1, (114));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str1, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str4, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str5, 1, (41));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str6, 12, (114, 101, 116, 117, 114, 110, 32, 36, 115, 32, 43, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str7, 1, (59));
Clo g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_entry, 4, 0};

V g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(V v_env_240, V v_s_241, V v_ind_242, V v_e_243) {
top: ;
  V v_t_244 = heff_take_field(v_s_241, 2);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop_rec(v_s_241, 4);
    V v_t_245 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str0)));
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastTrmc_24s942201055x1818819734(v_env_240, v_ind_242, v_e_243, v_t_245);
  }
  case TAG_False: {
    V v_t_246 = heff_get_n(v_s_241, 3, 4);
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str1)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_c_2412 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2411, v_ind_242, v_e_243));
      V v_t_2414;
      if (heff_intLt_c(heff_dup(heff_rfield(v_c_2412, 1)), MK_INT(2LL))) {
        v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str4), heff_strAppend(heff_get_n(v_c_2412, 0, 2), ((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str5)));
      } else {
        v_t_2414 = heff_get_n(v_c_2412, 0, 2);
      }
      V v_t_2415 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str6), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_str7))));
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      return (g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_242, v_e_243));
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str3, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str4, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str5, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str6, 1, (32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str7, 10, (32, 99, 111, 110, 116, 105, 110, 117, 101, 59));
V g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205(V v_env_240, V v_s_241, V v_ind_242, V v_as_243) {
top: ;
  V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_x2_2412 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_lam0, 2, 2, (V[]){v_env_240, v_ind_242}), heff_get_n(v_s_241, 1, 4), v_as_243));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str6); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_strAppend(v_t_247, heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str7)));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_a_249 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2411 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2410, v_ind_242, v_a_249));
  return heff_strAppend(v_p_248, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str3), heff_strAppend(heff_get_n(v_t_2411, 0, 2), ((V)&g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205_str4))));
}
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str4, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str5, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str6, 9, (117, 110, 100, 101, 102, 105, 110, 101, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str8, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str9, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str10, 8, (32, 61, 32, 123, 32, 36, 58, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str11, 6, (44, 32, 97, 58, 32, 91));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str12, 4, (93, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str13, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str14, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str16, 26, (105, 102, 32, 40, 36, 104, 111, 108, 101, 41, 32, 36, 104, 111, 108, 101, 46, 97, 91, 36, 97, 116, 93, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str17, 15, (59, 32, 101, 108, 115, 101, 32, 36, 114, 111, 111, 116, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str18, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str19, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str20, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str21, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str22, 8, (36, 104, 111, 108, 101, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str23, 8, (59, 32, 36, 97, 116, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str24, 1, (59));
V g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_entry, 7, 0};

V g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204(V v_env_240, V v_s_241, V v_ind_242, V v_t_243, V v_ini_244, V v_bs_245, V v_rr_246) {
top: ;
  V v_x2_247 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemit_2equoteGo(v_t_243, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str3)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str4), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str5)));
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_lam0, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_ind_242)}), heff_dup(v_ini_244)));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str6), NTAG(TAG_Nil)});
  V v_x2_2418 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str8); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str9), heff_strAppend(heff_dup(heff_rfield(v_rr_246, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str10), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str11), heff_strAppend(v_t_2421, ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str12))))))));
  V v_x2_2423 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str13)));
  V v_t_2426;
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    v_t_2426 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str14);
    break;
  }
  case TAG_Cons: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_xs_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    v_t_2426 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str15); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2423);
  }
  V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str16), heff_strAppend(heff_dup(heff_rfield(v_rr_246, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str17), heff_strAppend(heff_dup(heff_rfield(v_rr_246, 0)), ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str18))))));
  V v_x2_2428 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str19)));
  V v_t_2431;
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Nil: {
    v_t_2431 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str20);
    break;
  }
  case TAG_Cons: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_xs_2430 = heff_field(v_x2_2428, 1);
    heff_take_n(v_x2_2428, 3ULL, 2);
    v_t_2431 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str21); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2428);
  }
  V v_t_2432 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ini_244; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_ini_244); r_; });
  V v_t_2433 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str22), heff_strAppend(heff_get_n(v_rr_246, 0, 2), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str23), heff_strAppend(heff_intShow(v_t_2432), ((V)&g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_str24))))));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2434})});
  V v_t_2436 = (g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205(v_env_240, v_s_241, v_ind_242, v_bs_245));
  return (g_prelude_2e_2b_2b(v_t_2435, v_t_2436));
}
V g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2415 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2414, v_ind_242, v_a_2413));
  return heff_get_n(v_t_2415, 0, 2);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784_str0, 4, (99, 101, 108, 108));
Clo g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784_entry, 6, 0};

V g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784(V v_env_240, V v_s_241, V v_ind_242, V v_t_243, V v_as_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
  }
  case TAG_Just: {
    V v_x71_246 = heff_field(v_x7_245, 0);
    switch (heff_tag_of(v_x71_246)) {
    case TAG_MkPair: {
      V v_ini_247 = heff_field(v_x71_246, 0);
      V v_x712_248 = heff_field(v_x71_246, 1);
      switch (heff_tag_of(v_x712_248)) {
      case TAG_EVar: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EGlobal: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ELam: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EApp: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ELet: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ERecord: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EProj: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ETag: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EMatch: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EPrim: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EPrimCall: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ECall: {
        V v_k_2429 = heff_field(v_x712_248, 0);
        V v_bs_2430 = heff_field(v_x712_248, 1);
        V v_t_2431 = heff_dup(heff_rfield(v_s_241, 2));
        switch (heff_tag_of(v_t_2431)) {
        case TAG_True: {
          if (heff_strEq_c(heff_dup(v_k_2429), heff_dup(heff_rfield(v_s_241, 0)))) {
            V v_t_2433 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_bs_2430));
            V v_t_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_s_241, 1)));
            if (heff_intEq_c(v_t_2433, v_t_2434)) {
              heff_drop(v_as_244);
              V v_t_2436 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784_str0)));
              return (g_heff_2ecompile_2eemit_2elastCell_24s689646709x1022867204(v_env_240, v_s_241, v_ind_242, v_t_243, heff_dup(v_ini_247), heff_dup(v_bs_2430), v_t_2436));
            } else {
              return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
            }
          } else {
            return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
          }
        }
        case TAG_False: {
          return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
        }
        default: return heff_nomatch(v_t_2431);
        }
      }
      case TAG_EInt: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EFloat: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EStr: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EFixed: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EFloat32: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EAbandon: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EFix: {
        return (g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_n(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      default: return heff_nomatch(v_x712_248);
      }
    }
    default: return heff_nomatch(v_x71_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str0, 9, (115, 116, 114, 65, 112, 112, 101, 110, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str1, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str4, 6, (36, 115, 32, 43, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str5, 1, (59));
Clo g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_entry, 4, 0};

V g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(V v_env_240, V v_s_241, V v_ind_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ETag: {
    V v_t_2417 = heff_field(v_e_243, 0);
    V v_as_2418 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2421;
    switch (heff_tag_of(v_as_2418)) {
    case TAG_Nil: {
      v_t_2421 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_dup(heff_field(v_as_2418, 0));
      V v_rest_2420 = heff_dup(heff_field(v_as_2418, 1));
      v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){(g_heff_2ecompile_2eemit_2eunsnocGo(v_rest_2420, v_x_2419))});
      break;
    }
    default: heff_nomatch(v_as_2418);
    }
    return ({ V a_0 = v_env_240; V a_1 = v_s_241; V a_2 = v_ind_242; V a_3 = v_t_2417; V a_4 = v_as_2418; V a_5 = v_t_2421; V r_ = (g_heff_2ecompile_2eemit_2elastTag_24s1772473045x2012203784(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EPrimCall: {
    V v_p_2425 = heff_field(v_e_243, 0);
    V v_args_2426 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    switch (heff_tag_of(v_args_2426)) {
    case TAG_Nil: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2425, v_args_2426}));
    }
    case TAG_Cons: {
      V v_a_2427 = heff_dup(heff_field(v_args_2426, 0));
      V v_it2_2428 = heff_dup(heff_field(v_args_2426, 1));
      switch (heff_tag_of(v_it2_2428)) {
      case TAG_Nil: {
        heff_drop(v_a_2427);
        HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2425, v_args_2426}));
      }
      case TAG_Cons: {
        V v_rr_2429 = heff_field(v_it2_2428, 0);
        V v_it22_2430 = heff_field(v_it2_2428, 1);
        heff_take_n(v_it2_2428, 3ULL, 2);
        switch (heff_tag_of(v_it22_2430)) {
        case TAG_Nil: {
          V v_t_2434;
          if (heff_strEq_c(heff_dup(v_p_2425), ((V)&g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str0))) {
            V v_t_2432 = heff_dup(heff_rfield(v_s_241, 3));
            switch (heff_tag_of(v_t_2432)) {
            case TAG_True: {
              V v_t_2433 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_s_241, 1)));
              v_t_2434 = (g_heff_2ecompile_2eemit_2eappendEnd(heff_dup(heff_rfield(v_s_241, 0)), v_t_2433, v_rr_2429));
              break;
            }
            case TAG_False: {
              v_t_2434 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_2432);
            }
          } else {
            v_t_2434 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2434)) {
          case TAG_True: {
            heff_drop_rec(v_s_241, 4);
            heff_drop(v_p_2425);
            heff_drop_tag(v_args_2426, 2);
            V v_x2_2435 = (g_list_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str1)));
            V v_t_2438;
            switch (heff_tag_of(v_x2_2435)) {
            case TAG_Nil: {
              v_t_2438 = ((V)&g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str2);
              break;
            }
            case TAG_Cons: {
              V v_x_2436 = heff_field(v_x2_2435, 0);
              V v_xs_2437 = heff_field(v_x2_2435, 1);
              heff_take_n(v_x2_2435, 3ULL, 2);
              v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str3); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2435);
            }
            V v_t_2439 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
            V v_t_2440 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2439, heff_dup(v_ind_242), v_a_2427));
            V v_t_2441 = heff_strAppend(v_t_2438, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str4), heff_strAppend(heff_get_n(v_t_2440, 0, 2), ((V)&g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_str5))));
            V v_t_2442 = heff_dup(heff_rfield(v_env_240, 3));
            V v_t_2444;
            switch (heff_tag_of(v_t_2442)) {
            case TAG_Nothing: {
              v_t_2444 = (g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_242, v_rr_2429));
              break;
            }
            case TAG_Just: {
              V v_s_2443 = heff_field(v_t_2442, 0);
              heff_take_n(v_t_2442, 1ULL, 1);
              v_t_2444 = (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2443, v_ind_242, v_rr_2429));
              break;
            }
            default: heff_nomatch(v_t_2442);
            }
            return heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_Cons, 2, (V[]){v_t_2441, v_t_2444});
          }
          case TAG_False: {
            heff_drop(v_a_2427);
            heff_drop(v_rr_2429);
            HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2425, v_args_2426}));
          }
          default: return heff_nomatch(v_t_2434);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2430, 0ULL, 2);
          heff_drop(v_a_2427);
          heff_drop(v_rr_2429);
          HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_at_n(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2425, v_args_2426}));
        }
        default: return heff_nomatch(v_it22_2430);
        }
      }
      default: return heff_nomatch(v_it2_2428);
      }
    }
    default: return heff_nomatch(v_args_2426);
    }
  }
  case TAG_ECall: {
    V v_k_2447 = heff_field(v_e_243, 0);
    V v_as_2448 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_k_2447), heff_dup(heff_rfield(v_s_241, 0)))) {
      V v_t_2450 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2448));
      V v_t_2451 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_s_241, 1)));
      if (heff_intEq_c(v_t_2450, v_t_2451)) {
        heff_drop(v_k_2447);
        heff_drop_cell(v_ru_24e_243_24ECall, 2);
        HEFF_LAST return g_heff_2ecompile_2eemit_2eagain_24s735184361x1493666205(v_env_240, v_s_241, v_ind_242, v_as_2448);
      } else {
        HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_k_2447, v_as_2448}));
      }
    } else {
      HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_k_2447, v_as_2448}));
    }
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2eemit_2elastOther_24s1909043211x1744268627(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str3, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str4, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str5, 1, (59));
Clo g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_entry, 4, 0};

V g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483(V v_ind_240, V v_b_241, V v_ac_242, V v_nb_243) {
top: ;
  V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str3), heff_strAppend(heff_dup(heff_rfield(v_nb_243, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str4), heff_strAppend(heff_get_n(v_ac_242, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_str5))))));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(heff_get_n(v_nb_243, 1, 2), v_ind_240, v_b_241))});
}
V g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str4, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str5, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str6, 5, (99, 97, 115, 101, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str7, 3, (58, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str8, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str11, 1, (125));
Clo g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_entry, 5, 0};

V g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882(V v_sc_240, V v_ind_241, V v_tag_242, V v_bdy_243, V v_rb_244) {
top: ;
  V v_x2_245 = (g_list_2ereplicate(heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = (g_heff_2ecompile_2eemit_2equoteGo(v_tag_242, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str3)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str4), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str5)));
  V v_t_2411 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str7))));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = (g_heff_2ecompile_2eemit_2edeclsOf(heff_get_n(v_sc_240, 0, 3), heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL)), heff_take_field(v_rb_244, 0), MK_INT(0LL)));
  V v_t_2414 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(heff_get_n(v_rb_244, 1, 2), heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL)), v_bdy_243));
  V v_x2_2415 = (g_list_2ereplicate(heff_intAdd(v_ind_241, MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str8)));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str9);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str10); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_str11)), NTAG(TAG_Nil)});
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2419));
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2420));
  return (g_prelude_2e_2b_2b(v_t_2412, v_t_2421));
}
V g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_entry, 3, 0};

V g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076(V v_sc_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkArm: {
    V v_tag_243 = heff_field(v_x4_242, 0);
    V v_vs_244 = heff_field(v_x4_242, 1);
    V v_bdy_245 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24MkArm = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2412 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_lam0, 1, 1, (V[]){heff_dup(v_bdy_245)}), v_vs_244));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_vs_244);
      return heff_tag_at_n(v_ru_24x4_242_24MkArm, TAG_MkArmJs, 3, (V[]){v_tag_243, NTAG(TAG_True), (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(heff_get_n(v_sc_240, 1, 3), heff_intAdd(v_ind_241, MK_INT(2LL)), v_bdy_245))});
    }
    case TAG_False: {
      V v_t_2413 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), heff_dup(heff_rfield(v_sc_240, 1))});
      V v_t_2414 = (g_list_2efoldl_24s1430359702x555202731(v_t_2413, v_vs_244));
      return heff_tag_at_n(v_ru_24x4_242_24MkArm, TAG_MkArmJs, 3, (V[]){heff_dup(v_tag_243), NTAG(TAG_False), (g_heff_2ecompile_2eemit_2earmBound_24s1813785699x961169882(v_sc_240, v_ind_241, v_tag_243, v_bdy_245, v_t_2414))});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_bdy_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_bdy_245), NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_v_246), MK_INT(0LL), v_t_247));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_bdy_245, NTAG(TAG_Nil)});
  V v_t_2410 = (g_heff_2ecompile_2eir_2elamW(v_v_246, v_t_249));
  V v_t_2411 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_248, v_t_2410}), 0, 2);
  return heff_intEq(v_t_2411, MK_INT(0LL));
}
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str3, 16, (114, 101, 116, 117, 114, 110, 32, 36, 110, 111, 109, 97, 116, 99, 104, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str4, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str5, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str8, 8, (115, 119, 105, 116, 99, 104, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str9, 5, (46, 36, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str10, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str12, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str13, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str14, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str16, 16, (114, 101, 116, 117, 114, 110, 32, 36, 110, 111, 109, 97, 116, 99, 104, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str17, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str18, 1, (125));
V g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_entry, 3, 0};

V g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_arms_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_arms_241);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_arms_241);
    V v_x2_246 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str3), heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str4))));
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    return (g_prelude_2e_2b_2b(heff_get_n(v_sc_242, 2, 3), v_t_2411));
  }
  case TAG_False: {
    V v_x2_2412 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str5)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str7); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str8), heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str9))));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
    V v_t_2420 = (g_heff_2ecompile_2eemit_2esharedGo(heff_dup(v_ind_240), NTAG(TAG_Nil), v_t_2419));
    V v_x2_2421 = (g_list_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str10)));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str12); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_x2_2425 = (g_list_2ereplicate(v_ind_240, ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str13)));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str15); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    V v_t_2429 = heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str16), heff_strAppend(heff_dup(heff_rfield(v_sc_242, 0)), ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str17))));
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_str18)), v_t_2430});
    V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2431));
    V v_t_2433 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2432));
    return (g_prelude_2e_2b_2b(heff_get_n(v_sc_242, 2, 3), v_t_2433));
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200_lam0(V self, V *args) {
  V v_a_2418 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2eemit_2earmJs_24s1287820996x1149501076(v_sc_242, v_ind_240, v_a_2418));
}
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str3, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str4, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str5, 1, (59));
Clo g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry, 4, 0};

V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(V v_env_240, V v_ind_241, V v_s_242, V v_b_243) {
top: ;
  V v_x2_244 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_n(v_env_240, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_249 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_248, v_ind_241, v_s_242));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str3), heff_strAppend(heff_dup(heff_rfield(v_b_243, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str4), heff_strAppend(heff_get_n(v_t_249, 0, 2), ((V)&g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_str5))))));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  return heff_rec_n(3, shape_js__env__pre, (V[]){heff_dup(heff_rfield(v_b_243, 0)), heff_get_n(v_b_243, 1, 2), v_t_2411});
}
V g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str14, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str15, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str16, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str17, 1, (115));
HEFF_STRA(g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str18, 1, (115));
Clo g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry, 3, 0};

V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(V v_env_240, V v_ind_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_s_242, 0);
    V v_ru_24s_242_24EVar = heff_take_reuse_n(v_s_242, 1ULL, 1);
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_243), heff_rfield(v_env_240, 1)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str0)));
      return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, heff_tag_at_n(v_ru_24s_242_24EVar, TAG_EVar, 1, (V[]){v_x_243}), v_t_245));
    }
    case TAG_Just: {
      V v_js_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop(v_ind_241);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24s_242_24EVar, 1);
      return heff_rec_n(3, shape_js__env__pre, (V[]){v_js_246, v_env_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_248 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str1)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_248));
  }
  case TAG_ELam: {
    V v_t_2411 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str2)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2411));
  }
  case TAG_EApp: {
    V v_t_2414 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str3)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2414));
  }
  case TAG_ELet: {
    V v_t_2418 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str4)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2418));
  }
  case TAG_ERecord: {
    V v_t_2420 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str5)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2420));
  }
  case TAG_EProj: {
    V v_t_2424 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str6)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2424));
  }
  case TAG_ETag: {
    V v_t_2427 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str7)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2427));
  }
  case TAG_EMatch: {
    V v_t_2430 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str8)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2430));
  }
  case TAG_EPrim: {
    V v_t_2432 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str9)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2432));
  }
  case TAG_EPrimCall: {
    V v_t_2435 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str10)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2435));
  }
  case TAG_ECall: {
    V v_t_2438 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str11)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2438));
  }
  case TAG_EInt: {
    V v_t_2440 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str12)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2440));
  }
  case TAG_EFloat: {
    V v_t_2442 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str13)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2442));
  }
  case TAG_EStr: {
    V v_t_2444 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str14)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2444));
  }
  case TAG_EFixed: {
    V v_t_2447 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str15)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2447));
  }
  case TAG_EFloat32: {
    V v_t_2449 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str16)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2449));
  }
  case TAG_EAbandon: {
    V v_t_2450 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str17)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2450));
  }
  case TAG_EFix: {
    V v_t_2453 = (g_heff_2ecompile_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_str18)));
    return (g_heff_2ecompile_2eemit_2escrutBound_24s336121111x985246664(v_env_240, v_ind_241, v_s_242, v_t_2453));
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str0, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str3, 4, (105, 102, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str4, 3, (41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str5, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str8, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str11, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str12, 8, (125, 32, 101, 108, 115, 101, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str13, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str14, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str16, 4, (105, 102, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str17, 3, (41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str18, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str19, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str20, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str21, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str22, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str23, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str24, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str25, 8, (125, 32, 101, 108, 115, 101, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str26, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str27, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str28, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str29, 4, (105, 102, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str30, 3, (41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str31, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str32, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str33, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str34, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str35, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str36, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str37, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str38, 8, (125, 32, 101, 108, 115, 101, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str39, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str40, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str41, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str42, 4, (105, 102, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str43, 3, (41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str44, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str45, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str46, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str47, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str48, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str49, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str50, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str51, 8, (125, 32, 101, 108, 115, 101, 32, 123));
Clo g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_entry, 5, 0};

V g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508(V v_env_240, V v_ind_241, V v_c_242, V v_t_243, V v_f_244) {
top: ;
  switch (heff_tag_of(v_c_242)) {
  case TAG_PTrue: {
    heff_drop(v_f_244);
    return (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_240, v_ind_241, v_t_243));
  }
  case TAG_PFalse: {
    heff_drop(v_t_243);
    return (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_240, v_ind_241, v_f_244));
  }
  case TAG_PRel: {
    V v_t_246 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_242));
    V v_t_247 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_246));
    V v_x2_248 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str0)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = (g_heff_2ecompile_2eemit_2econdCode(v_c_242));
    V v_t_2413 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str3), heff_strAppend(heff_get_n(v_t_2412, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str4))));
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2415 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2416 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str5)));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str7); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2420 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2421 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str8)));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str10); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str11)), NTAG(TAG_Nil)});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str12)), (g_prelude_2e_2b_2b(v_t_2420, v_t_2425))});
    V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2426));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2427));
    return (g_prelude_2e_2b_2b(v_t_247, v_t_2428));
  }
  case TAG_PNot: {
    V v_t_2430 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_242));
    V v_t_2431 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_2430));
    V v_x2_2432 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str13)));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_Nil: {
      v_t_2435 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_xs_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str15); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2432);
    }
    V v_t_2436 = (g_heff_2ecompile_2eemit_2econdCode(v_c_242));
    V v_t_2437 = heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str16), heff_strAppend(heff_get_n(v_t_2436, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str17))));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
    V v_t_2439 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2440 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str18)));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str20); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    V v_t_2444 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2445 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str21)));
    V v_t_2448;
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_Nil: {
      v_t_2448 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_xs_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      v_t_2448 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str23); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2445);
    }
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str24)), NTAG(TAG_Nil)});
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str25)), (g_prelude_2e_2b_2b(v_t_2444, v_t_2449))});
    V v_t_2451 = (g_prelude_2e_2b_2b(v_t_2439, v_t_2450));
    V v_t_2452 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2451));
    return (g_prelude_2e_2b_2b(v_t_2431, v_t_2452));
  }
  case TAG_PIf: {
    V v_t_2456 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_242));
    V v_t_2457 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_2456));
    V v_x2_2458 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str26)));
    V v_t_2461;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nil: {
      v_t_2461 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str27);
      break;
    }
    case TAG_Cons: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_xs_2460 = heff_field(v_x2_2458, 1);
      heff_take_n(v_x2_2458, 3ULL, 2);
      v_t_2461 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str28); V a_1 = v_x_2459; V a_2 = v_xs_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    V v_t_2462 = (g_heff_2ecompile_2eemit_2econdCode(v_c_242));
    V v_t_2463 = heff_strAppend(v_t_2461, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str29), heff_strAppend(heff_get_n(v_t_2462, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str30))));
    V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
    V v_t_2465 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2466 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str31)));
    V v_t_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str32);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_t_2469 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str33); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    V v_t_2470 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2471 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str34)));
    V v_t_2474;
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_Nil: {
      v_t_2474 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_xs_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      v_t_2474 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str36); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2471);
    }
    V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2474, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str37)), NTAG(TAG_Nil)});
    V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str38)), (g_prelude_2e_2b_2b(v_t_2470, v_t_2475))});
    V v_t_2477 = (g_prelude_2e_2b_2b(v_t_2465, v_t_2476));
    V v_t_2478 = (g_prelude_2e_2b_2b(v_t_2464, v_t_2477));
    return (g_prelude_2e_2b_2b(v_t_2457, v_t_2478));
  }
  case TAG_PSeq: {
    V v_t_2482 = (g_heff_2ecompile_2eemit_2eseqsOf(v_c_242));
    V v_t_2483 = (g_heff_2ecompile_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_2482));
    V v_x2_2484 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str39)));
    V v_t_2487;
    switch (heff_tag_of(v_x2_2484)) {
    case TAG_Nil: {
      v_t_2487 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str40);
      break;
    }
    case TAG_Cons: {
      V v_x_2485 = heff_field(v_x2_2484, 0);
      V v_xs_2486 = heff_field(v_x2_2484, 1);
      heff_take_n(v_x2_2484, 3ULL, 2);
      v_t_2487 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str41); V a_1 = v_x_2485; V a_2 = v_xs_2486; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2486); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2484);
    }
    V v_t_2488 = (g_heff_2ecompile_2eemit_2econdCode(v_c_242));
    V v_t_2489 = heff_strAppend(v_t_2487, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str42), heff_strAppend(heff_get_n(v_t_2488, 0, 2), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str43))));
    V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
    V v_t_2491 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2492 = (g_list_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str44)));
    V v_t_2495;
    switch (heff_tag_of(v_x2_2492)) {
    case TAG_Nil: {
      v_t_2495 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str45);
      break;
    }
    case TAG_Cons: {
      V v_x_2493 = heff_field(v_x2_2492, 0);
      V v_xs_2494 = heff_field(v_x2_2492, 1);
      heff_take_n(v_x2_2492, 3ULL, 2);
      v_t_2495 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str46); V a_1 = v_x_2493; V a_2 = v_xs_2494; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2494); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2492);
    }
    V v_t_2496 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2497 = (g_list_2ereplicate(v_ind_241, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str47)));
    V v_t_24100;
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_Nil: {
      v_t_24100 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str48);
      break;
    }
    case TAG_Cons: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_xs_2499 = heff_field(v_x2_2497, 1);
      heff_take_n(v_x2_2497, 3ULL, 2);
      v_t_24100 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str49); V a_1 = v_x_2498; V a_2 = v_xs_2499; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2499); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2497);
    }
    V v_t_24101 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str50)), NTAG(TAG_Nil)});
    V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2495, ((V)&g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_str51)), (g_prelude_2e_2b_2b(v_t_2496, v_t_24101))});
    V v_t_24103 = (g_prelude_2e_2b_2b(v_t_2491, v_t_24102));
    V v_t_24104 = (g_prelude_2e_2b_2b(v_t_2490, v_t_24103));
    return (g_prelude_2e_2b_2b(v_t_2483, v_t_24104));
  }
  default: return heff_nomatch(v_c_242);
  }
}
V g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_str0, 4, (84, 114, 117, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_str1, 5, (70, 97, 108, 115, 101));
Clo g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_entry, 3, 0};

V g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_245, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_247 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_248, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_ELam: {
    V v_t_2411 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2412, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_EApp: {
    V v_t_2415 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2416, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_242, 0);
    V v_a_2418 = heff_field(v_e_242, 1);
    V v_b_2419 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2420 = heff_rec_n(4, shape_gs__names__used__self, (V[]){heff_dup(heff_rfield(v_env_240, 0)), heff_dup(heff_rfield(v_env_240, 1)), heff_dup(heff_rfield(v_env_240, 2)), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2420, heff_dup(v_ind_241), v_a_2418));
    V v_t_2422 = (g_heff_2ecompile_2eemit_2ebindName(v_env_240, v_x_2417));
    return (g_heff_2ecompile_2eemit_2estmtsLet2_24s1718355340x1606939483(v_ind_241, v_b_2419, v_t_2421, v_t_2422));
  }
  case TAG_ERecord: {
    V v_t_2424 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2425 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2425, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  case TAG_EProj: {
    V v_t_2429 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2430, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_ETag: {
    V v_t_2433 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2434 = heff_field(v_t_2433, 0);
      heff_take_n(v_t_2433, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2434, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_EMatch: {
    V v_s_2435 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2436 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2437 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_2436));
    V v_it_2443;
    if (heff_intEq_c(v_t_2437, MK_INT(2LL))) {
      V v_t_2439 = (g_heff_2ecompile_2eemit_2earmNamed(((V)&g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_str0), v_arms_2436));
      switch (heff_tag_of(v_t_2439)) {
      case TAG_Nothing: {
        v_it_2443 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2440 = heff_field(v_t_2439, 0);
        V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 1ULL, 1);
        V v_t_2441 = (g_heff_2ecompile_2eemit_2earmNamed(((V)&g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_str1), v_arms_2436));
        switch (heff_tag_of(v_t_2441)) {
        case TAG_Nothing: {
          heff_drop(v_t_2440);
          heff_drop_cell(v_ru_24t_2439_24Just, 1);
          v_it_2443 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2442 = heff_field(v_t_2441, 0);
          heff_take_n(v_t_2441, 1ULL, 1);
          v_it_2443 = heff_tag_at_n(v_ru_24t_2439_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_f_2442})});
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        break;
      }
      default: heff_nomatch(v_t_2439);
      }
    } else {
      v_it_2443 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_it_2443)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      V v_t_2444 = (g_heff_2ecompile_2eemit_2escrutOf_24s496132590x1970557114(v_env_240, heff_dup(v_ind_241), v_s_2435));
      HEFF_LAST return g_heff_2ecompile_2eemit_2estmtsMatch2_24s1117722930x608910200(v_ind_241, v_arms_2436, v_t_2444);
    }
    case TAG_Just: {
      V v_it1_2445 = heff_field(v_it_2443, 0);
      heff_take_n(v_it_2443, 1ULL, 1);
      heff_drop(v_arms_2436);
      switch (heff_tag_of(v_it1_2445)) {
      case TAG_MkPair: {
        V v_t_2446 = heff_field(v_it1_2445, 0);
        V v_f_2447 = heff_field(v_it1_2445, 1);
        heff_take_n(v_it1_2445, 3ULL, 2);
        V v_t_2448 = heff_dup(heff_rfield(v_env_240, 3));
        switch (heff_tag_of(v_t_2448)) {
        case TAG_Nothing: {
          V v_t_2449 = (g_heff_2ecompile_2eemit_2econdShaped(heff_dup(v_t_2446)));
          switch (heff_tag_of(v_t_2449)) {
          case TAG_True: {
            V v_t_2450 = (g_heff_2ecompile_2eemit_2econdShaped(heff_dup(v_f_2447)));
            switch (heff_tag_of(v_t_2450)) {
            case TAG_True: {
              heff_drop(v_s_2435);
              heff_drop(v_t_2446);
              heff_drop(v_f_2447);
              V v_t_2451 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(v_env_240, heff_dup(v_ind_241), v_e_242));
              return (g_heff_2ecompile_2eemit_2estmtsReturnCond(v_ind_241, v_t_2451));
            }
            case TAG_False: {
              heff_drop_tag(v_e_242, 2);
              V v_t_2452 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2435));
              return (g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508(v_env_240, v_ind_241, v_t_2452, v_t_2446, v_f_2447));
            }
            default: return heff_nomatch(v_t_2450);
            }
          }
          case TAG_False: {
            heff_drop_tag(v_e_242, 2);
            V v_t_2453 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2435));
            return (g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508(v_env_240, v_ind_241, v_t_2453, v_t_2446, v_f_2447));
          }
          default: return heff_nomatch(v_t_2449);
          }
        }
        case TAG_Just: {
          heff_take_n(v_t_2448, 0ULL, 1);
          heff_drop_tag(v_e_242, 2);
          V v_t_2455 = (g_heff_2ecompile_2eemit_2epredOf_24s504324711x793466716(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2435));
          return (g_heff_2ecompile_2eemit_2estmtsIf_24s1840888365x1591592508(v_env_240, v_ind_241, v_t_2455, v_t_2446, v_f_2447));
        }
        default: return heff_nomatch(v_t_2448);
        }
      }
      default: return heff_nomatch(v_it1_2445);
      }
    }
    default: return heff_nomatch(v_it_2443);
    }
  }
  case TAG_EPrim: {
    V v_t_2457 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2457)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2458 = heff_field(v_t_2457, 0);
      heff_take_n(v_t_2457, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2458, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2457);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2461 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2461)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2462 = heff_field(v_t_2461, 0);
      heff_take_n(v_t_2461, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2462, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2461);
    }
  }
  case TAG_ECall: {
    V v_t_2465 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2465)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2466 = heff_field(v_t_2465, 0);
      heff_take_n(v_t_2465, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2466, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2465);
    }
  }
  case TAG_EInt: {
    V v_t_2468 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2468)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2469 = heff_field(v_t_2468, 0);
      heff_take_n(v_t_2468, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2469, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2468);
    }
  }
  case TAG_EFloat: {
    V v_t_2471 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2471)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2472 = heff_field(v_t_2471, 0);
      heff_take_n(v_t_2471, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2472, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2471);
    }
  }
  case TAG_EStr: {
    V v_t_2474 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2474)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2475 = heff_field(v_t_2474, 0);
      heff_take_n(v_t_2474, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2475, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2474);
    }
  }
  case TAG_EFixed: {
    V v_t_2478 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2478)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2479 = heff_field(v_t_2478, 0);
      heff_take_n(v_t_2478, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2479, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2478);
    }
  }
  case TAG_EFloat32: {
    V v_t_2481 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2481)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2482 = heff_field(v_t_2481, 0);
      heff_take_n(v_t_2481, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2482, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2481);
    }
  }
  case TAG_EAbandon: {
    V v_t_2483 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2483)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2484 = heff_field(v_t_2483, 0);
      heff_take_n(v_t_2483, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2484, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2483);
    }
  }
  case TAG_EFix: {
    V v_t_2487 = heff_dup(heff_rfield(v_env_240, 3));
    switch (heff_tag_of(v_t_2487)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2ecompile_2eemit_2ereturnLines_24s1525950769x787430190(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2488 = heff_field(v_t_2487, 0);
      heff_take_n(v_t_2487, 1ULL, 1);
      return (g_heff_2ecompile_2eemit_2elastSelf_24s856698404x202832160(v_env_240, v_s_2488, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2487);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str0, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str2, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str3, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str4, 4, (32, 61, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str5, 6, (41, 32, 61, 62, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str6, 35, (32, 32, 108, 101, 116, 32, 36, 114, 111, 111, 116, 44, 32, 36, 104, 111, 108, 101, 32, 61, 32, 110, 117, 108, 108, 44, 32, 36, 97, 116, 32, 61, 32, 48, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str7, 14, (32, 32, 108, 101, 116, 32, 36, 115, 32, 61, 32, 34, 34, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str8, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str9, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str11, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str12, 10, (32, 32, 32, 32, 99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str13, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str14, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str15, 2, (125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str16, 3, (32, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str17, 12, (32, 32, 102, 111, 114, 32, 40, 59, 59, 41, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2elooped_str18, 0, (0));
Clo g_heff_2ecompile_2eemit_2elooped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elooped_entry, 6, 0};

V g_heff_2ecompile_2eemit_2elooped(V v_key_240, V v_i_241, V v_b_242, V v_r_243, V v_trmc_244, V v_sapp_245) {
top: ;
  V v_x2_246 = (g_list_2emap_24s374365348x2042978339(((V)&g_heff_2ecompile_2eemit_2elooped_str0), heff_dup(heff_rfield(v_r_243, 0))));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ecompile_2eemit_2elooped_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str3), heff_strAppend(heff_get_n(v_i_241, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str4), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2elooped_str5)))));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412;
  switch (heff_tag_of(v_trmc_244)) {
  case TAG_True: {
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str6), NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_trmc_244);
  }
  V v_t_2413;
  switch (heff_tag_of(v_sapp_245)) {
  case TAG_True: {
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str7), NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_sapp_245);
  }
  V v_t_2414 = (g_list_2emap_24s374365348x2042978339(((V)&g_heff_2ecompile_2eemit_2elooped_str8), heff_dup(heff_rfield(v_r_243, 0))));
  V v_x2_2415 = (g_list_2ezipWith_24s1610853704x1401907306(((V)&g_heff_2ecompile_2eemit_2elooped_str9), heff_dup(heff_rfield(v_r_243, 0)), v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ecompile_2eemit_2elooped_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2elooped_str11); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2elooped_str12), heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemit_2elooped_str13)));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = (g_list_2emap_24s374365348x2042978339(((V)&g_heff_2ecompile_2eemit_2elooped_str14), heff_take_field(v_r_243, 0)));
  V v_s_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_key__params__trmc__sapp, (V[]){v_key_240, v_t_2421, v_trmc_244, v_sapp_245})});
  V v_env_2423 = heff_get_n(v_r_243, 1, 2);
  V v_env_2424 = ({ V rv_3 = v_s_2422; V rr_ = heff_rec_reuse_n(v_env_2423, 7ULL, 4, shape_gs__names__used__self); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2425 = (g_heff_2ecompile_2eemit_2estmtsF_24s999842396x1823653542(v_env_2424, MK_INT(2LL), v_b_242));
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str15), NTAG(TAG_Nil)});
  V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2425, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str16), v_t_2426})));
  V v_t_2428 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str17), v_t_2420}), v_t_2427));
  V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2428));
  V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2429));
  return (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2elooped_str18), v_t_2411}), v_t_2430));
}
V g_heff_2ecompile_2eemit_2elooped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2elooped(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2edefFun_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefFun_str1, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefFun_str2, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefFun_str3, 4, (32, 61, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefFun_str4, 5, (41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefFun_str5, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefFun_str6, 0, (0));
Clo g_heff_2ecompile_2eemit_2edefFun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edefFun_entry, 6, 0};

V g_heff_2ecompile_2eemit_2edefFun(V v_curried_240, V v_key_241, V v_i_242, V v_xs_243, V v_b_244, V v_r_245) {
top: ;
  V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_243));
  V v_t_247 = (g_heff_2ecompile_2eemit_2etailSelf(heff_dup(v_key_241), v_t_246, v_b_244));
  V v_t_2419;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    V v_t_249 = (g_heff_2ecompile_2eemit_2econsSelf(heff_dup(v_key_241), v_t_248, v_b_244));
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    V v_t_2411 = (g_heff_2ecompile_2eemit_2eappendSelf(heff_dup(v_key_241), v_t_2410, v_b_244));
    v_t_2419 = (g_heff_2ecompile_2eemit_2elooped(heff_dup(v_key_241), heff_dup(v_i_242), v_b_244, heff_dup(v_r_245), v_t_249, v_t_2411));
    break;
  }
  case TAG_False: {
    V v_t_2412 = heff_dup(heff_rfield(v_r_245, 0));
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2edefFun_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_t_2412, 0);
      V v_xs_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2edefFun_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2416 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(heff_dup(heff_rfield(v_r_245, 1)), MK_INT(0LL), v_b_244));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str2), heff_strAppend(heff_dup(heff_rfield(v_i_242, 0)), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str3), heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefFun_str4), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2edefFun_str5)))))));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefFun_str6), v_t_2418});
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2420 = (g_heff_2ecompile_2eemit_2ewrapper(v_curried_240, v_key_241, v_i_242, heff_get_n(v_r_245, 0, 2)));
  return (g_prelude_2e_2b_2b(v_t_2419, v_t_2420));
}
V g_heff_2ecompile_2eemit_2edefFun_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2edefFun(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[3]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str0, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str1, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str2, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str4, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str5, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str6, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str7, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str8, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str9, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str10, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str11, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str12, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str13, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str14, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str16, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str17, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str18, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str19, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str20, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str21, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str22, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str23, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str24, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str25, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str26, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str27, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str28, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str29, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str30, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str31, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str32, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str33, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str34, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str35, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str36, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str37, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str38, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str39, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str40, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str41, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str42, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str43, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str44, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str45, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str46, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str47, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str48, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str49, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str50, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str51, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str52, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str53, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str54, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str55, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str56, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str57, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str58, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str59, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str60, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str61, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str62, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str63, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str64, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str65, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str66, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str67, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str68, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str69, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str70, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str71, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str72, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str73, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str74, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str75, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str76, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str77, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str78, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str79, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str80, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str81, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str82, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str83, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str84, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str85, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str86, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str87, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str88, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str89, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str90, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str91, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str92, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str93, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str94, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str95, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str96, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str97, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str98, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str99, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str100, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str101, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str102, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str103, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str104, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str105, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str106, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str107, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str108, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str109, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str110, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str111, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str112, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str113, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str114, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str115, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str116, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str117, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str118, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str119, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str120, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str121, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str122, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str123, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str124, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str125, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str126, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str127, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str128, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str129, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str130, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str131, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str132, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str133, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str134, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str135, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str136, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str137, 15, (32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str138, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str139, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str140, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str141, 3, (32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str142, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2edefBody_str143, 0, (0));
Clo g_heff_2ecompile_2eemit_2edefBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2edefBody_entry, 5, 0};

V g_heff_2ecompile_2eemit_2edefBody(V v_gs_240, V v_curried_241, V v_globalNames_242, V v_d_243, V v_i_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_d_243, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_EVar: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_247 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_249 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_248, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str0), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str1), heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemit_2edefBody_str2)))));
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str3), v_t_2411});
    }
    case TAG_False: {
      V v_t_2412 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2413 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2412, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str4), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str5), heff_strAppend(heff_get_n(v_t_2413, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str6)))));
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str7), v_t_2415});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_2417 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      V v_t_2418 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2419 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_2418, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str8), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str9), heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemit_2edefBody_str10)))));
      V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str11), v_t_2421});
    }
    case TAG_False: {
      V v_t_2422 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2423 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2422, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str12), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str13), heff_strAppend(heff_get_n(v_t_2423, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str14)))));
      V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str15), v_t_2425});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_ELam: {
    V v_xs_2426 = heff_field(v_t_245, 0);
    V v_b_2427 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 3ULL, 2);
    V v_t_2428 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_rec_n(2, shape_js__env, (V[]){NTAG(TAG_Nil), v_t_2428});
    V v_t_2430 = (g_list_2efoldl_24s1430359702x555202731(v_t_2429, heff_dup(v_xs_2426)));
    return ({ V a_0 = v_curried_241; V a_1 = heff_get_n(v_d_243, 0, 3); V a_2 = v_i_244; V a_3 = v_xs_2426; V a_4 = v_b_2427; V a_5 = v_t_2430; V r_ = (g_heff_2ecompile_2eemit_2edefFun(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2426); r_; });
  }
  case TAG_EApp: {
    V v_ru_24t_245_24EApp = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_2433 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      V v_t_2434 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2435 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_2434, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2436 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str16), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str17), heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemit_2edefBody_str18)))));
      V v_t_2437 = heff_tag_at_n(v_ru_24t_245_24EApp, TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str19), v_t_2437});
    }
    case TAG_False: {
      V v_t_2438 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2439 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2438, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2440 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str20), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str21), heff_strAppend(heff_get_n(v_t_2439, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str22)))));
      V v_t_2441 = heff_tag_at_n(v_ru_24t_245_24EApp, TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str23), v_t_2441});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_ELet: {
    heff_take_n(v_t_245, 0ULL, 3);
    V v_t_2445 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      V v_t_2446 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2447 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_2446, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str24), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str25), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eemit_2edefBody_str26)))));
      V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str27), v_t_2449});
    }
    case TAG_False: {
      V v_t_2450 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2451 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2450, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str28), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str29), heff_strAppend(heff_get_n(v_t_2451, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str30)))));
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str31), v_t_2453});
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_2455 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2455)) {
    case TAG_True: {
      V v_t_2456 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2457 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_2456, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2458 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str32), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str33), heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2eemit_2edefBody_str34)))));
      V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str35), v_t_2459});
    }
    case TAG_False: {
      V v_t_2460 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2461 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2460, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2462 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str36), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str37), heff_strAppend(heff_get_n(v_t_2461, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str38)))));
      V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str39), v_t_2463});
    }
    default: return heff_nomatch(v_t_2455);
    }
  }
  case TAG_EProj: {
    heff_take_n(v_t_245, 0ULL, 3);
    V v_t_2467 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2467)) {
    case TAG_True: {
      V v_t_2468 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2469 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_2468, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2470 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str40), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str41), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2eemit_2edefBody_str42)))));
      V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str43), v_t_2471});
    }
    case TAG_False: {
      V v_t_2472 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2473 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2472, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2474 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str44), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str45), heff_strAppend(heff_get_n(v_t_2473, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str46)))));
      V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str47), v_t_2475});
    }
    default: return heff_nomatch(v_t_2467);
    }
  }
  case TAG_ETag: {
    V v_ru_24t_245_24ETag = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_2478 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2478)) {
    case TAG_True: {
      V v_t_2479 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2480 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_2479, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2481 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str48), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str49), heff_strAppend(v_t_2480, ((V)&g_heff_2ecompile_2eemit_2edefBody_str50)))));
      V v_t_2482 = heff_tag_at_n(v_ru_24t_245_24ETag, TAG_Cons, 2, (V[]){v_t_2481, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str51), v_t_2482});
    }
    case TAG_False: {
      V v_t_2483 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2484 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2483, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2485 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str52), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str53), heff_strAppend(heff_get_n(v_t_2484, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str54)))));
      V v_t_2486 = heff_tag_at_n(v_ru_24t_245_24ETag, TAG_Cons, 2, (V[]){v_t_2485, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str55), v_t_2486});
    }
    default: return heff_nomatch(v_t_2478);
    }
  }
  case TAG_EMatch: {
    V v_ru_24t_245_24EMatch = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_2489 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2489)) {
    case TAG_True: {
      V v_t_2490 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2491 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_2490, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2492 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str56), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str57), heff_strAppend(v_t_2491, ((V)&g_heff_2ecompile_2eemit_2edefBody_str58)))));
      V v_t_2493 = heff_tag_at_n(v_ru_24t_245_24EMatch, TAG_Cons, 2, (V[]){v_t_2492, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str59), v_t_2493});
    }
    case TAG_False: {
      V v_t_2494 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2495 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_2494, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_2496 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str60), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str61), heff_strAppend(heff_get_n(v_t_2495, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str62)))));
      V v_t_2497 = heff_tag_at_n(v_ru_24t_245_24EMatch, TAG_Cons, 2, (V[]){v_t_2496, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str63), v_t_2497});
    }
    default: return heff_nomatch(v_t_2489);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_2499 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_2499)) {
    case TAG_True: {
      V v_t_24100 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24101 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24100, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24102 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str64), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str65), heff_strAppend(v_t_24101, ((V)&g_heff_2ecompile_2eemit_2edefBody_str66)))));
      V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24102, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str67), v_t_24103});
    }
    case TAG_False: {
      V v_t_24104 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24105 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24104, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24106 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str68), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str69), heff_strAppend(heff_get_n(v_t_24105, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str70)))));
      V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str71), v_t_24107});
    }
    default: return heff_nomatch(v_t_2499);
    }
  }
  case TAG_EPrimCall: {
    V v_ru_24t_245_24EPrimCall = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_24110 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24110)) {
    case TAG_True: {
      V v_t_24111 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24112 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24111, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24113 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str72), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str73), heff_strAppend(v_t_24112, ((V)&g_heff_2ecompile_2eemit_2edefBody_str74)))));
      V v_t_24114 = heff_tag_at_n(v_ru_24t_245_24EPrimCall, TAG_Cons, 2, (V[]){v_t_24113, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str75), v_t_24114});
    }
    case TAG_False: {
      V v_t_24115 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24116 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24115, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24117 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str76), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str77), heff_strAppend(heff_get_n(v_t_24116, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str78)))));
      V v_t_24118 = heff_tag_at_n(v_ru_24t_245_24EPrimCall, TAG_Cons, 2, (V[]){v_t_24117, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str79), v_t_24118});
    }
    default: return heff_nomatch(v_t_24110);
    }
  }
  case TAG_ECall: {
    V v_ru_24t_245_24ECall = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_24121 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24121)) {
    case TAG_True: {
      V v_t_24122 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24123 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24122, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str80), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str81), heff_strAppend(v_t_24123, ((V)&g_heff_2ecompile_2eemit_2edefBody_str82)))));
      V v_t_24125 = heff_tag_at_n(v_ru_24t_245_24ECall, TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str83), v_t_24125});
    }
    case TAG_False: {
      V v_t_24126 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24127 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24126, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24128 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str84), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str85), heff_strAppend(heff_get_n(v_t_24127, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str86)))));
      V v_t_24129 = heff_tag_at_n(v_ru_24t_245_24ECall, TAG_Cons, 2, (V[]){v_t_24128, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str87), v_t_24129});
    }
    default: return heff_nomatch(v_t_24121);
    }
  }
  case TAG_EInt: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_24131 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24131)) {
    case TAG_True: {
      V v_t_24132 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24133 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24132, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str88), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str89), heff_strAppend(v_t_24133, ((V)&g_heff_2ecompile_2eemit_2edefBody_str90)))));
      V v_t_24135 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24134, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str91), v_t_24135});
    }
    case TAG_False: {
      V v_t_24136 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24137 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24136, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24138 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str92), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str93), heff_strAppend(heff_get_n(v_t_24137, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str94)))));
      V v_t_24139 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str95), v_t_24139});
    }
    default: return heff_nomatch(v_t_24131);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_24141 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24141)) {
    case TAG_True: {
      V v_t_24142 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24143 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24142, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24144 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str96), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str97), heff_strAppend(v_t_24143, ((V)&g_heff_2ecompile_2eemit_2edefBody_str98)))));
      V v_t_24145 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24144, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str99), v_t_24145});
    }
    case TAG_False: {
      V v_t_24146 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24147 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24146, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24148 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str100), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str101), heff_strAppend(heff_get_n(v_t_24147, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str102)))));
      V v_t_24149 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24148, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str103), v_t_24149});
    }
    default: return heff_nomatch(v_t_24141);
    }
  }
  case TAG_EStr: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_24151 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24151)) {
    case TAG_True: {
      V v_t_24152 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24153 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24152, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24154 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str104), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str105), heff_strAppend(v_t_24153, ((V)&g_heff_2ecompile_2eemit_2edefBody_str106)))));
      V v_t_24155 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24154, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str107), v_t_24155});
    }
    case TAG_False: {
      V v_t_24156 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24157 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24156, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24158 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str108), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str109), heff_strAppend(heff_get_n(v_t_24157, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str110)))));
      V v_t_24159 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24158, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str111), v_t_24159});
    }
    default: return heff_nomatch(v_t_24151);
    }
  }
  case TAG_EFixed: {
    V v_ru_24t_245_24EFixed = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_24162 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24162)) {
    case TAG_True: {
      V v_t_24163 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24164 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24163, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24165 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str112), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str113), heff_strAppend(v_t_24164, ((V)&g_heff_2ecompile_2eemit_2edefBody_str114)))));
      V v_t_24166 = heff_tag_at_n(v_ru_24t_245_24EFixed, TAG_Cons, 2, (V[]){v_t_24165, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str115), v_t_24166});
    }
    case TAG_False: {
      V v_t_24167 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24168 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24167, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24169 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str116), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str117), heff_strAppend(heff_get_n(v_t_24168, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str118)))));
      V v_t_24170 = heff_tag_at_n(v_ru_24t_245_24EFixed, TAG_Cons, 2, (V[]){v_t_24169, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str119), v_t_24170});
    }
    default: return heff_nomatch(v_t_24162);
    }
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_24172 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24172)) {
    case TAG_True: {
      V v_t_24173 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24174 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24173, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24175 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str120), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str121), heff_strAppend(v_t_24174, ((V)&g_heff_2ecompile_2eemit_2edefBody_str122)))));
      V v_t_24176 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24175, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str123), v_t_24176});
    }
    case TAG_False: {
      V v_t_24177 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24178 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24177, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24179 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str124), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str125), heff_strAppend(heff_get_n(v_t_24178, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str126)))));
      V v_t_24180 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24179, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str127), v_t_24180});
    }
    default: return heff_nomatch(v_t_24172);
    }
  }
  case TAG_EAbandon: {
    V v_t_24181 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24181)) {
    case TAG_True: {
      V v_t_24182 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24183 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24182, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24184 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str128), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str129), heff_strAppend(v_t_24183, ((V)&g_heff_2ecompile_2eemit_2edefBody_str130)))));
      V v_t_24185 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24184, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str131), v_t_24185});
    }
    case TAG_False: {
      V v_t_24186 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24187 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24186, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24188 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str132), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str133), heff_strAppend(heff_get_n(v_t_24187, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str134)))));
      V v_t_24189 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24188, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str135), v_t_24189});
    }
    default: return heff_nomatch(v_t_24181);
    }
  }
  case TAG_EFix: {
    V v_ru_24t_245_24EFix = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_24192 = heff_take_field(v_i_244, 2);
    switch (heff_tag_of(v_t_24192)) {
    case TAG_True: {
      V v_t_24193 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24194 = (g_heff_2ecompile_2eemit_2ebodyF_24s1905402694x225173429(v_t_24193, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24195 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str136), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str137), heff_strAppend(v_t_24194, ((V)&g_heff_2ecompile_2eemit_2edefBody_str138)))));
      V v_t_24196 = heff_tag_at_n(v_ru_24t_245_24EFix, TAG_Cons, 2, (V[]){v_t_24195, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str139), v_t_24196});
    }
    case TAG_False: {
      V v_t_24197 = heff_rec_n(4, shape_gs__names__used__self, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24198 = heff_tr(g_heff_2ecompile_2eemit_2eexprGo_24s1506938304x1048494276(v_t_24197, MK_INT(0LL), heff_get_n(v_d_243, 2, 3)));
      V v_t_24199 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str140), heff_strAppend(heff_get_n(v_i_244, 0, 4), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2edefBody_str141), heff_strAppend(heff_get_n(v_t_24198, 0, 2), ((V)&g_heff_2ecompile_2eemit_2edefBody_str142)))));
      V v_t_24200 = heff_tag_at_n(v_ru_24t_245_24EFix, TAG_Cons, 2, (V[]){v_t_24199, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2edefBody_str143), v_t_24200});
    }
    default: return heff_nomatch(v_t_24192);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2eemit_2edefBody_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2edefBody(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str0, 10, (36, 102, 114, 111, 109, 66, 121, 116, 101, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str1, 153, (99, 111, 110, 115, 116, 32, 36, 102, 114, 111, 109, 66, 121, 116, 101, 115, 32, 61, 32, 116, 121, 112, 101, 111, 102, 32, 66, 117, 102, 102, 101, 114, 32, 61, 61, 61, 32, 34, 102, 117, 110, 99, 116, 105, 111, 110, 34, 32, 63, 32, 40, 98, 41, 32, 61, 62, 32, 40, 66, 117, 102, 102, 101, 114, 46, 105, 115, 66, 117, 102, 102, 101, 114, 40, 98, 41, 32, 63, 32, 98, 32, 58, 32, 66, 117, 102, 102, 101, 114, 46, 102, 114, 111, 109, 40, 98, 41, 41, 46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 34, 117, 116, 102, 56, 34, 41, 32, 58, 32, 40, 98, 41, 32, 61, 62, 32, 110, 101, 119, 32, 84, 101, 120, 116, 68, 101, 99, 111, 100, 101, 114, 40, 41, 46, 100, 101, 99, 111, 100, 101, 40, 98, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str2, 8, (36, 116, 111, 66, 121, 116, 101, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str3, 115, (99, 111, 110, 115, 116, 32, 36, 116, 111, 66, 121, 116, 101, 115, 32, 61, 32, 116, 121, 112, 101, 111, 102, 32, 66, 117, 102, 102, 101, 114, 32, 61, 61, 61, 32, 34, 102, 117, 110, 99, 116, 105, 111, 110, 34, 32, 63, 32, 40, 115, 41, 32, 61, 62, 32, 66, 117, 102, 102, 101, 114, 46, 102, 114, 111, 109, 40, 115, 44, 32, 34, 117, 116, 102, 56, 34, 41, 32, 58, 32, 40, 115, 41, 32, 61, 62, 32, 110, 101, 119, 32, 84, 101, 120, 116, 69, 110, 99, 111, 100, 101, 114, 40, 41, 46, 101, 110, 99, 111, 100, 101, 40, 115, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str4, 7, (36, 102, 114, 111, 109, 74, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str5, 25, (99, 111, 110, 115, 116, 32, 36, 102, 114, 111, 109, 74, 115, 32, 61, 32, 40, 116, 41, 32, 61, 62, 32, 116, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str6, 5, (36, 116, 111, 74, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2estrHelpers_str7, 23, (99, 111, 110, 115, 116, 32, 36, 116, 111, 74, 115, 32, 61, 32, 40, 115, 41, 32, 61, 62, 32, 115, 59));

static V g_heff_2ecompile_2eemit_2estrHelpers_val;
static int g_heff_2ecompile_2eemit_2estrHelpers_st;
static V g_heff_2ecompile_2eemit_2estrHelpers_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str0), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str1)}), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str2), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str3)}), v_t_240});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str4), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str5)}), v_t_241});
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2estrHelpers_str6), ((V)&g_heff_2ecompile_2eemit_2estrHelpers_str7)}), v_t_242});
}
V g_heff_2ecompile_2eemit_2estrHelpers_get(void) {
  if (g_heff_2ecompile_2eemit_2estrHelpers_st == 2) return g_heff_2ecompile_2eemit_2estrHelpers_val;
  if (g_heff_2ecompile_2eemit_2estrHelpers_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2estrHelpers_st = 1;
  g_heff_2ecompile_2eemit_2estrHelpers_val = heff_tr(g_heff_2ecompile_2eemit_2estrHelpers_init());
  g_heff_2ecompile_2eemit_2estrHelpers_st = 2;
  return g_heff_2ecompile_2eemit_2estrHelpers_val;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2etrampolineStr_str0, 206, (108, 101, 116, 32, 36, 100, 101, 112, 32, 61, 32, 48, 59, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 36, 66, 110, 99, 40, 102, 44, 32, 97, 41, 32, 123, 32, 116, 104, 105, 115, 46, 102, 32, 61, 32, 102, 59, 32, 116, 104, 105, 115, 46, 97, 32, 61, 32, 97, 59, 32, 125, 32, 99, 111, 110, 115, 116, 32, 36, 116, 114, 115, 32, 61, 32, 40, 114, 41, 32, 61, 62, 32, 123, 32, 100, 111, 32, 123, 32, 36, 100, 101, 112, 32, 61, 32, 48, 59, 32, 114, 32, 61, 32, 114, 46, 102, 40, 114, 46, 97, 41, 59, 32, 125, 32, 119, 104, 105, 108, 101, 32, 40, 114, 32, 105, 110, 115, 116, 97, 110, 99, 101, 111, 102, 32, 36, 66, 110, 99, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 59, 32, 125, 59, 32, 99, 111, 110, 115, 116, 32, 36, 116, 114, 32, 61, 32, 40, 114, 41, 32, 61, 62, 32, 114, 32, 105, 110, 115, 116, 97, 110, 99, 101, 111, 102, 32, 36, 66, 110, 99, 32, 63, 32, 36, 116, 114, 115, 40, 114, 41, 32, 58, 32, 114, 59));

static V g_heff_2ecompile_2eemit_2etrampolineStr_val;
static int g_heff_2ecompile_2eemit_2etrampolineStr_st;
static V g_heff_2ecompile_2eemit_2etrampolineStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2etrampolineStr_str0);
}
V g_heff_2ecompile_2eemit_2etrampolineStr_get(void) {
  if (g_heff_2ecompile_2eemit_2etrampolineStr_st == 2) return g_heff_2ecompile_2eemit_2etrampolineStr_val;
  if (g_heff_2ecompile_2eemit_2etrampolineStr_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2etrampolineStr_st = 1;
  g_heff_2ecompile_2eemit_2etrampolineStr_val = heff_tr(g_heff_2ecompile_2eemit_2etrampolineStr_init());
  g_heff_2ecompile_2eemit_2etrampolineStr_st = 2;
  return g_heff_2ecompile_2eemit_2etrampolineStr_val;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eextStr_str0, 217, (99, 111, 110, 115, 116, 32, 36, 101, 120, 116, 32, 61, 32, 40, 118, 41, 32, 61, 62, 32, 116, 121, 112, 101, 111, 102, 32, 118, 32, 61, 61, 61, 32, 34, 102, 117, 110, 99, 116, 105, 111, 110, 34, 32, 63, 32, 40, 120, 41, 32, 61, 62, 32, 36, 101, 120, 116, 40, 36, 116, 114, 40, 118, 40, 120, 41, 41, 41, 32, 58, 32, 118, 32, 33, 61, 61, 32, 110, 117, 108, 108, 32, 38, 38, 32, 116, 121, 112, 101, 111, 102, 32, 118, 32, 61, 61, 61, 32, 34, 111, 98, 106, 101, 99, 116, 34, 32, 38, 38, 32, 33, 65, 114, 114, 97, 121, 46, 105, 115, 65, 114, 114, 97, 121, 40, 118, 41, 32, 38, 38, 32, 33, 40, 34, 36, 34, 32, 105, 110, 32, 118, 41, 32, 63, 32, 79, 98, 106, 101, 99, 116, 46, 102, 114, 111, 109, 69, 110, 116, 114, 105, 101, 115, 40, 79, 98, 106, 101, 99, 116, 46, 101, 110, 116, 114, 105, 101, 115, 40, 118, 41, 46, 109, 97, 112, 40, 40, 91, 108, 44, 32, 120, 93, 41, 32, 61, 62, 32, 91, 108, 44, 32, 36, 101, 120, 116, 40, 120, 41, 93, 41, 41, 32, 58, 32, 118, 59));

static V g_heff_2ecompile_2eemit_2eextStr_val;
static int g_heff_2ecompile_2eemit_2eextStr_st;
static V g_heff_2ecompile_2eemit_2eextStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2eextStr_str0);
}
V g_heff_2ecompile_2eemit_2eextStr_get(void) {
  if (g_heff_2ecompile_2eemit_2eextStr_st == 2) return g_heff_2ecompile_2eemit_2eextStr_val;
  if (g_heff_2ecompile_2eemit_2eextStr_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2eextStr_st = 1;
  g_heff_2ecompile_2eemit_2eextStr_val = heff_tr(g_heff_2ecompile_2eemit_2eextStr_init());
  g_heff_2ecompile_2eemit_2eextStr_st = 2;
  return g_heff_2ecompile_2eemit_2eextStr_val;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str0, 5, (36, 108, 97, 122, 121));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str1, 4, (36, 66, 110, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str2, 6, (36, 102, 111, 114, 99, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str3, 4, (36, 116, 114, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str4, 2, (36, 84));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str5, 2, (36, 70));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str6, 60, (99, 111, 110, 115, 116, 32, 36, 84, 32, 61, 32, 123, 32, 36, 58, 32, 34, 84, 114, 117, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 44, 32, 36, 70, 32, 61, 32, 123, 32, 36, 58, 32, 34, 70, 97, 108, 115, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str7, 60, (99, 111, 110, 115, 116, 32, 36, 84, 32, 61, 32, 123, 32, 36, 58, 32, 34, 84, 114, 117, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 44, 32, 36, 70, 32, 61, 32, 123, 32, 36, 58, 32, 34, 70, 97, 108, 115, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str8, 8, (36, 97, 98, 97, 110, 100, 111, 110));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str9, 60, (99, 111, 110, 115, 116, 32, 36, 97, 98, 97, 110, 100, 111, 110, 32, 61, 32, 40, 41, 32, 61, 62, 32, 123, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 97, 98, 97, 110, 100, 111, 110, 34, 41, 59, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str10, 8, (36, 110, 111, 109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str11, 87, (99, 111, 110, 115, 116, 32, 36, 110, 111, 109, 97, 116, 99, 104, 32, 61, 32, 40, 115, 41, 32, 61, 62, 32, 123, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 32, 110, 111, 32, 99, 97, 115, 101, 32, 102, 111, 114, 32, 39, 34, 32, 43, 32, 40, 115, 32, 38, 38, 32, 115, 46, 36, 41, 32, 43, 32, 34, 39, 34, 41, 59, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str12, 6, (36, 102, 111, 114, 99, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str13, 125, (99, 111, 110, 115, 116, 32, 36, 102, 111, 114, 99, 101, 32, 61, 32, 40, 102, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 102, 46, 36, 109, 32, 33, 61, 61, 32, 117, 110, 100, 101, 102, 105, 110, 101, 100, 41, 32, 114, 101, 116, 117, 114, 110, 32, 102, 46, 36, 109, 59, 32, 99, 111, 110, 115, 116, 32, 118, 32, 61, 32, 36, 116, 114, 40, 102, 40, 123, 32, 36, 58, 32, 34, 77, 107, 85, 110, 105, 116, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 41, 41, 59, 32, 102, 46, 36, 109, 32, 61, 32, 118, 59, 32, 114, 101, 116, 117, 114, 110, 32, 118, 59, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str14, 5, (36, 108, 97, 122, 121));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntime_str15, 243, (99, 111, 110, 115, 116, 32, 36, 108, 97, 122, 121, 32, 61, 32, 40, 102, 41, 32, 61, 62, 32, 123, 32, 108, 101, 116, 32, 115, 116, 97, 116, 101, 32, 61, 32, 48, 44, 32, 118, 59, 32, 114, 101, 116, 117, 114, 110, 32, 40, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 115, 116, 97, 116, 101, 32, 61, 61, 61, 32, 50, 41, 32, 114, 101, 116, 117, 114, 110, 32, 118, 59, 32, 105, 102, 32, 40, 115, 116, 97, 116, 101, 32, 61, 61, 61, 32, 49, 41, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 32, 100, 101, 102, 105, 110, 101, 100, 32, 98, 121, 32, 105, 116, 115, 101, 108, 102, 34, 41, 59, 32, 115, 116, 97, 116, 101, 32, 61, 32, 49, 59, 32, 116, 114, 121, 32, 123, 32, 118, 32, 61, 32, 36, 116, 114, 40, 102, 40, 41, 41, 59, 32, 115, 116, 97, 116, 101, 32, 61, 32, 50, 59, 32, 114, 101, 116, 117, 114, 110, 32, 118, 59, 32, 125, 32, 102, 105, 110, 97, 108, 108, 121, 32, 123, 32, 105, 102, 32, 40, 115, 116, 97, 116, 101, 32, 61, 61, 61, 32, 49, 41, 32, 115, 116, 97, 116, 101, 32, 61, 32, 48, 59, 32, 125, 32, 125, 59, 32, 125, 59));
V g_heff_2ecompile_2eemit_2eruntime_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eruntime_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eruntime_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntime_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eruntime(V v_code_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str2), v_t_241})});
  V v_t_246 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eruntime_lam0, 1, 1, (V[]){heff_dup(v_code_240)}); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str3), v_t_242}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get())});
    break;
  }
  case TAG_False: {
    v_t_247 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_x3_248 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eruntime_str4), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2412;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    V v_x3_249 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eruntime_str5), heff_dup(v_code_240), MK_INT(0LL)));
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 0ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str6)});
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_248_24Just = heff_take_reuse_n(v_x3_248, 0ULL, 1);
    v_t_2412 = heff_tag_at_n(v_ru_24x3_248_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str7)});
    break;
  }
  default: heff_nomatch(v_x3_248);
  }
  V v_x3_2413 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eruntime_str8), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2415;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2413_24Just = heff_take_reuse_n(v_x3_2413, 0ULL, 1);
    v_t_2415 = heff_tag_at_n(v_ru_24x3_2413_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str9)});
    break;
  }
  default: heff_nomatch(v_x3_2413);
  }
  V v_x3_2416 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eruntime_str10), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2418;
  switch (heff_tag_of(v_x3_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2416_24Just = heff_take_reuse_n(v_x3_2416, 0ULL, 1);
    v_t_2418 = heff_tag_at_n(v_ru_24x3_2416_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str11)});
    break;
  }
  default: heff_nomatch(v_x3_2416);
  }
  V v_x3_2419 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eruntime_str12), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2421;
  switch (heff_tag_of(v_x3_2419)) {
  case TAG_Nothing: {
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2419_24Just = heff_take_reuse_n(v_x3_2419, 0ULL, 1);
    v_t_2421 = heff_tag_at_n(v_ru_24x3_2419_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str13)});
    break;
  }
  default: heff_nomatch(v_x3_2419);
  }
  V v_x3_2422 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eruntime_str14), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2424;
  switch (heff_tag_of(v_x3_2422)) {
  case TAG_Nothing: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2422_24Just = heff_take_reuse_n(v_x3_2422, 0ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24x3_2422_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2ecompile_2eemit_2eruntime_str15)});
    break;
  }
  default: heff_nomatch(v_x3_2422);
  }
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2426})});
  V v_t_2428 = (g_heff_2ecompile_2eemit_2ecatMaybesL(heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2427})));
  V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eruntime_lam1, 1, 1, (V[]){v_code_240}), heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get())));
  V v_t_2435 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2434));
  return (g_prelude_2e_2b_2b(v_t_2428, v_t_2435));
}
V g_heff_2ecompile_2eemit_2eruntime_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eruntime(a[0]);
}
V g_heff_2ecompile_2eemit_2eruntime_lam0(V self, V *args) {
  V v_k_243 = args[0];
  V v_code_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_244 = (g_prelude_2eindexFrom(v_k_243, v_code_240, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2eemit_2eruntime_lam1(V self, V *args) {
  V v_h_2429 = args[0];
  V v_code_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_h_2429)) {
  case TAG_MkPair: {
    V v_k_2430 = heff_field(v_h_2429, 0);
    V v_line_2431 = heff_field(v_h_2429, 1);
    heff_take_n(v_h_2429, 3ULL, 2);
    V v_x3_2432 = (g_prelude_2eindexFrom(v_k_2430, v_code_240, MK_INT(0LL)));
    switch (heff_tag_of(v_x3_2432)) {
    case TAG_Nothing: {
      heff_drop(v_line_2431);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_ru_24x3_2432_24Just = heff_take_reuse_n(v_x3_2432, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x3_2432_24Just, TAG_Just, 1, (V[]){v_line_2431});
    }
    default: return heff_nomatch(v_x3_2432);
    }
  }
  default: return heff_nomatch(v_h_2429);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemit_2euncurryGo_str0, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2euncurryGo_str1, 5, (41, 32, 61, 62, 32));
Clo g_heff_2ecompile_2eemit_2euncurryGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2euncurryGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2euncurryGo(V v_ps_240, V v_s_241) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_s_241), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2eemit_2euncurryGo_str0))) {
    V v_t_243 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
    V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2euncurryGo_str1), v_t_243, MK_INT(0LL)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
      return heff_rec_n(2, shape_params__body, (V[]){v_t_245, v_s_241});
    }
    case TAG_Just: {
      V v_i_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_247 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
      V v_t_248 = (g_heff_2ecompile_2eemit_2eisIdent(heff_strSlice(v_t_247, MK_INT(0LL), heff_dup(v_i_246))));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V v_t_249 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice(v_t_249, MK_INT(0LL), heff_dup(v_i_246)), v_ps_240});
        V v_t_2411 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
        V v_t_2412 = heff_intSub(heff_strLength(v_s_241), MK_INT(1LL));
        V v_t_2413 = heff_strSlice(v_t_2411, heff_intAdd(v_i_246, MK_INT(5LL)), v_t_2412);
        V t_0 = v_t_2410;
        V t_1 = v_t_2413;
        v_ps_240 = t_0;
        v_s_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_i_246);
        V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
        return heff_rec_n(2, shape_params__body, (V[]){v_t_2414, v_s_241});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_240));
    return heff_rec_n(2, shape_params__body, (V[]){v_t_2415, v_s_241});
  }
}
V g_heff_2ecompile_2eemit_2euncurryGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2euncurryGo(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUses_str0, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUses_str1, 2, (36, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUses_str2, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUses_str3, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUses_str4, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimUses_str5, 1, (40));
Clo g_heff_2ecompile_2eemit_2eprimUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimUses_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprimUses(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_m_240;
  }
  case TAG_EGlobal: {
    return v_m_240;
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_e_241, 1);
    V t_0 = v_m_240;
    V t_1 = v_b_245;
    v_m_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_e_241, 0);
    V v_as_247 = heff_field(v_e_241, 1);
    V v_t_248 = (g_heff_2ecompile_2eemit_2eprimUses(v_m_240, v_f_246));
    return (g_list_2efoldl(((V)&g_heff_2ecompile_2eemit_2eprimUses_clo), v_t_248, v_as_247));
  }
  case TAG_ELet: {
    V v_e1_2410 = heff_field(v_e_241, 1);
    V v_b_2411 = heff_field(v_e_241, 2);
    V v_t_2412 = (g_heff_2ecompile_2eemit_2eprimUses(v_m_240, v_e1_2410));
    V t_0 = v_t_2412;
    V t_1 = v_b_2411;
    v_m_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_e_241, 0);
    HEFF_LAST return g_list_2efoldl_24s776813750x121415612(v_m_240, v_fs_2413);
  }
  case TAG_EProj: {
    V v_e2_2414 = heff_field(v_e_241, 0);
    V t_0 = v_m_240;
    V t_1 = v_e2_2414;
    v_m_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2418 = heff_field(v_e_241, 1);
    return (g_list_2efoldl(((V)&g_heff_2ecompile_2eemit_2eprimUses_clo), v_m_240, v_as_2418));
  }
  case TAG_EMatch: {
    V v_s_2419 = heff_field(v_e_241, 0);
    V v_arms_2420 = heff_field(v_e_241, 1);
    V v_t_2421 = (g_heff_2ecompile_2eemit_2eprimUses(v_m_240, v_s_2419));
    HEFF_LAST return g_list_2efoldl_24s426392081x749835614(v_t_2421, v_arms_2420);
  }
  case TAG_EPrim: {
    V v_p_2422 = heff_field(v_e_241, 0);
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str0), heff_strAppend(heff_dup(v_p_2422), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str1)));
    return (g_map_2einsert_24s1341440536x470972936(v_t_2423, NTAG(TAG_MkUnit), v_m_240));
  }
  case TAG_EPrimCall: {
    V v_p_2424 = heff_field(v_e_241, 0);
    V v_as_2425 = heff_field(v_e_241, 1);
    V v_t_2439;
    switch (heff_tag_of(v_as_2425)) {
    case TAG_Nil: {
      V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str2), heff_strAppend(heff_dup(v_p_2424), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str3)));
      v_t_2439 = (g_map_2einsert_24s1341440536x470972936(v_t_2426, NTAG(TAG_MkUnit), v_m_240));
      break;
    }
    case TAG_Cons: {
      V v_it2_2428 = heff_field(v_as_2425, 1);
      V v_t_2437;
      switch (heff_tag_of(v_it2_2428)) {
      case TAG_Nil: {
        V v_x3_2429 = (g_heff_2ecompile_2eemit_2eprimUnary(heff_dup(v_p_2424)));
        switch (heff_tag_of(v_x3_2429)) {
        case TAG_Nothing: {
          v_t_2437 = NTAG(TAG_True);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2429, 0ULL, 1);
          v_t_2437 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x3_2429);
        }
        break;
      }
      case TAG_Cons: {
        V v_it22_2432 = heff_field(v_it2_2428, 1);
        switch (heff_tag_of(v_it22_2432)) {
        case TAG_Nil: {
          V v_x3_2433 = (g_heff_2ecompile_2eemit_2eprimOp(heff_dup(v_p_2424)));
          switch (heff_tag_of(v_x3_2433)) {
          case TAG_Nothing: {
            v_t_2437 = NTAG(TAG_True);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_x3_2433, 0ULL, 1);
            v_t_2437 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x3_2433);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2437 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it22_2432);
        }
        break;
      }
      default: heff_nomatch(v_it2_2428);
      }
      switch (heff_tag_of(v_t_2437)) {
      case TAG_True: {
        V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimUses_str4), heff_strAppend(heff_dup(v_p_2424), ((V)&g_heff_2ecompile_2eemit_2eprimUses_str5)));
        v_t_2439 = (g_map_2einsert_24s1341440536x470972936(v_t_2438, NTAG(TAG_MkUnit), v_m_240));
        break;
      }
      case TAG_False: {
        v_t_2439 = v_m_240;
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      break;
    }
    default: heff_nomatch(v_as_2425);
    }
    return (g_list_2efoldl(((V)&g_heff_2ecompile_2eemit_2eprimUses_clo), v_t_2439, v_as_2425));
  }
  case TAG_ECall: {
    V v_as_2441 = heff_field(v_e_241, 1);
    return (g_list_2efoldl(((V)&g_heff_2ecompile_2eemit_2eprimUses_clo), v_m_240, v_as_2441));
  }
  case TAG_EInt: {
    return v_m_240;
  }
  case TAG_EFloat: {
    return v_m_240;
  }
  case TAG_EStr: {
    return v_m_240;
  }
  case TAG_EFixed: {
    return v_m_240;
  }
  case TAG_EFloat32: {
    return v_m_240;
  }
  case TAG_EAbandon: {
    return v_m_240;
  }
  case TAG_EFix: {
    return v_m_240;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eemit_2eprimUses_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eprimUses(a[0], a[1]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str0, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str1, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str2, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str3, 2, (36, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str5, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str6, 7, (99, 111, 110, 115, 116, 32, 36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str7, 4, (32, 61, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str8, 5, (41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str9, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str11, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str12, 7, (99, 111, 110, 115, 116, 32, 36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str13, 4, (32, 61, 32, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str14, 5, (41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str15, 1, (59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str16, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str17, 2, (36, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str18, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str19, 5, (41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str20, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str21, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str22, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str23, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str24, 7, (99, 111, 110, 115, 116, 32, 36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str25, 5, (36, 99, 32, 61, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str26, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str27, 1, (40));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprimHelperU_str28, 2, (41, 59));
Clo g_heff_2ecompile_2eemit_2eprimHelperU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimHelperU_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprimHelperU(V v_uses_240, V v_p_241, V v_u_242) {
top: ;
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str0), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str1)));
  V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(v_t_243, v_uses_240));
  V v_t_2419;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str2), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str3)));
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(v_t_245, v_uses_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      V v_t_248 = heff_dup(heff_rfield(v_u_242, 0));
      V v_t_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        V v_xs_2410 = heff_field(v_t_248, 1);
        heff_take_n(v_t_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str6), heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str7), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str8), heff_strAppend(heff_dup(heff_rfield(v_u_242, 1)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str9)))))));
      v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    V v_t_2414 = heff_dup(heff_rfield(v_u_242, 0));
    V v_t_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      V v_xs_2416 = heff_field(v_t_2414, 1);
      heff_take_n(v_t_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str11); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str12), heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str13), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str14), heff_strAppend(heff_dup(heff_rfield(v_u_242, 1)), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str15)))))));
    v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str16), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str17)));
  V v_x3_2421 = (g_map_2elookup_24s659669741x1036301430(v_t_2420, v_uses_240));
  V v_t_2423;
  switch (heff_tag_of(v_x3_2421)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2421, 0ULL, 1);
    v_t_2423 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2421);
  }
  V v_t_2433;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    V v_x2_2424 = (g_list_2emap_24s499977176x606563528(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str18), ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str19), heff_dup(heff_rfield(v_u_242, 0))));
    V v_t_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str21); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2428 = heff_get_n(v_u_242, 0, 2);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_t_2428, 0);
      V v_xs_2430 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str23); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str24), heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str25), heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str26), heff_strAppend(v_p_241, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str27), heff_strAppend(v_t_2431, ((V)&g_heff_2ecompile_2eemit_2eprimHelperU_str28)))))))));
    v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    heff_drop(v_p_241);
    heff_drop_rec(v_u_242, 2);
    v_t_2433 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  return (g_prelude_2e_2b_2b(v_t_2419, v_t_2433));
}
V g_heff_2ecompile_2eemit_2eprimHelperU_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eprimHelperU(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemit_2eprimHelpers_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eprimHelpers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprimHelpers_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eprimHelpers(V v_defs_240) {
top: ;
  V v_uses_241 = (g_list_2efoldl_24s554524976x621147349(heff_dup(g_map_2eempty_get()), v_defs_240));
  V v_xs_242 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get());
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eprimHelpers_lam0, 2, 1, (V[]){v_uses_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_heff_2ecompile_2eemit_2eprimHelpers_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eprimHelpers(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemit_2eprimHelpers_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_uses_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_x_245)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x_245, 0);
    V v_i_247 = heff_field(v_x_245, 1);
    heff_take_n(v_x_245, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2eemit_2euncurryGo(NTAG(TAG_Nil), heff_get_n(v_i_247, 1, 2)));
    v_t_249 = ({ V a_0 = v_uses_241; V a_1 = v_p_246; V a_2 = v_t_248; V r_ = (g_heff_2ecompile_2eemit_2eprimHelperU(a_0, a_1, a_2)); heff_drop(v_uses_241); r_; });
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_244));
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsPick_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsPick_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsPick_str2, 1, (120));
V g_heff_2ecompile_2eemit_2ejsPick_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ejsPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsPick_entry, 3, 0};

V g_heff_2ecompile_2eemit_2ejsPick(V v_shorts_240, V v_key_241, V v_s_242) {
top: ;
  V v_xs_244 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemit_2ejsPick_lam0, 1, 1, (V[]){heff_dup(v_s_242)}), v_shorts_240));
  V v_a_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_244; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
  if (heff_intLt_c(MK_INT(1LL), v_a_245)) {
    heff_drop(v_s_242);
    V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_key_241)), MK_INT(1LL));
    V v_t_248 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_key_241), v_t_247));
    V v_t_249 = (g_heff_2ecompile_2eemit_2espellAt(v_key_241, v_t_248));
    V v_s_2410 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_249, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ejsPick_str0)));
    V v_t_2412;
    if (heff_strEq_c(heff_dup(v_s_2410), ((V)&g_heff_2ecompile_2eemit_2ejsPick_str1))) {
      heff_drop(v_s_2410);
      v_t_2412 = ((V)&g_heff_2ecompile_2eemit_2ejsPick_str2);
    } else {
      v_t_2412 = v_s_2410;
    }
    return (g_heff_2ecompile_2eemit_2esafeRes(v_t_2412));
  } else {
    heff_drop(v_key_241);
    return v_s_242;
  }
}
V g_heff_2ecompile_2eemit_2ejsPick_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ejsPick(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2ejsPick_lam0(V self, V *args) {
  V v_t_243 = args[0];
  V v_s_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_t_243, v_s_242);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsNameOf_str0, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsNameOf_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsNameOf_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsNameOf_str3, 1, (120));
Clo g_heff_2ecompile_2eemit_2ejsNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsNameOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ejsNameOf(V v_shorts_240, V v_key_241) {
top: ;
  V v_xs_242 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str0), heff_dup(v_key_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_242));
  V v_x2_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_x2_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_x2_246 = heff_tag_n(TAG_Just, 1, (V[]){v_x_244});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_x0_248;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    v_x0_248 = heff_dup(v_key_241);
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    v_x0_248 = v_x_247;
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_x0_248)), MK_INT(1LL));
  V v_t_2410 = (g_heff_2ecompile_2eemit_2elastDotFrom(heff_dup(v_x0_248), v_t_249));
  V v_t_2411 = (g_heff_2ecompile_2eemit_2espellAt(v_x0_248, v_t_2410));
  V v_s_2412 = (g_heff_2ecompile_2eemit_2esafeChars(v_t_2411, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str1)));
  V v_t_2414;
  if (heff_strEq_c(heff_dup(v_s_2412), ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str2))) {
    heff_drop(v_s_2412);
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ejsNameOf_str3);
  } else {
    v_t_2414 = v_s_2412;
  }
  V v_t_2415 = (g_heff_2ecompile_2eemit_2esafeRes(v_t_2414));
  return (g_heff_2ecompile_2eemit_2ejsPick(v_shorts_240, v_key_241, v_t_2415));
}
V g_heff_2ecompile_2eemit_2ejsNameOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ejsNameOf(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2elazyOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2elazyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2elazyOf_entry, 4, 0};

V g_heff_2ecompile_2eemit_2elazyOf(V v_acc_240, V v_key_241, V v_b_242, V v_ar_243) {
top: ;
  if (heff_intEq_c(v_ar_243, MK_INT(0LL))) {
    V v_t_245 = (g_heff_2ecompile_2eir_2eisValue(v_b_242));
    V v_x1_2413;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_242));
      V v_t_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
      v_x1_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2elazyOf_lam0, 1, 2, (V[]){v_key_241, heff_dup(v_acc_240)}); V a_1 = v_t_247; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_247); r_; });
      break;
    }
    case TAG_False: {
      heff_drop(v_key_241);
      heff_drop(v_b_242);
      v_x1_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2413);
    }
  } else {
    heff_drop(v_key_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2eemit_2elazyOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2elazyOf(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemit_2elazyOf_lam0(V self, V *args) {
  V v_k_248 = args[0];
  V v_key_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(v_k_248), v_key_241)) {
    heff_drop(v_k_248);
    heff_drop(v_acc_240);
    return NTAG(TAG_False);
  } else {
    V v_t_2410 = ({ V a_0 = v_k_248; V a_1 = v_acc_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_acc_240); r_; });
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_i_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      V v_t_2412 = heff_get_n(v_i_2411, 2, 4);
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
}
Clo g_heff_2ecompile_2eemit_2einfoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2einfoOne_entry, 4, 0};

V g_heff_2ecompile_2eemit_2einfoOne(V v_shorts_240, V v_bnc_241, V v_acc_242, V v_d_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eemit_2ejsNameOf(v_shorts_240, heff_dup(heff_rfield(v_d_243, 0))));
  V v_t_245 = heff_dup(heff_rfield(v_d_243, 2));
  V v_t_2436;
  switch (heff_tag_of(v_t_245)) {
  case TAG_EVar: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 2);
    v_t_2436 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_245, 0ULL, 3);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_245, 0ULL, 3);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EAbandon: {
    v_t_2436 = MK_INT(0LL);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2436 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2437 = heff_dup(heff_rfield(v_d_243, 2));
  V v_t_2468;
  switch (heff_tag_of(v_t_2437)) {
  case TAG_EVar: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_ELam: {
    V v_xs_2440 = heff_field(v_t_2437, 0);
    heff_take_n(v_t_2437, 1ULL, 2);
    v_t_2468 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2440; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2440); r_; });
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_2437, 0ULL, 3);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_2437, 0ULL, 3);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_t_2437, 0ULL, 1);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EAbandon: {
    v_t_2468 = MK_INT(0LL);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_2437, 0ULL, 2);
    v_t_2468 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_2437);
  }
  V v_t_2469 = (g_heff_2ecompile_2eemit_2elazyOf(v_acc_242, heff_dup(heff_rfield(v_d_243, 0)), heff_take_field(v_d_243, 2), v_t_2468));
  V v_x3_2470 = (g_map_2elookup_24s659669741x1036301430(heff_dup(heff_rfield(v_d_243, 0)), v_bnc_241));
  V v_t_2472;
  switch (heff_tag_of(v_x3_2470)) {
  case TAG_Nothing: {
    v_t_2472 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2470, 0ULL, 1);
    v_t_2472 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2470);
  }
  return (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_243, 0, 3), heff_rec_n(4, shape_js__arity__lazy__bounce, (V[]){v_t_244, v_t_2436, v_t_2469, v_t_2472}), v_acc_242));
}
V g_heff_2ecompile_2eemit_2einfoOne_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2einfoOne(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eemitCode_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eemitCode_str1, 1, (10));
V g_heff_2ecompile_2eemit_2eemitCode_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eemitCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eemitCode_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eemitCode(V v_defs_240, V v_info_241, V v_curried_242, V v_globalNames_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_240)));
  V v_code_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eemitCode_lam0, 2, 3, (V[]){heff_dup(v_info_241), heff_dup(v_curried_242), v_globalNames_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_helpers_2411 = ({ V a_0 = v_defs_240; V r_ = (g_heff_2ecompile_2eemit_2eprimHelpers(a_0)); heff_drop(v_defs_240); r_; });
  V v_x2_2412 = (g_prelude_2e_2b_2b(heff_dup(v_helpers_2411), heff_dup(v_code_2410)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2eemitCode_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eemitCode_str1); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = (g_heff_2ecompile_2eemit_2eruntime(v_t_2415));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_helpers_2411, v_code_2410));
  V v_t_2418 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2417));
  return heff_rec_n(2, shape_lines__globals, (V[]){v_t_2418, v_info_241});
}
V g_heff_2ecompile_2eemit_2eemitCode_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eemitCode(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2ecompile_2eemit_2eemitCode_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_info_241 = heff_env(self)[0];
  V v_curried_242 = heff_env(self)[1];
  V v_globalNames_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_x_246, 0)), v_info_241));
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_246, 3);
    heff_drop(v_info_241);
    heff_drop(v_curried_242);
    heff_drop(v_globalNames_243);
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = ({ V a_0 = v_info_241; V a_1 = v_curried_242; V a_2 = v_globalNames_243; V a_3 = v_x_246; V a_4 = v_i_248; V r_ = (g_heff_2ecompile_2eemit_2edefBody(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_curried_242); r_; });
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_245));
}
V g_heff_2ecompile_2eemit_2eemitWithShorts_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eemitWithShorts_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eemitWithShorts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eemitWithShorts_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eemitWithShorts(V v_defs_240, V v_roots_241, V v_shorts_242) {
top: ;
  V v_bnc_243 = (g_heff_2ecompile_2eemit_2ebounceGo(v_defs_240, heff_dup(g_map_2eempty_get())));
  V v_t_246 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2eemitWithShorts_lam0, 2, 2, (V[]){heff_dup(v_shorts_242), v_bnc_243}), heff_dup(g_map_2eempty_get()), v_defs_240));
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_240)));
  V v_t_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1787334480x145092089(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_xs_249 = (g_prelude_2e_2b_2b(v_t_248, v_roots_241));
  V v_t_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_xs_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eemitWithShorts_lam1, 1, 1, (V[]){v_shorts_242}), heff_dup(v_defs_240)));
  V v_t_2413 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2412; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2412); r_; });
  return ({ V a_0 = v_defs_240; V a_1 = v_t_246; V a_2 = v_t_2410; V a_3 = v_t_2413; V r_ = (g_heff_2ecompile_2eemit_2eemitCode(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
}
V g_heff_2ecompile_2eemit_2eemitWithShorts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eemitWithShorts(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemit_2eemitWithShorts_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_d_245 = args[1];
  V v_shorts_242 = heff_env(self)[0];
  V v_bnc_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_shorts_242; V a_1 = v_bnc_243; V a_2 = v_acc_244; V a_3 = v_d_245; V r_ = (g_heff_2ecompile_2eemit_2einfoOne(a_0, a_1, a_2, a_3)); heff_drop(v_bnc_243); r_; });
}
V g_heff_2ecompile_2eemit_2eemitWithShorts_lam1(V self, V *args) {
  V v_d_2411 = args[0];
  V v_shorts_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eemit_2ejsNameOf(v_shorts_242, heff_get_n(v_d_2411, 0, 3)));
}
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str0, 2, (125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str1, 44, (32, 32, 36, 112, 101, 114, 102, 111, 114, 109, 101, 114, 32, 61, 32, 40, 112, 44, 32, 107, 41, 32, 61, 62, 32, 112, 101, 114, 102, 111, 114, 109, 40, 112, 44, 32, 110, 111, 119, 40, 107, 41, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str2, 22, (32, 32, 114, 101, 116, 117, 114, 110, 32, 36, 116, 114, 40, 101, 110, 116, 114, 121, 40, 41, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str3, 16, (32, 32, 108, 101, 116, 32, 100, 101, 112, 116, 104, 32, 61, 32, 48, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str4, 129, (32, 32, 99, 111, 110, 115, 116, 32, 110, 111, 119, 32, 61, 32, 40, 107, 41, 32, 61, 62, 32, 40, 120, 41, 32, 61, 62, 32, 123, 32, 120, 32, 61, 32, 36, 116, 114, 40, 120, 41, 59, 32, 105, 102, 32, 40, 100, 101, 112, 116, 104, 32, 62, 32, 49, 48, 48, 48, 41, 32, 123, 32, 100, 101, 112, 116, 104, 32, 61, 32, 48, 59, 32, 108, 97, 116, 101, 114, 40, 40, 41, 32, 61, 62, 32, 36, 116, 114, 40, 107, 40, 120, 41, 41, 41, 59, 32, 114, 101, 116, 117, 114, 110, 59, 32, 125, 32, 100, 101, 112, 116, 104, 43, 43, 59, 32, 36, 116, 114, 40, 107, 40, 120, 41, 41, 59, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str5, 34, (99, 111, 110, 115, 116, 32, 36, 114, 117, 110, 32, 61, 32, 40, 101, 110, 116, 114, 121, 44, 32, 112, 101, 114, 102, 111, 114, 109, 41, 32, 61, 62, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str6, 92, (32, 32, 99, 111, 110, 115, 116, 32, 108, 97, 116, 101, 114, 32, 61, 32, 116, 121, 112, 101, 111, 102, 32, 115, 101, 116, 73, 109, 109, 101, 100, 105, 97, 116, 101, 32, 61, 61, 61, 32, 34, 102, 117, 110, 99, 116, 105, 111, 110, 34, 32, 63, 32, 115, 101, 116, 73, 109, 109, 101, 100, 105, 97, 116, 101, 32, 58, 32, 40, 102, 41, 32, 61, 62, 32, 115, 101, 116, 84, 105, 109, 101, 111, 117, 116, 40, 102, 44, 32, 48, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str7, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunStr_str8, 15, (108, 101, 116, 32, 36, 112, 101, 114, 102, 111, 114, 109, 101, 114, 59));

static V g_heff_2ecompile_2eemit_2erunStr_val;
static int g_heff_2ecompile_2eemit_2erunStr_st;
static V g_heff_2ecompile_2eemit_2erunStr_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunStr_str6), v_t_242})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunStr_str7); V a_1 = ((V)&g_heff_2ecompile_2eemit_2erunStr_str8); V a_2 = v_t_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_243, 2); r_; });
}
V g_heff_2ecompile_2eemit_2erunStr_get(void) {
  if (g_heff_2ecompile_2eemit_2erunStr_st == 2) return g_heff_2ecompile_2eemit_2erunStr_val;
  if (g_heff_2ecompile_2eemit_2erunStr_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2erunStr_st = 1;
  g_heff_2ecompile_2eemit_2erunStr_val = heff_tr(g_heff_2ecompile_2eemit_2erunStr_init());
  g_heff_2ecompile_2eemit_2erunStr_st = 2;
  return g_heff_2ecompile_2eemit_2erunStr_val;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2esumStr_str0, 77, (99, 111, 110, 115, 116, 32, 36, 115, 117, 109, 32, 61, 32, 40, 108, 44, 32, 114, 41, 32, 61, 62, 32, 40, 112, 44, 32, 107, 41, 32, 61, 62, 32, 112, 46, 36, 32, 61, 61, 61, 32, 34, 73, 110, 76, 34, 32, 63, 32, 108, 40, 112, 46, 97, 91, 48, 93, 44, 32, 107, 41, 32, 58, 32, 114, 40, 112, 46, 97, 91, 48, 93, 44, 32, 107, 41, 59));

static V g_heff_2ecompile_2eemit_2esumStr_val;
static int g_heff_2ecompile_2eemit_2esumStr_st;
static V g_heff_2ecompile_2eemit_2esumStr_init(void) {
  return ((V)&g_heff_2ecompile_2eemit_2esumStr_str0);
}
V g_heff_2ecompile_2eemit_2esumStr_get(void) {
  if (g_heff_2ecompile_2eemit_2esumStr_st == 2) return g_heff_2ecompile_2eemit_2esumStr_val;
  if (g_heff_2ecompile_2eemit_2esumStr_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2esumStr_st = 1;
  g_heff_2ecompile_2eemit_2esumStr_val = heff_tr(g_heff_2ecompile_2eemit_2esumStr_init());
  g_heff_2ecompile_2eemit_2esumStr_st = 2;
  return g_heff_2ecompile_2eemit_2esumStr_val;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str0, 5, (125, 41, 40, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str1, 105, (32, 32, 32, 32, 114, 101, 108, 101, 97, 115, 101, 58, 32, 40, 105, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 116, 32, 61, 32, 97, 116, 40, 105, 41, 59, 32, 116, 104, 105, 110, 103, 115, 46, 100, 101, 108, 101, 116, 101, 40, 105, 41, 59, 32, 110, 117, 109, 98, 101, 114, 115, 46, 100, 101, 108, 101, 116, 101, 40, 116, 46, 120, 41, 59, 32, 105, 102, 32, 40, 116, 46, 102, 114, 101, 101, 41, 32, 116, 46, 102, 114, 101, 101, 40, 116, 46, 120, 41, 59, 32, 125, 44));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str2, 4, (32, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str3, 145, (32, 32, 32, 32, 104, 111, 108, 100, 58, 32, 40, 120, 44, 32, 102, 114, 101, 101, 41, 32, 61, 62, 32, 123, 32, 108, 101, 116, 32, 105, 32, 61, 32, 110, 117, 109, 98, 101, 114, 115, 46, 103, 101, 116, 40, 120, 41, 59, 32, 105, 102, 32, 40, 105, 32, 61, 61, 61, 32, 117, 110, 100, 101, 102, 105, 110, 101, 100, 41, 32, 123, 32, 105, 32, 61, 32, 110, 101, 120, 116, 43, 43, 59, 32, 110, 117, 109, 98, 101, 114, 115, 46, 115, 101, 116, 40, 120, 44, 32, 105, 41, 59, 32, 116, 104, 105, 110, 103, 115, 46, 115, 101, 116, 40, 105, 44, 32, 123, 32, 120, 44, 32, 102, 114, 101, 101, 32, 125, 41, 59, 32, 125, 32, 114, 101, 116, 117, 114, 110, 32, 105, 59, 32, 125, 44));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str4, 24, (32, 32, 32, 32, 103, 101, 116, 58, 32, 40, 105, 41, 32, 61, 62, 32, 97, 116, 40, 105, 41, 46, 120, 44));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str5, 131, (32, 32, 99, 111, 110, 115, 116, 32, 97, 116, 32, 61, 32, 40, 105, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 116, 32, 61, 32, 116, 104, 105, 110, 103, 115, 46, 103, 101, 116, 40, 105, 41, 59, 32, 105, 102, 32, 40, 33, 116, 41, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 32, 116, 104, 101, 32, 119, 111, 114, 108, 100, 32, 104, 111, 108, 100, 115, 32, 110, 111, 116, 104, 105, 110, 103, 32, 110, 117, 109, 98, 101, 114, 101, 100, 32, 34, 32, 43, 32, 105, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 116, 59, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str6, 10, (32, 32, 114, 101, 116, 117, 114, 110, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str7, 48, (32, 32, 99, 111, 110, 115, 116, 32, 116, 104, 105, 110, 103, 115, 32, 61, 32, 110, 101, 119, 32, 77, 97, 112, 40, 41, 44, 32, 110, 117, 109, 98, 101, 114, 115, 32, 61, 32, 110, 101, 119, 32, 77, 97, 112, 40, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str8, 16, (32, 32, 108, 101, 116, 32, 110, 101, 120, 116, 32, 61, 32, 48, 110, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str9, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2eworldStr_str10, 23, (99, 111, 110, 115, 116, 32, 36, 119, 111, 114, 108, 100, 32, 61, 32, 40, 40, 41, 32, 61, 62, 32, 123));

static V g_heff_2ecompile_2eemit_2eworldStr_val;
static int g_heff_2ecompile_2eemit_2eworldStr_st;
static V g_heff_2ecompile_2eemit_2eworldStr_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2eworldStr_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eworldStr_str9); V a_1 = ((V)&g_heff_2ecompile_2eemit_2eworldStr_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ecompile_2eemit_2eworldStr_get(void) {
  if (g_heff_2ecompile_2eemit_2eworldStr_st == 2) return g_heff_2ecompile_2eemit_2eworldStr_val;
  if (g_heff_2ecompile_2eemit_2eworldStr_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2eworldStr_st = 1;
  g_heff_2ecompile_2eemit_2eworldStr_val = heff_tr(g_heff_2ecompile_2eemit_2eworldStr_init());
  g_heff_2ecompile_2eemit_2eworldStr_st = 2;
  return g_heff_2ecompile_2eemit_2eworldStr_val;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eexportNameOf_str0, 13, (101, 120, 112, 111, 114, 116, 32, 99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2eexportNameOf_str1, 1, (32));
Clo g_heff_2ecompile_2eemit_2eexportNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eexportNameOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eexportNameOf(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(13LL)), ((V)&g_heff_2ecompile_2eemit_2eexportNameOf_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength(heff_dup(v_l_240)));
    V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2eexportNameOf_str1), v_t_242, MK_INT(0LL)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength(v_l_240));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_strSlice(v_l_240, MK_INT(13LL), heff_intAdd(MK_INT(13LL), v_i_245));
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_246});
    }
    default: return heff_nomatch(v_t_243);
    }
  } else {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eemit_2eexportNameOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2eexportNameOf(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ehostLineOf_str0, 22, (101, 120, 112, 111, 114, 116, 32, 99, 111, 110, 115, 116, 32, 36, 104, 111, 115, 116, 32, 61, 32, 34));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehostLineOf_str1, 1, (34));
Clo g_heff_2ecompile_2eemit_2ehostLineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ehostLineOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2ehostLineOf(V v_l_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2ecompile_2eemit_2ehostLineOf_str0))) {
    V v_t_242 = heff_strSlice(heff_dup(v_l_240), MK_INT(22LL), heff_strLength(heff_dup(v_l_240)));
    V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2eemit_2ehostLineOf_str1), v_t_242, MK_INT(0LL)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = heff_strSlice(heff_dup(v_l_240), MK_INT(22LL), heff_strLength(v_l_240));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_strSlice(v_l_240, MK_INT(22LL), heff_intAdd(MK_INT(22LL), v_i_245));
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_246});
    }
    default: return heff_nomatch(v_t_243);
    }
  } else {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2eemit_2ehostLineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ehostLineOf(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str0, 3, (47, 47, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str1, 12, (46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 106, 115));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str2, 8, (99, 111, 110, 115, 116, 32, 36, 112));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str3, 11, (32, 61, 32, 40, 40, 41, 32, 61, 62, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str4, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str5, 7, (105, 109, 112, 111, 114, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str6, 13, (101, 120, 112, 111, 114, 116, 32, 99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str7, 6, (99, 111, 110, 115, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str8, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str9, 1, (36));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str11, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str12, 9, (114, 101, 116, 117, 114, 110, 32, 123, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str13, 3, (32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str14, 5, (125, 41, 40, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str15, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ebundleProvider_str16, 1, (10));
Clo g_heff_2ecompile_2eemit_2ebundleProvider_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleProvider_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleProvider(V v_i_240, V v_p_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str0), heff_strAppend(heff_dup(heff_rfield(v_p_241, 0)), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str2), heff_strAppend(heff_intShow(v_i_240), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str3)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  V v_t_245 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str4), heff_dup(heff_rfield(v_p_241, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2efilter_24s413688307x112671032(MK_INT(0LL), MK_INT(7LL), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str5), v_t_245));
  V v_t_247 = (g_list_2emap_24s1654555371x977048649(MK_INT(0LL), MK_INT(13LL), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str6), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str7), MK_INT(13LL), v_t_246));
  V v_t_248 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str8), heff_get_n(v_p_241, 1, 2), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_249 = (g_list_2emap_24s732475005x1616712052(v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_249));
  V v_x2_2411 = (g_list_2efilter_24s413688307x112671032(MK_INT(0LL), MK_INT(1LL), ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str9), v_t_2410));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str11); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str12), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str13)));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str14), NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2416})));
  V v_x2_2418 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_244}), v_t_2417));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str15);
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ebundleProvider_str16); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eemit_2ebundleProvider_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleProvider(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemit_2ebundleAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ebundleAll_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ebundleAll(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_242));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_heff_2ecompile_2eemit_2ebundleAll(heff_intAdd(v_i_240, MK_INT(1LL)), v_rest_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ebundleAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ebundleAll(a[0], a[1]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eprovStrHelpers_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eprovStrHelpers_str1, 1, (10));
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam2(V self, V *args);
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2eprovStrHelpers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovStrHelpers_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprovStrHelpers(V v_have_240, V v_provs_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24s1917746138x1825516092(v_provs_241));
  V v_text_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_text_245 = ((V)&g_heff_2ecompile_2eemit_2eprovStrHelpers_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_text_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eprovStrHelpers_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0, 1, 1, (V[]){v_text_245}), heff_dup(g_heff_2ecompile_2eemit_2estrHelpers_get())));
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2411));
  HEFF_LAST return g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemit_2eprovStrHelpers_lam1, 1, 1, (V[]){heff_dup(v_have_240)}), v_t_2412);
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eprovStrHelpers(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam0(V self, V *args) {
  V v_h_246 = args[0];
  V v_text_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_h_246)) {
  case TAG_MkPair: {
    V v_k_247 = heff_field(v_h_246, 0);
    V v_line_248 = heff_field(v_h_246, 1);
    heff_take_n(v_h_246, 3ULL, 2);
    V v_x3_249 = (g_prelude_2eindexFrom(v_k_247, v_text_245, MK_INT(0LL)));
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      heff_drop(v_line_248);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){v_line_248});
    }
    default: return heff_nomatch(v_x3_249);
    }
  }
  default: return heff_nomatch(v_h_246);
  }
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam2(V self, V *args) {
  V v_h_2414 = args[0];
  V v_l_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_h_2414, v_l_2413);
}
V g_heff_2ecompile_2eemit_2eprovStrHelpers_lam1(V self, V *args) {
  V v_l_2413 = args[0];
  V v_have_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2415 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eemit_2eprovStrHelpers_lam2, 1, 1, (V[]){v_l_2413}); V a_1 = v_have_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_have_240); r_; });
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntimeFor_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2eruntimeFor_str1, 1, (10));
Clo g_heff_2ecompile_2eemit_2eruntimeFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eruntimeFor_entry, 4, 0};

V g_heff_2ecompile_2eemit_2eruntimeFor(V v_hasTr_240, V v_have_241, V v_provs_242, V v_eff_243) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_hasTr_240)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_Nil);
    break;
  }
  case TAG_False: {
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_hasTr_240);
  }
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eworldStr_get()), NTAG(TAG_Nil)});
  V v_t_246 = (g_prelude_2e_2b_2b(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2erunStr_get()), v_t_245})));
  V v_t_2410;
  switch (heff_tag_of(v_eff_243)) {
  case TAG_Leaf: {
    heff_take_n(v_eff_243, 0ULL, 1);
    v_t_2410 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Plus: {
    V v_ru_24eff_243_24Plus = heff_take_reuse_n(v_eff_243, 0ULL, 2);
    v_t_2410 = heff_tag_at_n(v_ru_24eff_243_24Plus, TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2esumStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_eff_243);
  }
  V v_t_2411 = (g_heff_2ecompile_2eemit_2eprovStrHelpers(v_have_241, heff_dup(v_provs_242)));
  V v_t_2412 = (g_heff_2ecompile_2eemit_2ebundleAll(MK_INT(0LL), v_provs_242));
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2412));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  V v_x2_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str0);
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2eruntimeFor_str1); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eemit_2eruntimeFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eruntimeFor(a[0], a[1], a[2], a[3]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemit_2eprovIndexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovIndexGo_entry, 3, 0};

V g_heff_2ecompile_2eemit_2eprovIndexGo(V v_i_240, V v_md_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_md_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(v_md_241))) {
      heff_drop(v_md_241);
      return v_i_240;
    } else {
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_md_241;
      V t_2 = v_rest_244;
      v_i_240 = t_0;
      v_md_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemit_2eprovIndexGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eprovIndexGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str0, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str2, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str3, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str4, 2, (36, 112));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str5, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str6, 8, (40, 36, 119, 111, 114, 108, 100, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str7, 5, (36, 115, 117, 109, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str8, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2ehandlerOf_str9, 1, (41));
Clo g_heff_2ecompile_2eemit_2ehandlerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ehandlerOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ehandlerOf(V v_provs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str0), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_244 = (g_heff_2eelab_2eeffect_2edropLastD(v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = (g_heff_2ecompile_2eemit_2eprovIndexGo(MK_INT(0LL), v_t_247, v_provs_240));
    V v_t_249 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str3), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2410 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_249; V r_ = (g_heff_2eelab_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_249); r_; });
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str4), heff_strAppend(heff_intShow(v_t_248), heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str6)))));
  }
  case TAG_Plus: {
    V v_a_2411 = heff_field(v_x2_241, 0);
    V v_b_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_a_2411));
    V v_t_2414 = (g_heff_2ecompile_2eemit_2ehandlerOf(v_provs_240, v_b_2412));
    return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str7), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str8), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemit_2ehandlerOf_str9)))));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2ehandlerOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2ehandlerOf(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemit_2efindProv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2efindProv_entry, 2, 0};

V g_heff_2ecompile_2eemit_2efindProv(V v_md_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_md_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_p_242, 0)), heff_dup(v_md_240))) {
      heff_drop(v_md_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    } else {
      V t_0 = v_md_240;
      V t_1 = v_rest_243;
      v_md_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2efindProv_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2efindProv(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2eemit_2eprovsForGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eprovsForGo_entry, 2, 0};

V g_heff_2ecompile_2eemit_2eprovsForGo(V v_available_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_md_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemit_2efindProv(v_md_242, v_available_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_available_240;
      V t_1 = v_rest_243;
      v_available_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_p_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_p_245, (g_heff_2ecompile_2eemit_2eprovsForGo(v_available_240, v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemit_2eprovsForGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eprovsForGo(a[0], a[1]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2eimportLinesOf_str0, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2eimportLinesOf_str1, 7, (105, 109, 112, 111, 114, 116, 32));
Clo g_heff_2ecompile_2eemit_2eimportLinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2eimportLinesOf_entry, 1, 0};

V g_heff_2ecompile_2eemit_2eimportLinesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str0), heff_dup(heff_rfield(v_p_241, 1)), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_244 = (g_list_2efilter_24s926921591x156811372(MK_INT(0LL), MK_INT(7LL), ((V)&g_heff_2ecompile_2eemit_2eimportLinesOf_str1), v_t_243));
    V v_t_245 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_rest_242));
    return (g_prelude_2e_2b_2b(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemit_2eimportLinesOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2eimportLinesOf(a[0]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeHead_str0, 53, (105, 109, 112, 111, 114, 116, 32, 123, 32, 115, 112, 97, 119, 110, 32, 97, 115, 32, 36, 115, 112, 97, 119, 110, 32, 125, 32, 102, 114, 111, 109, 32, 34, 110, 111, 100, 101, 58, 99, 104, 105, 108, 100, 95, 112, 114, 111, 99, 101, 115, 115, 34, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeHead_str1, 42, (47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeHead_str2, 114, (105, 109, 112, 111, 114, 116, 32, 123, 32, 87, 111, 114, 107, 101, 114, 32, 97, 115, 32, 36, 87, 111, 114, 107, 101, 114, 44, 32, 105, 115, 77, 97, 105, 110, 84, 104, 114, 101, 97, 100, 32, 97, 115, 32, 36, 105, 115, 77, 97, 105, 110, 84, 104, 114, 101, 97, 100, 44, 32, 112, 97, 114, 101, 110, 116, 80, 111, 114, 116, 32, 97, 115, 32, 36, 112, 97, 114, 101, 110, 116, 80, 111, 114, 116, 32, 125, 32, 102, 114, 111, 109, 32, 34, 110, 111, 100, 101, 58, 119, 111, 114, 107, 101, 114, 95, 116, 104, 114, 101, 97, 100, 115, 34, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeHead_str3, 19, (35, 33, 47, 117, 115, 114, 47, 98, 105, 110, 47, 101, 110, 118, 32, 110, 111, 100, 101));

static V g_heff_2ecompile_2eemit_2enodeHead_val;
static int g_heff_2ecompile_2eemit_2enodeHead_st;
static V g_heff_2ecompile_2eemit_2enodeHead_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeHead_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeHead_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeHead_str2), v_t_240})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeHead_str3), v_t_241});
}
V g_heff_2ecompile_2eemit_2enodeHead_get(void) {
  if (g_heff_2ecompile_2eemit_2enodeHead_st == 2) return g_heff_2ecompile_2eemit_2enodeHead_val;
  if (g_heff_2ecompile_2eemit_2enodeHead_st == 1) heff_fail("defined by itself");
  g_heff_2ecompile_2eemit_2enodeHead_st = 1;
  g_heff_2ecompile_2eemit_2enodeHead_val = heff_tr(g_heff_2ecompile_2eemit_2enodeHead_init());
  g_heff_2ecompile_2eemit_2enodeHead_st = 2;
  return g_heff_2ecompile_2eemit_2enodeHead_val;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str0, 1, (125));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str1, 2, (32, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str2, 8, (125, 32, 101, 108, 115, 101, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str3, 79, (32, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 111, 110, 99, 101, 40, 34, 114, 101, 115, 117, 109, 101, 34, 44, 32, 40, 41, 32, 61, 62, 32, 36, 112, 97, 114, 101, 110, 116, 80, 111, 114, 116, 46, 112, 111, 115, 116, 77, 101, 115, 115, 97, 103, 101, 40, 123, 32, 115, 116, 100, 105, 110, 58, 32, 116, 114, 117, 101, 32, 125, 41, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str4, 70, (32, 32, 32, 32, 99, 104, 105, 108, 100, 46, 111, 110, 40, 34, 101, 120, 105, 116, 34, 44, 32, 40, 115, 116, 97, 116, 117, 115, 41, 32, 61, 62, 32, 123, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 115, 116, 97, 116, 117, 115, 32, 63, 63, 32, 49, 59, 32, 125, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str5, 5, (32, 32, 125, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str6, 65, (32, 32, 32, 32, 99, 111, 110, 115, 116, 32, 99, 104, 105, 108, 100, 32, 61, 32, 36, 115, 112, 97, 119, 110, 40, 101, 120, 101, 99, 91, 48, 93, 44, 32, 101, 120, 101, 99, 91, 49, 93, 44, 32, 123, 32, 115, 116, 100, 105, 111, 58, 32, 34, 105, 110, 104, 101, 114, 105, 116, 34, 32, 125, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str7, 82, (32, 32, 32, 32, 99, 104, 105, 108, 100, 46, 111, 110, 40, 34, 101, 114, 114, 111, 114, 34, 44, 32, 40, 101, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 111, 108, 101, 46, 101, 114, 114, 111, 114, 40, 101, 46, 109, 101, 115, 115, 97, 103, 101, 41, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 49, 59, 32, 125, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str8, 79, (32, 32, 32, 32, 105, 102, 32, 40, 112, 105, 112, 101, 100, 41, 32, 123, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 117, 110, 112, 105, 112, 101, 40, 119, 111, 114, 107, 101, 114, 46, 115, 116, 100, 105, 110, 41, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 100, 101, 115, 116, 114, 111, 121, 40, 41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str9, 51, (32, 32, 32, 32, 105, 102, 32, 40, 33, 101, 120, 101, 99, 41, 32, 123, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 99, 111, 100, 101, 59, 32, 114, 101, 116, 117, 114, 110, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str10, 73, (32, 32, 119, 111, 114, 107, 101, 114, 46, 111, 110, 40, 34, 101, 114, 114, 111, 114, 34, 44, 32, 40, 101, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 111, 108, 101, 46, 101, 114, 114, 111, 114, 40, 101, 41, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 49, 59, 32, 125, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str11, 31, (32, 32, 119, 111, 114, 107, 101, 114, 46, 111, 110, 40, 34, 101, 120, 105, 116, 34, 44, 32, 40, 99, 111, 100, 101, 41, 32, 61, 62, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str12, 35, (32, 32, 32, 32, 105, 102, 32, 40, 109, 32, 38, 38, 32, 109, 46, 101, 120, 101, 99, 41, 32, 101, 120, 101, 99, 32, 61, 32, 109, 46, 101, 120, 101, 99, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str13, 5, (32, 32, 125, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str14, 31, (32, 32, 119, 111, 114, 107, 101, 114, 46, 111, 110, 40, 34, 109, 101, 115, 115, 97, 103, 101, 34, 44, 32, 40, 109, 41, 32, 61, 62, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str15, 83, (32, 32, 32, 32, 105, 102, 32, 40, 109, 32, 38, 38, 32, 109, 46, 115, 116, 100, 105, 110, 32, 38, 38, 32, 33, 112, 105, 112, 101, 100, 41, 32, 123, 32, 112, 105, 112, 101, 100, 32, 61, 32, 116, 114, 117, 101, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 112, 105, 112, 101, 40, 119, 111, 114, 107, 101, 114, 46, 115, 116, 100, 105, 110, 41, 59, 32, 125));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str16, 125, (32, 32, 99, 111, 110, 115, 116, 32, 119, 111, 114, 107, 101, 114, 32, 61, 32, 110, 101, 119, 32, 36, 87, 111, 114, 107, 101, 114, 40, 110, 101, 119, 32, 85, 82, 76, 40, 105, 109, 112, 111, 114, 116, 46, 109, 101, 116, 97, 46, 117, 114, 108, 41, 44, 32, 123, 32, 97, 114, 103, 118, 58, 32, 112, 114, 111, 99, 101, 115, 115, 46, 97, 114, 103, 118, 46, 115, 108, 105, 99, 101, 40, 50, 41, 44, 32, 114, 101, 115, 111, 117, 114, 99, 101, 76, 105, 109, 105, 116, 115, 58, 32, 108, 105, 109, 105, 116, 115, 44, 32, 115, 116, 100, 105, 110, 58, 32, 116, 114, 117, 101, 32, 125, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str17, 33, (32, 32, 108, 101, 116, 32, 112, 105, 112, 101, 100, 32, 61, 32, 102, 97, 108, 115, 101, 44, 32, 101, 120, 101, 99, 32, 61, 32, 110, 117, 108, 108, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str18, 55, (32, 32, 105, 102, 32, 40, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 111, 117, 116, 46, 105, 115, 84, 84, 89, 41, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 110, 118, 46, 72, 69, 70, 70, 95, 84, 84, 89, 32, 61, 32, 34, 49, 34, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str19, 109, (32, 32, 99, 111, 110, 115, 116, 32, 108, 105, 109, 105, 116, 115, 32, 61, 32, 123, 32, 115, 116, 97, 99, 107, 83, 105, 122, 101, 77, 98, 58, 32, 53, 49, 50, 44, 32, 109, 97, 120, 79, 108, 100, 71, 101, 110, 101, 114, 97, 116, 105, 111, 110, 83, 105, 122, 101, 77, 98, 58, 32, 78, 117, 109, 98, 101, 114, 40, 112, 114, 111, 99, 101, 115, 115, 46, 101, 110, 118, 46, 72, 69, 70, 70, 95, 72, 69, 65, 80, 95, 77, 66, 41, 32, 124, 124, 32, 117, 110, 100, 101, 102, 105, 110, 101, 100, 32, 125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str20, 1, (10));
HEFF_STRA(g_heff_2ecompile_2eemit_2enodeRun_str21, 20, (105, 102, 32, 40, 36, 105, 115, 77, 97, 105, 110, 84, 104, 114, 101, 97, 100, 41, 32, 123));
Clo g_heff_2ecompile_2eemit_2enodeRun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2enodeRun_entry, 1, 0};

V g_heff_2ecompile_2eemit_2enodeRun(V v_run_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemit_2enodeRun_str1), v_run_240), v_t_241});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str3), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str5), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str7), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str9), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str11), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str13), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str15), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str16), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str17), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str18), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2enodeRun_str19), v_t_2410})});
  return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2enodeRun_str20); V a_1 = ((V)&g_heff_2ecompile_2eemit_2enodeRun_str21); V a_2 = v_t_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2411, 2); r_; });
}
V g_heff_2ecompile_2eemit_2enodeRun_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2enodeRun(a[0]);
}
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str0, 4, (110, 111, 100, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str1, 42, (47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str2, 9, (117, 110, 100, 101, 102, 105, 110, 101, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str3, 2, (36, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str4, 2, (40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str5, 11, (36, 114, 117, 110, 40, 40, 41, 32, 61, 62, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str6, 2, (44, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str7, 2, (41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str8, 4, (110, 111, 100, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str9, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str10, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str11, 4, (112, 97, 103, 101));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str12, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str13, 13, (34, 117, 115, 101, 32, 115, 116, 114, 105, 99, 116, 34, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str14, 5, (125, 41, 40, 41, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str15, 8, (40, 40, 41, 32, 61, 62, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str16, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str17, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2erunSource_str18, 1, (10));
Clo g_heff_2ecompile_2eemit_2erunSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2erunSource_entry, 5, 0};

V g_heff_2ecompile_2eemit_2erunSource(V v_host_240, V v_provs_241, V v_eff_242, V v_key_243, V v_m_244) {
top: ;
  V v_t_246;
  if (heff_strEq_c(heff_dup(v_host_240), ((V)&g_heff_2ecompile_2eemit_2erunSource_str0))) {
    v_t_246 = heff_dup(g_heff_2ecompile_2eemit_2enodeHead_get());
  } else {
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str1), NTAG(TAG_Nil)});
  }
  V v_xs_247 = (g_heff_2ecompile_2eemit_2eimportLinesOf(v_provs_241));
  V v_t_248 = (g_heff_2ecompile_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_247));
  V v_t_249 = (g_list_2eany_24s651308273x925219243(heff_rfield(v_m_244, 0)));
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = heff_rfield(v_m_244, 0); V a_2 = heff_dup(v_provs_241); V a_3 = heff_dup(v_eff_242); V r_ = (g_heff_2ecompile_2eemit_2eruntimeFor(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), heff_rfield(v_m_244, 1)));
  V v_t_2415;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str2);
    break;
  }
  case TAG_Just: {
    V v_i_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_2412, 1)))) {
      v_t_2415 = heff_strAppend(heff_get_n(v_i_2412, 0, 4), ((V)&g_heff_2ecompile_2eemit_2erunSource_str3));
    } else {
      V v_t_2414 = heff_take_field(v_i_2412, 2);
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        v_t_2415 = heff_strAppend(heff_get_n(v_i_2412, 0, 4), ((V)&g_heff_2ecompile_2eemit_2erunSource_str4));
        break;
      }
      case TAG_False: {
        v_t_2415 = heff_get_n(v_i_2412, 0, 4);
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
    }
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_t_2416 = ({ V a_0 = v_provs_241; V a_1 = v_eff_242; V r_ = (g_heff_2ecompile_2eemit_2ehandlerOf(a_0, a_1)); heff_drop(v_provs_241); heff_drop(v_eff_242); r_; });
  V v_run_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str5), heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2erunSource_str6), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemit_2erunSource_str7)))));
  V v_t_2419;
  if (heff_strEq_c(heff_dup(v_host_240), ((V)&g_heff_2ecompile_2eemit_2erunSource_str8))) {
    v_t_2419 = (g_heff_2ecompile_2eemit_2enodeRun(v_run_2417));
  } else {
    v_t_2419 = v_run_2417;
  }
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str9), v_t_2420})});
  V v_body_2422 = (g_prelude_2e_2b_2b(heff_get_n(v_m_244, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str10), v_t_2421})));
  V v_t_2427;
  if (heff_strEq_c(v_host_240, ((V)&g_heff_2ecompile_2eemit_2erunSource_str11))) {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str12), NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str13), (g_prelude_2e_2b_2b(v_body_2422, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str14), v_t_2424})))});
    v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str15), v_t_2425});
  } else {
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2erunSource_str16), NTAG(TAG_Nil)});
    v_t_2427 = (g_prelude_2e_2b_2b(v_body_2422, v_t_2426));
  }
  V v_t_2428 = (g_prelude_2e_2b_2b(v_t_248, v_t_2427));
  V v_x2_2429 = (g_prelude_2e_2b_2b(v_t_246, v_t_2428));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2erunSource_str17);
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_xs_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2erunSource_str18); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2eemit_2erunSource_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2erunSource(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileLowered_str0, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileLowered_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileLowered_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileLowered_str3, 1, (120));
Clo g_heff_2ecompile_2eemit_2ecompileLowered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileLowered_entry, 5, 0};

V g_heff_2ecompile_2eemit_2ecompileLowered(V v_host_240, V v_provs_241, V v_eff_242, V v_key_243, V v_l_244) {
top: ;
  V v_defs_245 = heff_take_field(v_l_244, 0);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_247 = (g_list_2emap_24s1438389342x1293406880(((V)&g_heff_2ecompile_2eemit_2ecompileLowered_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ecompileLowered_str1), ((V)&g_heff_2ecompile_2eemit_2ecompileLowered_str2), ((V)&g_heff_2ecompile_2eemit_2ecompileLowered_str3), heff_dup(v_defs_245)));
  V v_t_248 = (g_heff_2ecompile_2eemit_2eemitWithShorts(v_defs_245, v_t_246, v_t_247));
  V v_t_249 = (g_heff_2ecompile_2eemit_2erunSource(v_host_240, v_provs_241, v_eff_242, v_key_243, v_t_248));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_249, heff_get_n(v_l_244, 1, 2)});
}
V g_heff_2ecompile_2eemit_2ecompileLowered_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2ecompileLowered(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str0, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str1, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str2, 1, (34));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str3, 9, (117, 110, 100, 101, 102, 105, 110, 101, 100));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str4, 2, (36, 99));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str5, 2, (40, 41));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str6, 6, (32, 32, 103, 101, 116, 32));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str7, 17, (40, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 36, 101, 120, 116, 40));
HEFF_STRA(g_heff_2ecompile_2eemit_2egetterOf_str8, 5, (41, 59, 32, 125, 44));
Clo g_heff_2ecompile_2eemit_2egetterOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2egetterOf_entry, 2, 0};

V g_heff_2ecompile_2eemit_2egetterOf(V v_gs_240, V v_o_241) {
top: ;
  V v_x_242 = heff_take_field(v_o_241, 0);
  V v_t_243 = (g_heff_2ecompile_2eemit_2eisIdent(heff_dup(v_x_242)));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_245 = v_x_242;
    break;
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2ecompile_2eemit_2equoteGo(v_x_242, MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2egetterOf_str0)));
    v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str1), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2eemit_2egetterOf_str2)));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_get_n(v_o_241, 1, 2), v_gs_240));
  V v_t_2410;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_2410 = ((V)&g_heff_2ecompile_2eemit_2egetterOf_str3);
    break;
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    if (heff_intLe_c(MK_INT(2LL), heff_dup(heff_rfield(v_i_247, 1)))) {
      v_t_2410 = heff_strAppend(heff_get_n(v_i_247, 0, 4), ((V)&g_heff_2ecompile_2eemit_2egetterOf_str4));
    } else {
      V v_t_249 = heff_take_field(v_i_247, 2);
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_strAppend(heff_get_n(v_i_247, 0, 4), ((V)&g_heff_2ecompile_2eemit_2egetterOf_str5));
        break;
      }
      case TAG_False: {
        v_t_2410 = heff_get_n(v_i_247, 0, 4);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str6), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ecompile_2eemit_2egetterOf_str7), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemit_2egetterOf_str8)))));
}
V g_heff_2ecompile_2eemit_2egetterOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eemit_2egetterOf(a[0], a[1]); heff_drop(a[0]); return r;
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str0, 42, (47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str1, 16, (101, 120, 112, 111, 114, 116, 32, 100, 101, 102, 97, 117, 108, 116, 32, 123));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str3, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str4, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str5, 2, (125, 59));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str6, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ejsSource_str7, 1, (10));
V g_heff_2ecompile_2eemit_2ejsSource_lam0(V self, V *args);
V g_heff_2ecompile_2eemit_2ejsSource_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ejsSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ejsSource_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ejsSource(V v_exports_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str0), NTAG(TAG_Nil)});
  V v_t_243 = (g_list_2eany_24s651308273x925219243(heff_rfield(v_m_241, 0)));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_Nil);
    break;
  }
  case TAG_False: {
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str1), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemit_2eextStr_get()), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str2), v_t_245})});
  V v_t_247 = (g_prelude_2e_2b_2b(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str3), v_t_246})));
  V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemit_2ejsSource_lam0, 1, 1, (V[]){heff_dup(v_m_241)}), v_exports_240));
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eemit_2ejsSource_lam1, 1, 1, (V[]){heff_dup(v_m_241)}), v_t_2411));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str4), NTAG(TAG_Nil)});
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemit_2ejsSource_str5), v_t_2414})));
  V v_t_2416 = (g_prelude_2e_2b_2b(v_t_247, v_t_2415));
  V v_t_2417 = (g_prelude_2e_2b_2b(heff_get_n(v_m_241, 0, 2), v_t_2416));
  V v_x2_2418 = (g_prelude_2e_2b_2b(v_t_242, v_t_2417));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eemit_2ejsSource_str6);
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ecompile_2eemit_2ejsSource_str7); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eemit_2ejsSource_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ejsSource(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2ejsSource_lam0(V self, V *args) {
  V v_o_248 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_249 = ({ V a_0 = heff_get_n(v_o_248, 1, 2); V b_1 = heff_get_n(v_m_241, 1, 2); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_249, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_heff_2ecompile_2eemit_2ejsSource_lam1(V self, V *args) {
  V v_o_2412 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_m_241, 1, 2); V a_1 = v_o_2412; V r_ = (g_heff_2ecompile_2eemit_2egetterOf(b_0, a_1)); heff_drop(b_0); r_; });
}
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileExports_str0, 1, (46));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileExports_str1, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileExports_str2, 0, (0));
HEFF_STRA(g_heff_2ecompile_2eemit_2ecompileExports_str3, 1, (120));
Clo g_heff_2ecompile_2eemit_2ecompileExports_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileExports_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecompileExports(V v_exports_240, V v_l_241) {
top: ;
  V v_defs_242 = heff_take_field(v_l_241, 0);
  V v_roots_243 = (g_list_2emap_24s634984521x2042558081(heff_dup(v_exports_240)));
  V v_t_244 = (g_list_2emap_24s1438389342x1293406880(((V)&g_heff_2ecompile_2eemit_2ecompileExports_str0), MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemit_2ecompileExports_str1), ((V)&g_heff_2ecompile_2eemit_2ecompileExports_str2), ((V)&g_heff_2ecompile_2eemit_2ecompileExports_str3), heff_dup(v_defs_242)));
  V v_t_245 = (g_heff_2ecompile_2eemit_2eemitWithShorts(v_defs_242, v_roots_243, v_t_244));
  V v_t_246 = (g_heff_2ecompile_2eemit_2ejsSource(v_exports_240, v_t_245));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_246, heff_get_n(v_l_241, 1, 2)});
}
V g_heff_2ecompile_2eemit_2ecompileExports_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecompileExports(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2ecompileJs_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemit_2ecompileJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemit_2ecompileJs_entry, 2, 0};

V g_heff_2ecompile_2eemit_2ecompileJs(V v_g_240, V v_exports0_241) {
top: ;
  V v_exports_249;
  switch (heff_tag_of(v_exports0_241)) {
  case TAG_Nil: {
    V v_t_246 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemit_2ecompileJs_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
    v_exports_249 = (g_list_2emap_24s565104239x2094869705(v_t_246));
    break;
  }
  case TAG_Cons: {
    v_exports_249 = v_exports0_241;
    break;
  }
  default: heff_nomatch(v_exports0_241);
  }
  V v_roots_2410 = (g_list_2emap_24s634984521x2042558081(heff_dup(v_exports_249)));
  V v_t_2411 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_g_240));
  V v_t_2412 = (g_heff_2ecompile_2elower_2elowerErased(v_roots_2410, v_t_2411));
  HEFF_LAST return g_heff_2ecompile_2eemit_2ecompileExports(v_exports_249, v_t_2412);
}
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemit_2ecompileJs(a[0], a[1]);
}
V g_heff_2ecompile_2eemit_2ecompileJs_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get_n(v_g_240, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}