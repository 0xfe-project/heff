// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Expected 48537
#define TAG_Failed 62128
#define TAG_Got 19224
#define TAG_InArray 20296
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_Value 50841
V g_json_2edigitsEnd(V, V);
V g_json_2edigitsEnd_entry(V self, V *a);
extern Clo g_json_2edigitsEnd_clo;
V g_json_2ekeyThen(V, V, V, V);
V g_json_2ekeyThen_entry(V self, V *a);
extern Clo g_json_2ekeyThen_clo;
V g_json_2enumberAfterDigits(V, V, V, V);
V g_json_2enumberAfterDigits_entry(V self, V *a);
extern Clo g_json_2enumberAfterDigits_clo;
V g_json_2eskipSpace(V, V);
V g_json_2eskipSpace_entry(V self, V *a);
extern Clo g_json_2eskipSpace_clo;
V g_json_2esteps_2evalueAt_240(V, V, V);
V g_json_2esteps_2evalueAt_240_entry(V self, V *a);
extern Clo g_json_2esteps_2evalueAt_240_clo;
HeffT3 g_json_2estringAt_2estringFrom_240_24cpr(V, V, V, V);
HEFF_LIT(g_json_2esteps_2evalueAt_240_str0, 0, "");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str1, 8, "a string");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str2, 4, "null");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str3, 7, "a value");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str4, 4, "true");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str5, 7, "a value");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str6, 5, "false");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str7, 7, "a value");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str8, 7, "a value");
HEFF_LIT(g_json_2esteps_2evalueAt_240_str9, 7, "a digit");
Clo g_json_2esteps_2evalueAt_240_clo = {{0x80000000u, K_CLO, 0}, g_json_2esteps_2evalueAt_240_entry, 3, 0};

V g_json_2esteps_2evalueAt_240(V v_s_240, V v_i_241, V v_frames_242) {
top: ;
  V v_c_243 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
  if ((heff_peek_word(v_c_243) == ((int64_t)34ULL))) {
    heff_drop(v_c_243);
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)34ULL))) {
      HeffT3 v_t_244 = ({ V a_0 = v_s_240; V a_1 = heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)); V a_2 = heff_intAdd(v_i_241, MK_INT(1LL)); V a_3 = ((V)&g_json_2esteps_2evalueAt_240_str0); HeffT3 r_ = (g_json_2estringAt_2estringFrom_240_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_s_240); r_; });
      {
        V v_field_246 = v_t_244.f[1];
        V v_field_247 = v_t_244.f[2];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          heff_drop(v_frames_242);
          heff_drop(v_field_247);
          V v_e_248 = v_field_246;
          return heff_tag_n(TAG_Failed, 1, (V[]){v_e_248});
        } else {
          V v_x_249 = v_field_246;
          V v_j_2410 = v_field_247;
          return heff_tag_n(TAG_Got, 3, (V[]){heff_tag_n(TAG_JString, 1, (V[]){v_x_249}), v_j_2410, v_frames_242});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_frames_242);
      return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2esteps_2evalueAt_240_str1)})});
    }
  } else {
    if ((heff_peek_word(v_c_243) == ((int64_t)123ULL))) {
      heff_drop(v_c_243);
      V v_j_2411 = (g_json_2eskipSpace(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL))));
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2411, 0)) == ((int64_t)125ULL))) {
        heff_drop(v_s_240);
        V v_t_2412 = heff_tag_n(TAG_JObject, 1, (V[]){NTAG(TAG_Nil)});
        return heff_tag_n(TAG_Got, 3, (V[]){v_t_2412, heff_intAdd(v_j_2411, MK_INT(1LL)), v_frames_242});
      } else {
        return (g_json_2ekeyThen(v_s_240, v_j_2411, NTAG(TAG_Nil), v_frames_242));
      }
    } else {
      if ((heff_peek_word(v_c_243) == ((int64_t)91ULL))) {
        heff_drop(v_c_243);
        V v_j_2413 = (g_json_2eskipSpace(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL))));
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_2413, 1)) == ((int64_t)93ULL))) {
          V v_t_2414 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Got, 3, (V[]){v_t_2414, heff_intAdd(v_j_2413, MK_INT(1LL)), v_frames_242});
        } else {
          V v_t_2415 = heff_tag_n(TAG_InArray, 1, (V[]){NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Value, 2, (V[]){v_j_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_frames_242})});
        }
      } else {
        if ((heff_peek_word(v_c_243) == ((int64_t)110ULL))) {
          heff_drop(v_c_243);
          V v_t_2416 = heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(4LL)));
          if (heff_strEq_c(v_t_2416, ((V)&g_json_2esteps_2evalueAt_240_str2))) {
            return heff_tag_n(TAG_Got, 3, (V[]){NTAG(TAG_JNull), heff_intAdd(v_i_241, MK_INT(4LL)), v_frames_242});
          } else {
            heff_drop(v_frames_242);
            return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2esteps_2evalueAt_240_str3)})});
          }
        } else {
          if ((heff_peek_word(v_c_243) == ((int64_t)116ULL))) {
            heff_drop(v_c_243);
            V v_t_2417 = heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(4LL)));
            if (heff_strEq_c(v_t_2417, ((V)&g_json_2esteps_2evalueAt_240_str4))) {
              V v_t_2418 = heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
              return heff_tag_n(TAG_Got, 3, (V[]){v_t_2418, heff_intAdd(v_i_241, MK_INT(4LL)), v_frames_242});
            } else {
              heff_drop(v_frames_242);
              return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2esteps_2evalueAt_240_str5)})});
            }
          } else {
            if ((heff_unbox_word(v_c_243) == ((int64_t)102ULL))) {
              V v_t_2419 = heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(5LL)));
              if (heff_strEq_c(v_t_2419, ((V)&g_json_2esteps_2evalueAt_240_str6))) {
                V v_t_2420 = heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_False)});
                return heff_tag_n(TAG_Got, 3, (V[]){v_t_2420, heff_intAdd(v_i_241, MK_INT(5LL)), v_frames_242});
              } else {
                heff_drop(v_frames_242);
                return heff_tag_n(TAG_Failed, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_i_241, ((V)&g_json_2esteps_2evalueAt_240_str7)})});
              }
            } else {
              V v_s_2421 = v_s_240;
              V v_j_2422 = v_i_241;
              V v_d_2423;
              if ((heff_unbox_word(heff_strByteAt_lent(v_s_2421, v_j_2422, 0)) == ((int64_t)45ULL))) {
                v_d_2423 = heff_intAdd(heff_dup(v_j_2422), MK_INT(1LL));
              } else {
                v_d_2423 = heff_dup(v_j_2422);
              }
              V v_x3_2427;
              if ((heff_unbox_word(heff_strByteAt_lent(v_s_2421, v_d_2423, 0)) == ((int64_t)48ULL))) {
                v_x3_2427 = ({ V a_0 = v_s_2421; V a_1 = v_j_2422; V a_2 = heff_dup(v_d_2423); V a_3 = heff_intAdd(v_d_2423, MK_INT(1LL)); V r_ = (g_json_2enumberAfterDigits(a_0, a_1, a_2, a_3)); heff_drop(v_s_2421); heff_drop(v_j_2422); r_; });
              } else {
                V v_c_2424 = heff_strByteAt_lent(v_s_2421, v_d_2423, 0);
                if (((((int64_t)48ULL) <= heff_peek_word(v_c_2424)) && (heff_peek_word(v_c_2424) <= ((int64_t)57ULL)))) {
                  heff_drop(v_c_2424);
                  V v_t_2425 = (g_json_2edigitsEnd(v_s_2421, heff_dup(v_d_2423)));
                  v_x3_2427 = ({ V a_0 = v_s_2421; V a_1 = v_j_2422; V a_2 = v_d_2423; V a_3 = v_t_2425; V r_ = (g_json_2enumberAfterDigits(a_0, a_1, a_2, a_3)); heff_drop(v_s_2421); heff_drop(v_j_2422); r_; });
                } else {
                  heff_drop(v_s_2421);
                  heff_drop(v_c_2424);
                  V v_t_2426;
                  if (heff_intEq_c_lent(v_d_2423, v_j_2422, 2)) {
                    v_t_2426 = ((V)&g_json_2esteps_2evalueAt_240_str8);
                  } else {
                    v_t_2426 = ((V)&g_json_2esteps_2evalueAt_240_str9);
                  }
                  v_x3_2427 = heff_tag_n(TAG_Left, 1, (V[]){heff_tag_n(TAG_Expected, 2, (V[]){v_d_2423, v_t_2426})});
                }
              }
              switch (heff_tag_of(v_x3_2427)) {
              case TAG_Left: {
                V v_e_2428 = heff_field(v_x3_2427, 0);
                V v_ru_24x3_2427_24Left = heff_take_reuse_n(v_x3_2427, 1ULL, 1);
                heff_drop(v_frames_242);
                return heff_tag_at_n(v_ru_24x3_2427_24Left, TAG_Failed, 1, (V[]){v_e_2428});
              }
              case TAG_Right: {
                V v_x31_2429 = heff_field(v_x3_2427, 0);
                heff_take_n(v_x3_2427, 1ULL, 1);
                switch (heff_tag_of(v_x31_2429)) {
                case TAG_MkPair: {
                  V v_x_2430 = heff_field(v_x31_2429, 0);
                  V v_j_2431 = heff_field(v_x31_2429, 1);
                  heff_take_n(v_x31_2429, 3ULL, 2);
                  return heff_tag_n(TAG_Got, 3, (V[]){v_x_2430, v_j_2431, v_frames_242});
                }
                default: return heff_nomatch(v_x31_2429);
                }
              }
              default: return heff_nomatch(v_x3_2427);
              }
            }
          }
        }
      }
    }
  }
}
V g_json_2esteps_2evalueAt_240_entry(V self, V *a) {
  (void)self;
  return g_json_2esteps_2evalueAt_240(a[0], a[1], a[2]);
}