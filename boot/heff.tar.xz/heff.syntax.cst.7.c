// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Atom 28502
#define TAG_DMutual 35008
#define TAG_ECon 35052
#define TAG_EFSet 34673
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_EUSet 22856
#define TAG_Get 18914
#define TAG_Left 13886
#define TAG_MkLetHead 58143
#define TAG_MkSep 6724
#define TAG_Named 2049
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Throw 56084
#define TAG_Tup 31899
#define LBL_app 306331
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_pattern 1588251091
#define LBL_ret 322331
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202(V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967_clo;
V g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628(V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628_clo;
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376_clo;
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(V, V, V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V, V, V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo;
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929(V, V, V);
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_clo;
V g_heff_2esyntax_2ecst_2efieldNameF(V, V, V, V);
V g_heff_2esyntax_2ecst_2efieldNameF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldNameF_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2efirstP(V);
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstP_clo;
V g_heff_2esyntax_2ecst_2eheadGram_get(void);
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2elastP(V);
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastP_clo;
V g_heff_2esyntax_2ecst_2eletHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletHeadF_clo;
V g_heff_2esyntax_2ecst_2eletStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletStmtF_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emutualBlock(V, V, V);
V g_heff_2esyntax_2ecst_2emutualBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emutualBlock_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_clo;
V g_heff_2esyntax_2ecst_2eparensF(V, V, V);
V g_heff_2esyntax_2ecst_2eparensF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_clo;
V g_heff_2esyntax_2ecst_2ereadH_get(void);
V g_heff_2esyntax_2ecst_2ereadSumAlg(V, V);
V g_heff_2esyntax_2ecst_2ereadSumAlg_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ereadSumAlg_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_clo;
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_clo;
V g_heff_2esyntax_2ecst_2esegmentF(V, V, V);
V g_heff_2esyntax_2ecst_2esegmentF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegmentF_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_clo;
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886(V, V);
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF(V, V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_heff_2esyntax_2ecst_2ereadH_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ereadH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadH_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2ereadH_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ereadH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadH_lam1, 3, 0};

static V g_heff_2esyntax_2ecst_2ereadH_val;
static HEFF_ONCE g_heff_2esyntax_2ecst_2ereadH_st;
static V g_heff_2esyntax_2ecst_2ereadH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2esyntax_2ecst_2ereadH_lam0_clo), ((V)&g_heff_2esyntax_2ecst_2ereadH_lam1_clo), ((V)&g_heff_2esyntax_2ecst_2ereadSumAlg_clo)});
}
V g_heff_2esyntax_2ecst_2ereadH_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2ecst_2ereadH_st)) return g_heff_2esyntax_2ecst_2ereadH_val;
  return heff_global(&g_heff_2esyntax_2ecst_2ereadH_val, &g_heff_2esyntax_2ecst_2ereadH_st, g_heff_2esyntax_2ecst_2ereadH_init);
}
V g_heff_2esyntax_2ecst_2ereadH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_st_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_st_241});
}
V g_heff_2esyntax_2ecst_2ereadH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_st_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Left = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_re_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_246_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatBoundary_str0, 3, "eof");
V g_heff_2esyntax_2ecst_2eatBoundary_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatBoundary_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatBoundary_lam0, 1, 0};
Clo g_heff_2esyntax_2ecst_2eatBoundary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatBoundary_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatBoundary(V v_hd_240, V v_k2_241) {
top: ;
  V v_malg_242 = heff_take_field(v_hd_240, 2);
  V v_bind_243 = heff_get_n(v_hd_240, 1, 3);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eatBoundary_lam0_clo)})});
  V v_t_2412 = heff_tr(heff_call(v_malg_242, 1, (V[]){v_t_2411}));
  return heff_tail(v_bind_243, 2, (V[]){v_t_2412, v_k2_241});
}
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatBoundary(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatBoundary_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_t_245 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_244), heff_dup(heff_rfield(v_s_244, 1))));
  if (heff_strEq_c(heff_get_n(v_t_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eatBoundary_str0))) {
    heff_drop_rec(v_s_244, 5);
    return NTAG(TAG_True);
  } else {
    if (({ V v_t_246 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_244), heff_dup(heff_rfield(v_s_244, 1)))); int c_ = (heff_dup(heff_rfield(v_t_246, 6)) == NTAG(TAG_True)); heff_drop(v_t_246); c_; })) {
      V v_t_247 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_244), heff_dup(heff_rfield(v_s_244, 1))));
      V v_t_2424 = heff_get_n(v_t_247, 5, 9);
      V v_t_248 = heff_take_field(v_s_244, 3);
      V v_t_2425;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        v_t_2425 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 2);
        v_t_2425 = v_x_249;
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2423 = heff_intLe(v_t_2424, v_t_2425);
      switch (heff_tag_of(v_t_2423)) {
      case TAG_True: {
        V v_ret_24bool = heff_bool(!heff_intEq_c(heff_dup(heff_rfield(v_s_244, 1)), heff_dup(heff_rfield(v_s_244, 4))));
        heff_drop_rec(v_s_244, 5);
        return v_ret_24bool;
      }
      case TAG_False: {
        heff_drop_rec(v_s_244, 5);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2423);
      }
    } else {
      heff_drop_rec(v_s_244, 5);
      return NTAG(TAG_False);
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str2, 12, "expected `:`");
V g_heff_2esyntax_2ecst_2eexpectAnn_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectAnn_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexpectAnn(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectAnn_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectAnn(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexpectAnn_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_kind_245 = heff_take_field(v_x_244, 0);
  V v_text_246 = heff_take_field(v_x_244, 1);
  V v_start_247 = heff_take_field(v_x_244, 3);
  V v_end_248 = heff_get_n(v_x_244, 4, 9);
  if ((heff_strEq_c_lent(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str0), 2) && heff_strEq_c_lent(v_text_246, ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str1), 2))) {
    heff_drop(v_kind_245);
    heff_drop(v_text_246);
    heff_drop(v_start_247);
    heff_drop(v_end_248);
    heff_clo_take(self, 2);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_240, v_k_241));
  } else {
    heff_drop(v_kind_245);
    heff_drop(v_text_246);
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str2), heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    heff_clo_take(self, 2);
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_str1, 51, "an update sets a field by its name: `{ r | x = v }`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_str2, 1, "=");
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eupdateSettingF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateSettingF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateSettingF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateSettingF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eupdateSettingF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateSettingF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EUSet, 3, (V[]){v_x_2417, v_x_2418, v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam7, 1, 3, (V[]){v_k_242, v_x_2417, v_x_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam6, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_Atom, 1, (V[]){v_x_2416}), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam5, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_drop(v_x_2411);
  if (!heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_str0))) {
    heff_clo_take(self, 4);
    heff_drop_rec(v_g_240, 17);
    V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_str1), v_t_2412, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 4);
    heff_drop_rec(v_x_245, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam4, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
  }
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2efieldNameF(heff_dup(v_x_245), v_x_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam3, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_g_240})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_lam2, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str2, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str4, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str5, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str6, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str8, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str9, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str10, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str12, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str13, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str15, 1, ")");
V g_heff_2esyntax_2ecst_2eparensF_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eparensF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2eparensF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparensF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eparensF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eparensF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparensF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eparensF_lam3(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2eparensF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2416});
  V f_ = v_k_245;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_tag_n(TAG_EParen, 3, (V[]){v_x_243, heff_tag_n(TAG_Atom, 1, (V[]){v_x_2420}), v_x_2421});
  V f_ = v_k_245;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam7, 1, 3, (V[]){v_x_243, v_x_2420, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam10(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_ENest, 4, (V[]){v_x_243, v_x_2423, v_x_2424, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam9(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str6), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam10, 1, 4, (V[]){v_k_245, v_x_243, v_x_2423, v_x_2424})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam8(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam9, 1, 4, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam14(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_x_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Named, 5, (V[]){v_x_243, v_x_2426, v_x_2427, v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam13(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str11), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam14, 1, 5, (V[]){v_k_245, v_x_243, v_x_2426, v_x_2427, v_x_2428})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam12(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam13, 1, 5, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2426, v_x_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam11(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam12, 1, 5, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam18(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_t_2439;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkSep: {
    V v_items_2437 = heff_field(v_x_2435, 0);
    V v_seps_2438 = heff_field(v_x_2435, 1);
    heff_take_n(v_x_2435, 3ULL, 2);
    v_t_2439 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, v_items_2437, v_seps_2438, v_x_2436});
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_k_245;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam17(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str14), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam18, 1, 3, (V[]){v_x_2435, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam19(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_EParen, 3, (V[]){v_x_243, v_x_2430, v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam16(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_2433, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_str12))) {
    heff_clo_take(self, 5);
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eparensF_str13), heff_get_n(v_g_240, 0, 17), v_t_2434, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam17, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  } else {
    heff_clo_take(self, 5);
    heff_drop_rec(v_g_240, 17);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str15), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam19, 1, 3, (V[]){v_k_245, v_x_243, v_x_2430})));
  }
}
V g_heff_2esyntax_2ecst_2eparensF_lam15(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2431}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam16, 1, 5, (V[]){v_x_2430, v_g_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_text_2414 = heff_take_field(v_x_2413, 1);
  V v_kind_2415 = heff_get_n(v_x_2413, 0, 9);
  if ((heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_248, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str1)))) {
    heff_clo_take(self, 5);
    heff_drop_rec(v_x_248, 9);
    heff_drop_rec(v_g_240, 17);
    heff_drop(v_text_2414);
    heff_drop(v_kind_2415);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam5, 1, 2, (V[]){v_x_243, v_k_245})));
  } else {
    V v_t_2419;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str2))) {
      V v_x1_2418 = ({ V a_0 = v_x_248; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s565534491x447967237(a_0, b_1)); heff_drop(b_1); r_; });
      v_t_2419 = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
      heff_drop(v_x1_2418);
    } else {
      v_t_2419 = NTAG(TAG_False);
    }
    if (((heff_dup(v_t_2419) == NTAG(TAG_True)) && heff_strEq_c_lent(v_text_2414, ((V)&g_heff_2esyntax_2ecst_2eparensF_str3), 2))) {
      heff_clo_take(self, 5);
      heff_drop_rec(v_x_248, 9);
      heff_drop_rec(v_g_240, 17);
      heff_drop(v_text_2414);
      heff_drop(v_kind_2415);
      heff_drop(v_t_2419);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
    } else {
      heff_drop(v_t_2419);
      if ((heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_x_248, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str5)))) {
        heff_clo_take(self, 5);
        heff_drop_rec(v_x_248, 9);
        heff_drop(v_text_2414);
        heff_drop(v_kind_2415);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam8, 1, 4, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243})));
      } else {
        if (((heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str7)) || heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str8))) && (heff_strEq_c_lent(v_kind_2415, ((V)&g_heff_2esyntax_2ecst_2eparensF_str9), 2) && heff_strEq_c_lent(v_text_2414, ((V)&g_heff_2esyntax_2ecst_2eparensF_str10), 2)))) {
          heff_clo_take(self, 5);
          heff_drop_rec(v_x_248, 9);
          heff_drop(v_text_2414);
          heff_drop(v_kind_2415);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam11, 1, 4, (V[]){v_hd_244, v_g_240, v_k_245, v_x_243})));
        } else {
          heff_clo_take(self, 5);
          heff_drop_rec(v_x_248, 9);
          heff_drop(v_text_2414);
          heff_drop(v_kind_2415);
          V f_ = heff_dup(heff_rfield(v_g_240, 0));
          heff_room[0] = heff_dup(v_hd_244);
          heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam15, 1, 4, (V[]){v_hd_244, v_g_240, v_x_243, v_k_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eparensF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eparensF_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam4, 1, 5, (V[]){v_x_248, v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam2, 1, 4, (V[]){v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam1, 2, 2, (V[]){v_x_243, v_g_240}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str1, 4, "tick");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str2, 2, "::");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str3, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str5, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str6, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_str8, 3, "let");
V g_heff_2esyntax_2ecst_2esegOperandsF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegOperandsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegOperandsF_entry, 4, 0};

V g_heff_2esyntax_2ecst_2esegOperandsF(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_lam0, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2esegOperandsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegOperandsF(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2esegOperandsF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_249, v_x_2415}), v_acc_241});
  V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2416));
  V f_ = v_k_243;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegOperandsF_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_249, v_x_2418}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2esegOperandsF(v_g_240, v_t_2419, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2esegOperandsF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_text_2413 = heff_take_field(v_x_2412, 1);
  V v_kind_2414 = heff_get_n(v_x_2412, 0, 9);
  if ((heff_strEq_c_lent(v_text_2413, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str3), 2) || (heff_strEq_c_lent(v_kind_2414, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str4), 2) && (heff_strEq_c_lent(v_text_2413, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str5), 2) || (heff_strEq_c_lent(v_text_2413, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str6), 2) || (heff_strEq_c_lent(v_text_2413, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str7), 2) || heff_strEq_c_lent(v_text_2413, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str8), 2))))))) {
    heff_drop(v_text_2413);
    heff_drop(v_kind_2414);
    heff_clo_take(self, 5);
    V f_ = heff_get_n(v_g_240, 0, 17);
    heff_room[0] = v_hd_242;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_lam3, 1, 3, (V[]){v_x_249, v_acc_241, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_text_2413);
    heff_drop(v_kind_2414);
    heff_clo_take(self, 5);
    V f_ = heff_dup(heff_rfield(v_g_240, 3));
    heff_room[0] = heff_dup(v_hd_242);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_lam4, 1, 5, (V[]){v_x_249, v_acc_241, v_g_240, v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esegOperandsF_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2410}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_lam2, 1, 5, (V[]){v_g_240, v_hd_242, v_x_249, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esegOperandsF_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_t_248;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str0))) {
    V v_x1_247 = ({ V a_0 = v_x_246; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s565534491x447967237(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_248 = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
    heff_drop(v_x1_247);
  } else {
    v_t_248 = NTAG(TAG_False);
  }
  if ((((heff_dup(v_t_248) == NTAG(TAG_True)) || heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str1))) && !heff_strEq_c(heff_dup(heff_rfield(v_x_246, 1)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_str2)))) {
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_t_248);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_lam1, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})));
  } else {
    heff_drop_rec(v_x_246, 9);
    heff_clo_take(self, 4);
    heff_drop_rec(v_hd_242, 3);
    heff_drop_rec(v_g_240, 17);
    heff_drop(v_t_248);
    V v_x_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_2420;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str1, 2, "::");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str2, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str4, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str6, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegmentF_str7, 3, "let");
V g_heff_2esyntax_2ecst_2esegmentF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esegmentF_lam4(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegmentF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegmentF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2esegmentF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_g_243 = v_g_240;
  V v_hd_244 = heff_dup(v_hd_241);
  V v_k_2413 = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_lam0, 1, 2, (V[]){v_hd_241, v_k_242});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2414}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2415, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_lam4, 1, 3, (V[]){v_g_243, v_hd_244, v_k_2413})});
}
V g_heff_2esyntax_2ecst_2esegmentF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegmentF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2esegmentF_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Seg, 3, (V[]){v_x_245, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(NTAG(TAG_Nil), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_lam3, 1, 3, (V[]){v_k_242, v_x_245, v_x_2411})));
}
V g_heff_2esyntax_2ecst_2esegmentF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_kind_249 = heff_take_field(v_x_248, 0);
  V v_text_2410 = heff_get_n(v_x_248, 1, 9);
  if ((heff_strEq_c_lent(v_kind_249, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str0), 2) && heff_strEq_c_lent(v_text_2410, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str1), 2))) {
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_lam2, 1, 3, (V[]){v_hd_241, v_k_242, v_x_245})));
  } else {
    heff_clo_take(self, 3);
    heff_drop_rec(v_hd_241, 3);
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    V f_ = v_k_242;
    args[0] = v_x_245;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2esegmentF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esegmentF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_t_2423;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nil: {
    v_t_2423 = v_x_2419;
    break;
  }
  case TAG_Cons: {
    v_t_2423 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2419, v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V f_ = v_k_2413;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegmentF_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2esegOperandsF(v_g_243, NTAG(TAG_Nil), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_lam6, 1, 2, (V[]){v_x_2419, v_k_2413})));
}
V g_heff_2esyntax_2ecst_2esegmentF_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_text_2417 = heff_take_field(v_x_2416, 1);
  V v_kind_2418 = heff_get_n(v_x_2416, 0, 9);
  if ((heff_strEq_c_lent(v_text_2417, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str2), 2) || (heff_strEq_c_lent(v_kind_2418, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str3), 2) && (heff_strEq_c_lent(v_text_2417, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str4), 2) || (heff_strEq_c_lent(v_text_2417, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str5), 2) || (heff_strEq_c_lent(v_text_2417, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str6), 2) || heff_strEq_c_lent(v_text_2417, ((V)&g_heff_2esyntax_2ecst_2esegmentF_str7), 2))))))) {
    heff_drop(v_text_2417);
    heff_drop(v_kind_2418);
    heff_clo_take(self, 3);
    V f_ = heff_get_n(v_g_243, 0, 17);
    heff_room[0] = v_hd_244;
    heff_room[1] = v_k_2413;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_text_2417);
    heff_drop(v_kind_2418);
    heff_clo_take(self, 3);
    V f_ = heff_dup(heff_rfield(v_g_243, 3));
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegmentF_lam5, 1, 3, (V[]){v_g_243, v_hd_244, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str1, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str2, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str3, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_249});
  V f_ = v_k_245;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_t_2417;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkSep: {
    V v_items_2415 = heff_field(v_x_2413, 0);
    V v_seps_2416 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 3ULL, 2);
    v_t_2417 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, v_items_2415, v_seps_2416, v_x_2414});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_245;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str3), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6, 1, 3, (V[]){v_x_2413, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str2), v_item_240, v_t_2412, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str0))) {
    heff_clo_take(self, 4);
    heff_drop(v_item_240);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str1), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3, 1, 2, (V[]){v_x_243, v_k_245})));
  } else {
    heff_clo_take(self, 4);
    V f_ = heff_dup(v_item_240);
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2, 1, 4, (V[]){v_hd_244, v_x_243, v_k_245, v_item_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1, 2, 2, (V[]){v_x_243, v_item_240}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str2, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str3, 1, "=");
V g_heff_2esyntax_2ecst_2eletHeadF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletHeadF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_pattern_243 = heff_take_field(v_g_240, 5);
  V v_expr_244 = heff_get_n(v_g_240, 0, 17);
  return heff_tail(v_pattern_243, 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam0, 1, 3, (V[]){v_hd_241, v_expr_244, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletHeadF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_x_2412})});
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_MkLetHead, 4, (V[]){v_x_245, v_t_2415, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_expr_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_expr_244;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam5, 1, 5, (V[]){v_x_2411, v_x_2412, v_k_242, v_x_245, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_expr_244 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eletHeadF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam4, 1, 6, (V[]){v_expr_244, v_hd_241, v_x_2411, v_x_2412, v_k_242, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_expr_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_dup(v_expr_244);
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam3, 1, 5, (V[]){v_hd_241, v_expr_244, v_x_2411, v_k_242, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_MkLetHead, 4, (V[]){v_x_245, NTAG(TAG_Nothing), v_x_2416, v_x_2417});
  V f_ = v_k_242;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_expr_244 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_expr_244;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam7, 1, 3, (V[]){v_x_245, v_x_2416, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_expr_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_kind_249 = heff_take_field(v_x_248, 0);
  V v_text_2410 = heff_get_n(v_x_248, 1, 9);
  if ((heff_strEq_c_lent(v_kind_249, ((V)&g_heff_2esyntax_2ecst_2eletHeadF_str0), 2) && heff_strEq_c_lent(v_text_2410, ((V)&g_heff_2esyntax_2ecst_2eletHeadF_str1), 2))) {
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam2, 1, 4, (V[]){v_expr_244, v_hd_241, v_k_242, v_x_245})));
  } else {
    heff_drop(v_kind_249);
    heff_drop(v_text_2410);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eletHeadF_str3), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam6, 1, 4, (V[]){v_expr_244, v_hd_241, v_x_245, v_k_242})));
  }
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_expr_244 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam1, 1, 4, (V[]){v_hd_241, v_expr_244, v_k_242, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str1, 2, "in");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str2, 2, "in");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str4, 4, "else");
V g_heff_2esyntax_2ecst_2eletStmtF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletStmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletStmtF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletStmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletStmtF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_t_2418;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_2413 = heff_field(v_x_244, 0);
    V v_ann_2414 = heff_field(v_x_244, 1);
    V v_eq_2415 = heff_field(v_x_244, 2);
    V v_e_2416 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_x_2412})});
    v_t_2418 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_2413, v_ann_2414, v_eq_2415, v_e_2416, v_t_2417});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam5, 1, 4, (V[]){v_x_244, v_x_2411, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_p_2419 = heff_env(self)[2];
  V v_ann_2420 = heff_env(self)[3];
  V v_eq_2421 = heff_env(self)[4];
  V v_e_2422 = heff_env(self)[5];
  V v_x_2423 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ELetElse, 7, (V[]){v_x_243, v_p_2419, v_ann_2420, v_eq_2421, v_e_2422, v_x_2423, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_p_2419 = heff_env(self)[4];
  V v_ann_2420 = heff_env(self)[5];
  V v_eq_2421 = heff_env(self)[6];
  V v_e_2422 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_240, 14, 17), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam7, 1, 7, (V[]){v_k_242, v_x_243, v_p_2419, v_ann_2420, v_eq_2421, v_e_2422, v_x_2423})));
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_kind_248 = heff_env(self)[0];
  V v_text_249 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_k_242 = heff_env(self)[6];
  if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str0), 2) && heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str1), 2))) {
    heff_drop(v_x_2410);
    heff_clo_take(self, 7);
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eletStmtF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam4, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
  } else {
    if (((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str3), 2) && heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str4), 2)) && !(heff_dup(v_x_2410) == NTAG(TAG_True)))) {
      heff_drop(v_x_2410);
      heff_clo_take(self, 7);
      heff_drop(v_kind_248);
      heff_drop(v_text_249);
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkLetHead: {
        V v_p_2419 = heff_field(v_x_244, 0);
        V v_ann_2420 = heff_field(v_x_244, 1);
        V v_eq_2421 = heff_field(v_x_244, 2);
        V v_e_2422 = heff_field(v_x_244, 3);
        heff_take_n(v_x_244, 15ULL, 4);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam6, 1, 8, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_p_2419, v_ann_2420, v_eq_2421, v_e_2422})));
      }
      default: return heff_nomatch(v_x_244);
      }
    } else {
      heff_drop(v_x_2410);
      heff_clo_take(self, 7);
      heff_drop(v_kind_248);
      heff_drop(v_text_249);
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 17);
      V v_t_2429;
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkLetHead: {
        V v_p_2425 = heff_field(v_x_244, 0);
        V v_ann_2426 = heff_field(v_x_244, 1);
        V v_eq_2427 = heff_field(v_x_244, 2);
        V v_e_2428 = heff_field(v_x_244, 3);
        heff_take_n(v_x_244, 15ULL, 4);
        v_t_2429 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_2425, v_ann_2426, v_eq_2427, v_e_2428, NTAG(TAG_Nothing)});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V f_ = v_k_242;
      args[0] = v_t_2429;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_kind_248 = heff_take_field(v_x_247, 0);
  V v_text_249 = heff_get_n(v_x_247, 1, 9);
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam3, 1, 7, (V[]){v_kind_248, v_text_249, v_hd_241, v_g_240, v_x_244, v_x_243, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_244, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str1, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str2, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str3, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_PList, 4, (V[]){v_x_243, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_249});
  V f_ = v_k_245;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_t_2417;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkSep: {
    V v_items_2415 = heff_field(v_x_2413, 0);
    V v_seps_2416 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 3ULL, 2);
    v_t_2417 = heff_tag_n(TAG_PList, 4, (V[]){v_x_243, v_items_2415, v_seps_2416, v_x_2414});
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_245;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str3), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6, 1, 3, (V[]){v_x_2413, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str2), v_item_240, v_t_2412, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str0))) {
    heff_clo_take(self, 4);
    heff_drop(v_item_240);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str1), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3, 1, 2, (V[]){v_x_243, v_k_245})));
  } else {
    heff_clo_take(self, 4);
    V f_ = heff_dup(v_item_240);
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2, 1, 4, (V[]){v_hd_244, v_x_243, v_k_245, v_item_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1, 2, 2, (V[]){v_x_243, v_item_240}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_str0, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_str1, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_str2, 1, "}");
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam6(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_t_2413;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSep: {
    V v_items_2411 = heff_field(v_x_249, 0);
    V v_seps_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    v_t_2413 = heff_tag_n(TAG_Sum, 5, (V[]){v_x_242, v_x_243, v_items_2411, v_seps_2412, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_245;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam5(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_str2), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam6, 1, 4, (V[]){v_x_249, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_x_246, v_x_247}), NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo_24s1415547436x926482723(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_str1), v_t_248, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam5, 1, 4, (V[]){v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam4, 1, 5, (V[]){v_x_246, v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam2(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam3, 1, 4, (V[]){v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam2, 2, 2, (V[]){v_x_242, v_x_243}), v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_str0), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s48591008x615058202_lam1, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_str0, 1, "=");
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_245, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_245, v_t_246));
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFSet, 3, (V[]){v_x_2411, v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam5(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam6, 1, 3, (V[]){v_k_241, v_x_2411, v_x_2412})));
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_str0), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam5, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2411})));
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_drop(v_x_2410);
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam4, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldNameF(v_x_244, v_x_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2esettingF_24s1504884094x1976175886(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_248, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    heff_clo_take(self, 5);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1563612414x412069720_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_clo_take(self, 5);
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2410, v_t_2411});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_str1, 51, "an update sets a field by its name: `{ r | x = v }`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_str2, 1, "=");
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_dup(heff_rfield(v_s_245, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_245, v_t_246));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EUSet, 3, (V[]){v_x_2416, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam7, 1, 3, (V[]){v_k_241, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam6, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_Atom, 1, (V[]){v_x_2415}), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam5, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_drop(v_x_2410);
  if (!heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_str0))) {
    heff_clo_take(self, 3);
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_str1), v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 3);
    heff_drop_rec(v_x_244, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam4, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldNameF(heff_dup(v_x_244), v_x_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam3, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str1, 4, "tick");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str2, 2, "::");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str3, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str5, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str6, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str8, 3, "let");
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_entry, 3, 0};

V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam0, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_248, v_x_2414}), v_acc_240});
  V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2415));
  V f_ = v_k_242;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_acc_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_text_2412 = heff_take_field(v_x_2411, 1);
  V v_kind_2413 = heff_get_n(v_x_2411, 0, 9);
  if ((heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str3), 2) || (heff_strEq_c_lent(v_kind_2413, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str4), 2) && (heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str5), 2) || (heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str6), 2) || (heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str7), 2) || heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str8), 2))))))) {
    heff_drop(v_text_2412);
    heff_drop(v_kind_2413);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam3, 1, 3, (V[]){v_x_248, v_acc_240, v_k_242})));
  } else {
    heff_drop(v_text_2412);
    heff_drop(v_kind_2413);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2eappF_24s1081785160x760674967(v_x_248, v_acc_240, heff_dup(v_hd_241), v_k_242, v_hd_241));
  }
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_249}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam2, 1, 4, (V[]){v_hd_241, v_x_248, v_acc_240, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str0))) {
    V v_x1_246 = ({ V a_0 = v_x_245; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s565534491x447967237(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_247 = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
    heff_drop(v_x1_246);
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  if ((((heff_dup(v_t_247) == NTAG(TAG_True)) || heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str1))) && !heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_str2)))) {
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_t_247);
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s991595934x258768348_lam1, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})));
  } else {
    heff_drop_rec(v_x_245, 9);
    heff_clo_take(self, 3);
    heff_drop_rec(v_hd_241, 3);
    heff_drop(v_t_247);
    V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str4, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str5, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str6, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str9, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2419, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    heff_clo_take(self, 3);
    V v_span_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_take_field(v_x_244, 4)});
    V v_t_248;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str0))) {
      heff_drop_rec(v_x_244, 9);
      v_t_248 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str1);
    } else {
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str2), heff_get_n(v_x_244, 1, 9));
      v_t_248 = heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str3));
    }
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str4), v_t_248), v_span_246, NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_245);
    V v_x1_2412 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244)));
    if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
      heff_drop(v_x1_2412);
      heff_clo_take(self, 3);
      V v_span_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_take_field(v_x_244, 4)});
      V v_t_2415;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str5))) {
        heff_drop_rec(v_x_244, 9);
        v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str6);
      } else {
        V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str7), heff_get_n(v_x_244, 1, 9));
        v_t_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str8));
      }
      V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_str9), v_t_2415), v_span_2413, NTAG(TAG_Nothing)});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2417}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2418;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x1_2412);
      heff_clo_take(self, 3);
      return (g_heff_2esyntax_2ecst_2eatomBase_24s1445575669x976704341(v_x_244, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s213013295x1417922384_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str11, 5, "break");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str12, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str13, 8, "continue");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str14, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str15, 6, "return");
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929(V v_t_240, V v_z_241, V v_z_242) {
top: ;
  V v_text_243 = heff_take_field(v_t_240, 1);
  V v_kind_244 = heff_get_n(v_t_240, 0, 9);
  if ((heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str0), 2) && heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str1), 2))) {
    heff_drop(v_text_243);
    heff_drop(v_kind_244);
    return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 8)), 2, (V[]){v_z_241, v_z_242});
  } else {
    if ((heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str2), 2) && heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str3), 2))) {
      heff_drop(v_text_243);
      heff_drop(v_kind_244);
      return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 9)), 2, (V[]){v_z_241, v_z_242});
    } else {
      if ((heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str4), 2) && heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str5), 2))) {
        heff_drop(v_text_243);
        heff_drop(v_kind_244);
        return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 10)), 2, (V[]){v_z_241, v_z_242});
      } else {
        if ((heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str6), 2) && heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str7), 2))) {
          heff_drop(v_text_243);
          heff_drop(v_kind_244);
          return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 11)), 2, (V[]){v_z_241, v_z_242});
        } else {
          if ((heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str8), 2) && heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str9), 2))) {
            heff_drop(v_text_243);
            heff_drop(v_kind_244);
            return heff_tail(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2eheadGram_get(), 12)), 2, (V[]){v_z_241, v_z_242});
          } else {
            if (((heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str10), 2) && heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str11), 2)) || (heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str12), 2) && heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str13), 2)))) {
              heff_drop(v_text_243);
              heff_drop(v_kind_244);
              return (g_heff_2esyntax_2ecst_2enext(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam0, 1, 1, (V[]){v_z_242})));
            } else {
              if ((heff_strEq_c_lent(v_kind_244, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str14), 2) && heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_str15), 2))) {
                heff_drop(v_text_243);
                heff_drop(v_kind_244);
                return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam1, 1, 2, (V[]){v_z_241, v_z_242})));
              } else {
                heff_drop(v_text_243);
                heff_drop(v_kind_244);
                return (g_heff_2esyntax_2ecst_2eappF_24s1885000916x2079725628(MK_INT(0LL), heff_dup(v_z_241), v_z_242, v_z_241));
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_EJump, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_EReturn, 2, (V[]){v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1891014825x1429496493(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s793015820x2124399929_lam2, 1, 2, (V[]){v_z_242, v_x_246})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str4, 28, "expected an expression, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str5, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str6, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str9, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2419, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    heff_clo_take(self, 3);
    V v_span_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_take_field(v_x_244, 4)});
    V v_t_248;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str0))) {
      heff_drop_rec(v_x_244, 9);
      v_t_248 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str1);
    } else {
      V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str2), heff_get_n(v_x_244, 1, 9));
      v_t_248 = heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str3));
    }
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str4), v_t_248), v_span_246, NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_245);
    V v_x1_2412 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244)));
    if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
      heff_drop(v_x1_2412);
      heff_clo_take(self, 3);
      V v_span_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_take_field(v_x_244, 4)});
      V v_t_2415;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str5))) {
        heff_drop_rec(v_x_244, 9);
        v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str6);
      } else {
        V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str7), heff_get_n(v_x_244, 1, 9));
        v_t_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str8));
      }
      V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_str9), v_t_2415), v_span_2413, NTAG(TAG_Nothing)});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2417}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2418;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x1_2412);
      heff_clo_take(self, 3);
      return (g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(v_x_244, heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
    }
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str1, 4, "tick");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str2, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str4, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str6, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str7, 3, "let");
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_entry, 6, 0};

V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_acc_244, V v_hd_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam0, 1, 6, (V[]){v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2418}), v_acc_244});
  V v_x_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2419));
  V v_t_2423;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nil: {
    v_t_2423 = v_lit_241;
    break;
  }
  case TAG_Cons: {
    v_t_2423 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2420});
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_lit_240, v_t_2423, v_lit_242, v_lit_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_text_2416 = heff_take_field(v_x_2415, 1);
  V v_kind_2417 = heff_get_n(v_x_2415, 0, 9);
  if ((heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str2), 2) || (heff_strEq_c_lent(v_kind_2417, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str3), 2) && (heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str4), 2) || (heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str5), 2) || (heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str6), 2) || heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str7), 2))))))) {
    heff_drop(v_text_2416);
    heff_drop(v_kind_2417);
    heff_clo_take(self, 7);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam4, 1, 6, (V[]){v_x_2412, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
  } else {
    heff_drop(v_text_2416);
    heff_drop(v_kind_2417);
    heff_clo_take(self, 7);
    return (g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_x_2412, v_acc_244, heff_dup(v_hd_245), v_hd_245));
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2413}));
  heff_clo_take(self, 6);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam3, 1, 7, (V[]){v_hd_245, v_x_2412, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_t_2411;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str0))) {
    V v_x1_2410 = ({ V a_0 = v_x_248; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s565534491x447967237(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_2411 = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
    heff_drop(v_x1_2410);
  } else {
    v_t_2411 = NTAG(TAG_False);
  }
  if ((((heff_dup(v_t_2411) == NTAG(TAG_True)) || heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_str1))) && !(heff_dup(v_x_249) == NTAG(TAG_True)))) {
    heff_drop(v_x_249);
    heff_clo_take(self, 7);
    heff_drop_rec(v_x_248, 9);
    heff_drop(v_t_2411);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam2, 1, 6, (V[]){v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
  } else {
    heff_drop(v_x_249);
    heff_clo_take(self, 7);
    heff_drop_rec(v_x_248, 9);
    heff_drop_rec(v_hd_245, 3);
    heff_drop(v_t_2411);
    V v_x_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_244));
    V v_t_2427;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_Nil: {
      v_t_2427 = v_lit_241;
      break;
    }
    case TAG_Cons: {
      v_t_2427 = heff_tag_n(TAG_Ops, 2, (V[]){v_lit_241, v_x_2424});
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_lit_240, v_t_2427, v_lit_242, v_lit_243));
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_acc_244 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_lam1, 1, 7, (V[]){v_x_248, v_hd_245, v_acc_244, v_lit_241, v_lit_240, v_lit_242, v_lit_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str1, 4, "tick");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str2, 2, "::");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str3, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str5, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str6, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str8, 3, "let");
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_entry, 3, 0};

V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam0, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_248, v_x_2414}), v_acc_240});
  V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2415));
  V f_ = v_k_242;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_acc_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_text_2412 = heff_take_field(v_x_2411, 1);
  V v_kind_2413 = heff_get_n(v_x_2411, 0, 9);
  if ((heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str3), 2) || (heff_strEq_c_lent(v_kind_2413, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str4), 2) && (heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str5), 2) || (heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str6), 2) || (heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str7), 2) || heff_strEq_c_lent(v_text_2412, ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str8), 2))))))) {
    heff_drop(v_text_2412);
    heff_drop(v_kind_2413);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam3, 1, 3, (V[]){v_x_248, v_acc_240, v_k_242})));
  } else {
    heff_drop(v_text_2412);
    heff_drop(v_kind_2413);
    heff_clo_take(self, 4);
    return (g_heff_2esyntax_2ecst_2eappF_24s853177727x1238226376(v_x_248, v_acc_240, heff_dup(v_hd_241), v_k_242, v_hd_241));
  }
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_249}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam2, 1, 4, (V[]){v_hd_241, v_x_248, v_acc_240, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str0))) {
    V v_x1_246 = ({ V a_0 = v_x_245; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany_24s565534491x447967237(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_247 = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
    heff_drop(v_x1_246);
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  if ((((heff_dup(v_t_247) == NTAG(TAG_True)) || heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str1))) && !heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_str2)))) {
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_t_247);
    heff_clo_take(self, 3);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_lam1, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})));
  } else {
    heff_drop_rec(v_x_245, 9);
    heff_clo_take(self, 3);
    heff_drop_rec(v_hd_241, 3);
    heff_drop(v_t_247);
    V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str2, 27, "this line starts at column ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str3, 68, ", but the block it starts is inside one whose lines start at column ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str4, 21, ": indent it past that");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str5, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_t_2414 = heff_get_n(v_s_2413, 3, 5);
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nil: {
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 2);
    return v_x_2415;
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_col_249 = heff_env(self)[0];
  V v_t_2428 = heff_take_field(v_s_2427, 3);
  V v_top_2429 = heff_take_field(v_s_2427, 2);
  V v_start_2430 = heff_take_field(v_s_2427, 4);
  heff_clo_take(self, 1);
  return ({ V rv_2 = v_top_2429; V rv_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_col_249, v_t_2428}); V rv_4 = v_start_2430; V rr_ = heff_rec_reuse_nf(v_s_2427, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7(V self, V *args) {
  V v_s_2438 = args[0];
  V v_k_2439 = (g_list_2edrop(MK_INT(1LL), heff_rfield(v_s_2438, 3)));
  V v_top_2440 = heff_take_field(v_s_2438, 2);
  V v_start_2441 = heff_take_field(v_s_2438, 4);
  return ({ V rv_2 = v_top_2440; V rv_3 = v_k_2439; V rv_4 = v_start_2441; V rr_ = heff_rec_reuse_nf(v_s_2438, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  heff_drop(v_x_2447);
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_t_2445 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2444, NTAG(TAG_MkUnit)});
  heff_clo_take(self, 3);
  V v_t_2446 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2446;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9, 1, 2, (V[]){v_k_241, v_x_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7_clo)})});
  V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2442}));
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2443;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_col_249 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_drop(v_x_2436);
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(v_col_249, NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_col_249 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_t_2434 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2433, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})}));
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2435;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5, 1, 3, (V[]){v_col_249, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_first_248 = heff_env(self)[0];
  V v_col_249 = heff_env(self)[1];
  V v_start_246 = heff_env(self)[2];
  V v_end_247 = heff_env(self)[3];
  V v_hd_240 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  if (((heff_dup(v_first_248) == NTAG(TAG_True)) && heff_intLe_c_lent(v_col_249, v_x_2419, 0))) {
    heff_clo_take(self, 6);
    heff_drop(v_first_248);
    V v_t_2420 = heff_intShow(heff_intAdd(v_col_249, MK_INT(1LL)));
    V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str2), v_t_2420), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str3));
    V v_t_2422 = heff_intShow(heff_intAdd(v_x_2419, MK_INT(1LL)));
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2421, v_t_2422), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str4));
    V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str5), heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), heff_tag_n(TAG_Just, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2419);
    heff_clo_take(self, 6);
    heff_drop(v_first_248);
    heff_drop(v_start_246);
    heff_drop(v_end_247);
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3, 1, 1, (V[]){heff_dup(v_col_249)})})});
    V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2431}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2432;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4, 1, 3, (V[]){v_hd_240, v_col_249, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_kind_245 = heff_take_field(v_x_244, 0);
  V v_start_246 = heff_take_field(v_x_244, 3);
  V v_end_247 = heff_take_field(v_x_244, 4);
  V v_first_248 = heff_take_field(v_x_244, 6);
  V v_col_249 = heff_get_n(v_x_244, 5, 9);
  if (heff_strEq_c(v_kind_245, ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str0))) {
    heff_drop(v_first_248);
    heff_drop(v_col_249);
    V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
    heff_clo_take(self, 2);
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1_clo)})});
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2417}));
    heff_clo_take(self, 2);
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2418;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2, 1, 6, (V[]){v_first_248, v_col_249, v_start_246, v_end_247, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2emutualBlock_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emutualBlock_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emutualBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emutualBlock_entry, 3, 0};

V g_heff_2esyntax_2ecst_2emutualBlock(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_245 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2emutualBlock_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_245, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2emutualBlock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emutualBlock(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2emutualBlock_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DMutual, 2, (V[]){v_x_243, v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2emutualBlock_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eblock_24s915519806x274473034(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2emutualBlock_lam1, 1, 2, (V[]){v_k_241, v_x_243})));
}
Clo g_heff_2esyntax_2ecst_2efirstP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstP_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_243);
  }
  case TAG_PParen: {
    V v_o_244 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_244);
  }
  case TAG_PList: {
    V v_o_247 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_247);
  }
  case TAG_POp: {
    V v_l_2411 = heff_field(v_x1_240, 0);
    V t_0 = v_l_2411;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_o_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2414);
  }
  case TAG_PField: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2418);
  }
  case TAG_PAs: {
    V v_x_2421 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2421);
  }
  case TAG_PSeg: {
    V v_p_2424 = heff_field(v_x1_240, 0);
    V t_0 = v_p_2424;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstP(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastP_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_args_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      return v_t_241;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 2);
      heff_drop(v_t_241);
      V t_0 = v_x_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  case TAG_PAtom: {
    V v_t_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_246;
  }
  case TAG_PParen: {
    V v_c_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_249;
  }
  case TAG_PList: {
    V v_c_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2413;
  }
  case TAG_POp: {
    V v_r_2416 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_r_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_c_2420 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2420;
  }
  case TAG_PField: {
    V v_p_2423 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2423;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PAs: {
    V v_p_2426 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2426;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PSeg: {
    V v_cc_2428 = heff_field(v_x1_240, 1);
    V v_spec_2429 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_x1_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_spec_2429));
    switch (heff_tag_of(v_x1_2430)) {
    case TAG_Nil: {
      return v_cc_2428;
    }
    case TAG_Cons: {
      V v_x_2431 = heff_field(v_x1_2430, 0);
      heff_take_n(v_x1_2430, 1ULL, 2);
      heff_drop(v_cc_2428);
      return v_x_2431;
    }
    default: return heff_nomatch(v_x1_2430);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastP(a[0]);
}