// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_byName 571997869
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get(void);
V g_heff_2ecompile_2einterp_2ef32V2(V);
V g_heff_2ecompile_2einterp_2ef32V2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ef32V2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2eprojV(V, V);
V g_heff_2ecompile_2einterp_2eprojV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprojV_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str0, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str1, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str2, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str3, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str4, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str5, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str6, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str7, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str8, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str9, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str10, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str11, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str12, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str13, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str14, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str15, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str16, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str17, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str18, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str19, 25, "` of what is not a record");
Clo g_heff_2ecompile_2einterp_2eprojV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprojV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eprojV(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    V v_ru_24x1_240_24VFun = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str0), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str1));
    return heff_tag_at_n(v_ru_24x1_240_24VFun, TAG_Bug, 1, (V[]){v_t_243});
  }
  case TAG_VCons: {
    V v_fs_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VCons = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_byName_245 = heff_take_field(v_fs_244, 1);
    V v_values_246 = heff_get_n(v_fs_244, 2, 3);
    HeffT2 v_t_247 = ({ V a_0 = v_byName_245; V a_1 = v_x2_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_245); heff_drop(v_x2_241); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      V v_t_2413;
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_i_2410 = v_field_249;
        V v_xs_2411 = v_values_246;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2410, 1) && heff_intLt_c_lent(v_i_2410, heff_arrayLength_lent(v_xs_2411, 0), 2))) {
          V v_v_2412 = heff_arrayIndex(v_xs_2411, v_i_2410);
          v_t_2413 = v_v_2412;
        } else {
          heff_drop(v_i_2410);
          heff_drop(v_xs_2411);
          v_t_2413 = heff_abandon();
        }
      } else {
        heff_drop(v_values_246);
        heff_drop(v_field_249);
        v_t_2413 = heff_abandon();
      }
      return heff_tag_at_n(v_ru_24x1_240_24VCons, TAG_Ok, 1, (V[]){v_t_2413});
    }
  }
  case TAG_VTag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str2), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str3));
    return heff_tag_n(TAG_Bug, 1, (V[]){v_t_2416});
  }
  case TAG_VInt: {
    V v_ru_24x1_240_24VInt = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str4), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str5));
    return heff_tag_at_n(v_ru_24x1_240_24VInt, TAG_Bug, 1, (V[]){v_t_2418});
  }
  case TAG_VFloat: {
    V v_ru_24x1_240_24VFloat = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str6), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str7));
    return heff_tag_at_n(v_ru_24x1_240_24VFloat, TAG_Bug, 1, (V[]){v_t_2420});
  }
  case TAG_VFloat32: {
    V v_ru_24x1_240_24VFloat32 = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str8), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str9));
    return heff_tag_at_n(v_ru_24x1_240_24VFloat32, TAG_Bug, 1, (V[]){v_t_2422});
  }
  case TAG_VStr: {
    V v_ru_24x1_240_24VStr = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str10), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str11));
    return heff_tag_at_n(v_ru_24x1_240_24VStr, TAG_Bug, 1, (V[]){v_t_2424});
  }
  case TAG_VRune: {
    V v_ru_24x1_240_24VRune = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str12), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str13));
    return heff_tag_at_n(v_ru_24x1_240_24VRune, TAG_Bug, 1, (V[]){v_t_2426});
  }
  case TAG_VArr: {
    V v_ru_24x1_240_24VArr = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str14), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str15));
    return heff_tag_at_n(v_ru_24x1_240_24VArr, TAG_Bug, 1, (V[]){v_t_2428});
  }
  case TAG_VBytes: {
    V v_ru_24x1_240_24VBytes = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str16), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str17));
    return heff_tag_at_n(v_ru_24x1_240_24VBytes, TAG_Bug, 1, (V[]){v_t_2430});
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str18), v_x2_241), ((V)&g_heff_2ecompile_2einterp_2eprojV_str19));
    return heff_tag_n(TAG_Bug, 1, (V[]){v_t_2433});
  }
  case TAG_VErased: {
    heff_drop(v_x2_241);
    return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eprojV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprojV(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2estr2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2estr2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2estr2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2estr2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2estr2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2estr2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2estr2(a[0]);
}
V g_heff_2ecompile_2einterp_2estr2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      V v_f_249 = v_f_240;
      V v_x2_2410 = v_v_246;
      V v_x3_2411 = v_v_248;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_VFun: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VCons: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VTag: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VInt: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VStr: {
        V v_a_2419 = heff_field(v_x2_2410, 0);
        heff_take_n(v_x2_2410, 1ULL, 1);
        switch (heff_tag_of(v_x3_2411)) {
        case TAG_VFun: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VCons: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VTag: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VInt: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VStr: {
          V v_b_2427 = heff_field(v_x3_2411, 0);
          heff_take_n(v_x3_2411, 1ULL, 1);
          V f_ = v_f_249;
          args[0] = v_a_2419;
          args[1] = v_b_2427;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VRune: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VArr: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VBits: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_249);
          heff_drop(v_a_2419);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        default: return heff_nomatch(v_x3_2411);
        }
      }
      case TAG_VRune: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VArr: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VBits: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2438 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2438});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2439 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_re_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2439});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2estr2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_drop(v_d_241);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2estr2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsJoined_str10, 36, "a primitive given what is not `Bits`");
Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsJoined_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsJoined(V v_x1_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_241, v_acc_242})});
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_VFun: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str0)});
    }
    case TAG_VCons: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str1)});
    }
    case TAG_VTag: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str2)});
    }
    case TAG_VInt: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str3)});
    }
    case TAG_VFloat: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str4)});
    }
    case TAG_VFloat32: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str5)});
    }
    case TAG_VStr: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str6)});
    }
    case TAG_VRune: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str7)});
    }
    case TAG_VArr: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str8)});
    }
    case TAG_VBytes: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str9)});
    }
    case TAG_VBits: {
      V v_m_2416 = heff_field(v_x11_243, 0);
      V v_t_2417 = heff_field(v_x11_243, 1);
      V v_t_2418 = (g_heff_2ecompile_2einterp_2ebitsCopy(heff_dup(v_n_241), v_acc_242, v_t_2417, MK_INT(0LL), heff_dup(v_m_2416)));
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd_lent(v_n_241, v_m_2416, 1);
      V t_2 = v_t_2418;
      v_x1_240 = t_0;
      v_n_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    case TAG_VErased: {
      heff_drop(v_n_241);
      heff_drop(v_acc_242);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebitsJoined_str10)});
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2ebitsJoined(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2esliceV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2esliceV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2esliceV(V v_xs_240, V v_i_241, V v_j_242) {
top: ;
  V v_n_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
  V v_t_244;
  if (heff_intLt_c_lent(v_j_242, MK_INT(0LL), 2)) {
    if (heff_intLt_c(heff_intAdd_lent(v_j_242, v_n_243, 0), MK_INT(0LL))) {
      heff_drop(v_j_242);
      heff_drop(v_n_243);
      v_t_244 = MK_INT(0LL);
    } else {
      v_t_244 = heff_intAdd(v_j_242, v_n_243);
    }
  } else {
    if (heff_intLt_c_lent(v_n_243, v_j_242, 0)) {
      heff_drop(v_j_242);
      v_t_244 = v_n_243;
    } else {
      heff_drop(v_n_243);
      v_t_244 = v_j_242;
    }
  }
  V v_n_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
  V v_t_246;
  if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
    if (heff_intLt_c(heff_intAdd_lent(v_i_241, v_n_245, 0), MK_INT(0LL))) {
      heff_drop(v_n_245);
      v_t_246 = MK_INT(0LL);
    } else {
      v_t_246 = heff_intAdd_lent(v_i_241, v_n_245, 2);
    }
  } else {
    if (heff_intLt_c_lent(v_n_245, v_i_241, 0)) {
      v_t_246 = v_n_245;
    } else {
      heff_drop(v_n_245);
      v_t_246 = heff_dup(v_i_241);
    }
  }
  V v_n_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
  V v_t_248;
  if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
    if (heff_intLt_c(heff_intAdd_lent(v_i_241, v_n_247, 0), MK_INT(0LL))) {
      heff_drop(v_i_241);
      heff_drop(v_n_247);
      v_t_248 = MK_INT(0LL);
    } else {
      v_t_248 = heff_intAdd(v_i_241, v_n_247);
    }
  } else {
    if (heff_intLt_c_lent(v_n_247, v_i_241, 0)) {
      heff_drop(v_i_241);
      v_t_248 = v_n_247;
    } else {
      heff_drop(v_n_247);
      v_t_248 = v_i_241;
    }
  }
  V v_t_249 = (g_list_2edrop(v_t_248, v_xs_240));
  return (g_list_2etake(heff_intSub(v_t_244, v_t_246), v_t_249));
}
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2esliceV(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2ef32V2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2ef32V2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2ef32V2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2ef32V2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ef32V2(a[0]);
}
V g_heff_2ecompile_2einterp_2ef32V2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      V v_f_249 = v_f_240;
      V v_x2_2410 = v_v_246;
      V v_x3_2411 = v_v_248;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_VFun: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2418 = heff_field(v_x2_2410, 0);
        heff_take_n(v_x2_2410, 1ULL, 1);
        switch (heff_tag_of(v_x3_2411)) {
        case TAG_VFun: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2425 = heff_field(v_x3_2411, 0);
          heff_take_n(v_x3_2411, 1ULL, 1);
          V f_ = v_f_249;
          args[0] = v_a_2418;
          args[1] = v_b_2425;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VStr: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_x3_2411, 0ULL, 1);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_x3_2411, 0ULL, 2);
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_249);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_x3_2411);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_x2_2410, 0ULL, 1);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_x2_2410, 0ULL, 2);
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_249);
        heff_drop(v_x3_2411);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2438 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2438});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2439 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_re_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2439});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_drop(v_d_241);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_st;
static V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_st)) return g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_val, &g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_st, g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_init);
}
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_2410 = heff_field(v_v_243, 0);
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 1ULL, 1);
      double v_x_2411 = ((double)heff_peek_f32(v_a_2410));
      if (((v_x_2411 - v_x_2411) == (0.0))) {
        V v_t_2412 = heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_VInt, 1, (V[]){heff_floor_f32(heff_unbox_f32(v_a_2410))});
        return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){v_t_2412});
      } else {
        heff_drop(v_a_2410);
        return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VStr: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2419 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2419});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_st)) return g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_val, &g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_st, g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64((v_a_2413 * v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_re_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_re_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_st)) return g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_val, &g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_st, g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan2(v_a_2413, v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_re_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_re_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam1, 2, 1, (V[]){v_a_241})})});
}