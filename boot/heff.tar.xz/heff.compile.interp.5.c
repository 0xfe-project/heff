// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_VArr 15466
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_byName 571997869
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2ebytesOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get(void);
V g_heff_2ecompile_2einterp_2ef32V2(V);
V g_heff_2ecompile_2einterp_2ef32V2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ef32V2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2eprojV(V, V);
V g_heff_2ecompile_2einterp_2eprojV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprojV_clo;
V g_heff_2ecompile_2einterp_2ereversedBytes(V, V, V);
V g_heff_2ecompile_2einterp_2ereversedBytes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereversedBytes_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str0, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str1, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str2, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str3, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str4, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str5, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str6, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str7, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str8, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str9, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str10, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str11, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str12, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str13, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str14, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str15, 25, "` of what is not a record");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str16, 2, "`.");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprojV_str17, 25, "` of what is not a record");
Clo g_heff_2ecompile_2einterp_2eprojV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprojV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eprojV(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    V v_ru_24x1_240_24VFun = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_243 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str0), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str1)));
    return heff_tag_at_n(v_ru_24x1_240_24VFun, TAG_Bug, 1, (V[]){v_t_243});
  }
  case TAG_VCons: {
    V v_fs_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VCons = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(v_x2_241, heff_rfield(v_fs_244, 1)));
    V v_t_2411;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop_rec(v_fs_244, 3);
      v_t_2411 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_i_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V v_xs_247 = heff_get_n(v_fs_244, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_246))) {
        if (heff_intLt_c(heff_dup(v_i_246), heff_arrayLength(heff_dup(v_xs_247)))) {
          V v_v_2410 = heff_arrayIndex(v_xs_247, v_i_246);
          v_t_2411 = v_v_2410;
        } else {
          heff_drop(v_i_246);
          heff_drop(v_xs_247);
          v_t_2411 = heff_abandon();
        }
      } else {
        heff_drop(v_i_246);
        heff_drop(v_xs_247);
        v_t_2411 = heff_abandon();
      }
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return heff_tag_at_n(v_ru_24x1_240_24VCons, TAG_Ok, 1, (V[]){v_t_2411});
  }
  case TAG_VTag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str2), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str3)));
    return heff_tag_n(TAG_Bug, 1, (V[]){v_t_2414});
  }
  case TAG_VInt: {
    V v_ru_24x1_240_24VInt = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str4), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str5)));
    return heff_tag_at_n(v_ru_24x1_240_24VInt, TAG_Bug, 1, (V[]){v_t_2416});
  }
  case TAG_VFloat: {
    V v_ru_24x1_240_24VFloat = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str6), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str7)));
    return heff_tag_at_n(v_ru_24x1_240_24VFloat, TAG_Bug, 1, (V[]){v_t_2418});
  }
  case TAG_VFloat32: {
    V v_ru_24x1_240_24VFloat32 = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str8), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str9)));
    return heff_tag_at_n(v_ru_24x1_240_24VFloat32, TAG_Bug, 1, (V[]){v_t_2420});
  }
  case TAG_VStr: {
    V v_ru_24x1_240_24VStr = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str10), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str11)));
    return heff_tag_at_n(v_ru_24x1_240_24VStr, TAG_Bug, 1, (V[]){v_t_2422});
  }
  case TAG_VRune: {
    V v_ru_24x1_240_24VRune = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str12), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str13)));
    return heff_tag_at_n(v_ru_24x1_240_24VRune, TAG_Bug, 1, (V[]){v_t_2424});
  }
  case TAG_VArr: {
    V v_ru_24x1_240_24VArr = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str14), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str15)));
    return heff_tag_at_n(v_ru_24x1_240_24VArr, TAG_Bug, 1, (V[]){v_t_2426});
  }
  case TAG_VBytes: {
    V v_ru_24x1_240_24VBytes = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprojV_str16), heff_strAppend(v_x2_241, ((V)&g_heff_2ecompile_2einterp_2eprojV_str17)));
    return heff_tag_at_n(v_ru_24x1_240_24VBytes, TAG_Bug, 1, (V[]){v_t_2428});
  }
  case TAG_VErased: {
    heff_drop(v_x2_241);
    return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eprojV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprojV(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2estr2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2estr2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2estr2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2estr2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2estr2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2estr2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2estr2(a[0]);
}
V g_heff_2ecompile_2einterp_2estr2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VStr: {
        V v_a_2416 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VStr: {
          V v_b_2424 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2416;
          args[1] = v_b_2424;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2416);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2estr2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2estr2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebytesOfIntV_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebytesOfIntV_str1, 0, "");
Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytesOfIntV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebytesOfIntV(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_f_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Abn);
  } else {
    if (heff_intLt_c(MK_INT(64LL), heff_dup(v_n_240))) {
      heff_drop(v_n_240);
      heff_drop(v_f_241);
      heff_drop(v_v_242);
      return NTAG(TAG_Abn);
    } else {
      if (heff_intEq_c(heff_intMod(heff_dup(v_n_240), MK_INT(8LL)), MK_INT(0LL))) {
        V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
        V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
        V v_t_248 = heff_intAdd(heff_intMod(v_v_242, v_t_246), v_t_247);
        V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
        V v_b_2410 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_intDiv(v_n_240, MK_INT(8LL)), heff_intMod(v_t_248, v_t_249), ((V)&g_heff_2ecompile_2einterp_2ebytesOfIntV_str0)));
        V v_t_2412;
        if (heff_intEq_c(heff_intMod(v_f_241, MK_INT(2LL)), MK_INT(1LL))) {
          v_t_2412 = (g_heff_2ecompile_2einterp_2ereversedBytes(v_b_2410, MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2ebytesOfIntV_str1)));
        } else {
          v_t_2412 = v_b_2410;
        }
        return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_2412})});
      } else {
        heff_drop(v_n_240);
        heff_drop(v_f_241);
        heff_drop(v_v_242);
        return NTAG(TAG_Abn);
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebytesOfIntV(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2ef32V2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2ef32V2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2ef32V2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2ef32V2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ef32V2(a[0]);
}
V g_heff_2ecompile_2einterp_2ef32V2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2415 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2422 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2415;
          args[1] = v_b_2422;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2415);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_st;
static V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_st)) return g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_val, &g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_st, g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_init);
}
V g_heff_2ecompile_2einterp_2ef32V1_24s1760328150x1100035578_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VFloat32: {
      V v_a_2410 = heff_field(v_v_243, 0);
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 1ULL, 1);
      double v_x_2411 = ((double)heff_peek_f32(v_a_2410));
      if (((v_x_2411 - v_x_2411) == (0.0))) {
        V v_t_2413 = heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_VInt, 1, (V[]){heff_floor_f32(heff_unbox_f32(v_a_2410))});
        return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){v_t_2413});
      } else {
        heff_drop(v_a_2410);
        heff_drop_cell(v_ru_24v_243_24VFloat32, 1);
        return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VStr: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2418 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2418});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_st)) return g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_val, &g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_st, g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64((v_a_2413 * v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_st)) return g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_val, &g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_st, g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan2(v_a_2413, v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_lam1, 2, 1, (V[]){v_a_241})})});
}