// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_GivenOther 31238
#define TAG_GivenSame 9069
#define TAG_GivenTag 49870
#define TAG_ManyTags 51265
#define TAG_MkArm 55352
#define TAG_NoTag 1821
#define TAG_OneTag 13947
#define TAG_Tip 31527
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_last 9809757
#define LBL_name 9869138
#define LBL_slots 310891087
#define LBL_tag 324116
#define LBL_tys 324872
#define LBL_vars 10107635
static uint32_t shape_key__body__last__args[] = {LBL_key, LBL_body, LBL_last, LBL_args};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2escalars_2eselfLast(V, V, V);
V g_heff_2ecompile_2escalars_2eselfLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eselfLast_clo;
V g_heff_2ecompile_2eunbox_2eaddGiven(V, V);
V g_heff_2ecompile_2eunbox_2eaddGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eaddGiven_clo;
V g_heff_2ecompile_2eunbox_2eargsRw(V, V, V, V);
V g_heff_2ecompile_2eunbox_2eargsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eargsRw_clo;
V g_heff_2ecompile_2eunbox_2ecallerCall(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallerCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallerCall_clo;
V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallerCall_24tok2_clo;
V g_heff_2ecompile_2eunbox_2ecallersIn(V, V);
V g_heff_2ecompile_2eunbox_2ecallersIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersIn_clo;
V g_heff_2ecompile_2eunbox_2ecallersRw(V, V);
V g_heff_2ecompile_2eunbox_2ecallersRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersRw_clo;
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ecallersRw_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallersRw_24dps_clo;
V g_heff_2ecompile_2eunbox_2ecallsLoopW(V, V);
V g_heff_2ecompile_2eunbox_2ecallsLoopW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallsLoopW_clo;
V g_heff_2ecompile_2eunbox_2ecallsW(V, V, V);
V g_heff_2ecompile_2eunbox_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ecallsW_clo;
V g_heff_2ecompile_2eunbox_2efirstApart(V, V, V, V);
V g_heff_2ecompile_2eunbox_2efirstApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2efirstApart_clo;
V g_heff_2ecompile_2eunbox_2eisBuilt(V, V);
V g_heff_2ecompile_2eunbox_2eisBuilt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eisBuilt_clo;
V g_heff_2ecompile_2eunbox_2ejustsOf(V);
V g_heff_2ecompile_2eunbox_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ejustsOf_clo;
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2eunbox_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2eunbox_2ematchRw(V, V, V, V);
V g_heff_2ecompile_2eunbox_2ematchRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ematchRw_clo;
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ematchRw_24tok2_clo;
V g_heff_2ecompile_2eunbox_2eparamsRw(V, V, V);
V g_heff_2ecompile_2eunbox_2eparamsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eparamsRw_clo;
V g_heff_2ecompile_2eunbox_2erw(V, V);
V g_heff_2ecompile_2eunbox_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2erw_clo;
V g_heff_2ecompile_2eunbox_2erw_24dps(V, V, V, V);
V g_heff_2ecompile_2eunbox_2erw_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2erw_24dps_clo;
V g_heff_2ecompile_2eunbox_2eslotsIn(V, V);
V g_heff_2ecompile_2eunbox_2eslotsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotsIn_clo;
V g_heff_2ecompile_2eunbox_2eslotsOf(V);
V g_heff_2ecompile_2eunbox_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2eslotsOf_clo;
V g_heff_2ecompile_2eunbox_2esomeApart(V, V);
V g_heff_2ecompile_2eunbox_2esomeApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2esomeApart_clo;
V g_heff_2ecompile_2eunbox_2espread(V, V, V);
V g_heff_2ecompile_2eunbox_2espread_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2espread_clo;
V g_heff_2ecompile_2eunbox_2etakesApart(V, V, V, V, V);
V g_heff_2ecompile_2eunbox_2etakesApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2etakesApart_clo;
V g_heff_2ecompile_2eunbox_2ewrapBody(V, V, V);
V g_heff_2ecompile_2eunbox_2ewrapBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2ewrapBody_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1371286946x1388406575_24cpr(V, V);
V g_list_2efind_24s1734629631x1085593985(V, V);
V g_list_2efind_24s1734629631x1085593985_entry(V self, V *a);
extern Clo g_list_2efind_24s1734629631x1085593985_clo;
HeffT2 g_list_2efind_24s1734629631x1085593985_24cpr(V, V);
V g_list_2efind_24s1734629631x1085593985_24tok1(V, V, V);
V g_list_2efind_24s1734629631x1085593985_24tok1_entry(V self, V *a);
extern Clo g_list_2efind_24s1734629631x1085593985_24tok1_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1023948938x380005785(V, V, V);
V g_list_2ezipWith_24s1023948938x380005785_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1023948938x380005785_clo;
V g_list_2ezipWith_24s1893966264x617194987(V, V);
V g_list_2ezipWith_24s1893966264x617194987_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1893966264x617194987_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_heff_2ecompile_2eunbox_2efirstApart_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2efirstApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2efirstApart_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2efirstApart(V v_p_240, V v_t_241, V v_k_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_e_243, 1);
    V v_b_2412 = heff_field(v_e_243, 2);
    V v_t_2413 = (g_heff_2ecompile_2eir_2eisValue(v_a_2411));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      V t_0 = v_p_240;
      V t_1 = v_t_241;
      V t_2 = v_k_242;
      V t_3 = v_b_2412;
      v_p_240 = t_0;
      v_t_241 = t_1;
      v_k_242 = t_2;
      v_e_243 = t_3;
      goto top;
    } else {
      heff_drop(v_k_242);
      heff_drop(v_t_2413);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_e_243, 0);
    V v_arms_2424 = heff_field(v_e_243, 1);
    V v_t_2425 = (g_heff_2ecompile_2eunbox_2etakesApart(v_p_240, v_t_241, heff_dup(v_k_242), v_s_2423, v_arms_2424));
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_k_242);
      heff_drop(v_t_2425);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2425);
      switch (heff_tag_of(v_s_2423)) {
      case TAG_EVar: {
        switch (heff_tag_of(v_arms_2424)) {
        case TAG_Nil: {
          heff_drop(v_k_242);
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          return (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eunbox_2efirstApart_lam0, 1, 3, (V[]){heff_dup(v_p_240), heff_dup(v_t_241), v_k_242}), v_arms_2424));
        }
        default: return heff_nomatch(v_arms_2424);
        }
      }
      case TAG_EGlobal: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_drop(v_k_242);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_2423);
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_k_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2eunbox_2efirstApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2eunbox_2efirstApart(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eunbox_2efirstApart_lam0(V self, V *args) {
  V v_a_2429 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433;
  switch (heff_tag_of(v_a_2429)) {
  case TAG_MkArm: {
    V v_b_2432 = heff_field(v_a_2429, 2);
    heff_take_n(v_a_2429, 4ULL, 3);
    v_t_2433 = v_b_2432;
    break;
  }
  default: heff_nomatch(v_a_2429);
  }
  return ({ V a_0 = v_p_240; V a_1 = v_t_241; V a_2 = v_k_242; V a_3 = v_t_2433; V r_ = (g_heff_2ecompile_2eunbox_2efirstApart(a_0, a_1, a_2, a_3)); heff_drop(v_p_240); heff_drop(v_t_241); heff_drop(v_t_2433); r_; });
}
Clo g_heff_2ecompile_2eunbox_2eaddGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eaddGiven_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2eaddGiven(V v_s_240, V v_g_241) {
top: ;
  switch (heff_tag_of(v_g_241)) {
  case TAG_GivenTag: {
    V v_g1_242 = heff_field(v_g_241, 0);
    V v_g2_243 = heff_field(v_g_241, 1);
    V v_ru_24g_241_24GivenTag = heff_take_reuse_n(v_g_241, 3ULL, 2);
    switch (heff_tag_of(v_s_240)) {
    case TAG_NoTag: {
      return heff_tag_at_n(v_ru_24g_241_24GivenTag, TAG_OneTag, 2, (V[]){v_g1_242, v_g2_243});
    }
    case TAG_OneTag: {
      V v_t_244 = heff_field(v_s_240, 0);
      V v_ts_245 = heff_field(v_s_240, 1);
      heff_take_n(v_s_240, 3ULL, 2);
      if ((heff_strEq_c_lent(v_t_244, v_g1_242, 0) && ({ V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_245)); int c_ = ({ V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_g2_243)); int c_ = heff_intEq_c_lent(v_t_247, v_t_248, 0); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; }))) {
        heff_drop(v_g1_242);
        V v_t_246 = (g_list_2ezipWith_24s1893966264x617194987(v_ts_245, v_g2_243));
        return heff_tag_at_n(v_ru_24g_241_24GivenTag, TAG_OneTag, 2, (V[]){v_t_244, v_t_246});
      } else {
        heff_drop(v_g1_242);
        heff_drop(v_g2_243);
        heff_drop_cell(v_ru_24g_241_24GivenTag, 2);
        heff_drop(v_t_244);
        heff_drop(v_ts_245);
        return NTAG(TAG_ManyTags);
      }
    }
    case TAG_ManyTags: {
      heff_drop(v_g1_242);
      heff_drop(v_g2_243);
      heff_drop_cell(v_ru_24g_241_24GivenTag, 2);
      return NTAG(TAG_ManyTags);
    }
    default: return heff_nomatch(v_s_240);
    }
  }
  case TAG_GivenSame: {
    return v_s_240;
  }
  case TAG_GivenOther: {
    heff_drop(v_s_240);
    return NTAG(TAG_ManyTags);
  }
  default: return heff_nomatch(v_g_241);
  }
}
V g_heff_2ecompile_2eunbox_2eaddGiven_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eaddGiven(a[0], a[1]);
}
Clo g_heff_2ecompile_2eunbox_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2eunbox_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ms_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eunbox_2ejustsOf_24dps(v_ms_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eunbox_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ejustsOf(a[0]);
}
V g_heff_2ecompile_2eunbox_2eslotsIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eslotsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotsIn_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2eslotsIn(V v_xs_240, V v_c_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_c_241, 3));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop(v_xs_240);
    heff_drop_rec(v_c_241, 4);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    heff_take_n(v_t_242, 0ULL, 2);
    V v_t_248 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eunbox_2eslotsIn_lam0, 1, 1, (V[]){heff_dup(v_xs_240)}), heff_rfield(v_c_241, 3)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_xs_240);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_t_248);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_248);
      V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_240));
      V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(1LL))));
      V v_t_2411 = (g_list_2ezipWith_24s1023948938x380005785(v_c_241, v_xs_240, v_t_2410));
      return (g_heff_2ecompile_2eunbox_2ejustsOf(v_t_2411));
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eunbox_2eslotsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotsIn(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2eslotsIn_lam0(V self, V *args) {
  V v_argv_245 = args[0];
  V v_xs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_argv_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_argv_245); r_; });
  V v_y_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_240; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_240); r_; });
  V v_ret_24bool = heff_bool(!heff_intEq_c_lent(v_x_246, v_y_247, 0));
  heff_drop(v_x_246);
  heff_drop(v_y_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eunbox_2eslotsOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2eslotsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eslotsOf_entry, 1, 0};

V g_heff_2ecompile_2eunbox_2eslotsOf(V v_d_240) {
top: ;
  V v_body_241 = heff_take_field(v_d_240, 2);
  V v_key_242 = heff_get_n(v_d_240, 0, 3);
  switch (heff_tag_of(v_body_241)) {
  case TAG_EVar: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_body_241, 0);
    V v_b_246 = heff_field(v_body_241, 1);
    V v_ru_24body_241_24ELam = heff_take_reuse_n(v_body_241, 3ULL, 2);
    V v_t_248 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2eunbox_2eslotsOf_lam0, 1, 1, (V[]){heff_dup(v_b_246)}), v_xs_245));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_f_249 = heff_dup(v_key_242);
      V v_t_2410 = heff_tag_at_n(v_ru_24body_241_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_b_246), NTAG(TAG_Nil)});
      V v_args_2411 = ({ V a_0 = v_key_242; V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_heff_2ecompile_2eunbox_2ecallsW(a_0, a_1, a_2)); heff_drop(v_key_242); r_; });
      V v_xs_2412 = (g_heff_2ecompile_2escalars_2eselfLast(v_f_249, NTAG(TAG_Nil), heff_dup(v_b_246)));
      V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2412; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2411));
      V v_t_2415 = heff_bool(heff_intEq_c_lent(v_t_2413, v_t_2414, 0));
      heff_drop(v_t_2413);
      heff_drop(v_t_2414);
      return (g_heff_2ecompile_2eunbox_2eslotsIn(v_xs_245, heff_rec_n(4, shape_key__body__last__args, (V[]){v_f_249, v_b_246, v_t_2415, v_args_2411})));
    } else {
      heff_drop(v_key_242);
      heff_drop(v_xs_245);
      heff_drop(v_b_246);
      heff_drop_cell(v_ru_24body_241_24ELam, 2);
      heff_drop(v_t_248);
      return NTAG(TAG_Nil);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_body_241, 0ULL, 2);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_body_241, 0ULL, 3);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_body_241, 0ULL, 2);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_body_241, 0ULL, 4);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_body_241, 0ULL, 3);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_take_n(v_body_241, 0ULL, 2);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_241, 0ULL, 2);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_body_241, 0ULL, 2);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_body_241, 0ULL, 2);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    heff_take_n(v_body_241, 0ULL, 3);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EValues: {
    heff_take_n(v_body_241, 0ULL, 1);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_body_241, 0ULL, 2);
    heff_drop(v_key_242);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_body_241);
  }
}
V g_heff_2ecompile_2eunbox_2eslotsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eslotsOf(a[0]);
}
V g_heff_2ecompile_2eunbox_2eslotsOf_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_b_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_247; V a_1 = v_b_246; V r_ = (g_heff_2ecompile_2eunbox_2esomeApart(a_0, a_1)); heff_drop(v_x_247); heff_drop(v_b_246); r_; });
}
Clo g_heff_2ecompile_2eunbox_2espread_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2espread_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2espread(V v_go_240, V v_s_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EGlobal: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ELam: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EApp: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ELet: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ERecord: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EProj: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ETag: {
    V v_argv_2419 = heff_field(v_e_242, 1);
    heff_drop_rec(v_s_241, 5);
    return (g_list_2emap(v_go_240, heff_dup(v_argv_2419)));
  }
  case TAG_EMatch: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EPrim: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EPrimCall: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ECall: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EInt: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFloat: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EStr: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EBytes: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFixed: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFloat32: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EAbandon: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EBool: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ESet: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EValues: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFix: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eunbox_2espread_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eunbox_2espread(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_lam1(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_lam2(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_lam3(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ematchRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ematchRw_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2ematchRw(V v_go_240, V v_s_241, V v_arms_242, V v_m_243) {
top: ;
  switch (heff_tag_of(v_arms_242)) {
  case TAG_Nil: {
    V v_t_244 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
    V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam0, 1, 1, (V[]){v_go_240}), v_arms_242));
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_244, v_t_2419});
  }
  case TAG_Cons: {
    V v_arms1_2420 = heff_dup(heff_field(v_arms_242, 0));
    V v_arms2_2421 = heff_dup(heff_field(v_arms_242, 1));
    switch (heff_tag_of(v_arms1_2420)) {
    case TAG_MkArm: {
      V v_t_2422 = heff_field(v_arms1_2420, 0);
      V v_vs_2423 = heff_field(v_arms1_2420, 1);
      V v_b_2424 = heff_field(v_arms1_2420, 2);
      V v_ru_24arms1_2420_24MkArm = heff_take_reuse_n(v_arms1_2420, 7ULL, 3);
      switch (heff_tag_of(v_arms2_2421)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_m_243)) {
        case TAG_Nothing: {
          heff_drop(v_t_2422);
          heff_drop(v_vs_2423);
          heff_drop(v_b_2424);
          heff_drop_cell(v_ru_24arms1_2420_24MkArm, 3);
          V v_t_2425 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
          V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam1, 1, 1, (V[]){v_go_240}), v_arms_242));
          return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2425, v_t_2440});
        }
        case TAG_Just: {
          V v_sl_2441 = heff_field(v_m_243, 0);
          heff_drop_tag(v_arms_242, 2);
          V v_tag_2442 = heff_dup(heff_rfield(v_sl_2441, 2));
          V v_vars_2443 = heff_dup(heff_rfield(v_sl_2441, 4));
          if (heff_strEq_c_lent(v_t_2422, v_tag_2442, 2)) {
            heff_drop(v_s_241);
            heff_drop(v_t_2422);
            heff_drop_cell(v_ru_24arms1_2420_24MkArm, 3);
            V v_ps_2444 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_2423, v_vars_2443));
            V v_m_2445 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2444; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2444); r_; });
            V v_t_2446 = (g_std_2emap_2esize(v_m_2445));
            V v_t_2447;
            if (heff_intEq_c(v_t_2446, MK_INT(0LL))) {
              heff_drop(v_m_2445);
              v_t_2447 = v_b_2424;
            } else {
              v_t_2447 = ({ V a_0 = v_m_2445; V a_1 = v_b_2424; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2445); r_; });
            }
            return heff_tail(v_go_240, 1, (V[]){v_t_2447});
          } else {
            heff_drop(v_vars_2443);
            V v_t_2448 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
            V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24arms1_2420_24MkArm, TAG_MkArm, 3, (V[]){v_t_2422, v_vs_2423, v_b_2424}), NTAG(TAG_Nil)});
            V v_t_2464 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam2, 1, 1, (V[]){v_go_240}), v_t_2449));
            return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2448, v_t_2464});
          }
        }
        default: return heff_nomatch(v_m_243);
        }
      }
      case TAG_Cons: {
        V v_ru_24arms2_2421_24Cons = heff_take_reuse_n(v_arms2_2421, 0ULL, 2);
        heff_drop(v_t_2422);
        heff_drop(v_vs_2423);
        heff_drop(v_b_2424);
        heff_drop_cell(v_ru_24arms1_2420_24MkArm, 3);
        V v_t_2467 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_s_241}));
        V v_t_2482 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_lam3, 1, 1, (V[]){v_go_240}), v_arms_242));
        return heff_tag_at_n(v_ru_24arms2_2421_24Cons, TAG_EMatch, 2, (V[]){v_t_2467, v_t_2482});
      }
      default: return heff_nomatch(v_arms2_2421);
      }
    }
    default: return heff_nomatch(v_arms1_2420);
    }
  }
  default: return heff_nomatch(v_arms_242);
  }
}
V g_heff_2ecompile_2eunbox_2ematchRw_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eunbox_2ematchRw(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_a_245)) {
  case TAG_MkArm: {
    V v_t_246 = heff_dup(heff_field(v_a_245, 0));
    v_t_249 = v_t_246;
    break;
  }
  default: heff_nomatch(v_a_245);
  }
  V v_t_2413;
  switch (heff_tag_of(v_a_245)) {
  case TAG_MkArm: {
    V v_vs_2411 = heff_dup(heff_field(v_a_245, 1));
    v_t_2413 = v_vs_2411;
    break;
  }
  default: heff_nomatch(v_a_245);
  }
  V v_t_2417;
  switch (heff_tag_of(v_a_245)) {
  case TAG_MkArm: {
    V v_b_2416 = heff_field(v_a_245, 2);
    heff_take_n(v_a_245, 4ULL, 3);
    v_t_2417 = v_b_2416;
    break;
  }
  default: heff_nomatch(v_a_245);
  }
  V v_t_2418 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2417}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_t_2413, v_t_2418});
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam1(V self, V *args) {
  V v_a_2426 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_a_2426)) {
  case TAG_MkArm: {
    V v_t_2427 = heff_dup(heff_field(v_a_2426, 0));
    v_t_2430 = v_t_2427;
    break;
  }
  default: heff_nomatch(v_a_2426);
  }
  V v_t_2434;
  switch (heff_tag_of(v_a_2426)) {
  case TAG_MkArm: {
    V v_vs_2432 = heff_dup(heff_field(v_a_2426, 1));
    v_t_2434 = v_vs_2432;
    break;
  }
  default: heff_nomatch(v_a_2426);
  }
  V v_t_2438;
  switch (heff_tag_of(v_a_2426)) {
  case TAG_MkArm: {
    V v_b_2437 = heff_field(v_a_2426, 2);
    heff_take_n(v_a_2426, 4ULL, 3);
    v_t_2438 = v_b_2437;
    break;
  }
  default: heff_nomatch(v_a_2426);
  }
  V v_t_2439 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2438}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2430, v_t_2434, v_t_2439});
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam2(V self, V *args) {
  V v_a_2450 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2454;
  switch (heff_tag_of(v_a_2450)) {
  case TAG_MkArm: {
    V v_t_2451 = heff_dup(heff_field(v_a_2450, 0));
    v_t_2454 = v_t_2451;
    break;
  }
  default: heff_nomatch(v_a_2450);
  }
  V v_t_2458;
  switch (heff_tag_of(v_a_2450)) {
  case TAG_MkArm: {
    V v_vs_2456 = heff_dup(heff_field(v_a_2450, 1));
    v_t_2458 = v_vs_2456;
    break;
  }
  default: heff_nomatch(v_a_2450);
  }
  V v_t_2462;
  switch (heff_tag_of(v_a_2450)) {
  case TAG_MkArm: {
    V v_b_2461 = heff_field(v_a_2450, 2);
    heff_take_n(v_a_2450, 4ULL, 3);
    v_t_2462 = v_b_2461;
    break;
  }
  default: heff_nomatch(v_a_2450);
  }
  V v_t_2463 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2462}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2454, v_t_2458, v_t_2463});
}
V g_heff_2ecompile_2eunbox_2ematchRw_lam3(V self, V *args) {
  V v_a_2468 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472;
  switch (heff_tag_of(v_a_2468)) {
  case TAG_MkArm: {
    V v_t_2469 = heff_dup(heff_field(v_a_2468, 0));
    v_t_2472 = v_t_2469;
    break;
  }
  default: heff_nomatch(v_a_2468);
  }
  V v_t_2476;
  switch (heff_tag_of(v_a_2468)) {
  case TAG_MkArm: {
    V v_vs_2474 = heff_dup(heff_field(v_a_2468, 1));
    v_t_2476 = v_vs_2474;
    break;
  }
  default: heff_nomatch(v_a_2468);
  }
  V v_t_2480;
  switch (heff_tag_of(v_a_2468)) {
  case TAG_MkArm: {
    V v_b_2479 = heff_field(v_a_2468, 2);
    heff_take_n(v_a_2468, 4ULL, 3);
    v_t_2480 = v_b_2479;
    break;
  }
  default: heff_nomatch(v_a_2468);
  }
  V v_t_2481 = heff_tr(heff_call(v_go_240, 1, (V[]){v_t_2480}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2472, v_t_2476, v_t_2481});
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2erw_str0, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2erw_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2erw_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2erw(V v_lp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_list_2efind_24s1734629631x1085593985_24cpr(v_x_242, heff_get_n(v_lp_240, 1, 2)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        V v_s_246 = v_field_245;
        V v_tag_247 = heff_take_field(v_s_246, 2);
        V v_vars_248 = heff_take_field(v_s_246, 4);
        V v_tys_249 = heff_get_n(v_s_246, 3, 5);
        V v_t_2410 = (g_list_2emap_24s1809017761x1063871171_24tok1(v_ru_24x2_241_24EVar, v_vars_248));
        return heff_tag_n(TAG_ETag, 3, (V[]){v_tag_247, v_t_2410, v_tys_249});
      } else {
        heff_drop(v_field_245);
        return heff_tag_at_n(v_ru_24x2_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_2412 = heff_field(v_x2_241, 0);
    V v_b_2413 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2412, heff_hole()});
    V v_u_2415 = (g_heff_2ecompile_2eunbox_2erw_24dps(v_lp_240, v_b_2413, heff_dup(v_cell_2414), MK_INT(1LL)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  case TAG_EApp: {
    V v_f_2416 = heff_field(v_x2_241, 0);
    V v_argv_2417 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2418 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_f_2416));
    V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2420 = (g_list_2emap(v_t_2419, v_argv_2417));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2418, v_t_2420});
  }
  case TAG_ELet: {
    V v_x_2421 = heff_field(v_x2_241, 0);
    V v_a_2422 = heff_field(v_x2_241, 1);
    V v_b_2423 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2424 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_a_2422));
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2421, v_t_2424, heff_hole()});
    V v_u_2426 = (g_heff_2ecompile_2eunbox_2erw_24dps(v_lp_240, v_b_2423, heff_dup(v_cell_2425), MK_INT(2LL)));
    heff_drop(v_u_2426);
    return v_cell_2425;
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_x2_241, 0);
    V v_ts_2428 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2437 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2erw_lam0, 1, 1, (V[]){v_lp_240}), v_fs_2427));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2437, v_ts_2428});
  }
  case TAG_EProj: {
    V v_e_2438 = heff_field(v_x2_241, 0);
    V v_l_2439 = heff_field(v_x2_241, 1);
    V v_sh_2440 = heff_field(v_x2_241, 2);
    V v_t_2441 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2442 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_e_2438));
    return heff_tag_at_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, (V[]){v_t_2442, v_l_2439, v_sh_2440, v_t_2441});
  }
  case TAG_ETag: {
    V v_t_2443 = heff_field(v_x2_241, 0);
    V v_argv_2444 = heff_field(v_x2_241, 1);
    V v_ts_2445 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2447 = (g_list_2emap(v_t_2446, v_argv_2444));
    return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, (V[]){v_t_2443, v_t_2447, v_ts_2445});
  }
  case TAG_EMatch: {
    V v_s_2448 = heff_field(v_x2_241, 0);
    V v_arms_2449 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    V v_t_2490;
    switch (heff_tag_of(v_s_2448)) {
    case TAG_EVar: {
      V v_x_2451 = heff_dup(heff_field(v_s_2448, 0));
      v_t_2490 = ({ V a_0 = v_x_2451; V a_1 = heff_get_n(v_lp_240, 1, 2); V r_ = (g_list_2efind_24s1734629631x1085593985(a_0, a_1)); heff_drop(v_x_2451); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_drop_rec(v_lp_240, 2);
      v_t_2490 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_s_2448);
    }
    return ({ V a_0 = v_ru_24x2_241_24EMatch; V a_1 = v_t_2450; V a_2 = v_s_2448; V a_3 = v_arms_2449; V a_4 = v_t_2490; V r_ = (g_heff_2ecompile_2eunbox_2ematchRw_24tok2(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2490); r_; });
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_2492 = heff_field(v_x2_241, 0);
    V v_argv_2493 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2494 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2495 = (g_list_2emap(v_t_2494, v_argv_2493));
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2492, v_t_2495});
  }
  case TAG_ECall: {
    V v_g_2496 = heff_field(v_x2_241, 0);
    V v_argv_2497 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2496), heff_dup(heff_rfield(v_lp_240, 0)))) {
      V v_t_2498 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
      V v_t_2499 = (g_heff_2ecompile_2eunbox_2eargsRw(v_t_2498, heff_get_n(v_lp_240, 1, 2), MK_INT(0LL), v_argv_2497));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){heff_strAppend(v_g_2496, ((V)&g_heff_2ecompile_2eunbox_2erw_str0)), v_t_2499});
    } else {
      V v_t_24100 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
      V v_t_24101 = (g_list_2emap(v_t_24100, v_argv_2497));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_2496, v_t_24101});
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EBool: {
    V v_c_24109 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EBool = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24110 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_24111 = (g_heff_2ecompile_2eir_2econdMap(v_t_24110, v_c_24109));
    return heff_tag_at_n(v_ru_24x2_241_24EBool, TAG_EBool, 1, (V[]){v_t_24111});
  }
  case TAG_ESet: {
    V v_xs_24112 = heff_field(v_x2_241, 0);
    V v_a_24113 = heff_field(v_x2_241, 1);
    V v_b_24114 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ESet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_24115 = heff_tr(g_heff_2ecompile_2eunbox_2erw(heff_dup(v_lp_240), v_a_24113));
    V v_cell_24116 = heff_tag_at_n(v_ru_24x2_241_24ESet, TAG_ESet, 3, (V[]){v_xs_24112, v_t_24115, heff_hole()});
    V v_u_24117 = (g_heff_2ecompile_2eunbox_2erw_24dps(v_lp_240, v_b_24114, heff_dup(v_cell_24116), MK_INT(2LL)));
    heff_drop(v_u_24117);
    return v_cell_24116;
  }
  case TAG_EValues: {
    V v_es_24118 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EValues = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24119 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_24120 = (g_list_2emap(v_t_24119, v_es_24118));
    return heff_tag_at_n(v_ru_24x2_241_24EValues, TAG_EValues, 1, (V[]){v_t_24120});
  }
  case TAG_EFix: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2erw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2erw(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2erw_lam0(V self, V *args) {
  V v_p_2429 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432;
  switch (heff_tag_of(v_p_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_dup(heff_field(v_p_2429, 0));
    v_t_2432 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_p_2429);
  }
  V v_t_2435;
  switch (heff_tag_of(v_p_2429)) {
  case TAG_MkPair: {
    V v_y_2434 = heff_field(v_p_2429, 1);
    heff_take_n(v_p_2429, 2ULL, 2);
    v_t_2435 = v_y_2434;
    break;
  }
  default: heff_nomatch(v_p_2429);
  }
  V v_t_2436 = heff_tr(g_heff_2ecompile_2eunbox_2erw(v_lp_240, v_t_2435));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2432, v_t_2436});
}
Clo g_heff_2ecompile_2eunbox_2eparamsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2eparamsRw_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2eparamsRw(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ss_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_list_2efind_24s1371286946x1388406575_24cpr(heff_dup(v_i_241), heff_dup(v_ss_240)));
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_s_248 = v_field_247;
        v_t_249 = heff_get_n(v_s_248, 4, 5);
      } else {
        heff_drop(v_field_247);
        v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    V v_t_2410 = (g_heff_2ecompile_2eunbox_2eparamsRw(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eunbox_2eparamsRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2eparamsRw(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2ewrapBody_str0, 0, "");
V g_heff_2ecompile_2eunbox_2ewrapBody_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ewrapBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ewrapBody_entry, 3, 0};

V g_heff_2ecompile_2eunbox_2ewrapBody(V v_ys_240, V v_ss_241, V v_call_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_241));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eunbox_2ewrapBody_lam0, 2, 1, (V[]){heff_dup(v_ys_240)}); V a_1 = v_call_242; V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
}
V g_heff_2ecompile_2eunbox_2ewrapBody_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eunbox_2ewrapBody(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eunbox_2ewrapBody_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_ys_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_at_246 = heff_take_field(v_x_245, 0);
  V v_tag_247 = heff_take_field(v_x_245, 2);
  V v_vars_248 = heff_get_n(v_x_245, 4, 5);
  HeffT3 v_t_249 = ({ V a_0 = v_at_246; V a_1 = v_ys_240; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ys_240); r_; });
  V v_t_2415;
  {
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_x_2413 = v_field_2411;
      V v_x12_2414 = v_field_2412;
      heff_drop(v_x12_2414);
      v_t_2415 = v_x_2413;
    } else {
      heff_drop(v_field_2411);
      heff_drop(v_field_2412);
      v_t_2415 = ((V)&g_heff_2ecompile_2eunbox_2ewrapBody_str0);
    }
  }
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_247, v_vars_248, v_acc_244}), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2415}), v_t_2416});
}
HEFF_LIT(g_heff_2ecompile_2eunbox_2ecallerCall_str0, 6, "$unbox");
V g_heff_2ecompile_2eunbox_2ecallerCall_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallerCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallerCall_entry, 4, 0};

V g_heff_2ecompile_2eunbox_2ecallerCall(V v_go_240, V v_g_241, V v_argv_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2emap(v_go_240, v_argv_242));
    return heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_t_244});
  }
  case TAG_Just: {
    V v_ss_245 = heff_field(v_x4_243, 0);
    V v_t_2414 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallerCall_lam0, 1, 1, (V[]){heff_dup(v_argv_242)}), v_ss_245));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V v_t_2415 = (g_heff_2ecompile_2eunbox_2eargsRw(v_go_240, heff_dup(v_ss_245), MK_INT(0LL), v_argv_242));
      return heff_tag_n(TAG_ECall, 2, (V[]){heff_strAppend(v_g_241, ((V)&g_heff_2ecompile_2eunbox_2ecallerCall_str0)), v_t_2415});
    } else {
      heff_drop(v_t_2414);
      V v_t_2416 = (g_list_2emap(v_go_240, v_argv_242));
      return heff_tag_n(TAG_ECall, 2, (V[]){v_g_241, v_t_2416});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eunbox_2ecallerCall_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eunbox_2ecallerCall(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eunbox_2ecallerCall_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_argv_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT3 v_t_247 = ({ V a_0 = heff_dup(heff_rfield(v_s_246, 0)); V a_1 = v_argv_242; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_argv_242); r_; });
  V v_t_2413;
  {
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_249;
      V v_x12_2412 = v_field_2410;
      heff_drop(v_x12_2412);
      v_t_2413 = v_x_2411;
    } else {
      heff_drop(v_field_249);
      heff_drop(v_field_2410);
      v_t_2413 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_s_246; V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2eunbox_2eisBuilt(a_0, a_1)); heff_drop(v_t_2413); r_; });
}
V g_heff_2ecompile_2eunbox_2ecallersRw_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ecallersRw_lam1(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallersRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallersRw_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ecallersRw(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_244, heff_hole()});
    V v_u_247 = (g_heff_2ecompile_2eunbox_2ecallersRw_24dps(v_m_240, v_b_245, heff_dup(v_cell_246), MK_INT(1LL)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_x2_241, 0);
    V v_argv_249 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2410 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_f_248));
    V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2412 = (g_list_2emap(v_t_2411, v_argv_249));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2410, v_t_2412});
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_x2_241, 0);
    V v_a_2414 = heff_field(v_x2_241, 1);
    V v_b_2415 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_a_2414));
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2413, v_t_2416, heff_hole()});
    V v_u_2418 = (g_heff_2ecompile_2eunbox_2ecallersRw_24dps(v_m_240, v_b_2415, heff_dup(v_cell_2417), MK_INT(2LL)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  case TAG_ERecord: {
    V v_fs_2419 = heff_field(v_x2_241, 0);
    V v_ts_2420 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_lam0, 1, 1, (V[]){v_m_240}), v_fs_2419));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2429, v_ts_2420});
  }
  case TAG_EProj: {
    V v_e_2430 = heff_field(v_x2_241, 0);
    V v_l_2431 = heff_field(v_x2_241, 1);
    V v_sh_2432 = heff_field(v_x2_241, 2);
    V v_t_2433 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2434 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_e_2430));
    return heff_tag_at_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, (V[]){v_t_2434, v_l_2431, v_sh_2432, v_t_2433});
  }
  case TAG_ETag: {
    V v_t_2435 = heff_field(v_x2_241, 0);
    V v_argv_2436 = heff_field(v_x2_241, 1);
    V v_ts_2437 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2439 = (g_list_2emap(v_t_2438, v_argv_2436));
    return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, (V[]){v_t_2435, v_t_2439, v_ts_2437});
  }
  case TAG_EMatch: {
    V v_s_2440 = heff_field(v_x2_241, 0);
    V v_arms_2441 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2442 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_s_2440));
    V v_go_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersRw_lam1, 1, 1, (V[]){v_go_2443}), v_arms_2441));
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2442, v_t_2458});
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_2460 = heff_field(v_x2_241, 0);
    V v_argv_2461 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2462 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2463 = (g_list_2emap(v_t_2462, v_argv_2461));
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2460, v_t_2463});
  }
  case TAG_ECall: {
    V v_g_2464 = heff_field(v_x2_241, 0);
    V v_argv_2465 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){heff_dup(v_m_240)}));
    V v_t_2467 = ({ V a_0 = v_m_240; V a_1 = v_g_2464; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_m_240); r_; });
    return ({ V a_0 = v_ru_24x2_241_24ECall; V a_1 = v_t_2466; V a_2 = v_g_2464; V a_3 = v_argv_2465; V a_4 = v_t_2467; V r_ = (g_heff_2ecompile_2eunbox_2ecallerCall_24tok2(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2467); r_; });
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  case TAG_EBool: {
    V v_c_2475 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EBool = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2477 = (g_heff_2ecompile_2eir_2econdMap(v_t_2476, v_c_2475));
    return heff_tag_at_n(v_ru_24x2_241_24EBool, TAG_EBool, 1, (V[]){v_t_2477});
  }
  case TAG_ESet: {
    V v_xs_2478 = heff_field(v_x2_241, 0);
    V v_a_2479 = heff_field(v_x2_241, 1);
    V v_b_2480 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ESet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2481 = (g_heff_2ecompile_2eunbox_2ecallersRw(heff_dup(v_m_240), v_a_2479));
    V v_cell_2482 = heff_tag_at_n(v_ru_24x2_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2478, v_t_2481, heff_hole()});
    V v_u_2483 = (g_heff_2ecompile_2eunbox_2ecallersRw_24dps(v_m_240, v_b_2480, heff_dup(v_cell_2482), MK_INT(2LL)));
    heff_drop(v_u_2483);
    return v_cell_2482;
  }
  case TAG_EValues: {
    V v_es_2484 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EValues = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2485 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eunbox_2ecallersRw_clo), 1, (V[]){v_m_240}));
    V v_t_2486 = (g_list_2emap(v_t_2485, v_es_2484));
    return heff_tag_at_n(v_ru_24x2_241_24EValues, TAG_EValues, 1, (V[]){v_t_2486});
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallersRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ecallersRw(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2ecallersRw_lam0(V self, V *args) {
  V v_p_2421 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_dup(heff_field(v_p_2421, 0));
    v_t_2424 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2427;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_y_2426 = heff_field(v_p_2421, 1);
    heff_take_n(v_p_2421, 2ULL, 2);
    v_t_2427 = v_y_2426;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2428 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, v_t_2427));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2428});
}
V g_heff_2ecompile_2eunbox_2ecallersRw_lam1(V self, V *args) {
  V v_a_2444 = args[0];
  V v_go_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448;
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_dup(heff_field(v_a_2444, 0));
    v_t_2448 = v_t_2445;
    break;
  }
  default: heff_nomatch(v_a_2444);
  }
  V v_t_2452;
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_vs_2450 = heff_dup(heff_field(v_a_2444, 1));
    v_t_2452 = v_vs_2450;
    break;
  }
  default: heff_nomatch(v_a_2444);
  }
  V v_t_2456;
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_b_2455 = heff_field(v_a_2444, 2);
    heff_take_n(v_a_2444, 4ULL, 3);
    v_t_2456 = v_b_2455;
    break;
  }
  default: heff_nomatch(v_a_2444);
  }
  V v_t_2457 = heff_tr(heff_call(v_go_2443, 1, (V[]){v_t_2456}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2448, v_t_2452, v_t_2457});
}
V g_heff_2ecompile_2eunbox_2ecallersIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ecallersIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ecallersIn_entry, 2, 0};

V g_heff_2ecompile_2eunbox_2ecallersIn(V v_m_240, V v_ds_241) {
top: ;
  V v_t_242 = (g_std_2emap_2esize(v_m_240));
  if (heff_intEq_c(v_t_242, MK_INT(0LL))) {
    heff_drop(v_m_240);
    return v_ds_241;
  } else {
    HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ecallersIn_lam0, 1, 1, (V[]){v_m_240}), v_ds_241);
  }
}
V g_heff_2ecompile_2eunbox_2ecallersIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eunbox_2ecallersIn(a[0], a[1]);
}
V g_heff_2ecompile_2eunbox_2ecallersIn_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_243, 2)), NTAG(TAG_Nil)});
  V v_t_245 = (g_heff_2ecompile_2eunbox_2ecallsLoopW(v_m_240, v_t_244));
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_body_246 = (g_heff_2ecompile_2eunbox_2ecallersRw(v_m_240, heff_take_field(v_d_243, 2)));
    return ({ V rv_2 = v_body_246; V rr_ = heff_rec_reuse_nf(v_d_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  } else {
    heff_drop(v_m_240);
    heff_drop(v_t_245);
    return v_d_243;
  }
}
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam2(V self, V *args);
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam3(V self, V *args);
Clo g_heff_2ecompile_2eunbox_2ematchRw_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eunbox_2ematchRw_24tok2_entry, 5, 0};

V g_heff_2ecompile_2eunbox_2ematchRw_24tok2(V v_tok_240, V v_go_241, V v_s_242, V v_arms_243, V v_m_244) {
top: ;
  switch (heff_tag_of(v_arms_243)) {
  case TAG_Nil: {
    V v_t_245 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_s_242}));
    V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam0, 1, 1, (V[]){v_go_241}), v_arms_243));
    return heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){v_t_245, v_t_2420});
  }
  case TAG_Cons: {
    V v_arms1_2421 = heff_dup(heff_field(v_arms_243, 0));
    V v_arms2_2422 = heff_dup(heff_field(v_arms_243, 1));
    switch (heff_tag_of(v_arms1_2421)) {
    case TAG_MkArm: {
      V v_t_2423 = heff_field(v_arms1_2421, 0);
      V v_vs_2424 = heff_field(v_arms1_2421, 1);
      V v_b_2425 = heff_field(v_arms1_2421, 2);
      heff_take_n(v_arms1_2421, 7ULL, 3);
      switch (heff_tag_of(v_arms2_2422)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_m_244)) {
        case TAG_Nothing: {
          heff_drop(v_t_2423);
          heff_drop(v_vs_2424);
          heff_drop(v_b_2425);
          V v_t_2426 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_s_242}));
          V v_t_2441 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam1, 1, 1, (V[]){v_go_241}), v_arms_243));
          return heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){v_t_2426, v_t_2441});
        }
        case TAG_Just: {
          V v_sl_2442 = heff_field(v_m_244, 0);
          heff_drop_tag(v_arms_243, 2);
          V v_tag_2443 = heff_dup(heff_rfield(v_sl_2442, 2));
          V v_vars_2444 = heff_dup(heff_rfield(v_sl_2442, 4));
          if (heff_strEq_c_lent(v_t_2423, v_tag_2443, 2)) {
            heff_drop_cell(v_tok_240, 2);
            heff_drop(v_s_242);
            heff_drop(v_t_2423);
            V v_ps_2445 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_2424, v_vars_2444));
            V v_m_2446 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2445; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2445); r_; });
            V v_t_2447 = (g_std_2emap_2esize(v_m_2446));
            V v_t_2448;
            if (heff_intEq_c(v_t_2447, MK_INT(0LL))) {
              heff_drop(v_m_2446);
              v_t_2448 = v_b_2425;
            } else {
              v_t_2448 = ({ V a_0 = v_m_2446; V a_1 = v_b_2425; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2446); r_; });
            }
            return heff_tail(v_go_241, 1, (V[]){v_t_2448});
          } else {
            heff_drop(v_vars_2444);
            V v_t_2449 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_s_242}));
            V v_t_2450 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2423, v_vs_2424, v_b_2425}), NTAG(TAG_Nil)});
            V v_t_2465 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam2, 1, 1, (V[]){v_go_241}), v_t_2450));
            return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2449, v_t_2465});
          }
        }
        default: return heff_nomatch(v_m_244);
        }
      }
      case TAG_Cons: {
        V v_ru_24arms2_2422_24Cons = heff_take_reuse_n(v_arms2_2422, 0ULL, 2);
        heff_drop(v_t_2423);
        heff_drop(v_vs_2424);
        heff_drop(v_b_2425);
        V v_t_2468 = heff_tr(heff_call(heff_dup(v_go_241), 1, (V[]){v_s_242}));
        V v_t_2483 = (g_list_2emap_24tok2(v_ru_24arms2_2422_24Cons, heff_clo_n(g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam3, 1, 1, (V[]){v_go_241}), v_arms_243));
        return heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){v_t_2468, v_t_2483});
      }
      default: return heff_nomatch(v_arms2_2422);
      }
    }
    default: return heff_nomatch(v_arms1_2421);
    }
  }
  default: return heff_nomatch(v_arms_243);
  }
}
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eunbox_2ematchRw_24tok2(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410;
  switch (heff_tag_of(v_a_246)) {
  case TAG_MkArm: {
    V v_t_247 = heff_dup(heff_field(v_a_246, 0));
    v_t_2410 = v_t_247;
    break;
  }
  default: heff_nomatch(v_a_246);
  }
  V v_t_2414;
  switch (heff_tag_of(v_a_246)) {
  case TAG_MkArm: {
    V v_vs_2412 = heff_dup(heff_field(v_a_246, 1));
    v_t_2414 = v_vs_2412;
    break;
  }
  default: heff_nomatch(v_a_246);
  }
  V v_t_2418;
  switch (heff_tag_of(v_a_246)) {
  case TAG_MkArm: {
    V v_b_2417 = heff_field(v_a_246, 2);
    heff_take_n(v_a_246, 4ULL, 3);
    v_t_2418 = v_b_2417;
    break;
  }
  default: heff_nomatch(v_a_246);
  }
  V v_t_2419 = heff_tr(heff_call(v_go_241, 1, (V[]){v_t_2418}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_t_2414, v_t_2419});
}
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam1(V self, V *args) {
  V v_a_2427 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2431;
  switch (heff_tag_of(v_a_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_dup(heff_field(v_a_2427, 0));
    v_t_2431 = v_t_2428;
    break;
  }
  default: heff_nomatch(v_a_2427);
  }
  V v_t_2435;
  switch (heff_tag_of(v_a_2427)) {
  case TAG_MkArm: {
    V v_vs_2433 = heff_dup(heff_field(v_a_2427, 1));
    v_t_2435 = v_vs_2433;
    break;
  }
  default: heff_nomatch(v_a_2427);
  }
  V v_t_2439;
  switch (heff_tag_of(v_a_2427)) {
  case TAG_MkArm: {
    V v_b_2438 = heff_field(v_a_2427, 2);
    heff_take_n(v_a_2427, 4ULL, 3);
    v_t_2439 = v_b_2438;
    break;
  }
  default: heff_nomatch(v_a_2427);
  }
  V v_t_2440 = heff_tr(heff_call(v_go_241, 1, (V[]){v_t_2439}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2431, v_t_2435, v_t_2440});
}
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam2(V self, V *args) {
  V v_a_2451 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455;
  switch (heff_tag_of(v_a_2451)) {
  case TAG_MkArm: {
    V v_t_2452 = heff_dup(heff_field(v_a_2451, 0));
    v_t_2455 = v_t_2452;
    break;
  }
  default: heff_nomatch(v_a_2451);
  }
  V v_t_2459;
  switch (heff_tag_of(v_a_2451)) {
  case TAG_MkArm: {
    V v_vs_2457 = heff_dup(heff_field(v_a_2451, 1));
    v_t_2459 = v_vs_2457;
    break;
  }
  default: heff_nomatch(v_a_2451);
  }
  V v_t_2463;
  switch (heff_tag_of(v_a_2451)) {
  case TAG_MkArm: {
    V v_b_2462 = heff_field(v_a_2451, 2);
    heff_take_n(v_a_2451, 4ULL, 3);
    v_t_2463 = v_b_2462;
    break;
  }
  default: heff_nomatch(v_a_2451);
  }
  V v_t_2464 = heff_tr(heff_call(v_go_241, 1, (V[]){v_t_2463}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2455, v_t_2459, v_t_2464});
}
V g_heff_2ecompile_2eunbox_2ematchRw_24tok2_lam3(V self, V *args) {
  V v_a_2469 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2473;
  switch (heff_tag_of(v_a_2469)) {
  case TAG_MkArm: {
    V v_t_2470 = heff_dup(heff_field(v_a_2469, 0));
    v_t_2473 = v_t_2470;
    break;
  }
  default: heff_nomatch(v_a_2469);
  }
  V v_t_2477;
  switch (heff_tag_of(v_a_2469)) {
  case TAG_MkArm: {
    V v_vs_2475 = heff_dup(heff_field(v_a_2469, 1));
    v_t_2477 = v_vs_2475;
    break;
  }
  default: heff_nomatch(v_a_2469);
  }
  V v_t_2481;
  switch (heff_tag_of(v_a_2469)) {
  case TAG_MkArm: {
    V v_b_2480 = heff_field(v_a_2469, 2);
    heff_take_n(v_a_2469, 4ULL, 3);
    v_t_2481 = v_b_2480;
    break;
  }
  default: heff_nomatch(v_a_2469);
  }
  V v_t_2482 = heff_tr(heff_call(v_go_241, 1, (V[]){v_t_2481}));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2473, v_t_2477, v_t_2482});
}