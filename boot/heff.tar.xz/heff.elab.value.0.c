// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_F32 16337
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntoCons 46138
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkFolded 17353
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotApplicable 40298
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_keys 9783995
#define LBL_values 1123329101
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(V, V);
V g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s676305996x967270522_clo;
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(V);
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_clo;
V g_heff_2eelab_2evalue_2eappTy(V, V);
V g_heff_2eelab_2evalue_2eappTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eappTy_clo;
V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(V);
V g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
HeffT2 g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0(V, V, V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0(V, V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0_clo;
V g_heff_2eelab_2evalue_2edecodeEv(V);
V g_heff_2eelab_2evalue_2edecodeEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeEv_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_clo;
V g_heff_2eelab_2evalue_2eebind(V, V);
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_clo;
V g_heff_2eelab_2evalue_2eebind_24tok1(V, V, V);
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo;
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_clo;
V g_heff_2eelab_2evalue_2eimplicitDefault(V);
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eneuAppTy(V, V, V);
V g_heff_2eelab_2evalue_2eneuAppTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eneuAppTy_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojAt_24tok1(V, V, V, V);
V g_heff_2eelab_2evalue_2eprojAt_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojAt_24tok1_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_24generate0(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_24generate0_clo;
V g_heff_2eelab_2evalue_2eprojTyWith_24map0(V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_24map0_clo;
V g_heff_2eelab_2evalue_2ereflect(V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_clo;
V g_heff_2eelab_2evalue_2ereflect_24tok2(V, V, V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24tok2_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_heff_2eelab_2evalue_2especialize_24tok3(V, V, V, V);
V g_heff_2eelab_2evalue_2especialize_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_24tok3_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eelab_2evalue_2eunspecialize(V);
V g_heff_2eelab_2evalue_2eunspecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eunspecialize_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2eelab_2evalue_2eebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eebind_entry, 2, 0};

V g_heff_2eelab_2evalue_2eebind(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nom: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tail(v_f_240, 1, (V[]){v_x_242});
  }
  case TAG_Describe: {
    V v_x_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return heff_tail(v_f_240, 1, (V[]){v_x_243});
  }
  case TAG_Become: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Become = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_245 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_244}));
    V v_t_249;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nom: {
      V v_x_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_249 = v_x_246;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_245, 0ULL, 1);
      v_t_249 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_248 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at_n(v_ru_24x2_241_24Become, TAG_Become, 1, (V[]){v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2evalue_2eebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eebind(a[0], a[1]);
}
Clo g_heff_2eelab_2evalue_2ebehavior_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ebehavior_entry, 1, 0};

V g_heff_2eelab_2evalue_2ebehavior(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    V v_u_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VU = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VU, TAG_LikeU, 1, (V[]){v_u_241});
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_call(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return NTAG(TAG_NoRules);
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    V v_level_249 = heff_field(v_x1_240, 0);
    V v_dom_2410 = heff_field(v_x1_240, 1);
    V v_cod_2411 = heff_field(v_x1_240, 2);
    V v_implicit_2412 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 6);
    return heff_tag_n(TAG_LikeFunction, 4, (V[]){v_level_249, v_dom_2410, v_cod_2411, v_implicit_2412});
  }
  case TAG_VRecord: {
    V v_level_2415 = heff_field(v_x1_240, 0);
    V v_capture_2416 = heff_field(v_x1_240, 1);
    V v_fieldTypes_2417 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 4);
    return heff_tag_n(TAG_LikeRecord, 3, (V[]){v_level_2415, v_capture_2416, v_fieldTypes_2417});
  }
  case TAG_VSum: {
    V v_st_2419 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VSum = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VSum, TAG_LikeSum, 1, (V[]){v_st_2419});
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_LikeInt);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_LikeFloat);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_LikeString);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_LikeRune);
  }
  case TAG_VPrimArray: {
    V v_a_2420 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VPrimArray = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VPrimArray, TAG_LikeArray, 1, (V[]){v_a_2420});
  }
  case TAG_VFixed: {
    V v_w_2421 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24VFixed = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24VFixed, TAG_LikeFixed, 1, (V[]){v_w_2421});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2ebehavior(a[0]);
}
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str0, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str1, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str2, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str3, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str4, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str5, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str6, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str7, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str8, 7, "Float32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str9, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str10, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str11, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str12, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str13, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str14, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str15, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str16, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2evalue_2eisFixed_str17, 7, "Float32");
Clo g_heff_2eelab_2evalue_2eisFixed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eisFixed_entry, 2, 0};

V g_heff_2eelab_2evalue_2eisFixed(V v_w_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VU: {
    return NTAG(TAG_False);
  }
  case TAG_VDecode: {
    return NTAG(TAG_False);
  }
  case TAG_VFunction: {
    return NTAG(TAG_False);
  }
  case TAG_VRecord: {
    return NTAG(TAG_False);
  }
  case TAG_VSum: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimArray: {
    return NTAG(TAG_False);
  }
  case TAG_VFixed: {
    V v_w_27_2420 = heff_field(v_x2_241, 0);
    V v_t_2421;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str0);
      break;
    }
    case TAG_I16: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str1);
      break;
    }
    case TAG_I32: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str2);
      break;
    }
    case TAG_I64: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str3);
      break;
    }
    case TAG_U8: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str4);
      break;
    }
    case TAG_U16: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str5);
      break;
    }
    case TAG_U32: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str6);
      break;
    }
    case TAG_U64: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str7);
      break;
    }
    case TAG_F32: {
      v_t_2421 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str8);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2422;
    switch (heff_tag_of(v_w_27_2420)) {
    case TAG_I8: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str9);
      break;
    }
    case TAG_I16: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str10);
      break;
    }
    case TAG_I32: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str11);
      break;
    }
    case TAG_I64: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str12);
      break;
    }
    case TAG_U8: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str13);
      break;
    }
    case TAG_U16: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str14);
      break;
    }
    case TAG_U32: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str15);
      break;
    }
    case TAG_U64: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str16);
      break;
    }
    case TAG_F32: {
      v_t_2422 = ((V)&g_heff_2eelab_2evalue_2eisFixed_str17);
      break;
    }
    default: heff_nomatch(v_w_27_2420);
    }
    V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2421, v_t_2422, 0));
    heff_drop(v_t_2421);
    heff_drop(v_t_2422);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2evalue_2eisFixed(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr_lam0, 1, 0};

HeffT2 g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(V v_v_240) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_expansion_244 = heff_field(v_v_240, 3);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_expansion_244), 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_IntoCons: {
      V v_fields_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24IntoCons = heff_take_reuse_n(v_t_246, 1ULL, 1);
      V v_xs_248 = heff_take_field(v_fields_247, 2);
      V v_m_249 = heff_arrayLength_lent(v_xs_248, 0);
      V v_t_2414;
      if ((heff_peek_word(v_m_249) <= ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24t_246_24IntoCons, 1);
        heff_drop(v_xs_248);
        v_t_2414 = heff_arrayGenerate(v_m_249, ((V)&g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr_lam0_clo));
      } else {
        V v_t_2411 = heff_arrayIndex_lent(v_xs_248, MK_INT(0LL), 2);
        V v_y_2412 = heff_tag_at_n(v_ru_24t_246_24IntoCons, TAG_Nom, 1, (V[]){v_t_2411});
        V v_t_2413 = heff_arrayKeepsAs_lent(v_xs_248, v_y_2412, 0);
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_m_249);
          heff_drop(v_t_2413);
          v_t_2414 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0(MK_INT(1LL), heff_arraySet(v_xs_248, MK_INT(0LL), v_y_2412)));
        } else {
          heff_drop(v_t_2413);
          v_t_2414 = ({ V a_0 = v_xs_248; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_249, v_y_2412); V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        }
      }
      V v_f_2415 = ({ V rv_2 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_fields_247, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
    }
    case TAG_NotApplicable: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_246)}});
    }
  }
  case TAG_VCode: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VLam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    V v_fields_2419 = heff_field(v_v_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_fields_2419)}});
  }
  case TAG_VOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_v_240)}});
  }
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  heff_drop(v_u_2410);
  return heff_abandon();
}
Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry, 1, 0};

V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V v_v_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(v_v_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0_entry, 3, 0};

V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t_243 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), heff_tag_n(TAG_Nom, 1, (V[]){v_t_243}));
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_244;
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t_243 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), heff_tag_n(TAG_Nom, 1, (V[]){v_t_243}));
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_244;
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24generate0(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0_entry, 2, 0};

V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_t_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_243 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), heff_tag_n(TAG_Nom, 1, (V[]){v_t_242}));
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = v_t_243;
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_t_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_243 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), heff_tag_n(TAG_Nom, 1, (V[]){v_t_242}));
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = v_t_243;
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24map0(a[0], a[1]);
}
Clo g_heff_2eelab_2evalue_2efieldIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2efieldIn_entry, 2, 0};

V g_heff_2eelab_2evalue_2efieldIn(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  case TAG_Just: {
    V v_fields_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_byName_243 = heff_take_field(v_fields_242, 1);
    V v_values_244 = heff_get_n(v_fields_242, 2, 3);
    HeffT2 v_t_245 = ({ V a_0 = v_byName_243; V a_1 = v_x_241; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_243); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_i_248 = v_field_247;
        V v_xs_249 = v_values_244;
        if ((heff_intLe_c_lent(MK_INT(0LL), v_i_248, 1) && heff_intLt_c(heff_dup(v_i_248), heff_arrayLength_lent(v_xs_249, 0)))) {
          heff_drop_cell(v_ru_24x1_240_24Just, 1);
          V v_t_2410 = heff_arrayIndex(v_xs_249, v_i_248);
          return v_t_2410;
        } else {
          heff_drop(v_i_248);
          heff_drop(v_xs_249);
          return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
      } else {
        heff_drop(v_values_244);
        heff_drop(v_field_247);
        return heff_tag_at_n(v_ru_24x1_240_24Just, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2evalue_2efieldIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2evalue_2eproj_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eproj_entry, 2, 0};

V g_heff_2eelab_2evalue_2eproj(V v_v_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_t_247 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    HEFF_LAST return g_heff_2eelab_2evalue_2efieldIn(v_t_247, v_x_241);
  }
  case TAG_VCode: {
    V v_t_249 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    HEFF_LAST return g_heff_2eelab_2evalue_2efieldIn(v_t_249, v_x_241);
  }
  case TAG_VLam: {
    V v_t_2412 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    HEFF_LAST return g_heff_2eelab_2evalue_2efieldIn(v_t_2412, v_x_241);
  }
  case TAG_VCons: {
    V v_t_2414 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_240));
    HEFF_LAST return g_heff_2eelab_2evalue_2efieldIn(v_t_2414, v_x_241);
  }
  case TAG_VOpaque: {
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2evalue_2eproj(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam2(V self, V *args);
Clo g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_entry, 6, 0};

V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(V v_vs_240, V v_h_241, V v_sp_242, V v_desc_243, V v_x6_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_vs_240);
    heff_drop(v_h_241);
    heff_drop(v_sp_242);
    heff_drop(v_desc_243);
    return v_acc_245;
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_244, 0);
    V v_rest_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x61_246, 0);
      V v_f_249 = heff_field(v_x61_246, 1);
      V v_ru_24x61_246_24MkPair = heff_take_reuse_n(v_x61_246, 3ULL, 2);
      V v_h_2410 = heff_dup(v_h_241);
      V v_sp_2411 = heff_dup(v_sp_242);
      V v_desc_2412 = heff_dup(v_desc_243);
      V v_x_2413 = v_x_248;
      V v_x6_2414 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_dup(v_vs_240)}));
      V v_v_2436;
      switch (heff_tag_of(v_x6_2414)) {
      case TAG_MkField: {
        V v_fty_2415 = heff_field(v_x6_2414, 0);
        V v_x62_2416 = heff_field(v_x6_2414, 1);
        V v_ru_24x6_2414_24MkField = heff_take_reuse_n(v_x6_2414, 3ULL, 2);
        switch (heff_tag_of(v_x62_2416)) {
        case TAG_Nothing: {
          V v_t_2432;
          switch (heff_tag_of(v_desc_2412)) {
          case TAG_Nothing: {
            v_t_2432 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x_2417 = heff_field(v_desc_2412, 0);
            V v_ru_24desc_2412_24Just = heff_take_reuse_n(v_desc_2412, 1ULL, 1);
            V v_t_2431;
            switch (heff_tag_of(v_x_2417)) {
            case TAG_VNeu: {
              V v_t_2423 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_x_2417, 5); r_; });
              v_t_2431 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2423, v_x_2413));
              break;
            }
            case TAG_VCode: {
              V v_t_2425 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_x_2417, 1); r_; });
              v_t_2431 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2425, v_x_2413));
              break;
            }
            case TAG_VLam: {
              V v_t_2428 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_x_2417, 2); r_; });
              v_t_2431 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2428, v_x_2413));
              break;
            }
            case TAG_VCons: {
              V v_t_2430 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_x_2417, 1); r_; });
              v_t_2431 = (g_heff_2eelab_2evalue_2efieldIn(v_t_2430, v_x_2413));
              break;
            }
            case TAG_VOpaque: {
              v_t_2431 = heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
              break;
            }
            default: heff_nomatch(v_x_2417);
            }
            v_t_2432 = heff_tag_at_n(v_ru_24desc_2412_24Just, TAG_Just, 1, (V[]){v_t_2431});
            break;
          }
          default: heff_nomatch(v_desc_2412);
          }
          v_v_2436 = (g_heff_2eelab_2evalue_2ereflect_24tok2(v_ru_24x6_2414_24MkField, v_h_2410, heff_clo_n(g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam0, 1, 2, (V[]){v_sp_2411, v_x_2413}), heff_clo_n(g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam1, 1, 1, (V[]){v_fty_2415}), v_t_2432));
          break;
        }
        case TAG_Just: {
          V v_v_2435 = heff_field(v_x62_2416, 0);
          heff_take_n(v_x62_2416, 1ULL, 1);
          heff_drop(v_h_2410);
          heff_drop(v_sp_2411);
          heff_drop(v_desc_2412);
          heff_drop(v_x_2413);
          heff_drop(v_fty_2415);
          heff_drop_cell(v_ru_24x6_2414_24MkField, 2);
          v_v_2436 = v_v_2435;
          break;
        }
        default: heff_nomatch(v_x62_2416);
        }
        break;
      }
      default: heff_nomatch(v_x6_2414);
      }
      V t_0 = heff_tag_at_n(v_ru_24x61_246_24MkPair, TAG_LSnoc, 2, (V[]){v_vs_240, heff_clo_n(g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam2, 1, 1, (V[]){heff_dup(v_v_2436)})});
      V t_1 = v_h_241;
      V t_2 = v_sp_242;
      V t_3 = v_desc_243;
      V t_4 = v_rest_247;
      V t_5 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_v_2436, v_acc_245});
      v_vs_240 = t_0;
      v_h_241 = t_1;
      v_sp_242 = t_2;
      v_desc_243 = t_3;
      v_x6_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x61_246);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam0(V self, V *args) {
  V v_u_2433 = args[0];
  V v_sp_2411 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2433);
  return heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2411, v_x_2413});
}
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam1(V self, V *args) {
  V v_u_2434 = args[0];
  V v_fty_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return v_fty_2415;
}
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_lam2(V self, V *args) {
  V v_u_2437 = args[0];
  V v_v_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return v_v_2436;
}
Clo g_heff_2eelab_2evalue_2ereflect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ereflect_entry, 4, 0};

V g_heff_2eelab_2evalue_2ereflect(V v_h_240, V v_spineTh_241, V v_ty_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_tr(heff_call(v_spineTh_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_240, v_t_244, v_ty_242, NTAG(TAG_Nothing));
  }
  case TAG_Just: {
    V v_x41_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_245)) {
    case TAG_Nom: {
      V v_v_246 = heff_field(v_x41_245, 0);
      V v_ru_24x41_245_24Nom = heff_take_reuse_n(v_x41_245, 1ULL, 1);
      heff_drop(v_ty_242);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VNeu: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Nom, 1);
        return v_v_246;
      }
      case TAG_VCode: {
        V v_v1_2412 = heff_dup(heff_field(v_v_246, 0));
        switch (heff_tag_of(v_v1_2412)) {
        case TAG_VU: {
          heff_take_n(v_v1_2412, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2412, 0ULL, 5);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VFunction: {
          V v_level_2419 = heff_field(v_v1_2412, 0);
          V v_dom_2420 = heff_field(v_v1_2412, 1);
          V v_cod_2421 = heff_field(v_v1_2412, 2);
          V v_implicit_2422 = heff_field(v_v1_2412, 3);
          V v_dflt_2423 = heff_field(v_v1_2412, 4);
          V v_ru_24v1_2412_24VFunction = heff_take_reuse_n(v_v1_2412, 31ULL, 6);
          switch (heff_tag_of(v_v_246)) {
          case TAG_VCode: {
            heff_take_n(v_v_246, 0ULL, 1);
            V v_t_2426 = heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkFolded, 2, (V[]){v_h_240, v_spineTh_241})});
            return heff_tag_at_n(v_ru_24x41_245_24Nom, TAG_VCode, 1, (V[]){heff_tag_at_n(v_ru_24v1_2412_24VFunction, TAG_VFunction, 6, (V[]){v_level_2419, v_dom_2420, v_cod_2421, v_implicit_2422, v_dflt_2423, v_t_2426})});
          }
          default: return heff_nomatch(v_v_246);
          }
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2412, 0ULL, 4);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2412, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VPrimInt: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VPrimFloat: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VPrimString: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VPrimRune: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2412, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2412, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Nom, 1);
          return v_v_246;
        }
        default: return heff_nomatch(v_v1_2412);
        }
      }
      case TAG_VLam: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Nom, 1);
        return v_v_246;
      }
      case TAG_VCons: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Nom, 1);
        return v_v_246;
      }
      case TAG_VOpaque: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Nom, 1);
        return v_v_246;
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Describe: {
      V v_desc_2437 = heff_field(v_x41_245, 0);
      heff_take_n(v_x41_245, 1ULL, 1);
      V v_t_2438 = heff_tr(heff_call(v_spineTh_241, 1, (V[]){NTAG(TAG_MkUnit)}));
      HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_240, v_t_2438, v_ty_242, heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_desc_2437}));
    }
    case TAG_Become: {
      V v_v_2439 = heff_field(v_x41_245, 0);
      V v_ru_24x41_245_24Become = heff_take_reuse_n(v_x41_245, 1ULL, 1);
      heff_drop(v_ty_242);
      switch (heff_tag_of(v_v_2439)) {
      case TAG_VNeu: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Become, 1);
        return v_v_2439;
      }
      case TAG_VCode: {
        V v_v1_2445 = heff_dup(heff_field(v_v_2439, 0));
        switch (heff_tag_of(v_v1_2445)) {
        case TAG_VU: {
          heff_take_n(v_v1_2445, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2445, 0ULL, 5);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VFunction: {
          V v_level_2452 = heff_field(v_v1_2445, 0);
          V v_dom_2453 = heff_field(v_v1_2445, 1);
          V v_cod_2454 = heff_field(v_v1_2445, 2);
          V v_implicit_2455 = heff_field(v_v1_2445, 3);
          V v_dflt_2456 = heff_field(v_v1_2445, 4);
          V v_ru_24v1_2445_24VFunction = heff_take_reuse_n(v_v1_2445, 31ULL, 6);
          switch (heff_tag_of(v_v_2439)) {
          case TAG_VCode: {
            heff_take_n(v_v_2439, 0ULL, 1);
            V v_t_2459 = heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkFolded, 2, (V[]){v_h_240, v_spineTh_241})});
            return heff_tag_at_n(v_ru_24x41_245_24Become, TAG_VCode, 1, (V[]){heff_tag_at_n(v_ru_24v1_2445_24VFunction, TAG_VFunction, 6, (V[]){v_level_2452, v_dom_2453, v_cod_2454, v_implicit_2455, v_dflt_2456, v_t_2459})});
          }
          default: return heff_nomatch(v_v_2439);
          }
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2445, 0ULL, 4);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2445, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VPrimInt: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VPrimFloat: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VPrimString: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VPrimRune: {
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2445, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2445, 0ULL, 1);
          heff_drop(v_h_240);
          heff_drop(v_spineTh_241);
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          heff_drop_cell(v_ru_24x41_245_24Become, 1);
          return v_v_2439;
        }
        default: return heff_nomatch(v_v1_2445);
        }
      }
      case TAG_VLam: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Become, 1);
        return v_v_2439;
      }
      case TAG_VCons: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Become, 1);
        return v_v_2439;
      }
      case TAG_VOpaque: {
        heff_drop(v_h_240);
        heff_drop(v_spineTh_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop_cell(v_ru_24x41_245_24Become, 1);
        return v_v_2439;
      }
      default: return heff_nomatch(v_v_2439);
      }
    }
    default: return heff_nomatch(v_x41_245);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2evalue_2ereflect_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2ereflect(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2evalue_2eisError_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eisError_entry, 1, 0};

V g_heff_2eelab_2evalue_2eisError(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VNeu: {
    V v_h_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_HMeta: {
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_h_241);
    }
  }
  case TAG_VCode: {
    V v_x11_249 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_VU: {
      return NTAG(TAG_False);
    }
    case TAG_VDecode: {
      V v_h_2411 = heff_field(v_x11_249, 0);
      switch (heff_tag_of(v_h_2411)) {
      case TAG_HLocal: {
        return NTAG(TAG_False);
      }
      case TAG_HGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_HMeta: {
        return NTAG(TAG_False);
      }
      case TAG_HError: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_h_2411);
      }
    }
    case TAG_VFunction: {
      return NTAG(TAG_False);
    }
    case TAG_VRecord: {
      return NTAG(TAG_False);
    }
    case TAG_VSum: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_VPrimArray: {
      return NTAG(TAG_False);
    }
    case TAG_VFixed: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  case TAG_VLam: {
    return NTAG(TAG_False);
  }
  case TAG_VCons: {
    return NTAG(TAG_False);
  }
  case TAG_VOpaque: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eisError(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0, 1, 0};
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1(V self, V *args); static Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1, 1, 0};
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam2(V self, V *args);
Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry, 3, 0};

V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V v_h_240, V v_spine_241, V v_desc_242) {
top: ;
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_240, v_spine_241, ((V)&g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0_clo), ((V)&g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1_clo), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam2, 1, 1, (V[]){v_desc_242})});
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam0(V self, V *args) {
  V v_a_243 = args[0];
  heff_drop(v_a_243);
  return heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam1(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return NTAG(TAG_NotApplicable);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_lam2(V self, V *args) {
  V v_u_245 = args[0];
  V v_desc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_245);
  return v_desc_242;
}
Clo g_heff_2eelab_2evalue_2edecodeEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeEv_entry, 1, 0};

V g_heff_2eelab_2evalue_2edecodeEv(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Become, 1, (V[]){v_field_243});
    } else {
      if ((v_tag_242 == ((int64_t)1ULL))) {
        return heff_tag_n(TAG_Describe, 1, (V[]){v_field_243});
      } else {
        return heff_tag_n(TAG_Nom, 1, (V[]){v_field_243});
      }
    }
  }
}
V g_heff_2eelab_2evalue_2edecodeEv_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2edecodeEv(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2eappTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eappTy_entry, 2, 0};

V g_heff_2eelab_2evalue_2eappTy(V v_t_240, V v_arg_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_240)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_245 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_245)) {
      case TAG_HLocal: {
        heff_take_n(v_h_245, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_245, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_245, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_245);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeFunction: {
    V v_cod_2443 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 4ULL, 4);
    heff_drop(v_t_240);
    V v_x1_2449;
    switch (heff_tag_of(v_cod_2443)) {
    case TAG_MkClo: {
      V v_vs_2446 = heff_field(v_cod_2443, 1);
      V v_body_2447 = heff_field(v_cod_2443, 2);
      heff_take_n(v_cod_2443, 6ULL, 3);
      v_x1_2449 = heff_tr(heff_call(v_body_2447, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2446, v_arg_241})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2448 = heff_field(v_cod_2443, 0);
      heff_take_n(v_cod_2443, 1ULL, 1);
      heff_drop(v_arg_241);
      v_x1_2449 = v_body_2448;
      break;
    }
    default: heff_nomatch(v_cod_2443);
    }
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_Nom: {
      V v_x_2450 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      return v_x_2450;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2449, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_2452 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      return v_x_2452;
    }
    default: return heff_nomatch(v_x1_2449);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_2457 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_2457)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2457, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2457, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2457, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_2457);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_2495 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_2495)) {
      case TAG_HLocal: {
        heff_take_n(v_h_2495, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_2495, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_2495, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_2495);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24132 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24132)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24132, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24132, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24132, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24132);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeFloat: {
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24169 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24169)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24169, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24169, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24169, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24169);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeString: {
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24206 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24206)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24206, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24206, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24206, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24206);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeRune: {
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24243 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24243)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24243, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24243, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24243, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24243);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24281 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24281)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24281, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24281, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24281, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24281);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24319 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24319)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24319, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24319, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24319, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24319);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  case TAG_NoRules: {
    heff_drop(v_arg_241);
    switch (heff_tag_of(v_t_240)) {
    case TAG_VU: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VDecode: {
      V v_h_24356 = heff_dup(heff_field(v_t_240, 0));
      switch (heff_tag_of(v_h_24356)) {
      case TAG_HLocal: {
        heff_take_n(v_h_24356, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HGlobal: {
        heff_take_n(v_h_24356, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_h_24356, 0ULL, 1);
        switch (heff_tag_of(v_t_240)) {
        case TAG_VDecode: {
          heff_take_n(v_t_240, 0ULL, 5);
          return heff_abandon();
        }
        default: return heff_nomatch(v_t_240);
        }
      }
      case TAG_HError: {
        return v_t_240;
      }
      default: return heff_nomatch(v_h_24356);
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_t_240, 0ULL, 6);
      return heff_abandon();
    }
    case TAG_VRecord: {
      heff_take_n(v_t_240, 0ULL, 4);
      return heff_abandon();
    }
    case TAG_VSum: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VPrimInt: {
      return heff_abandon();
    }
    case TAG_VPrimFloat: {
      return heff_abandon();
    }
    case TAG_VPrimString: {
      return heff_abandon();
    }
    case TAG_VPrimRune: {
      return heff_abandon();
    }
    case TAG_VPrimArray: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_VFixed: {
      heff_take_n(v_t_240, 0ULL, 1);
      return heff_abandon();
    }
    default: return heff_nomatch(v_t_240);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2evalue_2eappTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eappTy(a[0], a[1]);
}
Clo g_heff_2eelab_2evalue_2eneuAppTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eneuAppTy_entry, 3, 0};

V g_heff_2eelab_2evalue_2eneuAppTy(V v_h_240, V v_t_241, V v_arg_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_HLocal: {
    return (g_heff_2eelab_2evalue_2eappTy(v_t_241, v_arg_242));
  }
  case TAG_HGlobal: {
    return (g_heff_2eelab_2evalue_2eappTy(v_t_241, v_arg_242));
  }
  case TAG_HMeta: {
    V v_t_246 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_241)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_LikeU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_246, 0ULL, 4);
      return (g_heff_2eelab_2evalue_2eappTy(v_t_241, v_arg_242));
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeInt: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFloat: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeString: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeRune: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_arg_242);
      return v_t_241;
    }
    case TAG_NoRules: {
      heff_drop(v_arg_242);
      return v_t_241;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_HError: {
    return (g_heff_2eelab_2evalue_2eappTy(v_t_241, v_arg_242));
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2eelab_2evalue_2eneuAppTy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eneuAppTy(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2evalue_2eapp_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_lam1(V self, V *args);
Clo g_heff_2eelab_2evalue_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eapp_entry, 2, 0};

V g_heff_2eelab_2evalue_2eapp(V v_f_240, V v_arg_241) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_f_240, 0);
    V v_sp_243 = heff_field(v_f_240, 1);
    V v_ty_244 = heff_field(v_f_240, 2);
    V v_desc_246 = heff_field(v_f_240, 4);
    heff_take_n(v_f_240, 23ULL, 5);
    V v_x2_247 = heff_tr(heff_call(v_desc_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_ru_24x2_247_24Just = heff_take_reuse_n(v_x2_247, 1ULL, 1);
      V v_t_249 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_x_248, heff_dup(v_arg_241)));
      v_t_2410 = heff_tag_at_n(v_ru_24x2_247_24Just, TAG_Just, 1, (V[]){v_t_249});
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2415 = (g_heff_2eelab_2evalue_2ereflect(heff_dup(v_h_242), heff_clo_n(g_heff_2eelab_2evalue_2eapp_lam0, 1, 2, (V[]){heff_dup(v_arg_241), v_sp_243}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_lam1, 1, 3, (V[]){v_ty_244, v_h_242, v_arg_241}), v_t_2410));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2415});
  }
  case TAG_VCode: {
    heff_take_n(v_f_240, 0ULL, 1);
    heff_drop(v_arg_241);
    return heff_abandon();
  }
  case TAG_VLam: {
    V v_clo_2418 = heff_field(v_f_240, 1);
    heff_take_n(v_f_240, 2ULL, 2);
    switch (heff_tag_of(v_clo_2418)) {
    case TAG_MkClo: {
      V v_vs_2420 = heff_field(v_clo_2418, 1);
      V v_body_2421 = heff_field(v_clo_2418, 2);
      heff_take_n(v_clo_2418, 6ULL, 3);
      return heff_tail(v_body_2421, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2420, v_arg_241})});
    }
    case TAG_CloConst: {
      V v_body_2422 = heff_field(v_clo_2418, 0);
      heff_take_n(v_clo_2418, 1ULL, 1);
      heff_drop(v_arg_241);
      return v_body_2422;
    }
    default: return heff_nomatch(v_clo_2418);
    }
  }
  case TAG_VCons: {
    heff_take_n(v_f_240, 0ULL, 1);
    heff_drop(v_arg_241);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    heff_drop(v_arg_241);
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eapp(a[0], a[1]);
}
V g_heff_2eelab_2evalue_2eapp_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_arg_241 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  V v_t_2412 = heff_tr(heff_call(v_arg_241, 1, (V[]){NTAG(TAG_MkUnit)}));
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_243, v_t_2412});
}
V g_heff_2eelab_2evalue_2eapp_lam1(V self, V *args) {
  V v_u_2413 = args[0];
  V v_ty_244 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_arg_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2413);
  V v_t_2414 = heff_tr(heff_call(v_ty_244, 1, (V[]){NTAG(TAG_MkUnit)}));
  return ({ V a_0 = v_h_242; V a_1 = v_t_2414; V a_2 = v_arg_241; V r_ = (g_heff_2eelab_2evalue_2eneuAppTy(a_0, a_1, a_2)); heff_drop(v_h_242); r_; });
}
V g_heff_2eelab_2evalue_2eunspecialize_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2eunspecialize_lam0(V self, V *args);
Clo g_heff_2eelab_2evalue_2eunspecialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eunspecialize_entry, 1, 0};

V g_heff_2eelab_2evalue_2eunspecialize(V v_v_240) {
top: ;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VNeu: {
    V v_v2_242 = heff_dup(heff_field(v_v_240, 1));
    switch (heff_tag_of(v_v2_242)) {
    case TAG_SpId: {
      return v_v_240;
    }
    case TAG_SpApp: {
      heff_take_n(v_v2_242, 0ULL, 2);
      return v_v_240;
    }
    case TAG_SpProj: {
      heff_take_n(v_v2_242, 0ULL, 2);
      return v_v_240;
    }
    case TAG_SpSpec: {
      V v_sp_2410 = heff_field(v_v2_242, 0);
      V v_x_2411 = heff_field(v_v2_242, 1);
      heff_take_n(v_v2_242, 3ULL, 3);
      switch (heff_tag_of(v_v_240)) {
      case TAG_VNeu: {
        V v_h_2413 = heff_field(v_v_240, 0);
        V v_ty_2415 = heff_field(v_v_240, 2);
        V v_expansion_2416 = heff_field(v_v_240, 3);
        V v_desc_2417 = heff_field(v_v_240, 4);
        V v_ru_24v_240_24VNeu = heff_take_reuse_n(v_v_240, 29ULL, 5);
        V t_0 = heff_tag_at_n(v_ru_24v_240_24VNeu, TAG_VNeu, 5, (V[]){v_h_2413, v_sp_2410, v_ty_2415, v_expansion_2416, heff_clo_n(g_heff_2eelab_2evalue_2eunspecialize_lam0, 1, 2, (V[]){v_desc_2417, v_x_2411})});
        v_v_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_v_240);
      }
    }
    default: return heff_nomatch(v_v2_242);
    }
  }
  case TAG_VCode: {
    return v_v_240;
  }
  case TAG_VLam: {
    return v_v_240;
  }
  case TAG_VCons: {
    return v_v_240;
  }
  case TAG_VOpaque: {
    return v_v_240;
  }
  default: return heff_nomatch(v_v_240);
  }
}
V g_heff_2eelab_2evalue_2eunspecialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eunspecialize(a[0]);
}
V g_heff_2eelab_2evalue_2eunspecialize_lam1(V self, V *args) {
  V v_a_2452 = args[0];
  V v_v_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453 = heff_tr(heff_call(v_v_2451, 1, (V[]){v_a_2452}));
  switch (heff_tag_of(v_t_2453)) {
  case TAG_MkField: {
    V v_a_2454 = heff_field(v_t_2453, 0);
    V v_ru_24t_2453_24MkField = heff_take_reuse_n(v_t_2453, 1ULL, 2);
    return heff_tag_at_n(v_ru_24t_2453_24MkField, TAG_MkField, 2, (V[]){v_a_2454, NTAG(TAG_Nothing)});
  }
  default: return heff_nomatch(v_t_2453);
  }
}
V g_heff_2eelab_2evalue_2eunspecialize_lam0(V self, V *args) {
  V v_u_2418 = args[0];
  V v_desc_2417 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2419 = heff_tr(heff_call(v_desc_2417, 1, (V[]){v_u_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nothing: {
    heff_drop(v_x_2411);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_ru_24x2_2419_24Just = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
    V v_t_2464;
    switch (heff_tag_of(v_x_2420)) {
    case TAG_VNeu: {
      heff_drop(v_x_2411);
      v_t_2464 = v_x_2420;
      break;
    }
    case TAG_VCode: {
      V v_v1_2426 = heff_dup(heff_field(v_x_2420, 0));
      switch (heff_tag_of(v_v1_2426)) {
      case TAG_VU: {
        heff_take_n(v_v1_2426, 0ULL, 1);
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VDecode: {
        heff_take_n(v_v1_2426, 0ULL, 5);
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VFunction: {
        heff_take_n(v_v1_2426, 0ULL, 6);
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VRecord: {
        V v_level_2439 = heff_field(v_v1_2426, 0);
        V v_capture_2440 = heff_field(v_v1_2426, 1);
        V v_fieldTypes_2441 = heff_field(v_v1_2426, 2);
        V v_defaults_2442 = heff_field(v_v1_2426, 3);
        V v_ru_24v1_2426_24VRecord = heff_take_reuse_n(v_v1_2426, 15ULL, 4);
        switch (heff_tag_of(v_x_2420)) {
        case TAG_VCode: {
          V v_ru_24x_2420_24VCode = heff_take_reuse_n(v_x_2420, 0ULL, 1);
          V v_d_2444 = v_fieldTypes_2441;
          V v_x_2445 = v_x_2411;
          HeffT2 v_t_2446 = ({ V a_0 = heff_rfield(v_d_2444, 1); V a_1 = v_x_2445; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_2445); r_; });
          V v_t_2457;
          {
            V v_field_2448 = v_t_2446.f[1];
            int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
            if ((v_tag_2447 == ((int64_t)0ULL))) {
              V v_i_2449 = v_field_2448;
              V v_xs_2450 = heff_dup(heff_rfield(v_d_2444, 2));
              if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2449, 1) && heff_intLt_c(heff_dup(v_i_2449), heff_arrayLength_lent(v_xs_2450, 0)))) {
                V v_v_2451 = heff_arrayIndex_lent(v_xs_2450, v_i_2449, 1);
                V v_t_2456 = heff_arraySet(heff_take_field(v_d_2444, 2), v_i_2449, heff_clo_n(g_heff_2eelab_2evalue_2eunspecialize_lam1, 1, 1, (V[]){v_v_2451}));
                v_t_2457 = ({ V rv_2 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_d_2444, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
              } else {
                heff_drop(v_i_2449);
                heff_drop(v_xs_2450);
                v_t_2457 = v_d_2444;
              }
            } else {
              heff_drop(v_field_2448);
              v_t_2457 = v_d_2444;
            }
          }
          v_t_2464 = heff_tag_at_n(v_ru_24x_2420_24VCode, TAG_VCode, 1, (V[]){heff_tag_at_n(v_ru_24v1_2426_24VRecord, TAG_VRecord, 4, (V[]){v_level_2439, v_capture_2440, v_t_2457, v_defaults_2442})});
          break;
        }
        default: heff_nomatch(v_x_2420);
        }
        break;
      }
      case TAG_VSum: {
        heff_take_n(v_v1_2426, 0ULL, 1);
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VPrimInt: {
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VPrimFloat: {
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VPrimString: {
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VPrimRune: {
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VPrimArray: {
        heff_take_n(v_v1_2426, 0ULL, 1);
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      case TAG_VFixed: {
        heff_take_n(v_v1_2426, 0ULL, 1);
        heff_drop(v_x_2411);
        v_t_2464 = v_x_2420;
        break;
      }
      default: heff_nomatch(v_v1_2426);
      }
      break;
    }
    case TAG_VLam: {
      heff_drop(v_x_2411);
      v_t_2464 = v_x_2420;
      break;
    }
    case TAG_VCons: {
      heff_drop(v_x_2411);
      v_t_2464 = v_x_2420;
      break;
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2411);
      v_t_2464 = v_x_2420;
      break;
    }
    default: heff_nomatch(v_x_2420);
    }
    return heff_tag_at_n(v_ru_24x2_2419_24Just, TAG_Just, 1, (V[]){v_t_2464});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
Clo g_heff_2eelab_2evalue_2eimplicitDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eimplicitDefault_entry, 1, 0};

V g_heff_2eelab_2evalue_2eimplicitDefault(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VU: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VDecode: {
    V v_described_245 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 5);
    V v_t_247 = heff_tr(heff_call(v_described_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V t_0 = v_t_248;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_VFunction: {
    V v_dflt_2413 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 6);
    return v_dflt_2413;
  }
  case TAG_VRecord: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_VSum: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_Nothing);
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_VFixed: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2evalue_2eimplicitDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eimplicitDefault(a[0]);
}
Clo g_heff_2eelab_2evalue_2ereplay_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ereplay_entry, 2, 0};

V g_heff_2eelab_2evalue_2ereplay(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    return v_v_240;
  }
  case TAG_SpApp: {
    V v_sp_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2eelab_2evalue_2ereplay(v_v_240, v_sp_242));
    V v_x1_245 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s676305996x967270522(heff_dup(v_a_243), v_t_244));
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nom: {
      V v_x_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      return v_x_246;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_245, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_248 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      return v_x_248;
    }
    default: return heff_nomatch(v_x1_245);
    }
  }
  case TAG_SpProj: {
    V v_sp_249 = heff_field(v_x2_241, 0);
    V v_l_2410 = heff_field(v_x2_241, 1);
    V v_t_2411 = (g_heff_2eelab_2evalue_2ereplay(v_v_240, v_sp_249));
    V v_x1_2412 = ({ V a_0 = v_t_2411; V a_1 = v_l_2410; V r_ = (g_heff_2eelab_2evalue_2eproj(a_0, a_1)); heff_drop(v_t_2411); r_; });
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_x_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      return v_x_2413;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2412, 0ULL, 1);
      return heff_abandon();
    }
    case TAG_Become: {
      V v_x_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      return v_x_2415;
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  case TAG_SpSpec: {
    V v_sp_2416 = heff_field(v_x2_241, 0);
    V v_l_2417 = heff_field(v_x2_241, 1);
    V v_f_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = (g_heff_2eelab_2evalue_2ereplay(v_v_240, v_sp_2416));
    return (g_heff_2eelab_2evalue_2especialize(v_t_2419, heff_dup(v_l_2417), heff_dup(v_f_2418)));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2evalue_2ereplay(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2evalue_2eprojTyWith_24cpr_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2eprojTyWith_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eprojTyWith_24cpr_lam0, 1, 0};

HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V v_t_240, V v_mf_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2evalue_2ebehavior(v_t_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_LikeU: {
    heff_take_n(v_t_243, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_243, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeRecord: {
    V v_capture_2410 = heff_field(v_t_243, 1);
    V v_fieldTypes_2411 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    switch (heff_tag_of(v_mf_241)) {
    case TAG_Nothing: {
      heff_drop(v_capture_2410);
      heff_drop(v_fieldTypes_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_fields_2412 = heff_field(v_mf_241, 0);
      V v_xs_2413 = heff_dup(heff_rfield(v_fields_2412, 2));
      V v_m_2414 = heff_arrayLength_lent(v_xs_2413, 0);
      V v_t_2422;
      if ((heff_peek_word(v_m_2414) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_2413);
        v_t_2422 = heff_arrayGenerate(v_m_2414, ((V)&g_heff_2eelab_2evalue_2eprojTyWith_24cpr_lam0_clo));
      } else {
        V v_e_2416 = heff_arrayIndex_lent(v_xs_2413, MK_INT(0LL), 2);
        V v_y_2420;
        switch (heff_tag_of(v_e_2416)) {
        case TAG_Nom: {
          V v_x_2417 = heff_field(v_e_2416, 0);
          heff_take_n(v_e_2416, 1ULL, 1);
          v_y_2420 = v_x_2417;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_e_2416, 0ULL, 1);
          v_y_2420 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2419 = heff_field(v_e_2416, 0);
          heff_take_n(v_e_2416, 1ULL, 1);
          v_y_2420 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_e_2416);
        }
        V v_t_2421 = heff_arrayKeepsAs_lent(v_xs_2413, v_y_2420, 0);
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_m_2414);
          heff_drop(v_t_2421);
          v_t_2422 = (g_heff_2eelab_2evalue_2eprojTyWith_24map0(MK_INT(1LL), heff_arraySet(v_xs_2413, MK_INT(0LL), v_y_2420)));
        } else {
          heff_drop(v_t_2421);
          v_t_2422 = ({ V a_0 = v_xs_2413; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_2414, v_y_2420); V r_ = (g_heff_2eelab_2evalue_2eprojTyWith_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
        }
      }
      V v_t_2423 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fields_2412, 0)), heff_dup(heff_rfield(v_fields_2412, 1)), v_t_2422});
      V v_x1_2424 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(v_capture_2410, v_fieldTypes_2411, v_x_242, v_t_2423));
      V v_f_2427;
      switch (heff_tag_of(v_x1_2424)) {
      case TAG_MkField: {
        V v_ty_2425 = heff_field(v_x1_2424, 0);
        heff_take_n(v_x1_2424, 1ULL, 2);
        v_f_2427 = v_ty_2425;
        break;
      }
      default: heff_nomatch(v_x1_2424);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
    }
    default: return ((HeffT2){{heff_nomatch(v_mf_241)}});
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_243, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_243, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_NoRules: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
V g_heff_2eelab_2evalue_2eprojTyWith_24cpr_lam0(V self, V *args) {
  V v_u_2415 = args[0];
  heff_drop(v_u_2415);
  return heff_abandon();
}
Clo g_heff_2eelab_2evalue_2eprojTyWith_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eprojTyWith_24generate0_entry, 3, 0};

V g_heff_2eelab_2evalue_2eprojTyWith_24generate0(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_e_243 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_241));
      V v_t_247;
      switch (heff_tag_of(v_e_243)) {
      case TAG_Nom: {
        V v_x_244 = heff_field(v_e_243, 0);
        v_t_247 = heff_dup(v_x_244);
        break;
      }
      case TAG_Describe: {
        v_t_247 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_246 = heff_field(v_e_243, 0);
        v_t_247 = heff_dup(v_x_246);
        break;
      }
      default: heff_nomatch(v_e_243);
      }
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_247);
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_e_243 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_241));
    V v_t_247;
    switch (heff_tag_of(v_e_243)) {
    case TAG_Nom: {
      V v_x_244 = heff_field(v_e_243, 0);
      v_t_247 = heff_dup(v_x_244);
      break;
    }
    case TAG_Describe: {
      v_t_247 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_246 = heff_field(v_e_243, 0);
      v_t_247 = heff_dup(v_x_246);
      break;
    }
    default: heff_nomatch(v_e_243);
    }
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_247);
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2evalue_2eprojTyWith_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2evalue_2eprojTyWith_24generate0(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2evalue_2eprojTyWith_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eprojTyWith_24map0_entry, 2, 0};

V g_heff_2eelab_2evalue_2eprojTyWith_24map0(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_e_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_246;
      switch (heff_tag_of(v_e_242)) {
      case TAG_Nom: {
        V v_x_243 = heff_field(v_e_242, 0);
        heff_take_n(v_e_242, 1ULL, 1);
        v_t_246 = v_x_243;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_e_242, 0ULL, 1);
        v_t_246 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_245 = heff_field(v_e_242, 0);
        heff_take_n(v_e_242, 1ULL, 1);
        v_t_246 = v_x_245;
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), v_t_246);
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_e_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_246;
    switch (heff_tag_of(v_e_242)) {
    case TAG_Nom: {
      V v_x_243 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      v_t_246 = v_x_243;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_e_242, 0ULL, 1);
      v_t_246 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_245 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      v_t_246 = v_x_245;
      break;
    }
    default: heff_nomatch(v_e_242);
    }
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), v_t_246);
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2evalue_2eprojTyWith_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eprojTyWith_24map0(a[0], a[1]);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam1(V self, V *args); static Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam1, 1, 0};
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam2(V self, V *args); static Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam2, 1, 0};
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam0, 1, 0};
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam3(V self, V *args); static Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam3, 1, 0};
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam4(V self, V *args);
Clo g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_entry, 3, 0};

V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(V v_h_240, V v_spine_241, V v_desc_242) {
top: ;
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_240, v_spine_241, ((V)&g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam0_clo), ((V)&g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam3_clo), heff_clo_n(g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam4, 1, 1, (V[]){v_desc_242})});
}
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam1(V self, V *args) {
  V v_a_244 = args[0];
  heff_drop(v_a_244);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam2(V self, V *args) {
  V v_a_245 = args[0];
  heff_drop(v_a_245);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam0(V self, V *args) {
  V v_a_243 = args[0];
  heff_drop(v_a_243);
  return heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam1_clo), ((V)&g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam2_clo)});
}
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam3(V self, V *args) {
  V v_u_246 = args[0];
  heff_drop(v_u_246);
  return NTAG(TAG_NotApplicable);
}
V g_heff_2eelab_2evalue_2emkNeu_24s1076983096x2052723749_lam4(V self, V *args) {
  V v_u_247 = args[0];
  V v_desc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_desc_242;
}
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam1(V self, V *args);
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam2(V self, V *args); static Clo g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam2, 1, 0};
Clo g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_entry, 1, 0};

V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(V v_f_240) {
top: ;
  switch (heff_tag_of(v_f_240)) {
  case TAG_VNeu: {
    V v_h_241 = heff_field(v_f_240, 0);
    V v_sp_242 = heff_field(v_f_240, 1);
    V v_ty_243 = heff_field(v_f_240, 2);
    V v_desc_245 = heff_field(v_f_240, 4);
    heff_take_n(v_f_240, 23ULL, 5);
    V v_x2_246 = heff_tr(heff_call(v_desc_245, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24Just = heff_take_reuse_n(v_x2_246, 1ULL, 1);
      V v_t_248 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(v_x_247));
      v_t_249 = heff_tag_at_n(v_ru_24x2_246_24Just, TAG_Just, 1, (V[]){v_t_248});
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2428 = (g_heff_2eelab_2evalue_2ereflect(heff_dup(v_h_241), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam0, 1, 1, (V[]){v_sp_242}), heff_clo_n(g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam1, 1, 2, (V[]){v_ty_243, v_h_241}), v_t_249));
    return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2428});
  }
  case TAG_VCode: {
    heff_take_n(v_f_240, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_VLam: {
    V v_clo_2431 = heff_field(v_f_240, 1);
    heff_take_n(v_f_240, 2ULL, 2);
    switch (heff_tag_of(v_clo_2431)) {
    case TAG_MkClo: {
      V v_vs_2433 = heff_field(v_clo_2431, 1);
      V v_body_2434 = heff_field(v_clo_2431, 2);
      heff_take_n(v_clo_2431, 6ULL, 3);
      return heff_tail(v_body_2434, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2433, ((V)&g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam2_clo)})});
    }
    case TAG_CloConst: {
      V v_body_2436 = heff_field(v_clo_2431, 0);
      heff_take_n(v_clo_2431, 1ULL, 1);
      return v_body_2436;
    }
    default: return heff_nomatch(v_clo_2431);
    }
  }
  case TAG_VCons: {
    heff_take_n(v_f_240, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_VOpaque: {
    return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
  }
  default: return heff_nomatch(v_f_240);
  }
}
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(a[0]);
}
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_sp_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_242, NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  V v_ty_243 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  V v_t_2412 = heff_tr(heff_call(v_ty_243, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    heff_take_n(v_h_241, 0ULL, 1);
    return (g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(v_t_2412));
  }
  case TAG_HGlobal: {
    heff_take_n(v_h_241, 0ULL, 1);
    return (g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(v_t_2412));
  }
  case TAG_HMeta: {
    heff_take_n(v_h_241, 0ULL, 1);
    V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2412)));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2416, 0ULL, 1);
      return v_t_2412;
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2416, 0ULL, 4);
      return (g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(v_t_2412));
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2416, 0ULL, 3);
      return v_t_2412;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2416, 0ULL, 1);
      return v_t_2412;
    }
    case TAG_LikeInt: {
      return v_t_2412;
    }
    case TAG_LikeFloat: {
      return v_t_2412;
    }
    case TAG_LikeString: {
      return v_t_2412;
    }
    case TAG_LikeRune: {
      return v_t_2412;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2416, 0ULL, 1);
      return v_t_2412;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2416, 0ULL, 1);
      return v_t_2412;
    }
    case TAG_NoRules: {
      return v_t_2412;
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  case TAG_HError: {
    return (g_heff_2eelab_2evalue_2eappTy_24s1932265294x1890494071(v_t_2412));
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_lam2(V self, V *args) {
  V v_a_2435 = args[0];
  heff_drop(v_a_2435);
  return NTAG(TAG_VOpaque);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam0(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam0, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam1(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam1, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam2(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam2, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam3(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam4(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam5(V self, V *args);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam6(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam6, 1, 0};
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam7(V self, V *args); static Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam7, 1, 0};
Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_entry, 6, 0};

V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(V v_tok_240, V v_h_241, V v_sp_242, V v_ty_243, V v_expansion_244, V v_desc_245) {
top: ;
  V v_x1_246 = heff_tr(heff_call(heff_dup(v_ty_243), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2429;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_VU: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_h_248 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 5);
    switch (heff_tag_of(v_h_248)) {
    case TAG_HLocal: {
      heff_take_n(v_h_248, 0ULL, 1);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_h_248, 0ULL, 1);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_h_248, 0ULL, 1);
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2429 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_248);
    }
    break;
  }
  case TAG_VFunction: {
    heff_take_n(v_x1_246, 0ULL, 6);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    heff_take_n(v_x1_246, 0ULL, 4);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_h_241);
    heff_drop(v_sp_242);
    heff_drop(v_ty_243);
    heff_drop(v_expansion_244);
    heff_drop(v_desc_245);
    heff_drop(v_t_2429);
    return heff_tag_at_n(v_tok_240, TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam0_clo), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam1_clo)});
  } else {
    heff_drop(v_t_2429);
    V v_x1_2432 = heff_tr(heff_call(heff_dup(v_ty_243), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_u_2452;
    switch (heff_tag_of(v_x1_2432)) {
    case TAG_VU: {
      V v_u_2433 = heff_field(v_x1_2432, 0);
      heff_take_n(v_x1_2432, 1ULL, 1);
      v_u_2452 = v_u_2433;
      break;
    }
    case TAG_VDecode: {
      heff_take_n(v_x1_2432, 0ULL, 5);
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VFunction: {
      heff_take_n(v_x1_2432, 0ULL, 6);
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VRecord: {
      heff_take_n(v_x1_2432, 0ULL, 4);
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VSum: {
      heff_take_n(v_x1_2432, 0ULL, 1);
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VPrimInt: {
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VPrimFloat: {
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VPrimString: {
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VPrimRune: {
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VPrimArray: {
      heff_take_n(v_x1_2432, 0ULL, 1);
      v_u_2452 = heff_abandon();
      break;
    }
    case TAG_VFixed: {
      heff_take_n(v_x1_2432, 0ULL, 1);
      v_u_2452 = heff_abandon();
      break;
    }
    default: heff_nomatch(v_x1_2432);
    }
    V v_x2_2453 = heff_tr(heff_call(heff_dup(v_desc_245), 1, (V[]){NTAG(TAG_MkUnit)}));
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_tok_240, TAG_VDecode, 5, (V[]){heff_dup(v_h_241), heff_dup(v_sp_242), v_u_2452, ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam2_clo), heff_clo_n(g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam3, 1, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245})});
    }
    case TAG_Just: {
      V v_x_2456 = heff_field(v_x2_2453, 0);
      heff_take_n(v_x2_2453, 1ULL, 1);
      switch (heff_tag_of(v_x_2456)) {
      case TAG_VNeu: {
        heff_take_n(v_x_2456, 0ULL, 5);
        heff_drop_cell(v_tok_240, 5);
        heff_drop(v_h_241);
        heff_drop(v_sp_242);
        heff_drop(v_ty_243);
        heff_drop(v_expansion_244);
        heff_drop(v_desc_245);
        heff_drop(v_u_2452);
        return heff_abandon();
      }
      case TAG_VCode: {
        V v_a_2462 = heff_field(v_x_2456, 0);
        heff_take_n(v_x_2456, 1ULL, 1);
        return heff_tag_at_n(v_tok_240, TAG_VDecode, 5, (V[]){heff_dup(v_h_241), heff_dup(v_sp_242), v_u_2452, heff_clo_n(g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam4, 1, 1, (V[]){v_a_2462}), heff_clo_n(g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam5, 1, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245})});
      }
      case TAG_VLam: {
        heff_take_n(v_x_2456, 0ULL, 2);
        heff_drop_cell(v_tok_240, 5);
        heff_drop(v_h_241);
        heff_drop(v_sp_242);
        heff_drop(v_ty_243);
        heff_drop(v_expansion_244);
        heff_drop(v_desc_245);
        heff_drop(v_u_2452);
        return heff_abandon();
      }
      case TAG_VCons: {
        heff_take_n(v_x_2456, 0ULL, 1);
        heff_drop_cell(v_tok_240, 5);
        heff_drop(v_h_241);
        heff_drop(v_sp_242);
        heff_drop(v_ty_243);
        heff_drop(v_expansion_244);
        heff_drop(v_desc_245);
        heff_drop(v_u_2452);
        return heff_abandon();
      }
      case TAG_VOpaque: {
        heff_drop(v_h_241);
        heff_drop(v_sp_242);
        heff_drop(v_ty_243);
        heff_drop(v_expansion_244);
        heff_drop(v_desc_245);
        heff_drop(v_u_2452);
        V v_t_2470 = heff_tag_at_n(v_tok_240, TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam6_clo), ((V)&g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam7_clo)});
        return v_t_2470;
      }
      default: return heff_nomatch(v_x_2456);
      }
    }
    default: return heff_nomatch(v_x2_2453);
    }
  }
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam0(V self, V *args) {
  V v_x_2430 = args[0];
  heff_drop(v_x_2430);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam1(V self, V *args) {
  V v_x_2431 = args[0];
  heff_drop(v_x_2431);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam2(V self, V *args) {
  V v_x_2454 = args[0];
  heff_drop(v_x_2454);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam3(V self, V *args) {
  V v_x_2455 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_ty_243 = heff_env(self)[2];
  V v_expansion_244 = heff_env(self)[3];
  V v_desc_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2455);
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245});
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam4(V self, V *args) {
  V v_x_2463 = args[0];
  V v_a_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2463);
  return heff_tag_n(TAG_Just, 1, (V[]){v_a_2462});
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam5(V self, V *args) {
  V v_x_2464 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_ty_243 = heff_env(self)[2];
  V v_expansion_244 = heff_env(self)[3];
  V v_desc_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2464);
  return heff_tag_n(TAG_VNeu, 5, (V[]){v_h_241, v_sp_242, v_ty_243, v_expansion_244, v_desc_245});
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam6(V self, V *args) {
  V v_x_2468 = args[0];
  heff_drop(v_x_2468);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_lam7(V self, V *args) {
  V v_x_2469 = args[0];
  heff_drop(v_x_2469);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2evalue_2eebind_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eebind_24tok1_entry, 3, 0};

V g_heff_2eelab_2evalue_2eebind_24tok1(V v_tok_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nom: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    heff_drop_cell(v_tok_240, 1);
    return heff_tail(v_f_241, 1, (V[]){v_x_243});
  }
  case TAG_Describe: {
    V v_x_244 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    heff_drop_cell(v_tok_240, 1);
    return heff_tail(v_f_241, 1, (V[]){v_x_244});
  }
  case TAG_Become: {
    V v_x_245 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_f_241, 1, (V[]){v_x_245}));
    V v_t_2410;
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Nom: {
      V v_x_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_t_2410 = v_x_247;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_246, 0ULL, 1);
      v_t_2410 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_249 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      v_t_2410 = v_x_249;
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    return heff_tag_at_n(v_tok_240, TAG_Become, 1, (V[]){v_t_2410});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2eelab_2evalue_2eebind_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eebind_24tok1(a[0], a[1], a[2]);
}
V g_heff_2eelab_2evalue_2eprojAt_24tok1_lam0(V self, V *args);
V g_heff_2eelab_2evalue_2eprojAt_24tok1_lam1(V self, V *args);
Clo g_heff_2eelab_2evalue_2eprojAt_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2eprojAt_24tok1_entry, 4, 0};

V g_heff_2eelab_2evalue_2eprojAt_24tok1(V v_tok_240, V v_v_241, V v_x_242, V v_a_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_24cpr(v_v_241));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_v_241);
      heff_drop(v_a_243);
      V v_fields_247 = v_field_246;
      V v_byName_248 = heff_take_field(v_fields_247, 1);
      V v_values_249 = heff_get_n(v_fields_247, 2, 3);
      HeffT2 v_t_2410 = ({ V a_0 = v_byName_248; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_248); heff_drop(v_x_242); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_i_2413 = v_field_2412;
          V v_xs_2414 = v_values_249;
          if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2413, 1) && heff_intLt_c(heff_dup(v_i_2413), heff_arrayLength_lent(v_xs_2414, 0)))) {
            V v_v_2415 = heff_arrayIndex(v_xs_2414, v_i_2413);
            return v_v_2415;
          } else {
            heff_drop(v_i_2413);
            heff_drop(v_xs_2414);
            return heff_abandon();
          }
        } else {
          heff_drop(v_values_249);
          heff_drop(v_field_2412);
          return heff_abandon();
        }
      }
    } else {
      heff_drop(v_field_246);
      switch (heff_tag_of(v_v_241)) {
      case TAG_VNeu: {
        V v_h_2416 = heff_field(v_v_241, 0);
        V v_sp_2417 = heff_field(v_v_241, 1);
        heff_take_n(v_v_241, 3ULL, 5);
        V v_t_2423 = (g_heff_2eelab_2evalue_2ereflect(v_h_2416, heff_clo_n(g_heff_2eelab_2evalue_2eprojAt_24tok1_lam0, 1, 2, (V[]){v_sp_2417, v_x_242}), heff_clo_n(g_heff_2eelab_2evalue_2eprojAt_24tok1_lam1, 1, 1, (V[]){v_a_243}), NTAG(TAG_Nothing)));
        return heff_tag_at_n(v_tok_240, TAG_Nom, 1, (V[]){v_t_2423});
      }
      case TAG_VCode: {
        heff_drop(v_a_243);
        switch (heff_tag_of(v_v_241)) {
        case TAG_VNeu: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2430 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 5); r_; });
          return ({ V a_0 = v_t_2430; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCode: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2432 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2432; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VLam: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2435 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 2); r_; });
          return ({ V a_0 = v_t_2435; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCons: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2437 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2437; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          return heff_tag_at_n(v_tok_240, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_241);
        }
      }
      case TAG_VLam: {
        heff_drop(v_a_243);
        switch (heff_tag_of(v_v_241)) {
        case TAG_VNeu: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2445 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 5); r_; });
          return ({ V a_0 = v_t_2445; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCode: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2447 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2447; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VLam: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2450 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 2); r_; });
          return ({ V a_0 = v_t_2450; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCons: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2452 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2452; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          return heff_tag_at_n(v_tok_240, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_241);
        }
      }
      case TAG_VCons: {
        heff_drop(v_a_243);
        switch (heff_tag_of(v_v_241)) {
        case TAG_VNeu: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2459 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 5); r_; });
          return ({ V a_0 = v_t_2459; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCode: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2461 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2461; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VLam: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2464 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 2); r_; });
          return ({ V a_0 = v_t_2464; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCons: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2466 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2466; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          return heff_tag_at_n(v_tok_240, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_241);
        }
      }
      case TAG_VOpaque: {
        heff_drop(v_a_243);
        switch (heff_tag_of(v_v_241)) {
        case TAG_VNeu: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2472 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 5); r_; });
          return ({ V a_0 = v_t_2472; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCode: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2474 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2474; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VLam: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2477 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 2); r_; });
          return ({ V a_0 = v_t_2477; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VCons: {
          heff_drop_cell(v_tok_240, 1);
          V v_t_2479 = ({ V a_0 = v_v_241; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_241, 1); r_; });
          return ({ V a_0 = v_t_2479; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_x_242); r_; });
        }
        case TAG_VOpaque: {
          heff_drop(v_x_242);
          return heff_tag_at_n(v_tok_240, TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
        }
        default: return heff_nomatch(v_v_241);
        }
      }
      default: return heff_nomatch(v_v_241);
      }
    }
  }
}
V g_heff_2eelab_2evalue_2eprojAt_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2eprojAt_24tok1(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2evalue_2eprojAt_24tok1_lam0(V self, V *args) {
  V v_u_2421 = args[0];
  V v_sp_2417 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2421);
  return heff_tag_n(TAG_SpProj, 2, (V[]){v_sp_2417, v_x_242});
}
V g_heff_2eelab_2evalue_2eprojAt_24tok1_lam1(V self, V *args) {
  V v_u_2422 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2422);
  return v_a_243;
}
Clo g_heff_2eelab_2evalue_2ereflect_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2evalue_2ereflect_24tok2_entry, 5, 0};

V g_heff_2eelab_2evalue_2ereflect_24tok2(V v_tok_240, V v_h_241, V v_spineTh_242, V v_ty_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 2);
    V v_t_245 = heff_tr(heff_call(v_spineTh_242, 1, (V[]){NTAG(TAG_MkUnit)}));
    return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_241, v_t_245, v_ty_243, NTAG(TAG_Nothing)));
  }
  case TAG_Just: {
    V v_x41_246 = heff_field(v_x4_244, 0);
    V v_ru_24x4_244_24Just = heff_take_reuse_n(v_x4_244, 1ULL, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_Nom: {
      V v_v_247 = heff_field(v_x41_246, 0);
      V v_ru_24x41_246_24Nom = heff_take_reuse_n(v_x41_246, 1ULL, 1);
      heff_drop(v_ty_243);
      switch (heff_tag_of(v_v_247)) {
      case TAG_VNeu: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Nom, 1);
        return v_v_247;
      }
      case TAG_VCode: {
        V v_v1_2413 = heff_dup(heff_field(v_v_247, 0));
        switch (heff_tag_of(v_v1_2413)) {
        case TAG_VU: {
          heff_take_n(v_v1_2413, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2413, 0ULL, 5);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VFunction: {
          V v_level_2420 = heff_field(v_v1_2413, 0);
          V v_dom_2421 = heff_field(v_v1_2413, 1);
          V v_cod_2422 = heff_field(v_v1_2413, 2);
          V v_implicit_2423 = heff_field(v_v1_2413, 3);
          V v_dflt_2424 = heff_field(v_v1_2413, 4);
          V v_ru_24v1_2413_24VFunction = heff_take_reuse_n(v_v1_2413, 31ULL, 6);
          switch (heff_tag_of(v_v_247)) {
          case TAG_VCode: {
            heff_take_n(v_v_247, 0ULL, 1);
            V v_t_2427 = heff_tag_at_n(v_ru_24x4_244_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_MkFolded, 2, (V[]){v_h_241, v_spineTh_242})});
            return heff_tag_at_n(v_ru_24x41_246_24Nom, TAG_VCode, 1, (V[]){heff_tag_at_n(v_ru_24v1_2413_24VFunction, TAG_VFunction, 6, (V[]){v_level_2420, v_dom_2421, v_cod_2422, v_implicit_2423, v_dflt_2424, v_t_2427})});
          }
          default: return heff_nomatch(v_v_247);
          }
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2413, 0ULL, 4);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2413, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VPrimInt: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VPrimFloat: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VPrimString: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VPrimRune: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2413, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2413, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Nom, 1);
          return v_v_247;
        }
        default: return heff_nomatch(v_v1_2413);
        }
      }
      case TAG_VLam: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Nom, 1);
        return v_v_247;
      }
      case TAG_VCons: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Nom, 1);
        return v_v_247;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Nom, 1);
        return v_v_247;
      }
      default: return heff_nomatch(v_v_247);
      }
    }
    case TAG_Describe: {
      V v_desc_2438 = heff_field(v_x41_246, 0);
      heff_take_n(v_x41_246, 1ULL, 1);
      heff_drop_cell(v_tok_240, 2);
      V v_t_2439 = heff_tr(heff_call(v_spineTh_242, 1, (V[]){NTAG(TAG_MkUnit)}));
      return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_h_241, v_t_2439, v_ty_243, heff_tag_at_n(v_ru_24x4_244_24Just, TAG_Just, 1, (V[]){v_desc_2438})));
    }
    case TAG_Become: {
      V v_v_2440 = heff_field(v_x41_246, 0);
      V v_ru_24x41_246_24Become = heff_take_reuse_n(v_x41_246, 1ULL, 1);
      heff_drop(v_ty_243);
      switch (heff_tag_of(v_v_2440)) {
      case TAG_VNeu: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Become, 1);
        return v_v_2440;
      }
      case TAG_VCode: {
        V v_v1_2446 = heff_dup(heff_field(v_v_2440, 0));
        switch (heff_tag_of(v_v1_2446)) {
        case TAG_VU: {
          heff_take_n(v_v1_2446, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VDecode: {
          heff_take_n(v_v1_2446, 0ULL, 5);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VFunction: {
          V v_level_2453 = heff_field(v_v1_2446, 0);
          V v_dom_2454 = heff_field(v_v1_2446, 1);
          V v_cod_2455 = heff_field(v_v1_2446, 2);
          V v_implicit_2456 = heff_field(v_v1_2446, 3);
          V v_dflt_2457 = heff_field(v_v1_2446, 4);
          V v_ru_24v1_2446_24VFunction = heff_take_reuse_n(v_v1_2446, 31ULL, 6);
          switch (heff_tag_of(v_v_2440)) {
          case TAG_VCode: {
            heff_take_n(v_v_2440, 0ULL, 1);
            V v_t_2460 = heff_tag_at_n(v_ru_24x4_244_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_tok_240, TAG_MkFolded, 2, (V[]){v_h_241, v_spineTh_242})});
            return heff_tag_at_n(v_ru_24x41_246_24Become, TAG_VCode, 1, (V[]){heff_tag_at_n(v_ru_24v1_2446_24VFunction, TAG_VFunction, 6, (V[]){v_level_2453, v_dom_2454, v_cod_2455, v_implicit_2456, v_dflt_2457, v_t_2460})});
          }
          default: return heff_nomatch(v_v_2440);
          }
        }
        case TAG_VRecord: {
          heff_take_n(v_v1_2446, 0ULL, 4);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VSum: {
          heff_take_n(v_v1_2446, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VPrimInt: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VPrimFloat: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VPrimString: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VPrimRune: {
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VPrimArray: {
          heff_take_n(v_v1_2446, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        case TAG_VFixed: {
          heff_take_n(v_v1_2446, 0ULL, 1);
          heff_drop_cell(v_tok_240, 2);
          heff_drop(v_h_241);
          heff_drop(v_spineTh_242);
          heff_drop_cell(v_ru_24x4_244_24Just, 1);
          heff_drop_cell(v_ru_24x41_246_24Become, 1);
          return v_v_2440;
        }
        default: return heff_nomatch(v_v1_2446);
        }
      }
      case TAG_VLam: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Become, 1);
        return v_v_2440;
      }
      case TAG_VCons: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Become, 1);
        return v_v_2440;
      }
      case TAG_VOpaque: {
        heff_drop_cell(v_tok_240, 2);
        heff_drop(v_h_241);
        heff_drop(v_spineTh_242);
        heff_drop_cell(v_ru_24x4_244_24Just, 1);
        heff_drop_cell(v_ru_24x41_246_24Become, 1);
        return v_v_2440;
      }
      default: return heff_nomatch(v_v_2440);
      }
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_heff_2eelab_2evalue_2ereflect_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2evalue_2ereflect_24tok2(a[0], a[1], a[2], a[3], a[4]);
}