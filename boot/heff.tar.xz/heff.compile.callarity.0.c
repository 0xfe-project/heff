// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_dirty 296951788
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_tables 1065764240
#define LBL_uses 10094739
#define LBL_vars 10107635
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_vars__globals__dirty[] = {LBL_vars, LBL_globals, LBL_dirty};
V g_heff_2ecompile_2ecallarity_2edropC(V, V);
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edropC_clo;
V g_heff_2ecompile_2ecallarity_2eexpandApp(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArg(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo;
V g_heff_2ecompile_2ecallarity_2eexpandGo(V, V);
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo;
V g_heff_2ecompile_2ecallarity_2eextend(V, V);
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_clo;
V g_heff_2ecompile_2ecallarity_2eextend_24dps(V, V, V);
V g_heff_2ecompile_2ecallarity_2eextend_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_24dps_clo;
V g_heff_2ecompile_2ecallarity_2efreshMany(V, V);
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo;
V g_heff_2ecompile_2ecallarity_2ehanded(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ehanded_clo;
V g_heff_2ecompile_2ecallarity_2eisNth(V, V, V);
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eisNth_clo;
V g_heff_2ecompile_2ecallarity_2eknownAdd(V, V, V);
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo;
V g_heff_2ecompile_2ecallarity_2enthOr(V, V, V);
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enthOr_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars(V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V, V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo;
V g_heff_2ecompile_2ecallarity_2eraiseDef(V, V, V);
V g_heff_2ecompile_2ecallarity_2eraiseDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eraiseDef_clo;
V g_heff_2ecompile_2ecallarity_2eraiseOnce(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eraiseOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eraiseOnce_clo;
V g_heff_2ecompile_2ecallarity_2eraiseTo(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eraiseTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eraiseTo_clo;
V g_heff_2ecompile_2ecallarity_2etraverseS(V, V);
V g_heff_2ecompile_2ecallarity_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2etraverseS_clo;
V g_heff_2ecompile_2ecallarity_2ezipTo(V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2ecallarity_2efreshMany_str1, 1, "z");
Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2efreshMany_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2efreshMany(V v_k_240, V v_p_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  } else {
    V v_m_243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_clo), 1, (V[]){heff_intSub(v_k_240, MK_INT(1LL))}));
    V v_x2_244 = heff_tr(heff_call(v_m_243, 1, (V[]){heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))}));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_n_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_str0), heff_intShow(v_p_241));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2ecallarity_2efreshMany_str1), v_t_247), v_x_245});
      return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_n_246});
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
}
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2efreshMany(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edropC_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edropC(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2eisNth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eisNth_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eisNth(V v_i_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_x_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_strEq(v_x_241, heff_dup(v_y_243));
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_x_241;
      V t_2 = v_ys_244;
      v_i_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eisNth(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ezipTo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2ezipTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_map_2eempty_get());
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x1_240, 0);
    V v_ys_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_dup(g_map_2eempty_get());
    }
    case TAG_Cons: {
      V v_z_244 = heff_field(v_x2_241, 0);
      V v_zs_245 = heff_field(v_x2_241, 1);
      V v_t_246 = (g_heff_2ecompile_2ecallarity_2ezipTo(v_ys_243, v_zs_245));
      return (g_map_2einsert_24s1341440536x470972936(heff_dup(v_y_242), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_z_244)}), v_t_246));
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2ezipTo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ehanded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ehanded_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2ehanded(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x_244, V v_n_245) {
top: ;
  V v_t_247;
  if (heff_strEq_c(heff_dup(v_h_242), heff_dup(heff_rfield(v_here_241, 0)))) {
    v_t_247 = ({ V a_0 = heff_dup(v_j_243); V a_1 = heff_dup(v_x_244); V b_2 = heff_get_n(v_here_241, 1, 4); V r_ = (g_heff_2ecompile_2ecallarity_2eisNth(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  } else {
    heff_drop_rec(v_here_241, 4);
    v_t_247 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_242);
    heff_drop(v_j_243);
    heff_drop(v_x_244);
    heff_drop(v_t_247);
    return v_n_245;
  } else {
    heff_drop(v_t_247);
    V v_x2_248 = ({ V a_0 = v_h_242; V b_1 = heff_get_n(v_t_240, 0, 1); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_k_2410;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      heff_drop(v_j_243);
      v_k_2410 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_ps_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      v_k_2410 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_243; V a_2 = v_ps_249; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_x3_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_244), heff_rfield(v_n_245, 0)));
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      heff_drop(v_x_244);
      heff_drop(v_k_2410);
      return v_n_245;
    }
    case TAG_Just: {
      V v_k0_2412 = heff_field(v_x3_2411, 0);
      heff_take_n(v_x3_2411, 1ULL, 1);
      if (heff_intLt_c(heff_dup(v_k_2410), v_k0_2412)) {
        V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_x_244, v_k_2410, heff_take_field(v_n_245, 0)));
        return ({ V rv_0 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_n_245, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      } else {
        heff_drop(v_x_244);
        heff_drop(v_k_2410);
        return v_n_245;
      }
    }
    default: return heff_nomatch(v_x3_2411);
    }
  }
}
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2ehanded(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_as_243;
      V t_1 = v_rest_241;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    case TAG_ELam: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2411 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    case TAG_EApp: {
      V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2415 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    case TAG_ELet: {
      V v_cell_2419 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2420 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2419)));
      heff_drop(v_u_2420);
      return v_cell_2419;
    }
    case TAG_ERecord: {
      V v_cell_2423 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2424 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2423)));
      heff_drop(v_u_2424);
      return v_cell_2423;
    }
    case TAG_EProj: {
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2430 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2429)));
      heff_drop(v_u_2430);
      return v_cell_2429;
    }
    case TAG_ETag: {
      V v_cell_2434 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2435 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2434)));
      heff_drop(v_u_2435);
      return v_cell_2434;
    }
    case TAG_EMatch: {
      V v_cell_2438 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2439 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2438)));
      heff_drop(v_u_2439);
      return v_cell_2438;
    }
    case TAG_EPrim: {
      V v_cell_2441 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2442 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2441)));
      heff_drop(v_u_2442);
      return v_cell_2441;
    }
    case TAG_EPrimCall: {
      V v_cell_2445 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2446 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2445)));
      heff_drop(v_u_2446);
      return v_cell_2445;
    }
    case TAG_ECall: {
      V v_cell_2449 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2450 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2449)));
      heff_drop(v_u_2450);
      return v_cell_2449;
    }
    case TAG_EInt: {
      V v_cell_2452 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2453 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2452)));
      heff_drop(v_u_2453);
      return v_cell_2452;
    }
    case TAG_EFloat: {
      V v_cell_2455 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2456 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2455)));
      heff_drop(v_u_2456);
      return v_cell_2455;
    }
    case TAG_EStr: {
      V v_cell_2458 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2459 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2458)));
      heff_drop(v_u_2459);
      return v_cell_2458;
    }
    case TAG_EBytes: {
      V v_cell_2461 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2462 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2461)));
      heff_drop(v_u_2462);
      return v_cell_2461;
    }
    case TAG_EFixed: {
      V v_cell_2465 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2466 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2465)));
      heff_drop(v_u_2466);
      return v_cell_2465;
    }
    case TAG_EFloat32: {
      V v_cell_2468 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2469 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2468)));
      heff_drop(v_u_2469);
      return v_cell_2468;
    }
    case TAG_EAbandon: {
      V v_cell_2470 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2471 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2470)));
      heff_drop(v_u_2471);
      return v_cell_2470;
    }
    case TAG_EFix: {
      V v_cell_2474 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2475 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2474)));
      heff_drop(v_u_2475);
      return v_cell_2474;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2epushNonVars(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_EVar: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_d_242;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2412 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2411;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2415;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_cell_2420 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2421 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2420));
      heff_drop(v_u_2421);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2420;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_cell_2424 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2425 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2424));
      heff_drop(v_u_2425);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2424;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_cell_2430 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2431 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2430));
      heff_drop(v_u_2431);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2430;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_cell_2435 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2436 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2435));
      heff_drop(v_u_2436);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2435;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_cell_2439 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2440 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2439));
      heff_drop(v_u_2440);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2439;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      V v_cell_2442 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2443 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2442));
      heff_drop(v_u_2443);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2442;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_cell_2446 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2447 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2446));
      heff_drop(v_u_2447);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2446;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_cell_2450 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2451 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2450));
      heff_drop(v_u_2451);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2450;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      V v_cell_2453 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2454 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2453));
      heff_drop(v_u_2454);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2453;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      V v_cell_2456 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2457 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2456));
      heff_drop(v_u_2457);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2456;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      V v_cell_2459 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2460 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2459));
      heff_drop(v_u_2460);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2459;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      V v_cell_2462 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2463 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2462));
      heff_drop(v_u_2463);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2462;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      V v_cell_2466 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2467 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2466));
      heff_drop(v_u_2467);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2466;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      V v_cell_2469 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2470 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2469));
      heff_drop(v_u_2470);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2469;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      V v_cell_2471 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2472 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2471));
      heff_drop(v_u_2472);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2471;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      V v_cell_2475 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2476 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2475));
      heff_drop(v_u_2476);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2475;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eknownAdd_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eknownAdd(V v_k_240, V v_d_241, V v_n_242) {
top: ;
  V v_t_243 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eknownAdd_lam0, 1, 1, (V[]){heff_dup(v_n_242)}), v_xs_246));
    V v_t_2413 = heff_get_n(heff_get_n(v_k_240, 0, 2), 0, 1);
    V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_d_241, 0, 3), v_t_2412, v_t_2413));
    return heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){v_t_2414}), heff_get_n(v_n_242, 1, 3)});
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eknownAdd(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_x_248; V b_1 = heff_get_n(v_n_242, 0, 3); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_k_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    if (heff_intLe_c(MK_INT(1000000LL), heff_dup(v_k_2410))) {
      heff_drop(v_k_2410);
      return MK_INT(0LL);
    } else {
      return v_k_2410;
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextend_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eextend(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return v_e_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      V v_t_245 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_245});
    }
    case TAG_EGlobal: {
      V v_t_247 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_247});
    }
    case TAG_ELam: {
      V v_ys_248 = heff_field(v_e_241, 0);
      V v_b_249 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      V v_y_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_y_2411, v_x_2410)) {
        V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2414 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2413, heff_dup(v_ys_248)));
        V v_m_2415 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2416 = (g_map_2esize(v_m_2415));
        V v_t_2418;
        if (heff_intEq_c(v_t_2416, MK_INT(0LL))) {
          heff_drop(v_m_2415);
          v_t_2418 = v_b_249;
        } else {
          v_t_2418 = ({ V a_0 = v_m_2415; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2415); r_; });
        }
        return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2414, v_t_2418});
      } else {
        heff_drop_cell(v_ru_24e_241_24ELam, 2);
        V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
        V v_t_2420 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2419, heff_dup(v_zs_240)));
        V v_m_2421 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2422 = (g_map_2esize(v_m_2421));
        V v_t_2424;
        if (heff_intEq_c(v_t_2422, MK_INT(0LL))) {
          heff_drop(v_m_2421);
          v_t_2424 = v_b_249;
        } else {
          v_t_2424 = ({ V a_0 = v_m_2421; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2421); r_; });
        }
        V t_0 = v_t_2420;
        V t_1 = v_t_2424;
        v_zs_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2425 = heff_field(v_e_241, 0);
      V v_as_2426 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_t_2427 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2428 = (g_prelude_2e_2b_2b(v_as_2426, v_t_2427));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_f_2425, v_t_2428});
    }
    case TAG_ELet: {
      V v_x_2429 = heff_field(v_e_241, 0);
      V v_a_2430 = heff_field(v_e_241, 1);
      V v_b_2431 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2432 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2429, v_a_2430, heff_hole()});
      V v_u_2433 = (g_heff_2ecompile_2ecallarity_2eextend_24dps(v_zs_240, v_b_2431, heff_dup(v_cell_2432)));
      heff_drop(v_u_2433);
      return v_cell_2432;
    }
    case TAG_ERecord: {
      V v_t_2436 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2436});
    }
    case TAG_EProj: {
      V v_t_2441 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2441});
    }
    case TAG_ETag: {
      V v_t_2445 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2445});
    }
    case TAG_EMatch: {
      V v_s_2446 = heff_field(v_e_241, 0);
      V v_arms_2447 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_f_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextend_clo), 1, (V[]){v_zs_240}));
      V v_t_2454 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eextend_lam0, 1, 1, (V[]){v_f_2448}), v_arms_2447));
      return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2446, v_t_2454});
    }
    case TAG_EPrim: {
      V v_t_2456 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2456});
    }
    case TAG_EPrimCall: {
      V v_t_2459 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2459});
    }
    case TAG_ECall: {
      V v_t_2462 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2462});
    }
    case TAG_EInt: {
      V v_t_2464 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2464});
    }
    case TAG_EFloat: {
      V v_t_2466 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2466});
    }
    case TAG_EStr: {
      V v_t_2468 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2468});
    }
    case TAG_EBytes: {
      V v_t_2470 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2470});
    }
    case TAG_EFixed: {
      V v_t_2473 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2473});
    }
    case TAG_EFloat32: {
      V v_t_2475 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2475});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return NTAG(TAG_EAbandon);
    }
    case TAG_EFix: {
      V v_t_2478 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2478});
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextend(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args) {
  V v_x2_2449 = args[0];
  V v_f_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkArm: {
    V v_tg_2450 = heff_field(v_x2_2449, 0);
    V v_vs_2451 = heff_field(v_x2_2449, 1);
    V v_b_2452 = heff_field(v_x2_2449, 2);
    V v_ru_24x2_2449_24MkArm = heff_take_reuse_n(v_x2_2449, 7ULL, 3);
    V v_t_2453 = heff_tr(heff_call(v_f_2448, 1, (V[]){v_b_2452}));
    return heff_tag_at_n(v_ru_24x2_2449_24MkArm, TAG_MkArm, 3, (V[]){v_tg_2450, v_vs_2451, v_t_2453});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eextend_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextend_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eextend_24dps(V v_zs_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      V v_t_246 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_246}));
    }
    case TAG_EGlobal: {
      V v_t_248 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_248}));
    }
    case TAG_ELam: {
      V v_ys_249 = heff_field(v_e_241, 0);
      V v_b_2410 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 3ULL, 2);
      V v_x_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_249));
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2415 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2414, heff_dup(v_ys_249)));
        V v_m_2416 = ({ V a_0 = v_ys_249; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_249); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2417 = (g_map_2esize(v_m_2416));
        V v_t_2419;
        if (heff_intEq_c(v_t_2417, MK_INT(0LL))) {
          heff_drop(v_m_2416);
          v_t_2419 = v_b_2410;
        } else {
          v_t_2419 = ({ V a_0 = v_m_2416; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2416); r_; });
        }
        return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, v_t_2419}));
      } else {
        V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_249));
        V v_t_2421 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2420, heff_dup(v_zs_240)));
        V v_m_2422 = ({ V a_0 = v_ys_249; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_249); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2423 = (g_map_2esize(v_m_2422));
        V v_t_2425;
        if (heff_intEq_c(v_t_2423, MK_INT(0LL))) {
          heff_drop(v_m_2422);
          v_t_2425 = v_b_2410;
        } else {
          v_t_2425 = ({ V a_0 = v_m_2422; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2422); r_; });
        }
        V t_0 = v_t_2421;
        V t_1 = v_t_2425;
        V t_2 = v_d_242;
        v_zs_240 = t_0;
        v_e_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2426 = heff_field(v_e_241, 0);
      V v_as_2427 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 3ULL, 2);
      V v_t_2428 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2429 = (g_prelude_2e_2b_2b(v_as_2427, v_t_2428));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_f_2426, v_t_2429}));
    }
    case TAG_ELet: {
      V v_x_2430 = heff_field(v_e_241, 0);
      V v_a_2431 = heff_field(v_e_241, 1);
      V v_b_2432 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2433 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2430, v_a_2431, heff_hole()});
      V v_u_2434 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2433));
      heff_drop(v_u_2434);
      V t_0 = v_zs_240;
      V t_1 = v_b_2432;
      V t_2 = v_cell_2433;
      v_zs_240 = t_0;
      v_e_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_t_2437 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2437}));
    }
    case TAG_EProj: {
      V v_t_2442 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2442}));
    }
    case TAG_ETag: {
      V v_t_2446 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2446}));
    }
    case TAG_EMatch: {
      V v_s_2447 = heff_field(v_e_241, 0);
      V v_arms_2448 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 3ULL, 2);
      V v_f_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextend_clo), 1, (V[]){v_zs_240}));
      V v_t_2455 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0, 1, 1, (V[]){v_f_2449}), v_arms_2448));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2447, v_t_2455}));
    }
    case TAG_EPrim: {
      V v_t_2457 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2457}));
    }
    case TAG_EPrimCall: {
      V v_t_2460 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2460}));
    }
    case TAG_ECall: {
      V v_t_2463 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2463}));
    }
    case TAG_EInt: {
      V v_t_2465 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2465}));
    }
    case TAG_EFloat: {
      V v_t_2467 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2467}));
    }
    case TAG_EStr: {
      V v_t_2469 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2469}));
    }
    case TAG_EBytes: {
      V v_t_2471 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2471}));
    }
    case TAG_EFixed: {
      V v_t_2474 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2474}));
    }
    case TAG_EFloat32: {
      V v_t_2476 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2476}));
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return heff_setField(v_d_242, MK_INT(2LL), NTAG(TAG_EAbandon));
    }
    case TAG_EFix: {
      V v_t_2479 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2479}));
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextend_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0(V self, V *args) {
  V v_x2_2450 = args[0];
  V v_f_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkArm: {
    V v_tg_2451 = heff_field(v_x2_2450, 0);
    V v_vs_2452 = heff_field(v_x2_2450, 1);
    V v_b_2453 = heff_field(v_x2_2450, 2);
    V v_ru_24x2_2450_24MkArm = heff_take_reuse_n(v_x2_2450, 7ULL, 3);
    V v_t_2454 = heff_tr(heff_call(v_f_2449, 1, (V[]){v_b_2453}));
    return heff_tag_at_n(v_ru_24x2_2450_24MkArm, TAG_MkArm, 3, (V[]){v_tg_2451, v_vs_2452, v_t_2454});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
Clo g_heff_2ecompile_2ecallarity_2eraiseTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eraiseTo_entry, 5, 0};

V g_heff_2ecompile_2ecallarity_2eraiseTo(V v_d_240, V v_xs_241, V v_b_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_z_244});
  }
  case TAG_Just: {
    V v_m_245 = heff_field(v_x4_243, 0);
    V v_y_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    if (heff_intLt_c(v_y_246, heff_dup(v_m_245))) {
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_249 = heff_intSub(heff_dup(v_m_245), v_t_248);
      V v_x2_2410 = (g_heff_2ecompile_2ecallarity_2efreshMany(v_t_249, v_z_244));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_n_2412 = heff_field(v_x2_2410, 1);
        V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
        V v_t_2413 = (g_prelude_2e_2b_2b(v_xs_241, heff_dup(v_x_2411)));
        V v_t_2414 = (g_heff_2ecompile_2ecallarity_2eextend(v_x_2411, v_b_242));
        V v_body_2415 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2413, v_t_2414});
        V v_t_2416 = ({ V rv_2 = v_body_2415; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2416, v_n_2412});
      }
      default: return heff_nomatch(v_x2_2410);
      }
    } else {
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_z_244});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eraiseTo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2ecallarity_2eraiseTo(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eraiseOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eraiseOnce_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eraiseOnce(V v_d_240, V v_calls_241, V v_uses_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_calls_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
  }
  case TAG_Just: {
    V v_m_244 = heff_field(v_calls_241, 0);
    switch (heff_tag_of(v_uses_242)) {
    case TAG_Nothing: {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
    }
    case TAG_Just: {
      V v_uses1_245 = heff_field(v_uses_242, 0);
      if (heff_intEq_c(heff_dup(v_uses1_245), MK_INT(1LL))) {
        if (heff_intLt_c(MK_INT(0LL), heff_dup(v_m_244))) {
          V v_x2_248 = (g_heff_2ecompile_2ecallarity_2efreshMany(heff_dup(v_m_244), v_p_243));
          switch (heff_tag_of(v_x2_248)) {
          case TAG_MkPair: {
            V v_x_249 = heff_field(v_x2_248, 0);
            V v_n_2410 = heff_field(v_x2_248, 1);
            V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
            V v_t_2411 = (g_heff_2ecompile_2ecallarity_2eextend(heff_dup(v_x_249), heff_take_field(v_d_240, 2)));
            V v_body_2412 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_249, v_t_2411});
            V v_t_2413 = ({ V rv_2 = v_body_2412; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_n_2410});
          }
          default: return heff_nomatch(v_x2_248);
          }
        } else {
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
        }
      } else {
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_p_243});
      }
    }
    default: return heff_nomatch(v_uses_242);
    }
  }
  default: return heff_nomatch(v_calls_241);
  }
}
V g_heff_2ecompile_2ecallarity_2eraiseOnce_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eraiseOnce(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2eraiseDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eraiseDef_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eraiseDef(V v_gl_240, V v_d_241, V v_z_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    V v_ru_24t_243_24EVar = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_247;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EVar, 1);
      v_t_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_247 = heff_tag_at_n(v_ru_24t_243_24EVar, TAG_Just, 1, (V[]){heff_get_n(v_u_246, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    V v_x1_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2410;
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nothing: {
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Just = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x1_248_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_249, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_248);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_247; V a_2 = v_t_2410; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); heff_drop(v_t_2410); r_; });
  }
  case TAG_EGlobal: {
    V v_ru_24t_243_24EGlobal = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_2412 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2414;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EGlobal, 1);
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24t_243_24EGlobal, TAG_Just, 1, (V[]){heff_get_n(v_u_2413, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    V v_x1_2415 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2417;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_Nothing: {
      v_t_2417 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2416 = heff_field(v_x1_2415, 0);
      V v_ru_24x1_2415_24Just = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
      v_t_2417 = heff_tag_at_n(v_ru_24x1_2415_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2416, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2414; V a_2 = v_t_2417; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); heff_drop(v_t_2417); r_; });
  }
  case TAG_ELam: {
    V v_xs_2418 = heff_field(v_t_243, 0);
    V v_b_2419 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    V v_x1_2420 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2422;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nothing: {
      v_t_2422 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2421 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24Just = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      v_t_2422 = heff_tag_at_n(v_ru_24x1_2420_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2421, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_xs_2418; V a_2 = v_b_2419; V a_3 = v_t_2422; V a_4 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseTo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2422); r_; });
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2425 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2427;
    switch (heff_tag_of(v_x1_2425)) {
    case TAG_Nothing: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2426 = heff_field(v_x1_2425, 0);
      V v_ru_24x1_2425_24Just = heff_take_reuse_n(v_x1_2425, 1ULL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24x1_2425_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2426, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2425);
    }
    V v_x1_2428 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2430;
    switch (heff_tag_of(v_x1_2428)) {
    case TAG_Nothing: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2429 = heff_field(v_x1_2428, 0);
      V v_ru_24x1_2428_24Just = heff_take_reuse_n(v_x1_2428, 1ULL, 1);
      v_t_2430 = heff_tag_at_n(v_ru_24x1_2428_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2429, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2428);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2427; V a_2 = v_t_2430; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2427); heff_drop(v_t_2430); r_; });
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_x1_2434 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2436;
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_Nothing: {
      v_t_2436 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2435 = heff_field(v_x1_2434, 0);
      V v_ru_24x1_2434_24Just = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
      v_t_2436 = heff_tag_at_n(v_ru_24x1_2434_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2435, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2434);
    }
    V v_x1_2437 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2439;
    switch (heff_tag_of(v_x1_2437)) {
    case TAG_Nothing: {
      v_t_2439 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2438 = heff_field(v_x1_2437, 0);
      V v_ru_24x1_2437_24Just = heff_take_reuse_n(v_x1_2437, 1ULL, 1);
      v_t_2439 = heff_tag_at_n(v_ru_24x1_2437_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2438, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2437);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2436; V a_2 = v_t_2439; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2436); heff_drop(v_t_2439); r_; });
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2442 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2444;
    switch (heff_tag_of(v_x1_2442)) {
    case TAG_Nothing: {
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2443 = heff_field(v_x1_2442, 0);
      V v_ru_24x1_2442_24Just = heff_take_reuse_n(v_x1_2442, 1ULL, 1);
      v_t_2444 = heff_tag_at_n(v_ru_24x1_2442_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2443, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2442);
    }
    V v_x1_2445 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2447;
    switch (heff_tag_of(v_x1_2445)) {
    case TAG_Nothing: {
      v_t_2447 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2446 = heff_field(v_x1_2445, 0);
      V v_ru_24x1_2445_24Just = heff_take_reuse_n(v_x1_2445, 1ULL, 1);
      v_t_2447 = heff_tag_at_n(v_ru_24x1_2445_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2446, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2445);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2444; V a_2 = v_t_2447; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2444); heff_drop(v_t_2447); r_; });
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    V v_x1_2452 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2454;
    switch (heff_tag_of(v_x1_2452)) {
    case TAG_Nothing: {
      v_t_2454 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2453 = heff_field(v_x1_2452, 0);
      V v_ru_24x1_2452_24Just = heff_take_reuse_n(v_x1_2452, 1ULL, 1);
      v_t_2454 = heff_tag_at_n(v_ru_24x1_2452_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2453, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2452);
    }
    V v_x1_2455 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2457;
    switch (heff_tag_of(v_x1_2455)) {
    case TAG_Nothing: {
      v_t_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2456 = heff_field(v_x1_2455, 0);
      V v_ru_24x1_2455_24Just = heff_take_reuse_n(v_x1_2455, 1ULL, 1);
      v_t_2457 = heff_tag_at_n(v_ru_24x1_2455_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2456, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2455);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2454; V a_2 = v_t_2457; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2454); heff_drop(v_t_2457); r_; });
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    V v_x1_2461 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2463;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_Nothing: {
      v_t_2463 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24Just = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      v_t_2463 = heff_tag_at_n(v_ru_24x1_2461_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2462, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    V v_x1_2464 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2466;
    switch (heff_tag_of(v_x1_2464)) {
    case TAG_Nothing: {
      v_t_2466 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2465 = heff_field(v_x1_2464, 0);
      V v_ru_24x1_2464_24Just = heff_take_reuse_n(v_x1_2464, 1ULL, 1);
      v_t_2466 = heff_tag_at_n(v_ru_24x1_2464_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2465, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2464);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2463; V a_2 = v_t_2466; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2463); heff_drop(v_t_2466); r_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2469 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2469)) {
    case TAG_Nothing: {
      v_t_2471 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2470 = heff_field(v_x1_2469, 0);
      V v_ru_24x1_2469_24Just = heff_take_reuse_n(v_x1_2469, 1ULL, 1);
      v_t_2471 = heff_tag_at_n(v_ru_24x1_2469_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2470, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2469);
    }
    V v_x1_2472 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2474;
    switch (heff_tag_of(v_x1_2472)) {
    case TAG_Nothing: {
      v_t_2474 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2473 = heff_field(v_x1_2472, 0);
      V v_ru_24x1_2472_24Just = heff_take_reuse_n(v_x1_2472, 1ULL, 1);
      v_t_2474 = heff_tag_at_n(v_ru_24x1_2472_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2473, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2472);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2471; V a_2 = v_t_2474; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2471); heff_drop(v_t_2474); r_; });
  }
  case TAG_EPrim: {
    V v_ru_24t_243_24EPrim = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_2476 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2478;
    switch (heff_tag_of(v_x1_2476)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EPrim, 1);
      v_t_2478 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2477 = heff_field(v_x1_2476, 0);
      heff_take_n(v_x1_2476, 1ULL, 1);
      v_t_2478 = heff_tag_at_n(v_ru_24t_243_24EPrim, TAG_Just, 1, (V[]){heff_get_n(v_u_2477, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2476);
    }
    V v_x1_2479 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2481;
    switch (heff_tag_of(v_x1_2479)) {
    case TAG_Nothing: {
      v_t_2481 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2480 = heff_field(v_x1_2479, 0);
      V v_ru_24x1_2479_24Just = heff_take_reuse_n(v_x1_2479, 1ULL, 1);
      v_t_2481 = heff_tag_at_n(v_ru_24x1_2479_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2480, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2479);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2478; V a_2 = v_t_2481; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2478); heff_drop(v_t_2481); r_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2484 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2486;
    switch (heff_tag_of(v_x1_2484)) {
    case TAG_Nothing: {
      v_t_2486 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2485 = heff_field(v_x1_2484, 0);
      V v_ru_24x1_2484_24Just = heff_take_reuse_n(v_x1_2484, 1ULL, 1);
      v_t_2486 = heff_tag_at_n(v_ru_24x1_2484_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2485, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2484);
    }
    V v_x1_2487 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2489;
    switch (heff_tag_of(v_x1_2487)) {
    case TAG_Nothing: {
      v_t_2489 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2488 = heff_field(v_x1_2487, 0);
      V v_ru_24x1_2487_24Just = heff_take_reuse_n(v_x1_2487, 1ULL, 1);
      v_t_2489 = heff_tag_at_n(v_ru_24x1_2487_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2488, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2487);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2486; V a_2 = v_t_2489; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2486); heff_drop(v_t_2489); r_; });
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_2492 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2494;
    switch (heff_tag_of(v_x1_2492)) {
    case TAG_Nothing: {
      v_t_2494 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2493 = heff_field(v_x1_2492, 0);
      V v_ru_24x1_2492_24Just = heff_take_reuse_n(v_x1_2492, 1ULL, 1);
      v_t_2494 = heff_tag_at_n(v_ru_24x1_2492_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2493, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2492);
    }
    V v_x1_2495 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_2497;
    switch (heff_tag_of(v_x1_2495)) {
    case TAG_Nothing: {
      v_t_2497 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_2496 = heff_field(v_x1_2495, 0);
      V v_ru_24x1_2495_24Just = heff_take_reuse_n(v_x1_2495, 1ULL, 1);
      v_t_2497 = heff_tag_at_n(v_ru_24x1_2495_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_2496, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2495);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2494; V a_2 = v_t_2497; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2494); heff_drop(v_t_2497); r_; });
  }
  case TAG_EInt: {
    V v_ru_24t_243_24EInt = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_2499 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24101;
    switch (heff_tag_of(v_x1_2499)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EInt, 1);
      v_t_24101 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24100 = heff_field(v_x1_2499, 0);
      heff_take_n(v_x1_2499, 1ULL, 1);
      v_t_24101 = heff_tag_at_n(v_ru_24t_243_24EInt, TAG_Just, 1, (V[]){heff_get_n(v_u_24100, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_2499);
    }
    V v_x1_24102 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24104;
    switch (heff_tag_of(v_x1_24102)) {
    case TAG_Nothing: {
      v_t_24104 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24103 = heff_field(v_x1_24102, 0);
      V v_ru_24x1_24102_24Just = heff_take_reuse_n(v_x1_24102, 1ULL, 1);
      v_t_24104 = heff_tag_at_n(v_ru_24x1_24102_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24103, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24102);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24101; V a_2 = v_t_24104; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24101); heff_drop(v_t_24104); r_; });
  }
  case TAG_EFloat: {
    V v_ru_24t_243_24EFloat = heff_take_reuse_na(v_t_243, 0ULL, 1);
    V v_x1_24106 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24108;
    switch (heff_tag_of(v_x1_24106)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EFloat, 1);
      v_t_24108 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24107 = heff_field(v_x1_24106, 0);
      heff_take_n(v_x1_24106, 1ULL, 1);
      v_t_24108 = heff_tag_at_n(v_ru_24t_243_24EFloat, TAG_Just, 1, (V[]){heff_get_n(v_u_24107, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24106);
    }
    V v_x1_24109 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24111;
    switch (heff_tag_of(v_x1_24109)) {
    case TAG_Nothing: {
      v_t_24111 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24110 = heff_field(v_x1_24109, 0);
      V v_ru_24x1_24109_24Just = heff_take_reuse_n(v_x1_24109, 1ULL, 1);
      v_t_24111 = heff_tag_at_n(v_ru_24x1_24109_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24110, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24109);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24108; V a_2 = v_t_24111; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24108); heff_drop(v_t_24111); r_; });
  }
  case TAG_EStr: {
    V v_ru_24t_243_24EStr = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_24113 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24115;
    switch (heff_tag_of(v_x1_24113)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EStr, 1);
      v_t_24115 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24114 = heff_field(v_x1_24113, 0);
      heff_take_n(v_x1_24113, 1ULL, 1);
      v_t_24115 = heff_tag_at_n(v_ru_24t_243_24EStr, TAG_Just, 1, (V[]){heff_get_n(v_u_24114, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24113);
    }
    V v_x1_24116 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24118;
    switch (heff_tag_of(v_x1_24116)) {
    case TAG_Nothing: {
      v_t_24118 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24117 = heff_field(v_x1_24116, 0);
      V v_ru_24x1_24116_24Just = heff_take_reuse_n(v_x1_24116, 1ULL, 1);
      v_t_24118 = heff_tag_at_n(v_ru_24x1_24116_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24117, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24116);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24115; V a_2 = v_t_24118; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24115); heff_drop(v_t_24118); r_; });
  }
  case TAG_EBytes: {
    V v_ru_24t_243_24EBytes = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_x1_24120 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24122;
    switch (heff_tag_of(v_x1_24120)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EBytes, 1);
      v_t_24122 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24121 = heff_field(v_x1_24120, 0);
      heff_take_n(v_x1_24120, 1ULL, 1);
      v_t_24122 = heff_tag_at_n(v_ru_24t_243_24EBytes, TAG_Just, 1, (V[]){heff_get_n(v_u_24121, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24120);
    }
    V v_x1_24123 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24125;
    switch (heff_tag_of(v_x1_24123)) {
    case TAG_Nothing: {
      v_t_24125 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24124 = heff_field(v_x1_24123, 0);
      V v_ru_24x1_24123_24Just = heff_take_reuse_n(v_x1_24123, 1ULL, 1);
      v_t_24125 = heff_tag_at_n(v_ru_24x1_24123_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24124, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24123);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24122; V a_2 = v_t_24125; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24122); heff_drop(v_t_24125); r_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_24128 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24130;
    switch (heff_tag_of(v_x1_24128)) {
    case TAG_Nothing: {
      v_t_24130 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24129 = heff_field(v_x1_24128, 0);
      V v_ru_24x1_24128_24Just = heff_take_reuse_n(v_x1_24128, 1ULL, 1);
      v_t_24130 = heff_tag_at_n(v_ru_24x1_24128_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24129, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24128);
    }
    V v_x1_24131 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24133;
    switch (heff_tag_of(v_x1_24131)) {
    case TAG_Nothing: {
      v_t_24133 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24132 = heff_field(v_x1_24131, 0);
      V v_ru_24x1_24131_24Just = heff_take_reuse_n(v_x1_24131, 1ULL, 1);
      v_t_24133 = heff_tag_at_n(v_ru_24x1_24131_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24132, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24131);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24130; V a_2 = v_t_24133; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24130); heff_drop(v_t_24133); r_; });
  }
  case TAG_EFloat32: {
    V v_ru_24t_243_24EFloat32 = heff_take_reuse_na(v_t_243, 0ULL, 1);
    V v_x1_24135 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24137;
    switch (heff_tag_of(v_x1_24135)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24EFloat32, 1);
      v_t_24137 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24136 = heff_field(v_x1_24135, 0);
      heff_take_n(v_x1_24135, 1ULL, 1);
      v_t_24137 = heff_tag_at_n(v_ru_24t_243_24EFloat32, TAG_Just, 1, (V[]){heff_get_n(v_u_24136, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24135);
    }
    V v_x1_24138 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24140;
    switch (heff_tag_of(v_x1_24138)) {
    case TAG_Nothing: {
      v_t_24140 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24139 = heff_field(v_x1_24138, 0);
      V v_ru_24x1_24138_24Just = heff_take_reuse_n(v_x1_24138, 1ULL, 1);
      v_t_24140 = heff_tag_at_n(v_ru_24x1_24138_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24139, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24138);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24137; V a_2 = v_t_24140; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24137); heff_drop(v_t_24140); r_; });
  }
  case TAG_EAbandon: {
    V v_x1_24141 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24143;
    switch (heff_tag_of(v_x1_24141)) {
    case TAG_Nothing: {
      v_t_24143 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24142 = heff_field(v_x1_24141, 0);
      V v_ru_24x1_24141_24Just = heff_take_reuse_n(v_x1_24141, 1ULL, 1);
      v_t_24143 = heff_tag_at_n(v_ru_24x1_24141_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24142, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24141);
    }
    V v_x1_24144 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24146;
    switch (heff_tag_of(v_x1_24144)) {
    case TAG_Nothing: {
      v_t_24146 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24145 = heff_field(v_x1_24144, 0);
      V v_ru_24x1_24144_24Just = heff_take_reuse_n(v_x1_24144, 1ULL, 1);
      v_t_24146 = heff_tag_at_n(v_ru_24x1_24144_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24145, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24144);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24143; V a_2 = v_t_24146; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24143); heff_drop(v_t_24146); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    V v_x1_24149 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24151;
    switch (heff_tag_of(v_x1_24149)) {
    case TAG_Nothing: {
      v_t_24151 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24150 = heff_field(v_x1_24149, 0);
      V v_ru_24x1_24149_24Just = heff_take_reuse_n(v_x1_24149, 1ULL, 1);
      v_t_24151 = heff_tag_at_n(v_ru_24x1_24149_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24150, 0, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24149);
    }
    V v_x1_24152 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_241, 0)), v_gl_240));
    V v_t_24154;
    switch (heff_tag_of(v_x1_24152)) {
    case TAG_Nothing: {
      v_t_24154 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_u_24153 = heff_field(v_x1_24152, 0);
      V v_ru_24x1_24152_24Just = heff_take_reuse_n(v_x1_24152, 1ULL, 1);
      v_t_24154 = heff_tag_at_n(v_ru_24x1_24152_24Just, TAG_Just, 1, (V[]){heff_get_n(v_u_24153, 1, 3)});
      break;
    }
    default: heff_nomatch(v_x1_24152);
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24151; V a_2 = v_t_24154; V a_3 = v_z_242; V r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_24151); heff_drop(v_t_24154); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eraiseDef_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2ecallarity_2eraiseDef(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam20(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArg_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArg(V v_t_240, V v_h_241, V v_j_242, V v_a_243) {
top: ;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam0, 1, 1, (V[]){v_a_243});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam1, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELam: {
    V v_ys_248 = heff_field(v_a_243, 0);
    V v_b_249 = heff_field(v_a_243, 1);
    heff_take_n(v_a_243, 3ULL, 2);
    V v_x2_2410 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_h_241), heff_rfield(v_t_240, 0)));
    V v_x_2412;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      v_x_2412 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_ps_2411 = heff_field(v_x2_2410, 0);
      heff_take_n(v_x2_2410, 1ULL, 1);
      v_x_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_242); V a_2 = v_ps_2411; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    V v_y_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
    if (heff_intLt_c(v_y_2413, v_x_2412)) {
      V v_x2_2415 = ({ V a_0 = v_h_241; V b_1 = heff_get_n(v_t_240, 0, 1); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2417;
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nothing: {
        heff_drop(v_j_242);
        v_t_2417 = MK_INT(0LL);
        break;
      }
      case TAG_Just: {
        V v_ps_2416 = heff_field(v_x2_2415, 0);
        heff_take_n(v_x2_2415, 1ULL, 1);
        v_t_2417 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_242; V a_2 = v_ps_2416; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
      V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      V v_t_2419 = heff_intSub(v_t_2417, v_t_2418);
      return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam2, 1, 3, (V[]){v_t_2419, v_ys_248, v_b_249});
    } else {
      heff_drop_rec(v_t_240, 1);
      heff_drop(v_h_241);
      heff_drop(v_j_242);
      return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam3, 1, 2, (V[]){v_ys_248, v_b_249});
    }
  }
  case TAG_EApp: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam4, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELet: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam5, 1, 1, (V[]){v_a_243});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam6, 1, 1, (V[]){v_a_243});
  }
  case TAG_EProj: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam7, 1, 1, (V[]){v_a_243});
  }
  case TAG_ETag: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam8, 1, 1, (V[]){v_a_243});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam9, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam10, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam11, 1, 1, (V[]){v_a_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam12, 1, 1, (V[]){v_a_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam13, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam14, 1, 1, (V[]){v_a_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam15, 1, 1, (V[]){v_a_243});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam16, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam17, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam18, 1, 1, (V[]){v_a_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam19, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_h_241);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam20, 1, 1, (V[]){v_a_243});
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandArg(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_247});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_t_2419 = heff_env(self)[0];
  V v_ys_248 = heff_env(self)[1];
  V v_b_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2421 = (g_heff_2ecompile_2ecallarity_2efreshMany(v_t_2419, v_n_2420));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = (g_prelude_2e_2b_2b(v_ys_248, heff_dup(v_x_2422)));
    V v_t_2425 = (g_heff_2ecompile_2ecallarity_2eextend(v_x_2422, v_b_249));
    V v_x_2426 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2424, v_t_2425});
    return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){v_x_2426, v_n_2423});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args) {
  V v_n_2427 = args[0];
  V v_ys_248 = heff_env(self)[0];
  V v_b_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_ys_248, v_b_249}), v_n_2427});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args) {
  V v_n_2430 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2430});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args) {
  V v_n_2434 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2434});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args) {
  V v_n_2437 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2437});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args) {
  V v_n_2442 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2442});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args) {
  V v_n_2446 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2446});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args) {
  V v_n_2449 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2449});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args) {
  V v_n_2451 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2451});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args) {
  V v_n_2454 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2454});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args) {
  V v_n_2457 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2457});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args) {
  V v_n_2459 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2459});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args) {
  V v_n_2461 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2461});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args) {
  V v_n_2463 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2463});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args) {
  V v_n_2465 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2465});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args) {
  V v_n_2468 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2468});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args) {
  V v_n_2470 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2470});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args) {
  V v_n_2471 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2471});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam20(V self, V *args) {
  V v_n_2474 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2474});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam22(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandGo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eexpandGo(V v_t_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_247));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_241, 0);
    V v_as_2414 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    return (g_heff_2ecompile_2ecallarity_2eexpandApp(v_t_2415, v_t_240, v_f_2413, v_as_2414));
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_e_241, 0);
    V v_a_2417 = heff_field(v_e_241, 1);
    V v_b_2418 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2419 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_a_2417));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam3, 1, 4, (V[]){v_m_2419, v_t_240, v_b_2418, v_x_2416});
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_e_241, 0);
    V v_ts_2429 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_go_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2439 = (g_heff_2ecompile_2ecallarity_2etraverseS(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam4, 1, 1, (V[]){v_go_2430}), v_fs_2428));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam6, 1, 2, (V[]){v_m_2439, v_ts_2429});
  }
  case TAG_EProj: {
    V v_e1_2444 = heff_field(v_e_241, 0);
    V v_l_2445 = heff_field(v_e_241, 1);
    V v_sh_2446 = heff_field(v_e_241, 2);
    V v_ft_2447 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_2448 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_e1_2444));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam7, 1, 4, (V[]){v_m_2448, v_l_2445, v_sh_2446, v_ft_2447});
  }
  case TAG_ETag: {
    V v_tg_2453 = heff_field(v_e_241, 0);
    V v_as_2454 = heff_field(v_e_241, 1);
    V v_ts_2455 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2457 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_t_2456, v_as_2454));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam8, 1, 3, (V[]){v_m_2457, v_tg_2453, v_ts_2455});
  }
  case TAG_EMatch: {
    V v_s_2462 = heff_field(v_e_241, 0);
    V v_arms_2463 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2464 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_s_2462));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam9, 1, 3, (V[]){v_m_2464, v_t_240, v_arms_2463});
  }
  case TAG_EPrim: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam12, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_2485 = heff_field(v_e_241, 0);
    V v_as_2486 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2488 = (g_heff_2ecompile_2ecallarity_2etraverseS(v_t_2487, v_as_2486));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam13, 1, 2, (V[]){v_m_2488, v_p_2485});
  }
  case TAG_ECall: {
    V v_g_2493 = heff_field(v_e_241, 0);
    V v_as_2494 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    V v_m_2496 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_t_2495, v_t_240, heff_dup(v_g_2493), MK_INT(0LL), v_as_2494));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam14, 1, 2, (V[]){v_m_2496, v_g_2493});
  }
  case TAG_EInt: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam15, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam16, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam17, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam18, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam19, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam20, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam21, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam22, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandGo(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_243});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_b_2418 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_m_2424 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_2418));
    V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_n_2423}));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_n_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2416, v_x_2422, v_x_2426}), v_n_2427});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_l_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2432, v_x_2437}), v_n_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_go_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_l_2432 = heff_field(v_x2_2431, 0);
    V v_e_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    V v_m_2434 = heff_tr(heff_call(v_go_2430, 1, (V[]){v_e_2433}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam5, 1, 2, (V[]){v_m_2434, v_l_2432});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_ts_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2442, v_ts_2429}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_l_2445 = heff_env(self)[1];
  V v_sh_2446 = heff_env(self)[2];
  V v_ft_2447 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2451, v_l_2445, v_sh_2446, v_ft_2447}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_tg_2453 = heff_env(self)[1];
  V v_ts_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_tg_2453, v_x_2460, v_ts_2455}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args) {
  V v_n_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_tg_2471 = heff_env(self)[1];
  V v_vs_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_n_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_n_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tg_2471, v_vs_2472, v_x_2477}), v_n_2478});
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args) {
  V v_x2_2470 = args[0];
  V v_go_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkArm: {
    V v_tg_2471 = heff_field(v_x2_2470, 0);
    V v_vs_2472 = heff_field(v_x2_2470, 1);
    V v_b_2473 = heff_field(v_x2_2470, 2);
    heff_take_n(v_x2_2470, 7ULL, 3);
    V v_m_2474 = heff_tr(heff_call(v_go_2469, 1, (V[]){v_b_2473}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam11, 1, 3, (V[]){v_m_2474, v_tg_2471, v_vs_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args) {
  V v_n_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_arms_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_n_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_n_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    V v_go_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2479 = (g_heff_2ecompile_2ecallarity_2etraverseS(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam10, 1, 1, (V[]){v_go_2469}), v_arms_2463));
    V v_x2_2480 = heff_tr(heff_call(v_m_2479, 1, (V[]){v_n_2468}));
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_MkPair: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      V v_n_2482 = heff_field(v_x2_2480, 1);
      heff_take_n(v_x2_2480, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2467, v_x_2481}), v_n_2482});
    }
    default: return heff_nomatch(v_x2_2480);
    }
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args) {
  V v_n_2484 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_2484});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args) {
  V v_n_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_p_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_n_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_n_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2485, v_x_2491}), v_n_2492});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args) {
  V v_n_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_g_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_n_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_n_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2493, v_x_2499}), v_n_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args) {
  V v_n_24102 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24102});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args) {
  V v_n_24104 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24104});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args) {
  V v_n_24106 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24106});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args) {
  V v_n_24108 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24108});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args) {
  V v_n_24111 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24111});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args) {
  V v_n_24113 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24113});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args) {
  V v_n_24114 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24114});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam22(V self, V *args) {
  V v_n_24117 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_n_24117});
}