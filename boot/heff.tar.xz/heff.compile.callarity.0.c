// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_dirty 296951788
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_tables 1065764240
#define LBL_uses 10094739
#define LBL_vars 10107635
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_vars__globals__dirty[] = {LBL_vars, LBL_globals, LBL_dirty};
V g_heff_2ecompile_2ecallarity_2edropC(V, V);
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edropC_clo;
V g_heff_2ecompile_2ecallarity_2eexpandApp(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArg(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo;
V g_heff_2ecompile_2ecallarity_2eexpandGo(V, V);
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo;
V g_heff_2ecompile_2ecallarity_2eextend(V, V);
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_clo;
V g_heff_2ecompile_2ecallarity_2eextend_24dps(V, V, V);
V g_heff_2ecompile_2ecallarity_2eextend_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_24dps_clo;
V g_heff_2ecompile_2ecallarity_2efreshMany(V, V);
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V, V);
V g_heff_2ecompile_2ecallarity_2ehanded(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ehanded_clo;
V g_heff_2ecompile_2ecallarity_2eisNth(V, V, V);
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eisNth_clo;
V g_heff_2ecompile_2ecallarity_2eknownAdd(V, V, V);
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo;
V g_heff_2ecompile_2ecallarity_2enthOr(V, V, V);
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enthOr_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars(V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V, V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseTo_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo(V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2etraverse_24s740446701x774604387(V, V);
V g_prelude_2etraverse_24s740446701x774604387_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s740446701x774604387_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2efreshMany_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2efreshMany(V v_k_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_k_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2efreshMany(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edropC_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edropC(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2eisNth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eisNth_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eisNth(V v_i_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return heff_strEq_lent(v_x_241, v_y_243, 0);
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_x_241;
      V t_2 = v_ys_244;
      v_i_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eisNth(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ezipTo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2ezipTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2emap_2eempty_get());
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x1_240, 0);
    V v_ys_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_dup(g_std_2emap_2eempty_get());
    }
    case TAG_Cons: {
      V v_z_244 = heff_field(v_x2_241, 0);
      V v_zs_245 = heff_field(v_x2_241, 1);
      V v_t_246 = (g_heff_2ecompile_2ecallarity_2ezipTo(v_ys_243, v_zs_245));
      return (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_246, heff_dup(v_y_242), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_z_244)})));
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2ezipTo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ehanded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ehanded_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2ehanded(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x_244, V v_n_245) {
top: ;
  V v_t_247;
  if (heff_strEq_c(heff_dup(v_h_242), heff_dup(heff_rfield(v_here_241, 0)))) {
    v_t_247 = ({ V a_0 = heff_dup(v_j_243); V a_1 = v_x_244; V b_2 = heff_get_n(v_here_241, 1, 4); V r_ = (g_heff_2ecompile_2ecallarity_2eisNth(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  } else {
    heff_drop_rec(v_here_241, 4);
    v_t_247 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_243);
    heff_drop(v_x_244);
    heff_drop(v_t_247);
    return v_n_245;
  } else {
    heff_drop(v_t_247);
    HeffT2 v_t_248 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      V v_k_2413;
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_ps_2412 = v_field_2410;
        v_k_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_243; V a_2 = v_ps_2412; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2412); r_; });
      } else {
        heff_drop(v_j_243);
        heff_drop(v_field_2410);
        v_k_2413 = MK_INT(0LL);
      }
      HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_n_245, 0), v_x_244));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_k0_2418 = v_field_2416;
          if (heff_intLt_c_lent(v_k_2413, v_k0_2418, 2)) {
            V v_t_2420 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_n_245, 0), v_x_244, v_k_2413));
            return ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_n_245, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          } else {
            heff_drop(v_x_244);
            heff_drop(v_k_2413);
            return v_n_245;
          }
        } else {
          heff_drop(v_x_244);
          heff_drop(v_k_2413);
          heff_drop(v_field_2416);
          return v_n_245;
        }
      }
    }
  }
}
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2ehanded(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_as_243;
      V t_1 = v_rest_241;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    case TAG_ELam: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2411 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    case TAG_EApp: {
      V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2415 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    case TAG_ELet: {
      V v_cell_2419 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2420 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2419)));
      heff_drop(v_u_2420);
      return v_cell_2419;
    }
    case TAG_ERecord: {
      V v_cell_2423 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2424 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2423)));
      heff_drop(v_u_2424);
      return v_cell_2423;
    }
    case TAG_EProj: {
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2430 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2429)));
      heff_drop(v_u_2430);
      return v_cell_2429;
    }
    case TAG_ETag: {
      V v_cell_2434 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2435 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2434)));
      heff_drop(v_u_2435);
      return v_cell_2434;
    }
    case TAG_EMatch: {
      V v_cell_2438 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2439 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2438)));
      heff_drop(v_u_2439);
      return v_cell_2438;
    }
    case TAG_EPrim: {
      V v_cell_2441 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2442 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2441)));
      heff_drop(v_u_2442);
      return v_cell_2441;
    }
    case TAG_EPrimCall: {
      V v_cell_2445 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2446 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2445)));
      heff_drop(v_u_2446);
      return v_cell_2445;
    }
    case TAG_ECall: {
      V v_cell_2449 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2450 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2449)));
      heff_drop(v_u_2450);
      return v_cell_2449;
    }
    case TAG_EInt: {
      V v_cell_2452 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2453 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2452)));
      heff_drop(v_u_2453);
      return v_cell_2452;
    }
    case TAG_EFloat: {
      V v_cell_2455 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2456 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2455)));
      heff_drop(v_u_2456);
      return v_cell_2455;
    }
    case TAG_EStr: {
      V v_cell_2458 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2459 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2458)));
      heff_drop(v_u_2459);
      return v_cell_2458;
    }
    case TAG_EBytes: {
      V v_cell_2461 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2462 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2461)));
      heff_drop(v_u_2462);
      return v_cell_2461;
    }
    case TAG_EFixed: {
      V v_cell_2465 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2466 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2465)));
      heff_drop(v_u_2466);
      return v_cell_2465;
    }
    case TAG_EFloat32: {
      V v_cell_2468 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2469 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2468)));
      heff_drop(v_u_2469);
      return v_cell_2468;
    }
    case TAG_EAbandon: {
      V v_cell_2470 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2471 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2470)));
      heff_drop(v_u_2471);
      return v_cell_2470;
    }
    case TAG_EFix: {
      V v_cell_2474 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2475 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_as_243, v_rest_241, heff_dup(v_cell_2474)));
      heff_drop(v_u_2475);
      return v_cell_2474;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2epushNonVars(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_EVar: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_d_242;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2412 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2411;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2415;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_cell_2420 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2421 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2420));
      heff_drop(v_u_2421);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2420;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_cell_2424 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2425 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2424));
      heff_drop(v_u_2425);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2424;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_cell_2430 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2431 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2430));
      heff_drop(v_u_2431);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2430;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_cell_2435 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2436 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2435));
      heff_drop(v_u_2436);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2435;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_cell_2439 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2440 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2439));
      heff_drop(v_u_2440);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2439;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      V v_cell_2442 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2443 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2442));
      heff_drop(v_u_2443);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2442;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_cell_2446 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2447 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2446));
      heff_drop(v_u_2447);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2446;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_cell_2450 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2451 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2450));
      heff_drop(v_u_2451);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2450;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      V v_cell_2453 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2454 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2453));
      heff_drop(v_u_2454);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2453;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      V v_cell_2456 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2457 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2456));
      heff_drop(v_u_2457);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2456;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      V v_cell_2459 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2460 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2459));
      heff_drop(v_u_2460);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2459;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      V v_cell_2462 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2463 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2462));
      heff_drop(v_u_2463);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2462;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      V v_cell_2466 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2467 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2466));
      heff_drop(v_u_2467);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2466;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      V v_cell_2469 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2470 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2469));
      heff_drop(v_u_2470);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2469;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      V v_cell_2471 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2472 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2471));
      heff_drop(v_u_2472);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2471;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      V v_cell_2475 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2476 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2475));
      heff_drop(v_u_2476);
      V t_0 = v_as_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2475;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eknownAdd_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eknownAdd(V v_k_240, V v_d_241, V v_n_242) {
top: ;
  V v_t_243 = heff_take_field(v_d_241, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_t_248 = heff_get_n(heff_get_n(v_k_240, 0, 2), 0, 1);
    V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eknownAdd_lam0, 1, 1, (V[]){heff_dup(v_n_242)}), v_xs_246));
    V v_t_2417 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_248, heff_get_n(v_d_241, 0, 3), v_t_2416));
    return heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){v_t_2417}), heff_get_n(v_n_242, 1, 3)});
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EStr: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EBytes: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_243, 0ULL, 1);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_d_241, 3);
    return ({ V rv_1 = heff_get_n(v_n_242, 1, 3); V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eknownAdd(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_n_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_n_242, 0, 3); V a_1 = v_x_249; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_249); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_k_2414 = v_field_2412;
      if (heff_intLe_c_lent(MK_INT(1000000LL), v_k_2414, 1)) {
        heff_drop(v_k_2414);
        return MK_INT(0LL);
      } else {
        return v_k_2414;
      }
    } else {
      heff_drop(v_field_2412);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextend_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eextend(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return v_e_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      V v_t_245 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_245});
    }
    case TAG_EGlobal: {
      V v_t_247 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_247});
    }
    case TAG_ELam: {
      V v_ys_248 = heff_field(v_e_241, 0);
      V v_b_249 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      V v_y_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_y_2411, v_x_2410)) {
        V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2414 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2413, heff_dup(v_ys_248)));
        V v_m_2415 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2416 = (g_std_2emap_2esize(v_m_2415));
        V v_t_2418;
        if (heff_intEq_c(v_t_2416, MK_INT(0LL))) {
          heff_drop(v_m_2415);
          v_t_2418 = v_b_249;
        } else {
          v_t_2418 = ({ V a_0 = v_m_2415; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2415); r_; });
        }
        return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2414, v_t_2418});
      } else {
        heff_drop_cell(v_ru_24e_241_24ELam, 2);
        V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
        V v_t_2420 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2419, heff_dup(v_zs_240)));
        V v_m_2421 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2422 = (g_std_2emap_2esize(v_m_2421));
        V v_t_2424;
        if (heff_intEq_c(v_t_2422, MK_INT(0LL))) {
          heff_drop(v_m_2421);
          v_t_2424 = v_b_249;
        } else {
          v_t_2424 = ({ V a_0 = v_m_2421; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2421); r_; });
        }
        V t_0 = v_t_2420;
        V t_1 = v_t_2424;
        v_zs_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2425 = heff_field(v_e_241, 0);
      V v_as_2426 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_t_2427 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2428 = (g_prelude_2e_2b_2b(v_as_2426, v_t_2427));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_f_2425, v_t_2428});
    }
    case TAG_ELet: {
      V v_x_2429 = heff_field(v_e_241, 0);
      V v_a_2430 = heff_field(v_e_241, 1);
      V v_b_2431 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2432 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2429, v_a_2430, heff_hole()});
      V v_u_2433 = (g_heff_2ecompile_2ecallarity_2eextend_24dps(v_zs_240, v_b_2431, heff_dup(v_cell_2432)));
      heff_drop(v_u_2433);
      return v_cell_2432;
    }
    case TAG_ERecord: {
      V v_t_2436 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2436});
    }
    case TAG_EProj: {
      V v_t_2441 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2441});
    }
    case TAG_ETag: {
      V v_t_2445 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2445});
    }
    case TAG_EMatch: {
      V v_s_2446 = heff_field(v_e_241, 0);
      V v_arms_2447 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_f_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextend_clo), 1, (V[]){v_zs_240}));
      V v_t_2454 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eextend_lam0, 1, 1, (V[]){v_f_2448}), v_arms_2447));
      return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2446, v_t_2454});
    }
    case TAG_EPrim: {
      V v_t_2456 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2456});
    }
    case TAG_EPrimCall: {
      V v_t_2459 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2459});
    }
    case TAG_ECall: {
      V v_t_2462 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2462});
    }
    case TAG_EInt: {
      V v_t_2464 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2464});
    }
    case TAG_EFloat: {
      V v_t_2466 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2466});
    }
    case TAG_EStr: {
      V v_t_2468 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2468});
    }
    case TAG_EBytes: {
      V v_t_2470 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2470});
    }
    case TAG_EFixed: {
      V v_t_2473 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2473});
    }
    case TAG_EFloat32: {
      V v_t_2475 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2475});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return NTAG(TAG_EAbandon);
    }
    case TAG_EFix: {
      V v_t_2478 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2478});
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextend(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args) {
  V v_x2_2449 = args[0];
  V v_f_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkArm: {
    V v_tg_2450 = heff_field(v_x2_2449, 0);
    V v_vs_2451 = heff_field(v_x2_2449, 1);
    V v_b_2452 = heff_field(v_x2_2449, 2);
    V v_ru_24x2_2449_24MkArm = heff_take_reuse_n(v_x2_2449, 7ULL, 3);
    V v_t_2453 = heff_tr(heff_call(v_f_2448, 1, (V[]){v_b_2452}));
    return heff_tag_at_n(v_ru_24x2_2449_24MkArm, TAG_MkArm, 3, (V[]){v_tg_2450, v_vs_2451, v_t_2453});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eextend_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextend_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eextend_24dps(V v_zs_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      V v_t_246 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_246}));
    }
    case TAG_EGlobal: {
      V v_t_248 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_248}));
    }
    case TAG_ELam: {
      V v_ys_249 = heff_field(v_e_241, 0);
      V v_b_2410 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 3ULL, 2);
      V v_x_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_249));
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2415 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2414, heff_dup(v_ys_249)));
        V v_m_2416 = ({ V a_0 = v_ys_249; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_249); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2417 = (g_std_2emap_2esize(v_m_2416));
        V v_t_2419;
        if (heff_intEq_c(v_t_2417, MK_INT(0LL))) {
          heff_drop(v_m_2416);
          v_t_2419 = v_b_2410;
        } else {
          v_t_2419 = ({ V a_0 = v_m_2416; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2416); r_; });
        }
        return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, v_t_2419}));
      } else {
        V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_249));
        V v_t_2421 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2420, heff_dup(v_zs_240)));
        V v_m_2422 = ({ V a_0 = v_ys_249; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_249); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2423 = (g_std_2emap_2esize(v_m_2422));
        V v_t_2425;
        if (heff_intEq_c(v_t_2423, MK_INT(0LL))) {
          heff_drop(v_m_2422);
          v_t_2425 = v_b_2410;
        } else {
          v_t_2425 = ({ V a_0 = v_m_2422; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2422); r_; });
        }
        V t_0 = v_t_2421;
        V t_1 = v_t_2425;
        V t_2 = v_d_242;
        v_zs_240 = t_0;
        v_e_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2426 = heff_field(v_e_241, 0);
      V v_as_2427 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 3ULL, 2);
      V v_t_2428 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2429 = (g_prelude_2e_2b_2b(v_as_2427, v_t_2428));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_f_2426, v_t_2429}));
    }
    case TAG_ELet: {
      V v_x_2430 = heff_field(v_e_241, 0);
      V v_a_2431 = heff_field(v_e_241, 1);
      V v_b_2432 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2433 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2430, v_a_2431, heff_hole()});
      V v_u_2434 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2433));
      heff_drop(v_u_2434);
      V t_0 = v_zs_240;
      V t_1 = v_b_2432;
      V t_2 = v_cell_2433;
      v_zs_240 = t_0;
      v_e_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_t_2437 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2437}));
    }
    case TAG_EProj: {
      V v_t_2442 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2442}));
    }
    case TAG_ETag: {
      V v_t_2446 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2446}));
    }
    case TAG_EMatch: {
      V v_s_2447 = heff_field(v_e_241, 0);
      V v_arms_2448 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 3ULL, 2);
      V v_f_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextend_clo), 1, (V[]){v_zs_240}));
      V v_t_2455 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0, 1, 1, (V[]){v_f_2449}), v_arms_2448));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2447, v_t_2455}));
    }
    case TAG_EPrim: {
      V v_t_2457 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2457}));
    }
    case TAG_EPrimCall: {
      V v_t_2460 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2460}));
    }
    case TAG_ECall: {
      V v_t_2463 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2463}));
    }
    case TAG_EInt: {
      V v_t_2465 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2465}));
    }
    case TAG_EFloat: {
      V v_t_2467 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2467}));
    }
    case TAG_EStr: {
      V v_t_2469 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2469}));
    }
    case TAG_EBytes: {
      V v_t_2471 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2471}));
    }
    case TAG_EFixed: {
      V v_t_2474 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2474}));
    }
    case TAG_EFloat32: {
      V v_t_2476 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2476}));
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return heff_setField(v_d_242, MK_INT(2LL), NTAG(TAG_EAbandon));
    }
    case TAG_EFix: {
      V v_t_2479 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2479}));
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextend_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0(V self, V *args) {
  V v_x2_2450 = args[0];
  V v_f_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkArm: {
    V v_tg_2451 = heff_field(v_x2_2450, 0);
    V v_vs_2452 = heff_field(v_x2_2450, 1);
    V v_b_2453 = heff_field(v_x2_2450, 2);
    V v_ru_24x2_2450_24MkArm = heff_take_reuse_n(v_x2_2450, 7ULL, 3);
    V v_t_2454 = heff_tr(heff_call(v_f_2449, 1, (V[]){v_b_2453}));
    return heff_tag_at_n(v_ru_24x2_2450_24MkArm, TAG_MkArm, 3, (V[]){v_tg_2451, v_vs_2452, v_t_2454});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseTo_24cpr(V v_d_240, V v_xs_241, V v_b_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    return ((HeffT2){{v_d_240, v_z_244}});
  }
  case TAG_Just: {
    V v_m_245 = heff_field(v_x4_243, 0);
    V v_y_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    if (heff_intLt_c_lent(v_y_246, v_m_245, 1)) {
      V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_249 = heff_intSub(heff_dup(v_m_245), v_t_248);
      HeffT2 v_t_2410 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_249, v_z_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_n_2414 = v_field_2412;
        V v_t_2415 = (g_prelude_2e_2b_2b(v_xs_241, heff_dup(v_x_2413)));
        V v_t_2416 = (g_heff_2ecompile_2ecallarity_2eextend(v_x_2413, v_b_242));
        V v_body_2417 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, v_t_2416});
        V v_f_2418 = ({ V rv_2 = v_body_2417; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        return ((HeffT2){{v_f_2418, v_n_2414}});
      }
    } else {
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      return ((HeffT2){{v_d_240, v_z_244}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V v_gl_240, V v_d_241, V v_z_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    V v_ru_24t_243_24EVar = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_u_249 = v_field_247;
        v_t_2410 = heff_tag_at_n(v_ru_24t_243_24EVar, TAG_Just, 1, (V[]){heff_get_n(v_u_249, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EVar, 1);
        heff_drop(v_field_247);
        v_t_2410 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2416;
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        V v_u_2415 = v_field_2413;
        v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2415, 1, 3)});
      } else {
        heff_drop(v_field_2413);
        v_t_2416 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2410; V a_2 = v_t_2416; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); heff_drop(v_t_2416); r_; });
  }
  case TAG_EGlobal: {
    V v_ru_24t_243_24EGlobal = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_2418 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2423;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_u_2422 = v_field_2420;
        v_t_2423 = heff_tag_at_n(v_ru_24t_243_24EGlobal, TAG_Just, 1, (V[]){heff_get_n(v_u_2422, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EGlobal, 1);
        heff_drop(v_field_2420);
        v_t_2423 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2424 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2429;
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_u_2428 = v_field_2426;
        v_t_2429 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2428, 1, 3)});
      } else {
        heff_drop(v_field_2426);
        v_t_2429 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2423; V a_2 = v_t_2429; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2423); heff_drop(v_t_2429); r_; });
  }
  case TAG_ELam: {
    V v_xs_2430 = heff_field(v_t_243, 0);
    V v_b_2431 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    HeffT2 v_t_2432 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2437;
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((v_tag_2433 == ((int64_t)0ULL))) {
        V v_u_2436 = v_field_2434;
        v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2436, 0, 3)});
      } else {
        heff_drop(v_field_2434);
        v_t_2437 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_xs_2430; V a_2 = v_b_2431; V a_3 = v_t_2437; V a_4 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseTo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2437); r_; });
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_2440 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2445;
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        V v_u_2444 = v_field_2442;
        v_t_2445 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2444, 0, 3)});
      } else {
        heff_drop(v_field_2442);
        v_t_2445 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2446 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2451;
    {
      V v_field_2448 = v_t_2446.f[1];
      int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
      if ((v_tag_2447 == ((int64_t)0ULL))) {
        V v_u_2450 = v_field_2448;
        v_t_2451 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2450, 1, 3)});
      } else {
        heff_drop(v_field_2448);
        v_t_2451 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2445; V a_2 = v_t_2451; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2445); heff_drop(v_t_2451); r_; });
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    HeffT2 v_t_2455 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2460;
    {
      V v_field_2457 = v_t_2455.f[1];
      int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
      if ((v_tag_2456 == ((int64_t)0ULL))) {
        V v_u_2459 = v_field_2457;
        v_t_2460 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2459, 0, 3)});
      } else {
        heff_drop(v_field_2457);
        v_t_2460 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2461 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2466;
    {
      V v_field_2463 = v_t_2461.f[1];
      int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
      if ((v_tag_2462 == ((int64_t)0ULL))) {
        V v_u_2465 = v_field_2463;
        v_t_2466 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2465, 1, 3)});
      } else {
        heff_drop(v_field_2463);
        v_t_2466 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2460; V a_2 = v_t_2466; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2460); heff_drop(v_t_2466); r_; });
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_2469 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2474;
    {
      V v_field_2471 = v_t_2469.f[1];
      int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
      if ((v_tag_2470 == ((int64_t)0ULL))) {
        V v_u_2473 = v_field_2471;
        v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2473, 0, 3)});
      } else {
        heff_drop(v_field_2471);
        v_t_2474 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2475 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2480;
    {
      V v_field_2477 = v_t_2475.f[1];
      int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
      if ((v_tag_2476 == ((int64_t)0ULL))) {
        V v_u_2479 = v_field_2477;
        v_t_2480 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2479, 1, 3)});
      } else {
        heff_drop(v_field_2477);
        v_t_2480 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2474; V a_2 = v_t_2480; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2474); heff_drop(v_t_2480); r_; });
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    HeffT2 v_t_2485 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2490;
    {
      V v_field_2487 = v_t_2485.f[1];
      int64_t v_tag_2486 = ((int64_t)v_t_2485.f[0]);
      if ((v_tag_2486 == ((int64_t)0ULL))) {
        V v_u_2489 = v_field_2487;
        v_t_2490 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2489, 0, 3)});
      } else {
        heff_drop(v_field_2487);
        v_t_2490 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2491 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2496;
    {
      V v_field_2493 = v_t_2491.f[1];
      int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
      if ((v_tag_2492 == ((int64_t)0ULL))) {
        V v_u_2495 = v_field_2493;
        v_t_2496 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2495, 1, 3)});
      } else {
        heff_drop(v_field_2493);
        v_t_2496 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2490; V a_2 = v_t_2496; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2490); heff_drop(v_t_2496); r_; });
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    HeffT2 v_t_24100 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24105;
    {
      V v_field_24102 = v_t_24100.f[1];
      int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
      if ((v_tag_24101 == ((int64_t)0ULL))) {
        V v_u_24104 = v_field_24102;
        v_t_24105 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24104, 0, 3)});
      } else {
        heff_drop(v_field_24102);
        v_t_24105 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24106 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24111;
    {
      V v_field_24108 = v_t_24106.f[1];
      int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
      if ((v_tag_24107 == ((int64_t)0ULL))) {
        V v_u_24110 = v_field_24108;
        v_t_24111 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24110, 1, 3)});
      } else {
        heff_drop(v_field_24108);
        v_t_24111 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24105; V a_2 = v_t_24111; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24105); heff_drop(v_t_24111); r_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24114 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24119;
    {
      V v_field_24116 = v_t_24114.f[1];
      int64_t v_tag_24115 = ((int64_t)v_t_24114.f[0]);
      if ((v_tag_24115 == ((int64_t)0ULL))) {
        V v_u_24118 = v_field_24116;
        v_t_24119 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24118, 0, 3)});
      } else {
        heff_drop(v_field_24116);
        v_t_24119 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24120 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24125;
    {
      V v_field_24122 = v_t_24120.f[1];
      int64_t v_tag_24121 = ((int64_t)v_t_24120.f[0]);
      if ((v_tag_24121 == ((int64_t)0ULL))) {
        V v_u_24124 = v_field_24122;
        v_t_24125 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24124, 1, 3)});
      } else {
        heff_drop(v_field_24122);
        v_t_24125 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24119; V a_2 = v_t_24125; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24119); heff_drop(v_t_24125); r_; });
  }
  case TAG_EPrim: {
    V v_ru_24t_243_24EPrim = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24127 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24132;
    {
      V v_field_24129 = v_t_24127.f[1];
      int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
      if ((v_tag_24128 == ((int64_t)0ULL))) {
        V v_u_24131 = v_field_24129;
        v_t_24132 = heff_tag_at_n(v_ru_24t_243_24EPrim, TAG_Just, 1, (V[]){heff_get_n(v_u_24131, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EPrim, 1);
        heff_drop(v_field_24129);
        v_t_24132 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24133 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24138;
    {
      V v_field_24135 = v_t_24133.f[1];
      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
      if ((v_tag_24134 == ((int64_t)0ULL))) {
        V v_u_24137 = v_field_24135;
        v_t_24138 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24137, 1, 3)});
      } else {
        heff_drop(v_field_24135);
        v_t_24138 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24132; V a_2 = v_t_24138; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24132); heff_drop(v_t_24138); r_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24141 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24146;
    {
      V v_field_24143 = v_t_24141.f[1];
      int64_t v_tag_24142 = ((int64_t)v_t_24141.f[0]);
      if ((v_tag_24142 == ((int64_t)0ULL))) {
        V v_u_24145 = v_field_24143;
        v_t_24146 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24145, 0, 3)});
      } else {
        heff_drop(v_field_24143);
        v_t_24146 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24147 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24152;
    {
      V v_field_24149 = v_t_24147.f[1];
      int64_t v_tag_24148 = ((int64_t)v_t_24147.f[0]);
      if ((v_tag_24148 == ((int64_t)0ULL))) {
        V v_u_24151 = v_field_24149;
        v_t_24152 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24151, 1, 3)});
      } else {
        heff_drop(v_field_24149);
        v_t_24152 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24146; V a_2 = v_t_24152; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24146); heff_drop(v_t_24152); r_; });
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24155 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24160;
    {
      V v_field_24157 = v_t_24155.f[1];
      int64_t v_tag_24156 = ((int64_t)v_t_24155.f[0]);
      if ((v_tag_24156 == ((int64_t)0ULL))) {
        V v_u_24159 = v_field_24157;
        v_t_24160 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24159, 0, 3)});
      } else {
        heff_drop(v_field_24157);
        v_t_24160 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24161 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24166;
    {
      V v_field_24163 = v_t_24161.f[1];
      int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
      if ((v_tag_24162 == ((int64_t)0ULL))) {
        V v_u_24165 = v_field_24163;
        v_t_24166 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24165, 1, 3)});
      } else {
        heff_drop(v_field_24163);
        v_t_24166 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24160; V a_2 = v_t_24166; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24160); heff_drop(v_t_24166); r_; });
  }
  case TAG_EInt: {
    V v_ru_24t_243_24EInt = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24168 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24173;
    {
      V v_field_24170 = v_t_24168.f[1];
      int64_t v_tag_24169 = ((int64_t)v_t_24168.f[0]);
      if ((v_tag_24169 == ((int64_t)0ULL))) {
        V v_u_24172 = v_field_24170;
        v_t_24173 = heff_tag_at_n(v_ru_24t_243_24EInt, TAG_Just, 1, (V[]){heff_get_n(v_u_24172, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EInt, 1);
        heff_drop(v_field_24170);
        v_t_24173 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24174 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24179;
    {
      V v_field_24176 = v_t_24174.f[1];
      int64_t v_tag_24175 = ((int64_t)v_t_24174.f[0]);
      if ((v_tag_24175 == ((int64_t)0ULL))) {
        V v_u_24178 = v_field_24176;
        v_t_24179 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24178, 1, 3)});
      } else {
        heff_drop(v_field_24176);
        v_t_24179 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24173; V a_2 = v_t_24179; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24173); heff_drop(v_t_24179); r_; });
  }
  case TAG_EFloat: {
    V v_ru_24t_243_24EFloat = heff_take_reuse_na(v_t_243, 0ULL, 1);
    HeffT2 v_t_24181 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24186;
    {
      V v_field_24183 = v_t_24181.f[1];
      int64_t v_tag_24182 = ((int64_t)v_t_24181.f[0]);
      if ((v_tag_24182 == ((int64_t)0ULL))) {
        V v_u_24185 = v_field_24183;
        v_t_24186 = heff_tag_at_n(v_ru_24t_243_24EFloat, TAG_Just, 1, (V[]){heff_get_n(v_u_24185, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EFloat, 1);
        heff_drop(v_field_24183);
        v_t_24186 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24187 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24192;
    {
      V v_field_24189 = v_t_24187.f[1];
      int64_t v_tag_24188 = ((int64_t)v_t_24187.f[0]);
      if ((v_tag_24188 == ((int64_t)0ULL))) {
        V v_u_24191 = v_field_24189;
        v_t_24192 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24191, 1, 3)});
      } else {
        heff_drop(v_field_24189);
        v_t_24192 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24186; V a_2 = v_t_24192; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24186); heff_drop(v_t_24192); r_; });
  }
  case TAG_EStr: {
    V v_ru_24t_243_24EStr = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24194 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24199;
    {
      V v_field_24196 = v_t_24194.f[1];
      int64_t v_tag_24195 = ((int64_t)v_t_24194.f[0]);
      if ((v_tag_24195 == ((int64_t)0ULL))) {
        V v_u_24198 = v_field_24196;
        v_t_24199 = heff_tag_at_n(v_ru_24t_243_24EStr, TAG_Just, 1, (V[]){heff_get_n(v_u_24198, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EStr, 1);
        heff_drop(v_field_24196);
        v_t_24199 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24200 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24205;
    {
      V v_field_24202 = v_t_24200.f[1];
      int64_t v_tag_24201 = ((int64_t)v_t_24200.f[0]);
      if ((v_tag_24201 == ((int64_t)0ULL))) {
        V v_u_24204 = v_field_24202;
        v_t_24205 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24204, 1, 3)});
      } else {
        heff_drop(v_field_24202);
        v_t_24205 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24199; V a_2 = v_t_24205; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24199); heff_drop(v_t_24205); r_; });
  }
  case TAG_EBytes: {
    V v_ru_24t_243_24EBytes = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24207 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24212;
    {
      V v_field_24209 = v_t_24207.f[1];
      int64_t v_tag_24208 = ((int64_t)v_t_24207.f[0]);
      if ((v_tag_24208 == ((int64_t)0ULL))) {
        V v_u_24211 = v_field_24209;
        v_t_24212 = heff_tag_at_n(v_ru_24t_243_24EBytes, TAG_Just, 1, (V[]){heff_get_n(v_u_24211, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EBytes, 1);
        heff_drop(v_field_24209);
        v_t_24212 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24213 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24218;
    {
      V v_field_24215 = v_t_24213.f[1];
      int64_t v_tag_24214 = ((int64_t)v_t_24213.f[0]);
      if ((v_tag_24214 == ((int64_t)0ULL))) {
        V v_u_24217 = v_field_24215;
        v_t_24218 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24217, 1, 3)});
      } else {
        heff_drop(v_field_24215);
        v_t_24218 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24212; V a_2 = v_t_24218; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24212); heff_drop(v_t_24218); r_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24221 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24226;
    {
      V v_field_24223 = v_t_24221.f[1];
      int64_t v_tag_24222 = ((int64_t)v_t_24221.f[0]);
      if ((v_tag_24222 == ((int64_t)0ULL))) {
        V v_u_24225 = v_field_24223;
        v_t_24226 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24225, 0, 3)});
      } else {
        heff_drop(v_field_24223);
        v_t_24226 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24227 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24232;
    {
      V v_field_24229 = v_t_24227.f[1];
      int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
      if ((v_tag_24228 == ((int64_t)0ULL))) {
        V v_u_24231 = v_field_24229;
        v_t_24232 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24231, 1, 3)});
      } else {
        heff_drop(v_field_24229);
        v_t_24232 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24226; V a_2 = v_t_24232; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24226); heff_drop(v_t_24232); r_; });
  }
  case TAG_EFloat32: {
    V v_ru_24t_243_24EFloat32 = heff_take_reuse_na(v_t_243, 0ULL, 1);
    HeffT2 v_t_24234 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24239;
    {
      V v_field_24236 = v_t_24234.f[1];
      int64_t v_tag_24235 = ((int64_t)v_t_24234.f[0]);
      if ((v_tag_24235 == ((int64_t)0ULL))) {
        V v_u_24238 = v_field_24236;
        v_t_24239 = heff_tag_at_n(v_ru_24t_243_24EFloat32, TAG_Just, 1, (V[]){heff_get_n(v_u_24238, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EFloat32, 1);
        heff_drop(v_field_24236);
        v_t_24239 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24240 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24245;
    {
      V v_field_24242 = v_t_24240.f[1];
      int64_t v_tag_24241 = ((int64_t)v_t_24240.f[0]);
      if ((v_tag_24241 == ((int64_t)0ULL))) {
        V v_u_24244 = v_field_24242;
        v_t_24245 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24244, 1, 3)});
      } else {
        heff_drop(v_field_24242);
        v_t_24245 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24239; V a_2 = v_t_24245; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24239); heff_drop(v_t_24245); r_; });
  }
  case TAG_EAbandon: {
    HeffT2 v_t_24246 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24251;
    {
      V v_field_24248 = v_t_24246.f[1];
      int64_t v_tag_24247 = ((int64_t)v_t_24246.f[0]);
      if ((v_tag_24247 == ((int64_t)0ULL))) {
        V v_u_24250 = v_field_24248;
        v_t_24251 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24250, 0, 3)});
      } else {
        heff_drop(v_field_24248);
        v_t_24251 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24252 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24257;
    {
      V v_field_24254 = v_t_24252.f[1];
      int64_t v_tag_24253 = ((int64_t)v_t_24252.f[0]);
      if ((v_tag_24253 == ((int64_t)0ULL))) {
        V v_u_24256 = v_field_24254;
        v_t_24257 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24256, 1, 3)});
      } else {
        heff_drop(v_field_24254);
        v_t_24257 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24251; V a_2 = v_t_24257; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24251); heff_drop(v_t_24257); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24260 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24265;
    {
      V v_field_24262 = v_t_24260.f[1];
      int64_t v_tag_24261 = ((int64_t)v_t_24260.f[0]);
      if ((v_tag_24261 == ((int64_t)0ULL))) {
        V v_u_24264 = v_field_24262;
        v_t_24265 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24264, 0, 3)});
      } else {
        heff_drop(v_field_24262);
        v_t_24265 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24266 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24271;
    {
      V v_field_24268 = v_t_24266.f[1];
      int64_t v_tag_24267 = ((int64_t)v_t_24266.f[0]);
      if ((v_tag_24267 == ((int64_t)0ULL))) {
        V v_u_24270 = v_field_24268;
        v_t_24271 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24270, 1, 3)});
      } else {
        heff_drop(v_field_24268);
        v_t_24271 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24265; V a_2 = v_t_24271; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24265); heff_drop(v_t_24271); r_; });
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam20(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArg_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArg(V v_t_240, V v_h_241, V v_j_242, V v_a_243) {
top: ;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam0, 1, 1, (V[]){v_a_243});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam1, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELam: {
    V v_ys_248 = heff_field(v_a_243, 0);
    V v_b_249 = heff_field(v_a_243, 1);
    heff_take_n(v_a_243, 3ULL, 2);
    HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_t_240, 0), v_h_241));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_x_2415;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_ps_2414 = v_field_2412;
        v_x_2415 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_242); V a_2 = v_ps_2414; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2414); r_; });
      } else {
        heff_drop(v_field_2412);
        v_x_2415 = MK_INT(0LL);
      }
      V v_y_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      if (heff_intLt_c(v_y_2416, v_x_2415)) {
        HeffT2 v_t_2418 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2423;
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            V v_ps_2422 = v_field_2420;
            v_t_2423 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_242; V a_2 = v_ps_2422; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2422); r_; });
          } else {
            heff_drop(v_j_242);
            heff_drop(v_field_2420);
            v_t_2423 = MK_INT(0LL);
          }
        }
        V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
        V v_t_2425 = heff_intSub(v_t_2423, v_t_2424);
        return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam2, 1, 3, (V[]){v_t_2425, v_ys_248, v_b_249});
      } else {
        heff_drop_rec(v_t_240, 1);
        heff_drop(v_j_242);
        return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam3, 1, 2, (V[]){v_ys_248, v_b_249});
      }
    }
  }
  case TAG_EApp: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam4, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELet: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam5, 1, 1, (V[]){v_a_243});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam6, 1, 1, (V[]){v_a_243});
  }
  case TAG_EProj: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam7, 1, 1, (V[]){v_a_243});
  }
  case TAG_ETag: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam8, 1, 1, (V[]){v_a_243});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam9, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam10, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam11, 1, 1, (V[]){v_a_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam12, 1, 1, (V[]){v_a_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam13, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam14, 1, 1, (V[]){v_a_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam15, 1, 1, (V[]){v_a_243});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam16, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam17, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam18, 1, 1, (V[]){v_a_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam19, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam20, 1, 1, (V[]){v_a_243});
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2eexpandArg(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_247});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args) {
  V v_n_2426 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_ys_248 = heff_env(self)[1];
  V v_b_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2427 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_2425, v_n_2426));
  {
    V v_field_2428 = v_t_2427.f[0];
    V v_field_2429 = v_t_2427.f[1];
    V v_x_2430 = v_field_2428;
    V v_n_2431 = v_field_2429;
    V v_t_2432 = (g_prelude_2e_2b_2b(v_ys_248, heff_dup(v_x_2430)));
    V v_t_2433 = (g_heff_2ecompile_2ecallarity_2eextend(v_x_2430, v_b_249));
    V v_x_2434 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2432, v_t_2433});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_n_2431});
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args) {
  V v_n_2435 = args[0];
  V v_ys_248 = heff_env(self)[0];
  V v_b_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_ys_248, v_b_249}), v_n_2435});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args) {
  V v_n_2438 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2438});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args) {
  V v_n_2442 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2442});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args) {
  V v_n_2445 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2445});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args) {
  V v_n_2450 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2450});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args) {
  V v_n_2454 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2454});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args) {
  V v_n_2457 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2457});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args) {
  V v_n_2459 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2459});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args) {
  V v_n_2462 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2462});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args) {
  V v_n_2465 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2465});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args) {
  V v_n_2467 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2467});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args) {
  V v_n_2469 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2469});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args) {
  V v_n_2471 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2471});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args) {
  V v_n_2473 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2473});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args) {
  V v_n_2476 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2476});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args) {
  V v_n_2478 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2478});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args) {
  V v_n_2479 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2479});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam20(V self, V *args) {
  V v_n_2482 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2482});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam22(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandGo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eexpandGo(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_247));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_241, 0);
    V v_as_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    return (g_heff_2ecompile_2ecallarity_2eexpandApp(v_t_2415, v_t_240, v_f_2413, v_as_2414));
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_a_2417 = heff_field(v_x2_241, 1);
    V v_b_2418 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2419 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_a_2417));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam3, 1, 4, (V[]){v_m_2419, v_t_240, v_b_2418, v_x_2416});
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_go_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2439 = (g_prelude_2etraverse_24s740446701x774604387(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam4, 1, 1, (V[]){v_go_2430}), v_fs_2428));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam6, 1, 2, (V[]){v_m_2439, v_ts_2429});
  }
  case TAG_EProj: {
    V v_e_2444 = heff_field(v_x2_241, 0);
    V v_l_2445 = heff_field(v_x2_241, 1);
    V v_sh_2446 = heff_field(v_x2_241, 2);
    V v_ft_2447 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2448 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_e_2444));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam7, 1, 4, (V[]){v_m_2448, v_l_2445, v_sh_2446, v_ft_2447});
  }
  case TAG_ETag: {
    V v_tg_2453 = heff_field(v_x2_241, 0);
    V v_as_2454 = heff_field(v_x2_241, 1);
    V v_ts_2455 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2457 = (g_prelude_2etraverse_24s740446701x774604387(v_t_2456, v_as_2454));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam8, 1, 3, (V[]){v_m_2457, v_tg_2453, v_ts_2455});
  }
  case TAG_EMatch: {
    V v_s_2462 = heff_field(v_x2_241, 0);
    V v_arms_2463 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2464 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_s_2462));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam9, 1, 3, (V[]){v_m_2464, v_t_240, v_arms_2463});
  }
  case TAG_EPrim: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam12, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2485 = heff_field(v_x2_241, 0);
    V v_as_2486 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2488 = (g_prelude_2etraverse_24s740446701x774604387(v_t_2487, v_as_2486));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam13, 1, 2, (V[]){v_m_2488, v_p_2485});
  }
  case TAG_ECall: {
    V v_g_2493 = heff_field(v_x2_241, 0);
    V v_as_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    V v_m_2496 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_t_2495, v_t_240, v_g_2493, MK_INT(0LL), v_as_2494));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam14, 1, 2, (V[]){v_m_2496, v_g_2493});
  }
  case TAG_EInt: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam15, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFix: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam22, 1, 1, (V[]){v_x2_241});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandGo(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_243});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_b_2418 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_m_2424 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_2418));
    V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_n_2423}));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_n_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2416, v_x_2422, v_x_2426}), v_n_2427});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_l_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2432, v_x_2437}), v_n_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_go_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_l_2432 = heff_field(v_x2_2431, 0);
    V v_e_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    V v_m_2434 = heff_tr(heff_call(v_go_2430, 1, (V[]){v_e_2433}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam5, 1, 2, (V[]){v_m_2434, v_l_2432});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_ts_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2442, v_ts_2429}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_l_2445 = heff_env(self)[1];
  V v_sh_2446 = heff_env(self)[2];
  V v_ft_2447 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2451, v_l_2445, v_sh_2446, v_ft_2447}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_tg_2453 = heff_env(self)[1];
  V v_ts_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_tg_2453, v_x_2460, v_ts_2455}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args) {
  V v_n_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_tg_2471 = heff_env(self)[1];
  V v_vs_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_n_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_n_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tg_2471, v_vs_2472, v_x_2477}), v_n_2478});
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args) {
  V v_x2_2470 = args[0];
  V v_go_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkArm: {
    V v_tg_2471 = heff_field(v_x2_2470, 0);
    V v_vs_2472 = heff_field(v_x2_2470, 1);
    V v_b_2473 = heff_field(v_x2_2470, 2);
    heff_take_n(v_x2_2470, 7ULL, 3);
    V v_m_2474 = heff_tr(heff_call(v_go_2469, 1, (V[]){v_b_2473}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam11, 1, 3, (V[]){v_m_2474, v_tg_2471, v_vs_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args) {
  V v_n_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_arms_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_n_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_n_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    V v_go_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2479 = (g_prelude_2etraverse_24s740446701x774604387(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam10, 1, 1, (V[]){v_go_2469}), v_arms_2463));
    V v_x2_2480 = heff_tr(heff_call(v_m_2479, 1, (V[]){v_n_2468}));
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_MkPair: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      V v_n_2482 = heff_field(v_x2_2480, 1);
      heff_take_n(v_x2_2480, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2467, v_x_2481}), v_n_2482});
    }
    default: return heff_nomatch(v_x2_2480);
    }
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args) {
  V v_n_2484 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_2484});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args) {
  V v_n_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_p_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_n_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_n_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2485, v_x_2491}), v_n_2492});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args) {
  V v_n_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_g_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_n_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_n_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2493, v_x_2499}), v_n_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args) {
  V v_n_24102 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24102});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args) {
  V v_n_24104 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24104});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args) {
  V v_n_24106 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24106});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args) {
  V v_n_24108 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24108});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args) {
  V v_n_24111 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24111});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args) {
  V v_n_24113 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24113});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args) {
  V v_n_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24114});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam22(V self, V *args) {
  V v_n_24117 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24117});
}