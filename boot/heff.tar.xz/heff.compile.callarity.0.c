// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_calls 295783919
#define LBL_dirty 296951788
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_pa 10328
#define LBL_params 951713969
#define LBL_tables 1065764240
#define LBL_uses 10094739
#define LBL_vars 10107635
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_pa[] = {LBL_pa};
static uint32_t shape_tables__globals[] = {LBL_tables, LBL_globals};
static uint32_t shape_vars__globals__dirty[] = {LBL_vars, LBL_globals, LBL_dirty};
V g_heff_2ecompile_2ecallarity_2edropC(V, V);
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2edropC_clo;
V g_heff_2ecompile_2ecallarity_2eexpandApp(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandApp_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArg(V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo;
V g_heff_2ecompile_2ecallarity_2eexpandArgs(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2eexpandArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandArgs_clo;
V g_heff_2ecompile_2ecallarity_2eexpandGo(V, V);
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo;
V g_heff_2ecompile_2ecallarity_2eextend(V, V);
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_clo;
V g_heff_2ecompile_2ecallarity_2eextend_24dps(V, V, V);
V g_heff_2ecompile_2ecallarity_2eextend_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eextend_24dps_clo;
V g_heff_2ecompile_2ecallarity_2efreshMany(V, V);
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(V, V);
V g_heff_2ecompile_2ecallarity_2ehanded(V, V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ehanded_clo;
V g_heff_2ecompile_2ecallarity_2eisNth(V, V, V);
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eisNth_clo;
V g_heff_2ecompile_2ecallarity_2eknownAdd(V, V, V);
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo;
V g_heff_2ecompile_2ecallarity_2enthOr(V, V, V);
V g_heff_2ecompile_2ecallarity_2enthOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2enthOr_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars(V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo;
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V, V, V);
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo;
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2ecallarity_2eraiseTo_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo(V, V);
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s740446701x774604387(V, V);
V g_prelude_2etraverse_24s740446701x774604387_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s740446701x774604387_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
Clo g_heff_2ecompile_2ecallarity_2efreshMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2efreshMany_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2efreshMany(V v_k_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_k_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2ecallarity_2efreshMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2efreshMany(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2edropC_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2edropC(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2eisNth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eisNth_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eisNth(V v_i_240, V v_x_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_241, v_y_243, 0));
      return v_ret_24bool;
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_x_241;
      V t_2 = v_ys_244;
      v_i_240 = t_0;
      v_x_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2ecallarity_2eisNth_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2eisNth(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ezipTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ezipTo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2ezipTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2emap_2eempty_get());
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x1_240, 0);
    V v_ys_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_dup(g_std_2emap_2eempty_get());
    }
    case TAG_Cons: {
      V v_z_244 = heff_field(v_x2_241, 0);
      V v_zs_245 = heff_field(v_x2_241, 1);
      V v_t_246 = (g_heff_2ecompile_2ecallarity_2ezipTo(v_ys_243, v_zs_245));
      return (g_std_2emap_2einsert_24s93785294x875597928(v_t_246, heff_dup(v_y_242), heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_z_244)})));
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2ezipTo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2ezipTo(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2ecallarity_2ehanded_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2ehanded_entry, 6, 0};

V g_heff_2ecompile_2ecallarity_2ehanded(V v_t_240, V v_here_241, V v_h_242, V v_j_243, V v_x_244, V v_n_245) {
top: ;
  V v_key_246 = heff_take_field(v_here_241, 0);
  V v_params_247 = heff_get_n(v_here_241, 1, 4);
  if (heff_strEq_c_lent(v_h_242, v_key_246, 2)) {
    V v_t_248 = ({ V a_0 = heff_dup(v_j_243); V a_1 = v_x_244; V a_2 = v_params_247; V r_ = (g_heff_2ecompile_2ecallarity_2eisNth(a_0, a_1, a_2)); heff_drop(v_params_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop_rec(v_t_240, 1);
      heff_drop(v_j_243);
      heff_drop(v_x_244);
      heff_drop(v_t_248);
      return v_n_245;
    } else {
      heff_drop(v_t_248);
      HeffT2 v_t_249 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        V v_k_2413;
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_ps_2412 = v_field_2411;
          v_k_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_243; V a_2 = v_ps_2412; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2412); r_; });
        } else {
          heff_drop(v_j_243);
          heff_drop(v_field_2411);
          v_k_2413 = MK_INT(0LL);
        }
        HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_n_245, 0), v_x_244));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_k0_2417 = v_field_2416;
            if (heff_intLt_c_lent(v_k_2413, v_k0_2417, 2)) {
              V v_t_2418 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_n_245, 0), v_x_244, v_k_2413));
              return ({ V rv_0 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_n_245, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            } else {
              heff_drop(v_x_244);
              heff_drop(v_k_2413);
              return v_n_245;
            }
          } else {
            heff_drop(v_x_244);
            heff_drop(v_k_2413);
            heff_drop(v_field_2416);
            return v_n_245;
          }
        }
      }
    }
  } else {
    heff_drop(v_params_247);
    HeffT2 v_t_2419 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      V v_k_2423;
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_ps_2422 = v_field_2421;
        v_k_2423 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_243; V a_2 = v_ps_2422; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2422); r_; });
      } else {
        heff_drop(v_j_243);
        heff_drop(v_field_2421);
        v_k_2423 = MK_INT(0LL);
      }
      HeffT2 v_t_2424 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_n_245, 0), v_x_244));
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_k0_2427 = v_field_2426;
          if (heff_intLt_c_lent(v_k_2423, v_k0_2427, 2)) {
            V v_t_2428 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_n_245, 0), v_x_244, v_k_2423));
            return ({ V rv_0 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_n_245, 6ULL, 3, shape_vars__globals__dirty, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          } else {
            heff_drop(v_x_244);
            heff_drop(v_k_2423);
            return v_n_245;
          }
        } else {
          heff_drop(v_x_244);
          heff_drop(v_k_2423);
          heff_drop(v_field_2426);
          return v_n_245;
        }
      }
    }
  }
}
V g_heff_2ecompile_2ecallarity_2ehanded_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2ecallarity_2ehanded(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_args_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_args_243;
      V t_1 = v_rest_241;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    case TAG_ELam: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2411 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    case TAG_EApp: {
      V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2415 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    case TAG_ELet: {
      V v_cell_2419 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2420 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2419)));
      heff_drop(v_u_2420);
      return v_cell_2419;
    }
    case TAG_ERecord: {
      V v_cell_2423 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2424 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2423)));
      heff_drop(v_u_2424);
      return v_cell_2423;
    }
    case TAG_EProj: {
      V v_cell_2429 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2430 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2429)));
      heff_drop(v_u_2430);
      return v_cell_2429;
    }
    case TAG_ETag: {
      V v_cell_2434 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2435 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2434)));
      heff_drop(v_u_2435);
      return v_cell_2434;
    }
    case TAG_EMatch: {
      V v_cell_2438 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2439 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2438)));
      heff_drop(v_u_2439);
      return v_cell_2438;
    }
    case TAG_EPrim: {
      V v_cell_2441 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2442 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2441)));
      heff_drop(v_u_2442);
      return v_cell_2441;
    }
    case TAG_EPrimCall: {
      V v_cell_2445 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2446 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2445)));
      heff_drop(v_u_2446);
      return v_cell_2445;
    }
    case TAG_ECall: {
      V v_cell_2449 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2450 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2449)));
      heff_drop(v_u_2450);
      return v_cell_2449;
    }
    case TAG_EInt: {
      V v_cell_2452 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2453 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2452)));
      heff_drop(v_u_2453);
      return v_cell_2452;
    }
    case TAG_EFloat: {
      V v_cell_2455 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2456 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2455)));
      heff_drop(v_u_2456);
      return v_cell_2455;
    }
    case TAG_EStr: {
      V v_cell_2458 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2459 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2458)));
      heff_drop(v_u_2459);
      return v_cell_2458;
    }
    case TAG_EBytes: {
      V v_cell_2461 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2462 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2461)));
      heff_drop(v_u_2462);
      return v_cell_2461;
    }
    case TAG_EFixed: {
      V v_cell_2465 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2466 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2465)));
      heff_drop(v_u_2466);
      return v_cell_2465;
    }
    case TAG_EFloat32: {
      V v_cell_2468 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2469 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2468)));
      heff_drop(v_u_2469);
      return v_cell_2468;
    }
    case TAG_EAbandon: {
      V v_cell_2470 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2471 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2470)));
      heff_drop(v_u_2471);
      return v_cell_2470;
    }
    case TAG_EBool: {
      V v_cell_2473 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2474 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2473)));
      heff_drop(v_u_2474);
      return v_cell_2473;
    }
    case TAG_ESet: {
      V v_cell_2478 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2479 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2478)));
      heff_drop(v_u_2479);
      return v_cell_2478;
    }
    case TAG_EValues: {
      V v_cell_2481 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2482 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2481)));
      heff_drop(v_u_2482);
      return v_cell_2481;
    }
    case TAG_EFix: {
      V v_cell_2485 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_242, heff_hole()});
      V v_u_2486 = (g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(v_args_243, v_rest_241, heff_dup(v_cell_2485)));
      heff_drop(v_u_2486);
      return v_cell_2485;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2epushNonVars(a[0], a[1]);
}
Clo g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_args_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_EVar: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_d_242;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2412 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2411;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_cell_2415 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2415;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_cell_2420 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2421 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2420));
      heff_drop(v_u_2421);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2420;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_cell_2424 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2425 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2424));
      heff_drop(v_u_2425);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2424;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_cell_2430 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2431 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2430));
      heff_drop(v_u_2431);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2430;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_cell_2435 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2436 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2435));
      heff_drop(v_u_2436);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2435;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_cell_2439 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2440 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2439));
      heff_drop(v_u_2440);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2439;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      V v_cell_2442 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2443 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2442));
      heff_drop(v_u_2443);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2442;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_cell_2446 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2447 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2446));
      heff_drop(v_u_2447);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2446;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_cell_2450 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2451 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2450));
      heff_drop(v_u_2451);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2450;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      V v_cell_2453 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2454 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2453));
      heff_drop(v_u_2454);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2453;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      V v_cell_2456 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2457 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2456));
      heff_drop(v_u_2457);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2456;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      V v_cell_2459 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2460 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2459));
      heff_drop(v_u_2460);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2459;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      V v_cell_2462 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2463 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2462));
      heff_drop(v_u_2463);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2462;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      V v_cell_2466 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2467 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2466));
      heff_drop(v_u_2467);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2466;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      V v_cell_2469 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2470 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2469));
      heff_drop(v_u_2470);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2469;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      V v_cell_2471 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2472 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2471));
      heff_drop(v_u_2472);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2471;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_cell_2474 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2475 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2474));
      heff_drop(v_u_2475);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2474;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_cell_2479 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2480 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2479));
      heff_drop(v_u_2480);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2479;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_cell_2482 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2483 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2482));
      heff_drop(v_u_2483);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2482;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      V v_cell_2486 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x11_243, heff_hole()});
      V v_u_2487 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2486));
      heff_drop(v_u_2487);
      V t_0 = v_args_244;
      V t_1 = v_rest_241;
      V t_2 = v_cell_2486;
      v_x1_240 = t_0;
      v_rest_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2ecallarity_2epushNonVars_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2epushNonVars_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eknownAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eknownAdd_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eknownAdd(V v_k_240, V v_d_241, V v_n_242) {
top: ;
  V v_globals_243 = heff_take_field(v_n_242, 1);
  V v_vars_244 = heff_get_n(v_n_242, 0, 3);
  V v_body_245 = heff_take_field(v_d_241, 2);
  V v_key_246 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_245)) {
  case TAG_EVar: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_body_245, 0);
    V v_ru_24body_245_24ELam = heff_take_reuse_n(v_body_245, 1ULL, 2);
    V v_t_2411 = heff_get_n(heff_get_n(v_k_240, 0, 2), 0, 1);
    V v_t_2417 = (g_list_2emap_24tok2(v_ru_24body_245_24ELam, heff_clo_n(g_heff_2ecompile_2ecallarity_2eknownAdd_lam0, 1, 1, (V[]){v_vars_244}), v_xs_249));
    V v_t_2418 = (g_std_2emap_2einsert_24s93785294x875597928(v_t_2411, v_key_246, v_t_2417));
    return heff_rec_n(2, shape_tables__globals, (V[]){heff_rec_n(1, shape_pa, (V[]){v_t_2418}), v_globals_243});
  }
  case TAG_EApp: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ELet: {
    heff_take_n(v_body_245, 0ULL, 3);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ERecord: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EProj: {
    heff_take_n(v_body_245, 0ULL, 4);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ETag: {
    heff_take_n(v_body_245, 0ULL, 3);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ECall: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EInt: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat: {
    heff_take_na(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EStr: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EBytes: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EAbandon: {
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EBool: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_ESet: {
    heff_take_n(v_body_245, 0ULL, 3);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EValues: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_EFix: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_vars_244);
    heff_drop(v_key_246);
    return ({ V rv_1 = v_globals_243; V rr_ = heff_rec_reuse_nf(v_k_240, 1ULL, 2, shape_tables__globals, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: return heff_nomatch(v_body_245);
  }
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eknownAdd(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eknownAdd_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_vars_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2413 = ({ V a_0 = v_vars_244; V a_1 = v_x_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_vars_244); heff_drop(v_x_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_k_2416 = v_field_2415;
      if (heff_intLe_c_lent(MK_INT(1000000LL), v_k_2416, 1)) {
        heff_drop(v_k_2416);
        return MK_INT(0LL);
      } else {
        return v_k_2416;
      }
    } else {
      heff_drop(v_field_2415);
      return MK_INT(0LL);
    }
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextend_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eextend(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return v_e_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      V v_t_245 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_245});
    }
    case TAG_EGlobal: {
      V v_t_247 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_247});
    }
    case TAG_ELam: {
      V v_ys_248 = heff_field(v_e_241, 0);
      V v_b_249 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_x_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      V v_y_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_y_2411, v_x_2410)) {
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2413 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2412, heff_dup(v_ys_248)));
        V v_m_2414 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2415 = (g_std_2emap_2esize(v_m_2414));
        V v_t_2416;
        if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
          heff_drop(v_m_2414);
          v_t_2416 = v_b_249;
        } else {
          v_t_2416 = ({ V a_0 = v_m_2414; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2414); r_; });
        }
        return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_t_2416});
      } else {
        heff_drop_cell(v_ru_24e_241_24ELam, 2);
        V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
        V v_t_2418 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2417, heff_dup(v_zs_240)));
        V v_m_2419 = ({ V a_0 = v_ys_248; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_248); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2420 = (g_std_2emap_2esize(v_m_2419));
        V v_t_2421;
        if (heff_intEq_c(v_t_2420, MK_INT(0LL))) {
          heff_drop(v_m_2419);
          v_t_2421 = v_b_249;
        } else {
          v_t_2421 = ({ V a_0 = v_m_2419; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2419); r_; });
        }
        V t_0 = v_t_2418;
        V t_1 = v_t_2421;
        v_zs_240 = t_0;
        v_e_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2422 = heff_field(v_e_241, 0);
      V v_args_2423 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_t_2424 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      V v_t_2425 = (g_prelude_2e_2b_2b(v_args_2423, v_t_2424));
      return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_f_2422, v_t_2425});
    }
    case TAG_ELet: {
      V v_x_2426 = heff_field(v_e_241, 0);
      V v_a_2427 = heff_field(v_e_241, 1);
      V v_b_2428 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2429 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2426, v_a_2427, heff_hole()});
      V v_u_2430 = (g_heff_2ecompile_2ecallarity_2eextend_24dps(v_zs_240, v_b_2428, heff_dup(v_cell_2429)));
      heff_drop(v_u_2430);
      return v_cell_2429;
    }
    case TAG_ERecord: {
      V v_t_2433 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2433});
    }
    case TAG_EProj: {
      V v_t_2438 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2438});
    }
    case TAG_ETag: {
      V v_t_2442 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2442});
    }
    case TAG_EMatch: {
      V v_s_2443 = heff_field(v_e_241, 0);
      V v_arms_2444 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_f_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextend_clo), 1, (V[]){v_zs_240}));
      V v_t_2451 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2ecallarity_2eextend_lam0, 1, 1, (V[]){v_f_2445}), v_arms_2444));
      return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2443, v_t_2451});
    }
    case TAG_EPrim: {
      V v_t_2453 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2453});
    }
    case TAG_EPrimCall: {
      V v_t_2456 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2456});
    }
    case TAG_ECall: {
      V v_t_2459 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2459});
    }
    case TAG_EInt: {
      V v_t_2461 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2461});
    }
    case TAG_EFloat: {
      V v_t_2463 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2463});
    }
    case TAG_EStr: {
      V v_t_2465 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2465});
    }
    case TAG_EBytes: {
      V v_t_2467 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2467});
    }
    case TAG_EFixed: {
      V v_t_2470 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2470});
    }
    case TAG_EFloat32: {
      V v_t_2472 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2472});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return NTAG(TAG_EAbandon);
    }
    case TAG_EBool: {
      V v_t_2474 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2474});
    }
    case TAG_ESet: {
      V v_xs_2475 = heff_field(v_e_241, 0);
      V v_a_2476 = heff_field(v_e_241, 1);
      V v_b_2477 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2478 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2475, v_a_2476, heff_hole()});
      V v_u_2479 = (g_heff_2ecompile_2ecallarity_2eextend_24dps(v_zs_240, v_b_2477, heff_dup(v_cell_2478)));
      heff_drop(v_u_2479);
      return v_cell_2478;
    }
    case TAG_EValues: {
      V v_t_2481 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2481});
    }
    case TAG_EFix: {
      V v_t_2484 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2484});
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextend(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eextend_lam0(V self, V *args) {
  V v_x2_2446 = args[0];
  V v_f_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkArm: {
    V v_tg_2447 = heff_field(v_x2_2446, 0);
    V v_vs_2448 = heff_field(v_x2_2446, 1);
    V v_b_2449 = heff_field(v_x2_2446, 2);
    V v_ru_24x2_2446_24MkArm = heff_take_reuse_n(v_x2_2446, 7ULL, 3);
    V v_t_2450 = heff_tr(heff_call(v_f_2445, 1, (V[]){v_b_2449}));
    return heff_tag_at_n(v_ru_24x2_2446_24MkArm, TAG_MkArm, 3, (V[]){v_tg_2447, v_vs_2448, v_t_2450});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eextend_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eextend_24dps_entry, 3, 0};

V g_heff_2ecompile_2ecallarity_2eextend_24dps(V v_zs_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_zs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      V v_t_246 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_246}));
    }
    case TAG_EGlobal: {
      V v_t_248 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_248}));
    }
    case TAG_ELam: {
      V v_ys_249 = heff_field(v_e_241, 0);
      V v_b_2410 = heff_field(v_e_241, 1);
      heff_take_n(v_e_241, 3ULL, 2);
      V v_x_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_249));
      V v_y_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
      if (heff_intLt_c(v_y_2412, v_x_2411)) {
        V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_zs_240));
        V v_t_2414 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2413, heff_dup(v_ys_249)));
        V v_m_2415 = ({ V a_0 = v_ys_249; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_249); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2416 = (g_std_2emap_2esize(v_m_2415));
        V v_t_2417;
        if (heff_intEq_c(v_t_2416, MK_INT(0LL))) {
          heff_drop(v_m_2415);
          v_t_2417 = v_b_2410;
        } else {
          v_t_2417 = ({ V a_0 = v_m_2415; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2415); r_; });
        }
        return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_ELam, 2, (V[]){v_t_2414, v_t_2417}));
      } else {
        V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_249));
        V v_t_2419 = (g_heff_2ecompile_2ecallarity_2edropC(v_t_2418, heff_dup(v_zs_240)));
        V v_m_2420 = ({ V a_0 = v_ys_249; V a_1 = v_zs_240; V r_ = (g_heff_2ecompile_2ecallarity_2ezipTo(a_0, a_1)); heff_drop(v_ys_249); heff_drop_tag(v_zs_240, 2); r_; });
        V v_t_2421 = (g_std_2emap_2esize(v_m_2420));
        V v_t_2422;
        if (heff_intEq_c(v_t_2421, MK_INT(0LL))) {
          heff_drop(v_m_2420);
          v_t_2422 = v_b_2410;
        } else {
          v_t_2422 = ({ V a_0 = v_m_2420; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2420); r_; });
        }
        V t_0 = v_t_2419;
        V t_1 = v_t_2422;
        V t_2 = v_d_242;
        v_zs_240 = t_0;
        v_e_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2423 = heff_field(v_e_241, 0);
      V v_args_2424 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_t_2425 = (g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24e_241_24EApp, v_zs_240));
      V v_t_2426 = (g_prelude_2e_2b_2b(v_args_2424, v_t_2425));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_f_2423, v_t_2426}));
    }
    case TAG_ELet: {
      V v_x_2427 = heff_field(v_e_241, 0);
      V v_a_2428 = heff_field(v_e_241, 1);
      V v_b_2429 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2430 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2427, v_a_2428, heff_hole()});
      V v_u_2431 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2430));
      heff_drop(v_u_2431);
      V t_0 = v_zs_240;
      V t_1 = v_b_2429;
      V t_2 = v_cell_2430;
      v_zs_240 = t_0;
      v_e_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_t_2434 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2434}));
    }
    case TAG_EProj: {
      V v_t_2439 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2439}));
    }
    case TAG_ETag: {
      V v_t_2443 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2443}));
    }
    case TAG_EMatch: {
      V v_s_2444 = heff_field(v_e_241, 0);
      V v_arms_2445 = heff_field(v_e_241, 1);
      V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
      V v_f_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eextend_clo), 1, (V[]){v_zs_240}));
      V v_t_2452 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0, 1, 1, (V[]){v_f_2446}), v_arms_2445));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2444, v_t_2452}));
    }
    case TAG_EPrim: {
      V v_t_2454 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2454}));
    }
    case TAG_EPrimCall: {
      V v_t_2457 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2457}));
    }
    case TAG_ECall: {
      V v_t_2460 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2460}));
    }
    case TAG_EInt: {
      V v_t_2462 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2462}));
    }
    case TAG_EFloat: {
      V v_t_2464 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2464}));
    }
    case TAG_EStr: {
      V v_t_2466 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2466}));
    }
    case TAG_EBytes: {
      V v_t_2468 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2468}));
    }
    case TAG_EFixed: {
      V v_t_2471 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2471}));
    }
    case TAG_EFloat32: {
      V v_t_2473 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2473}));
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_zs_240, 2);
      return heff_setField(v_d_242, MK_INT(2LL), NTAG(TAG_EAbandon));
    }
    case TAG_EBool: {
      V v_t_2475 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2475}));
    }
    case TAG_ESet: {
      V v_xs_2476 = heff_field(v_e_241, 0);
      V v_a_2477 = heff_field(v_e_241, 1);
      V v_b_2478 = heff_field(v_e_241, 2);
      V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
      V v_cell_2479 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2476, v_a_2477, heff_hole()});
      V v_u_2480 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2479));
      heff_drop(v_u_2480);
      V t_0 = v_zs_240;
      V t_1 = v_b_2478;
      V t_2 = v_cell_2479;
      v_zs_240 = t_0;
      v_e_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_t_2482 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2482}));
    }
    case TAG_EFix: {
      V v_t_2485 = (g_list_2emap_24s1809017761x1063871171(v_zs_240));
      return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EApp, 2, (V[]){v_e_241, v_t_2485}));
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_zs_240);
  }
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eextend_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2ecallarity_2eextend_24dps_lam0(V self, V *args) {
  V v_x2_2447 = args[0];
  V v_f_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkArm: {
    V v_tg_2448 = heff_field(v_x2_2447, 0);
    V v_vs_2449 = heff_field(v_x2_2447, 1);
    V v_b_2450 = heff_field(v_x2_2447, 2);
    V v_ru_24x2_2447_24MkArm = heff_take_reuse_n(v_x2_2447, 7ULL, 3);
    V v_t_2451 = heff_tr(heff_call(v_f_2446, 1, (V[]){v_b_2450}));
    return heff_tag_at_n(v_ru_24x2_2447_24MkArm, TAG_MkArm, 3, (V[]){v_tg_2448, v_vs_2449, v_t_2451});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseTo_24cpr(V v_d_240, V v_xs_241, V v_b_242, V v_x4_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    return ((HeffT2){{v_d_240, v_z_244}});
  }
  case TAG_Just: {
    V v_m_245 = heff_field(v_x4_243, 0);
    V v_y_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    if (heff_intLt_c_lent(v_y_246, v_m_245, 1)) {
      V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_248 = heff_intSub(heff_dup(v_m_245), v_t_247);
      HeffT2 v_t_249 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_248, v_z_244));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_n_2413 = v_field_2411;
        V v_t_2414 = (g_prelude_2e_2b_2b(v_xs_241, heff_dup(v_x_2412)));
        V v_t_2415 = (g_heff_2ecompile_2ecallarity_2eextend(v_x_2412, v_b_242));
        V v_body_2416 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2414, v_t_2415});
        V v_f_2417 = ({ V rv_2 = v_body_2416; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        return ((HeffT2){{v_f_2417, v_n_2413}});
      }
    } else {
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      return ((HeffT2){{v_d_240, v_z_244}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT2 g_heff_2ecompile_2ecallarity_2eraiseDef_24cpr(V v_gl_240, V v_d_241, V v_z_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_EVar: {
    V v_ru_24t_243_24EVar = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_u_248 = v_field_247;
        v_t_249 = heff_tag_at_n(v_ru_24t_243_24EVar, TAG_Just, 1, (V[]){heff_get_n(v_u_248, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EVar, 1);
        heff_drop(v_field_247);
        v_t_249 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2414;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_u_2413 = v_field_2412;
        v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2413, 1, 3)});
      } else {
        heff_drop(v_field_2412);
        v_t_2414 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_249; V a_2 = v_t_2414; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); heff_drop(v_t_2414); r_; });
  }
  case TAG_EGlobal: {
    V v_ru_24t_243_24EGlobal = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_2416 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2420;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_u_2419 = v_field_2418;
        v_t_2420 = heff_tag_at_n(v_ru_24t_243_24EGlobal, TAG_Just, 1, (V[]){heff_get_n(v_u_2419, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EGlobal, 1);
        heff_drop(v_field_2418);
        v_t_2420 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2421 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2425;
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_u_2424 = v_field_2423;
        v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2424, 1, 3)});
      } else {
        heff_drop(v_field_2423);
        v_t_2425 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2420; V a_2 = v_t_2425; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); heff_drop(v_t_2425); r_; });
  }
  case TAG_ELam: {
    V v_xs_2426 = heff_field(v_t_243, 0);
    V v_b_2427 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    HeffT2 v_t_2428 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2432;
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        V v_u_2431 = v_field_2430;
        v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2431, 0, 3)});
      } else {
        heff_drop(v_field_2430);
        v_t_2432 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_xs_2426; V a_2 = v_b_2427; V a_3 = v_t_2432; V a_4 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseTo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2432); r_; });
  }
  case TAG_EApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_2435 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2439;
    {
      V v_field_2437 = v_t_2435.f[1];
      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
      if ((v_tag_2436 == ((int64_t)0ULL))) {
        V v_u_2438 = v_field_2437;
        v_t_2439 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2438, 0, 3)});
      } else {
        heff_drop(v_field_2437);
        v_t_2439 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2440 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2444;
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        V v_u_2443 = v_field_2442;
        v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2443, 1, 3)});
      } else {
        heff_drop(v_field_2442);
        v_t_2444 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2439; V a_2 = v_t_2444; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2439); heff_drop(v_t_2444); r_; });
  }
  case TAG_ELet: {
    heff_take_n(v_t_243, 0ULL, 3);
    HeffT2 v_t_2448 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2452;
    {
      V v_field_2450 = v_t_2448.f[1];
      int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
      if ((v_tag_2449 == ((int64_t)0ULL))) {
        V v_u_2451 = v_field_2450;
        v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2451, 0, 3)});
      } else {
        heff_drop(v_field_2450);
        v_t_2452 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2453 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2457;
    {
      V v_field_2455 = v_t_2453.f[1];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_u_2456 = v_field_2455;
        v_t_2457 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2456, 1, 3)});
      } else {
        heff_drop(v_field_2455);
        v_t_2457 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2452; V a_2 = v_t_2457; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2452); heff_drop(v_t_2457); r_; });
  }
  case TAG_ERecord: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_2460 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2464;
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_u_2463 = v_field_2462;
        v_t_2464 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2463, 0, 3)});
      } else {
        heff_drop(v_field_2462);
        v_t_2464 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2465 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2469;
    {
      V v_field_2467 = v_t_2465.f[1];
      int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
      if ((v_tag_2466 == ((int64_t)0ULL))) {
        V v_u_2468 = v_field_2467;
        v_t_2469 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2468, 1, 3)});
      } else {
        heff_drop(v_field_2467);
        v_t_2469 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2464; V a_2 = v_t_2469; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2464); heff_drop(v_t_2469); r_; });
  }
  case TAG_EProj: {
    heff_take_n(v_t_243, 0ULL, 4);
    HeffT2 v_t_2474 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2478;
    {
      V v_field_2476 = v_t_2474.f[1];
      int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
      if ((v_tag_2475 == ((int64_t)0ULL))) {
        V v_u_2477 = v_field_2476;
        v_t_2478 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2477, 0, 3)});
      } else {
        heff_drop(v_field_2476);
        v_t_2478 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2479 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2483;
    {
      V v_field_2481 = v_t_2479.f[1];
      int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
      if ((v_tag_2480 == ((int64_t)0ULL))) {
        V v_u_2482 = v_field_2481;
        v_t_2483 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2482, 1, 3)});
      } else {
        heff_drop(v_field_2481);
        v_t_2483 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2478; V a_2 = v_t_2483; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2478); heff_drop(v_t_2483); r_; });
  }
  case TAG_ETag: {
    heff_take_n(v_t_243, 0ULL, 3);
    HeffT2 v_t_2487 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2491;
    {
      V v_field_2489 = v_t_2487.f[1];
      int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
      if ((v_tag_2488 == ((int64_t)0ULL))) {
        V v_u_2490 = v_field_2489;
        v_t_2491 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2490, 0, 3)});
      } else {
        heff_drop(v_field_2489);
        v_t_2491 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_2492 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_2496;
    {
      V v_field_2494 = v_t_2492.f[1];
      int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
      if ((v_tag_2493 == ((int64_t)0ULL))) {
        V v_u_2495 = v_field_2494;
        v_t_2496 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_2495, 1, 3)});
      } else {
        heff_drop(v_field_2494);
        v_t_2496 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_2491; V a_2 = v_t_2496; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2491); heff_drop(v_t_2496); r_; });
  }
  case TAG_EMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_2499 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24103;
    {
      V v_field_24101 = v_t_2499.f[1];
      int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
      if ((v_tag_24100 == ((int64_t)0ULL))) {
        V v_u_24102 = v_field_24101;
        v_t_24103 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24102, 0, 3)});
      } else {
        heff_drop(v_field_24101);
        v_t_24103 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24104 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24108;
    {
      V v_field_24106 = v_t_24104.f[1];
      int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
      if ((v_tag_24105 == ((int64_t)0ULL))) {
        V v_u_24107 = v_field_24106;
        v_t_24108 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24107, 1, 3)});
      } else {
        heff_drop(v_field_24106);
        v_t_24108 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24103; V a_2 = v_t_24108; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24103); heff_drop(v_t_24108); r_; });
  }
  case TAG_EPrim: {
    V v_ru_24t_243_24EPrim = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24110 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24114;
    {
      V v_field_24112 = v_t_24110.f[1];
      int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
      if ((v_tag_24111 == ((int64_t)0ULL))) {
        V v_u_24113 = v_field_24112;
        v_t_24114 = heff_tag_at_n(v_ru_24t_243_24EPrim, TAG_Just, 1, (V[]){heff_get_n(v_u_24113, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EPrim, 1);
        heff_drop(v_field_24112);
        v_t_24114 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24115 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24119;
    {
      V v_field_24117 = v_t_24115.f[1];
      int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
      if ((v_tag_24116 == ((int64_t)0ULL))) {
        V v_u_24118 = v_field_24117;
        v_t_24119 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24118, 1, 3)});
      } else {
        heff_drop(v_field_24117);
        v_t_24119 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24114; V a_2 = v_t_24119; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24114); heff_drop(v_t_24119); r_; });
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24122 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24126;
    {
      V v_field_24124 = v_t_24122.f[1];
      int64_t v_tag_24123 = ((int64_t)v_t_24122.f[0]);
      if ((v_tag_24123 == ((int64_t)0ULL))) {
        V v_u_24125 = v_field_24124;
        v_t_24126 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24125, 0, 3)});
      } else {
        heff_drop(v_field_24124);
        v_t_24126 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24127 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24131;
    {
      V v_field_24129 = v_t_24127.f[1];
      int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
      if ((v_tag_24128 == ((int64_t)0ULL))) {
        V v_u_24130 = v_field_24129;
        v_t_24131 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24130, 1, 3)});
      } else {
        heff_drop(v_field_24129);
        v_t_24131 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24126; V a_2 = v_t_24131; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24126); heff_drop(v_t_24131); r_; });
  }
  case TAG_ECall: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24134 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24138;
    {
      V v_field_24136 = v_t_24134.f[1];
      int64_t v_tag_24135 = ((int64_t)v_t_24134.f[0]);
      if ((v_tag_24135 == ((int64_t)0ULL))) {
        V v_u_24137 = v_field_24136;
        v_t_24138 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24137, 0, 3)});
      } else {
        heff_drop(v_field_24136);
        v_t_24138 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24139 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24143;
    {
      V v_field_24141 = v_t_24139.f[1];
      int64_t v_tag_24140 = ((int64_t)v_t_24139.f[0]);
      if ((v_tag_24140 == ((int64_t)0ULL))) {
        V v_u_24142 = v_field_24141;
        v_t_24143 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24142, 1, 3)});
      } else {
        heff_drop(v_field_24141);
        v_t_24143 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24138; V a_2 = v_t_24143; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24138); heff_drop(v_t_24143); r_; });
  }
  case TAG_EInt: {
    V v_ru_24t_243_24EInt = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24145 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24149;
    {
      V v_field_24147 = v_t_24145.f[1];
      int64_t v_tag_24146 = ((int64_t)v_t_24145.f[0]);
      if ((v_tag_24146 == ((int64_t)0ULL))) {
        V v_u_24148 = v_field_24147;
        v_t_24149 = heff_tag_at_n(v_ru_24t_243_24EInt, TAG_Just, 1, (V[]){heff_get_n(v_u_24148, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EInt, 1);
        heff_drop(v_field_24147);
        v_t_24149 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24150 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24154;
    {
      V v_field_24152 = v_t_24150.f[1];
      int64_t v_tag_24151 = ((int64_t)v_t_24150.f[0]);
      if ((v_tag_24151 == ((int64_t)0ULL))) {
        V v_u_24153 = v_field_24152;
        v_t_24154 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24153, 1, 3)});
      } else {
        heff_drop(v_field_24152);
        v_t_24154 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24149; V a_2 = v_t_24154; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24149); heff_drop(v_t_24154); r_; });
  }
  case TAG_EFloat: {
    V v_ru_24t_243_24EFloat = heff_take_reuse_na(v_t_243, 0ULL, 1);
    HeffT2 v_t_24156 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24160;
    {
      V v_field_24158 = v_t_24156.f[1];
      int64_t v_tag_24157 = ((int64_t)v_t_24156.f[0]);
      if ((v_tag_24157 == ((int64_t)0ULL))) {
        V v_u_24159 = v_field_24158;
        v_t_24160 = heff_tag_at_n(v_ru_24t_243_24EFloat, TAG_Just, 1, (V[]){heff_get_n(v_u_24159, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EFloat, 1);
        heff_drop(v_field_24158);
        v_t_24160 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24161 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24165;
    {
      V v_field_24163 = v_t_24161.f[1];
      int64_t v_tag_24162 = ((int64_t)v_t_24161.f[0]);
      if ((v_tag_24162 == ((int64_t)0ULL))) {
        V v_u_24164 = v_field_24163;
        v_t_24165 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24164, 1, 3)});
      } else {
        heff_drop(v_field_24163);
        v_t_24165 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24160; V a_2 = v_t_24165; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24160); heff_drop(v_t_24165); r_; });
  }
  case TAG_EStr: {
    V v_ru_24t_243_24EStr = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24167 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24171;
    {
      V v_field_24169 = v_t_24167.f[1];
      int64_t v_tag_24168 = ((int64_t)v_t_24167.f[0]);
      if ((v_tag_24168 == ((int64_t)0ULL))) {
        V v_u_24170 = v_field_24169;
        v_t_24171 = heff_tag_at_n(v_ru_24t_243_24EStr, TAG_Just, 1, (V[]){heff_get_n(v_u_24170, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EStr, 1);
        heff_drop(v_field_24169);
        v_t_24171 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24172 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24176;
    {
      V v_field_24174 = v_t_24172.f[1];
      int64_t v_tag_24173 = ((int64_t)v_t_24172.f[0]);
      if ((v_tag_24173 == ((int64_t)0ULL))) {
        V v_u_24175 = v_field_24174;
        v_t_24176 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24175, 1, 3)});
      } else {
        heff_drop(v_field_24174);
        v_t_24176 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24171; V a_2 = v_t_24176; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24171); heff_drop(v_t_24176); r_; });
  }
  case TAG_EBytes: {
    V v_ru_24t_243_24EBytes = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24178 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24182;
    {
      V v_field_24180 = v_t_24178.f[1];
      int64_t v_tag_24179 = ((int64_t)v_t_24178.f[0]);
      if ((v_tag_24179 == ((int64_t)0ULL))) {
        V v_u_24181 = v_field_24180;
        v_t_24182 = heff_tag_at_n(v_ru_24t_243_24EBytes, TAG_Just, 1, (V[]){heff_get_n(v_u_24181, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EBytes, 1);
        heff_drop(v_field_24180);
        v_t_24182 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24183 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24187;
    {
      V v_field_24185 = v_t_24183.f[1];
      int64_t v_tag_24184 = ((int64_t)v_t_24183.f[0]);
      if ((v_tag_24184 == ((int64_t)0ULL))) {
        V v_u_24186 = v_field_24185;
        v_t_24187 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24186, 1, 3)});
      } else {
        heff_drop(v_field_24185);
        v_t_24187 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24182; V a_2 = v_t_24187; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24182); heff_drop(v_t_24187); r_; });
  }
  case TAG_EFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24190 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24194;
    {
      V v_field_24192 = v_t_24190.f[1];
      int64_t v_tag_24191 = ((int64_t)v_t_24190.f[0]);
      if ((v_tag_24191 == ((int64_t)0ULL))) {
        V v_u_24193 = v_field_24192;
        v_t_24194 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24193, 0, 3)});
      } else {
        heff_drop(v_field_24192);
        v_t_24194 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24195 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24199;
    {
      V v_field_24197 = v_t_24195.f[1];
      int64_t v_tag_24196 = ((int64_t)v_t_24195.f[0]);
      if ((v_tag_24196 == ((int64_t)0ULL))) {
        V v_u_24198 = v_field_24197;
        v_t_24199 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24198, 1, 3)});
      } else {
        heff_drop(v_field_24197);
        v_t_24199 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24194; V a_2 = v_t_24199; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24194); heff_drop(v_t_24199); r_; });
  }
  case TAG_EFloat32: {
    V v_ru_24t_243_24EFloat32 = heff_take_reuse_na(v_t_243, 0ULL, 1);
    HeffT2 v_t_24201 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24205;
    {
      V v_field_24203 = v_t_24201.f[1];
      int64_t v_tag_24202 = ((int64_t)v_t_24201.f[0]);
      if ((v_tag_24202 == ((int64_t)0ULL))) {
        V v_u_24204 = v_field_24203;
        v_t_24205 = heff_tag_at_n(v_ru_24t_243_24EFloat32, TAG_Just, 1, (V[]){heff_get_n(v_u_24204, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EFloat32, 1);
        heff_drop(v_field_24203);
        v_t_24205 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24206 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24210;
    {
      V v_field_24208 = v_t_24206.f[1];
      int64_t v_tag_24207 = ((int64_t)v_t_24206.f[0]);
      if ((v_tag_24207 == ((int64_t)0ULL))) {
        V v_u_24209 = v_field_24208;
        v_t_24210 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24209, 1, 3)});
      } else {
        heff_drop(v_field_24208);
        v_t_24210 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24205; V a_2 = v_t_24210; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24205); heff_drop(v_t_24210); r_; });
  }
  case TAG_EAbandon: {
    HeffT2 v_t_24211 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24215;
    {
      V v_field_24213 = v_t_24211.f[1];
      int64_t v_tag_24212 = ((int64_t)v_t_24211.f[0]);
      if ((v_tag_24212 == ((int64_t)0ULL))) {
        V v_u_24214 = v_field_24213;
        v_t_24215 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24214, 0, 3)});
      } else {
        heff_drop(v_field_24213);
        v_t_24215 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24216 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24220;
    {
      V v_field_24218 = v_t_24216.f[1];
      int64_t v_tag_24217 = ((int64_t)v_t_24216.f[0]);
      if ((v_tag_24217 == ((int64_t)0ULL))) {
        V v_u_24219 = v_field_24218;
        v_t_24220 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24219, 1, 3)});
      } else {
        heff_drop(v_field_24218);
        v_t_24220 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24215; V a_2 = v_t_24220; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24215); heff_drop(v_t_24220); r_; });
  }
  case TAG_EBool: {
    V v_ru_24t_243_24EBool = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24222 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24226;
    {
      V v_field_24224 = v_t_24222.f[1];
      int64_t v_tag_24223 = ((int64_t)v_t_24222.f[0]);
      if ((v_tag_24223 == ((int64_t)0ULL))) {
        V v_u_24225 = v_field_24224;
        v_t_24226 = heff_tag_at_n(v_ru_24t_243_24EBool, TAG_Just, 1, (V[]){heff_get_n(v_u_24225, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EBool, 1);
        heff_drop(v_field_24224);
        v_t_24226 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24227 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24231;
    {
      V v_field_24229 = v_t_24227.f[1];
      int64_t v_tag_24228 = ((int64_t)v_t_24227.f[0]);
      if ((v_tag_24228 == ((int64_t)0ULL))) {
        V v_u_24230 = v_field_24229;
        v_t_24231 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24230, 1, 3)});
      } else {
        heff_drop(v_field_24229);
        v_t_24231 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24226; V a_2 = v_t_24231; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24226); heff_drop(v_t_24231); r_; });
  }
  case TAG_ESet: {
    heff_take_n(v_t_243, 0ULL, 3);
    HeffT2 v_t_24235 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24239;
    {
      V v_field_24237 = v_t_24235.f[1];
      int64_t v_tag_24236 = ((int64_t)v_t_24235.f[0]);
      if ((v_tag_24236 == ((int64_t)0ULL))) {
        V v_u_24238 = v_field_24237;
        v_t_24239 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24238, 0, 3)});
      } else {
        heff_drop(v_field_24237);
        v_t_24239 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24240 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24244;
    {
      V v_field_24242 = v_t_24240.f[1];
      int64_t v_tag_24241 = ((int64_t)v_t_24240.f[0]);
      if ((v_tag_24241 == ((int64_t)0ULL))) {
        V v_u_24243 = v_field_24242;
        v_t_24244 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24243, 1, 3)});
      } else {
        heff_drop(v_field_24242);
        v_t_24244 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24239; V a_2 = v_t_24244; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24239); heff_drop(v_t_24244); r_; });
  }
  case TAG_EValues: {
    V v_ru_24t_243_24EValues = heff_take_reuse_n(v_t_243, 0ULL, 1);
    HeffT2 v_t_24246 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24250;
    {
      V v_field_24248 = v_t_24246.f[1];
      int64_t v_tag_24247 = ((int64_t)v_t_24246.f[0]);
      if ((v_tag_24247 == ((int64_t)0ULL))) {
        V v_u_24249 = v_field_24248;
        v_t_24250 = heff_tag_at_n(v_ru_24t_243_24EValues, TAG_Just, 1, (V[]){heff_get_n(v_u_24249, 0, 3)});
      } else {
        heff_drop_cell(v_ru_24t_243_24EValues, 1);
        heff_drop(v_field_24248);
        v_t_24250 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24251 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24255;
    {
      V v_field_24253 = v_t_24251.f[1];
      int64_t v_tag_24252 = ((int64_t)v_t_24251.f[0]);
      if ((v_tag_24252 == ((int64_t)0ULL))) {
        V v_u_24254 = v_field_24253;
        v_t_24255 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24254, 1, 3)});
      } else {
        heff_drop(v_field_24253);
        v_t_24255 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24250; V a_2 = v_t_24255; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24250); heff_drop(v_t_24255); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    HeffT2 v_t_24258 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24262;
    {
      V v_field_24260 = v_t_24258.f[1];
      int64_t v_tag_24259 = ((int64_t)v_t_24258.f[0]);
      if ((v_tag_24259 == ((int64_t)0ULL))) {
        V v_u_24261 = v_field_24260;
        v_t_24262 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24261, 0, 3)});
      } else {
        heff_drop(v_field_24260);
        v_t_24262 = NTAG(TAG_Nothing);
      }
    }
    HeffT2 v_t_24263 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_gl_240, heff_rfield(v_d_241, 0)));
    V v_t_24267;
    {
      V v_field_24265 = v_t_24263.f[1];
      int64_t v_tag_24264 = ((int64_t)v_t_24263.f[0]);
      if ((v_tag_24264 == ((int64_t)0ULL))) {
        V v_u_24266 = v_field_24265;
        v_t_24267 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_24266, 1, 3)});
      } else {
        heff_drop(v_field_24265);
        v_t_24267 = NTAG(TAG_Nothing);
      }
    }
    return ({ V a_0 = v_d_241; V a_1 = v_t_24262; V a_2 = v_t_24267; V a_3 = v_z_242; HeffT2 r_ = (g_heff_2ecompile_2ecallarity_2eraiseOnce_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_24262); heff_drop(v_t_24267); r_; });
  }
  default: return ((HeffT2){{heff_nomatch(v_t_243)}});
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam20(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam21(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam22(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam23(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandArg_entry, 4, 0};

V g_heff_2ecompile_2ecallarity_2eexpandArg(V v_t_240, V v_h_241, V v_j_242, V v_a_243) {
top: ;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam0, 1, 1, (V[]){v_a_243});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam1, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELam: {
    V v_ys_248 = heff_field(v_a_243, 0);
    V v_b_249 = heff_field(v_a_243, 1);
    heff_take_n(v_a_243, 3ULL, 2);
    HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_t_240, 0), v_h_241));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_x_2414;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_ps_2413 = v_field_2412;
        v_x_2414 = ({ V a_0 = MK_INT(0LL); V a_1 = heff_dup(v_j_242); V a_2 = v_ps_2413; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2413); r_; });
      } else {
        heff_drop(v_field_2412);
        v_x_2414 = MK_INT(0LL);
      }
      V v_y_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
      if (heff_intLt_c(v_y_2415, v_x_2414)) {
        HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_t_240, 0, 1); V a_1 = v_h_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2420;
        {
          V v_field_2418 = v_t_2416.f[1];
          int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
          if ((v_tag_2417 == ((int64_t)0ULL))) {
            V v_ps_2419 = v_field_2418;
            v_t_2420 = ({ V a_0 = MK_INT(0LL); V a_1 = v_j_242; V a_2 = v_ps_2419; V r_ = (g_heff_2ecompile_2ecallarity_2enthOr(a_0, a_1, a_2)); heff_drop(v_ps_2419); r_; });
          } else {
            heff_drop(v_j_242);
            heff_drop(v_field_2418);
            v_t_2420 = MK_INT(0LL);
          }
        }
        V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_248));
        V v_t_2422 = heff_intSub(v_t_2420, v_t_2421);
        return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam2, 1, 3, (V[]){v_t_2422, v_ys_248, v_b_249});
      } else {
        heff_drop_rec(v_t_240, 1);
        heff_drop(v_j_242);
        return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam3, 1, 2, (V[]){v_ys_248, v_b_249});
      }
    }
  }
  case TAG_EApp: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam4, 1, 1, (V[]){v_a_243});
  }
  case TAG_ELet: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam5, 1, 1, (V[]){v_a_243});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam6, 1, 1, (V[]){v_a_243});
  }
  case TAG_EProj: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam7, 1, 1, (V[]){v_a_243});
  }
  case TAG_ETag: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam8, 1, 1, (V[]){v_a_243});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam9, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam10, 1, 1, (V[]){v_a_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam11, 1, 1, (V[]){v_a_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam12, 1, 1, (V[]){v_a_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam13, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam14, 1, 1, (V[]){v_a_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam15, 1, 1, (V[]){v_a_243});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam16, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam17, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam18, 1, 1, (V[]){v_a_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam19, 1, 1, (V[]){v_a_243});
  }
  case TAG_EBool: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam20, 1, 1, (V[]){v_a_243});
  }
  case TAG_ESet: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam21, 1, 1, (V[]){v_a_243});
  }
  case TAG_EValues: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam22, 1, 1, (V[]){v_a_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_t_240, 1);
    heff_drop(v_j_242);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandArg_lam23, 1, 1, (V[]){v_a_243});
  }
  default: return heff_nomatch(v_a_243);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2ecallarity_2eexpandArg(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_247});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam2(V self, V *args) {
  V v_n_2423 = args[0];
  V v_t_2422 = heff_env(self)[0];
  V v_ys_248 = heff_env(self)[1];
  V v_b_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2424 = (g_heff_2ecompile_2ecallarity_2efreshMany_24cpr(v_t_2422, v_n_2423));
  {
    V v_field_2425 = v_t_2424.f[0];
    V v_field_2426 = v_t_2424.f[1];
    V v_x_2427 = v_field_2425;
    V v_n_2428 = v_field_2426;
    V v_t_2429 = (g_prelude_2e_2b_2b(v_ys_248, heff_dup(v_x_2427)));
    V v_t_2430 = (g_heff_2ecompile_2ecallarity_2eextend(v_x_2427, v_b_249));
    V v_x_2431 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2429, v_t_2430});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2431, v_n_2428});
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam3(V self, V *args) {
  V v_n_2432 = args[0];
  V v_ys_248 = heff_env(self)[0];
  V v_b_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_ys_248, v_b_249}), v_n_2432});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam4(V self, V *args) {
  V v_n_2435 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2435});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam5(V self, V *args) {
  V v_n_2439 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2439});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam6(V self, V *args) {
  V v_n_2442 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2442});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam7(V self, V *args) {
  V v_n_2447 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2447});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam8(V self, V *args) {
  V v_n_2451 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2451});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam9(V self, V *args) {
  V v_n_2454 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2454});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam10(V self, V *args) {
  V v_n_2456 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2456});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam11(V self, V *args) {
  V v_n_2459 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2459});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam12(V self, V *args) {
  V v_n_2462 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2462});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam13(V self, V *args) {
  V v_n_2464 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2464});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam14(V self, V *args) {
  V v_n_2466 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2466});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam15(V self, V *args) {
  V v_n_2468 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2468});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam16(V self, V *args) {
  V v_n_2470 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2470});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam17(V self, V *args) {
  V v_n_2473 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2473});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam18(V self, V *args) {
  V v_n_2475 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2475});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam19(V self, V *args) {
  V v_n_2476 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2476});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam20(V self, V *args) {
  V v_n_2478 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2478});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam21(V self, V *args) {
  V v_n_2482 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2482});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam22(V self, V *args) {
  V v_n_2484 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2484});
}
V g_heff_2ecompile_2ecallarity_2eexpandArg_lam23(V self, V *args) {
  V v_n_2487 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_n_2487});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam22(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam23(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam24(V self, V *args);
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam25(V self, V *args);
Clo g_heff_2ecompile_2ecallarity_2eexpandGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2ecallarity_2eexpandGo_entry, 2, 0};

V g_heff_2ecompile_2ecallarity_2eexpandGo(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_247));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    return (g_heff_2ecompile_2ecallarity_2eexpandApp(v_t_2415, v_t_240, v_f_2413, v_args_2414));
  }
  case TAG_ELet: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_a_2417 = heff_field(v_x2_241, 1);
    V v_b_2418 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2419 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_a_2417));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam3, 1, 4, (V[]){v_m_2419, v_t_240, v_b_2418, v_x_2416});
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_go_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2439 = (g_prelude_2etraverse_24s740446701x774604387(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam4, 1, 1, (V[]){v_go_2430}), v_fs_2428));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam6, 1, 2, (V[]){v_m_2439, v_ts_2429});
  }
  case TAG_EProj: {
    V v_e_2444 = heff_field(v_x2_241, 0);
    V v_l_2445 = heff_field(v_x2_241, 1);
    V v_sh_2446 = heff_field(v_x2_241, 2);
    V v_ft_2447 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2448 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_e_2444));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam7, 1, 4, (V[]){v_m_2448, v_l_2445, v_sh_2446, v_ft_2447});
  }
  case TAG_ETag: {
    V v_tg_2453 = heff_field(v_x2_241, 0);
    V v_args_2454 = heff_field(v_x2_241, 1);
    V v_ts_2455 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2457 = (g_prelude_2etraverse_24s740446701x774604387(v_t_2456, v_args_2454));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam8, 1, 3, (V[]){v_m_2457, v_tg_2453, v_ts_2455});
  }
  case TAG_EMatch: {
    V v_s_2462 = heff_field(v_x2_241, 0);
    V v_arms_2463 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2464 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_s_2462));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam9, 1, 3, (V[]){v_m_2464, v_t_240, v_arms_2463});
  }
  case TAG_EPrim: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam12, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2485 = heff_field(v_x2_241, 0);
    V v_args_2486 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2488 = (g_prelude_2etraverse_24s740446701x774604387(v_t_2487, v_args_2486));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam13, 1, 2, (V[]){v_m_2488, v_p_2485});
  }
  case TAG_ECall: {
    V v_g_2493 = heff_field(v_x2_241, 0);
    V v_args_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){heff_dup(v_t_240)}));
    V v_m_2496 = (g_heff_2ecompile_2ecallarity_2eexpandArgs(v_t_2495, v_t_240, v_g_2493, MK_INT(0LL), v_args_2494));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam14, 1, 2, (V[]){v_m_2496, v_g_2493});
  }
  case TAG_EInt: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam15, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBool: {
    V v_c_24115 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24116 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_24117 = (g_heff_2ecompile_2eir_2econdTraverse_24s1369662855x2066618804(v_t_24116, v_c_24115));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam22, 1, 1, (V[]){v_m_24117});
  }
  case TAG_ESet: {
    V v_xs_24122 = heff_field(v_x2_241, 0);
    V v_a_24123 = heff_field(v_x2_241, 1);
    V v_b_24124 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24125 = (g_heff_2ecompile_2ecallarity_2eexpandGo(heff_dup(v_t_240), v_a_24123));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam23, 1, 4, (V[]){v_m_24125, v_t_240, v_b_24124, v_xs_24122});
  }
  case TAG_EValues: {
    V v_es_24134 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24135 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_24136 = (g_prelude_2etraverse_24s740446701x774604387(v_t_24135, v_es_24134));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam24, 1, 1, (V[]){v_m_24136});
  }
  case TAG_EFix: {
    heff_drop(v_t_240);
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam25, 1, 1, (V[]){v_x2_241});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2ecallarity_2eexpandGo(a[0], a[1]);
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_243});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_245});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam3(V self, V *args) {
  V v_n_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_b_2418 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_n_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_m_2424 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_2418));
    V v_x2_2425 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_n_2423}));
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_n_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2416, v_x_2422, v_x_2426}), v_n_2427});
    }
    default: return heff_nomatch(v_x2_2425);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam5(V self, V *args) {
  V v_n_2435 = args[0];
  V v_m_2434 = heff_env(self)[0];
  V v_l_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2436 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2435}));
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_x_2437 = heff_field(v_x2_2436, 0);
    V v_n_2438 = heff_field(v_x2_2436, 1);
    V v_ru_24x2_2436_24MkPair = heff_take_reuse_n(v_x2_2436, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2432, v_x_2437}), v_n_2438});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam4(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_go_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_l_2432 = heff_field(v_x2_2431, 0);
    V v_e_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    V v_m_2434 = heff_tr(heff_call(v_go_2430, 1, (V[]){v_e_2433}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam5, 1, 2, (V[]){v_m_2434, v_l_2432});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam6(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_ts_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2442, v_ts_2429}), v_n_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam7(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_l_2445 = heff_env(self)[1];
  V v_sh_2446 = heff_env(self)[2];
  V v_ft_2447 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2451, v_l_2445, v_sh_2446, v_ft_2447}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam8(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_tg_2453 = heff_env(self)[1];
  V v_ts_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_tg_2453, v_x_2460, v_ts_2455}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam11(V self, V *args) {
  V v_n_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_tg_2471 = heff_env(self)[1];
  V v_vs_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_n_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_n_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tg_2471, v_vs_2472, v_x_2477}), v_n_2478});
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam10(V self, V *args) {
  V v_x2_2470 = args[0];
  V v_go_2469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkArm: {
    V v_tg_2471 = heff_field(v_x2_2470, 0);
    V v_vs_2472 = heff_field(v_x2_2470, 1);
    V v_b_2473 = heff_field(v_x2_2470, 2);
    heff_take_n(v_x2_2470, 7ULL, 3);
    V v_m_2474 = heff_tr(heff_call(v_go_2469, 1, (V[]){v_b_2473}));
    return heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam11, 1, 3, (V[]){v_m_2474, v_tg_2471, v_vs_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam9(V self, V *args) {
  V v_n_2465 = args[0];
  V v_m_2464 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_arms_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2466 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_n_2465}));
  switch (heff_tag_of(v_x2_2466)) {
  case TAG_MkPair: {
    V v_x_2467 = heff_field(v_x2_2466, 0);
    V v_n_2468 = heff_field(v_x2_2466, 1);
    V v_ru_24x2_2466_24MkPair = heff_take_reuse_n(v_x2_2466, 3ULL, 2);
    V v_go_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2ecallarity_2eexpandGo_clo), 1, (V[]){v_t_240}));
    V v_m_2479 = (g_prelude_2etraverse_24s740446701x774604387(heff_clo_n(g_heff_2ecompile_2ecallarity_2eexpandGo_lam10, 1, 1, (V[]){v_go_2469}), v_arms_2463));
    V v_x2_2480 = heff_tr(heff_call(v_m_2479, 1, (V[]){v_n_2468}));
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_MkPair: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      V v_n_2482 = heff_field(v_x2_2480, 1);
      heff_take_n(v_x2_2480, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2467, v_x_2481}), v_n_2482});
    }
    default: return heff_nomatch(v_x2_2480);
    }
  }
  default: return heff_nomatch(v_x2_2466);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam12(V self, V *args) {
  V v_n_2484 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_2484});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam13(V self, V *args) {
  V v_n_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_p_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_n_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_n_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2485, v_x_2491}), v_n_2492});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam14(V self, V *args) {
  V v_n_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_g_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_n_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_n_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2493, v_x_2499}), v_n_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam15(V self, V *args) {
  V v_n_24102 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24102});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam16(V self, V *args) {
  V v_n_24104 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24104});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam17(V self, V *args) {
  V v_n_24106 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24106});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam18(V self, V *args) {
  V v_n_24108 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24108});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam19(V self, V *args) {
  V v_n_24111 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24111});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam20(V self, V *args) {
  V v_n_24113 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24113});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam21(V self, V *args) {
  V v_n_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24114});
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam22(V self, V *args) {
  V v_n_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24119 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_n_24118}));
  switch (heff_tag_of(v_x2_24119)) {
  case TAG_MkPair: {
    V v_x_24120 = heff_field(v_x2_24119, 0);
    V v_n_24121 = heff_field(v_x2_24119, 1);
    V v_ru_24x2_24119_24MkPair = heff_take_reuse_n(v_x2_24119, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24120}), v_n_24121});
  }
  default: return heff_nomatch(v_x2_24119);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam23(V self, V *args) {
  V v_n_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_b_24124 = heff_env(self)[2];
  V v_xs_24122 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_n_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_m_24130 = (g_heff_2ecompile_2ecallarity_2eexpandGo(v_t_240, v_b_24124));
    V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_n_24129}));
    switch (heff_tag_of(v_x2_24131)) {
    case TAG_MkPair: {
      V v_x_24132 = heff_field(v_x2_24131, 0);
      V v_n_24133 = heff_field(v_x2_24131, 1);
      heff_take_n(v_x2_24131, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24122, v_x_24128, v_x_24132}), v_n_24133});
    }
    default: return heff_nomatch(v_x2_24131);
    }
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam24(V self, V *args) {
  V v_n_24137 = args[0];
  V v_m_24136 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24138 = heff_tr(heff_call(v_m_24136, 1, (V[]){v_n_24137}));
  switch (heff_tag_of(v_x2_24138)) {
  case TAG_MkPair: {
    V v_x_24139 = heff_field(v_x2_24138, 0);
    V v_n_24140 = heff_field(v_x2_24138, 1);
    V v_ru_24x2_24138_24MkPair = heff_take_reuse_n(v_x2_24138, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24138_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24139}), v_n_24140});
  }
  default: return heff_nomatch(v_x2_24138);
  }
}
V g_heff_2ecompile_2ecallarity_2eexpandGo_lam25(V self, V *args) {
  V v_n_24143 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24143});
}