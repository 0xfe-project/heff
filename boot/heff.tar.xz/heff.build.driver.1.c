// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Bug 14592
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Div 16157
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpId 35501
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VOpaque 37311
#define TAG_VPrimInt 4244
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_cached 579094605
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_defs 9574869
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_doc 309170
#define LBL_el 9998
#define LBL_entries 787768015
#define LBL_expected 956903529
#define LBL_exposes 1070285678
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_header 725871032
#define LBL_hidden 729654485
#define LBL_holds 300818350
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_multi 305615187
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_opens 307306371
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_places 961367927
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_syntax 1059664654
#define LBL_tags 10047712
#define LBL_tests 311609915
#define LBL_to 10466
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_unexposed 2027212082
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watch 314261737
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_decls, LBL_top, LBL_diags, LBL_own, LBL_deps, LBL_opens, LBL_aliases, LBL_fixities, LBL_cached, LBL_exposes};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_unexposed, LBL_instances};
static uint32_t shape_out__multi__first[] = {LBL_out, LBL_multi, LBL_first};
static uint32_t shape_owner__line__watch[] = {LBL_owner, LBL_line, LBL_watch};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2eaddTests(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eaddTests_clo;
V g_heff_2ebuild_2edriver_2ealiasModule(V, V);
V g_heff_2ebuild_2edriver_2ealiasModule_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasModule_clo;
V g_heff_2ebuild_2edriver_2ealiasOpen(V, V, V, V);
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasQualified(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo;
V g_heff_2ebuild_2edriver_2eanyD(V, V);
V g_heff_2ebuild_2edriver_2eanyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s18585397x663188215(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s18585397x663188215_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s18585397x663188215_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s62568991x6102141(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s62568991x6102141_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s62568991x6102141_clo;
V g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendD_24dps(V, V, V);
V g_heff_2ebuild_2edriver_2eappendD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_24dps_clo;
V g_heff_2ebuild_2edriver_2eargV(V, V);
V g_heff_2ebuild_2edriver_2eargV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eargV_clo;
V g_heff_2ebuild_2edriver_2ebrokenIn(V);
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(V, V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_clo;
V g_heff_2ebuild_2edriver_2eelabClashed(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabClashed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabClashed_clo;
V g_heff_2ebuild_2edriver_2eelabDecls(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabDecls_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabDecls_clo;
V g_heff_2ebuild_2edriver_2eelabEnv(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabEnv_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabEnv_clo;
V g_heff_2ebuild_2edriver_2eelabRead(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabRead_clo;
V g_heff_2ebuild_2edriver_2eelabTop(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabTop_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabTop_clo;
V g_heff_2ebuild_2edriver_2eevalWatch(V, V);
V g_heff_2ebuild_2edriver_2eevalWatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalWatch_clo;
V g_heff_2ebuild_2edriver_2eexposedDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexposedDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedDiag_clo;
V g_heff_2ebuild_2edriver_2eexposedInstances(V);
V g_heff_2ebuild_2edriver_2eexposedInstances_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedInstances_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindChecked_24cpr(V, V);
V g_heff_2ebuild_2edriver_2efixityLine(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLine_clo;
V g_heff_2ebuild_2edriver_2efixityLines(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_clo;
V g_heff_2ebuild_2edriver_2efixityLines_24acc(V, V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_24acc_clo;
V g_heff_2ebuild_2edriver_2egivesWay(V, V, V);
V g_heff_2ebuild_2edriver_2egivesWay_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2egivesWay_clo;
V g_heff_2ebuild_2edriver_2eglueOne(V, V);
V g_heff_2ebuild_2edriver_2eglueOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eglueOne_clo;
V g_heff_2ebuild_2edriver_2eimportLines(V);
V g_heff_2ebuild_2edriver_2eimportLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportLines_clo;
V g_heff_2ebuild_2edriver_2eisBenchOwn(V, V);
V g_heff_2ebuild_2edriver_2eisBenchOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisBenchOwn_clo;
V g_heff_2ebuild_2edriver_2eisBenchTy(V);
V g_heff_2ebuild_2edriver_2eisBenchTy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisBenchTy_clo;
V g_heff_2ebuild_2edriver_2eisDataKey(V, V);
V g_heff_2ebuild_2edriver_2eisDataKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisDataKey_clo;
V g_heff_2ebuild_2edriver_2eisTestEl(V);
V g_heff_2ebuild_2edriver_2eisTestEl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestEl_clo;
V g_heff_2ebuild_2edriver_2eisTestOwn(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo;
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2elistOfV_24dps(V, V);
V g_heff_2ebuild_2edriver_2elistOfV_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_24dps_clo;
V g_heff_2ebuild_2edriver_2elistedName(V);
V g_heff_2ebuild_2edriver_2elistedName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistedName_clo;
V g_heff_2ebuild_2edriver_2emoduleStruct(V, V, V);
V g_heff_2ebuild_2edriver_2emoduleStruct_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emoduleStruct_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2enubStrD_24dps(V, V);
V g_heff_2ebuild_2edriver_2enubStrD_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_24dps_clo;
V g_heff_2ebuild_2edriver_2eopenNames(V);
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_clo;
V g_heff_2ebuild_2edriver_2eopenNames_24dps(V, V);
V g_heff_2ebuild_2edriver_2eopenNames_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_24dps_clo;
HeffT2 g_heff_2ebuild_2edriver_2eownKeyOf_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eownUses(V, V);
V g_heff_2ebuild_2edriver_2eownUses_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eownUses_clo;
V g_heff_2ebuild_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epromoteAt_clo;
V g_heff_2ebuild_2edriver_2ereachOwn(V, V, V);
V g_heff_2ebuild_2edriver_2ereachOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ereachOwn_clo;
V g_heff_2ebuild_2edriver_2erootsAmong(V, V);
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erootsAmong_clo;
V g_heff_2ebuild_2edriver_2estructIdxGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo;
V g_heff_2ebuild_2edriver_2etestOwner(V, V);
V g_heff_2ebuild_2edriver_2etestOwner_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestOwner_clo;
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked(V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo;
V g_heff_2ebuild_2edriver_2etypeArgsOf(V, V);
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo;
V g_heff_2ebuild_2edriver_2ewatchInfo(V, V, V);
V g_heff_2ebuild_2edriver_2ewatchInfo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchInfo_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithEntry(V, V, V);
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithEntry_clo;
V g_heff_2ebuild_2edriver_2ewithHiddenOne(V, V);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithHiddenOne_clo;
V g_heff_2ebuild_2edriver_2ewithImportedInstances(V, V, V);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo;
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2eglobalEnvGo(V, V);
V g_heff_2ecompile_2einterp_2eglobalEnvGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eglobalEnvGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eelab_2eglobals_2eisBroken(V, V);
V g_heff_2eelab_2eglobals_2eisBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eisBroken_clo;
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1993301886x522650342(V, V);
V g_list_2eany_24s1993301886x522650342_entry(V self, V *a);
extern Clo g_list_2eany_24s1993301886x522650342_clo;
V g_list_2eany_24s2062006893x520992087(V, V, V);
V g_list_2eany_24s2062006893x520992087_entry(V self, V *a);
extern Clo g_list_2eany_24s2062006893x520992087_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s359366115x1439523039(V, V);
V g_list_2eany_24s359366115x1439523039_entry(V self, V *a);
extern Clo g_list_2eany_24s359366115x1439523039_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24f1300261417x1763075249(V, V, V, V, V);
V g_list_2efilter_24f1300261417x1763075249_entry(V self, V *a);
extern Clo g_list_2efilter_24f1300261417x1763075249_clo;
V g_list_2efilter_24s1646962431x688731818(V, V);
V g_list_2efilter_24s1646962431x688731818_entry(V self, V *a);
extern Clo g_list_2efilter_24s1646962431x688731818_clo;
V g_list_2efilter_24s1725367856x1498536808(V);
V g_list_2efilter_24s1725367856x1498536808_entry(V self, V *a);
extern Clo g_list_2efilter_24s1725367856x1498536808_clo;
V g_list_2efilter_24s716173495x680820632(V, V);
V g_list_2efilter_24s716173495x680820632_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s1122556128x1089664899(V, V);
V g_list_2efoldl_24s1122556128x1089664899_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1122556128x1089664899_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1722922134x788519507(V, V);
V g_list_2efoldl_24s1722922134x788519507_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1722922134x788519507_clo;
V g_list_2efoldl_24s1973731134x151660308(V, V, V);
V g_list_2efoldl_24s1973731134x151660308_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1973731134x151660308_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s75764538x1218461500(V, V, V);
V g_list_2efoldl_24s75764538x1218461500_entry(V self, V *a);
extern Clo g_list_2efoldl_24s75764538x1218461500_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f902549164x1589757410(V, V);
V g_list_2emap_24f902549164x1589757410_entry(V self, V *a);
extern Clo g_list_2emap_24f902549164x1589757410_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s1354328764x1362350361(V);
V g_list_2emap_24s1354328764x1362350361_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_clo;
V g_list_2emap_24s1366476796x894764441(V, V);
V g_list_2emap_24s1366476796x894764441_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_clo;
V g_list_2emap_24s1534167768x1221742344(V);
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_clo;
V g_list_2emap_24s1535007417x1587061701(V);
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1960706388x853997965(V);
V g_list_2emap_24s1960706388x853997965_entry(V self, V *a);
extern Clo g_list_2emap_24s1960706388x853997965_clo;
V g_list_2emap_24s984607094x1283457643(V, V, V, V);
V g_list_2emap_24s984607094x1283457643_entry(V self, V *a);
extern Clo g_list_2emap_24s984607094x1283457643_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2edelete_24s339308281x1667047697(V, V);
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s339308281x1667047697_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2ebuild_2edriver_2eappendD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendD_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eappendD(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ebuild_2edriver_2eappendD_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendD(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2eappendD_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendD_24dps_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eappendD_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendD_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendD_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2enubStrD_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2enubStrD_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2enubStrD_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2enubStrD_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2enubStrD_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2ewithEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithEntry_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithEntry(V v_k_240, V v_c_241, V v_g_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_242, 1), v_k_240));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_k_240);
      heff_drop_rec(v_c_241, 14);
      V v_e_247 = v_field_245;
      heff_drop(v_e_247);
      return v_g_242;
    } else {
      heff_drop(v_field_245);
      V v_g_248 = heff_get_n(heff_get_n(v_c_241, 5, 14), 0, 9);
      HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_248, 1), v_k_240));
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          heff_drop_rec(v_g_248, 9);
          V v_e_2413 = v_field_2411;
          HEFF_LAST return g_heff_2eelab_2eglobals_2eaddEntry(v_k_240, v_e_2413, v_g_242);
        } else {
          heff_drop(v_field_2411);
          HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_248, 2), v_k_240));
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_k2_2418 = v_field_2416;
              HeffT2 v_t_2419 = ({ V b_0 = heff_get_n(v_g_248, 1, 9); V a_1 = v_k2_2418; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2418); r_; });
              {
                V v_field_2421 = v_t_2419.f[1];
                int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                if ((v_tag_2420 == ((int64_t)0ULL))) {
                  V v_e_2423 = v_field_2421;
                  HEFF_LAST return g_heff_2eelab_2eglobals_2eaddEntry(v_k_240, v_e_2423, v_g_242);
                } else {
                  heff_drop(v_k_240);
                  heff_drop(v_field_2421);
                  return v_g_242;
                }
              }
            } else {
              heff_drop(v_k_240);
              heff_drop_rec(v_g_248, 9);
              heff_drop(v_field_2416);
              return v_g_242;
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithEntry(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecatMaybesD_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecatMaybesD_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2eanyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eanyD_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eanyD(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eanyD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eanyD(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewithHiddenOne_str0, 4, "(..)");
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam3(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewithHiddenOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithHiddenOne_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewithHiddenOne(V v_g_240, V v_c_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_c_241, 13));
  V v_t_246;
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_es_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    v_t_246 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam0, 1, 1, (V[]){v_es_243}), heff_dup(heff_rfield(v_c_241, 7))));
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam1, 2, 1, (V[]){heff_dup(v_c_241)}); V a_1 = v_g_240; V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2411 = heff_dup(heff_rfield(v_c_241, 13));
  V v_t_2415;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_es_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    v_t_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam2, 1, 1, (V[]){v_es_2412}), heff_dup(heff_rfield(v_c_241, 7))));
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithHiddenOne_lam3, 2, 1, (V[]){v_c_241}); V a_1 = v_t_2410; V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithHiddenOne(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam0(V self, V *args) {
  V v_o_244 = args[0];
  V v_es_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = ({ V b_0 = heff_get_n(v_o_244, 0, 2); V a_1 = v_es_243; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_243); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam1(V self, V *args) {
  V v_g2_247 = args[0];
  V v_o_248 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_g2_247, 6), heff_get_n(v_o_248, 1, 2), heff_get_n(v_c_241, 0, 14)));
  return ({ V rv_6 = v_t_249; V rr_ = heff_rec_reuse_nf(v_g2_247, 447ULL, 9, shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam2(V self, V *args) {
  V v_o_2413 = args[0];
  V v_es_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2414 = ({ V b_0 = heff_get_n(v_o_2413, 0, 2); V a_1 = v_es_2412; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s18585397x663188215(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_2412); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2414) == NTAG(TAG_True)));
  heff_drop(v_x1_2414);
  return v_ret_24bool;
}
V g_heff_2ebuild_2edriver_2ewithHiddenOne_lam3(V self, V *args) {
  V v_g2_2416 = args[0];
  V v_o_2417 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_strAppend(heff_get_n(v_o_2417, 1, 2), ((V)&g_heff_2ebuild_2edriver_2ewithHiddenOne_str0));
  V v_t_2419 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_g2_2416, 6), v_t_2418, heff_get_n(v_c_241, 0, 14)));
  return ({ V rv_6 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_g2_2416, 447ULL, 9, shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances, 249855u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ebuild_2edriver_2egivesWay_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2egivesWay_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2egivesWay_entry, 3, 0};

V g_heff_2ebuild_2edriver_2egivesWay(V v_unwritten_240, V v_imported_241, V v_o_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_o_242, 2))}));
  V v_t_244 = (g_list_2eany(v_t_243, v_unwritten_240));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    return (g_heff_2ebuild_2edriver_2eanyD(heff_clo_n(g_heff_2ebuild_2edriver_2egivesWay_lam0, 1, 2, (V[]){v_o_242, heff_dup(v_unwritten_240)}), v_imported_241));
  } else {
    heff_drop_rec(v_o_242, 3);
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edriver_2egivesWay_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2egivesWay(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2egivesWay_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_unwritten_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_p_245, 0)), heff_dup(heff_rfield(v_o_242, 0))) && ({ V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_p_245, 2))})); int c_ = ({ V v_x1_248 = (g_list_2eany(heff_dup(v_t_247), v_unwritten_240)); int c_ = !(heff_dup(v_x1_248) == NTAG(TAG_True)); heff_drop(v_x1_248); c_; }); heff_drop(v_t_247); c_; })));
  heff_drop_rec(v_p_245, 3);
  heff_drop_rec(v_o_242, 3);
  heff_drop(v_unwritten_240);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasModule_str0, 1, "#");
Clo g_heff_2ebuild_2edriver_2ealiasModule_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasModule_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ealiasModule(V v_g_240, V v_q_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2eelab_2eglobals_2elookupKey_24cpr(heff_dup(v_g_240), heff_dup(heff_rfield(v_q_241, 1))));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_q_241, 2);
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_MkPair: {
        heff_take_n(v_it1_246, 0ULL, 2);
        return v_g_240;
      }
      default: return heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_244);
      V v_t_249 = heff_strAppend(heff_take_field(v_q_241, 0), ((V)&g_heff_2ebuild_2edriver_2ealiasModule_str0));
      V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_g_240, 2), heff_get_n(v_q_241, 1, 2), v_t_249));
      return ({ V rv_2 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_g_240, 507ULL, 9, shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances, 262095u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    }
  }
}
V g_heff_2ebuild_2edriver_2ealiasModule_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ealiasModule(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eexposedInstances_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2eexposedInstances_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eexposedInstances_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexposedInstances_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eexposedInstances(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_241, 8, 9)));
  V v_t_243 = (g_list_2emap_24f902549164x1589757410(heff_dup(v_c_240), v_t_242));
  return (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eexposedInstances_lam0, 1, 1, (V[]){v_c_240}), v_t_243));
}
V g_heff_2ebuild_2edriver_2eexposedInstances_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eexposedInstances(a[0]);
}
V g_heff_2ebuild_2edriver_2eexposedInstances_lam1(V self, V *args) {
  V v_o_248 = args[0];
  V v_es_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_o_248, 0, 2); V a_1 = v_es_247; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_247); r_; });
}
V g_heff_2ebuild_2edriver_2eexposedInstances_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_own_245 = heff_take_field(v_c_240, 7);
  V v_t_246 = heff_get_n(v_c_240, 13, 14);
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_249 = v_own_245;
    break;
  }
  case TAG_Just: {
    V v_es_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_249 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eexposedInstances_lam1, 1, 1, (V[]){v_es_247}), v_own_245));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return ({ V a_0 = v_k_244; V a_1 = v_t_249; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s62568991x6102141(a_0, a_1)); heff_drop(v_k_244); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithImportedInstances_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithImportedInstances(V v_done_240, V v_modules_241, V v_g_242) {
top: ;
  HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0, 2, 1, (V[]){v_done_240}), v_g_242, v_modules_241);
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ewithImportedInstances(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1(V self, V *args) {
  V v_g3_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_rec_n(2, shape_key__module, (V[]){heff_dup(v_k_2412), heff_get_n(v_c_249, 0, 14)});
  V v_t_2414 = ({ V a_0 = v_k_2412; V a_1 = heff_take_field(v_g3_2411, 8); V r_ = (g_list_2efilter_24s716173495x680820632(a_0, a_1)); heff_drop(v_k_2412); r_; });
  return ({ V rv_8 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2414}); V rr_ = heff_rec_reuse_nf(v_g3_2411, 255ULL, 9, shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0(V self, V *args) {
  V v_g2_243 = args[0];
  V v_m_244 = args[1];
  V v_done_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V a_0 = v_done_240; V a_1 = v_m_244; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindChecked_24cpr(a_0, a_1)); heff_drop(v_m_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_247;
      V v_t_2410 = (g_heff_2ebuild_2edriver_2eexposedInstances(heff_dup(v_c_249)));
      return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1, 2, 1, (V[]){v_c_249}); V a_1 = v_g2_243; V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    } else {
      heff_drop(v_field_247);
      return v_g2_243;
    }
  }
}
Clo g_heff_2ebuild_2edriver_2eopenNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eopenNames_24dps_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eopenNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_i_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_i_242, 1);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_i_242, 0, 3), heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_i_242, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eopenNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eopenNames_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructIdxGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2estructIdxGo(V v_i_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_242, heff_dup(heff_rfield(v_r_243, 1)), heff_dup(v_i_240)));
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_t_245;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_m_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2estructIdxGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ecloseTermF_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ecloseTermF_lam2(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTermF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SGlobal: {
    V v_k_246 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SGlobal = heff_take_reuse_n(v_e_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_idx_241, v_k_246));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_j_2411 = v_field_249;
        if (heff_intLt_c_lent(v_j_2411, v_i_242, 0)) {
          heff_drop(v_k_246);
          heff_drop_cell(v_ru_24e_244_24SGlobal, 1);
          V v_t_2413 = heff_intSub(heff_intSub(v_i_242, MK_INT(1LL)), v_j_2411);
          return heff_tag_n(TAG_SLocal, 1, (V[]){heff_intAdd(v_depth_243, v_t_2413)});
        } else {
          heff_drop(v_i_242);
          heff_drop(v_depth_243);
          heff_drop(v_j_2411);
          return heff_tag_at_n(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, (V[]){v_k_246});
        }
      } else {
        heff_drop(v_i_242);
        heff_drop(v_depth_243);
        heff_drop(v_field_249);
        return heff_tag_at_n(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, (V[]){v_k_246});
      }
    }
  }
  case TAG_SCode: {
    V v_t_2414 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCode = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2414}));
    return heff_tag_at_n(v_ru_24e_244_24SCode, TAG_SCode, 1, (V[]){v_t_2415});
  }
  case TAG_SApp: {
    V v_f_2416 = heff_field(v_e_244, 0);
    V v_a2_2417 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SApp = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_f_2416}));
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_a2_2417}));
    return heff_tag_at_n(v_ru_24e_244_24SApp, TAG_SApp, 2, (V[]){v_t_2418, v_t_2419});
  }
  case TAG_SLam: {
    V v_t_2420 = heff_field(v_e_244, 0);
    V v_b_2421 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SLam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2422 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2420}));
    V v_t_2428;
    switch (heff_tag_of(v_b_2421)) {
    case TAG_MkAbs: {
      V v_x_2423 = heff_field(v_b_2421, 0);
      V v_t_2424 = heff_field(v_b_2421, 1);
      V v_ru_24b_2421_24MkAbs = heff_take_reuse_n(v_b_2421, 3ULL, 2);
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2424}));
      v_t_2428 = heff_tag_at_n(v_ru_24b_2421_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2423, v_t_2425});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2426 = heff_field(v_b_2421, 0);
      V v_ru_24b_2421_24AbsConst = heff_take_reuse_n(v_b_2421, 1ULL, 1);
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2426}));
      v_t_2428 = heff_tag_at_n(v_ru_24b_2421_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2427});
      break;
    }
    default: heff_nomatch(v_b_2421);
    }
    return heff_tag_at_n(v_ru_24e_244_24SLam, TAG_SLam, 2, (V[]){v_t_2422, v_t_2428});
  }
  case TAG_SCons: {
    V v_d_2429 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCons = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_xs_2430 = heff_take_field(v_d_2429, 2);
    V v_t_2433 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2430, 0), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTermF_lam0, 1, 4, (V[]){v_xs_2430, v_r_240, v_i_242, v_depth_243}));
    V v_t_2434 = ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_d_2429, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_244_24SCons, TAG_SCons, 1, (V[]){v_t_2434});
  }
  case TAG_SProj: {
    V v_e2_2435 = heff_field(v_e_244, 0);
    V v_l_2436 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SProj = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2435}));
    return heff_tag_at_n(v_ru_24e_244_24SProj, TAG_SProj, 2, (V[]){v_t_2437, v_l_2436});
  }
  case TAG_STag: {
    V v_t_2438 = heff_field(v_e_244, 0);
    V v_as_2439 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24STag = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2441 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTermF_lam1, 1, 3, (V[]){v_r_240, v_i_242, v_depth_243}), heff_arrayToList(v_as_2439)));
    return heff_tag_at_n(v_ru_24e_244_24STag, TAG_STag, 2, (V[]){v_t_2438, heff_arrayFromList(v_t_2441)});
  }
  case TAG_SMatch: {
    V v_e2_2442 = heff_field(v_e_244, 0);
    V v_cs_2443 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2442}));
    V v_xs_2445 = heff_take_field(v_cs_2443, 2);
    V v_t_2452 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2445, 0), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTermF_lam2, 1, 4, (V[]){v_xs_2445, v_r_240, v_i_242, v_depth_243}));
    V v_t_2453 = ({ V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_cs_2443, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_244_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, v_t_2453});
  }
  case TAG_SSpecialize: {
    V v_e2_2454 = heff_field(v_e_244, 0);
    V v_l_2455 = heff_field(v_e_244, 1);
    V v_v_2456 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SSpecialize = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2454}));
    V v_t_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_v_2456}));
    return heff_tag_at_n(v_ru_24e_244_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2457, v_l_2455, v_t_2458});
  }
  case TAG_SIs: {
    V v_e2_2459 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SIs = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2459}));
    return heff_tag_at_n(v_ru_24e_244_24SIs, TAG_SIs, 1, (V[]){v_t_2460});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SRec: {
    V v_e2_2461 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SRec = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2462 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2461}));
    return heff_tag_at_n(v_ru_24e_244_24SRec, TAG_SRec, 1, (V[]){v_t_2462});
  }
  case TAG_SFix: {
    V v_t_2463 = heff_field(v_e_244, 0);
    V v_b_2464 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SFix = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2465 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2463}));
    V v_t_2471;
    switch (heff_tag_of(v_b_2464)) {
    case TAG_MkAbs: {
      V v_x_2466 = heff_field(v_b_2464, 0);
      V v_t_2467 = heff_field(v_b_2464, 1);
      V v_ru_24b_2464_24MkAbs = heff_take_reuse_n(v_b_2464, 3ULL, 2);
      V v_t_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2467}));
      v_t_2471 = heff_tag_at_n(v_ru_24b_2464_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2466, v_t_2468});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2469 = heff_field(v_b_2464, 0);
      V v_ru_24b_2464_24AbsConst = heff_take_reuse_n(v_b_2464, 1ULL, 1);
      V v_t_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2469}));
      v_t_2471 = heff_tag_at_n(v_ru_24b_2464_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2470});
      break;
    }
    default: heff_nomatch(v_b_2464);
    }
    return heff_tag_at_n(v_ru_24e_244_24SFix, TAG_SFix, 2, (V[]){v_t_2465, v_t_2471});
  }
  case TAG_SImplicit: {
    V v_x_2472 = heff_field(v_e_244, 0);
    V v_e2_2473 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SImplicit = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2473}));
    return heff_tag_at_n(v_ru_24e_244_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2472, v_t_2474});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_e_244, 0);
    V v_xs_2477 = heff_field(v_e_244, 1);
    V v_t_2478 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SMetaApp = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2479 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2478}));
    return heff_tag_at_n(v_ru_24e_244_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2476, v_xs_2477, v_t_2479});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ecloseTermF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam0(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_e2_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_i_242;
  heff_room[1] = v_depth_243;
  heff_room[2] = v_e2_2432;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam1(V self, V *args) {
  V v_e2_2440 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_i_242 = heff_env(self)[1];
  V v_depth_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_i_242;
  heff_room[1] = v_depth_243;
  heff_room[2] = v_e2_2440;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
    V v_t_2450 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_2448)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, v_t_2450), v_b_2449}));
    return heff_tag_at_n(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2451});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ethawedChecked_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2ethawedChecked_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2ethawedChecked_str2, 1, ".");
V g_heff_2ebuild_2edriver_2ethawedChecked_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ethawedChecked_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ethawedChecked(V v_s_240, V v_imps_241, V v_th_242, V v_t_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_imps_241, 2));
  V v_own_249;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_own_245 = ({ V a_0 = heff_dup(heff_rfield(v_s_240, 0)); V a_1 = ((V)&g_heff_2ebuild_2edriver_2ethawedChecked_str0); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_243, 2)); V r_ = (g_list_2efilter_24f1300261417x1763075249(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    v_own_249 = v_own_245;
    break;
  }
  case TAG_Just: {
    V v_h_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_own_247 = ({ V a_0 = heff_dup(heff_rfield(v_s_240, 0)); V a_1 = ((V)&g_heff_2ebuild_2edriver_2ethawedChecked_str1); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_243, 2)); V r_ = (g_list_2efilter_24f1300261417x1763075249(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    v_own_249 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2ethawedChecked_lam0, 1, 1, (V[]){v_h_246}), v_own_247));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_globals_2410 = (g_heff_2ebuild_2edriver_2emoduleStruct(heff_dup(heff_rfield(v_s_240, 0)), v_own_249, heff_take_field(v_t_243, 0)));
  V v_own_2411 = ({ V a_0 = heff_dup(heff_rfield(v_s_240, 0)); V a_1 = ((V)&g_heff_2ebuild_2edriver_2ethawedChecked_str2); V b_2 = MK_INT(0LL); V a_3 = MK_INT(1LL); V a_4 = heff_dup(heff_rfield(v_t_243, 2)); V r_ = (g_list_2efilter_24f1300261417x1763075249(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  V v_t_2412 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_241, 0))));
  V v_deps_2413 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2412));
  V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2415 = (g_list_2edrop(v_t_2414, heff_rfield(v_imps_241, 0)));
  V v_opens_2416 = (g_heff_2ebuild_2edriver_2eopenNames(v_t_2415));
  V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2418 = (g_list_2edrop(v_t_2417, heff_rfield(v_imps_241, 0)));
  V v_aliases_2419 = (g_heff_2ebuild_2edriver_2ealiasPairs(v_t_2418));
  V v_t_2420 = ({ V rv_0 = v_globals_2410; V rr_ = heff_rec_reuse_nf(v_t_243, 510ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2421 = heff_get_n(v_imps_241, 2, 4);
  V v_t_2423;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_h_2422 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    v_t_2423 = heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){heff_get_n(v_h_2422, 0, 3)});
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  return heff_rec_n(14, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached__exposes, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 2)), heff_get_n(v_s_240, 3, 7), NTAG(TAG_Nil), v_t_2420, NTAG(TAG_Nil), v_own_2411, v_deps_2413, v_opens_2416, v_aliases_2419, heff_get_n(v_th_242, 0, 3), NTAG(TAG_True), v_t_2423});
}
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ethawedChecked(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edriver_2ethawedChecked_lam0(V self, V *args) {
  V v_o_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_o_248, 0, 2); V b_1 = heff_get_n(v_h_246, 0, 3); V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str1, 17, "` is listed twice");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str2, 40, "` has no tags to expose: list it bare, `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str5, 23, "the module defines no `");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexposedDiag_str6, 37, "`: a header lists its own definitions");
Clo g_heff_2ebuild_2edriver_2eexposedDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexposedDiag_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eexposedDiag(V v_g_240, V v_own_241, V v_before_242, V v_x_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348(heff_rfield(v_x_243, 0), v_before_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_own_241);
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2ebuild_2edriver_2elistedName(heff_take_field(v_x_243, 0)));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str0), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str1)));
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_246, heff_get_n(v_x_243, 2, 3), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_244);
    HeffT2 v_t_248 = (g_heff_2ebuild_2edriver_2eownKeyOf_24cpr(v_own_241, heff_rfield(v_x_243, 0)));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_k_2412 = v_field_2410;
        V v_t_2413 = heff_take_field(v_x_243, 1);
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          V v_x1_2414 = ({ V a_0 = v_g_240; V a_1 = v_k_2412; V r_ = (g_heff_2ebuild_2edriver_2eisDataKey(a_0, a_1)); heff_drop(v_k_2412); r_; });
          if ((heff_dup(v_x1_2414) == NTAG(TAG_True))) {
            heff_drop_rec(v_x_243, 3);
            heff_drop(v_x1_2414);
            return NTAG(TAG_Nil);
          } else {
            heff_drop(v_x1_2414);
            V v_t_2415 = (g_heff_2ebuild_2edriver_2elistedName(heff_dup(heff_rfield(v_x_243, 0))));
            V v_t_2416 = (g_heff_2ebuild_2edriver_2elistedName(heff_take_field(v_x_243, 0)));
            V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str2), heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str3)));
            V v_msg_2418 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str4), heff_strAppend(v_t_2415, v_t_2417));
            V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_2418, heff_get_n(v_x_243, 2, 3), NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
          }
        } else {
          heff_drop(v_g_240);
          heff_drop_rec(v_x_243, 3);
          heff_drop(v_k_2412);
          heff_drop(v_t_2413);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_field_2410);
        V v_t_2420 = (g_heff_2eelab_2eglobals_2eisBroken(v_g_240, heff_rfield(v_x_243, 0)));
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop_rec(v_x_243, 3);
          heff_drop(v_t_2420);
          return NTAG(TAG_Nil);
        } else {
          heff_drop(v_t_2420);
          V v_t_2421 = (g_heff_2ebuild_2edriver_2elistedName(heff_take_field(v_x_243, 0)));
          V v_msg_2422 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str5), heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2edriver_2eexposedDiag_str6)));
          V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(155LL), NTAG(TAG_SError), v_msg_2422, heff_get_n(v_x_243, 2, 3), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2eexposedDiag_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eexposedDiag(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701(V v_lit_240, V v_lit_241, V v_g_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 7);
    heff_drop(v_lit_241);
    return v_g_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_rest_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_std_2emap_2edelete_24s339308281x1667047697(heff_take_field(v_g_242, 4), v_x_244));
    V v_t_247 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_strAppend(heff_dup(v_lit_241), heff_dup(v_x_244)));
    V v_t_248 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_g_242, 2), heff_dup(v_x_244), v_t_247));
    V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_lit_240, 0)), heff_strAppend(heff_dup(v_lit_241), heff_dup(v_x_244)));
    V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_g_242, 3), v_t_249, NTAG(TAG_MkUnit)));
    V v_t_2411 = ({ V rv_2 = v_t_248; V rv_3 = v_t_2410; V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_g_242, 483ULL, 9, shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances, 261135u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2411;
    V t_3 = v_rest_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_g_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabRead_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabRead_str1, 1, ".");
Clo g_heff_2ebuild_2edriver_2eelabRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabRead_entry, 6, 0};

V g_heff_2ebuild_2edriver_2eelabRead(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244, V v_r_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_s_241, 6));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_g0_247 = (g_heff_2ebuild_2edriver_2ewithParseBroken_24s1307036810x1641682701(heff_dup(v_s_241), ((V)&g_heff_2ebuild_2edriver_2eelabRead_str0), v_g0_244, heff_rfield(v_r_245, 3)));
    V v_t_248 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_g0_247, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_249 = (g_list_2emap_24s1960706388x853997965(heff_dup(heff_rfield(v_r_245, 0))));
    V v_t_2410 = ({ V a_0 = heff_dup(heff_rfield(v_s_241, 0)); V a_1 = ((V)&g_heff_2ebuild_2edriver_2eelabRead_str1); V a_2 = v_t_248; V a_3 = v_t_249; V r_ = (g_heff_2eelab_2etoplevel_2etopGo_24s1529097332x1150887916(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
    return (g_heff_2ebuild_2edriver_2eelabTop(v_s_241, v_imps_242, v_direct_243, v_r_245, v_t_2410));
  } else {
    heff_drop(v_t_246);
    V v_t_2411 = (g_list_2emap_24s1535007417x1587061701(heff_dup(heff_rfield(v_r_245, 0))));
    V v_refused_2412 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2411));
    V v_t_2413 = (g_list_2emap_24s1534167768x1221742344(heff_dup(v_refused_2412)));
    V v_t_2414 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_r_245, 1), v_t_2413));
    V v_t_2415 = (g_list_2emap_24s1937570095x2110149801(v_refused_2412));
    V v_t_2416 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_r_245, 3), v_t_2415));
    V v_t_2417 = heff_rec_n(4, shape_decls__diags__fixities__broken, (V[]){heff_dup(heff_rfield(v_r_245, 0)), v_t_2414, heff_take_field(v_r_245, 2), v_t_2416});
    V v_t_2418 = (g_list_2efilter_24s1725367856x1498536808(heff_get_n(v_r_245, 0, 4)));
    return (g_heff_2ebuild_2edriver_2eelabDecls(v_done_240, v_s_241, v_imps_242, v_direct_243, v_g0_244, v_t_2417, v_t_2418));
  }
}
V g_heff_2ebuild_2edriver_2eelabRead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2eelabRead(a0, a[1], a[2], a3, a[4], a[5]); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_entry, 1, 0};

V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ebuild_2edriver_2ebrokenIn(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(v_xs_242));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2eelabClashed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabClashed_entry, 8, 0};

V g_heff_2ebuild_2edriver_2eelabClashed(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_direct_244, V v_needed_245, V v_imported_246, V v_clashes_247) {
top: ;
  V v_t_248 = (g_list_2emap_24s1817208647x1282894070(heff_dup(heff_rfield(v_imps_242, 0))));
  V v_t_249 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_248));
  V v_qs_2410 = (g_heff_2ebuild_2edriver_2ealiasPairs(heff_dup(heff_rfield(v_imps_242, 0))));
  V v_g_2411 = (g_list_2efoldl_24s1261443129x1682844402(heff_dup(g_heff_2eelab_2eglobals_2eemptyGlobals_get()), v_needed_245));
  V v_t_2412 = (g_list_2efoldl_24s1722922134x788519507(v_g_2411, v_needed_245));
  V v_t_2413 = (g_heff_2ebuild_2edriver_2ealiasOpen(heff_dup(v_done_240), v_clashes_247, v_t_2412, v_imported_246));
  V v_t_2414 = (g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(v_direct_244));
  V v_t_2415 = (g_heff_2ebuild_2edriver_2ealiasOpen(heff_dup(v_done_240), v_clashes_247, v_t_2413, v_t_2414));
  V v_t_2416 = (g_heff_2ebuild_2edriver_2ealiasPairs(heff_dup(heff_rfield(v_imps_242, 0))));
  V v_g_2417 = ({ V a_0 = heff_dup(v_done_240); V a_1 = v_t_2415; V a_2 = v_t_2416; V r_ = (g_heff_2ebuild_2edriver_2ealiasQualified(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  V v_t_2418 = (g_list_2efoldl_24s1122556128x1089664899(v_g_2417, v_direct_244));
  V v_t_2419 = ({ V a_0 = heff_dup(v_done_240); V a_1 = v_t_2418; V a_2 = v_qs_2410; V r_ = (g_list_2efoldl_24s1973731134x151660308(a_0, a_1, a_2)); heff_drop(v_qs_2410); r_; });
  V v_g0_2420 = ({ V a_0 = heff_dup(v_done_240); V a_1 = v_t_249; V a_2 = v_t_2419; V r_ = (g_heff_2ebuild_2edriver_2ewithImportedInstances(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  switch (heff_tag_of(v_thaw_243)) {
  case TAG_Nothing: {
    return ({ V a_0 = v_done_240; V a_1 = v_s_241; V a_2 = v_imps_242; V a_3 = v_direct_244; V a_4 = v_g0_2420; V r_ = (g_heff_2ebuild_2edriver_2eelabEnv(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_done_240); r_; });
  }
  case TAG_Just: {
    V v_th_2421 = heff_field(v_thaw_243, 0);
    heff_drop(v_done_240);
    V v_t_2422 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_g0_2420, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2423 = (g_list_2efoldl_24s337463599x663364213(v_t_2422, heff_rfield(v_th_2421, 1)));
    V v_t_2424 = (g_heff_2eelab_2etoplevel_2ethawDone(v_t_2423));
    return (g_heff_2ebuild_2edriver_2ethawedChecked(v_s_241, v_imps_242, heff_dup(v_th_2421), v_t_2424));
  }
  default: return heff_nomatch(v_thaw_243);
  }
}
V g_heff_2ebuild_2edriver_2eelabClashed_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_heff_2ebuild_2edriver_2eelabClashed(a[0], a[1], a[2], a3, a4, a5, a[6], a7); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etypeArgsOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etypeArgsOf(V v_lvl_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LikeU: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFunction: {
    V v_dom_244 = heff_field(v_x2_241, 1);
    V v_cod_245 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 4);
    V v_t_247 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(v_lvl_240), heff_dup(v_dom_244)));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_x1_2414;
      switch (heff_tag_of(v_cod_245)) {
      case TAG_MkClo: {
        V v_vs_249 = heff_field(v_cod_245, 1);
        V v_body_2410 = heff_field(v_cod_245, 2);
        heff_take_n(v_cod_245, 6ULL, 3);
        v_x1_2414 = heff_tr(heff_call(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ebuild_2edriver_2etypeArgsOf_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_244})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2413 = heff_field(v_cod_245, 0);
        heff_take_n(v_cod_245, 1ULL, 1);
        heff_drop(v_dom_244);
        v_x1_2414 = v_body_2413;
        break;
      }
      default: heff_nomatch(v_cod_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nom: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        v_t_2418 = v_x_2415;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        v_t_2418 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2417 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        v_t_2418 = v_x_2417;
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2419 = (g_heff_2eelab_2evalue_2ebehavior(v_t_2418));
      V v_t_2420 = (g_heff_2ebuild_2edriver_2etypeArgsOf(heff_intAdd(v_lvl_240, MK_INT(1LL)), v_t_2419));
      return heff_intAdd(MK_INT(1LL), v_t_2420);
    } else {
      heff_drop(v_lvl_240);
      heff_drop(v_dom_244);
      heff_drop(v_cod_245);
      heff_drop(v_t_247);
      return MK_INT(0LL);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeSum: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeArray: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etypeArgsOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_244;
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ebuild_2edriver_2etypeArgsOf_lam1, 1, 1, (V[]){v_dom_244}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalWatch_str0, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalWatch_str1, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalWatch_str2, 15, "<compiler bug: ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalWatch_str3, 1, ">");
Clo g_heff_2ebuild_2edriver_2eevalWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevalWatch_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eevalWatch(V v_ge_240, V v_entry_241) {
top: ;
  V v_x1_242 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(v_ge_240, heff_take_field(v_entry_241, 0), MK_INT(0LL)));
  V v_t_243 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_entry_241, 3, 4)));
  V v_t_244 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_243));
  V v_t_247;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    v_t_247 = heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_RSucceeded, 1, (V[]){v_v_245});
    break;
  }
  case TAG_Abn: {
    v_t_247 = NTAG(TAG_RAbandoned);
    break;
  }
  case TAG_Div: {
    v_t_247 = NTAG(TAG_RDiverged);
    break;
  }
  case TAG_Bug: {
    V v_what_246 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    v_t_247 = heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_RBug, 1, (V[]){v_what_246});
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_x1_248 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_244, v_t_247));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_RSucceeded: {
    V v_v_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_249; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_RAbandoned: {
    return ((V)&g_heff_2ebuild_2edriver_2eevalWatch_str0);
  }
  case TAG_RDiverged: {
    return ((V)&g_heff_2ebuild_2edriver_2eevalWatch_str1);
  }
  case TAG_RBug: {
    V v_what_2410 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eevalWatch_str2), heff_strAppend(v_what_2410, ((V)&g_heff_2ebuild_2edriver_2eevalWatch_str3)));
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2ebuild_2edriver_2eevalWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eevalWatch(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ewatchesOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewatchesOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewatchesOf(V v_c_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_ws_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 14);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_gs_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
    V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewatchesOf_lam0, 2, 1, (V[]){heff_dup(v_gs_244)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_gs_244, 0, 9); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_ge_2413 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2einterp_2eglobalEnvGo(a_0, a_1)); heff_drop(v_t_2412); r_; });
    HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ewatchesOf_lam1, 1, 2, (V[]){v_c_240, v_ge_2413}), v_ws_241);
  }
  default: return heff_nomatch(v_ws_241);
  }
}
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewatchesOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_k_246 = args[1];
  V v_gs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_gs_244, 1, 9); V a_1 = v_k_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_e_2411 = v_field_249;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_246, v_e_2411}), v_acc_245});
    } else {
      heff_drop(v_k_246);
      heff_drop(v_field_249);
      return v_acc_245;
    }
  }
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam1(V self, V *args) {
  V v_w_2414 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ge_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2edriver_2ewatchInfo(v_c_240, v_ge_2413, v_w_2414));
}
V g_heff_2ebuild_2edriver_2etestOwner_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2etestOwner_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etestOwner_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etestOwner(V v_c_240, V v_from_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 9);
  V v_x1_249 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), heff_clo_n(g_heff_2ebuild_2edriver_2etestOwner_lam0, 1, 2, (V[]){v_from_241, v_c_240}), v_t_242));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2410, 0, 2)});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2ebuild_2edriver_2etestOwner_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etestOwner(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2etestOwner_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_from_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_m_243, 1)), 0, 2);
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_t_244, v_from_241, 0) && ({ V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9); int c_ = ({ V v_t_247 = (g_list_2emap_24s1354328764x1362350361(heff_dup(v_t_246))); int c_ = ({ V v_x1_248 = (g_list_2eany_24s2062006893x520992087(heff_dup(v_m_243), heff_dup(v_from_241), v_t_247)); int c_ = !(heff_dup(v_x1_248) == NTAG(TAG_True)); heff_drop(v_x1_248); c_; }); heff_drop(v_t_247); c_; }); heff_drop(v_t_246); c_; })));
  heff_drop_rec(v_m_243, 2);
  heff_drop(v_from_241);
  heff_drop_rec(v_c_240, 14);
  heff_drop(v_t_244);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2etestReportOf_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2etestReportOf_str1, 1, "\012");
Clo g_heff_2ebuild_2edriver_2etestReportOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etestReportOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etestReportOf(V v_c_240, V v_w_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_w_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_dup(heff_rfield(v_w_241, 6));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 14);
      heff_drop_rec(v_w_241, 10);
      heff_drop(v_t_243);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_243);
      V v_t_244 = heff_dup(heff_rfield(v_w_241, 9));
      V v_t_2412;
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
        V v_t_246 = ({ V a_0 = heff_dup(heff_rfield(v_w_241, 1)); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_245; V r_ = (g_list_2efoldl_24s75764538x1218461500(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
        switch (heff_tag_of(v_t_246)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_p_247 = heff_field(v_t_246, 0);
          V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
          V v_t_2410;
          switch (heff_tag_of(v_p_247)) {
          case TAG_MkPair: {
            V v_x_248 = heff_field(v_p_247, 0);
            heff_take_n(v_p_247, 1ULL, 2);
            v_t_2410 = v_x_248;
            break;
          }
          default: heff_nomatch(v_p_247);
          }
          V v_t_2411 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_t_2410));
          v_t_2412 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_t_2411});
          break;
        }
        default: heff_nomatch(v_t_246);
        }
      } else {
        heff_drop(v_t_244);
        v_t_2412 = (g_heff_2ebuild_2edriver_2etestOwner(heff_dup(v_c_240), heff_dup(heff_rfield(v_w_241, 0))));
      }
      V v_src_2413 = heff_get_n(v_c_240, 3, 14);
      V v_j_2414 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2etestReportOf_str0), v_src_2413, MK_INT(0LL), 5);
      V v_t_2416;
      if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
        heff_drop(v_j_2414);
        v_t_2416 = NTAG(TAG_Nothing);
      } else {
        v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2414});
      }
      V v_t_2417 = ({ V a_0 = v_src_2413; V a_1 = heff_dup(heff_rfield(v_w_241, 0)); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2416; V r_ = (g_heff_2elsp_2erender_2elineColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2413); r_; });
      V v_t_2418 = heff_intAdd(heff_get_n(v_t_2417, 0, 3), MK_INT(1LL));
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_owner__line__watch, (V[]){v_t_2412, v_t_2418, v_w_241})});
    }
  }
  case TAG_Just: {
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 0ULL, 1);
    V v_t_2420 = heff_dup(heff_rfield(v_w_241, 9));
    V v_t_2428;
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
      V v_t_2422 = ({ V a_0 = heff_dup(heff_rfield(v_w_241, 1)); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2421; V r_ = (g_list_2efoldl_24s75764538x1218461500(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_242_24Just, 1);
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_p_2423 = heff_field(v_t_2422, 0);
        heff_take_n(v_t_2422, 1ULL, 1);
        V v_t_2426;
        switch (heff_tag_of(v_p_2423)) {
        case TAG_MkPair: {
          V v_x_2424 = heff_field(v_p_2423, 0);
          heff_take_n(v_p_2423, 1ULL, 2);
          v_t_2426 = v_x_2424;
          break;
        }
        default: heff_nomatch(v_p_2423);
        }
        V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_t_2426));
        v_t_2428 = heff_tag_at_n(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_t_2427});
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
    } else {
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      heff_drop(v_t_2420);
      v_t_2428 = (g_heff_2ebuild_2edriver_2etestOwner(heff_dup(v_c_240), heff_dup(heff_rfield(v_w_241, 0))));
    }
    V v_src_2429 = heff_get_n(v_c_240, 3, 14);
    V v_j_2430 = heff_strFind_lent(((V)&g_heff_2ebuild_2edriver_2etestReportOf_str1), v_src_2429, MK_INT(0LL), 5);
    V v_t_2432;
    if (heff_intLt_c_lent(v_j_2430, MK_INT(0LL), 2)) {
      heff_drop(v_j_2430);
      v_t_2432 = NTAG(TAG_Nothing);
    } else {
      v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2430});
    }
    V v_t_2433 = ({ V a_0 = v_src_2429; V a_1 = heff_dup(heff_rfield(v_w_241, 0)); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = v_t_2432; V r_ = (g_heff_2elsp_2erender_2elineColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2429); r_; });
    V v_t_2434 = heff_intAdd(heff_get_n(v_t_2433, 0, 3), MK_INT(1LL));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_owner__line__watch, (V[]){v_t_2428, v_t_2434, v_w_241})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etestReportOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str7, 0, "");
Clo g_heff_2ebuild_2edriver_2epromoteAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2epromoteAt_entry, 4, 0};

V g_heff_2ebuild_2edriver_2epromoteAt(V v_s_240, V v_from_241, V v_to_242, V v_lines_243) {
top: ;
  V v_t_247;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), v_from_241, 2), ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str0))) {
    v_t_247 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str1);
  } else {
    V v_t_245 = heff_strSlice(heff_dup(v_s_240), heff_intSub(heff_dup(v_from_241), MK_INT(1LL)), heff_dup(v_from_241));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str2))) {
      v_t_247 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str3);
    } else {
      v_t_247 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str4);
    }
  }
  V v_x2_248 = (g_list_2emap_24s1366476796x894764441(((V)&g_heff_2ebuild_2edriver_2epromoteAt_str5), v_lines_243));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str7); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2412 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_to_242), heff_strLength_lent(v_s_240, 0));
  V v_t_2413 = heff_strAppend(v_t_247, heff_strAppend(v_t_2411, v_t_2412));
  return heff_strAppend(heff_strSlice_lent(v_s_240, MK_INT(0LL), v_from_241, 6), v_t_2413);
}
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2epromoteAt(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eisTestEl_str0, 10, "check.Test");
Clo g_heff_2ebuild_2edriver_2eisTestEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisTestEl_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eisTestEl(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    V v_k_242 = heff_field(v_x1_240, 0);
    return heff_strEq_lent(v_k_242, ((V)&g_heff_2ebuild_2edriver_2eisTestEl_str0), 2);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eisTestEl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eisTestEl(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisTestOwn_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eisTestOwn(V v_c_240, V v_o_241) {
top: ;
  V v_g_242 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 9);
  V v_k_243 = heff_get_n(v_o_241, 1, 2);
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_242, 1), v_k_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop_rec(v_g_242, 9);
      heff_drop(v_k_243);
      V v_e_248 = v_field_246;
      V v_t_249 = heff_get_n(v_e_248, 1, 4);
      switch (heff_tag_of(v_t_249)) {
      case TAG_SU: {
        heff_take_n(v_t_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SDecode: {
        V v_t_2411 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        return ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2edriver_2eisTestEl(a_0)); heff_drop(v_t_2411); r_; });
      }
      case TAG_SFunction: {
        heff_take_n(v_t_249, 0ULL, 5);
        return NTAG(TAG_False);
      }
      case TAG_SRecord: {
        heff_take_n(v_t_249, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_SSum: {
        heff_take_n(v_t_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SIsTy: {
        heff_take_n(v_t_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SPrimInt: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimFloat: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimString: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimRune: {
        return NTAG(TAG_False);
      }
      case TAG_SPrimArray: {
        heff_take_n(v_t_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_SFixed: {
        heff_take_n(v_t_249, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_249);
      }
    } else {
      heff_drop(v_field_246);
      HeffT2 v_t_2424 = ({ V a_0 = heff_rfield(v_g_242, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_k2_2428 = v_field_2426;
          HeffT2 v_t_2429 = ({ V b_0 = heff_get_n(v_g_242, 1, 9); V a_1 = v_k2_2428; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2428); r_; });
          {
            V v_field_2431 = v_t_2429.f[1];
            int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
            if ((v_tag_2430 == ((int64_t)0ULL))) {
              V v_e_2433 = v_field_2431;
              V v_t_2434 = heff_get_n(v_e_2433, 1, 4);
              switch (heff_tag_of(v_t_2434)) {
              case TAG_SU: {
                heff_take_n(v_t_2434, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SDecode: {
                V v_t_2436 = heff_field(v_t_2434, 0);
                heff_take_n(v_t_2434, 1ULL, 1);
                return ({ V a_0 = v_t_2436; V r_ = (g_heff_2ebuild_2edriver_2eisTestEl(a_0)); heff_drop(v_t_2436); r_; });
              }
              case TAG_SFunction: {
                heff_take_n(v_t_2434, 0ULL, 5);
                return NTAG(TAG_False);
              }
              case TAG_SRecord: {
                heff_take_n(v_t_2434, 0ULL, 3);
                return NTAG(TAG_False);
              }
              case TAG_SSum: {
                heff_take_n(v_t_2434, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SIsTy: {
                heff_take_n(v_t_2434, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SPrimInt: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimFloat: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimString: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimRune: {
                return NTAG(TAG_False);
              }
              case TAG_SPrimArray: {
                heff_take_n(v_t_2434, 0ULL, 1);
                return NTAG(TAG_False);
              }
              case TAG_SFixed: {
                heff_take_n(v_t_2434, 0ULL, 1);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_t_2434);
              }
            } else {
              heff_drop(v_field_2431);
              return NTAG(TAG_False);
            }
          }
        } else {
          heff_drop_rec(v_g_242, 9);
          heff_drop(v_field_2426);
          return NTAG(TAG_False);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eisTestOwn(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eownUses_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eownUses_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eownUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eownUses_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eownUses(V v_c_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_242, 1), v_k_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop_rec(v_g_242, 9);
      V v_e_247 = v_field_245;
      V v_t_248 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_247, 0, 4)));
      V v_t_249 = (g_heff_2eelab_2erename_2enubFirst(v_t_248));
      HEFF_LAST return g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eownUses_lam0, 1, 1, (V[]){v_c_240}), v_t_249);
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_242, 2), v_k_241));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_k2_2415 = v_field_2413;
          HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_g_242, 1, 9); V a_1 = v_k2_2415; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2415); r_; });
          {
            V v_field_2418 = v_t_2416.f[1];
            int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
            if ((v_tag_2417 == ((int64_t)0ULL))) {
              V v_e_2420 = v_field_2418;
              V v_t_2421 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_2420, 0, 4)));
              V v_t_2422 = (g_heff_2eelab_2erename_2enubFirst(v_t_2421));
              HEFF_LAST return g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eownUses_lam1, 1, 1, (V[]){v_c_240}), v_t_2422);
            } else {
              heff_drop_rec(v_c_240, 14);
              heff_drop(v_field_2418);
              return NTAG(TAG_Nil);
            }
          }
        } else {
          heff_drop_rec(v_c_240, 14);
          heff_drop_rec(v_g_242, 9);
          heff_drop(v_field_2413);
          return NTAG(TAG_Nil);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2eownUses_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eownUses(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2eownUses_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_u_2410; V b_1 = heff_get_n(v_c_240, 7, 14); V r_ = (g_list_2eany_24s359366115x1439523039(a_0, b_1)); heff_drop(v_u_2410); heff_drop(b_1); r_; });
}
V g_heff_2ebuild_2edriver_2eownUses_lam1(V self, V *args) {
  V v_u_2423 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_u_2423; V b_1 = heff_get_n(v_c_240, 7, 14); V r_ = (g_list_2eany_24s359366115x1439523039(a_0, b_1)); heff_drop(v_u_2423); heff_drop(b_1); r_; });
}
Clo g_heff_2ebuild_2edriver_2ereachOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ereachOwn_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ereachOwn(V v_c_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2eany_24s2065989517x1307020881(v_k_243, v_seen_241));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_k_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_c_240;
      V t_1 = v_seen_241;
      V t_2 = v_rest_244;
      v_c_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_t_246 = (g_heff_2ebuild_2edriver_2eownUses(heff_dup(v_c_240), v_k_243));
      V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_rest_244));
      V t_0 = v_c_240;
      V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_k_243, v_seen_241});
      V t_2 = v_t_247;
      v_c_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2ereachOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ereachOwn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2erootsAmong_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2erootsAmong_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2erootsAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2erootsAmong_entry, 2, 0};

V g_heff_2ebuild_2edriver_2erootsAmong(V v_c_240, V v_all_241) {
top: ;
  HEFF_LAST return g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2erootsAmong_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_all_241)}), v_all_241);
}
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2erootsAmong(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2erootsAmong_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_o_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = (g_heff_2ebuild_2edriver_2eownUses(heff_dup(v_c_240), heff_rfield(v_t_243, 1)));
  V v_t_245 = (g_heff_2ebuild_2edriver_2ereachOwn(v_c_240, NTAG(TAG_Nil), v_t_244));
  V v_t_246 = (g_list_2efilter_24s1646962431x688731818(v_t_243, v_t_245));
  return ({ V a_0 = v_o_242; V a_1 = v_t_246; V r_ = (g_list_2eany_24s1993301886x522650342(a_0, a_1)); heff_drop(v_t_246); r_; });
}
V g_heff_2ebuild_2edriver_2erootsAmong_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_all_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_247 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2erootsAmong_lam1, 1, 2, (V[]){v_c_240, v_o_242}); V a_1 = v_all_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_all_241); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
Clo g_heff_2ebuild_2edriver_2eisBenchOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisBenchOwn_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eisBenchOwn(V v_c_240, V v_o_241) {
top: ;
  V v_g_242 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 9);
  V v_k_243 = heff_get_n(v_o_241, 1, 2);
  HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_242, 1), v_k_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop_rec(v_g_242, 9);
      heff_drop(v_k_243);
      V v_e_248 = v_field_246;
      return ({ V b_0 = heff_get_n(v_e_248, 1, 4); V r_ = (g_heff_2ebuild_2edriver_2eisBenchTy(b_0)); heff_drop(b_0); r_; });
    } else {
      heff_drop(v_field_246);
      HeffT2 v_t_249 = ({ V a_0 = heff_rfield(v_g_242, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_k2_2413 = v_field_2411;
          HeffT2 v_t_2414 = ({ V b_0 = heff_get_n(v_g_242, 1, 9); V a_1 = v_k2_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2413); r_; });
          {
            V v_field_2416 = v_t_2414.f[1];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_e_2418 = v_field_2416;
              return ({ V b_0 = heff_get_n(v_e_2418, 1, 4); V r_ = (g_heff_2ebuild_2edriver_2eisBenchTy(b_0)); heff_drop(b_0); r_; });
            } else {
              heff_drop(v_field_2416);
              return NTAG(TAG_False);
            }
          }
        } else {
          heff_drop_rec(v_g_242, 9);
          heff_drop(v_field_2411);
          return NTAG(TAG_False);
        }
      }
    }
  }
}
V g_heff_2ebuild_2edriver_2eisBenchOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eisBenchOwn(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2eargV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eargV_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eargV(V v_v_240, V v_i_241) {
top: ;
  V v_t_2415;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_245 = heff_field(v_v_240, 1);
    v_t_2415 = heff_dup(v_vs_245);
    break;
  }
  case TAG_VInt: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat32: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRune: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBytes: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VBits: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  HeffT3 v_t_2416 = ({ V a_0 = v_i_241; V a_1 = v_t_2415; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2415); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    V v_field_2419 = v_t_2416.f[2];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_x_2421 = v_field_2418;
      V v_x12_2422 = v_field_2419;
      heff_drop(v_x12_2422);
      return v_x_2421;
    } else {
      heff_drop(v_field_2418);
      heff_drop(v_field_2419);
      return NTAG(TAG_VErased);
    }
  }
}
V g_heff_2ebuild_2edriver_2eargV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eargV(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str11, 4, "Cons");
Clo g_heff_2ebuild_2edriver_2elistOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elistOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elistOfV(V v_v_240) {
top: ;
  V v_t_2414;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_field(v_v_240, 0);
    v_t_2414 = heff_dup(v_x_243);
    break;
  }
  case TAG_VInt: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str7);
    break;
  }
  case TAG_VBytes: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str8);
    break;
  }
  case TAG_VBits: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str9);
    break;
  }
  case TAG_VErased: {
    v_t_2414 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str10);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2414, ((V)&g_heff_2ebuild_2edriver_2elistOfV_str11))) {
    V v_t_2429;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2419 = heff_field(v_v_240, 1);
      v_t_2429 = heff_dup(v_vs_2419);
      break;
    }
    case TAG_VInt: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2429 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2430 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2429; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2429); r_; });
    V v_t_2437;
    {
      V v_field_2432 = v_t_2430.f[1];
      V v_field_2433 = v_t_2430.f[2];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_x_2435 = v_field_2432;
        V v_x12_2436 = v_field_2433;
        heff_drop(v_x12_2436);
        v_t_2437 = v_x_2435;
      } else {
        heff_drop(v_field_2432);
        heff_drop(v_field_2433);
        v_t_2437 = NTAG(TAG_VErased);
      }
    }
    V v_cell_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_t_2452;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2442 = heff_field(v_v_240, 1);
      v_t_2452 = heff_dup(v_vs_2442);
      break;
    }
    case TAG_VInt: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    HeffT3 v_t_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2452; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2452); r_; });
    V v_t_2460;
    {
      V v_field_2455 = v_t_2453.f[1];
      V v_field_2456 = v_t_2453.f[2];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_x_2458 = v_field_2455;
        V v_x12_2459 = v_field_2456;
        heff_drop(v_x12_2459);
        v_t_2460 = v_x_2458;
      } else {
        heff_drop(v_field_2455);
        heff_drop(v_field_2456);
        v_t_2460 = NTAG(TAG_VErased);
      }
    }
    V v_u_2461 = (g_heff_2ebuild_2edriver_2elistOfV_24dps(v_t_2460, heff_dup(v_cell_2438)));
    heff_drop(v_u_2461);
    return v_cell_2438;
  } else {
    return NTAG(TAG_Nil);
  }
}
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2elistOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str0, 20, "> test integrations ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str1, 26, "check.integrationsSelected");
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str2, 7, "> test ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str3, 17, "check.runSelected");
Clo g_heff_2ebuild_2edriver_2eaddTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eaddTests_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eaddTests(V v_pattern_240, V v_seed_241, V v_i_242, V v_x4_243, V v_g_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_pattern_240);
    heff_drop(v_seed_241);
    heff_drop(v_i_242);
    return v_g_244;
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eaddTests_str0), heff_intShow(heff_dup(v_i_242)));
    V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_SApp, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2eaddTests_str1)}), heff_tag_n(TAG_SLitString, 1, (V[]){heff_dup(v_pattern_240)})});
    V v_t_249 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_dup(heff_rfield(v_o_245, 1))});
    V v_t_2410 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_t_248, v_t_249}), NTAG(TAG_SPrimInt), NTAG(TAG_VOpaque), NTAG(TAG_VPrimInt)});
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eaddTests_str2), heff_intShow(heff_dup(v_i_242)));
    V v_t_2412 = heff_tag_n(TAG_SApp, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2eaddTests_str3)}), heff_tag_n(TAG_SLitString, 1, (V[]){heff_dup(v_pattern_240)})});
    V v_t_2413 = heff_tag_n(TAG_SApp, 2, (V[]){v_t_2412, heff_tag_n(TAG_SLitInt, 1, (V[]){heff_dup(v_seed_241)})});
    V v_t_2414 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_get_n(v_o_245, 1, 2)});
    V v_t_2415 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_t_2413, v_t_2414}), NTAG(TAG_SPrimInt), NTAG(TAG_VOpaque), NTAG(TAG_VPrimInt)});
    V v_t_2416 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2411, v_t_2415, v_g_244));
    V v_t_2417 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_247, v_t_2410, v_t_2416));
    V t_0 = v_pattern_240;
    V t_1 = v_seed_241;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_rest_246;
    V t_4 = v_t_2417;
    v_pattern_240 = t_0;
    v_seed_241 = t_1;
    v_i_242 = t_2;
    v_x4_243 = t_3;
    v_g_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eaddTests(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLines_str0, 0, "");
Clo g_heff_2ebuild_2edriver_2efixityLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixityLines_entry, 3, 0};

V g_heff_2ebuild_2edriver_2efixityLines(V v_fx_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_fx_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2ebuild_2edriver_2efixityLines_str0);
  }
  case TAG_Cons: {
    V v_g_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_s_245 = (g_heff_2ebuild_2edriver_2efixityLine(heff_dup(v_fx_240), heff_dup(v_i_241), heff_dup(v_g_243)));
    return (g_heff_2ebuild_2edriver_2efixityLines_24acc(v_fx_240, heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL))), v_rest_244, v_s_245));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2efixityLines(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str5, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eglueOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eglueOne_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eglueOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_acc_240, 2);
  V v_t_247;
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str0);
  } else {
    heff_drop(v_t_242);
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_d_241, 0)) - ((int64_t)1ULL));
    V v_t_244 = heff_strFind(((V)&g_heff_2ebuild_2edriver_2eglueOne_str1), heff_strSlice_lent(v_d_241, MK_INT(0LL), heff_box_word(v_t_243), 6), MK_INT(0LL));
    if (heff_intLe_c(MK_INT(0LL), v_t_244)) {
      v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str2);
    } else {
      V v_t_246 = heff_dup(heff_rfield(v_acc_240, 1));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str3);
      } else {
        heff_drop(v_t_246);
        v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str4);
      }
    }
  }
  V v_t_248 = heff_strAppend(heff_get_n(v_acc_240, 0, 3), heff_strAppend(v_t_247, heff_dup(v_d_241)));
  int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_d_241, 0)) - ((int64_t)1ULL));
  V v_t_2410 = heff_strFind(((V)&g_heff_2ebuild_2edriver_2eglueOne_str5), heff_strSlice(v_d_241, MK_INT(0LL), heff_box_word(v_t_249)), MK_INT(0LL));
  return heff_rec_n(3, shape_out__multi__first, (V[]){v_t_248, heff_intLe(MK_INT(0LL), v_t_2410), NTAG(TAG_False)});
}
V g_heff_2ebuild_2edriver_2eglueOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eglueOne(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str0, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str4, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str5, 4, " as ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str8, 0, "");
Clo g_heff_2ebuild_2edriver_2eimportLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportLines_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eimportLines(V v_c_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ebuild_2edriver_2eimportLines_str0), ((V)&g_heff_2ebuild_2edriver_2eimportLines_str1), heff_take_field(v_c_240, 9)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = (g_list_2emap_24s984607094x1283457643(((V)&g_heff_2ebuild_2edriver_2eimportLines_str4), ((V)&g_heff_2ebuild_2edriver_2eimportLines_str5), ((V)&g_heff_2ebuild_2edriver_2eimportLines_str6), heff_get_n(v_c_240, 10, 14)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str8); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(v_t_244, v_t_248);
}
V g_heff_2ebuild_2edriver_2eimportLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eimportLines(a[0]);
}