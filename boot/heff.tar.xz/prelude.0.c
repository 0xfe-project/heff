// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_IAny 21222
#define TAG_IVal 40987
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SetPath 11095
#define LBL_at 9882
#define LBL_def 308863
#define LBL_field 298786068
#define LBL_labels 836724522
#define LBL_name 9869138
#define LBL_op 10312
#define LBL_param 307795111
#define LBL_path 9928940
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_slots 310891087
#define LBL_span 10032145
#define LBL_tys 324872
#define LBL_vars 10107635
static uint32_t shape_at__param__labels__tys__vars[] = {LBL_at, LBL_param, LBL_labels, LBL_tys, LBL_vars};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ecompile_2eearly_2eearlyDef(V);
V g_heff_2ecompile_2eearly_2eearlyDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eearlyDef_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
HeffT2 g_heff_2ecompile_2escalars_2edefWith_24cpr(V, V, V);
V g_heff_2ecompile_2escalars_2eslotsOf(V);
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotsOf_clo;
V g_heff_2ecompile_2esimplify_2etieOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etieOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieOne_clo;
V g_heff_2ecompile_2eunbox_2edefWith(V, V);
V g_heff_2ecompile_2eunbox_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eunbox_2edefWith_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2erules_2easSmall(V, V);
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2easSmall_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2epatName(V, V, V);
V g_heff_2eelab_2etoplevel_2epatName_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epatName_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2eupdatePath(V, V, V);
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo;
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(V);
V g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1476602679x302842688(V, V);
V g_list_2efoldl_24s1476602679x302842688_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1476602679x302842688_clo;
V g_list_2efoldl_24s1935134062x1256175429(V, V);
V g_list_2efoldl_24s1935134062x1256175429_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1935134062x1256175429_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s478414341x1543613922(V, V);
V g_list_2efoldl_24s478414341x1543613922_entry(V self, V *a);
extern Clo g_list_2efoldl_24s478414341x1543613922_clo;
V g_list_2efoldl_24s947545569x507961639(V, V);
V g_list_2efoldl_24s947545569x507961639_entry(V self, V *a);
extern Clo g_list_2efoldl_24s947545569x507961639_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24dps(V, V, V);
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24dps_clo;
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo;
V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_clo;
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo;
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(V, V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_24dps_clo;
V g_prelude_2e_2b_2b_24f1818809633x296343841_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f1818809633x296343841_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1818809633x296343841_24dps_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670(V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo;
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo;
V g_prelude_2e_2b_2b_24f354580856x2119298159(V, V, V, V);
V g_prelude_2e_2b_2b_24f354580856x2119298159_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f354580856x2119298159_clo;
V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_24dps_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(V, V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_clo;
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo;
V g_prelude_2e_2b_2b_24f714167978x1237207677(V, V, V, V);
V g_prelude_2e_2b_2b_24f714167978x1237207677_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f714167978x1237207677_clo;
V g_prelude_2e_2b_2b_24f714167978x1237207677_24dps(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f714167978x1237207677_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f714167978x1237207677_24dps_clo;
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps(V, V, V);
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f738852651x284559611_24dps_clo;
HeffT2 g_prelude_2edigitsFrom_24cpr(V, V, V);
V g_prelude_2emaybe_24s1822328499x1781525065(V, V);
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a);
extern Clo g_prelude_2emaybe_24s1822328499x1781525065_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2esplitFrom_2ebackwards_240(V, V);
V g_prelude_2esplitFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_2ebackwards_240_clo;
V g_prelude_2etraverse_24s1019364152x1582657694(V, V);
V g_prelude_2etraverse_24s1019364152x1582657694_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1019364152x1582657694_clo;
V g_prelude_2etraverse_24s1099455515x1225465224(V);
V g_prelude_2etraverse_24s1099455515x1225465224_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1099455515x1225465224_clo;
V g_prelude_2etraverse_24s1157078602x1175067503(V, V, V);
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1157078602x1175067503_clo;
V g_prelude_2etraverse_24s1211845059x266223635(V);
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1211845059x266223635_clo;
V g_prelude_2etraverse_24s1258110132x2117245331(V, V, V, V);
V g_prelude_2etraverse_24s1258110132x2117245331_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1258110132x2117245331_clo;
HeffT2 g_prelude_2etraverse_24s1266173017x1167058160_24cpr(V, V);
V g_prelude_2etraverse_24s1267794550x535874087(V, V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s1267794550x535874087_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1267794550x535874087_clo;
HeffT2 g_prelude_2etraverse_24s1267794550x535874087_24cpr(V, V, V, V, V, V, V, V, V);
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_prelude_2etraverse_24s1435890225x1582751312(V, V, V, V);
V g_prelude_2etraverse_24s1435890225x1582751312_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1435890225x1582751312_clo;
HeffT2 g_prelude_2etraverse_24s1483742185x1081287844_24cpr(V);
V g_prelude_2etraverse_24s1599688186x1142413429(V);
V g_prelude_2etraverse_24s1599688186x1142413429_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1599688186x1142413429_clo;
V g_prelude_2etraverse_24s1673840189x4008143(V, V);
V g_prelude_2etraverse_24s1673840189x4008143_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1673840189x4008143_clo;
HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V);
HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V, V);
V g_prelude_2etraverse_24s183237039x2129949159(V, V, V, V);
V g_prelude_2etraverse_24s183237039x2129949159_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s183237039x2129949159_clo;
V g_prelude_2etraverse_24s189232456x1797852535(V);
V g_prelude_2etraverse_24s189232456x1797852535_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s189232456x1797852535_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_prelude_2etraverse_24s247294553x1909820037(V, V, V, V);
V g_prelude_2etraverse_24s247294553x1909820037_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s247294553x1909820037_clo;
V g_prelude_2etraverse_24s251316015x352006831(V, V);
V g_prelude_2etraverse_24s251316015x352006831_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s251316015x352006831_clo;
V g_prelude_2etraverse_24s352965232x546119438(V, V);
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s352965232x546119438_clo;
HeffT2 g_prelude_2etraverse_24s366524614x1308602553_24cpr(V);
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s515579549x140669784(V);
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s515579549x140669784_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_prelude_2etraverse_24s564092924x2137198544(V);
V g_prelude_2etraverse_24s564092924x2137198544_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s564092924x2137198544_clo;
HeffT2 g_prelude_2etraverse_24s577758486x2142661336_24cpr(V, V);
V g_prelude_2etraverse_24s666910252x269127721(V);
V g_prelude_2etraverse_24s666910252x269127721_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s666910252x269127721_clo;
V g_prelude_2ewordsFrom(V, V, V, V);
V g_prelude_2ewordsFrom_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_clo;
V g_prelude_2ewordsFrom_2ebackwards_240(V, V);
V g_prelude_2ewordsFrom_2ebackwards_240_entry(V self, V *a);
extern Clo g_prelude_2ewordsFrom_2ebackwards_240_clo;
Clo g_prelude_2e_2b_2b_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_prelude_2e_2b_2b_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2esplitFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2esplitFrom_entry, 5, 0};

V g_prelude_2esplitFrom(V v_sep_240, V v_s_241, V v_i_242, V v_j_243, V v_acc_244) {
top: ;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    V v_t_246 = heff_strSlice(heff_dup(v_s_241), v_i_242, heff_strLength_lent(v_s_241, 0));
    return (g_prelude_2esplitFrom_2ebackwards_240(heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_acc_244}), NTAG(TAG_Nil)));
  } else {
    V v_t_247 = heff_intAdd(heff_dup(v_j_243), heff_strLength_lent(v_sep_240, 0));
    V v_t_248 = heff_intAdd(heff_dup(v_j_243), heff_strLength_lent(v_sep_240, 0));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_241, v_i_242, v_j_243, 6), v_acc_244});
    V t_0 = v_sep_240;
    V t_1 = v_s_241;
    V t_2 = v_t_247;
    V t_3 = heff_strFind_lent(v_sep_240, v_s_241, v_t_248, 4);
    V t_4 = v_t_249;
    v_sep_240 = t_0;
    v_s_241 = t_1;
    v_i_242 = t_2;
    v_j_243 = t_3;
    v_acc_244 = t_4;
    goto top;
  }
}
V g_prelude_2esplitFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2esplitFrom(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_prelude_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2ewordsFrom_entry, 4, 0};

V g_prelude_2ewordsFrom(V v_s_240, V v_start_241, V v_box_24i_242, V v_acc_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_242)) {
    V v_t_246;
    if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
      v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
    } else {
      heff_drop(v_start_241);
      v_t_246 = v_acc_243;
    }
    return (g_prelude_2ewordsFrom_2ebackwards_240(v_t_246, NTAG(TAG_Nil)));
  } else {
    V v_c_247 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_242), 2);
    V v_t_2411 = heff_bool(((heff_peek_word(v_c_247) == ((int64_t)32ULL)) || ((heff_peek_word(v_c_247) == ((int64_t)9ULL)) || ((heff_peek_word(v_c_247) == ((int64_t)10ULL)) || (heff_peek_word(v_c_247) == ((int64_t)13ULL))))));
    heff_drop(v_c_247);
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2413;
      if (heff_intLt_c_lent(v_start_241, heff_box_word(v_i_242), 2)) {
        v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_start_241, heff_box_word(v_i_242), 6), v_acc_243});
      } else {
        heff_drop(v_start_241);
        v_t_2413 = v_acc_243;
      }
      V t_0 = v_s_240;
      V t_1 = heff_box_word((v_i_242 + ((int64_t)1ULL)));
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_t_2413;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2411);
      V t_0 = v_s_240;
      V t_1 = v_start_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_start_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_prelude_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_prelude_2ewordsFrom(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_prelude_2eparseInt_24cpr_str0, 1, "-");

HeffT2 g_prelude_2eparseInt_24cpr(V v_s_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) == ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_prelude_2eparseInt_24cpr_str0))) {
      if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) == ((int64_t)1ULL))) {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        HeffT2 v_t_244 = (g_prelude_2edigitsFrom_24cpr(v_s_240, MK_INT(1LL), MK_INT(0LL)));
        {
          V v_field_246 = v_t_244.f[1];
          int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            V v_x_248 = v_field_246;
            V v_f_249 = heff_intSub(MK_INT(0LL), v_x_248);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
          } else {
            heff_drop(v_field_246);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    } else {
      return (g_prelude_2edigitsFrom_24cpr(v_s_240, MK_INT(0LL), MK_INT(0LL)));
    }
  }
}
V g_prelude_2etraverse_24s499544530x2060473942_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s499544530x2060473942_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s499544530x2060473942_lam0, 1, 0};
V g_prelude_2etraverse_24s499544530x2060473942_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s499544530x2060473942_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s499544530x2060473942_entry, 2, 0};

V g_prelude_2etraverse_24s499544530x2060473942(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s499544530x2060473942_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s499544530x2060473942_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s499544530x2060473942(a[0], a[1]);
}
V g_prelude_2etraverse_24s499544530x2060473942_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_prelude_2etraverse_24s499544530x2060473942_lam1(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_245);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_m_2413 = (g_prelude_2etraverse_24s499544530x2060473942(v_f_240, v_xs_245));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x11_249_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_x_2418})});
          return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_prelude_2etraverse_24s518454301x170091462_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s518454301x170091462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s518454301x170091462_lam0, 1, 0};
V g_prelude_2etraverse_24s518454301x170091462_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s518454301x170091462_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s518454301x170091462_entry, 1, 0};

V g_prelude_2etraverse_24s518454301x170091462(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s518454301x170091462_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_245 = (g_heff_2esyntax_2esurface_2edataParamL_24s1386959793x2028309826(v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s518454301x170091462_lam1, 1, 2, (V[]){v_m_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s518454301x170091462(a[0]);
}
V g_prelude_2etraverse_24s518454301x170091462_lam0(V self, V *args) {
  V v_st_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_st_241});
}
V g_prelude_2etraverse_24s518454301x170091462_lam1(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_xs_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_m_2412 = (g_prelude_2etraverse_24s518454301x170091462(v_xs_244));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop(v_x_2411);
          heff_drop_cell(v_ru_24x11_248_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417})});
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){v_t_2418, v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_prelude_2etraverse_24s2064368144x1684679122_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s2064368144x1684679122_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2064368144x1684679122_lam0, 1, 0};
V g_prelude_2etraverse_24s2064368144x1684679122_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s2064368144x1684679122_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s2064368144x1684679122_entry, 2, 0};

V g_prelude_2etraverse_24s2064368144x1684679122(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s2064368144x1684679122_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s2064368144x1684679122_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s2064368144x1684679122(a[0], a[1]);
}
V g_prelude_2etraverse_24s2064368144x1684679122_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s2064368144x1684679122_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s2064368144x1684679122(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s1258110132x2117245331_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1258110132x2117245331_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1258110132x2117245331_lam0, 1, 0};
V g_prelude_2etraverse_24s1258110132x2117245331_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1258110132x2117245331_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1258110132x2117245331_entry, 4, 0};

V g_prelude_2etraverse_24s1258110132x2117245331(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    return ((V)&g_prelude_2etraverse_24s1258110132x2117245331_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2esimplify_2etieOne(heff_dup(v_lit_240), v_lit_241, heff_dup(v_lit_242), v_x_245));
    return heff_clo_n(g_prelude_2etraverse_24s1258110132x2117245331_lam1, 1, 5, (V[]){v_m_247, v_lit_240, heff_dup(v_lit_241), v_lit_242, v_xs_246});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2etraverse_24s1258110132x2117245331_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2etraverse_24s1258110132x2117245331(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_prelude_2etraverse_24s1258110132x2117245331_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_244});
}
V g_prelude_2etraverse_24s1258110132x2117245331_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_xs_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_246; V r_ = (g_prelude_2etraverse_24s1258110132x2117245331(a_0, a_1, a_2, a_3)); heff_drop(v_lit_241); r_; });
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_prelude_2etraverse_24s251316015x352006831_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s251316015x352006831_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s251316015x352006831_lam0, 1, 0};
V g_prelude_2etraverse_24s251316015x352006831_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s251316015x352006831_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s251316015x352006831_entry, 2, 0};

V g_prelude_2etraverse_24s251316015x352006831(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s251316015x352006831_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s251316015x352006831_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s251316015x352006831_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s251316015x352006831(a[0], a[1]);
}
V g_prelude_2etraverse_24s251316015x352006831_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s251316015x352006831_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s251316015x352006831(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s1673840189x4008143_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1673840189x4008143_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1673840189x4008143_lam0, 1, 0};
V g_prelude_2etraverse_24s1673840189x4008143_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1673840189x4008143_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1673840189x4008143_entry, 2, 0};

V g_prelude_2etraverse_24s1673840189x4008143(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1673840189x4008143_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1673840189x4008143_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1673840189x4008143_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1673840189x4008143(a[0], a[1]);
}
V g_prelude_2etraverse_24s1673840189x4008143_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s1673840189x4008143_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s1673840189x4008143(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_prelude_2etraverse_24s1267794550x535874087_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1267794550x535874087_entry, 9, 0};

V g_prelude_2etraverse_24s1267794550x535874087(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_p_248) {
top: ;
  HeffT2 v_t_249 = (g_prelude_2etraverse_24s1267794550x535874087_24cpr(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_x2_247, v_p_248));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_2410, v_field_2411});
  }
}
V g_prelude_2etraverse_24s1267794550x535874087_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1267794550x535874087(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_prelude_2etraverse_24s247294553x1909820037_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s247294553x1909820037_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s247294553x1909820037_lam0, 1, 0};
V g_prelude_2etraverse_24s247294553x1909820037_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s247294553x1909820037_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s247294553x1909820037_entry, 4, 0};

V g_prelude_2etraverse_24s247294553x1909820037(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((V)&g_prelude_2etraverse_24s247294553x1909820037_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ecompile_2eir_2ebaseGo(v_x_245, heff_dup(v_lit_240)));
    return heff_clo_n(g_prelude_2etraverse_24s247294553x1909820037_lam1, 1, 5, (V[]){v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_a_247});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2etraverse_24s247294553x1909820037_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s247294553x1909820037(a[0], a[1], a[2], a[3]);
}
V g_prelude_2etraverse_24s247294553x1909820037_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_244});
}
V g_prelude_2etraverse_24s247294553x1909820037_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_xs_246 = heff_env(self)[3];
  V v_a_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_m_249 = (g_prelude_2etraverse_24s247294553x1909820037(v_lit_240, heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246));
  V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){heff_intAdd(heff_dup(v_n_248), v_lit_242)}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_strAppend(v_lit_241, heff_intShow(v_n_248));
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_a_247, v_t_2413), v_x_2411});
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_prelude_2etraverse_24s666910252x269127721_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s666910252x269127721_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s666910252x269127721_lam0, 1, 0};
V g_prelude_2etraverse_24s666910252x269127721_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s666910252x269127721_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s666910252x269127721_entry, 1, 0};

V g_prelude_2etraverse_24s666910252x269127721(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s666910252x269127721_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2eearly_2eearlyDef(v_x_242));
    return heff_clo_n(g_prelude_2etraverse_24s666910252x269127721_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s666910252x269127721_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s666910252x269127721(a[0]);
}
V g_prelude_2etraverse_24s666910252x269127721_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s666910252x269127721_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s666910252x269127721(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_prelude_2etraverse_24s352965232x546119438_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s352965232x546119438_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s352965232x546119438_lam0, 1, 0};
V g_prelude_2etraverse_24s352965232x546119438_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s352965232x546119438_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s352965232x546119438_entry, 2, 0};

V g_prelude_2etraverse_24s352965232x546119438(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s352965232x546119438_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_prelude_2etraverse_24s352965232x546119438_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s352965232x546119438(a[0], a[1]);
}
V g_prelude_2etraverse_24s352965232x546119438_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_243});
}
V g_prelude_2etraverse_24s352965232x546119438_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_xs_245);
    return heff_tag_at_n(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_m_2413 = (g_prelude_2etraverse_24s352965232x546119438(v_f_240, v_xs_245));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x2_2414, 0);
        V v_ru_24x2_2414_24Left = heff_take_reuse_n(v_x2_2414, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_248_24Right, 1);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24x21_2410_24MkPair, 2);
        return heff_tag_at_n(v_ru_24x2_2414_24Left, TAG_Left, 1, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x21_2416 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        switch (heff_tag_of(v_x21_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x21_2416, 0);
          V v_n_2418 = heff_field(v_x21_2416, 1);
          heff_take_n(v_x21_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417}), v_n_2418});
          return heff_tag_at_n(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_x21_2416);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}

HeffT2 g_prelude_2etraverse_24s1266173017x1167058160_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_prelude_2etraverse_24s577758486x2142661336_24cpr(heff_dup(heff_rfield(v_x_242, 2)), v_p_241));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_n_248 = v_field_246;
      HeffT2 v_t_249 = (g_prelude_2etraverse_24s1266173017x1167058160_24cpr(v_xs_243, v_n_248));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x_2412 = v_field_2410;
        V v_n_2413 = v_field_2411;
        V v_t_2414 = ({ V rv_4 = v_x_247; V rr_ = heff_rec_reuse_nf(v_x_242, 15ULL, 5, shape_at__param__labels__tys__vars, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        V v_f_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_x_2412});
        return ((HeffT2){{v_f_2415, v_n_2413}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s183237039x2129949159_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s183237039x2129949159_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s183237039x2129949159_lam0, 1, 0};
V g_prelude_2etraverse_24s183237039x2129949159_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s183237039x2129949159_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s183237039x2129949159_entry, 4, 0};

V g_prelude_2etraverse_24s183237039x2129949159(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((V)&g_prelude_2etraverse_24s183237039x2129949159_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ecompile_2eir_2ebaseGo(v_x_245, heff_dup(v_lit_240)));
    return heff_clo_n(g_prelude_2etraverse_24s183237039x2129949159_lam1, 1, 5, (V[]){v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_a_247});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2etraverse_24s183237039x2129949159_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s183237039x2129949159(a[0], a[1], a[2], a[3]);
}
V g_prelude_2etraverse_24s183237039x2129949159_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_244});
}
V g_prelude_2etraverse_24s183237039x2129949159_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_xs_246 = heff_env(self)[3];
  V v_a_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_m_249 = (g_prelude_2etraverse_24s183237039x2129949159(v_lit_240, heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246));
  V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){heff_intAdd(heff_dup(v_n_248), v_lit_242)}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_strAppend(v_lit_241, heff_intShow(v_n_248));
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_a_247, v_t_2413), v_x_2411});
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_prelude_2etraverse_24s564092924x2137198544_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s564092924x2137198544_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s564092924x2137198544_lam0, 1, 0};
V g_prelude_2etraverse_24s564092924x2137198544_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s564092924x2137198544_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s564092924x2137198544_entry, 1, 0};

V g_prelude_2etraverse_24s564092924x2137198544(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s564092924x2137198544_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2escalars_2eslotsOf(heff_dup(v_x_242)));
    return heff_clo_n(g_prelude_2etraverse_24s564092924x2137198544_lam1, 1, 3, (V[]){v_x_242, v_t_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s564092924x2137198544_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s564092924x2137198544(a[0]);
}
V g_prelude_2etraverse_24s564092924x2137198544_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s564092924x2137198544_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_t_244 = heff_env(self)[1];
  V v_xs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_246 = (g_heff_2ecompile_2escalars_2edefWith_24cpr(v_x_242, v_t_244, v_n_245));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x_249 = v_field_247;
    V v_n_2410 = v_field_248;
    V v_m_2411 = (g_prelude_2etraverse_24s564092924x2137198544(v_xs_243));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2413}), v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
}
V g_prelude_2etraverse_24s1019364152x1582657694_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1019364152x1582657694_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1019364152x1582657694_lam0, 1, 0};
V g_prelude_2etraverse_24s1019364152x1582657694_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1019364152x1582657694_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1019364152x1582657694_entry, 2, 0};

V g_prelude_2etraverse_24s1019364152x1582657694(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1019364152x1582657694_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1019364152x1582657694_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1019364152x1582657694_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1019364152x1582657694(a[0], a[1]);
}
V g_prelude_2etraverse_24s1019364152x1582657694_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_prelude_2etraverse_24s1019364152x1582657694_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s1019364152x1582657694(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2etraverse_24s1435890225x1582751312_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1435890225x1582751312_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1435890225x1582751312_lam0, 1, 0};
V g_prelude_2etraverse_24s1435890225x1582751312_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1435890225x1582751312_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1435890225x1582751312_entry, 4, 0};

V g_prelude_2etraverse_24s1435890225x1582751312(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((V)&g_prelude_2etraverse_24s1435890225x1582751312_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_heff_2ecompile_2eir_2ebaseGo(v_x_245, heff_dup(v_lit_240)));
    return heff_clo_n(g_prelude_2etraverse_24s1435890225x1582751312_lam1, 1, 5, (V[]){v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_a_247});
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_prelude_2etraverse_24s1435890225x1582751312_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1435890225x1582751312(a[0], a[1], a[2], a[3]);
}
V g_prelude_2etraverse_24s1435890225x1582751312_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_244});
}
V g_prelude_2etraverse_24s1435890225x1582751312_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_xs_246 = heff_env(self)[3];
  V v_a_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_m_249 = (g_prelude_2etraverse_24s1435890225x1582751312(v_lit_240, heff_dup(v_lit_241), heff_dup(v_lit_242), v_xs_246));
  V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){heff_intAdd(heff_dup(v_n_248), v_lit_242)}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_strAppend(v_lit_241, heff_intShow(v_n_248));
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_a_247, v_t_2413), v_x_2411});
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_prelude_2etraverse_24s1599688186x1142413429_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1599688186x1142413429_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1599688186x1142413429_lam0, 1, 0};
V g_prelude_2etraverse_24s1599688186x1142413429_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1599688186x1142413429_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1599688186x1142413429_entry, 1, 0};

V g_prelude_2etraverse_24s1599688186x1142413429(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1599688186x1142413429_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2eunbox_2edefWith(heff_take_field(v_x_242, 0), heff_get_n(v_x_242, 1, 2)));
    return heff_clo_n(g_prelude_2etraverse_24s1599688186x1142413429_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1599688186x1142413429_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1599688186x1142413429(a[0]);
}
V g_prelude_2etraverse_24s1599688186x1142413429_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_prelude_2etraverse_24s1599688186x1142413429_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_prelude_2etraverse_24s1599688186x1142413429(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str0, 3, "===");
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str1, 1, "<");
HEFF_LIT(g_prelude_2emaybe_24s1822328499x1781525065_str2, 2, "<=");
Clo g_prelude_2emaybe_24s1822328499x1781525065_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2emaybe_24s1822328499x1781525065_entry, 2, 0};

V g_prelude_2emaybe_24s1822328499x1781525065(V v_d_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nothing: {
    return v_d_240;
  }
  case TAG_Just: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24Just = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_d_240);
    V v_t_243 = heff_get_n(v_x_242, 1, 2);
    switch (heff_tag_of(v_t_243)) {
    case TAG_OpAdd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSub: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpMul: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpDiv: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpRem: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpEq: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str0)});
    }
    case TAG_OpLt: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str1)});
    }
    case TAG_OpLe: {
      return heff_tag_at_n(v_ru_24x3_241_24Just, TAG_Just, 1, (V[]){((V)&g_prelude_2emaybe_24s1822328499x1781525065_str2)});
    }
    case TAG_OpAnd: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpOr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpXor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShl: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShr: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpShow: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToInt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpSqrt: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFromFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpToFloat: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_OpFloor: {
      heff_drop_cell(v_ru_24x3_241_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_prelude_2emaybe_24s1822328499x1781525065_entry(V self, V *a) {
  (void)self;
  return g_prelude_2emaybe_24s1822328499x1781525065(a[0], a[1]);
}
V g_prelude_2etraverse_24s1362847681x1386678580_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1362847681x1386678580_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1362847681x1386678580_lam0, 1, 0};
V g_prelude_2etraverse_24s1362847681x1386678580_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1362847681x1386678580_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1362847681x1386678580_entry, 2, 0};

V g_prelude_2etraverse_24s1362847681x1386678580(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_prelude_2etraverse_24s1362847681x1386678580_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_prelude_2etraverse_24s1362847681x1386678580_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1362847681x1386678580(a[0], a[1]);
}
V g_prelude_2etraverse_24s1362847681x1386678580_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_prelude_2etraverse_24s1362847681x1386678580_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}

HeffT2 g_prelude_2etraverse_24s1807059150x502333573_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_err_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_245}});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      HeffT2 v_t_247 = (g_prelude_2etraverse_24s1807059150x502333573_24cpr(v_f_240, v_xs_243));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_x_246);
          V v_err_2411 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2411}});
        } else {
          V v_x_2412 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_x_2412})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1483742185x1081287844_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_a_244));
      {
        V v_field_247 = v_t_245.f[1];
        int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
        if ((v_tag_246 == ((int64_t)0ULL))) {
          heff_drop(v_xs_242);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_a_243);
          V v_a_249 = v_field_247;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_249}});
        } else {
          V v_a_2410 = v_field_247;
          HeffT2 v_t_2411 = (g_prelude_2etraverse_24s1483742185x1081287844_24cpr(v_xs_242));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24x2_240_24Cons, 2);
              heff_drop(v_a_243);
              heff_drop(v_a_2410);
              V v_err_2415 = v_field_2413;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2415}});
            } else {
              V v_x_2416 = v_field_2413;
              V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_243, v_a_2410}), v_x_2416});
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2417}});
            }
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}

HeffT2 g_prelude_2etraverse_24s1778157750x1229378888_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        heff_take_n(v_a_243, 12ULL, 4);
        HeffT2 v_t_249 = (g_prelude_2etraverse_24s366524614x1308602553_24cpr(v_a_247));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop(v_xs_242);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_a_248);
            V v_a_2413 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_a_2413}});
          } else {
            V v_a_2414 = v_field_2411;
            HeffT2 v_t_2415 = (g_prelude_2etraverse_24s1778157750x1229378888_24cpr(v_xs_242));
            {
              V v_field_2417 = v_t_2415.f[1];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                heff_drop_cell(v_ru_24x2_240_24Cons, 2);
                heff_drop(v_a_248);
                heff_drop(v_a_2414);
                V v_err_2419 = v_field_2417;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_err_2419}});
              } else {
                V v_x_2420 = v_field_2417;
                V v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_a_2414, v_a_248}), v_x_2420});
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2421}});
              }
            }
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_prelude_2etraverse_24s1157078602x1175067503_lam1(V self, V *args);
V g_prelude_2etraverse_24s1157078602x1175067503_lam0(V self, V *args);
Clo g_prelude_2etraverse_24s1157078602x1175067503_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1157078602x1175067503_entry, 3, 0};

V g_prelude_2etraverse_24s1157078602x1175067503(V v_x2_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    return ({ V a_0 = v_x_243; V a_1 = heff_dup(v_p_241); V a_2 = heff_clo_n(g_prelude_2etraverse_24s1157078602x1175067503_lam0, 1, 3, (V[]){v_xs_244, v_p_241, v_p_242}); V r_ = (g_heff_2eelab_2etoplevel_2epatName(a_0, a_1, a_2)); heff_drop(v_x_243); r_; });
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1157078602x1175067503(a[0], a[1], a[2]);
}
V g_prelude_2etraverse_24s1157078602x1175067503_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_a_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_a_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1157078602x1175067503_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_prelude_2etraverse_24s1157078602x1175067503(v_xs_244, v_p_241, heff_clo_n(g_prelude_2etraverse_24s1157078602x1175067503_lam1, 1, 2, (V[]){v_p_242, v_a_245})));
}
V g_prelude_2etraverse_24s515579549x140669784_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s515579549x140669784_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s515579549x140669784_lam0, 2, 0};
V g_prelude_2etraverse_24s515579549x140669784_lam2(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam1(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam5(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam4(V self, V *args);
V g_prelude_2etraverse_24s515579549x140669784_lam3(V self, V *args);
Clo g_prelude_2etraverse_24s515579549x140669784_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s515579549x140669784_entry, 1, 0};

V g_prelude_2etraverse_24s515579549x140669784(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s515579549x140669784_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_a_248 = heff_field(v_a_245, 1);
        heff_take_n(v_a_245, 3ULL, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_a_248));
        v_a_2414 = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam1, 2, 3, (V[]){v_a_249, v_a_246, v_a_247});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam3, 2, 2, (V[]){v_a_2414, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s515579549x140669784(a[0]);
}
V g_prelude_2etraverse_24s515579549x140669784_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam2(V self, V *args) {
  V v_a_2412 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = (g_heff_2eelab_2etoplevel_2eupdatePath(v_a_246, v_a_247, v_a_2412));
  V f_ = v_t_2413;
  heff_room[0] = v_a_2410;
  heff_room[1] = v_a_2411;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s515579549x140669784_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_2411 = args[1];
  V v_a_249 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_249;
  args[0] = heff_dup(v_a_2410);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam2, 1, 4, (V[]){v_a_246, v_a_247, v_a_2410, v_a_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_a_2416 = heff_env(self)[0];
  V v_a_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2416;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2417, v_a_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s515579549x140669784_lam4(V self, V *args) {
  V v_a_2417 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_2415 = heff_env(self)[1];
  V v_a_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_2418 = (g_prelude_2etraverse_24s515579549x140669784(v_xs_244));
  V f_ = v_a_2418;
  heff_room[0] = v_a_2415;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam5, 1, 2, (V[]){v_a_2416, v_a_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s515579549x140669784_lam3(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2416 = args[1];
  V v_a_2414 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2414;
  args[0] = heff_dup(v_a_2415);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s515579549x140669784_lam4, 1, 3, (V[]){v_xs_244, v_a_2415, v_a_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s189232456x1797852535_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s189232456x1797852535_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s189232456x1797852535_lam0, 2, 0};
V g_prelude_2etraverse_24s189232456x1797852535_lam3(V self, V *args);
V g_prelude_2etraverse_24s189232456x1797852535_lam2(V self, V *args);
V g_prelude_2etraverse_24s189232456x1797852535_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s189232456x1797852535_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s189232456x1797852535_entry, 1, 0};

V g_prelude_2etraverse_24s189232456x1797852535(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s189232456x1797852535_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s189232456x1797852535_lam1, 2, 2, (V[]){v_t_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s189232456x1797852535_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s189232456x1797852535(a[0]);
}
V g_prelude_2etraverse_24s189232456x1797852535_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s189232456x1797852535_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_248, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s189232456x1797852535_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = (g_prelude_2etraverse_24s189232456x1797852535(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s189232456x1797852535_lam3, 1, 2, (V[]){v_a_247, v_a_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s189232456x1797852535_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_t_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_245, heff_dup(v_a_246), heff_clo_n(g_prelude_2etraverse_24s189232456x1797852535_lam2, 1, 3, (V[]){v_xs_244, v_a_246, v_a_247})));
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1099455515x1225465224_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1099455515x1225465224_lam0, 2, 0};
V g_prelude_2etraverse_24s1099455515x1225465224_lam3(V self, V *args);
V g_prelude_2etraverse_24s1099455515x1225465224_lam2(V self, V *args);
V g_prelude_2etraverse_24s1099455515x1225465224_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1099455515x1225465224_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1099455515x1225465224_entry, 1, 0};

V g_prelude_2etraverse_24s1099455515x1225465224(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1099455515x1225465224_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s1099455515x1225465224_lam1, 2, 2, (V[]){v_a_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1099455515x1225465224_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1099455515x1225465224(a[0]);
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_a_248, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_249 = (g_prelude_2etraverse_24s1099455515x1225465224(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1099455515x1225465224_lam3, 1, 2, (V[]){v_a_247, v_a_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1099455515x1225465224_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1099455515x1225465224_lam2, 1, 3, (V[]){v_xs_244, v_a_246, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam0(V self, V *args); static Clo g_prelude_2etraverse_24s1211845059x266223635_lam0_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1211845059x266223635_lam0, 2, 0};
V g_prelude_2etraverse_24s1211845059x266223635_lam3(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam2(V self, V *args);
V g_prelude_2etraverse_24s1211845059x266223635_lam1(V self, V *args);
Clo g_prelude_2etraverse_24s1211845059x266223635_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2etraverse_24s1211845059x266223635_entry, 1, 0};

V g_prelude_2etraverse_24s1211845059x266223635(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_prelude_2etraverse_24s1211845059x266223635_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_x_243));
    return heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam1, 2, 3, (V[]){v_a_245, v_xs_244, v_x_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_prelude_2etraverse_24s1211845059x266223635_entry(V self, V *a) {
  (void)self;
  return g_prelude_2etraverse_24s1211845059x266223635(a[0]);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_a_242 = args[1];
  heff_drop(v_a_241);
  V f_ = v_a_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam3(V self, V *args) {
  V v_a_2410 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_a_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_x_243)) {
  case TAG_At: {
    V v_a_2412 = heff_field(v_x_243, 1);
    heff_take_n(v_x_243, 2ULL, 2);
    v_t_2413 = v_a_2412;
    break;
  }
  default: heff_nomatch(v_x_243);
  }
  V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_a_248; V r_ = (g_heff_2eelab_2erules_2easSmall(a_0, a_1)); heff_drop(v_a_248); r_; });
  V f_ = v_a_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_a_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_prelude_2etraverse_24s1211845059x266223635_lam2(V self, V *args) {
  V v_a_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_a_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_a_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_a_249 = (g_prelude_2etraverse_24s1211845059x266223635(v_xs_244));
  V f_ = v_a_249;
  heff_room[0] = v_a_246;
  heff_room[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam3, 1, 3, (V[]){v_x_243, v_a_248, v_a_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_prelude_2etraverse_24s1211845059x266223635_lam1(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  V v_a_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_245;
  args[0] = heff_dup(v_a_246);
  args[1] = heff_clo_n(g_prelude_2etraverse_24s1211845059x266223635_lam2, 1, 4, (V[]){v_xs_244, v_a_246, v_x_243, v_a_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_241))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 3);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1521533208x253309881_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f1521533208x253309881_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_243 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      if (heff_strEq_c_lent(v_x_245, ((V)&g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_str0), 2)) {
        heff_drop(v_x_245);
        return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
      } else {
        V v_t_247 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_t_247}));
      }
    }
    case TAG_PatTag: {
      V v_ps_2410 = heff_field(v_x11_243, 2);
      heff_take_n(v_x11_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2410));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2413);
    }
    case TAG_PatOp: {
      V v_ps_2416 = heff_field(v_x11_243, 2);
      heff_take_n(v_x11_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2416));
      V v_t_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1935134062x1256175429(a_0, a_1)); heff_drop(v_t_2417); r_; });
      V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2418, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2419);
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatFloat: {
      heff_take_na(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatString: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatRecord: {
      V v_fs_2425 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2425));
      V v_t_2427 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2426; V r_ = (g_list_2efoldl_24s947545569x507961639(a_0, a_1)); heff_drop(v_t_2426); r_; });
      V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2427, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatAs: {
      V v_x_2430 = heff_field(v_x11_243, 0);
      V v_q_2432 = heff_field(v_x11_243, 2);
      heff_take_n(v_x11_243, 5ULL, 3);
      V v_cell_2433 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2430, heff_hole()});
      V v_u_2434 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2433));
      heff_drop(v_u_2434);
      V t_0 = v_ys_240;
      V t_1 = v_q_2432;
      V t_2 = v_cell_2433;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1057423371x1101358195_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_entry, 2, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_241, 0);
    V v_xs_243 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_t_245 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_242); r_; });
    V v_u_246 = (g_prelude_2e_2b_2b_24f368057430x559112032_24dps(v_ys_240, v_t_245, heff_dup(v_cell_244)));
    heff_drop(v_u_246);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f368057430x559112032(a[0], a[1]);
}
Clo g_prelude_2e_2b_2b_24f368057430x559112032_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f368057430x559112032_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_243); r_; });
    V t_0 = v_ys_240;
    V t_1 = v_t_247;
    V t_2 = v_cell_245;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f368057430x559112032_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f368057430x559112032_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f714167978x1237207677_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f714167978x1237207677_entry, 4, 0};

V g_prelude_2e_2b_2b_24f714167978x1237207677(V v_ys_240, V v_lit_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_x3_243);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_x_244);
      heff_drop(v_xs_245);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      return v_ys_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
      V v_x_2411;
      switch (heff_tag_of(v_x_244)) {
      case TAG_MkPair: {
        V v_a_248 = heff_field(v_x_244, 0);
        V v_a_249 = heff_field(v_x_244, 1);
        heff_take_n(v_x_244, 3ULL, 2);
        if (heff_intEq_c_lent(v_y_246, v_lit_241, 1)) {
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop(v_a_248);
          v_x_2411 = heff_tag_n(TAG_IAny, 1, (V[]){v_a_249});
        } else {
          v_x_2411 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_IVal, 2, (V[]){v_a_248, v_a_249});
        }
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2413 = (g_prelude_2e_2b_2b_24f714167978x1237207677_24dps(v_ys_240, v_lit_241, v_xs_245, v_ys_247, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f714167978x1237207677_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f714167978x1237207677(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f489629841x1061860251_entry, 3, 0};

V g_prelude_2e_2b_2b_24f489629841x1061860251(V v_ys_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return (g_prelude_2e_2b_2b(v_ys_242, v_ys_240));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f489629841x1061860251_24dps(v_ys_240, v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f489629841x1061860251(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f709746438x971999636_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f709746438x971999636_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_x12_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x12_244)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_x12_244;
      V t_2 = v_cell_247;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x12_244);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_prelude_2e_2b_2b_24f709746438x971999636_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f709746438x971999636_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f58476578x2140998212_entry, 3, 0};

V g_prelude_2e_2b_2b_24f58476578x2140998212(V v_ys_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(v_ys_240, v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f58476578x2140998212(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(V v_ys_240, V v_f_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f58476578x2140998212_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f58476578x2140998212_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_strAppend(heff_dup(v_lit_241), v_x_243);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1306153264x1245859556(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_strAppend(heff_dup(v_lit_241), v_x_244);
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1306153264x1245859556_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_entry, 10, 0};

V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(V v_ys_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247, V v_x3_248, V v_d_249) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_x3_248);
    return heff_setField(v_d_249, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_247, 0);
    V v_xs_2411 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24Cons = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_244);
      heff_drop(v_lit_245);
      heff_drop(v_lit_246);
      heff_drop(v_x_2410);
      heff_drop(v_xs_2411);
      heff_drop_cell(v_ru_24x2_247_24Cons, 2);
      return heff_setField(v_d_249, MK_INT(1LL), v_ys_240);
    }
    case TAG_Cons: {
      V v_y_2412 = heff_field(v_x3_248, 0);
      V v_ys_2413 = heff_field(v_x3_248, 1);
      heff_take_n(v_x3_248, 3ULL, 2);
      V v_t_2414 = ({ V a_0 = v_x_2410; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V a_3 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2410); r_; });
      V v_t_2415 = heff_strAppend(heff_intShow(v_y_2412), heff_dup(v_lit_246));
      V v_x_2416 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2414), heff_strAppend(heff_dup(v_lit_245), v_t_2415));
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_247_24Cons, TAG_Cons, 2, (V[]){v_x_2416, heff_hole()});
      V v_u_2418 = heff_setField(v_d_249, MK_INT(1LL), heff_dup(v_cell_2417));
      heff_drop(v_u_2418);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_2411;
      V t_8 = v_ys_2413;
      V t_9 = v_cell_2417;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      v_x3_248 = t_8;
      v_d_249 = t_9;
      goto top;
    }
    default: return heff_nomatch(v_x3_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1727312714x1365290191_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
Clo g_prelude_2e_2b_2b_24f354580856x2119298159_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f354580856x2119298159_entry, 4, 0};

V g_prelude_2e_2b_2b_24f354580856x2119298159(V v_ys_240, V v_lit_241, V v_x1_242, V v_ys_243) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    V v_t_244 = (g_list_2emap_24s231073986x752637537(v_lit_241, v_ys_243));
    return (g_prelude_2e_2b_2b(v_t_244, v_ys_240));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_242, 0);
    V v_xs_246 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    V v_x_247 = heff_strAppend(heff_dup(v_lit_241), v_x_245);
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = (g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(v_ys_240, v_lit_241, v_xs_246, v_ys_243, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_prelude_2e_2b_2b_24f354580856x2119298159_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f354580856x2119298159(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_entry, 5, 0};

V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(V v_ys_240, V v_lit_241, V v_x1_242, V v_ys_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    V v_t_245 = (g_list_2emap_24s231073986x752637537(v_lit_241, v_ys_243));
    V v_t_246 = (g_prelude_2e_2b_2b(v_t_245, v_ys_240));
    return heff_setField(v_d_244, MK_INT(1LL), v_t_246);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_242, 0);
    V v_xs_248 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24Cons = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    V v_x_249 = heff_strAppend(heff_dup(v_lit_241), v_x_247);
    V v_cell_2410 = heff_tag_at_n(v_ru_24x1_242_24Cons, TAG_Cons, 2, (V[]){v_x_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_248;
    V t_3 = v_ys_243;
    V t_4 = v_cell_2410;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x1_242 = t_2;
    v_ys_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_prelude_2e_2b_2b_24f354580856x2119298159_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f354580856x2119298159_24dps(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1815933030x829523367_str0, 1, ":");
Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1815933030x829523367_entry, 2, 0};

V g_prelude_2e_2b_2b_24f1815933030x829523367(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_x_242, 0));
    V v_x_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_prelude_2e_2b_2b_24f1815933030x829523367_str0), v_x_242));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_prelude_2e_2b_2b_24f1815933030x829523367_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1815933030x829523367(a[0], a[1]);
}
HEFF_LIT(g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_str0, 1, "_");
Clo g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(V v_ys_240, V v_p_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_241, 0);
    V v_p2_244 = heff_field(v_p_241, 1);
    V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 3ULL, 2);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      if (heff_strEq_c_lent(v_x_245, ((V)&g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_str0), 2)) {
        heff_drop(v_p2_244);
        heff_drop(v_x_245);
        return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
      } else {
        V v_x_247 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_245, v_p2_244, NTAG(TAG_False)});
        V v_t_248 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_ys_240));
        return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_t_248}));
      }
    }
    case TAG_PatTag: {
      V v_ps_2411 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2411));
      V v_t_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2412); r_; });
      V v_t_2414 = (g_prelude_2e_2b_2b(v_t_2413, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
    }
    case TAG_PatOp: {
      V v_ps_2417 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2417));
      V v_t_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2418); r_; });
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2419, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2420);
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatBinary: {
      V v_segs_2424 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_segs_2424));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1476602679x302842688(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2426, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2427);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatRecord: {
      V v_fs_2429 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2429));
      V v_t_2431 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_list_2efoldl_24s478414341x1543613922(a_0, a_1)); heff_drop(v_t_2430); r_; });
      V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2431, v_ys_240));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2432);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop(v_p2_244);
      heff_drop_cell(v_ru_24p_241_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
    }
    case TAG_PatAs: {
      V v_x_2434 = heff_field(v_p1_243, 0);
      V v_sp_2435 = heff_field(v_p1_243, 1);
      V v_q_2436 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 7ULL, 3);
      heff_drop(v_p2_244);
      V v_x_2437 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2434, v_sp_2435, NTAG(TAG_False)});
      V v_cell_2438 = heff_tag_at_n(v_ru_24p_241_24At, TAG_Cons, 2, (V[]){v_x_2437, heff_hole()});
      V v_u_2439 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2438));
      heff_drop(v_u_2439);
      V t_0 = v_ys_240;
      V t_1 = v_q_2436;
      V t_2 = v_cell_2438;
      v_ys_240 = t_0;
      v_p_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_prelude_2e_2b_2b_24f1537904782x516751275_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f1537904782x516751275_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f227594336x1851497670_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f227594336x1851497670_entry, 3, 0};

V g_prelude_2e_2b_2b_24f227594336x1851497670(V v_ys_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_241), heff_hole()});
    V v_u_246 = (g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(v_ys_240, v_lit_241, v_xs_244, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f227594336x1851497670_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f227594336x1851497670(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 2ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_241), heff_hole()});
    V v_u_247 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_246;
    v_ys_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f227594336x1851497670_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f227594336x1851497670_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_prelude_2e_2b_2b_24f738852651x284559611_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f738852651x284559611_24dps_entry, 3, 0};

V g_prelude_2e_2b_2b_24f738852651x284559611_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_245 = (g_heff_2ebuild_2edriver_2elean(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_prelude_2e_2b_2b_24f738852651x284559611_24dps_entry(V self, V *a) {
  (void)self;
  return g_prelude_2e_2b_2b_24f738852651x284559611_24dps(a[0], a[1], a[2]);
}
Clo g_prelude_2e_2b_2b_24f1818809633x296343841_24dps_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2e_2b_2b_24f1818809633x296343841_24dps_entry, 4, 0};

V g_prelude_2e_2b_2b_24f1818809633x296343841_24dps(V v_ys_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241))) {
      heff_drop_rec(v_x_244, 14);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_ys_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_247;
      v_ys_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_prelude_2e_2b_2b_24f1818809633x296343841_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_prelude_2e_2b_2b_24f1818809633x296343841_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}