// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2eeffect_2eappendE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeffect_2eappendE_entry, 2, 0};

V g_heff_2eeffect_2eappendE(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eeffect_2eappendE(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eeffect_2eappendE_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeffect_2eappendE(a[0], a[1]);
}
Clo g_heff_2eeffect_2eleaves_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeffect_2eleaves_entry, 1, 0};

V g_heff_2eeffect_2eleaves(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Leaf: {
    V v_x_241 = heff_field(v_x1_240, 0);
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
  }
  case TAG_Plus: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_b_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2eeffect_2eleaves(v_a_242));
    V v_t_245 = (g_heff_2eeffect_2eleaves(v_b_243));
    return (g_heff_2eeffect_2eappendE(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eeffect_2eleaves_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eeffect_2eleaves(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eeffect_2edropLastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeffect_2edropLastD_entry, 1, 0};

V g_heff_2eeffect_2edropLastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2eeffect_2edropLastD(v_x12_242))});
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eeffect_2edropLastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeffect_2edropLastD(a[0]);
}
Clo g_heff_2eeffect_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeffect_2elastOr_entry, 2, 0};

V g_heff_2eeffect_2elastOr(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_d_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_d_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_d_240;
      V t_1 = v_x22_243;
      v_d_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eeffect_2elastOr_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eeffect_2elastOr(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eeffect_2eeffectOf_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 46, 112, 108, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eeffect_2eeffectOf_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 46, 60, 43, 62}};
Clo g_heff_2eeffect_2eeffectOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeffect_2eeffectOf_entry, 2, 0};

V g_heff_2eeffect_2eeffectOf(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_SLocal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    V v_k_243 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24SGlobal = heff_take_reuse_n(v_e_241, 1ULL, 1);
    V v_t_244 = (g_heff_2eglobals_2elookupEntry(heff_dup(v_g_240), heff_dup(v_k_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_g_240);
      return heff_tag_at(v_ru_24e_241_24SGlobal, TAG_Just, 1, (V[]){heff_tag(TAG_Leaf, 1, (V[]){v_k_243})});
    }
    case TAG_Just: {
      V v_entry_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_x2_246 = (g_heff_2eeffect_2eeffectOf(v_g_240, heff_get(v_entry_245, LBL_syntax)));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nothing: {
        return heff_tag_at(v_ru_24e_241_24SGlobal, TAG_Just, 1, (V[]){heff_tag(TAG_Leaf, 1, (V[]){v_k_243})});
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_x2_246, 0);
        heff_take_n(v_x2_246, 1ULL, 1);
        heff_drop(v_k_243);
        return heff_tag_at(v_ru_24e_241_24SGlobal, TAG_Just, 1, (V[]){v_e_247});
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    V v_it1_249 = heff_field(v_e_241, 0);
    V v_b_2410 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24SApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_it1_249)) {
    case TAG_SLocal: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      V v_k_2412 = heff_field(v_it1_249, 0);
      V v_ru_24it1_249_24SGlobal = heff_take_reuse_n(v_it1_249, 1ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return heff_tag_at(v_ru_24it1_249_24SGlobal, TAG_Just, 1, (V[]){heff_tag(TAG_Leaf, 1, (V[]){v_k_2412})});
    }
    case TAG_SCode: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      V v_it11_2414 = heff_field(v_it1_249, 0);
      V v_a_2415 = heff_field(v_it1_249, 1);
      heff_take_n(v_it1_249, 3ULL, 2);
      switch (heff_tag_of(v_it11_2414)) {
      case TAG_SLocal: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        V v_p_2417 = heff_field(v_it11_2414, 0);
        V v_ru_24it11_2414_24SGlobal = heff_take_reuse_n(v_it11_2414, 1ULL, 1);
        V v_t_2418 = heff_strEq(heff_dup(v_p_2417), ((V)&g_heff_2eeffect_2eeffectOf_str0));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          heff_drop(v_p_2417);
          V v_x1_2419 = (g_heff_2eeffect_2eeffectOf(heff_dup(v_g_240), v_a_2415));
          V v_x2_2420 = (g_heff_2eeffect_2eeffectOf(v_g_240, v_b_2410));
          switch (heff_tag_of(v_x1_2419)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24e_241_24SApp, 2);
            heff_drop_cell(v_ru_24it11_2414_24SGlobal, 1);
            heff_drop(v_x2_2420);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_a_2421 = heff_field(v_x1_2419, 0);
            heff_take_n(v_x1_2419, 1ULL, 1);
            switch (heff_tag_of(v_x2_2420)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24e_241_24SApp, 2);
              heff_drop_cell(v_ru_24it11_2414_24SGlobal, 1);
              heff_drop(v_a_2421);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_b_2422 = heff_field(v_x2_2420, 0);
              heff_take_n(v_x2_2420, 1ULL, 1);
              return heff_tag_at(v_ru_24it11_2414_24SGlobal, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24e_241_24SApp, TAG_Plus, 2, (V[]){v_a_2421, v_b_2422})});
            }
            default: return heff_nomatch(v_x2_2420);
            }
          }
          default: return heff_nomatch(v_x1_2419);
          }
        }
        case TAG_False: {
          V v_t_2423 = heff_strEq(v_p_2417, ((V)&g_heff_2eeffect_2eeffectOf_str1));
          switch (heff_tag_of(v_t_2423)) {
          case TAG_True: {
            V v_x1_2424 = (g_heff_2eeffect_2eeffectOf(heff_dup(v_g_240), v_a_2415));
            V v_x2_2425 = (g_heff_2eeffect_2eeffectOf(v_g_240, v_b_2410));
            switch (heff_tag_of(v_x1_2424)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24e_241_24SApp, 2);
              heff_drop_cell(v_ru_24it11_2414_24SGlobal, 1);
              heff_drop(v_x2_2425);
              return NTAG(TAG_Nothing);
            }
            case TAG_Just: {
              V v_a_2426 = heff_field(v_x1_2424, 0);
              heff_take_n(v_x1_2424, 1ULL, 1);
              switch (heff_tag_of(v_x2_2425)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24e_241_24SApp, 2);
                heff_drop_cell(v_ru_24it11_2414_24SGlobal, 1);
                heff_drop(v_a_2426);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_b_2427 = heff_field(v_x2_2425, 0);
                heff_take_n(v_x2_2425, 1ULL, 1);
                return heff_tag_at(v_ru_24it11_2414_24SGlobal, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24e_241_24SApp, TAG_Plus, 2, (V[]){v_a_2426, v_b_2427})});
              }
              default: return heff_nomatch(v_x2_2425);
              }
            }
            default: return heff_nomatch(v_x1_2424);
            }
          }
          case TAG_False: {
            heff_drop(v_g_240);
            heff_drop(v_b_2410);
            heff_drop_cell(v_ru_24e_241_24SApp, 2);
            heff_drop(v_a_2415);
            heff_drop_cell(v_ru_24it11_2414_24SGlobal, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2423);
          }
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      case TAG_SCode: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SApp: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCons: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMatch: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SIs: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SOpaque: {
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SAbandon: {
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SRec: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFix: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SImplicit: {
        heff_take_n(v_it11_2414, 0ULL, 2);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_it11_2414, 0ULL, 3);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitInt: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitString: {
        heff_take_n(v_it11_2414, 0ULL, 1);
        heff_drop(v_g_240);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24e_241_24SApp, 2);
        heff_drop(v_a_2415);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it11_2414);
      }
    }
    case TAG_SLam: {
      heff_take_n(v_it1_249, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_it1_249, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_it1_249, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_it1_249, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_it1_249, 0ULL, 3);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SOpaque: {
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_it1_249, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_it1_249, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_it1_249, 0ULL, 3);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_it1_249, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_b_2410);
      heff_drop_cell(v_ru_24e_241_24SApp, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_it1_249);
    }
  }
  case TAG_SLam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    V v_e_27_2493 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V t_0 = v_g_240;
    V t_1 = v_e_27_2493;
    v_g_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2eeffect_2eeffectOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eeffect_2eeffectOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eeffect_2ecomputationEffect_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 111, 46, 67, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eeffect_2ecomputationEffect_str1 = {{0x80000000u, K_STR, 0}, 10, 10, {99, 111, 46, 72, 97, 110, 100, 108, 101, 114}};
Clo g_heff_2eeffect_2ecomputationEffect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eeffect_2ecomputationEffect_entry, 2, 0};

V g_heff_2eeffect_2ecomputationEffect(V v_g_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SU: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SDecode: {
    V v_it1_243 = heff_field(v_t_241, 0);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_SLocal: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      V v_it11_247 = heff_field(v_it1_243, 0);
      switch (heff_tag_of(v_it11_247)) {
      case TAG_SLocal: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCode: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SApp: {
        V v_it111_2412 = heff_field(v_it11_247, 0);
        V v_h_2413 = heff_field(v_it11_247, 1);
        switch (heff_tag_of(v_it111_2412)) {
        case TAG_SLocal: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          V v_p_2415 = heff_field(v_it111_2412, 0);
          V v_t_2416 = heff_strEq(heff_dup(v_p_2415), ((V)&g_heff_2eeffect_2ecomputationEffect_str0));
          switch (heff_tag_of(v_t_2416)) {
          case TAG_True: {
            HEFF_LAST return g_heff_2eeffect_2eeffectOf(v_g_240, heff_dup(v_h_2413));
          }
          case TAG_False: {
            heff_drop(v_g_240);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2416);
          }
        }
        case TAG_SCode: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SOpaque: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it111_2412);
        }
      }
      case TAG_SLam: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCons: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMatch: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SSpecialize: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SIs: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SOpaque: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SAbandon: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SRec: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFix: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SImplicit: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMetaApp: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitInt: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitString: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it11_247);
      }
    }
    case TAG_SLam: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SOpaque: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  case TAG_SFunction: {
    V v_it2_2496 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_it2_2496)) {
    case TAG_SU: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SDecode: {
      V v_it21_24100 = heff_field(v_it2_2496, 0);
      switch (heff_tag_of(v_it21_24100)) {
      case TAG_SLocal: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCode: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SApp: {
        V v_it211_24104 = heff_field(v_it21_24100, 0);
        V v_h_24105 = heff_field(v_it21_24100, 1);
        switch (heff_tag_of(v_it211_24104)) {
        case TAG_SLocal: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          V v_p_24107 = heff_field(v_it211_24104, 0);
          V v_t_24108 = heff_strEq(heff_dup(v_p_24107), ((V)&g_heff_2eeffect_2ecomputationEffect_str1));
          switch (heff_tag_of(v_t_24108)) {
          case TAG_True: {
            HEFF_LAST return g_heff_2eeffect_2eeffectOf(v_g_240, heff_dup(v_h_24105));
          }
          case TAG_False: {
            heff_drop(v_g_240);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_24108);
          }
        }
        case TAG_SCode: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SOpaque: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_drop(v_g_240);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it211_24104);
        }
      }
      case TAG_SLam: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCons: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMatch: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SSpecialize: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SIs: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SOpaque: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SAbandon: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SRec: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFix: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SImplicit: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMetaApp: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitInt: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitString: {
        heff_drop(v_g_240);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it21_24100);
      }
    }
    case TAG_SFunction: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRecord: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSum: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIsTy: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimInt: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFloat: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimString: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimArray: {
      heff_drop(v_g_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_it2_2496);
    }
  }
  case TAG_SRecord: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSum: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIsTy: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrimInt: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrimString: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrimArray: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eeffect_2ecomputationEffect_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eeffect_2ecomputationEffect(a[0], a[1]); heff_drop(a[1]); return r;
}