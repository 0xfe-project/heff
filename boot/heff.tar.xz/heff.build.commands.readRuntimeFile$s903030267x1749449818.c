// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str1, 22, "heff: no C runtime at ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str3, 0, "");
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0(V v_st_240, V v_x_241, V v_name_242, V v_hd_243, V v_k_244, V v_x_245) {
top: ;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_ru_24x_245_24Left = heff_take_reuse_n(v_x_245, 0ULL, 1);
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_241));
    V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str0)));
    V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
    V v_a_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_2410));
    V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_name_242));
    V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
    V v_t_2414 = ({ V a_0 = v_st_240; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2413); r_; });
    V v_str_2415 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str1), v_t_2414);
    V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2415, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str2)), NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_at_n(v_ru_24x_245_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_lam0, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    heff_drop(v_st_240);
    heff_drop(v_x_241);
    heff_drop(v_name_242);
    heff_drop(v_hd_243);
    return heff_tail(v_k_244, 1, (V[]){v_y_2430});
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_244 = heff_env(self)[0];
  heff_drop(v_x_2429);
  heff_clo_take(self, 1);
  V f_ = v_k_244;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_str3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_drop(v_x_2422);
  V v_t_2423 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_243, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_lam1, 1, 1, (V[]){v_k_244})));
}