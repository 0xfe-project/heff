// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Doc 16324
#define TAG_EAnn 33099
#define TAG_EImplicitVar 16588
#define TAG_EMatch 41631
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Eqn 17358
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sig 30557
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_below 294979659
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_groups 709681407
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_waiting 1348170899
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2eanyS(V, V);
V g_heff_2esyntax_2esurface_2eanyS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eanyS_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eapplyPatOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyPatOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyPatOp_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2ebelowLoosest(V, V, V);
V g_heff_2esyntax_2esurface_2ebelowLoosest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebelowLoosest_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecycleDiag(V, V);
V g_heff_2esyntax_2esurface_2ecycleDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecycleDiag_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefNext(V, V, V);
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefNext_clo;
V g_heff_2esyntax_2esurface_2edocNext(V, V, V);
V g_heff_2esyntax_2esurface_2edocNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edocNext_clo;
V g_heff_2esyntax_2esurface_2efixDiagsOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo;
double g_heff_2esyntax_2esurface_2efloatOfDigits_w(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits(V);
V g_heff_2esyntax_2esurface_2efloatOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efloatOfDigits_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eisAnnE(V);
V g_heff_2esyntax_2esurface_2eisAnnE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisAnnE_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2epatTok(V);
V g_heff_2esyntax_2esurface_2epatTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTok_clo;
V g_heff_2esyntax_2esurface_2eplaceStep(V, V, V);
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceStep_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
V g_heff_2esyntax_2esurface_2eshortcut(V, V, V, V);
V g_heff_2esyntax_2esurface_2eshortcut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eshortcut_clo;
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f359508862x1661952287(V, V, V, V);
V g_list_2emap_24f359508862x1661952287_entry(V self, V *a);
extern Clo g_list_2emap_24f359508862x1661952287_clo;
V g_list_2emap_24f482741271x1112521151(V, V, V, V, V);
V g_list_2emap_24f482741271x1112521151_entry(V self, V *a);
extern Clo g_list_2emap_24f482741271x1112521151_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str0, 4, "Bool");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str1, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str2, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str3, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str4, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str5, 4, "Bool");
Clo g_heff_2esyntax_2esurface_2eshortcut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eshortcut_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eshortcut(V v_op_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_osp_244 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_240, 3)), heff_dup(heff_rfield(v_op_240, 4))});
  V v_osp_245 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_240, 3)), heff_dup(heff_rfield(v_op_240, 4))});
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EImplicitVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str0)}), heff_dup(v_osp_245)});
  V v_a_249;
  switch (heff_tag_of(v_c_241)) {
  case TAG_At: {
    V v_s_248 = heff_dup(heff_field(v_c_241, 1));
    v_a_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  V v_t_2410 = ({ V rv_1 = heff_get_n(v_osp_245, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_249, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){heff_dup(v_c_241), v_t_246}), v_t_2410});
  V v_tsp_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_240, 3)), heff_dup(heff_rfield(v_op_240, 4))});
  V v_t_2413 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str1), heff_dup(v_tsp_2412), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str2)}), heff_dup(v_tsp_2412)});
  V v_x1_2415 = ({ V a_0 = v_t_2414; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_b_2418;
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_At: {
    V v_s_2417 = heff_field(v_x1_2415, 1);
    heff_take_n(v_x1_2415, 2ULL, 2);
    v_b_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_x1_2415);
  }
  V v_t_2419 = ({ V rv_1 = heff_get_n(v_b_2418, 1, 2); V rr_ = heff_rec_reuse_nf(v_tsp_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_p_2420 = heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_t_2419});
  V v_a_2423;
  switch (heff_tag_of(v_p_2420)) {
  case TAG_At: {
    V v_s_2422 = heff_dup(heff_field(v_p_2420, 1));
    v_a_2423 = v_s_2422;
    break;
  }
  default: heff_nomatch(v_p_2420);
  }
  V v_b_2426;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2425 = heff_dup(heff_field(v_a_242, 1));
    v_b_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2427 = ({ V rv_1 = heff_get_n(v_b_2426, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2423, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2420, heff_dup(v_a_242)}), v_t_2427});
  V v_tsp_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_240, 3), heff_get_n(v_op_240, 4, 9)});
  V v_t_2430 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str3), heff_dup(v_tsp_2429), NTAG(TAG_Nil)});
  V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str4)}), heff_dup(v_tsp_2429)});
  V v_x1_2432 = ({ V a_0 = v_t_2431; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_b_2435;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_At: {
    V v_s_2434 = heff_field(v_x1_2432, 1);
    heff_take_n(v_x1_2432, 2ULL, 2);
    v_b_2435 = v_s_2434;
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  V v_t_2436 = ({ V rv_1 = heff_get_n(v_b_2435, 1, 2); V rr_ = heff_rec_reuse_nf(v_tsp_2429, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_p_2437 = heff_tag_n(TAG_At, 2, (V[]){v_t_2430, v_t_2436});
  V v_a_2440;
  switch (heff_tag_of(v_p_2437)) {
  case TAG_At: {
    V v_s_2439 = heff_dup(heff_field(v_p_2437, 1));
    v_a_2440 = v_s_2439;
    break;
  }
  default: heff_nomatch(v_p_2437);
  }
  V v_b_2443;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2442 = heff_dup(heff_field(v_b_243, 1));
    v_b_2443 = v_s_2442;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2444 = ({ V rv_1 = heff_get_n(v_b_2443, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2440, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2437, heff_dup(v_b_243)}), v_t_2444});
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
  V v_t_2447 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2446})});
  V v_t_2450;
  switch (heff_tag_of(v_c_241)) {
  case TAG_At: {
    V v_s_2449 = heff_field(v_c_241, 1);
    heff_take_n(v_c_241, 2ULL, 2);
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  V v_a_2451 = heff_get_n(v_t_2450, 0, 2);
  V v_t_2454;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2453 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 2ULL, 2);
    v_t_2454 = v_s_2453;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_a_2455 = heff_get_n(v_t_2454, 1, 2);
  V v_t_2458;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2457 = heff_field(v_b_243, 1);
    heff_take_n(v_b_243, 2ULL, 2);
    v_t_2458 = v_s_2457;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_b_2459 = heff_get_n(v_t_2458, 1, 2);
  V v_b_2461;
  if (heff_intLt_c(heff_dup(v_a_2455), heff_dup(v_b_2459))) {
    heff_drop(v_a_2455);
    v_b_2461 = v_b_2459;
  } else {
    heff_drop(v_b_2459);
    v_b_2461 = v_a_2455;
  }
  V v_e_2462 = heff_tag_n(TAG_At, 2, (V[]){v_t_2447, heff_rec_n(2, shape_start__end, (V[]){v_a_2451, v_b_2461})});
  V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EImplicitVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str5)}), heff_dup(v_osp_244)});
  V v_a_2466;
  switch (heff_tag_of(v_e_2462)) {
  case TAG_At: {
    V v_s_2465 = heff_dup(heff_field(v_e_2462, 1));
    v_a_2466 = v_s_2465;
    break;
  }
  default: heff_nomatch(v_e_2462);
  }
  V v_t_2467 = ({ V rv_1 = heff_get_n(v_osp_244, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2466, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_e_2462, v_t_2463}), v_t_2467});
}
V g_heff_2esyntax_2esurface_2eshortcut_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eshortcut(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2eapplyPatOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eapplyPatOp_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eapplyPatOp(V v_op_240, V v_l_241, V v_r_242) {
top: ;
  V v_x_243 = heff_take_field(v_op_240, 1);
  V v_xsp_244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_240, 3), heff_get_n(v_op_240, 4, 9)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_r_242), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_PatOp, 3, (V[]){heff_dup(v_x_243), heff_dup(v_xsp_244), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_l_241), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_243}), heff_dup(v_xsp_244)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, NTAG(TAG_Nil)});
  V v_x1_249 = ({ V a_0 = v_t_247; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, v_t_248}); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_b_2412;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_At: {
    V v_s_2411 = heff_field(v_x1_249, 1);
    heff_take_n(v_x1_249, 2ULL, 2);
    v_b_2412 = v_s_2411;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_t_2413 = ({ V rv_1 = heff_get_n(v_b_2412, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_2413});
}
V g_heff_2esyntax_2esurface_2eapplyPatOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eapplyPatOp(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eplaceStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplaceStep_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eplaceStep(V v_src_240, V v_p_241, V v_it_242) {
top: ;
  switch (heff_tag_of(v_it_242)) {
  case TAG_Sig: {
    V v_t_2440;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_Eqn: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_Whole: {
      V v_d_2416 = heff_dup(heff_field(v_it_242, 0));
      switch (heff_tag_of(v_d_2416)) {
      case TAG_At: {
        V v_x11_2417 = heff_field(v_d_2416, 0);
        heff_take_n(v_d_2416, 1ULL, 2);
        switch (heff_tag_of(v_x11_2417)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2417, 0ULL, 5);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2417, 0ULL, 5);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2417, 0ULL, 4);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2417, 0ULL, 3);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2417, 0ULL, 2);
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2417, 0ULL, 1);
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2417);
        }
        break;
      }
      default: heff_nomatch(v_d_2416);
      }
      break;
    }
    case TAG_Doc: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edefNext(v_src_240, v_p_241, v_it_242);
    } else {
      heff_drop(v_src_240);
      heff_drop(v_t_2440);
      V v_items_2441 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
      V v_diags_2442 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_diags_2442);
      V v_items_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2441});
      V v_items_2444 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_items_2444);
      V v_diags_2445 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
      return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2443, NTAG(TAG_Nil), v_diags_2445});
    }
  }
  case TAG_Eqn: {
    V v_t_2481;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      v_t_2481 = NTAG(TAG_True);
      break;
    }
    case TAG_Eqn: {
      v_t_2481 = NTAG(TAG_False);
      break;
    }
    case TAG_Whole: {
      V v_d_2457 = heff_dup(heff_field(v_it_242, 0));
      switch (heff_tag_of(v_d_2457)) {
      case TAG_At: {
        V v_x11_2458 = heff_field(v_d_2457, 0);
        heff_take_n(v_d_2457, 1ULL, 2);
        switch (heff_tag_of(v_x11_2458)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2458, 0ULL, 5);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2458, 0ULL, 5);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2458, 0ULL, 4);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2458, 0ULL, 3);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2458, 0ULL, 2);
          v_t_2481 = NTAG(TAG_False);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2481 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2458);
        }
        break;
      }
      default: heff_nomatch(v_d_2457);
      }
      break;
    }
    case TAG_Doc: {
      v_t_2481 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
      heff_drop(v_t_2481);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edefNext(v_src_240, v_p_241, v_it_242);
    } else {
      heff_drop(v_src_240);
      heff_drop(v_t_2481);
      V v_items_2482 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
      V v_diags_2483 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_diags_2483);
      V v_items_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2482});
      V v_items_2485 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_items_2485);
      V v_diags_2486 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
      return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2484, NTAG(TAG_Nil), v_diags_2486});
    }
  }
  case TAG_Whole: {
    V v_t_24120;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      v_t_24120 = NTAG(TAG_True);
      break;
    }
    case TAG_Eqn: {
      v_t_24120 = NTAG(TAG_False);
      break;
    }
    case TAG_Whole: {
      V v_d_2496 = heff_dup(heff_field(v_it_242, 0));
      switch (heff_tag_of(v_d_2496)) {
      case TAG_At: {
        V v_x11_2497 = heff_field(v_d_2496, 0);
        heff_take_n(v_d_2496, 1ULL, 2);
        switch (heff_tag_of(v_x11_2497)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2497, 0ULL, 5);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2497, 0ULL, 5);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2497, 0ULL, 4);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2497, 0ULL, 3);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2497, 0ULL, 2);
          v_t_24120 = NTAG(TAG_False);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2497, 0ULL, 1);
          v_t_24120 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2497);
        }
        break;
      }
      default: heff_nomatch(v_d_2496);
      }
      break;
    }
    case TAG_Doc: {
      v_t_24120 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if ((heff_dup(v_t_24120) == NTAG(TAG_True))) {
      heff_drop(v_t_24120);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edefNext(v_src_240, v_p_241, v_it_242);
    } else {
      heff_drop(v_src_240);
      heff_drop(v_t_24120);
      V v_items_24121 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
      V v_diags_24122 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_diags_24122);
      V v_items_24123 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_24121});
      V v_items_24124 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_items_24124);
      V v_diags_24125 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
      return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_24123, NTAG(TAG_Nil), v_diags_24125});
    }
  }
  case TAG_Doc: {
    V v_d_24126 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2edocNext(v_src_240, v_p_241, v_d_24126);
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eplaceStep(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str6, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str7, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str8, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str9, 3, "sym");
Clo g_heff_2esyntax_2esurface_2epatTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatTok_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epatTok(V v_t_240) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2epatTok_str0))) {
    V v_t_242 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_take_field(v_t_240, 1)});
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_243});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2epatTok_str1))) {
      V v_t_245 = (g_heff_2esyntax_2esurface_2eintOfText(heff_take_field(v_t_240, 1)));
      V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatInt, 1, (V[]){v_t_245}), v_t_246});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2epatTok_str2))) {
        V v_x2_248 = (g_prelude_2esplitFrom(((V)&g_heff_2esyntax_2esurface_2epatTok_str3), heff_take_field(v_t_240, 1), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_t_2411;
        switch (heff_tag_of(v_x2_248)) {
        case TAG_Nil: {
          v_t_2411 = ((V)&g_heff_2esyntax_2esurface_2epatTok_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_x2_248, 0);
          V v_xs_2410 = heff_field(v_x2_248, 1);
          heff_take_n(v_x2_248, 3ULL, 2);
          v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2epatTok_str5); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
          break;
        }
        default: heff_nomatch(v_x2_248);
        }
        double v_t_2412 = (g_heff_2esyntax_2esurface_2efloatOfDigits_w(v_t_2411));
        V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatFloat, 1, (V[]){heff_box_f64(v_t_2412)}), v_t_2413});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2epatTok_str6))) {
          V v_t_2415 = heff_tag_n(TAG_PatString, 1, (V[]){heff_take_field(v_t_240, 1)});
          V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2416});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2epatTok_str7))) {
            V v_t_2418 = heff_tag_n(TAG_PatBytes, 1, (V[]){heff_take_field(v_t_240, 1)});
            V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            return heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2419});
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2epatTok_str8))) {
              V v_t_2421 = heff_strRuneAt(heff_take_field(v_t_240, 1), MK_INT(0LL));
              V v_t_2422 = heff_tag_n(TAG_PatRune, 1, (V[]){heff_runeToInt(v_t_2421)});
              V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2423});
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2esurface_2epatTok_str9))) {
                V v_t_2425 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_take_field(v_t_240, 1)});
                V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2426});
              } else {
                V v_t_2427 = (g_heff_2esyntax_2esurface_2ewordKw(heff_take_field(v_t_240, 1)));
                V v_t_2428 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatWord, 1, (V[]){v_t_2427}), v_t_2428});
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2epatTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatTok(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2equalifiedE_str0, 1, ".");
Clo g_heff_2esyntax_2esurface_2equalifiedE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2equalifiedE_entry, 2, 0};

V g_heff_2esyntax_2esurface_2equalifiedE(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_ETag, 1, (V[]){heff_take_field(v_t_240, 1)});
    V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_t_243});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2equalifiedE_str0), heff_take_field(v_f_244, 1));
    V v_t_247 = heff_strAppend(heff_take_field(v_t_240, 1), v_t_246);
    V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_t_240, 3, 9), heff_get_n(v_f_244, 4, 9)});
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), v_t_248});
    V v_t_2410 = (g_list_2emap_24s513201124x806973253(v_rest_245));
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_249, v_t_2410);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2equalifiedE(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclarationL_str0, 24, "a field is `name : Type`");
V g_heff_2esyntax_2esurface_2edeclarationL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edeclarationL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclarationL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edeclarationL(V v_r_240, V v_e_241) {
top: ;
  V v_m_242 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
  return heff_clo_n(g_heff_2esyntax_2esurface_2edeclarationL_lam0, 1, 1, (V[]){v_m_242});
}
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edeclarationL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edeclarationL_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_MkPair: {
    V v_x11_245 = heff_field(v_x1_244, 0);
    V v_st_246 = heff_field(v_x1_244, 1);
    V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_Left: {
      V v_e_247 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_247}), v_st_246});
    }
    case TAG_Right: {
      V v_x_248 = heff_field(v_x11_245, 0);
      heff_take_n(v_x11_245, 1ULL, 1);
      V v_t_249 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_248));
      V v_x1_2410 = (g_heff_2esyntax_2esurface_2easBinderOn(v_t_249, v_st_246));
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_MkPair: {
        V v_x11_2411 = heff_field(v_x1_2410, 0);
        V v_st_2412 = heff_field(v_x1_2410, 1);
        heff_take_n(v_x1_2410, 3ULL, 2);
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_Left: {
          V v_e_2413 = heff_field(v_x11_2411, 0);
          heff_take_n(v_x11_2411, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
        }
        case TAG_Right: {
          V v_x_2414 = heff_field(v_x11_2411, 0);
          heff_take_n(v_x11_2411, 1ULL, 1);
          V v_t_2415 = (g_heff_2esyntax_2esurface_2eisAnnE(v_x_2414));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_t_2415);
            return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2414}), v_st_2412});
          } else {
            heff_drop(v_t_2415);
            V v_span_2418;
            switch (heff_tag_of(v_x_2414)) {
            case TAG_At: {
              V v_s_2417 = heff_field(v_x_2414, 1);
              heff_take_n(v_x_2414, 2ULL, 2);
              v_span_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_x_2414);
            }
            V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2edeclarationL_str0), v_span_2418, NTAG(TAG_Nothing)});
            return heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2412});
          }
        }
        default: return heff_nomatch(v_x11_2411);
        }
      }
      default: return heff_nomatch(v_x1_2410);
      }
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2esurface_2eletHeadL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eletHeadL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eletHeadL_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eletHeadL(V v_r_240, V v_p_241, V v_ann0_242, V v_e_243) {
top: ;
  V v_m_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){v_p_241}));
  return heff_clo_n(g_heff_2esyntax_2esurface_2eletHeadL_lam0, 1, 4, (V[]){v_m_244, v_ann0_242, v_r_240, v_e_243});
}
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eletHeadL(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2eletHeadL_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_ann0_242 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_ann0_242);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e_243);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      switch (heff_tag_of(v_ann0_242)) {
      case TAG_Nothing: {
        V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_243}));
        V v_x1_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_248}));
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_MkPair: {
          V v_x11_2413 = heff_field(v_x1_2412, 0);
          V v_st_2414 = heff_field(v_x1_2412, 1);
          V v_ru_24x1_2412_24MkPair = heff_take_reuse_n(v_x1_2412, 3ULL, 2);
          switch (heff_tag_of(v_x11_2413)) {
          case TAG_Left: {
            V v_e_2415 = heff_field(v_x11_2413, 0);
            heff_take_n(v_x11_2413, 1ULL, 1);
            heff_drop(v_x_2410);
            heff_drop_cell(v_ru_24x11_247_24Right, 1);
            heff_drop_cell(v_ru_24x1_2412_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2415}), v_st_2414});
          }
          case TAG_Right: {
            V v_x_2416 = heff_field(v_x11_2413, 0);
            heff_take_n(v_x11_2413, 1ULL, 1);
            V v_t_2417 = heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2410, v_x_2416})});
            return heff_tag_at_n(v_ru_24x1_2412_24MkPair, TAG_MkPair, 2, (V[]){v_t_2417, v_st_2414});
          }
          default: return heff_nomatch(v_x11_2413);
          }
        }
        default: return heff_nomatch(v_x1_2412);
        }
      }
      case TAG_Just: {
        V v_it1_2418 = heff_field(v_ann0_242, 0);
        heff_take_n(v_ann0_242, 1ULL, 1);
        switch (heff_tag_of(v_it1_2418)) {
        case TAG_MkPair: {
          V v_ty_2420 = heff_field(v_it1_2418, 1);
          V v_ru_24it1_2418_24MkPair = heff_take_reuse_n(v_it1_2418, 2ULL, 2);
          V v_m_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_2420}));
          V v_x1_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_st_248}));
          switch (heff_tag_of(v_x1_2422)) {
          case TAG_MkPair: {
            V v_x11_2423 = heff_field(v_x1_2422, 0);
            V v_st_2424 = heff_field(v_x1_2422, 1);
            V v_ru_24x1_2422_24MkPair = heff_take_reuse_n(v_x1_2422, 3ULL, 2);
            switch (heff_tag_of(v_x11_2423)) {
            case TAG_Left: {
              V v_e_2425 = heff_field(v_x11_2423, 0);
              heff_take_n(v_x11_2423, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop(v_e_243);
              heff_drop(v_x_2410);
              heff_drop_cell(v_ru_24x11_247_24Right, 1);
              heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
              heff_drop_cell(v_ru_24x1_2422_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2425}), v_st_2424});
            }
            case TAG_Right: {
              V v_x_2426 = heff_field(v_x11_2423, 0);
              heff_take_n(v_x11_2423, 1ULL, 1);
              V v_m_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_243}));
              V v_x1_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2424}));
              switch (heff_tag_of(v_x1_2428)) {
              case TAG_MkPair: {
                V v_x11_2429 = heff_field(v_x1_2428, 0);
                V v_st_2430 = heff_field(v_x1_2428, 1);
                heff_take_n(v_x1_2428, 3ULL, 2);
                switch (heff_tag_of(v_x11_2429)) {
                case TAG_Left: {
                  V v_e_2431 = heff_field(v_x11_2429, 0);
                  heff_take_n(v_x11_2429, 1ULL, 1);
                  heff_drop(v_x_2410);
                  heff_drop_cell(v_ru_24x11_247_24Right, 1);
                  heff_drop_cell(v_ru_24it1_2418_24MkPair, 2);
                  heff_drop_cell(v_ru_24x1_2422_24MkPair, 2);
                  heff_drop(v_x_2426);
                  return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2431}), v_st_2430});
                }
                case TAG_Right: {
                  V v_x_2432 = heff_field(v_x11_2429, 0);
                  heff_take_n(v_x11_2429, 1ULL, 1);
                  V v_t_2435;
                  switch (heff_tag_of(v_x_2426)) {
                  case TAG_At: {
                    V v_s_2434 = heff_dup(heff_field(v_x_2426, 1));
                    v_t_2435 = v_s_2434;
                    break;
                  }
                  default: heff_nomatch(v_x_2426);
                  }
                  V v_a_2436 = heff_get_n(v_t_2435, 0, 2);
                  V v_t_2439;
                  switch (heff_tag_of(v_x_2432)) {
                  case TAG_At: {
                    V v_s_2438 = heff_dup(heff_field(v_x_2432, 1));
                    v_t_2439 = v_s_2438;
                    break;
                  }
                  default: heff_nomatch(v_x_2432);
                  }
                  V v_b_2440 = heff_get_n(v_t_2439, 1, 2);
                  V v_t_2441 = heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_2432, v_x_2426}), heff_rec_n(2, shape_start__end, (V[]){v_a_2436, v_b_2440})});
                  V v_x_2442 = heff_tag_at_n(v_ru_24it1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2410, v_t_2441});
                  return heff_tag_at_n(v_ru_24x1_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2442}), v_st_2430});
                }
                default: return heff_nomatch(v_x11_2429);
                }
              }
              default: return heff_nomatch(v_x1_2428);
              }
            }
            default: return heff_nomatch(v_x11_2423);
            }
          }
          default: return heff_nomatch(v_x1_2422);
          }
        }
        default: return heff_nomatch(v_it1_2418);
        }
      }
      default: return heff_nomatch(v_ann0_242);
      }
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclNameOf_str0, 0, "");
Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclNameOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edeclNameOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_name__span, (V[]){((V)&g_heff_2esyntax_2esurface_2edeclNameOf_str0), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  }
  case TAG_Cons: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      V v_t_243 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_t_241, 3)), heff_dup(heff_rfield(v_t_241, 4))});
      return heff_rec_n(2, shape_name__span, (V[]){heff_dup(heff_rfield(v_t_241, 1)), v_t_243});
    }
    case TAG_Cons: {
      V v_op_244 = heff_field(v_x12_242, 0);
      V v_x122_245 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_t_241, 3)), heff_dup(heff_rfield(v_t_241, 4))});
        return heff_rec_n(2, shape_name__span, (V[]){heff_dup(heff_rfield(v_t_241, 1)), v_t_246});
      }
      case TAG_Cons: {
        V v_x1222_248 = heff_field(v_x122_245, 1);
        switch (heff_tag_of(v_x1222_248)) {
        case TAG_Nil: {
          V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_244, 3)), heff_dup(heff_rfield(v_op_244, 4))});
          return heff_rec_n(2, shape_name__span, (V[]){heff_dup(heff_rfield(v_op_244, 1)), v_t_249});
        }
        case TAG_Cons: {
          V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_t_241, 3)), heff_dup(heff_rfield(v_t_241, 4))});
          return heff_rec_n(2, shape_name__span, (V[]){heff_dup(heff_rfield(v_t_241, 1)), v_t_2412});
        }
        default: return heff_nomatch(v_x1222_248);
        }
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edeclNameOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eanyS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eanyS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eanyS(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eanyS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eanyS(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str1, 28, "` is syntax, not an operator");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str3, 54, "` has no fixity to be above or below: declare it first");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str4, 54, "a fixity declaration names its operators: `infixl + -`");
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDiagsOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDiagsOf(V v_scope_240, V v_all_241, V v_d_242) {
top: ;
  V v_t_243 = (g_list_2emap_24f359508862x1661952287(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str0), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str1), heff_dup(heff_rfield(v_d_242, 1))));
  V v_t_244 = (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_d_242, 2)), heff_dup(heff_rfield(v_d_242, 3))));
  V v_t_2410 = (g_list_2emap_24f482741271x1112521151(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str2), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str3), heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam0, 1, 1, (V[]){heff_dup(v_scope_240)}), v_t_244));
  V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam2, 1, 2, (V[]){v_scope_240, heff_dup(v_d_242)}), heff_dup(heff_rfield(v_d_242, 3))));
  V v_t_2413 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2412));
  V v_t_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_d_242, 1)));
  V v_t_2417;
  if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
    V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str4), heff_dup(heff_rfield(v_d_242, 6)), NTAG(TAG_Nothing)});
    v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
  } else {
    v_t_2417 = NTAG(TAG_Nil);
  }
  V v_t_2418 = (g_heff_2esyntax_2esurface_2ecycleDiag(v_all_241, heff_dup(v_d_242)));
  V v_t_2419 = (g_heff_2esyntax_2esurface_2eappendS(heff_get_n(v_d_242, 5, 8), v_t_2418));
  V v_t_2420 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2417, v_t_2419));
  V v_t_2421 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2413, v_t_2420));
  V v_t_2422 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2410, v_t_2421));
  return (g_heff_2esyntax_2esurface_2eappendS(v_t_243, v_t_2422));
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixDiagsOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam1(V self, V *args) {
  V v_g_246 = args[0];
  V v_u_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_u_245, 1, 7)}));
  return ({ V a_0 = v_t_247; V b_1 = heff_get_n(v_g_246, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_scope_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam1, 1, 1, (V[]){v_u_245}); V b_1 = heff_get_n(v_scope_240, 0, 2); V r_ = (g_heff_2esyntax_2efixity_2efindG(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    heff_take_n(v_t_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam2(V self, V *args) {
  V v_u_2411 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurface_2ebelowLoosest(v_scope_240, v_d_242, v_u_2411));
}