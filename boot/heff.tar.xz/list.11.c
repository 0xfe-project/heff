// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAbandon 62759
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBool 8245
#define TAG_EBreak 7195
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EFor 37939
#define TAG_EGlobal 62762
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EProject 35489
#define TAG_ERecord 5518
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESet 50124
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EStr 50587
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkPath 49630
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PVar 52952
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_SBytes 19273
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TagVariant 25174
#define LBL_again 294104954
#define LBL_args 9498020
#define LBL_atom 9500184
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_by 9918
#define LBL_code 9554612
#define LBL_detail 611917692
#define LBL_end 310101
#define LBL_env 310119
#define LBL_field 298786068
#define LBL_first 298798794
#define LBL_imports 10411951
#define LBL_js 10160
#define LBL_key 315609
#define LBL_label 304085774
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_path 9928940
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_use 325633
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_js__env[] = {LBL_js, LBL_env};
static uint32_t shape_name__args[] = {LBL_name, LBL_args};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__span__field[] = {LBL_name, LBL_span, LBL_field};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2edriver_2eimportOfGo(V, V, V);
V g_heff_2ebuild_2edriver_2eimportOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportOfGo_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2edriver_2eplaceAt(V, V);
V g_heff_2ebuild_2edriver_2eplaceAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eplaceAt_clo;
HeffT2 g_heff_2ecompile_2eemit_2ebindFrom_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom(V, V);
V g_heff_2ecompile_2eemit_2elastDotFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2elastDotFrom_clo;
V g_heff_2ecompile_2eemit_2esafeChars(V, V, V);
V g_heff_2ecompile_2eemit_2esafeChars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeChars_clo;
V g_heff_2ecompile_2eemit_2esafeFrom(V);
V g_heff_2ecompile_2eemit_2esafeFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2esafeFrom_clo;
V g_heff_2ecompile_2eemit_2espellAt(V, V);
V g_heff_2ecompile_2eemit_2espellAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2espellAt_clo;
V g_heff_2ecompile_2eimperative_2eisSimple(V);
V g_heff_2ecompile_2eimperative_2eisSimple_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eisSimple_clo;
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(V);
V g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eowned_2eokSt(V, V, V, V);
V g_heff_2ecompile_2eowned_2eokSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eokSt_clo;
V g_heff_2ecompile_2erepr_2eunite(V, V, V);
V g_heff_2ecompile_2erepr_2eunite_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eunite_clo;
V g_heff_2ecompile_2esimplify_2eetaWanted(V, V);
V g_heff_2ecompile_2esimplify_2eetaWanted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaWanted_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2ecompile_2eworker_2enumericW(V);
V g_heff_2ecompile_2eworker_2enumericW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworker_2enumericW_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2elsp_2esplit_2eexprName(V);
V g_heff_2elsp_2esplit_2eexprName_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_clo;
V g_heff_2elsp_2esplit_2eexprName_24tok1(V, V);
V g_heff_2elsp_2esplit_2eexprName_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2esplit_2eexprName_24tok1_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_list_2eall_24s141743730x1400463797(V, V, V, V);
V g_list_2eall_24s141743730x1400463797_entry(V self, V *a);
extern Clo g_list_2eall_24s141743730x1400463797_clo;
V g_list_2eall_24s392821322x1502625120(V);
V g_list_2eall_24s392821322x1502625120_entry(V self, V *a);
extern Clo g_list_2eall_24s392821322x1502625120_clo;
V g_list_2eall_24s783782562x1319139556(V);
V g_list_2eall_24s783782562x1319139556_entry(V self, V *a);
extern Clo g_list_2eall_24s783782562x1319139556_clo;
V g_list_2eany_24s392952474x1351014279(V, V);
V g_list_2eany_24s392952474x1351014279_entry(V self, V *a);
extern Clo g_list_2eany_24s392952474x1351014279_clo;
V g_list_2eascending_24s390745979x1196509894(V, V, V);
V g_list_2eascending_24s390745979x1196509894_entry(V self, V *a);
extern Clo g_list_2eascending_24s390745979x1196509894_clo;
V g_list_2ecollapse(V, V, V);
V g_list_2ecollapse_entry(V self, V *a);
extern Clo g_list_2ecollapse_clo;
V g_list_2ecollapse_24s1236926497x1606764496(V, V);
V g_list_2ecollapse_24s1236926497x1606764496_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1236926497x1606764496_clo;
V g_list_2edescending_24s1679501129x89119467(V, V, V);
V g_list_2edescending_24s1679501129x89119467_entry(V self, V *a);
extern Clo g_list_2edescending_24s1679501129x89119467_clo;
V g_list_2efind_24s633938771x532201311(V, V);
V g_list_2efind_24s633938771x532201311_entry(V self, V *a);
extern Clo g_list_2efind_24s633938771x532201311_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1980014771x775787011(V, V);
V g_list_2efoldl_24s1980014771x775787011_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1980014771x775787011_clo;
V g_list_2efoldl_24s2018454372x1607369768(V, V, V, V, V, V, V);
V g_list_2efoldl_24s2018454372x1607369768_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2018454372x1607369768_clo;
V g_list_2efoldl_24s271650647x1598714891(V, V);
V g_list_2efoldl_24s271650647x1598714891_entry(V self, V *a);
extern Clo g_list_2efoldl_24s271650647x1598714891_clo;
V g_list_2efoldl_24s37738078x926874390(V, V, V, V);
V g_list_2efoldl_24s37738078x926874390_entry(V self, V *a);
extern Clo g_list_2efoldl_24s37738078x926874390_clo;
V g_list_2efoldl_24s532743697x1094589833(V, V);
V g_list_2efoldl_24s532743697x1094589833_entry(V self, V *a);
extern Clo g_list_2efoldl_24s532743697x1094589833_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s958865698x1719976126(V, V, V);
V g_list_2efoldl_24s958865698x1719976126_entry(V self, V *a);
extern Clo g_list_2efoldl_24s958865698x1719976126_clo;
V g_list_2ekeepIf_24s1457049037x722637222_24dps(V, V);
V g_list_2ekeepIf_24s1457049037x722637222_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1457049037x722637222_24dps_clo;
V g_list_2ekeepIf_24s1674319799x1081446864(V);
V g_list_2ekeepIf_24s1674319799x1081446864_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1674319799x1081446864_clo;
V g_list_2ekeepIf_24s1674319799x1081446864_24dps(V, V);
V g_list_2ekeepIf_24s1674319799x1081446864_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1674319799x1081446864_24dps_clo;
V g_list_2ekeepIf_24s304198972x561714839_24dps(V, V, V);
V g_list_2ekeepIf_24s304198972x561714839_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_24dps_clo;
V g_list_2emap_24f1213328022x1811586494_24dps(V, V, V);
V g_list_2emap_24f1213328022x1811586494_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_24dps_clo;
V g_list_2emap_24f1619849299x1543923271_24dps(V, V);
V g_list_2emap_24f1619849299x1543923271_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1619849299x1543923271_24dps_clo;
V g_list_2emap_24f2053285389x511622380_24dps(V, V, V, V, V, V);
V g_list_2emap_24f2053285389x511622380_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2053285389x511622380_24dps_clo;
V g_list_2emap_24s1276400643x126214923(V);
V g_list_2emap_24s1276400643x126214923_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_clo;
V g_list_2emap_24s1276400643x126214923_24dps(V, V);
V g_list_2emap_24s1276400643x126214923_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_24dps_clo;
V g_list_2emap_24s1289827711x943898099(V);
V g_list_2emap_24s1289827711x943898099_entry(V self, V *a);
extern Clo g_list_2emap_24s1289827711x943898099_clo;
V g_list_2emap_24s1289827711x943898099_24dps(V, V);
V g_list_2emap_24s1289827711x943898099_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1289827711x943898099_24dps_clo;
V g_list_2emap_24s129316455x2072694707_24dps(V, V);
V g_list_2emap_24s129316455x2072694707_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s129316455x2072694707_24dps_clo;
V g_list_2emap_24s1372232877x278600396_24dps(V, V);
V g_list_2emap_24s1372232877x278600396_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1372232877x278600396_24dps_clo;
V g_list_2emap_24s1418269708x2034621695(V, V);
V g_list_2emap_24s1418269708x2034621695_entry(V self, V *a);
extern Clo g_list_2emap_24s1418269708x2034621695_clo;
V g_list_2emap_24s1418269708x2034621695_24dps(V, V, V);
V g_list_2emap_24s1418269708x2034621695_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1418269708x2034621695_24dps_clo;
V g_list_2emap_24s1455783996x1449538216(V);
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_clo;
V g_list_2emap_24s1455783996x1449538216_24dps(V, V);
V g_list_2emap_24s1455783996x1449538216_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1455783996x1449538216_24dps_clo;
V g_list_2emap_24s1624059865x1140896478_24dps(V, V);
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_24dps_clo;
V g_list_2emap_24s1895313378x47656836(V);
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_clo;
V g_list_2emap_24s1895313378x47656836_24dps(V, V);
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_24dps_clo;
V g_list_2emap_24s1990719097x1419059608_24dps(V, V);
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_24dps_clo;
V g_list_2emap_24s204237290x1967740547(V, V, V, V);
V g_list_2emap_24s204237290x1967740547_entry(V self, V *a);
extern Clo g_list_2emap_24s204237290x1967740547_clo;
V g_list_2emap_24s204237290x1967740547_24dps(V, V, V, V, V);
V g_list_2emap_24s204237290x1967740547_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s204237290x1967740547_24dps_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s219049803x1458391381_24dps(V, V);
V g_list_2emap_24s219049803x1458391381_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_24dps_clo;
V g_list_2emap_24s419081849x11460228(V);
V g_list_2emap_24s419081849x11460228_entry(V self, V *a);
extern Clo g_list_2emap_24s419081849x11460228_clo;
V g_list_2emap_24s419081849x11460228_24dps(V, V);
V g_list_2emap_24s419081849x11460228_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s419081849x11460228_24dps_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s4199228x1154005405_24dps(V, V);
V g_list_2emap_24s4199228x1154005405_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24dps_clo;
V g_list_2emap_24s473401207x1960255357_24dps(V, V);
V g_list_2emap_24s473401207x1960255357_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s473401207x1960255357_24dps_clo;
V g_list_2emap_24s580776739x648604941_24dps(V, V);
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s580776739x648604941_24dps_clo;
V g_list_2emap_24s698781565x943874959(V, V, V, V, V, V, V);
V g_list_2emap_24s698781565x943874959_entry(V self, V *a);
extern Clo g_list_2emap_24s698781565x943874959_clo;
V g_list_2emap_24s698781565x943874959_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s698781565x943874959_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s698781565x943874959_24dps_clo;
V g_list_2emap_24s796727596x829078925_24dps(V, V);
V g_list_2emap_24s796727596x829078925_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s796727596x829078925_24dps_clo;
V g_list_2emerge(V, V, V);
V g_list_2emerge_entry(V self, V *a);
extern Clo g_list_2emerge_clo;
V g_list_2emergeRuns(V, V, V);
V g_list_2emergeRuns_entry(V self, V *a);
extern Clo g_list_2emergeRuns_clo;
V g_list_2emergeRuns_24s1094647646x865851942(V, V);
V g_list_2emergeRuns_24s1094647646x865851942_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1094647646x865851942_clo;
V g_list_2epushRun(V, V, V, V);
V g_list_2epushRun_entry(V self, V *a);
extern Clo g_list_2epushRun_clo;
V g_list_2epushRun_24s782281454x118641000(V, V, V);
V g_list_2epushRun_24s782281454x118641000_entry(V self, V *a);
extern Clo g_list_2epushRun_24s782281454x118641000_clo;
V g_list_2erunFrom(V, V, V);
V g_list_2erunFrom_entry(V self, V *a);
extern Clo g_list_2erunFrom_clo;
V g_list_2ezipWith_24s634961829x758866838(V, V);
V g_list_2ezipWith_24s634961829x758866838_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634961829x758866838_clo;
V g_list_2ezipWith_24s634961829x758866838_24dps(V, V, V);
V g_list_2ezipWith_24s634961829x758866838_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634961829x758866838_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_list_2epushRun_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_entry, 4, 0};

V g_list_2epushRun(V v_le_240, V v_k_241, V v_run_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_le_240);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_241, v_run_242}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_j_246 = heff_field(v_x41_244, 0);
      V v_below_247 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24MkPair = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_246, v_k_241, 0)) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_j_246);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        V v_t_248 = (g_list_2emerge(heff_dup(v_le_240), v_below_247, v_run_242));
        V t_0 = v_le_240;
        V t_1 = heff_intAdd(v_k_241, MK_INT(1LL));
        V t_2 = v_t_248;
        V t_3 = v_rest_245;
        v_le_240 = t_0;
        v_k_241 = t_1;
        v_run_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      } else {
        heff_drop(v_le_240);
        V v_t_249 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_244_24MkPair, TAG_MkPair, 2, (V[]){v_j_246, v_below_247}), v_rest_245});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_241, v_run_242}), v_t_249});
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_list_2epushRun_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emergeRuns_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_entry, 3, 0};

V g_list_2emergeRuns(V v_le_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_run_243 = heff_field(v_x3_242, 0);
    V v_x32_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x32_244)) {
    case TAG_Nil: {
      return ({ V a_0 = v_le_240; V a_1 = v_run_243; V a_2 = v_stack_241; V r_ = (g_list_2ecollapse(a_0, a_1, a_2)); heff_drop(v_stack_241); r_; });
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x32_244, 0);
      V v_xs_246 = heff_field(v_x32_244, 1);
      heff_take_n(v_x32_244, 3ULL, 2);
      V v_t_247 = (g_list_2epushRun(heff_dup(v_le_240), MK_INT(0LL), v_run_243, v_stack_241));
      V v_t_248 = (g_list_2erunFrom(heff_dup(v_le_240), v_x_245, v_xs_246));
      V t_0 = v_le_240;
      V t_1 = v_t_247;
      V t_2 = v_t_248;
      v_le_240 = t_0;
      v_stack_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x32_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2emergeRuns_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1289827711x943898099_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1289827711x943898099_entry, 1, 0};

V g_list_2emap_24s1289827711x943898099(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2eelab_2eprimitive_2eprimName(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_x_241}), heff_hole()});
    V v_u_245 = (g_list_2emap_24s1289827711x943898099_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1289827711x943898099_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1289827711x943898099(a[0]);
}
Clo g_list_2efoldl_24s37738078x926874390_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s37738078x926874390_entry, 4, 0};

V g_list_2efoldl_24s37738078x926874390(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_244, 1);
      v_t_248 = heff_dup(v_a_247);
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_249 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_t_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_z_242, v_t_249);
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s37738078x926874390_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2efoldl_24s37738078x926874390(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s958865698x1719976126_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s958865698x1719976126_entry, 3, 0};

V g_list_2efoldl_24s958865698x1719976126(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_247}), v_z_241});
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_lit_240});
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s958865698x1719976126_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s958865698x1719976126(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s1674319799x1081446864_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1674319799x1081446864_entry, 1, 0};

V g_list_2ekeepIf_24s1674319799x1081446864(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    switch (heff_tag_of(v_a_246)) {
    case TAG_Nil: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1674319799x1081446864_24dps(v_xs_242, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    case TAG_Cons: {
      V v_a_249 = heff_field(v_a_246, 0);
      heff_take_n(v_a_246, 1ULL, 2);
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_field(v_a_249, 0);
        heff_take_n(v_a_249, 1ULL, 2);
        switch (heff_tag_of(v_a_2411)) {
        case TAG_StmtBind: {
          heff_take_n(v_a_2411, 0ULL, 3);
          V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
          V v_u_2417 = (g_list_2ekeepIf_24s1674319799x1081446864_24dps(v_xs_242, heff_dup(v_cell_2416)));
          heff_drop(v_u_2417);
          return v_cell_2416;
        }
        case TAG_StmtLet: {
          heff_take_n(v_a_2411, 0ULL, 2);
          V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
          V v_u_2421 = (g_list_2ekeepIf_24s1674319799x1081446864_24dps(v_xs_242, heff_dup(v_cell_2420)));
          heff_drop(v_u_2421);
          return v_cell_2420;
        }
        case TAG_StmtExpr: {
          V v_a_2422 = heff_field(v_a_2411, 0);
          heff_take_n(v_a_2411, 1ULL, 1);
          V v_t_2423 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_a_2422));
          if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
            heff_drop(v_t_2423);
            V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
            V v_u_2425 = (g_list_2ekeepIf_24s1674319799x1081446864_24dps(v_xs_242, heff_dup(v_cell_2424)));
            heff_drop(v_u_2425);
            return v_cell_2424;
          } else {
            heff_drop(v_x_241);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_t_2423);
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          }
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_a_2411, 0ULL, 3);
          V v_cell_2429 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
          V v_u_2430 = (g_list_2ekeepIf_24s1674319799x1081446864_24dps(v_xs_242, heff_dup(v_cell_2429)));
          heff_drop(v_u_2430);
          return v_cell_2429;
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_a_2411, 0ULL, 3);
          V v_cell_2434 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
          V v_u_2435 = (g_list_2ekeepIf_24s1674319799x1081446864_24dps(v_xs_242, heff_dup(v_cell_2434)));
          heff_drop(v_u_2435);
          return v_cell_2434;
        }
        default: return heff_nomatch(v_a_2411);
        }
      }
      default: return heff_nomatch(v_a_249);
      }
    }
    default: return heff_nomatch(v_a_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1674319799x1081446864_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1674319799x1081446864(a[0]);
}
Clo g_list_2eall_24s783782562x1319139556_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s783782562x1319139556_entry, 1, 0};

V g_list_2eall_24s783782562x1319139556(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 2ULL, 2);
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_dup(heff_field(v_a_246, 0));
          switch (heff_tag_of(v_a_247)) {
          case TAG_EDo: {
            V v_a_249 = heff_field(v_a_247, 0);
            heff_take_n(v_a_247, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop_cell(v_ru_24x_241_24At, 2);
            switch (heff_tag_of(v_a_246)) {
            case TAG_At: {
              heff_take_n(v_a_246, 0ULL, 2);
              v_t_2416 = v_a_249;
              break;
            }
            default: heff_nomatch(v_a_246);
            }
            break;
          }
          default: {
            heff_drop(v_a_247);
            V v_t_2414;
            switch (heff_tag_of(v_a_246)) {
            case TAG_At: {
              V v_a_2413 = heff_dup(heff_field(v_a_246, 1));
              v_t_2414 = v_a_2413;
              break;
            }
            default: heff_nomatch(v_a_246);
            }
            V v_t_2415 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_a_246}), v_t_2414});
            v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
            break;
          }
          }
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_a_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2416));
    switch (heff_tag_of(v_a_2417)) {
    case TAG_Nil: {
      heff_drop(v_xs_242);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_a_2418 = heff_field(v_a_2417, 0);
      heff_take_n(v_a_2417, 1ULL, 2);
      switch (heff_tag_of(v_a_2418)) {
      case TAG_At: {
        V v_a_2420 = heff_field(v_a_2418, 0);
        heff_take_n(v_a_2418, 1ULL, 2);
        switch (heff_tag_of(v_a_2420)) {
        case TAG_StmtBind: {
          heff_take_n(v_a_2420, 0ULL, 3);
          heff_drop(v_xs_242);
          return NTAG(TAG_False);
        }
        case TAG_StmtLet: {
          heff_take_n(v_a_2420, 0ULL, 2);
          heff_drop(v_xs_242);
          return NTAG(TAG_False);
        }
        case TAG_StmtExpr: {
          V v_a_2427 = heff_field(v_a_2420, 0);
          heff_take_n(v_a_2420, 1ULL, 1);
          V v_t_2428 = (g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(v_a_2427));
          if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
            heff_drop(v_t_2428);
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          } else {
            heff_drop(v_xs_242);
            heff_drop(v_t_2428);
            return NTAG(TAG_False);
          }
        }
        case TAG_StmtLetMut: {
          heff_take_n(v_a_2420, 0ULL, 3);
          heff_drop(v_xs_242);
          return NTAG(TAG_False);
        }
        case TAG_StmtLetElse: {
          heff_take_n(v_a_2420, 0ULL, 3);
          heff_drop(v_xs_242);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_a_2420);
        }
      }
      default: return heff_nomatch(v_a_2418);
      }
    }
    default: return heff_nomatch(v_a_2417);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s783782562x1319139556_entry(V self, V *a) {
  (void)self;
  return g_list_2eall_24s783782562x1319139556(a[0]);
}
Clo g_list_2emap_24s1276400643x126214923_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1276400643x126214923_entry, 1, 0};

V g_list_2emap_24s1276400643x126214923(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2423;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkEquation: {
        V v_f_246 = heff_field(v_x21_244, 0);
        V v_fsp_247 = heff_field(v_x21_244, 1);
        V v_ps_248 = heff_field(v_x21_244, 2);
        V v_rhs_249 = heff_field(v_x21_244, 3);
        V v_ru_24x21_244_24MkEquation = heff_take_reuse_n(v_x21_244, 15ULL, 4);
        HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_rhs_249));
        V v_t_2422;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_243_24At, 2);
            V v_c_2413 = v_field_2412;
            v_t_2422 = v_c_2413;
          } else {
            if ((v_tag_2411 == ((int64_t)1ULL))) {
              V v_i_2414 = v_field_2412;
              V v_t_2417;
              switch (heff_tag_of(v_i_2414)) {
              case TAG_At: {
                V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
                v_t_2417 = v_s_2416;
                break;
              }
              default: heff_nomatch(v_i_2414);
              }
              v_t_2422 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2414}), v_t_2417});
            } else {
              V v_t_2418 = v_field_2412;
              V v_t_2421;
              switch (heff_tag_of(v_t_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_t_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_t_2418);
              }
              v_t_2422 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2418}), v_t_2421});
            }
          }
        }
        v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_244_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_246, v_fsp_247, v_ps_248, v_t_2422}), v_sp_245});
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = (g_list_2emap_24s1276400643x126214923_24dps(v_xs_242, heff_dup(v_cell_2424)));
    heff_drop(v_u_2425);
    return v_cell_2424;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1276400643x126214923_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1276400643x126214923(a[0]);
}
Clo g_list_2emap_24s1624059865x1140896478_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1624059865x1140896478_24dps_entry, 2, 0};

V g_list_2emap_24s1624059865x1140896478_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2esurface_2easNameE(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1624059865x1140896478_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s473401207x1960255357_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s473401207x1960255357_24dps_entry, 2, 0};

V g_list_2emap_24s473401207x1960255357_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2espec_2ecallsNothing(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s473401207x1960255357_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s473401207x1960255357_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s392952474x1351014279_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s392952474x1351014279_entry, 2, 0};

V g_list_2eany_24s392952474x1351014279(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2eetaWanted(heff_dup(v_lit_240), v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s392952474x1351014279_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s392952474x1351014279(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eall_24s392821322x1502625120_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s392821322x1502625120_entry, 1, 0};

V g_list_2eall_24s392821322x1502625120(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2ecompile_2eimperative_2eisSimple(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s392821322x1502625120_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s392821322x1502625120(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s419081849x11460228_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s419081849x11460228_entry, 1, 0};

V g_list_2emap_24s419081849x11460228(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_t_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_249 = (g_heff_2ecompile_2eimperative_2eonceVal_24s1540411236x378108524(v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_249}), heff_hole()});
    V v_u_2411 = (g_list_2emap_24s419081849x11460228_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s419081849x11460228_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s419081849x11460228(a[0]);
}
Clo g_list_2eall_24s141743730x1400463797_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s141743730x1400463797_entry, 4, 0};

V g_list_2eall_24s141743730x1400463797(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_tr(g_heff_2ecompile_2eowned_2eokSt(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_x_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_t_246);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eall_24s141743730x1400463797_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_list_2eall_24s141743730x1400463797(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_list_2efoldl_24s271650647x1598714891_lam0(V self, V *args);
Clo g_list_2efoldl_24s271650647x1598714891_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s271650647x1598714891_entry, 2, 0};

V g_list_2efoldl_24s271650647x1598714891(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s1980014771x775787011(NTAG(TAG_Nil), v_t_247));
    V v_t_2414 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s271650647x1598714891_lam0, 2, 1, (V[]){heff_dup(v_x_242)}); V a_1 = v_z_240; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
    V t_0 = v_t_2414;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s271650647x1598714891_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s271650647x1598714891(a[0], a1); heff_drop(a1); return r;
}
V g_list_2efoldl_24s271650647x1598714891_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413;
  switch (heff_tag_of(v_x_242)) {
  case TAG_MkPair: {
    V v_a_2411 = heff_field(v_x_242, 0);
    heff_take_n(v_x_242, 1ULL, 2);
    v_t_2413 = v_a_2411;
    break;
  }
  default: heff_nomatch(v_x_242);
  }
  return (g_heff_2ecompile_2erepr_2eunite(v_a_249, v_t_2413, v_a_2410));
}
Clo g_list_2emap_24s1990719097x1419059608_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1990719097x1419059608_24dps_entry, 2, 0};

V g_list_2emap_24s1990719097x1419059608_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(v_x_242, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1990719097x1419059608_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1990719097x1419059608_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1457049037x722637222_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1457049037x722637222_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1457049037x722637222_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_249);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1457049037x722637222_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1457049037x722637222_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s634961829x758866838_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s634961829x758866838_entry, 2, 0};

V g_list_2ezipWith_24s634961829x758866838(V v_x2_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x3_241, 0);
      V v_ys_245 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_248;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_246 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_248 = v_a_246;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      V v_t_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_248, heff_get_n(v_y_244, 1, 2)});
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2411 = (g_list_2ezipWith_24s634961829x758866838_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_2410)));
      heff_drop(v_u_2411);
      return v_cell_2410;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s634961829x758866838_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s634961829x758866838(a[0], a[1]);
}
Clo g_list_2efoldl_24s532743697x1094589833_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s532743697x1094589833_entry, 2, 0};

V g_list_2efoldl_24s532743697x1094589833(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    HeffT2 v_t_2413 = ({ V a_0 = v_z_240; V b_1 = heff_get_n(v_t_2412, 0, 3); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2417;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_a_2416 = v_field_2415;
        v_t_2417 = v_a_2416;
      } else {
        heff_drop(v_field_2415);
        v_t_2417 = NTAG(TAG_Nil);
      }
    }
    V v_t_2418 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_z_240, heff_get_n(v_t_246, 0, 3), heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2417})));
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s532743697x1094589833_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s532743697x1094589833(a[0], a[1]);
}
Clo g_list_2efoldl_24s2018454372x1607369768_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2018454372x1607369768_entry, 7, 0};

V g_list_2efoldl_24s2018454372x1607369768(V v_lit_240, V v_box_24lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_z_245, V v_x3_246) {
  int64_t v_lit_241 = heff_unbox_word(v_box_24lit_241);
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return v_z_245;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_246, 0);
    V v_xs_248 = heff_field(v_x3_246, 1);
    V v_ru_24x3_246_24Cons = heff_take_reuse_n(v_x3_246, 3ULL, 2);
    V v_a_249 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_247), heff_dup(v_lit_240)));
    int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_a_249, 0)) - v_lit_241);
    V v_t_2411 = (g_heff_2ecompile_2eemit_2elastDotFrom(v_a_249, heff_box_word(v_t_2410)));
    V v_t_2412 = ({ V a_0 = v_a_249; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2eemit_2espellAt(a_0, a_1)); heff_drop(v_t_2411); r_; });
    V v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = heff_dup(v_lit_242); V a_2 = heff_dup(v_lit_243); V r_ = (g_heff_2ecompile_2eemit_2esafeChars(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_heff_2ecompile_2eemit_2esafeFrom(v_t_2413));
    HeffT2 v_t_2415 = (g_heff_2ecompile_2eemit_2ebindFrom_24cpr(heff_take_field(v_z_245, 1), v_x_247, v_t_2414, heff_dup(v_lit_244)));
    V v_t_2420;
    {
      V v_field_2416 = v_t_2415.f[0];
      V v_field_2417 = v_t_2415.f[1];
      V v_t_2418 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){v_field_2416, NTAG(TAG_Nil)});
      V v_t_2419 = (g_prelude_2e_2b_2b(heff_get_n(v_z_245, 0, 2), v_t_2418));
      v_t_2420 = heff_rec_n(2, shape_js__env, (V[]){v_t_2419, v_field_2417});
    }
    V t_0 = v_lit_240;
    int64_t t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_t_2420;
    V t_6 = v_xs_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_z_245 = t_5;
    v_x3_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_list_2efoldl_24s2018454372x1607369768_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2018454372x1607369768(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s1455783996x1449538216_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1455783996x1449538216_entry, 1, 0};

V g_list_2emap_24s1455783996x1449538216(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = v_x_241;
    V v_t_2437;
    switch (heff_tag_of(v_x1_243)) {
    case TAG_PartVal: {
      V v_x11_244 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24PartVal = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_SVar: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_246 = heff_field(v_x11_244, 0);
        heff_take_n(v_x11_244, 1ULL, 1);
        v_t_2437 = heff_tag_at_n(v_ru_24x1_243_24PartVal, TAG_Just, 1, (V[]){v_g_246});
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x11_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_x11_244, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x11_244, 0ULL, 4);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x11_244, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_243_24PartVal, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    case TAG_PartOp: {
      V v_x11_2428 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24PartOp = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      switch (heff_tag_of(v_x11_2428)) {
      case TAG_OSimple: {
        heff_take_n(v_x11_2428, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartOp, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OCall: {
        V v_g_2430 = heff_field(v_x11_2428, 0);
        heff_take_n(v_x11_2428, 1ULL, 2);
        v_t_2437 = heff_tag_at_n(v_ru_24x1_243_24PartOp, TAG_Just, 1, (V[]){v_g_2430});
        break;
      }
      case TAG_OApply: {
        heff_take_n(v_x11_2428, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_243_24PartOp, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OPrim: {
        heff_take_n(v_x11_2428, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_243_24PartOp, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x1_243_24PartOp, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_OBool: {
        heff_take_n(v_x11_2428, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_243_24PartOp, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2428);
      }
      break;
    }
    default: heff_nomatch(v_x1_243);
    }
    V v_cell_2438 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_u_2439 = (g_list_2emap_24s1455783996x1449538216_24dps(v_xs_242, heff_dup(v_cell_2438)));
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1455783996x1449538216_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1455783996x1449538216(a[0]);
}
Clo g_list_2emap_24s129316455x2072694707_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s129316455x2072694707_24dps_entry, 2, 0};

V g_list_2emap_24s129316455x2072694707_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_a_244), v_a_244});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s129316455x2072694707_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s129316455x2072694707_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1418269708x2034621695_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1418269708x2034621695_entry, 2, 0};

V g_list_2emap_24s1418269708x2034621695(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strSlice(heff_dup(v_x_242), heff_dup(v_lit_240), heff_strLength(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s1418269708x2034621695_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1418269708x2034621695_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1418269708x2034621695(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s796727596x829078925_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s796727596x829078925_24dps_entry, 2, 0};

V g_list_2emap_24s796727596x829078925_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s796727596x829078925_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s796727596x829078925_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s204237290x1967740547_str0, 15, "the primitive `");
HEFF_LIT(g_list_2emap_24s204237290x1967740547_str1, 14, "` is declared ");
HEFF_LIT(g_list_2emap_24s204237290x1967740547_str2, 6, ", and ");
Clo g_list_2emap_24s204237290x1967740547_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s204237290x1967740547_entry, 4, 0};

V g_list_2emap_24s204237290x1967740547(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_done_246 = heff_dup(v_lit_240);
    V v_imps_247 = heff_dup(v_lit_241);
    V v_c_248 = heff_dup(v_lit_242);
    V v_t_249 = v_x_244;
    V v_again_2410 = heff_take_field(v_t_249, 1);
    V v_first_2411 = heff_get_n(v_t_249, 0, 2);
    V v_t_2412 = heff_strAppend(((V)&g_list_2emap_24s204237290x1967740547_str0), heff_take_field(v_again_2410, 0));
    V v_t_2413 = (g_heff_2ebuild_2edriver_2eplaceAt(heff_take_field(v_first_2411, 1), heff_get_n(v_first_2411, 2, 3)));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_list_2emap_24s204237290x1967740547_str1)), v_t_2413);
    V v_t_2415 = (g_heff_2ebuild_2edriver_2eplaceAt(heff_dup(heff_rfield(v_again_2410, 1)), heff_dup(heff_rfield(v_again_2410, 2))));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_list_2emap_24s204237290x1967740547_str2)), v_t_2415);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_again_2410, 1)), 0, 14);
    V v_t_2419;
    if (heff_strEq_c(v_t_2417, heff_get_n(v_c_248, 0, 14))) {
      heff_drop(v_done_246);
      heff_drop_rec(v_imps_247, 4);
      v_t_2419 = heff_get_n(v_again_2410, 2, 3);
    } else {
      V v_t_2418 = heff_get_n(heff_get_n(v_again_2410, 1, 3), 0, 14);
      v_t_2419 = ({ V a_0 = v_done_246; V a_1 = v_t_2418; V b_2 = heff_get_n(v_imps_247, 0, 4); V r_ = (g_heff_2ebuild_2edriver_2eimportOfGo(a_0, a_1, b_2)); heff_drop(v_done_246); heff_drop(b_2); r_; });
    }
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(336LL), NTAG(TAG_SError), v_t_2416, v_t_2419, NTAG(TAG_Nothing)});
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = (g_list_2emap_24s204237290x1967740547_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2421)));
    heff_drop(v_u_2422);
    return v_cell_2421;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s204237290x1967740547_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s204237290x1967740547(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s1895313378x47656836_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895313378x47656836_entry, 1, 0};

V g_list_2emap_24s1895313378x47656836(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = ({ V a_0 = v_x_241; V r_ = (g_heff_2ebuild_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_241); r_; });
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1895313378x47656836_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895313378x47656836(a[0]);
}
HEFF_LIT(g_list_2emap_24s219049803x1458391381_str0, 0, "");
Clo g_list_2emap_24s219049803x1458391381_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s219049803x1458391381_entry, 1, 0};

V g_list_2emap_24s219049803x1458391381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPath: {
      V v_xs_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_xs_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_x1_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_list_2emap_24s219049803x1458391381_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      v_t_2410 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s219049803x1458391381_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s219049803x1458391381(a[0]);
}
Clo g_list_2emergeRuns_24s1094647646x865851942_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s1094647646x865851942_entry, 2, 0};

V g_list_2emergeRuns_24s1094647646x865851942(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s1236926497x1606764496(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      V v_ru_24x32_243_24Cons = heff_take_reuse_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s782281454x118641000(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_2414;
      switch (heff_tag_of(v_xs_245)) {
      case TAG_Nil: {
        V v_t_247 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        v_t_2414 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_y_248 = heff_field(v_xs_245, 0);
        V v_ys_249 = heff_field(v_xs_245, 1);
        V v_ru_24xs_245_24Cons = heff_take_reuse_n(v_xs_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_x_244, 2)), 0, 2);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_y_248, 2)), 0, 2);
        if (heff_intLe_c(v_t_2410, v_t_2411)) {
          V v_t_2412 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2414 = (g_list_2eascending_24s390745979x1196509894(heff_dup(v_y_248), heff_tag_at_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_t_2412}), v_ys_249));
        } else {
          V v_t_2413 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2414 = (g_list_2edescending_24s1679501129x89119467(heff_dup(v_y_248), heff_tag_at_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_t_2413}), v_ys_249));
        }
        break;
      }
      default: heff_nomatch(v_xs_245);
      }
      V t_0 = v_t_246;
      V t_1 = v_t_2414;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s1094647646x865851942_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s1094647646x865851942(a[0], a[1]);
}
Clo g_list_2emap_24s698781565x943874959_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s698781565x943874959_entry, 7, 0};

V g_list_2emap_24s698781565x943874959(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_JNull: {
      v_t_2415 = heff_dup(v_lit_240);
      break;
    }
    case TAG_JBool: {
      heff_take_n(v_x_247, 0ULL, 1);
      v_t_2415 = heff_dup(v_lit_241);
      break;
    }
    case TAG_JInt: {
      heff_take_n(v_x_247, 0ULL, 1);
      v_t_2415 = heff_dup(v_lit_242);
      break;
    }
    case TAG_JFloat: {
      heff_take_na(v_x_247, 0ULL, 1);
      v_t_2415 = heff_dup(v_lit_243);
      break;
    }
    case TAG_JString: {
      V v_a_2412 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 1);
      v_t_2415 = v_a_2412;
      break;
    }
    case TAG_JArray: {
      heff_take_n(v_x_247, 0ULL, 1);
      v_t_2415 = heff_dup(v_lit_244);
      break;
    }
    case TAG_JObject: {
      heff_take_n(v_x_247, 0ULL, 1);
      v_t_2415 = heff_dup(v_lit_245);
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s698781565x943874959_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s698781565x943874959_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s698781565x943874959(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2emap_24s580776739x648604941_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s580776739x648604941_24dps_entry, 2, 0};

V g_list_2emap_24s580776739x648604941_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_TagVariant: {
        V v_t_246 = heff_field(v_x11_244, 0);
        V v_args_248 = heff_field(v_x11_244, 2);
        heff_take_n(v_x11_244, 5ULL, 3);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__args, (V[]){v_t_246, v_args_248})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s580776739x648604941_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s580776739x648604941_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s633938771x532201311_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s633938771x532201311_entry, 2, 0};

V g_list_2efind_24s633938771x532201311(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_lit_240, 0));
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_245 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_245)) {
      case TAG_DeclEquations: {
        V v_a_247 = heff_field(v_a_245, 0);
        if (heff_strEq_c_lent(v_a_244, v_a_247, 1)) {
          heff_drop_rec(v_lit_240, 2);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclDefine: {
        V v_a_2412 = heff_field(v_a_245, 0);
        if (heff_strEq_c_lent(v_a_244, v_a_2412, 1)) {
          heff_drop_rec(v_lit_240, 2);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclTheory: {
        V v_a_2417 = heff_field(v_a_245, 0);
        if (heff_strEq_c_lent(v_a_244, v_a_2417, 1)) {
          heff_drop_rec(v_lit_240, 2);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclPrimitive: {
        V v_a_2421 = heff_field(v_a_245, 0);
        if (heff_strEq_c_lent(v_a_244, v_a_2421, 1)) {
          heff_drop_rec(v_lit_240, 2);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclTest: {
        V v_a_2424 = heff_field(v_a_245, 0);
        if (heff_strEq_c_lent(v_a_244, v_a_2424, 1)) {
          heff_drop_rec(v_lit_240, 2);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
        } else {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
      case TAG_DeclWatch: {
        heff_drop(v_a_244);
        switch (heff_tag_of(v_x_242)) {
        case TAG_At: {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_x_242);
        }
      }
      default: return heff_nomatch(v_a_245);
      }
    }
    default: return heff_nomatch(v_x_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s633938771x532201311_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s633938771x532201311(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1372232877x278600396_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1372232877x278600396_24dps_entry, 2, 0};

V g_list_2emap_24s1372232877x278600396_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2elsp_2esplit_2eexprName(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1372232877x278600396_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1372232877x278600396_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s304198972x561714839_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s304198972x561714839_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s304198972x561714839_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_245;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_243, 4);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s304198972x561714839_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s304198972x561714839_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str0, 5, "label");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str1, 4, "kind");
HEFF_LIT(g_list_2emap_24s4199228x1154005405_str2, 6, "detail");
Clo g_list_2emap_24s4199228x1154005405_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s4199228x1154005405_entry, 1, 0};

V g_list_2emap_24s4199228x1154005405(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_label_243 = heff_take_field(v_x_241, 0);
    V v_detail_244 = heff_get_n(v_x_241, 1, 2);
    V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str0), heff_tag_n(TAG_JString, 1, (V[]){v_label_243})});
    V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str1), heff_tag_n(TAG_JInt, 1, (V[]){MK_INT(3LL)})});
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_list_2emap_24s4199228x1154005405_str2), heff_tag_n(TAG_JString, 1, (V[]){v_detail_244})});
    V v_t_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_248})});
    V v_cell_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_JObject, 1, (V[]){v_t_249}), heff_hole()});
    V v_u_2411 = (g_list_2emap_24s4199228x1154005405_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s4199228x1154005405(a[0]);
}
Clo g_list_2emap_24f2053285389x511622380_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2053285389x511622380_24dps_entry, 6, 0};

V g_list_2emap_24f2053285389x511622380_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_a_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 2), heff_take_field(v_x_246, 3)});
      V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_get_n(v_x_246, 1, 7));
      V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(v_t_2410, heff_dup(v_lit_242)), v_a_249, NTAG(TAG_Nothing)});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    } else {
      heff_drop_rec(v_x_246, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_d_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f2053285389x511622380_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f2053285389x511622380_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1619849299x1543923271_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1619849299x1543923271_24dps_entry, 2, 0};

V g_list_2emap_24f1619849299x1543923271_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_body_244 = heff_take_field(v_x_242, 2);
    V v_key_245 = heff_get_n(v_x_242, 0, 3);
    V v_t_2446;
    switch (heff_tag_of(v_body_244)) {
    case TAG_EVar: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_body_244, NTAG(TAG_Nil)});
      v_t_2446 = (g_heff_2ecompile_2eworker_2enumericW(v_t_2410));
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_body_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_body_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_body_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_body_244, 0ULL, 4);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_body_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_body_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_body_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_body_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_body_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_body_244, 0ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_body_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_body_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_body_244);
    }
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_t_2446);
      V v_cell_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_key_245, heff_hole()});
      V v_u_2448 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2447));
      heff_drop(v_u_2448);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2447;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_key_245);
      heff_drop(v_t_2446);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24f1619849299x1543923271_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1619849299x1543923271_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24f1488358745x465096512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1488358745x465096512_entry, 2, 0};

V g_list_2efoldl_24f1488358745x465096512(V v_z_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24At = heff_take_reuse_n(v_x1_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_EVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ETag: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ERune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EProject: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EPi: {
      V v_x111_2418 = heff_field(v_x11_242, 0);
      V v_r_2419 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      switch (heff_tag_of(v_x111_2418)) {
      case TAG_PiNamed: {
        heff_take_n(v_x111_2418, 0ULL, 3);
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_r_2419);
        return v_z_240;
      }
      case TAG_PiImplicit: {
        V v_x_2423 = heff_field(v_x111_2418, 0);
        V v_sp_2424 = heff_field(v_x111_2418, 1);
        heff_take_n(v_x111_2418, 3ULL, 5);
        V v_x_2428 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2423, v_sp_2424, NTAG(TAG_False)});
        V t_0 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2428, v_z_240});
        V t_1 = v_r_2419;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_PiInstance: {
        V v_x_2429 = heff_field(v_x111_2418, 0);
        V v_sp_2430 = heff_field(v_x111_2418, 1);
        heff_take_n(v_x111_2418, 3ULL, 4);
        V v_x_2433 = heff_rec_n(3, shape_name__span__field, (V[]){v_x_2429, v_sp_2430, NTAG(TAG_False)});
        V t_0 = heff_tag_at_n(v_ru_24x1_241_24At, TAG_Cons, 2, (V[]){v_x_2433, v_z_240});
        V t_1 = v_r_2419;
        v_z_240 = t_0;
        v_x1_241 = t_1;
        goto top;
      }
      case TAG_PiAnon: {
        heff_take_n(v_x111_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_241_24At, 2);
        heff_drop(v_r_2419);
        return v_z_240;
      }
      default: return heff_nomatch(v_x111_2418);
      }
    }
    case TAG_ELam: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESig: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ESum: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EDo: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EFor: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ENest: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_ETry: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    case TAG_EWith: {
      heff_take_n(v_x11_242, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_241_24At, 2);
      return v_z_240;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1488358745x465096512(a[0], a[1]);
}
Clo g_list_2emap_24f1213328022x1811586494_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1213328022x1811586494_24dps_entry, 3, 0};

V g_list_2emap_24f1213328022x1811586494_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_binder_245 = heff_take_field(v_x_243, 0);
    V v_use_246 = heff_get_n(v_x_243, 1, 2);
    V v_a_247 = heff_get_n(v_binder_245, 1, 3);
    V v_start_248 = heff_take_field(v_a_247, 0);
    V v_end_249 = heff_get_n(v_a_247, 1, 2);
    V v_a_2410 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_2411 = heff_take_field(v_a_2410, 0);
    V v_end_2412 = heff_get_n(v_a_2410, 1, 2);
    if ((heff_intEq_c_lent(v_start_248, v_start_2411, 0) && heff_intEq_c_lent(v_end_249, v_end_2412, 0))) {
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_start_2411);
      heff_drop(v_end_2412);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_use_246, heff_hole()});
      V v_u_2414 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2413;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_use_246);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_start_2411);
      heff_drop(v_end_2412);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1213328022x1811586494_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1213328022x1811586494_24dps(a[0], a[1], a[2]);
}